package com.tracfone.ejb.entity.retail;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "C_RTL_TP_NORM", uniqueConstraints = @UniqueConstraint(columnNames = {
        "TP2ZIP", "TP2CARRIER_DTL" }))
@XmlRootElement
@NamedQueries({@NamedQuery(name = "CRtlTpNorm.findByZipAndCarrierDetail",
        query = "SELECT c FROM CRtlTpNorm c where c.tp2Zip = :tp2Zip and c.tp2CarrierDtl = :tp2CarrierDtl")})
public class CRtlTpNorm implements Serializable {
    private static final long serialVersionUID = -2519166323117755246L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Tp_Norm_Seq")
    @SequenceGenerator(name = "Tp_Norm_Seq", sequenceName = "C_RTL_TP_NORM_SEQ", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "OBJID", unique = true, nullable = false, precision = 22, scale = 0)
    private BigDecimal objid;
    @Column(name = "TP2USER", nullable = false)
    private String secUserId;
    @Column(name = "TP2ZIP", nullable = false)
    private String tp2Zip;
    @Column(name = "TP2CARRIER_DTL", nullable = false)
    private BigDecimal tp2CarrierDtl;
    @Column(name = "RANK")
    private BigDecimal rank;
    @Column(name = "SFLK_STATE")
    private BigDecimal state;
    @Column(name = "COVERAGE", nullable = false, length = 35)
    private String coverage;
    @Column(name = "COVERAGE_NOTES", nullable = false, length = 50)
    private String coverageNotes;
    @Column(name = "ENV")
    private String env;
    @Temporal(TemporalType.DATE)
    @Column(name = "INSERT_DATE", nullable = false, length = 7)
    private Date insertDate;
    @Temporal(TemporalType.DATE)
    @Column(name = "UPDATE_DATE", length = 7)
    private Date updateDate;

    public BigDecimal getObjid() {
        return objid;
    }

    public void setObjid(BigDecimal objid) {
        this.objid = objid;
    }

    public String getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(String secUserId) {
        this.secUserId = secUserId;
    }

    public String getTp2Zip() {
        return tp2Zip;
    }

    public void setTp2Zip(String tp2Zip) {
        this.tp2Zip = tp2Zip;
    }

    public BigDecimal getTp2CarrierDtl() {
        return tp2CarrierDtl;
    }

    public void setTp2CarrierDtl(BigDecimal tp2CarrierDtl) {
        this.tp2CarrierDtl = tp2CarrierDtl;
    }

    public BigDecimal getRank() {
        return rank;
    }

    public void setRank(BigDecimal rank) {
        this.rank = rank;
    }

    public BigDecimal getState() {
        return state;
    }

    public void setState(BigDecimal state) {
        this.state = state;
    }

    public String getCoverage() {
        return coverage;
    }

    public void setCoverage(String coverage) {
        this.coverage = coverage;
    }

    public String getCoverageNotes() {
        return coverageNotes;
    }

    public void setCoverageNotes(String coverageNotes) {
        this.coverageNotes = coverageNotes;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}
