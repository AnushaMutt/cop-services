package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlCarrierPref;

import javax.ejb.Local;
import javax.persistence.EntityManager;

@Local
public interface CRtlCarrierPrefFacadeLocal {
    CRtlCarrierPref find(Object id);

    void create(CRtlCarrierPref cRtlCarrierPrefGrp);

    EntityManager getEntityManager();

    void remove(CRtlCarrierPref cRtlCarrierPref);
}
