/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.UserDbenv;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author user
 */
@Local
public interface UserDbenvFacadeLocal {

    void create(UserDbenv userDbenv);

    void edit(UserDbenv userDbenv);

    void remove(UserDbenv userDbenv);

    UserDbenv find(Object id);

    List<UserDbenv> findAll();

    List<UserDbenv> findRange(int[] range);

    int count();
    
}
