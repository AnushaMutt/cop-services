package com.tracfone.ejb.entity.retail;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "C_RTL_PARENT", uniqueConstraints = @UniqueConstraint(columnNames = "RETAILER"))
@XmlRootElement
@NamedQueries({@NamedQuery(name = "CRtlParent.findAll", query = "SELECT c FROM CRtlParent c order by c.retailer")})
public class CRtlParent implements Serializable {
    private static final long serialVersionUID = 139056674118158015L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Carrier_Parent_Seq")
    @SequenceGenerator(name = "Carrier_Parent_Seq", sequenceName = "C_RTL_PARENT_SEQ", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "OBJID", unique = true, nullable = false, precision = 22, scale = 0)
    private BigDecimal objid;
    @Column(name = "RETAILER", nullable = false, length = 125)
    private String retailer;
    @Column(name = "PARENT2USER", nullable = false)
    private BigDecimal secUserId;
    @Column(name = "PARENT2GROUPING")
    private BigDecimal groupingId;
    @Column(name = "STATUS", nullable = false, length = 10)
    private String status;
    @Temporal(TemporalType.DATE)
    @Column(name = "INSERT_DATE", nullable = false, length = 7)
    private Date insertDate;
    @Temporal(TemporalType.DATE)
    @Column(name = "UPDATE_DATE", length = 7)
    private Date updateDate;

    public CRtlParent() {
    }

    public BigDecimal getObjid() {
        return objid;
    }

    public void setObjid(BigDecimal objid) {
        this.objid = objid;
    }

    public String getRetailer() {
        return retailer;
    }

    public void setRetailer(String retailer) {
        this.retailer = retailer;
    }

    public BigDecimal getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(BigDecimal secUserId) {
        this.secUserId = secUserId;
    }

    public BigDecimal getGroupingId() {
        return groupingId;
    }

    public void setGroupingId(BigDecimal groupingId) {
        this.groupingId = groupingId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}