package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlBrand;
import com.tracfone.ejb.entity.retail.CRtlCarrierDtl;

import javax.ejb.Local;
import java.util.List;

@Local
public interface CRtlBrandFacadeLocal {
    CRtlBrand find(Object id);

    List<CRtlBrand> findAll();

    void create(CRtlBrand cRtlBrand);

    void edit(CRtlBrand cRtlBrand);
}
