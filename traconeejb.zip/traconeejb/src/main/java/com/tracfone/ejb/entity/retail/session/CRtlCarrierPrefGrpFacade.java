package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlCarrierPrefGrp;
import com.tracfone.ejb.entity.session.AbstractFacade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class CRtlCarrierPrefGrpFacade extends AbstractFacade<CRtlCarrierPrefGrp> implements CRtlCarrierPrefGrpFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_2.0PU")
    private EntityManager em;

    public CRtlCarrierPrefGrpFacade() {
        super(CRtlCarrierPrefGrp.class);
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}

