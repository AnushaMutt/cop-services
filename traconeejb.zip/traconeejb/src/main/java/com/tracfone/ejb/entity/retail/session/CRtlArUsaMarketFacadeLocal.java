package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlArUsaMarket;

import javax.ejb.Local;
import javax.persistence.EntityManager;
import java.util.List;

@Local
public interface CRtlArUsaMarketFacadeLocal {

    List<CRtlArUsaMarket> findAll();

    CRtlArUsaMarket findRecord(String keyCode, String carrierEntity);

    void create(CRtlArUsaMarket cRtlArUsaMarket);

    void edit(CRtlArUsaMarket cRtlArUsaMarket);

    void remove(CRtlArUsaMarket cRtlArUsaMarket);

    EntityManager getEntityManager();
}
