/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.UserDbenv;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author user
 */
@Stateless
public class UserDbenvFacade extends AbstractFacade<UserDbenv> implements UserDbenvFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_1.0PU")
    private EntityManager em;

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    public UserDbenvFacade() {
        super(UserDbenv.class);
    }
    
}
