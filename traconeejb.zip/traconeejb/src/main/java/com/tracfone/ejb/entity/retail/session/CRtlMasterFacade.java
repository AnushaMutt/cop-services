package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlMaster;
import com.tracfone.ejb.entity.session.AbstractFacade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.util.List;

@Stateless
public class CRtlMasterFacade extends AbstractFacade<CRtlMaster> implements CRtlMasterFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_2.0PU")
    private EntityManager em;

    public CRtlMasterFacade() {
        super(CRtlMaster.class);
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    @Override
    public List<CRtlMaster> findAllByParent(BigDecimal master2Parent) {
        return em.createNamedQuery("CRtlMaster.findAllByParent")
                .setParameter("master2Parent", master2Parent)
                .getResultList();
    }
}
