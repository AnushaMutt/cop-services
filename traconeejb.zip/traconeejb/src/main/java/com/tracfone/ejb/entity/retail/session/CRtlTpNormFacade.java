package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlParentRule;
import com.tracfone.ejb.entity.retail.CRtlTpNorm;
import com.tracfone.ejb.entity.session.AbstractFacade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.util.List;

@Stateless
public class CRtlTpNormFacade extends AbstractFacade<CRtlTpNorm> implements CRtlTpNormFacadeLocal {
    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_2.0PU")
    private EntityManager em;

    public CRtlTpNormFacade() {
        super(CRtlTpNorm.class);
    }

    @Override
    public List<CRtlTpNorm> findByZipAndCarrierDetail(String tp2Zip, BigDecimal tp2CarrierDtl) {
        return em.createNamedQuery("CRtlTpNorm.findByZipAndCarrierDetail")
                .setParameter("tp2Zip", tp2Zip)
                .setParameter("tp2CarrierDtl", tp2CarrierDtl)
                .getResultList();
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}
