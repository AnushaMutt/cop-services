/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlTFOneReport;
import com.tracfone.ejb.entity.session.AbstractFacade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TemporalType;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Gaurav.Sharma
 */
@Stateless
public class CRtlReportFacade extends AbstractFacade<CRtlTFOneReport> implements CRtlReportFacadeLocal{
    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_2.0PU")
    private EntityManager em;

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    public CRtlReportFacade() {
        super(CRtlTFOneReport.class);
    }   
    
    @Override
    public CRtlTFOneReport findIgTopErrReportByDate(Date fromDate, Date toDate, String reportName) {
        List<CRtlTFOneReport> lastReports = ( List<CRtlTFOneReport>)em.createNamedQuery("CRtlTFOneReport.findByDateRange")
                .setParameter("fromDate", fromDate, TemporalType.TIMESTAMP)
                .setParameter("toDate", toDate, TemporalType.TIMESTAMP)
                .setParameter("reportName", reportName)
                .setMaxResults(1)
                .getResultList();
        
        if(lastReports.size() > 0)
            return (CRtlTFOneReport)lastReports.get(0);
        return null;
    }
    
    @Override
    public CRtlTFOneReport findLastRowInserted(String reportName) {
        List<CRtlTFOneReport> lastReports = ( List<CRtlTFOneReport>)em.createNamedQuery("CRtlTFOneReport.findLastRowInserted")
                .setParameter("reportName", reportName)
                .setMaxResults(1)
                .getResultList();
        if(lastReports.size() > 0)
            return (CRtlTFOneReport)lastReports.get(0);
        return null;
    }
    
    @Override
    public void deletetfOneReport(int numberOfdays) {

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, numberOfdays);
        //java.sql.Date purgeDate = new java.sql.Date(cal.getTimeInMillis());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String purgeDate = sdf.format(cal.getTime());
        //System.out.println("Purge Date : " + purgeDate);
        em.createNamedQuery("CRtlTFOneReport.purgeByDays").setParameter("oldDate", purgeDate).executeUpdate();
    }
}
