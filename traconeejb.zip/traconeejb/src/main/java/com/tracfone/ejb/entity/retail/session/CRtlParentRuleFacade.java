package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlMaster;
import com.tracfone.ejb.entity.retail.CRtlParentRule;
import com.tracfone.ejb.entity.session.AbstractFacade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.util.List;

@Stateless
public class CRtlParentRuleFacade extends AbstractFacade<CRtlParentRule> implements CRtlParentRuleFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_2.0PU")
    private EntityManager em;

    public CRtlParentRuleFacade() {
        super(CRtlParentRule.class);
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    @Override
    public List<CRtlParentRule> findAllByParent(BigDecimal rule2Parent) {
        return em.createNamedQuery("CRtlParentRule.findAllByParent")
                .setParameter("rule2Parent", rule2Parent)
                .getResultList();
    }
}
