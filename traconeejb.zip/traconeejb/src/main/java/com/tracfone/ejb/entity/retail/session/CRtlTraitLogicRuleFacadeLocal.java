package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlTraitLogicRule;

import javax.ejb.Local;
import java.util.List;

@Local
public interface CRtlTraitLogicRuleFacadeLocal {
    List<CRtlTraitLogicRule> findAll();

    void create(CRtlTraitLogicRule cRtlTraitLogicRule);

    CRtlTraitLogicRule find(Object id);

    void edit(CRtlTraitLogicRule cRtlTraitLogicRule);
}
