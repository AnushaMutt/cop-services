package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlMaster;

import javax.ejb.Local;
import java.math.BigDecimal;
import java.util.List;

@Local
public interface CRtlMasterFacadeLocal {
    CRtlMaster find(Object id);

    List<CRtlMaster> findAllByParent(BigDecimal master2Parent);

    void create(CRtlMaster cRtlMaster);

    void edit(CRtlMaster cRtlMaster);
}
