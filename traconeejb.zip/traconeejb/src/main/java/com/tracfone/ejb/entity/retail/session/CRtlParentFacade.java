package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlParent;
import com.tracfone.ejb.entity.session.AbstractFacade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class CRtlParentFacade extends AbstractFacade<CRtlParent> implements CRtlParentFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_2.0PU")
    private EntityManager em;

    public CRtlParentFacade() {
        super(CRtlParent.class);
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}

