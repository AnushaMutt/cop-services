package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlParent;

import javax.ejb.Local;
import java.util.List;

@Local
public interface CRtlParentFacadeLocal {
    CRtlParent find(Object id);

    List<CRtlParent> findAll();

    void create(CRtlParent cRtlParent);

    void edit(CRtlParent cRtlParent);
}
