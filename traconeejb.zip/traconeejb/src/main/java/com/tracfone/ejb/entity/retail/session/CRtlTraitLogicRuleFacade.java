package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlTraitLogicRule;
import com.tracfone.ejb.entity.session.AbstractFacade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class CRtlTraitLogicRuleFacade extends AbstractFacade<CRtlTraitLogicRule> implements CRtlTraitLogicRuleFacadeLocal {
    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_2.0PU")
    private EntityManager em;

    public CRtlTraitLogicRuleFacade() {
        super(CRtlTraitLogicRule.class);
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }
}
