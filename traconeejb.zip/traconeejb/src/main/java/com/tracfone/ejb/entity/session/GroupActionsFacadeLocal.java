/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.GroupActions;

import java.util.List;
import javax.ejb.Local;
import javax.persistence.EntityManager;

/**
 *
 * @author user
 */
@Local
public interface GroupActionsFacadeLocal {
    
    EntityManager getEntityManager();    
    
    void create(GroupActions group);

    void edit(GroupActions group);

    void remove(GroupActions group);

    GroupActions find(Object id);

    List<GroupActions> findAll();

    List<GroupActions> findRange(int[] range);

    List<GroupActions> findAllEntityByGroupId(Integer id);
    
    List<Integer> findAllEntityByActionId(Integer id);
    
    List<Integer> findAllByGroupId(Integer id);
    
    int count();
}
