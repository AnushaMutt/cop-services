/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PersistenceUnit;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author user
 */
@Entity
@Table(name = "cop.cop_tfone_reports")
@XmlRootElement
@NamedQueries({
     @NamedQuery(name = "TFOneReport.findById", query = "SELECT r FROM TFOneReport r WHERE r.id = :id")
    ,@NamedQuery(name = "TFOneReport.findByDateRange", query = "SELECT r FROM TFOneReport r WHERE r.createddate >= :fromDate and r.createddate < :toDate AND r.reportName = :reportName")
    ,@NamedQuery(name = "TFOneReport.findLastRowInserted", query = "SELECT r FROM TFOneReport r WHERE r.reportName = :reportName order by r.id desc")
    ,@NamedQuery(name = "TFOneReport.purgeByDays", query = "DELETE FROM TFOneReport r WHERE FUNC('TRUNC', CAST(r.createddate as Date)) <= FUNCTION('TO_DATE' :oldDate, 'yyyy/mm/dd')")})

public class TFOneReport implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "TFOneReport_Seq")
    @SequenceGenerator(name="TFOneReport_Seq", sequenceName="cop.cop_tfone_reports_seq", allocationSize=1)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "createddate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createddate;
    @Column(name = "jsonResponse")
    private String jsonResponse;
    @Column(name = "reportName")
    private String reportName;

    public TFOneReport() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getCreateddate() {
        return createddate;
    }

    public void setCreateddate(Date createddate) {
        this.createddate = createddate;
    }

    public String getJsonResponse() {
        return jsonResponse;
    }

    public void setJsonResponse(String jsonResponse) {
        this.jsonResponse = jsonResponse;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TFOneReport)) {
            return false;
        }
        TFOneReport other = (TFOneReport) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.tracfone.ejb.entity.ReportIgError[ id=" + id + " ]";
    }
}
