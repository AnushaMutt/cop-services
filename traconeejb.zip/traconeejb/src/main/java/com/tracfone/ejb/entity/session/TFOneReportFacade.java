/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.TFOneReport;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TemporalType;

/**
 *
 * @author user
 */
@Stateless
public class TFOneReportFacade extends AbstractFacade<TFOneReport> implements TFOneReportFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_1.0PU")
    private EntityManager em;

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    public TFOneReportFacade() {
        super(TFOneReport.class);
    }   
    
    @Override
    public TFOneReport findIgTopErrReportByDate(Date fromDate, Date toDate, String reportName) {
        List<TFOneReport> lastReports = ( List<TFOneReport>)em.createNamedQuery("TFOneReport.findByDateRange")
                .setParameter("fromDate", fromDate, TemporalType.TIMESTAMP)
                .setParameter("toDate", toDate, TemporalType.TIMESTAMP)
                .setParameter("reportName", reportName)
                .setMaxResults(1)
                .getResultList();
        
        if(lastReports.size() > 0)
            return (TFOneReport)lastReports.get(0);
        return null;
    }
    
    @Override
    public TFOneReport findLastRowInserted(String reportName) {
        List<TFOneReport> lastReports = ( List<TFOneReport>)em.createNamedQuery("TFOneReport.findLastRowInserted")
                .setParameter("reportName", reportName)
                .setMaxResults(1)
                .getResultList();
        if(lastReports.size() > 0)
            return (TFOneReport)lastReports.get(0);
        return null;
    }
    
    @Override
    public void deletetfOneReport(int numberOfdays) {

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, numberOfdays);
        //java.sql.Date purgeDate = new java.sql.Date(cal.getTimeInMillis());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String purgeDate = sdf.format(cal.getTime());
        //System.out.println("Purge Date : " + purgeDate);
        em.createNamedQuery("TFOneReport.purgeByDays").setParameter("oldDate", purgeDate).executeUpdate();
    }
}
