/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.Carrier;
import java.util.List;
import javax.ejb.Local;
import javax.persistence.EntityManager;

/**
 *
 * @author Srinivas Murthy Pulavarthy
 */
@Local
public interface CarrierFacadeLocal {

    void create(Carrier action);

    void edit(Carrier action);

    void remove(Carrier action);

    Carrier find(Object id);

    int count();
    
    EntityManager getEntityManager();
    
   
    
    
}
