package com.tracfone.ejb.entity;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "cop.COP_USER_TASK")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "UserTask.AssignedUserId", query = "SELECT u FROM UserTask u WHERE u.assignedUserId = :assignedUserId  and u.status in :status " +
                "and FUNC('TRUNC', CAST(u.creationDate as Date)) >= FUNCTION('TO_DATE' :fromCreationDate, 'yyyy/mm/dd') " +
                "and FUNC('TRUNC', CAST(u.creationDate as Date)) <= FUNCTION('TO_DATE' :toCreationDate, 'yyyy/mm/dd') " +
                "and u.type = :type order by u.creationDate DESC"),
        @NamedQuery(name = "UserTask.purgeByDays", query = "DELETE FROM UserTask u WHERE FUNC('TRUNC', CAST(u.creationDate as Date)) <= FUNCTION('TO_DATE' :oldDate, 'yyyy/mm/dd')")})
public class UserTask implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "User_Task_Seq")
    @SequenceGenerator(name = "User_Task_Seq", sequenceName = "COP.SEQ_COP_USER_TASK", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Column(name = "TASK_NAME")
    private String taskName;
    @Column(name = "DESCRIPTION")
    private String description;
    @Column(name = "USER_ID")
    private Integer userId;
    @Column(name = "ASSIGNED_USERID")
    private Integer assignedUserId;
    @Column(name = "TYPE")
    private String type;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "CREATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;
    @Column(name = "UPDATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "userTask", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<UserTaskDetail> userTaskDetails;

    public UserTask() {
        userTaskDetails = new ArrayList<>();
    }

    public void addUserTaskDetail(UserTaskDetail userTaskDetail) {
        userTaskDetails.add(userTaskDetail);
        userTaskDetail.setUserTask(this);
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getAssignedUserId() {
        return assignedUserId;
    }

    public void setAssignedUserId(Integer assignedUserId) {
        this.assignedUserId = assignedUserId;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public List<UserTaskDetail> getUserTaskDetails() {
        return userTaskDetails;
    }

    public void setUserTaskDetails(List<UserTaskDetail> userTaskDetails) {
        this.userTaskDetails = userTaskDetails;
    }

}