package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.UserHistory;

import javax.ejb.Local;

@Local
public interface UserHistoryFacadeLocal {

    void create(UserHistory userHistory);

    void edit(UserHistory userHistory);

    void deleteUserHistory(int numberOfdays);

}
