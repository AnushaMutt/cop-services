package com.tracfone.ejb.entity.retail;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "C_RTL_MASTER", uniqueConstraints = @UniqueConstraint(columnNames = {
        "MASTER2PARENT", "STORE_NAME" }))
@XmlRootElement
@NamedQueries({@NamedQuery(name = "CRtlMaster.findAllByParent",
        query = "SELECT c FROM CRtlMaster c where c.master2Parent = :master2Parent order by c.storeName")})
public class CRtlMaster implements Serializable {
    private static final long serialVersionUID = 139056674118158015L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Carrier_Master_Seq")
    @SequenceGenerator(name = "Carrier_Master_Seq", sequenceName = "C_RTL_MASTER_SEQ", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "OBJID", unique = true, nullable = false, precision = 22, scale = 0)
    private BigDecimal objid;
    @Column(name = "STORE_NAME", nullable = false, length = 125)
    private String storeName;
    @Column(name = "MASTER2USER", nullable = false)
    private BigDecimal secUserId;
    @Column(name = "MASTER2PARENT", nullable = false)
    private BigDecimal master2Parent;
    @Column(name = "STATUS", nullable = false, length = 10)
    private String status;
    @Temporal(TemporalType.DATE)
    @Column(name = "INSERT_DATE", nullable = false, length = 7)
    private Date insertDate;
    @Temporal(TemporalType.DATE)
    @Column(name = "UPDATE_DATE", length = 7)
    private Date updateDate;

    public BigDecimal getObjid() {
        return objid;
    }

    public void setObjid(BigDecimal objid) {
        this.objid = objid;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public BigDecimal getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(BigDecimal secUserId) {
        this.secUserId = secUserId;
    }

    public BigDecimal getMaster2Parent() {
        return master2Parent;
    }

    public void setMaster2Parent(BigDecimal master2Parent) {
        this.master2Parent = master2Parent;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}
