package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlBrand;
import com.tracfone.ejb.entity.retail.CRtlTech;
import com.tracfone.ejb.entity.session.AbstractFacade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class CRtlTechFacade extends AbstractFacade<CRtlTech> implements CRtlTechFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_2.0PU")
    private EntityManager em;

    public CRtlTechFacade() {
        super(CRtlTech.class);
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    @Override
    public void edit(CRtlTech entity) {
        getEntityManager().persist(entity);
        getEntityManager().flush();
        getEntityManager().refresh(entity);
    }

}
