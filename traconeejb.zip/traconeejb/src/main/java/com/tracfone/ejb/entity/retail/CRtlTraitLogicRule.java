package com.tracfone.ejb.entity.retail;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;

@Entity
@Table(name = "C_RTL_TRAIT_LOGIC_RULE")
@XmlRootElement
@NamedQueries({@NamedQuery(name = "CRtlTraitLogicRule.findAll", query = "SELECT c FROM CRtlTraitLogicRule c")})
public class CRtlTraitLogicRule implements Serializable {
    private static final long serialVersionUID = -6114867101593517202L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Trait_Logic_Rule_Seq")
    @SequenceGenerator(name = "Trait_Logic_Rule_Seq", sequenceName = "C_RTL_TRAIT_LOGIC_RULE_SEQ", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "OBJID", unique = true, nullable = false, precision = 22, scale = 0)
    private BigDecimal objid;
    @Column(name = "RULE_NAME", nullable = false, length = 30)
    private String ruleName;
    @Column(name = "INNER_RADIUS")
    private BigDecimal innerRadius;
    @Column(name = "INNER_POP")
    private BigDecimal innerPop;
    @Column(name = "INNER_GEO")
    private BigDecimal innerGeo;
    @Column(name = "OUTER_RADIUS")
    private BigDecimal outerRadius;
    @Column(name = "OUTER_POP")
    private BigDecimal outerPop;
    @Column(name = "OUTER_GEO")
    private BigDecimal outerGeo;
    @Column(name = "USE_OUTER_POP")
    private BigDecimal useOuterPop;
    @Column(name = "RULE2LOGIC")
    private String rule2Logic;
    @Column(name = "RULE2USER")
    private String secUserId;
    @Column(name = "PREF_ALL_CARR")
    private BigDecimal prefAllCarr;

    public CRtlTraitLogicRule() {
    }

    public BigDecimal getObjid() {
        return objid;
    }

    public void setObjid(BigDecimal objid) {
        this.objid = objid;
    }

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public BigDecimal getInnerRadius() {
        return innerRadius;
    }

    public void setInnerRadius(BigDecimal innerRadius) {
        this.innerRadius = innerRadius;
    }

    public BigDecimal getInnerPop() {
        return innerPop;
    }

    public void setInnerPop(BigDecimal innerPop) {
        this.innerPop = innerPop;
    }

    public BigDecimal getInnerGeo() {
        return innerGeo;
    }

    public void setInnerGeo(BigDecimal innerGeo) {
        this.innerGeo = innerGeo;
    }

    public BigDecimal getOuterRadius() {
        return outerRadius;
    }

    public void setOuterRadius(BigDecimal outerRadius) {
        this.outerRadius = outerRadius;
    }

    public BigDecimal getOuterPop() {
        return outerPop;
    }

    public void setOuterPop(BigDecimal outerPop) {
        this.outerPop = outerPop;
    }

    public BigDecimal getOuterGeo() {
        return outerGeo;
    }

    public void setOuterGeo(BigDecimal outerGeo) {
        this.outerGeo = outerGeo;
    }

    public BigDecimal getUseOuterPop() {
        return useOuterPop;
    }

    public void setUseOuterPop(BigDecimal useOuterPop) {
        this.useOuterPop = useOuterPop;
    }

    public String getRule2Logic() {
        return rule2Logic;
    }

    public void setRule2Logic(String rule2Logic) {
        this.rule2Logic = rule2Logic;
    }

    public String getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(String secUserId) {
        this.secUserId = secUserId;
    }

    public BigDecimal getPrefAllCarr() {
        return prefAllCarr;
    }

    public void setPrefAllCarr(BigDecimal prefAllCarr) {
        this.prefAllCarr = prefAllCarr;
    }
}
