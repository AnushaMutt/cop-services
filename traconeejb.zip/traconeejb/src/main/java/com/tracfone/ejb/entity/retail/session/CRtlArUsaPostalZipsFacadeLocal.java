package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlArUsaPostalZips;

import javax.ejb.Local;
import javax.persistence.EntityManager;
import java.util.List;

@Local
public interface CRtlArUsaPostalZipsFacadeLocal {

    List<CRtlArUsaPostalZips> findAll();

    void create(CRtlArUsaPostalZips cRtlArUsaPostalZips);

    void edit(CRtlArUsaPostalZips cRtlArUsaPostalZips);

    void remove(CRtlArUsaPostalZips cRtlArUsaPostalZips);

    EntityManager getEntityManager();
}
