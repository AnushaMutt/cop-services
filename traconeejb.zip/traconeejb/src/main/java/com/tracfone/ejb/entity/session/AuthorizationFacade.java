/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author user
 */
@Stateless
public class AuthorizationFacade implements AuthorizationFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_1.0PU")
    private EntityManager em;
    
    /*private String jpaQuery = "SELECT  a.id, a.name, ug.userid " +
                              " FROM Usergroups ug , GroupActions ga, Action a " +
                              " WHERE ug.userid= :userId " +
                            " and a.serviceuri = :resource" +
                            " and ug.groupid = ga.groupId" +
                            " and a.id = ga.actionId";
  */
      private String jpaQuery = "SELECT  a.id, a.name, ug.userid " +
                              " FROM Usergroups ug , GroupActions ga, Action a, ServiceDetails sd " +
                              " WHERE ug.userid= :userId " +
                            " and a.serviceid = sd.sid" +
                            " and sd.serviceuri = :resource" + 
                            " and ug.groupid = ga.groupId" +
                            " and a.id = ga.actionId";

    public EntityManager getEntityManager() {
        return em;
    }

    @Override
    public int find(int id, String resource) {
        
        List resourceAccessList = em.createQuery(jpaQuery).setParameter("userId", id).setParameter("resource", resource).getResultList();
        return resourceAccessList.size();
    }
    
}
