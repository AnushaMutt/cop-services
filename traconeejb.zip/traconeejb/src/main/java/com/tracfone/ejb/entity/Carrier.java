/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity;




/**
 *
 * @author Srinivas Murthy Pulavarthy
 */

public class Carrier  {

    private static final long serialVersionUID = 1L;
    

    private String feature_value;

    public String getFeature_Value() {
        return feature_value;
    }

    public void setFeature_Value(String feature_value) {
        this.feature_value = feature_value;
    }
}
