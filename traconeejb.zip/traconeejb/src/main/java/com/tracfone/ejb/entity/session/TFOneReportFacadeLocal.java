
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.TFOneReport;
import java.util.Date;
import javax.ejb.Local;

/**
 *
 * @author user
 */
@Local
public interface TFOneReportFacadeLocal {

    void create(TFOneReport report);

    void edit(TFOneReport report);

    void remove(TFOneReport report);

    TFOneReport find(Object id);
    
    TFOneReport findIgTopErrReportByDate(Date fromDate, Date toDate, String reportName);
    
    TFOneReport findLastRowInserted(String reportName);
    
    void deletetfOneReport(int numberOfdays);

    int count();   
}