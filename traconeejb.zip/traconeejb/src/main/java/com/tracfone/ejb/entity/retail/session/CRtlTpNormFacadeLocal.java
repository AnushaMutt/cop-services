package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlTpNorm;

import javax.ejb.Local;
import javax.persistence.EntityManager;
import java.math.BigDecimal;
import java.util.List;

@Local
public interface CRtlTpNormFacadeLocal {
    void create(CRtlTpNorm cRtlTpNorm);

    CRtlTpNorm find(Object id);

    List<CRtlTpNorm> findByZipAndCarrierDetail(String tp2Zip, BigDecimal tp2CarrierDtl);

    void edit(CRtlTpNorm cRtlTpNorm);

    EntityManager getEntityManager();
}
