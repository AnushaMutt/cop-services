package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.UserTask;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

@Stateless
public class UserTaskFacade extends AbstractFacade<UserTask> implements UserTaskFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_1.0PU")
    private EntityManager em;

    public UserTaskFacade() {
        super(UserTask.class);
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    @Override
    public List<UserTask> findAllUserTask(Integer assignedUserId, List<String> status,
                                          String fromCreationDate, String toCreationDate,
                                          String type) {
        List<UserTask> userTasks = (List<UserTask>) em.createNamedQuery("UserTask.AssignedUserId")
                .setParameter("assignedUserId", assignedUserId)
                .setParameter("status", status)
                .setParameter("fromCreationDate", fromCreationDate)
                .setParameter("toCreationDate", toCreationDate)
                .setParameter("type", type)
                .getResultList();
        return userTasks;
    }

    @Override
    public void deleteUserTask(int numberOfdays) {

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, numberOfdays);
        //java.sql.Date purgeDate = new java.sql.Date(cal.getTimeInMillis());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String purgeDate = sdf.format(cal.getTime());
        //System.out.println("Purge Date : " + purgeDate);
        em.createNamedQuery("UserTask.purgeByDays").setParameter("oldDate", purgeDate).executeUpdate();
    }
}