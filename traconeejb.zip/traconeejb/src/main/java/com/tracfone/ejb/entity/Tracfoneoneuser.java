/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;

import javax.persistence.Table;

import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;


/**
 * @author user
 */
@Entity
@Table(name = "cop.cop_tracfoneoneuser")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "Tracfoneoneuser.findAll", query = "SELECT t FROM Tracfoneoneuser t")
        , @NamedQuery(name = "Tracfoneoneuser.findById", query = "SELECT t FROM Tracfoneoneuser t WHERE t.id = :id")
        , @NamedQuery(name = "Tracfoneoneuser.findByUsername", query = "SELECT t FROM Tracfoneoneuser t WHERE LOWER(t.username) = LOWER(:username)")
        , @NamedQuery(name = "Tracfoneoneuser.findByDescription", query = "SELECT t FROM Tracfoneoneuser t WHERE LOWER(t.description) = LOWER(:desc)")
        , @NamedQuery(name = "Tracfoneoneuser.findByToken", query = "SELECT t FROM Tracfoneoneuser t WHERE t.token = :token")
        , @NamedQuery(name = "Tracfoneoneuser.findByListOfId", query = "SELECT t FROM Tracfoneoneuser t WHERE t.id IN :listIDs")})
public class Tracfoneoneuser implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Tracfoneoneuser_Seq")
    @SequenceGenerator(name = "Tracfoneoneuser_Seq", sequenceName = "cop.cop_tracfoneoneuser_seq", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Size(max = 45)
    @Column(name = "username", nullable = false, unique = true)
    private String username;
    @Size(max = 100)
    @Column(name = "description")
    private String description;
    @Size(max = 100)
    @Column(name = "email")
    private String email;
    @Column(name = "token")
    private String token;
    @Column(name = "roleId", nullable = false)
    private Integer roleId;

    public Tracfoneoneuser() {
    }

    public Tracfoneoneuser(Integer id) {
        this.id = id;
    }

    public Tracfoneoneuser(Integer id, String token) {
        this.id = id;
        this.token = token;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tracfoneoneuser)) {
            return false;
        }
        Tracfoneoneuser other = (Tracfoneoneuser) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.tracfone.ejb.entity.Tracfoneoneuser[ id=" + id + " ]";
    }

}
