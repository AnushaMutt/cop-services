package com.tracfone.ejb.entity.retail;


import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@Entity
@Table(name="cop.AR_USA_MARKET")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "CRtlArUsaMarket.findRecords", query = "SELECT u FROM CRtlArUsaMarket u WHERE u.keyCode = :keyCode  and u.carrierEntity = :carrierEntity ")})
public class CRtlArUsaMarket implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "ArUsaMarket_Seq")
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "KEY_CODE")
    private String keyCode;
    @Column(name = "NATION", nullable = false)
    private String nation;
    @Column(name = "STATE", nullable = false)
    private String state;
    @Column(name = "COUNTY", nullable = false)
    private String county;
    @Column(name = "CARRIER_ENTITY", nullable = false)
    private String carrierEntity;
    @Column(name = "MARKETING_NAME", nullable = false)
    private String marketingName;
    @Column(name = "MHZ_TOTAL")
    private String mhzTotal;
    @Column(name = "SPECTRUM_BLOCKS")
    private String spectrumBlocks;
    @Column(name = "CMA_MKT_CODE", nullable = false)
    private String cmaMktCode ;
    @Column(name = "CMA_MKT_STATE", nullable = false)
    private String cmaMktState;
    @Column(name = "CMA_MKT_NAME", nullable = false)
    private String cmaMktName;
    @Column(name = "CMA_MKT_NAME_ALTERNATE")
    private String cmaMktNameAlternate;
    @Column(name = "CMA_MKT_MULTI_STATE")
    private String cmaMktMultiState;
    @Column(name = "BTA_MKT_CODE", nullable = false)
    private String btaMktCode;
    @Column(name = "BTA_MKT_STATE", nullable = false)
    private String btaMktState;
    @Column(name = "BTA_MKT_NAME", nullable = false)
    private String btaMktName;
    @Column(name = "BTA_MKT_NAME_ALTERNATE")
    private String btaMktNameAlternate;
    @Column(name = "BTA_MKT_MULTI_STATE")
    private String btaMktMultiState;
    @Column(name = "BEA_MKT_CODE", nullable = false)
    private String beaMktCode;
    @Column(name = "BEA_MKT_STATE", nullable = false)
    private String beaMktState;
    @Column(name = "BEA_MKT_NAME", nullable = false)
    private String beaMktName;
    @Column(name = "BEA_MKT_NAME_ALTERNATE")
    private String beaMktNameAlternate;
    @Column(name = "BEA_MKT_MULTI_STATE")
    private String beaMktMultiState;
    @Column(name = "PROTOCOL")
    private String protocol;
    @Column(name = "EXTENDED_SERVICES")
    private String extendedServices;
    @Column(name = "BID1")
    private String bid1;
    @Column(name = "BID1_NAME")
    private String bid1Name;
    @Column(name = "BID1_BSID1")
    private String bid1Bsid1;
    @Column(name = "BID1_BSID2")
    private String bid1Bsid2;
    @Column(name = "BID1_BSID3" )
    private String bid1Bsid3;
    @Column(name = "BID1_MNC")
    private String bid1Mnc;
    @Column(name = "BID2")
    private String bid2;
    @Column(name = "BID2_NAME")
    private String bid2Name;
    @Column(name = "BID2_BSID1")
    private String bid2Bsid1;
    @Column(name = "BID2_BSID2")
    private String bid2Bsid2;
    @Column(name = "BID2_BSID3")
    private String bid2Bsid3;
    @Column(name = "BID2_MNC")
    private String bid2Mnc;
    @Column(name = "BID3")
    private String bid3;
    @Column(name = "BID3_NAME")
    private String bid3Name;
    @Column(name = "BID3_BSID1")
    private String bid3Bsid1;
    @Column(name = "BID3_BSID2")
    private String bid3Bsid2;
    @Column(name = "BID3_BSID3")
    private String bid3Bsid3;
    @Column(name = "BID3_MNC")
    private String bid3Mnc;
    @Column(name = "BID4")
    private String bid4;
    @Column(name = "BID4_NAME")
    private String bid4Name;
    @Column(name = "BID4_BSID1")
    private String bid4Bsid1;
    @Column(name = "BID4_BSID2")
    private String bid4Bsid2;
    @Column(name = "BID4_BSID3")
    private String bid4Bsid3;
    @Column(name = "BID4_MNC")
    private String bid4Mnc;

    public CRtlArUsaMarket() {
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getKeyCode() {
        return keyCode;
    }

    public void setKeyCode(String keyCode) {
        this.keyCode = keyCode;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getCarrierEntity() {
        return carrierEntity;
    }

    public void setCarrierEntity(String carrierEntity) {
        this.carrierEntity = carrierEntity;
    }

    public String getMarketingName() {
        return marketingName;
    }

    public void setMarketingName(String marketingName) {
        this.marketingName = marketingName;
    }

    public String getMhzTotal() {
        return mhzTotal;
    }

    public void setMhzTotal(String mhzTotal) {
        this.mhzTotal = mhzTotal;
    }

    public String getSpectrumBlocks() {
        return spectrumBlocks;
    }

    public void setSpectrumBlocks(String spectrumBlocks) {
        this.spectrumBlocks = spectrumBlocks;
    }

    public String getCmaMktCode() {
        return cmaMktCode;
    }

    public void setCmaMktCode(String cmaMktCode) {
        this.cmaMktCode = cmaMktCode;
    }

    public String getCmaMktState() {
        return cmaMktState;
    }

    public void setCmaMktState(String cmaMktState) {
        this.cmaMktState = cmaMktState;
    }

    public String getCmaMktName() {
        return cmaMktName;
    }

    public void setCmaMktName(String cmaMktName) {
        this.cmaMktName = cmaMktName;
    }

    public String getCmaMktNameAlternate() {
        return cmaMktNameAlternate;
    }

    public void setCmaMktNameAlternate(String cmaMktNameAlternate) {
        this.cmaMktNameAlternate = cmaMktNameAlternate;
    }

    public String getCmaMktMultiState() {
        return cmaMktMultiState;
    }

    public void setCmaMktMultiState(String cmaMktMultiState) {
        this.cmaMktMultiState = cmaMktMultiState;
    }

    public String getBtaMktCode() {
        return btaMktCode;
    }

    public void setBtaMktCode(String btaMktCode) {
        this.btaMktCode = btaMktCode;
    }

    public String getBtaMktState() {
        return btaMktState;
    }

    public void setBtaMktState(String btaMktState) {
        this.btaMktState = btaMktState;
    }

    public String getBtaMktName() {
        return btaMktName;
    }

    public void setBtaMktName(String btaMktName) {
        this.btaMktName = btaMktName;
    }

    public String getBtaMktNameAlternate() {
        return btaMktNameAlternate;
    }

    public void setBtaMktNameAlternate(String btaMktNameAlternate) {
        this.btaMktNameAlternate = btaMktNameAlternate;
    }

    public String getBtaMktMultiState() {
        return btaMktMultiState;
    }

    public void setBtaMktMultiState(String btaMktMultiState) {
        this.btaMktMultiState = btaMktMultiState;
    }

    public String getBeaMktCode() {
        return beaMktCode;
    }

    public void setBeaMktCode(String beaMktCode) {
        this.beaMktCode = beaMktCode;
    }

    public String getBeaMktState() {
        return beaMktState;
    }

    public void setBeaMktState(String beaMktState) {
        this.beaMktState = beaMktState;
    }

    public String getBeaMktName() {
        return beaMktName;
    }

    public void setBeaMktName(String beaMktName) {
        this.beaMktName = beaMktName;
    }

    public String getBeaMktNameAlternate() {
        return beaMktNameAlternate;
    }

    public void setBeaMktNameAlternate(String beaMktNameAlternate) {
        this.beaMktNameAlternate = beaMktNameAlternate;
    }

    public String getBeaMktMultiState() {
        return beaMktMultiState;
    }

    public void setBeaMktMultiState(String beaMktMultiState) {
        this.beaMktMultiState = beaMktMultiState;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public String getExtendedServices() {
        return extendedServices;
    }

    public void setExtendedServices(String extendedServices) {
        this.extendedServices = extendedServices;
    }

    public String getBid1() {
        return bid1;
    }

    public void setBid1(String bid1) {
        this.bid1 = bid1;
    }

    public String getBid1Name() {
        return bid1Name;
    }

    public void setBid1Name(String bid1Name) {
        this.bid1Name = bid1Name;
    }

    public String getBid1Bsid1() {
        return bid1Bsid1;
    }

    public void setBid1Bsid1(String bid1Bsid1) {
        this.bid1Bsid1 = bid1Bsid1;
    }

    public String getBid1Bsid2() {
        return bid1Bsid2;
    }

    public void setBid1Bsid2(String bid1Bsid2) {
        this.bid1Bsid2 = bid1Bsid2;
    }

    public String getBid1Bsid3() {
        return bid1Bsid3;
    }

    public void setBid1Bsid3(String bid1Bsid3) {
        this.bid1Bsid3 = bid1Bsid3;
    }

    public String getBid1Mnc() {
        return bid1Mnc;
    }

    public void setBid1Mnc(String bid1Mnc) {
        this.bid1Mnc = bid1Mnc;
    }

    public String getBid2() {
        return bid2;
    }

    public void setBid2(String bid2) {
        this.bid2 = bid2;
    }

    public String getBid2Name() {
        return bid2Name;
    }

    public void setBid2Name(String bid2Name) {
        this.bid2Name = bid2Name;
    }

    public String getBid2Bsid1() {
        return bid2Bsid1;
    }

    public void setBid2Bsid1(String bid2Bsid1) {
        this.bid2Bsid1 = bid2Bsid1;
    }

    public String getBid2Bsid2() {
        return bid2Bsid2;
    }

    public void setBid2Bsid2(String bid2Bsid2) {
        this.bid2Bsid2 = bid2Bsid2;
    }

    public String getBid2Bsid3() {
        return bid2Bsid3;
    }

    public void setBid2Bsid3(String bid2Bsid3) {
        this.bid2Bsid3 = bid2Bsid3;
    }

    public String getBid2Mnc() {
        return bid2Mnc;
    }

    public void setBid2Mnc(String bid2Mnc) {
        this.bid2Mnc = bid2Mnc;
    }

    public String getBid3() {
        return bid3;
    }

    public void setBid3(String bid3) {
        this.bid3 = bid3;
    }

    public String getBid3Name() {
        return bid3Name;
    }

    public void setBid3Name(String bid3Name) {
        this.bid3Name = bid3Name;
    }

    public String getBid3Bsid1() {
        return bid3Bsid1;
    }

    public void setBid3Bsid1(String bid3Bsid1) {
        this.bid3Bsid1 = bid3Bsid1;
    }

    public String getBid3Bsid2() {
        return bid3Bsid2;
    }

    public void setBid3Bsid2(String bid3Bsid2) {
        this.bid3Bsid2 = bid3Bsid2;
    }

    public String getBid3Bsid3() {
        return bid3Bsid3;
    }

    public void setBid3Bsid3(String bid3Bsid3) {
        this.bid3Bsid3 = bid3Bsid3;
    }

    public String getBid3Mnc() {
        return bid3Mnc;
    }

    public void setBid3Mnc(String bid3Mnc) {
        this.bid3Mnc = bid3Mnc;
    }

    public String getBid4() {
        return bid4;
    }

    public void setBid4(String bid4) {
        this.bid4 = bid4;
    }

    public String getBid4Name() {
        return bid4Name;
    }

    public void setBid4Name(String bid4Name) {
        this.bid4Name = bid4Name;
    }

    public String getBid4Bsid1() {
        return bid4Bsid1;
    }

    public void setBid4Bsid1(String bid4Bsid1) {
        this.bid4Bsid1 = bid4Bsid1;
    }

    public String getBid4Bsid2() {
        return bid4Bsid2;
    }

    public void setBid4Bsid2(String bid4Bsid2) {
        this.bid4Bsid2 = bid4Bsid2;
    }

    public String getBid4Bsid3() {
        return bid4Bsid3;
    }

    public void setBid4Bsid3(String bid4Bsid3) {
        this.bid4Bsid3 = bid4Bsid3;
    }

    public String getBid4Mnc() {
        return bid4Mnc;
    }

    public void setBid4Mnc(String bid4Mnc) {
        this.bid4Mnc = bid4Mnc;
    }

    @Override
    public String toString() {
        return "CRtlArUsaMarket{" +
                "keyCode='" + keyCode + '\'' +
                ", nation='" + nation + '\'' +
                ", state='" + state + '\'' +
                ", county='" + county + '\'' +
                ", carrierEntity='" + carrierEntity + '\'' +
                ", marketingName='" + marketingName + '\'' +
                ", mhzTotal='" + mhzTotal + '\'' +
                ", spectrumBlocks='" + spectrumBlocks + '\'' +
                ", cmaMktCode='" + cmaMktCode + '\'' +
                ", cmaMktState='" + cmaMktState + '\'' +
                ", cmaMktName='" + cmaMktName + '\'' +
                ", cmaMktNameAlternate='" + cmaMktNameAlternate + '\'' +
                ", cmaMktMultiState='" + cmaMktMultiState + '\'' +
                ", btaMktCode='" + btaMktCode + '\'' +
                ", btaMktState='" + btaMktState + '\'' +
                ", btaMktName='" + btaMktName + '\'' +
                ", btaMktNameAlternate='" + btaMktNameAlternate + '\'' +
                ", btaMktMultiState='" + btaMktMultiState + '\'' +
                ", beaMktCode='" + beaMktCode + '\'' +
                ", beaMktState='" + beaMktState + '\'' +
                ", beaMktName='" + beaMktName + '\'' +
                ", beaMktNameAlternate='" + beaMktNameAlternate + '\'' +
                ", beaMktMultiState='" + beaMktMultiState + '\'' +
                ", protocol='" + protocol + '\'' +
                ", extendedServices='" + extendedServices + '\'' +
                ", bid1='" + bid1 + '\'' +
                ", bid1Name='" + bid1Name + '\'' +
                ", bid1Bsid1='" + bid1Bsid1 + '\'' +
                ", bid1Bsid2='" + bid1Bsid2 + '\'' +
                ", bid1Bsid3='" + bid1Bsid3 + '\'' +
                ", bid1Mnc='" + bid1Mnc + '\'' +
                ", bid2='" + bid2 + '\'' +
                ", bid2Name='" + bid2Name + '\'' +
                ", bid2Bsid1='" + bid2Bsid1 + '\'' +
                ", bid2Bsid2='" + bid2Bsid2 + '\'' +
                ", bid2Bsid3='" + bid2Bsid3 + '\'' +
                ", bid2Mnc='" + bid2Mnc + '\'' +
                ", bid3='" + bid3 + '\'' +
                ", bid3Name='" + bid3Name + '\'' +
                ", bid3Bsid1='" + bid3Bsid1 + '\'' +
                ", bid3Bsid2='" + bid3Bsid2 + '\'' +
                ", bid3Bsid3='" + bid3Bsid3 + '\'' +
                ", bid3Mnc='" + bid3Mnc + '\'' +
                ", bid4='" + bid4 + '\'' +
                ", bid4Name='" + bid4Name + '\'' +
                ", bid4Bsid1='" + bid4Bsid1 + '\'' +
                ", bid4Bsid2='" + bid4Bsid2 + '\'' +
                ", bid4Bsid3='" + bid4Bsid3 + '\'' +
                ", bid4Mnc='" + bid4Mnc + '\'' +
                '}';
    }
}
