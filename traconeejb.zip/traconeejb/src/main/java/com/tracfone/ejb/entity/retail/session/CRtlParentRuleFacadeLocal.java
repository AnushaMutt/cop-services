package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlParentRule;

import javax.ejb.Local;
import java.math.BigDecimal;
import java.util.List;

@Local
public interface CRtlParentRuleFacadeLocal {
    CRtlParentRule find(Object id);

    List<CRtlParentRule> findAllByParent(BigDecimal rule2Parent);

    void create(CRtlParentRule cRtlParentRule);

    void edit(CRtlParentRule cRtlParentRule);
}
