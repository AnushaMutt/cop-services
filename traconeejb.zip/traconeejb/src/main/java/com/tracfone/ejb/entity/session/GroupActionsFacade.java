/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.GroupActions;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class GroupActionsFacade extends AbstractFacade<GroupActions> implements GroupActionsFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_1.0PU")
    private EntityManager em;

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    public GroupActionsFacade() {
        super(GroupActions.class);
    }    

    @Override
    public List<Integer> findAllByGroupId(Integer id) {
        List<Integer> actionsOfGroup = (List<Integer>)em.createNamedQuery("GroupActions.findAllByGroupId").setParameter("groupId", id).getResultList();
        return actionsOfGroup;
    }

    @Override
    public List<GroupActions> findAllEntityByGroupId(Integer id) {
        List<GroupActions> actionsOfGroup = (List<GroupActions>)em.createNamedQuery("GroupActions.findAllEntityByGroupId").setParameter("groupId", id).getResultList();
        return actionsOfGroup;
    }

    @Override
    public List<Integer> findAllEntityByActionId(Integer id) {
        List<Integer> actionsOfGroup = (List<Integer>)em.createNamedQuery("GroupActions.findAllByActionId").setParameter("actionId", id).getResultList();
        return actionsOfGroup;
    }
}
