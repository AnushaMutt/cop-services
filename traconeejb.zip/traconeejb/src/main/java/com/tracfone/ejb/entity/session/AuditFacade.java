/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.Action;
import com.tracfone.ejb.entity.Audit;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author user
 */
@Stateless
public class AuditFacade extends AbstractFacade<Audit> implements AuditFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_1.0PU")
    private EntityManager em;

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    public AuditFacade() {
        super(Audit.class);
    }

    @Override
    public List<Audit> findAllAuditsByUserId(Integer userId) {
        List<Audit> audits = (List<Audit>)em.createNamedQuery("Audit.findByUserId").setParameter("userId", userId).getResultList();
        return audits;
    }

   @Override
    public void deleteAudit(int numberOfdays) {

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, numberOfdays);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String purgeDate = sdf.format(cal.getTime());
        //System.out.println("Purge Date : " + purgeDate);
        em.createNamedQuery("Audit.purgeByDays").setParameter("oldDate", purgeDate).executeUpdate();
    }
}
