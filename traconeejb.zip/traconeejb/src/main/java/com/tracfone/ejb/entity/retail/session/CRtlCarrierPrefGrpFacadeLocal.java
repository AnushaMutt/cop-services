package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlCarrierPrefGrp;

import javax.ejb.Local;
import java.util.List;

@Local
public interface CRtlCarrierPrefGrpFacadeLocal {
    CRtlCarrierPrefGrp find(Object id);

    List<CRtlCarrierPrefGrp> findAll();

    void create(CRtlCarrierPrefGrp cRtlCarrierPrefGrp);

    void edit(CRtlCarrierPrefGrp cRtlCarrierPrefGrp);
}
