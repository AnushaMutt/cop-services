package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlTech;

import javax.ejb.Local;
import java.util.List;

@Local
public interface CRtlTechFacadeLocal {
    CRtlTech find(Object id);

    List<CRtlTech> findAll();

    void create(CRtlTech cRtlTech);

    void edit(CRtlTech cRtlTech);
}
