package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlCarrierDtl;

import javax.ejb.Local;
import javax.persistence.EntityManager;
import java.util.List;

@Local
public interface CRtlCarrierDtlFacadeLocal {
    CRtlCarrierDtl find(Object id);

    List<CRtlCarrierDtl> findAll();

    void create(CRtlCarrierDtl cRtlCarrierDtl);

    void edit(CRtlCarrierDtl cRtlCarrierDtl);

    EntityManager getEntityManager();
}
