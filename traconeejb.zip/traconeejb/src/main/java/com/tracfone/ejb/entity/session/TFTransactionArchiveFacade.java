/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.TFTransactionArchive;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


/**
 *
 * @author Srinivas Murthy Pulavarthy
 */
@Stateless
public class TFTransactionArchiveFacade extends AbstractFacade<TFTransactionArchive> implements TFTransactionArchiveFacadeLocal  {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_1.0PU")
    private EntityManager em;

    @Override
    public EntityManager getEntityManager() {
        return em;
    }
    
    public TFTransactionArchiveFacade() {
        super(TFTransactionArchive.class);
    }


    @Override
    public List<TFTransactionArchive> findAllEligibleTFTransactionArchives(int numberOfdays) {
        
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, numberOfdays);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String deactivationDate = sdf.format(cal.getTime());
        List<TFTransactionArchive> tfTransactionArchives = em.createNamedQuery("TFTransactionArchive.findTransactionForDeactivationByDate").setParameter("oldDate", deactivationDate).getResultList();
        return tfTransactionArchives;
    }
    
    @Override
    public List<TFTransactionArchive> findAllTransactionByUserIdAndDbEnv(int userId, String dbEnv) {
        
        List<TFTransactionArchive> tfTransactionArchives = (List<TFTransactionArchive>)em.createNamedQuery("TFTransactionArchive.findAllTransactionByUserIdAndDbEnv").setParameter("userId", userId).setParameter("dbenv", dbEnv).getResultList();
        return tfTransactionArchives;
    }
    
    @Override
    public TFTransactionArchive findByAId(String actionItemID) {
        List<TFTransactionArchive> tfTransactionArchive = (List<TFTransactionArchive>)em.createNamedQuery("TFTransactionArchive.findByAID")
                .setParameter("aid", actionItemID)
                .setMaxResults(1)
                .getResultList();
        
        if(tfTransactionArchive.size() > 0)
            return tfTransactionArchive.get(0);
        return null;
    }
    
    @Override
    public List<TFTransactionArchive> findAllTransactionByDbEnv(String dbEnv) {
        List<TFTransactionArchive> tfTransactionArchives = (List<TFTransactionArchive>)em.createNamedQuery("TFTransactionArchive.findByDbEnv").setParameter("dbenv", dbEnv).getResultList();
        return tfTransactionArchives;
    }
    
}
