package com.tracfone.ejb.entity.retail;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "C_RTL_CARRIER_PREF_GRP")
@XmlRootElement
@NamedQueries({@NamedQuery(name = "CRtlCarrierPrefGrp.findAll", query = "SELECT c FROM CRtlCarrierPrefGrp c order by c.description")})
public class CRtlCarrierPrefGrp implements Serializable {
    private static final long serialVersionUID = 139056674118158015L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Carrier_Pref_Grp_Seq")
    @SequenceGenerator(name = "Carrier_Pref_Grp_Seq", sequenceName = "C_RTL_CARRIER_PREF_GRP_SEQ", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "OBJID", unique = true, nullable = false, precision = 22, scale = 0)
    private BigDecimal objid;
    @Column(name = "CPREFGRP2USER", nullable = false)
    private BigDecimal secUserId;
    @Column(name = "CPREFGRP2BRAND")
    private BigDecimal cPrefGrp2Brand;
    @Column(name = "DESCRIPTION", length = 225)
    private String description;
    @Column(name = "STATUS", nullable = false, length = 10)
    private String status;
    @Temporal(TemporalType.DATE)
    @Column(name = "INSERT_DATE", nullable = false, length = 7)
    private Date insertDate;
    @Temporal(TemporalType.DATE)
    @Column(name = "UPDATE_DATE", length = 7)
    private Date updateDate;

    public CRtlCarrierPrefGrp() {
    }

    public BigDecimal getObjid() {
        return objid;
    }

    public void setObjid(BigDecimal objid) {
        this.objid = objid;
    }

    public BigDecimal getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(BigDecimal secUserId) {
        this.secUserId = secUserId;
    }

    public BigDecimal getcPrefGrp2Brand() {
        return cPrefGrp2Brand;
    }

    public void setcPrefGrp2Brand(BigDecimal cPrefGrp2Brand) {
        this.cPrefGrp2Brand = cPrefGrp2Brand;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}
