/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.Audit;
import java.sql.Date;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author user
 */
@Local
public interface AuditFacadeLocal {

    void create(Audit audit);
    List<Audit> findAllAuditsByUserId(Integer userId);
    void deleteAudit(int numberOfdays);

}
