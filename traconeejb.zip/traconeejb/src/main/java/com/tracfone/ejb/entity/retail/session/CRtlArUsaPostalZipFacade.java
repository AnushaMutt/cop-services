package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlArUsaPostalZips;
import com.tracfone.ejb.entity.session.AbstractFacade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class CRtlArUsaPostalZipFacade extends AbstractFacade<CRtlArUsaPostalZips> implements CRtlArUsaPostalZipsFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_2.0PU")
    private EntityManager em;

    public CRtlArUsaPostalZipFacade() {
        super(CRtlArUsaPostalZips.class);
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }
    
}

