package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.UserHistory;
import com.tracfone.ejb.entity.UserTask;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class UserHistoryFacade extends AbstractFacade<UserHistory> implements UserHistoryFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_1.0PU")
    private EntityManager em;

    public UserHistoryFacade() {
        super(UserHistory.class);
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    @Override
    public void deleteUserHistory(int numberOfdays) {

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, numberOfdays);
        //java.sql.Date purgeDate = new java.sql.Date(cal.getTimeInMillis());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String purgeDate = sdf.format(cal.getTime());
        //System.out.println("Purge Date : " + purgeDate);
        em.createNamedQuery("UserHistory.purgeByDays").setParameter("oldDate", purgeDate).executeUpdate();
    }
}
