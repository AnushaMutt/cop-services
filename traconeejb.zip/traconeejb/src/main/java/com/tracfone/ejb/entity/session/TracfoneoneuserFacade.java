/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.Tracfoneoneuser;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author user
 */
@Stateless
public class TracfoneoneuserFacade extends AbstractFacade<Tracfoneoneuser> implements TracfoneoneuserFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_1.0PU")
    private EntityManager em;

    @Override
     public EntityManager getEntityManager() {
        return em;
    }

    public TracfoneoneuserFacade() {
        super(Tracfoneoneuser.class);
    }
    
    @Override
    public void create(Tracfoneoneuser entity) {
      getEntityManager().persist(entity);
      getEntityManager().flush();
      getEntityManager().refresh(entity);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Tracfoneoneuser findTracfoneUserByName(String userName) {
        Tracfoneoneuser tracfoneUser = (Tracfoneoneuser)em.createNamedQuery("Tracfoneoneuser.findByUsername").setParameter("username", userName).getSingleResult();
        return tracfoneUser;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Tracfoneoneuser validateToken(String token) {
       Tracfoneoneuser tracfoneUser = (Tracfoneoneuser)em.createNamedQuery("Tracfoneoneuser.findByToken").setParameter("token", token).getSingleResult();
        return tracfoneUser;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<Tracfoneoneuser> findByListOfId(List<Integer> userIdList) {
        List<Tracfoneoneuser> tracfoneUser = (List<Tracfoneoneuser>) em.createNamedQuery("Tracfoneoneuser.findByListOfId").setParameter("listIDs", userIdList).getResultList();
        return tracfoneUser;
    }

    @Override
    public Tracfoneoneuser findTracfoneUserByDescription(String description) {
        Tracfoneoneuser tracfoneUser = (Tracfoneoneuser)em.createNamedQuery("Tracfoneoneuser.findByDescription").setParameter("desc", description).getSingleResult();
        return tracfoneUser;
    }
}