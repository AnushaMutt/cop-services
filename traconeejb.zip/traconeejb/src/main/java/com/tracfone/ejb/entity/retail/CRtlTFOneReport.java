package com.tracfone.ejb.entity.retail;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author Gaurav.Sharma
 */
@Entity
@Table(name = "cop.cop_tfone_reports")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CRtlTFOneReport.findById", query = "SELECT r FROM CRtlTFOneReport r WHERE r.id = :id"),
    @NamedQuery(name = "CRtlTFOneReport.findByDateRange", query = "SELECT r FROM CRtlTFOneReport r WHERE r.createddate >= :fromDate and r.createddate < :toDate AND r.reportName = :reportName"),
    @NamedQuery(name = "CRtlTFOneReport.findLastRowInserted", query = "SELECT r FROM CRtlTFOneReport r WHERE r.reportName = :reportName order by r.id desc"),
    @NamedQuery(name = "CRtlTFOneReport.purgeByDays", query = "DELETE FROM CRtlTFOneReport r WHERE FUNC('TRUNC', CAST(r.createddate as Date)) <= FUNCTION('TO_DATE' :oldDate, 'yyyy/mm/dd')")})

public class CRtlTFOneReport implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "TFOneReport_Seq")
    @SequenceGenerator(name = "TFOneReport_Seq", sequenceName = "cop.cop_tfone_reports_seq", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "createddate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createddate;
    @Column(name = "jsonResponse")
    private String jsonResponse;
    @Column(name = "reportName")
    private String reportName;

    public CRtlTFOneReport() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getCreateddate() {
        return createddate;
    }

    public void setCreateddate(Date createddate) {
        this.createddate = createddate;
    }

    public String getJsonResponse() {
        return jsonResponse;
    }

    public void setJsonResponse(String jsonResponse) {
        this.jsonResponse = jsonResponse;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CRtlTFOneReport)) {
            return false;
        }
        CRtlTFOneReport other = (CRtlTFOneReport) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.tracfone.ejb.entity.ReportIgError[ id=" + id + " ]";
    }
}
