package com.tracfone.ejb.entity.retail;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@Entity
@Table(name="cop.AR_USA_POSTAL_ZIPS",uniqueConstraints = @UniqueConstraint(columnNames = "POSTAL_CODE"))
@XmlRootElement

public class CRtlArUsaPostalZips implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "ArUsaPostalZips_Seq")
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "POSTAL_CODE",unique = true, nullable = false)
    private String postalCode;
    @Column(name = "KEY_CODE", nullable = false)
    private String keyCode;
    @Column(name = "STATE", nullable = false)
    private String state;
    @Column(name = "CITY", nullable = false)
    private String city;

    public CRtlArUsaPostalZips() {
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getKeyCode() {
        return keyCode;
    }

    public void setKeyCode(String keyCode) {
        this.keyCode = keyCode;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public String toString() {
        return "CRtlArUsaPostalZips{" +
                "id=" + id +
                ", postalCode='" + postalCode + '\'' +
                ", keyCode='" + keyCode + '\'' +
                ", state='" + state + '\'' +
                ", city='" + city + '\'' +
                '}';
    }
}
