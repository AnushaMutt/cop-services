/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author user
 */
@Entity
@Table(name = "cop.cop_usergroups")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Usergroups.findAll", query = "SELECT u FROM Usergroups u")
    , @NamedQuery(name = "Usergroups.findById", query = "SELECT u FROM Usergroups u WHERE u.id = :id")
    , @NamedQuery(name = "Usergroups.findByGroupid", query = "SELECT u FROM Usergroups u WHERE u.groupid = :groupid")
    , @NamedQuery(name = "Usergroups.findByUserid", query = "SELECT u.groupid FROM Usergroups u WHERE u.userid = :userid")
    , @NamedQuery(name = "Usergroups.findEntityByUserid", query = "SELECT u FROM Usergroups u WHERE u.userid = :userid")
    , @NamedQuery(name = "Usergroups.findByCreateddate", query = "SELECT u FROM Usergroups u WHERE u.createddate = :createddate")
    , @NamedQuery(name = "Usergroups.findByCreatedby", query = "SELECT u FROM Usergroups u WHERE u.createdby = :createdby")
    , @NamedQuery(name = "Usergroups.findByModifieddate", query = "SELECT u FROM Usergroups u WHERE u.modifieddate = :modifieddate")
    , @NamedQuery(name = "Usergroups.findByModifiedby", query = "SELECT u FROM Usergroups u WHERE u.modifiedby = :modifiedby")
    , @NamedQuery(name = "Usergroups.findEntitiesByListOfGroupIDs", query = "SELECT u.userid FROM Usergroups u WHERE u.groupid IN :groupIDs")})
public class Usergroups implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Usergroups_Seq")
    @SequenceGenerator(name="Usergroups_Seq", sequenceName="cop.cop_usergroups_seq", allocationSize=1)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "groupid")
    private Integer groupid;
    @Column(name = "userid")
    private Integer userid;
    @Column(name = "createddate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createddate;
    @Size(max = 45)
    @Column(name = "createdby")
    private String createdby;
    @Column(name = "modifieddate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifieddate;
    @Size(max = 45)
    @Column(name = "modifiedby")
    private String modifiedby;

    public Usergroups() {
    }

    public Usergroups(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getGroupid() {
        return groupid;
    }

    public void setGroupid(Integer groupid) {
        this.groupid = groupid;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public Date getCreateddate() {
        return createddate;
    }

    public void setCreateddate(Date createddate) {
        this.createddate = createddate;
    }

    public String getCreatedby() {
        return createdby;
    }

    public void setCreatedby(String createdby) {
        this.createdby = createdby;
    }

    public Date getModifieddate() {
        return modifieddate;
    }

    public void setModifieddate(Date modifieddate) {
        this.modifieddate = modifieddate;
    }

    public String getModifiedby() {
        return modifiedby;
    }

    public void setModifiedby(String modifiedby) {
        this.modifiedby = modifiedby;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Usergroups)) {
            return false;
        }
        Usergroups other = (Usergroups) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.tracfone.ejb.entity.Usergroups[ id=" + id + " ]";
    }
    
}
