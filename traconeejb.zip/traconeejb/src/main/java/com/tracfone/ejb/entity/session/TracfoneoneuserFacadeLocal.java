/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.Tracfoneoneuser;
import java.util.List;
import javax.ejb.Local;
import javax.persistence.EntityManager;

/**
 *
 * @author user
 */
@Local
public interface TracfoneoneuserFacadeLocal {

    void create(Tracfoneoneuser tracfoneoneuser);

    void edit(Tracfoneoneuser tracfoneoneuser);

    void remove(Tracfoneoneuser tracfoneoneuser);

    Tracfoneoneuser find(Object id);

    List<Tracfoneoneuser> findAll();

    List<Tracfoneoneuser> findRange(int[] range);
    
    Tracfoneoneuser findTracfoneUserByName(String userName);
    
    Tracfoneoneuser validateToken(String token);
    
    List<Tracfoneoneuser> findByListOfId(List<Integer> userIdList);
    
    int count();

    Tracfoneoneuser findTracfoneUserByDescription(String description);
}
