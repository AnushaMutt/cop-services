package com.tracfone.ejb.entity.retail;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "C_RTL_CARRIER_PREF", uniqueConstraints = @UniqueConstraint(columnNames = {
        "CPREF2CARRIER_PREF_GRP", "CPREF2CARRIER_DTL", "RANK" }))
@XmlRootElement
@NamedQueries({@NamedQuery(name = "CRtlCarrierPref.findByCarrierPrefGroup",
        query = "SELECT c FROM CRtlCarrierPref c WHERE c.cPref2CarrierPrefGrp = :cPref2CarrierPrefGrp order by c.rank")})
public class CRtlCarrierPref implements Serializable {
    private static final long serialVersionUID = 139056674118158015L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Carrier_Pref_Seq")
    @SequenceGenerator(name = "Carrier_Pref_Seq", sequenceName = "C_RTL_CARRIER_PREF_SEQ", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "OBJID", unique = true, nullable = false, precision = 22, scale = 0)
    private BigDecimal objid;
    @Column(name = "CPREF2CARRIER_PREF_GRP", nullable = false)
    private BigDecimal cPref2CarrierPrefGrp;
    @Column(name = "CPREF2CARRIER_DTL", nullable = false)
    private BigDecimal cPref2CarrierDtl;
    @Column(name = "RANK", nullable = false)
    private BigDecimal rank;

    public CRtlCarrierPref() {
    }

    public BigDecimal getObjid() {
        return objid;
    }

    public void setObjid(BigDecimal objid) {
        this.objid = objid;
    }

    public BigDecimal getcPref2CarrierPrefGrp() {
        return cPref2CarrierPrefGrp;
    }

    public void setcPref2CarrierPrefGrp(BigDecimal cPref2CarrierPrefGrp) {
        this.cPref2CarrierPrefGrp = cPref2CarrierPrefGrp;
    }

    public BigDecimal getcPref2CarrierDtl() {
        return cPref2CarrierDtl;
    }

    public void setcPref2CarrierDtl(BigDecimal cPref2CarrierDtl) {
        this.cPref2CarrierDtl = cPref2CarrierDtl;
    }

    public BigDecimal getRank() {
        return rank;
    }

    public void setRank(BigDecimal rank) {
        this.rank = rank;
    }
}
