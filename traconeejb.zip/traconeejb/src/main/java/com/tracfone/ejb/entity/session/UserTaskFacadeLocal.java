package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.UserTask;

import javax.ejb.Local;
import javax.persistence.EntityManager;
import java.util.List;

@Local
public interface UserTaskFacadeLocal {

    EntityManager getEntityManager();

    void create(UserTask userTask);

    void edit(UserTask userTask);

    UserTask find(Object id);

    List<UserTask> findAllUserTask(Integer assignedUserId, List<String> status, String fromCreationDate, String toCreationDate, String type);

    void deleteUserTask(int numberOfdays);

}
