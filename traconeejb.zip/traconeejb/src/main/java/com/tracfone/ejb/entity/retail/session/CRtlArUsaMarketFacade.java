package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlArUsaMarket;
import com.tracfone.ejb.entity.session.AbstractFacade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class CRtlArUsaMarketFacade extends AbstractFacade<CRtlArUsaMarket> implements CRtlArUsaMarketFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_2.0PU")
    private EntityManager em;

    public CRtlArUsaMarketFacade() {
        super(CRtlArUsaMarket.class);
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }


    @Override
    public CRtlArUsaMarket findRecord(String keyCode, String carrierEntity) {
        return  (CRtlArUsaMarket) em.createNamedQuery("CRtlArUsaMarket.findRecords")
                .setParameter("keyCode", keyCode)
                .setParameter("carrierEntity", carrierEntity)
                .getResultList();

    }
}

