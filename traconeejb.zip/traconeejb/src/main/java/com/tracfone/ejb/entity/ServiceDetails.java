/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author user
 */
@Entity
@Table(name = "cop.cop_servicedetails")
@XmlRootElement
public class ServiceDetails implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "ServiceDetails_Seq")
    @SequenceGenerator(name="ServiceDetails_Seq",sequenceName="cop.cop_servicedetails_seq", allocationSize=1)
    @Basic(optional = false)
    @Column(name = "sid")
    private Integer sid;
    @Column(name = "serviceuri")
    private String serviceuri;
    @Column(name = "method")
    private String method;

    public Integer getSid() {
        return sid;
    }

    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public String getServiceuri() {
        return serviceuri;
    }

    public void setServiceuri(String serviceuri) {
        this.serviceuri = serviceuri;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (sid != null ? sid.hashCode() : 0);
        return hash;
    }

    @Override
    public String toString() {
        return "ServiceDetails{" + "sid=" + sid + ", serviceuri=" + serviceuri + ", method=" + method + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ServiceDetails other = (ServiceDetails) obj;
        return true;
    }
    
    
    
}
