package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.Tracfoneoneuser;
import com.tracfone.ejb.entity.retail.CRtlCarrier;
import com.tracfone.ejb.entity.session.AbstractFacade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class CRtlCarrierFacade extends AbstractFacade<CRtlCarrier> implements CRtlCarrierFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_2.0PU")
    private EntityManager em;

    public CRtlCarrierFacade() {
        super(CRtlCarrier.class);
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    @Override
    public void edit(CRtlCarrier entity) {
        getEntityManager().persist(entity);
        getEntityManager().flush();
        getEntityManager().refresh(entity);
    }

}
