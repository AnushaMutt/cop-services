/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.Usergroups;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author user
 */
@Stateless
public class UsergroupsFacade extends AbstractFacade<Usergroups> implements UsergroupsFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_1.0PU")
    private EntityManager em;

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    public UsergroupsFacade() {
        super(Usergroups.class);
    }

    @Override
    public List<Integer> findByUserid(Integer userId) {
        List<Integer> groupIdsByUser = (List<Integer>)em.createNamedQuery("Usergroups.findByUserid").setParameter("userid", userId).getResultList();
        return groupIdsByUser;
    } 
    
    @Override
    public List<Usergroups> findEntityByUserid(Integer userId) {
        List<Usergroups> userGroupEntities = (List<Usergroups>)em.createNamedQuery("Usergroups.findEntityByUserid").setParameter("userid", userId).getResultList();
        return userGroupEntities;
    } 
    
    @Override
    public List<Integer> findEntitiesByListOfGroupIDs(List<Integer> groupIDs) {
        List<Integer> userIDs = (List<Integer>)em.createNamedQuery("Usergroups.findEntitiesByListOfGroupIDs").setParameter("groupIDs", groupIDs).getResultList();
        return userIDs;
    } 
}
