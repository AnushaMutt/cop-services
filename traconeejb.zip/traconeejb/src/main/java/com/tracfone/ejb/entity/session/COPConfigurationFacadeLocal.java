/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.COPConfiguration;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author user
 */
@Local
public interface COPConfigurationFacadeLocal {

    void create(COPConfiguration copConfiguration);

    void edit(COPConfiguration copConfiguration);

    void remove(COPConfiguration copConfiguration);

    COPConfiguration find(Object id);

    List<COPConfiguration> findAll();

    int count();
    
}
