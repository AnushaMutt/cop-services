/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Srinivas Murthy Pulavarthy
 */
@Entity
@Table(name = "cop.cop_transactions_archive")
@XmlRootElement
@NamedQueries({ @NamedQuery(name = "TFTransactionArchive.findAll",  query = "SELECT a FROM TFTransactionArchive a")
               ,@NamedQuery(name = "TFTransactionArchive.findById", query = "SELECT a FROM TFTransactionArchive a WHERE a.id = :id")
               ,@NamedQuery(name = "TFTransactionArchive.findByAID", query = "SELECT a FROM TFTransactionArchive a WHERE a.actionItemId = :aid")
               ,@NamedQuery(name = "TFTransactionArchive.findTransactionForDeactivationByDate", query = "SELECT a FROM TFTransactionArchive a WHERE FUNC('TRUNC', CAST(a.createddate as Date)) <= FUNCTION('TO_DATE' :oldDate, 'yyyy/mm/dd')")
               ,@NamedQuery(name = "TFTransactionArchive.findAllTransactionByUserIdAndDbEnv", query = "SELECT a FROM TFTransactionArchive a WHERE a.userId = :userId and a.dbEnv = :dbenv" )
               ,@NamedQuery(name = "TFTransactionArchive.findByDbEnv", query = "SELECT a FROM TFTransactionArchive a WHERE a.dbEnv = :dbenv")})
public class TFTransactionArchive implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Action_Seq")
    //@SequenceGenerator(name="Action_Seq",sequenceName="cop.cop_action_seq", allocationSize=1)
    @Basic(optional = false)
    @Column(name = "id")
    private Long id;
     
    @Column(name = "user_id")
    private Long userId;
    
    @Column(name = "transactionid")
    private String transactionId;
    
    @Column(name = "actionitemid")
    private String actionItemId;
    
    @Column(name = "dbenv")
    private String dbEnv;
    
    @Column(name = "status")
    private String status;
    
    @Column(name = "createddate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createddate;
    
    @Column(name = "modifieddate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifieddate;
    
    @Column(name = "deactivationdate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deactivationDate;

    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreateddate() {
        return createddate;
    }

    public void setCreateddate(Date createddate) {
        this.createddate = createddate;
    }

    public Date getModifieddate() {
        return modifieddate;
    }

    public void setModifieddate(Date modifieddate) {
        this.modifieddate = modifieddate;
    }
    
    public Date getDeactivationDate() {
        return deactivationDate;
    }

    public void setDeactivationDate(Date deactivationDate) {
        this.deactivationDate = deactivationDate;
    }

    public String getActionItemId() {
        return actionItemId;
    }

    public void setActionItemId(String actionItemId) {
        this.actionItemId = actionItemId;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TFTransactionArchive)) {
            return false;
        }
        TFTransactionArchive other = (TFTransactionArchive) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.tracfone.ejb.entity.TFTransactionArchive[ id=" + id + " ]";
    }
}
