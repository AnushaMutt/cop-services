package com.tracfone.ejb.entity.retail;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * CRtlCarrier entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "C_RTL_CARRIER", uniqueConstraints = @UniqueConstraint(columnNames = "CARRIER"))
@XmlRootElement
@NamedQueries({@NamedQuery(name = "CRtlCarrier.findAll", query = "SELECT c FROM CRtlCarrier c order by c.carrier")})
public class CRtlCarrier implements Serializable {
    private static final long serialVersionUID = 6731033584733873173L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Carrier_Seq")
    @SequenceGenerator(name = "Carrier_Seq", sequenceName = "C_RTL_CARRIER_SEQ", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "OBJID", unique = true, nullable = false, precision = 22, scale = 0)
    private BigDecimal objid;
    @Column(name = "CARRIER2USER", nullable = false)
    private String secUserId;
    @Column(name = "STATUS", nullable = false, length = 10)
    private String status;
    @Column(name = "CARRIER", unique = true, nullable = false, length = 50)
    private String carrier;
    @Column(name = "CARRIER_LONG")
    private String carrierLong;
    @Temporal(TemporalType.DATE)
    @Column(name = "INSERT_DATE", nullable = false, length = 7)
    private Date insertDate;
    @Temporal(TemporalType.DATE)
    @Column(name = "UPDATE_DATE", length = 7)
    private Date updateDate;

    public CRtlCarrier() {
    }

    public BigDecimal getObjid() {
        return objid;
    }

    public void setObjid(BigDecimal objid) {
        this.objid = objid;
    }

    public String getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(String secUserId) {
        this.secUserId = secUserId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getCarrierLong() {
        return carrierLong;
    }

    public void setCarrierLong(String carrierLong) {
        this.carrierLong = carrierLong;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}