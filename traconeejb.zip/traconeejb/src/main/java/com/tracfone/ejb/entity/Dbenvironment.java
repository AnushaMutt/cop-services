/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author user
 */
@Entity
@Table(name = "cop.cop_dbenvironment")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Dbenvironment.findAll", query = "SELECT d FROM Dbenvironment d")
    , @NamedQuery(name = "Dbenvironment.findById", query = "SELECT d FROM Dbenvironment d WHERE d.id = :id")
    , @NamedQuery(name = "Dbenvironment.findByName", query = "SELECT d FROM Dbenvironment d WHERE d.name = :name")
    , @NamedQuery(name = "Dbenvironment.findByDescription", query = "SELECT d FROM Dbenvironment d WHERE d.description = :description")
    , @NamedQuery(name = "Dbenvironment.findByCreationdate", query = "SELECT d FROM Dbenvironment d WHERE d.creationdate = :creationdate")
    , @NamedQuery(name = "Dbenvironment.findByModifieddate", query = "SELECT d FROM Dbenvironment d WHERE d.modifieddate = :modifieddate")
    , @NamedQuery(name = "Dbenvironment.findByCreatedby", query = "SELECT d FROM Dbenvironment d WHERE d.createdby = :createdby")})
public class Dbenvironment implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Dbenvironment_Seq")
    @SequenceGenerator(name="Dbenvironment_Seq",sequenceName="cop.cop_dbenvironment_seq", allocationSize=1)
    @Basic(optional = false)
    @NotNull
    @Column(name = "id")
    private Integer id;
    @Size(max = 45)
    @Column(name = "name")
    private String name;
    @Size(max = 45)
    @Column(name = "description")
    private String description;
    @Column(name = "creationdate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationdate;
    @Column(name = "modifieddate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifieddate;
    @Size(max = 45)
    @Column(name = "createdby")
    private String createdby;
//    @OneToMany(mappedBy = "dbenvid")
//    private Collection<UserDbenv> userDbenvCollection;

    public Dbenvironment() {
    }

    public Dbenvironment(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreationdate() {
        return creationdate;
    }

    public void setCreationdate(Date creationdate) {
        this.creationdate = creationdate;
    }

    public Date getModifieddate() {
        return modifieddate;
    }

    public void setModifieddate(Date modifieddate) {
        this.modifieddate = modifieddate;
    }

    public String getCreatedby() {
        return createdby;
    }

    public void setCreatedby(String createdby) {
        this.createdby = createdby;
    }

//    @XmlTransient
//    public Collection<UserDbenv> getUserDbenvCollection() {
//        return userDbenvCollection;
//    }
//
//    public void setUserDbenvCollection(Collection<UserDbenv> userDbenvCollection) {
//        this.userDbenvCollection = userDbenvCollection;
//    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Dbenvironment)) {
            return false;
        }
        Dbenvironment other = (Dbenvironment) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.tracfone.ejb.entity.Dbenvironment[ id=" + id + " ]";
    }
    
}
