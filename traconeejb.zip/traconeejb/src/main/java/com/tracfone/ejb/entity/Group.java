/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author user
 */

/**
 *
 * @author user
 */
@Entity
@Table(name = "cop.cop_group")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Group.findAll", query = "SELECT g FROM Group g")
    , @NamedQuery(name = "Group.findById", query = "SELECT g FROM Group g WHERE g.id = :id")
    , @NamedQuery(name = "Group.findByCreateddate", query = "SELECT g FROM Group g WHERE g.createddate = :createddate")
    , @NamedQuery(name = "Group.findByModifieddate", query = "SELECT g FROM Group g WHERE g.modifieddate = :modifieddate")
    , @NamedQuery(name = "Group.findByCreatedby", query = "SELECT g FROM Group g WHERE g.createdby = :createdby")
    , @NamedQuery(name = "Group.findByGroupname", query = "SELECT g FROM Group g WHERE g.groupname = :groupname")
    , @NamedQuery(name = "Group.findByLastupdatedby", query = "SELECT g FROM Group g WHERE g.lastupdatedby = :lastupdatedby")
    , @NamedQuery(name = "Group.findByEnabled", query = "SELECT g FROM Group g WHERE g.enabled = :enabled")
    , @NamedQuery(name = "Group.findAllById", query = "SELECT g FROM Group g WHERE g.id in :groupIds")})
public class Group implements Serializable {

   private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Group_Seq")
    @SequenceGenerator(name="Group_Seq",sequenceName="cop.cop_group_seq", allocationSize=1)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "createddate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createddate;
    @Column(name = "modifieddate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifieddate;
    @Column(name = "createdby")
    private Integer createdby;
    @Size(max = 45)
    @Column(name = "groupname",nullable = false)
    private String groupname;
    @Size(max = 45)
    @Column(name = "lastupdatedby")
    private String lastupdatedby;
    @Column(name = "enabled")
    private Short enabled;
    @Column(name = "description")
    private String description;
    
    public Group() {
    }

    public Group(Integer id) {
        this.id = id;
    }
    
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getCreateddate() {
        return createddate;
    }

    public void setCreateddate(Date createddate) {
        this.createddate = createddate;
    }

    public Date getModifieddate() {
        return modifieddate;
    }

    public void setModifieddate(Date modifieddate) {
        this.modifieddate = modifieddate;
    }

    public Integer getCreatedby() {
        return createdby;
    }

    public void setCreatedby(Integer createdby) {
        this.createdby = createdby;
    }

    public String getGroupname() {
        return groupname;
    }

    public void setGroupname(String groupname) {
        this.groupname = groupname;
    }

    public String getLastupdatedby() {
        return lastupdatedby;
    }

    public void setLastupdatedby(String lastupdatedby) {
        this.lastupdatedby = lastupdatedby;
    }

    public Short getEnabled() {
        return enabled;
    }

    public void setEnabled(Short enabled) {
        this.enabled = enabled;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Group)) {
            return false;
        }
        Group other = (Group) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.tracfone.ejb.entity.Group[ id=" + id + " ]";
    }
    
}
