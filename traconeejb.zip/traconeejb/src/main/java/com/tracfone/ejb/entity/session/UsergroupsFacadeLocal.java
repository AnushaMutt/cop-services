/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.Usergroups;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author user
 */
@Local
public interface UsergroupsFacadeLocal {

    void create(Usergroups usergroups);

    void edit(Usergroups usergroups);

    void remove(Usergroups usergroups);

    Usergroups find(Object id);

    List<Usergroups> findAll();

    List<Usergroups> findRange(int[] range);
    
    List<Integer> findByUserid(Integer userId);
    
    List<Usergroups> findEntityByUserid(Integer userId);
    
    List<Integer> findEntitiesByListOfGroupIDs(List<Integer> groupIDs);

    int count();
    
}
