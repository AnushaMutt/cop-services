/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author spulavarthy
 */
@Entity
@Table(name = "COP.COP_ID_USER_HISTORY")
@NamedQueries({@NamedQuery(name = "UserHistory.purgeByDays", query = "DELETE FROM UserHistory u WHERE FUNC('TRUNC', CAST(u.creationDate as Date)) <= FUNCTION('TO_DATE' :oldDate, 'yyyy/mm/dd')")})
public class UserHistory implements Serializable {

    private static final long serialVersionUID = 11L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "User_History_Seq")
    @SequenceGenerator(name = "User_History_Seq", sequenceName = "COP.SEQ_COP_ID_USER_HISTORY", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "ID")
    private Long id;
    @Column(name = "USER_ID")
    private Integer userId;
    @Column(name = "TYPE")
    private String type;
    @Column(name = "CREATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;
    @Column(name = "UPDATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "userHistory", cascade = CascadeType.REMOVE, orphanRemoval = true)
    private List<UserHistoryDetail> userHistoryDetails;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public List<UserHistoryDetail> getUserHistoryDetails() {
        return userHistoryDetails;
    }

    public void setUserHistoryDetails(List<UserHistoryDetail> userHistoryDetails) {
        this.userHistoryDetails = userHistoryDetails;
    }
}