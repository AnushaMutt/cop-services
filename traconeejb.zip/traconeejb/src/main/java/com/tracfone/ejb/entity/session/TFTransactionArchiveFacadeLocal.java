/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.session;

import com.tracfone.ejb.entity.TFTransactionArchive;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Srinivas Murthy Pulavarthy
 */
@Local
public interface TFTransactionArchiveFacadeLocal {

    void create(TFTransactionArchive tfTransactionArchive);

    void edit(TFTransactionArchive tfTransactionArchive);

    void remove(TFTransactionArchive tfTransactionArchive);

    TFTransactionArchive find(Object id);

    List<TFTransactionArchive> findAll();

    List<TFTransactionArchive> findRange(int[] range);
    
    List<TFTransactionArchive> findAllEligibleTFTransactionArchives(int days);
    
    List<TFTransactionArchive> findAllTransactionByUserIdAndDbEnv(int userId, String dbEnv);
    
    TFTransactionArchive findByAId(String tid);
    
    List<TFTransactionArchive> findAllTransactionByDbEnv(String dbEnv);

    int count();
    
}
