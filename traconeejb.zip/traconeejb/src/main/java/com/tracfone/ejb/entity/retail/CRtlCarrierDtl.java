package com.tracfone.ejb.entity.retail;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * CRtlCarrierDtl entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "C_RTL_CARRIER_DTL", uniqueConstraints = @UniqueConstraint(columnNames = {
        "CDTL2CARRIER", "CDTL2BRAND", "CDTL2TECH"}))
@XmlRootElement
@NamedQueries({@NamedQuery(name = "CRtlCarrierDtl.findAll", query = "SELECT c FROM CRtlCarrierDtl c")})
public class CRtlCarrierDtl implements Serializable {
    private static final long serialVersionUID = 139056674118158015L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Carrier_Detail_Seq")
    @SequenceGenerator(name = "Carrier_Detail_Seq", sequenceName = "C_RTL_CARRIER_DTL_SEQ", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "OBJID", unique = true, nullable = false, precision = 22, scale = 0)
    private BigDecimal objid;
    @Column(name = "CDTL2USER", nullable = false)
    private String secUserId;
    @Column(name = "CDTL2TECH", nullable = false)
    private String cRtlTechId;
    @Column(name = "CDTL2CARRIER", nullable = false)
    private String cRtlCarrierId;
    @Column(name = "CDTL2BRAND", nullable = false)
    private String cRtlBrandId;
    @Column(name = "STATUS", nullable = false, length = 10)
    private String status;
    @Temporal(TemporalType.DATE)
    @Column(name = "INSERT_DATE", nullable = false, length = 7)
    private Date insertDate;
    @Temporal(TemporalType.DATE)
    @Column(name = "UPDATE_DATE", length = 7)
    private Date updateDate;

    public CRtlCarrierDtl() {
    }

    public BigDecimal getObjid() {
        return this.objid;
    }

    public void setObjid(BigDecimal objid) {
        this.objid = objid;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getInsertDate() {
        return this.insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(String secUserId) {
        this.secUserId = secUserId;
    }

    public String getcRtlTechId() {
        return cRtlTechId;
    }

    public void setcRtlTechId(String cRtlTechId) {
        this.cRtlTechId = cRtlTechId;
    }

    public String getcRtlCarrierId() {
        return cRtlCarrierId;
    }

    public void setcRtlCarrierId(String cRtlCarrierId) {
        this.cRtlCarrierId = cRtlCarrierId;
    }

    public String getcRtlBrandId() {
        return cRtlBrandId;
    }

    public void setcRtlBrandId(String cRtlBrandId) {
        this.cRtlBrandId = cRtlBrandId;
    }
}