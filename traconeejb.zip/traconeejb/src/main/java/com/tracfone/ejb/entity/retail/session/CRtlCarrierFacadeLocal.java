package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlCarrier;

import javax.ejb.Local;
import java.util.List;

@Local
public interface CRtlCarrierFacadeLocal {
    CRtlCarrier find(Object id);

    List<CRtlCarrier> findAll();

    void create(CRtlCarrier cRtlCarrier);

    void edit(CRtlCarrier cRtlCarrier);
}
