package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlBrand;
import com.tracfone.ejb.entity.retail.CRtlCarrierDtl;
import com.tracfone.ejb.entity.session.AbstractFacade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class CRtlBrandFacade extends AbstractFacade<CRtlBrand> implements CRtlBrandFacadeLocal {

    @PersistenceContext(unitName = "com.tracfone_traconeejb_ejb_2.0PU")
    private EntityManager em;

    public CRtlBrandFacade() {
        super(CRtlBrand.class);
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    @Override
    public void edit(CRtlBrand entity) {
        getEntityManager().persist(entity);
        getEntityManager().flush();
        getEntityManager().refresh(entity);
    }

}
