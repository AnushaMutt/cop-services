package com.tracfone.ejb.entity.retail;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "C_RTL_TECH", uniqueConstraints = @UniqueConstraint(columnNames = "TECH"))
@XmlRootElement
@NamedQueries({@NamedQuery(name = "CRtlTech.findAll", query = "SELECT c FROM CRtlTech c order by c.tech")})
public class CRtlTech implements Serializable {
    private static final long serialVersionUID = -2519166323117755246L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Tech_Seq")
    @SequenceGenerator(name = "Tech_Seq", sequenceName = "C_RTL_TECH_SEQ", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "OBJID", unique = true, nullable = false, precision = 22, scale = 0)
    private BigDecimal objid;
    @Column(name = "TECH2USER", nullable = false)
    private String secUserId;
    @Column(name = "STATUS", nullable = false, length = 10)
    private String status;
    @Column(name = "TECH", unique = true, nullable = false, length = 50)
    private String tech;
    @Column(name = "TECH_LONG")
    private String techLong;
    @Temporal(TemporalType.DATE)
    @Column(name = "INSERT_DATE", nullable = false, length = 7)
    private Date insertDate;
    @Temporal(TemporalType.DATE)
    @Column(name = "UPDATE_DATE", length = 7)
    private Date updateDate;

    public CRtlTech() {
    }

    public BigDecimal getObjid() {
        return this.objid;
    }

    public void setObjid(BigDecimal objid) {
        this.objid = objid;
    }

    public String getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(String secUserId) {
        this.secUserId = secUserId;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTech() {
        return this.tech;
    }

    public void setTech(String tech) {
        this.tech = tech;
    }

    public Date getInsertDate() {
        return this.insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getTechLong() {
        return this.techLong;
    }

    public void setTechLong(String techLong) {
        this.techLong = techLong;
    }

}