/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity.retail.session;

import com.tracfone.ejb.entity.retail.CRtlTFOneReport;

import javax.ejb.Local;
import java.util.Date;

/**
 * @author Gaurav.Sharma
 */
@Local
public interface CRtlReportFacadeLocal {
    void create(CRtlTFOneReport report);

    void edit(CRtlTFOneReport report);

    void remove(CRtlTFOneReport report);

    CRtlTFOneReport find(Object id);

    CRtlTFOneReport findIgTopErrReportByDate(Date fromDate, Date toDate, String reportName);

    CRtlTFOneReport findLastRowInserted(String reportName);

    void deletetfOneReport(int numberOfdays);

    int count();
}
