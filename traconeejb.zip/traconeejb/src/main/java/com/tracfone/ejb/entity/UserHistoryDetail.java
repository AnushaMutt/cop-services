/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.ejb.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author spulavarthy
 */
@Entity
@Table(name = "COP.COP_ID_USER_HISTORY_DETAIL")
public class UserHistoryDetail implements Serializable{
    
    private static final long serialVersionUID = 12L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "User_History_Detail_Seq")
    @SequenceGenerator(name = "User_History_Detail_Seq", sequenceName = "COP.SEQ_COP_ID_USER_HISTORY_DETAIL", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "ID")
    private Long id;
    @JoinColumn(name = "HISTORY_ID")
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = UserHistory.class)
    private UserHistory userHistory;
    @Column(name = "ID_TYPE")
    private String IdType;
    @Column(name = "ID_DETAIL")
    private String detail;
    @Column(name = "CREATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;
    @Column(name = "UPDATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public UserHistory getUserHistory() { return userHistory; }

    public void setUserHistory(UserHistory userHistory) { this.userHistory = userHistory; }

    public String getIdType() {
        return IdType;
    }

    public void setIdType(String IdType) {
        this.IdType = IdType;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
     @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UserHistoryDetail)) return false;
        return id != null && id.equals(((UserHistoryDetail) o).getId());
    }

    @Override
    public int hashCode() {
        return 31;
    }
    
    
}
