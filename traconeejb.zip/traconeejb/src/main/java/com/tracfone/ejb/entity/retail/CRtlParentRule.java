package com.tracfone.ejb.entity.retail;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;

@Entity
@Table(name = "C_RTL_PARENT_RULE", uniqueConstraints = @UniqueConstraint(columnNames = {
        "RULE2PARENT", "RULE2CPREF_GRP_TRAIT"}))
@XmlRootElement
@NamedQueries({@NamedQuery(name = "CRtlParentRule.findAllByParent", query = "SELECT c FROM CRtlParentRule c where c.rule2Parent = :rule2Parent")})
public class CRtlParentRule implements Serializable {
    private static final long serialVersionUID = 139056674118158015L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "Carrier_Parent_Rule_Seq")
    @SequenceGenerator(name = "Carrier_Parent_Rule_Seq", sequenceName = "C_RTL_PARENT_RULE_SEQ", allocationSize = 1)
    @Basic(optional = false)
    @Column(name = "OBJID", unique = true, nullable = false, precision = 22, scale = 0)
    private BigDecimal objid;
    @Column(name = "RULE2PARENT", nullable = false)
    private BigDecimal rule2Parent;
    @Column(name = "RULE2CPREF_GRP_TRAIT", nullable = false)
    private BigDecimal rule2cPrefGrpTrait;
    @Column(name = "RULE2CPREF_GRP_RANK")
    private BigDecimal rule2cPrefGrpRank;
    @Column(name = "RULE2TRAIT_RULE")
    private BigDecimal rule2TraitRule;

    public CRtlParentRule() {
    }

    public BigDecimal getObjid() {
        return objid;
    }

    public void setObjid(BigDecimal objid) {
        this.objid = objid;
    }

    public BigDecimal getRule2Parent() {
        return rule2Parent;
    }

    public void setRule2Parent(BigDecimal rule2Parent) {
        this.rule2Parent = rule2Parent;
    }

    public BigDecimal getRule2cPrefGrpTrait() {
        return rule2cPrefGrpTrait;
    }

    public void setRule2cPrefGrpTrait(BigDecimal rule2cPrefGrpTrait) {
        this.rule2cPrefGrpTrait = rule2cPrefGrpTrait;
    }

    public BigDecimal getRule2cPrefGrpRank() {
        return rule2cPrefGrpRank;
    }

    public void setRule2cPrefGrpRank(BigDecimal rule2cPrefGrpRank) {
        this.rule2cPrefGrpRank = rule2cPrefGrpRank;
    }

    public BigDecimal getRule2TraitRule() {
        return rule2TraitRule;
    }

    public void setRule2TraitRule(BigDecimal rule2TraitRule) {
        this.rule2TraitRule = rule2TraitRule;
    }
}
