package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfig;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfigDetails;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGCarrierConfig;
import com.tracfone.service.model.response.TFOneIGCarrierConfigDetails;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import com.tracfone.service.util.TracfoneOneIGCarrierConfigConstant;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import org.mockito.junit.MockitoJUnitRunner;

/**
 *
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneIGCarrierConfigControllerTest implements TracfoneOneIGCarrierConfigConstant {

    private static final String DBENV = "DBENV";

    @InjectMocks
    TracfoneOneIGCarrierConfigController controller;

    @Mock
    TracfoneOneIGCarrierConfigActionLocal action;

    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "100");
        tracfoneOneException = new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
    }

    @Test
    public void testGetCarriers() throws TracfoneOneException {
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setDbEnv(DBENV);
        List<String> carrierData = new ArrayList<>();
        carrierData.add("TMOBILE");
        carrierData.add("VERIZON");
        when(action.getCarriers(any())).thenReturn(carrierData);
        List<String> carriers = controller.getCarriers(any());
        assertEquals("[TMOBILE, VERIZON]", carriers.toString());
    }

    @Test
    public void testGetCarriers_whenException() throws TracfoneOneException {
        doThrow(TracfoneOneException.class).when(action).getCarriers(any());
        try {
            controller.getCarriers(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_CARRIERS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_CARRIERS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCarrierConfigs() throws TracfoneOneException {
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setDbEnv(DBENV);
        carrierConfig.setCarrier("TMOBILE");
        List<TFOneIGCarrierConfig> carrierConfigs = new ArrayList<>();
        TFOneIGCarrierConfig config = new TFOneIGCarrierConfig();
        TFOneIGCarrierConfigDetails carrierDetails = new TFOneIGCarrierConfigDetails();
        config.setCarrier("TMOBILE");
        config.setConfigId("21212");
        config.setPropName("TEST");
        config.setPropType("STRING");
        carrierDetails.setConfigId("21212");
        carrierDetails.setPropKey("123");
        carrierDetails.setPropValue("TESTING");
        config.setCarrierDetails(carrierDetails);
        carrierConfigs.add(config);
        when(action.getCarrierConfig(any())).thenReturn(carrierConfigs);
        List<TFOneIGCarrierConfig> tFOneIGCarrierConfigs = controller.getCarrierConfig(any());
        assertEquals("[TFOneIGCarrierConfig{configId=21212, carrier=TMOBILE, propName=TEST, propType=STRING, description=null, carrierDetails=TFOneIGCarrierDetails{configId=21212, propKey=123, propValueType=null, propValue=TESTING, propValueKey=null, propValueKeyType=null, propValueKeyKey=null, remarks=null}}]", tFOneIGCarrierConfigs.toString());
    }

    @Test
    public void testGetCarrierConfigs_whenException() throws TracfoneOneException {
        doThrow(TracfoneOneException.class).when(action).getCarrierConfig(any());
        try {
            controller.getCarrierConfig(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_CARRIER_CONFIGS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_CARRIER_CONFIGS_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierDetails() throws TracfoneOneException {
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setDbEnv(DBENV);
        carrierConfig.setPropType("MAP");
        carrierConfig.setConfigId("12212");
        TracfoneOneIGCarrierConfigDetails carrierDetails = new TracfoneOneIGCarrierConfigDetails();
        carrierDetails.setConfigId("12121");
        carrierDetails.setDbEnv(DBENV);
        carrierDetails.setPropKey("123");
        carrierDetails.setPropValue("TEST");
        carrierDetails.setPropValueType("STRING");
        carrierDetails.setOldPropKey("213");
        carrierDetails.setOldPropValue("TEST");
        carrierDetails.setOldPropValueType("STRING");
        carrierConfig.setIgCarrierDetails(carrierDetails);
        when(action.updateCarrierConfigDetails(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = controller.updateCarrierConfigDetails(carrierConfig, 100);
        assertEquals("200", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testUpdateCarrierDetails_whenException() throws TracfoneOneException {
        doThrow(TracfoneOneException.class).when(action).updateCarrierConfigDetails(any(), anyInt());
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setDbEnv(DBENV);
        carrierConfig.setPropType("String");
        try {
            controller.updateCarrierConfigDetails(carrierConfig, 123);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CARRIER_CONFIG_DETAILS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CARRIER_CONFIG_DETAILS_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierDetails() throws TracfoneOneException {
        TracfoneOneIGCarrierConfigDetails carrierDetails = new TracfoneOneIGCarrierConfigDetails();
        carrierDetails.setConfigId("12121");
        carrierDetails.setDbEnv(DBENV);
        carrierDetails.setPropKey("123");
        carrierDetails.setPropValue("TEST");
        carrierDetails.setPropValueType("STRING");
        carrierDetails.setOldPropKey("213");
        carrierDetails.setOldPropValue("TEST");
        carrierDetails.setOldPropValueType("STRING");
        when(action.deleteCarrierConfigDetails(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = controller.deleteCarrierConfigDetails(carrierDetails, 100);
        assertEquals("200", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testDeleteCarrierDetails_whenException() throws TracfoneOneException {
        doThrow(TracfoneOneException.class).when(action).deleteCarrierConfigDetails(any(), anyInt());
        try {
            controller.deleteCarrierConfigDetails(null, 123);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_CARRIER_CONFIG_DETAILS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_CARRIER_CONFIG_DETAILS_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierDetails() throws TracfoneOneException {
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setConfigId("12121");
        carrierConfig.setPropType("String");
        TracfoneOneIGCarrierConfigDetails carrierDetails = new TracfoneOneIGCarrierConfigDetails();
        carrierDetails.setConfigId("12121");
        carrierDetails.setDbEnv(DBENV);
        carrierDetails.setPropKey("123");
        carrierDetails.setPropValue("TEST");
        carrierDetails.setPropValueType("STRING");
        carrierDetails.setOldPropKey("213");
        carrierDetails.setOldPropValue("TEST");
        carrierDetails.setOldPropValueType("STRING");
        carrierConfig.setIgCarrierDetails(carrierDetails);
        when(action.insertCarrierConfigDetails(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = controller.insertCarrierConfigDetails(carrierConfig, 100);
        assertEquals("Success", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testInsertCarrierDetails_whenException() throws TracfoneOneException {
        doThrow(TracfoneOneException.class).when(action).insertCarrierConfigDetails(any(), anyInt());
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setConfigId("12121");
        carrierConfig.setPropType("String");
        try {
            controller.insertCarrierConfigDetails(carrierConfig, 123);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_CARRIER_CONFIG_DETAILS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_CARRIER_CONFIG_DETAILS_MESSAGE, e.getErrorMessage());
        }
    }

    /** Sprint - 32 */

    @Test
    public void testInsertCarrierConfig() throws TracfoneOneException {
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setConfigId("12121");
        carrierConfig.setPropType("String");
        carrierConfig.setPropName("String");
        carrierConfig.setCarrier("TMO");
        carrierConfig.setDescription("TEST");
        when(action.insertCarrierConfig(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = controller.insertCarrierConfig(carrierConfig, 100);
        assertEquals("Success", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testInsertCarrierConfig_whenException() throws TracfoneOneException {
        doThrow(TracfoneOneException.class).when(action).insertCarrierConfig(any(), anyInt());
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setConfigId("12121");
        carrierConfig.setPropType("String");
        try {
            controller.insertCarrierConfig(carrierConfig, 123);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_CARRIER_CONFIG_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_CARRIER_CONFIG_MESSAGE, e.getErrorMessage());
        }
    }

}
