package com.tracfone.service;

import com.tracfone.service.controller.TracfoneOneIgCarrierNotficationControllerLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneIGCarrierNotification;
import java.io.UnsupportedEncodingException;
import javax.ws.rs.core.Response;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import org.mockito.junit.MockitoJUnitRunner;

/**
 *
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneIgCarrierNotificationResourceTest {

    @InjectMocks
    private TracfoneOneIgCarrierNotificationResource resource;
    
    public final String JSON = "application/json";
    @Mock
    private TracfoneOneIgCarrierNotficationControllerLocal carrierNotficationControllerLocal;
    
    @Test
    public void testGetResponse() throws TracfoneOneException, UnsupportedEncodingException {
        String carrierData = "";
        TracfoneOneIGCarrierNotification carrierNotification = new TracfoneOneIGCarrierNotification();
        carrierNotification.setRequest("TESTING");
        carrierNotification.setRequestMethod("POST");
        carrierNotification.setRequestType("XML");

        when(carrierNotficationControllerLocal.getResponse(any())).thenReturn(carrierData);
        Response response = resource.getCarriers(carrierNotification);
        assertEquals(response.getStatus(), 200);
    }

}
