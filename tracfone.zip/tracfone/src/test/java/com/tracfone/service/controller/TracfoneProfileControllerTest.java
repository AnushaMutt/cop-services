package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneAncillaryCode;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeConfig;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeDiscount;
import com.tracfone.service.model.request.TracfoneOneChildPlan;
import com.tracfone.service.model.request.TracfoneOneLineStatusCode;
import com.tracfone.service.model.request.TracfoneOneMultiRatePlanEsn;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtension;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionLink;
import com.tracfone.service.model.request.TracfoneOneRatePlanProfile;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneThrottleStatusCode;
import com.tracfone.service.model.response.TFOneAncillaryCode;
import com.tracfone.service.model.response.TFOneAncillaryCodeConfig;
import com.tracfone.service.model.response.TFOneAncillaryCodeDiscount;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneMultiRatePlanEsn;
import com.tracfone.service.model.response.TFOneRatePlanExtension;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_ANCILLARY_CODE_DISCOUNT_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_ANCILLARY_CODE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_ANCILLARY_CODE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_MULTI_RATE_PLAN_ESNS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_PROFILE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_PROFILE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_PROFILE_EXTENSION_LINK_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_PROFILE_EXTENSION_LINK_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_RP_EXTENSION_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_RP_EXTENSION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ANCILLARY_CODE_DEPENDENCY_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ANCILLARY_CODE_DEPENDENCY_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_CHILD_PLAN_DEPENDENCY_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_CHILD_PLAN_DEPENDENCY_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_ANCILLARY_CODE_CONFIG_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_ANCILLARY_CODE_DISCOUNT_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_ANCILLARY_CODE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_ANCILLARY_CODE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CHILD_PLAN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CHILD_PLAN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_LINE_STATUS_CODE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_LINE_STATUS_CODE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_MULTI_RATE_PLAN_ESNS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_PROFILE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_PROFILE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_RP_EXTENSION_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_RP_EXTENSION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_RP_EXTENSION_LINK_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_RP_EXTENSION_LINK_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_THROTTLE_STATUS_CODE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_THROTTLE_STATUS_CODE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_ANCILLARY_CODE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_ANCILLARY_CODE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_CHILD_PLAN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_CHILD_PLAN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_PROFILE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_PROFILE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_RP_EXTENSION_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_RP_EXTENSION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ANCILLARY_CODE_CONFIG_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_PROFILE_SERVICE_PLANS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_PROFILE_SERVICE_PLANS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_RP_SERVICE_PLANS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_RP_SERVICE_PLANS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_CHILD_PLAN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_CHILD_PLAN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_RP_EXTENSION_DEPENDENCY_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_RP_EXTENSION_DEPENDENCY_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_ANCILLARY_CODE_DISCOUNT_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_ANCILLARY_CODE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_ANCILLARY_CODE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_MULTI_RATE_PLAN_ESNS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_PROFILE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_PROFILE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_PROFILE_FOR_UPDATE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_PROFILE_FOR_UPDATE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_RP_EXTENSION_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_RP_EXTENSION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_ANCILLARY_CODE_DISCOUNT_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_ANCILLARY_DESC_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_ANCILLARY_DESC_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CHILD_PLAN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CHILD_PLAN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_MULTI_RATE_PLAN_ESNS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_PROFILE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_PROFILE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_RP_EXTENSION_LINK_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_RP_EXTENSION_LINK_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_VIEW_ALL_ANCILLARY_CODES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_VIEW_ALL_ANCILLARY_CODES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_VIEW_ALL_CHILD_PLANS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_VIEW_ALL_CHILD_PLANS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_VIEW_PROFILE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_VIEW_PROFILE_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneProfileControllerTest {
    @InjectMocks
    private TracfoneProfileController tracfoneProfileController;
    @Mock
    private TracfoneProfileLocalAction tracfoneProfileLocalAction;
    private TracfoneOneException tracfoneOneException;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private static final String PROFILE_ID = "1000";
    private static final String DBENV = "DBENV";
    private static final String SAMPLE = "SAMPLE";
    private static final String ACTIVE_FLAG = "Y";

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", SAMPLE);
        tracfoneOneException = new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
    }

    @Test
    public void testInsertProfile() throws Exception {
        TracfoneOneRatePlanProfile tracfoneOneRatePlanProfile = new TracfoneOneRatePlanProfile();
        tracfoneOneRatePlanProfile.setDbEnv(DBENV);
        tracfoneOneRatePlanProfile.setProfileDescription(SAMPLE);
        when(tracfoneProfileLocalAction.insertProfile(any(TracfoneOneRatePlanProfile.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.insertProfile(tracfoneOneRatePlanProfile, 100);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneRatePlanProfile.getProfileDescription());
    }

    @Test
    public void testViewBucket_whenException() throws Exception {
        TracfoneOneRatePlanProfile tracfoneOneRatePlanProfile = new TracfoneOneRatePlanProfile();
        tracfoneOneRatePlanProfile.setDbEnv(DBENV);
        tracfoneOneRatePlanProfile.setProfileDescription("DESC");
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).insertProfile(any(TracfoneOneRatePlanProfile.class), anyInt());
        try {
            tracfoneProfileController.insertProfile(tracfoneOneRatePlanProfile, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_PROFILE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_PROFILE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testViewProfile() throws Exception {
        TracfoneOneRatePlanProfile tracfoneOneRatePlanProfile = new TracfoneOneRatePlanProfile();
        tracfoneOneRatePlanProfile.setDbEnv(DBENV);
        tracfoneOneRatePlanProfile.setProfileId(PROFILE_ID);
        tracfoneOneRatePlanProfile.setProfileDescription(SAMPLE);
        TFOneRatePlanProfile tfOneRatePlanProfile = new TFOneRatePlanProfile();
        tfOneRatePlanProfile.setProfileId(PROFILE_ID);
        tfOneRatePlanProfile.setProfileDescription(SAMPLE);
        when(tracfoneProfileLocalAction.viewProfile(any(TracfoneOneRatePlanProfile.class))).thenReturn(tfOneRatePlanProfile);
        TFOneRatePlanProfile response = tracfoneProfileController.viewProfile(tracfoneOneRatePlanProfile);
        assertEquals(response.getProfileId(), tracfoneOneRatePlanProfile.getProfileId());
        assertEquals(response.getProfileDescription(), tracfoneOneRatePlanProfile.getProfileDescription());
    }

    @Test
    public void testViewProfile_whenException() throws Exception {
        TracfoneOneRatePlanProfile tracfoneOneRatePlanProfile = new TracfoneOneRatePlanProfile();
        tracfoneOneRatePlanProfile.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).viewProfile(any(TracfoneOneRatePlanProfile.class));
        try {
            tracfoneProfileController.viewProfile(tracfoneOneRatePlanProfile);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_VIEW_PROFILE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_VIEW_PROFILE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateProfile() throws Exception {
        TracfoneOneRatePlanProfile tracfoneOneRatePlanProfile = new TracfoneOneRatePlanProfile();
        tracfoneOneRatePlanProfile.setDbEnv(DBENV);
        tracfoneOneRatePlanProfile.setProfileId(PROFILE_ID);
        tracfoneOneRatePlanProfile.setProfileDescription(SAMPLE);
        TFOneRatePlanProfile duplicateProfile = new TFOneRatePlanProfile();
        duplicateProfile.setProfileId(PROFILE_ID);
        duplicateProfile.setProfileDescription(SAMPLE);
        when(tracfoneProfileLocalAction.viewProfile(any(TracfoneOneRatePlanProfile.class))).thenReturn(duplicateProfile);
        when(tracfoneProfileLocalAction.updateProfile(any(TracfoneOneRatePlanProfile.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.updateProfile(tracfoneOneRatePlanProfile, 1000);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals(SAMPLE, response.getMessage());
    }

    @Test
    public void testUpdateProfile_whenException() throws Exception {
        TracfoneOneRatePlanProfile tracfoneOneRatePlanProfile = new TracfoneOneRatePlanProfile();
        tracfoneOneRatePlanProfile.setDbEnv(DBENV);
        tracfoneOneRatePlanProfile.setProfileId(PROFILE_ID);
        tracfoneOneRatePlanProfile.setProfileDescription(SAMPLE);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).updateProfile(any(TracfoneOneRatePlanProfile.class), anyInt());
        try {
            tracfoneProfileController.updateProfile(tracfoneOneRatePlanProfile, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_PROFILE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_PROFILE_ERROR_MESSAGE, e.getErrorMessage());
        }

        // case of duplicate
        TFOneRatePlanProfile duplicateProfile = new TFOneRatePlanProfile();
        duplicateProfile.setProfileId("DIFFERENT_ID");
        duplicateProfile.setProfileDescription(SAMPLE);
        when(tracfoneProfileLocalAction.viewProfile(any(TracfoneOneRatePlanProfile.class))).thenReturn(duplicateProfile);
        try {
            tracfoneProfileController.updateProfile(tracfoneOneRatePlanProfile, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DUPLICATE_PROFILE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DUPLICATE_PROFILE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteProfile() throws Exception {
        TracfoneOneRatePlanProfile tracfoneOneRatePlanProfile = new TracfoneOneRatePlanProfile();
        tracfoneOneRatePlanProfile.setDbEnv(DBENV);
        tracfoneOneRatePlanProfile.setProfileId(PROFILE_ID);
        tracfoneOneRatePlanProfile.setProfileDescription(SAMPLE);
        when(tracfoneProfileLocalAction.deleteProfile(anyString(), anyList(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.deleteProfile(tracfoneOneRatePlanProfile, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneRatePlanProfile.getProfileDescription());
    }

    @Test
    public void testDeleteProfile_whenException() throws Exception {
        TracfoneOneRatePlanProfile tracfoneOneRatePlanProfile = new TracfoneOneRatePlanProfile();
        tracfoneOneRatePlanProfile.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).deleteProfile(anyString(), anyList(), anyInt());
        try {
            tracfoneProfileController.deleteProfile(tracfoneOneRatePlanProfile, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_PROFILE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_PROFILE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllAncillaryCodes() throws Exception {
        List<TFOneAncillaryCode> tfOneAncillaryCodes = new ArrayList<>();
        TFOneAncillaryCode tfOneAncillaryCode = new TFOneAncillaryCode();
        tfOneAncillaryCode.setAncillaryCode(SAMPLE);
        tfOneAncillaryCode.setDescription(SAMPLE);
        tfOneAncillaryCodes.add(tfOneAncillaryCode);
        when(tracfoneProfileLocalAction.getAllAncillaryCodes(anyString())).thenReturn(tfOneAncillaryCodes);
        List<TFOneAncillaryCode> response = tracfoneProfileController.getAllAncillaryCodes(DBENV);
        assertEquals(response.get(0).getAncillaryCode(), tfOneAncillaryCode.getAncillaryCode());
        assertEquals(response.get(0).getDescription(), tfOneAncillaryCode.getDescription());
    }

    @Test
    public void testGetAllAncillaryCodes_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).getAllAncillaryCodes(anyString());
        try {
            tracfoneProfileController.getAllAncillaryCodes(DBENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_VIEW_ALL_ANCILLARY_CODES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_VIEW_ALL_ANCILLARY_CODES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllChildPlans() throws Exception {
        List<TFOneChildPlan> tfOneAncillaryCodes = new ArrayList<>();
        TFOneChildPlan tfOneAncillaryCode = new TFOneChildPlan();
        tfOneAncillaryCode.setChildPlanId(SAMPLE);
        tfOneAncillaryCode.setChildDescription(SAMPLE);
        tfOneAncillaryCodes.add(tfOneAncillaryCode);
        when(tracfoneProfileLocalAction.getAllChildPlans(anyString())).thenReturn(tfOneAncillaryCodes);
        List<TFOneChildPlan> response = tracfoneProfileController.getAllChildPlans(DBENV);
        assertEquals(response.get(0).getChildPlanId(), tfOneAncillaryCode.getChildPlanId());
        assertEquals(response.get(0).getChildDescription(), tfOneAncillaryCode.getChildDescription());
    }

    @Test
    public void testGetAllChildPlans_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).getAllChildPlans(anyString());
        try {
            tracfoneProfileController.getAllChildPlans(DBENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_VIEW_ALL_CHILD_PLANS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_VIEW_ALL_CHILD_PLANS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchProfile() throws Exception {
        List<TFOneRatePlanProfile> tfOneRatePlanProfileList = new ArrayList<>();
        TFOneRatePlanProfile tfOneAncillaryCode = new TFOneRatePlanProfile();
        tfOneAncillaryCode.setProfileId(SAMPLE);
        tfOneAncillaryCode.setProfileDescription(SAMPLE);
        tfOneRatePlanProfileList.add(tfOneAncillaryCode);
        TracfoneOneSearchProfileModel tracfoneOneRatePlanProfile = new TracfoneOneSearchProfileModel();
        tracfoneOneRatePlanProfile.setProfileDesc(SAMPLE);
        tracfoneOneRatePlanProfile.setDbEnv(DBENV);
        tracfoneOneRatePlanProfile.setProfileId(PROFILE_ID);
        when(tracfoneProfileLocalAction.searchProfile(any())).thenReturn(tfOneRatePlanProfileList);
        List<TFOneRatePlanProfile> response = tracfoneProfileController.searchProfile(tracfoneOneRatePlanProfile);
        assertEquals(response.get(0).getProfileDescription(), tfOneAncillaryCode.getProfileDescription());
        assertEquals(response.get(0).getProfileId(), tfOneAncillaryCode.getProfileId());
    }

    @Test
    public void testSearchProfile_whenException() throws Exception {
        TracfoneOneSearchProfileModel tracfoneOneRatePlanProfile = new TracfoneOneSearchProfileModel();
        tracfoneOneRatePlanProfile.setProfileDesc(SAMPLE);
        tracfoneOneRatePlanProfile.setDbEnv(DBENV);
        tracfoneOneRatePlanProfile.setProfileId(PROFILE_ID);
        tracfoneOneRatePlanProfile.setRatePlan("Rate_Plan");
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).searchProfile(any());
        try {
            tracfoneProfileController.searchProfile(tracfoneOneRatePlanProfile);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_PROFILE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_PROFILE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchForUnlinkedProfiles() throws Exception {
        List<TFOneRatePlanProfile> tfOneRatePlanProfileList = new ArrayList<>();
        TFOneRatePlanProfile tfOneAncillaryCode = new TFOneRatePlanProfile();
        tfOneAncillaryCode.setProfileId(SAMPLE);
        tfOneAncillaryCode.setProfileDescription(SAMPLE);
        tfOneRatePlanProfileList.add(tfOneAncillaryCode);
        TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel = new TracfoneOneSearchProfileModel();
        tracfoneOneSearchProfileModel.setDbEnv(DBENV);
        tracfoneOneSearchProfileModel.setProfileId(PROFILE_ID);
        when(tracfoneProfileLocalAction.searchProfilesForUpdate(any(TracfoneOneSearchProfileModel.class))).thenReturn(tfOneRatePlanProfileList);
        List<TFOneRatePlanProfile> response = tracfoneProfileController.searchProfilesForUpdate(tracfoneOneSearchProfileModel);
        assertEquals(response.get(0).getProfileDescription(), tfOneAncillaryCode.getProfileDescription());
        assertEquals(response.get(0).getProfileId(), tfOneAncillaryCode.getProfileId());
    }

    @Test
    public void testSearchForUnlinkedProfiles_whenException() throws Exception {
        TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel = new TracfoneOneSearchProfileModel();
        tracfoneOneSearchProfileModel.setDbEnv(DBENV);
        tracfoneOneSearchProfileModel.setProfileId(PROFILE_ID);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).searchProfilesForUpdate(any(TracfoneOneSearchProfileModel.class));
        try {
            tracfoneProfileController.searchProfilesForUpdate(tracfoneOneSearchProfileModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_PROFILE_FOR_UPDATE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_PROFILE_FOR_UPDATE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateChildPlan() throws Exception {
        TracfoneOneChildPlan tracfoneOneChildPlan = new TracfoneOneChildPlan();
        tracfoneOneChildPlan.setDbEnv(DBENV);
        tracfoneOneChildPlan.setChildDescription(SAMPLE);
        tracfoneOneChildPlan.setChildPlanId(SAMPLE);
        TFOneChildPlan oneRatePlanProfile = new TFOneChildPlan();
        oneRatePlanProfile.setChildDescription(SAMPLE);
        when(tracfoneProfileLocalAction.viewChildPlan(any(TracfoneOneChildPlan.class))).thenReturn(oneRatePlanProfile);
        when(tracfoneProfileLocalAction.updateChildPlan(any(TracfoneOneChildPlan.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.updateChildPlan(tracfoneOneChildPlan, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneChildPlan.getChildDescription());
    }

    @Test
    public void testUpdateChildPlan_whenException() throws Exception {
        TracfoneOneChildPlan tracfoneOneChildPlan = new TracfoneOneChildPlan();
        tracfoneOneChildPlan.setDbEnv(DBENV);
        tracfoneOneChildPlan.setChildDescription(SAMPLE);
        tracfoneOneChildPlan.setChildPlanId(SAMPLE);
        TFOneChildPlan oneRatePlanProfile = new TFOneChildPlan();
        oneRatePlanProfile.setChildDescription(SAMPLE);
        when(tracfoneProfileLocalAction.viewChildPlan(any(TracfoneOneChildPlan.class))).thenReturn(oneRatePlanProfile);
        try {
            tracfoneProfileController.updateChildPlan(tracfoneOneChildPlan, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CHILD_PLAN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CHILD_PLAN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateChildPlan_whenChildProfileIsNotNull() throws Exception {
        TracfoneOneChildPlan tracfoneOneChildPlan = new TracfoneOneChildPlan();
        tracfoneOneChildPlan.setDbEnv(DBENV);
        tracfoneOneChildPlan.setChildDescription(SAMPLE);
        tracfoneOneChildPlan.setChildPlanId(SAMPLE);
        TFOneChildPlan oneRatePlanProfile = new TFOneChildPlan();
        oneRatePlanProfile.setChildDescription(SAMPLE);
        oneRatePlanProfile.setChildPlanId(PROFILE_ID);
        when(tracfoneProfileLocalAction.viewChildPlan(any(TracfoneOneChildPlan.class))).thenReturn(oneRatePlanProfile);
        try {
            tracfoneProfileController.updateChildPlan(tracfoneOneChildPlan, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DUPLICATE_CHILD_PLAN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DUPLICATE_CHILD_PLAN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertChildPlan() throws Exception {
        TracfoneOneChildPlan tracfoneOneChildPlan = new TracfoneOneChildPlan();
        tracfoneOneChildPlan.setDbEnv(DBENV);
        tracfoneOneChildPlan.setChildDescription(SAMPLE);
        tracfoneOneChildPlan.setChildPlanId(SAMPLE);
        when(tracfoneProfileLocalAction.insertChildPlan(any(TracfoneOneChildPlan.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.insertChildPlan(tracfoneOneChildPlan, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneChildPlan.getChildDescription());
    }

    @Test
    public void testInsertChildPlan_whenException() throws Exception {
        TracfoneOneChildPlan tracfoneOneChildPlan = new TracfoneOneChildPlan();
        tracfoneOneChildPlan.setDbEnv(DBENV);
        tracfoneOneChildPlan.setChildDescription(SAMPLE);
        tracfoneOneChildPlan.setChildPlanId(SAMPLE);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).insertChildPlan(any(TracfoneOneChildPlan.class), anyInt());
        try {
            tracfoneProfileController.insertChildPlan(tracfoneOneChildPlan, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_CHILD_PLAN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_CHILD_PLAN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteChildPlan() throws Exception {
        TracfoneOneChildPlan tracfoneOneChildPlan = new TracfoneOneChildPlan();
        tracfoneOneChildPlan.setDbEnv(DBENV);
        tracfoneOneChildPlan.setChildDescription(SAMPLE);
        tracfoneOneChildPlan.setChildPlanId(SAMPLE);
        when(tracfoneProfileLocalAction.deleteChildPlan(any(TracfoneOneChildPlan.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.deleteChildPlan(tracfoneOneChildPlan, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneChildPlan.getChildDescription());
    }

    @Test
    public void testDeleteChildPlan_whenCheckChildPlanDependenciesIsTrue() throws Exception {
        TracfoneOneChildPlan tracfoneOneChildPlan = new TracfoneOneChildPlan();
        tracfoneOneChildPlan.setDbEnv(DBENV);
        tracfoneOneChildPlan.setChildDescription(SAMPLE);
        tracfoneOneChildPlan.setChildPlanId(SAMPLE);
        when(tracfoneProfileLocalAction.checkChildPlanDependencies(any(TracfoneOneChildPlan.class))).thenReturn(true);
        try {
            tracfoneProfileController.deleteChildPlan(tracfoneOneChildPlan, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_CHILD_PLAN_DEPENDENCY_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_CHILD_PLAN_DEPENDENCY_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteChildPlan_whenException() throws Exception {
        TracfoneOneChildPlan tracfoneOneChildPlan = new TracfoneOneChildPlan();
        tracfoneOneChildPlan.setDbEnv(DBENV);
        tracfoneOneChildPlan.setChildDescription(SAMPLE);
        tracfoneOneChildPlan.setChildPlanId(SAMPLE);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).deleteChildPlan(any(TracfoneOneChildPlan.class), anyInt());
        try {
            tracfoneProfileController.deleteChildPlan(tracfoneOneChildPlan, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_CHILD_PLAN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_CHILD_PLAN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteAncillaryCode() throws Exception {
        TracfoneOneAncillaryCode tracfoneOneChildPlan = new TracfoneOneAncillaryCode();
        tracfoneOneChildPlan.setDbEnv(DBENV);
        tracfoneOneChildPlan.setDescription(SAMPLE);
        tracfoneOneChildPlan.setAncillaryCode(SAMPLE);
        when(tracfoneProfileLocalAction.deleteAncillaryCode(any(TracfoneOneAncillaryCode.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.deleteAncillaryCode(tracfoneOneChildPlan, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneChildPlan.getDescription());
    }

    @Test
    public void testDeleteAncillaryCode_whenCheckAncillaryCodeDependenciesIsTrue() throws Exception {
        TracfoneOneAncillaryCode tracfoneOneChildPlan = new TracfoneOneAncillaryCode();
        tracfoneOneChildPlan.setDbEnv(DBENV);
        tracfoneOneChildPlan.setAncillaryCode(SAMPLE);
        tracfoneOneChildPlan.setDescription(SAMPLE);
        when(tracfoneProfileLocalAction.checkRpExtensionCodeDependencies(any(TracfoneOneRatePlanExtension.class))).thenReturn(true);
        try {
            tracfoneProfileController.deleteAncillaryCode(tracfoneOneChildPlan, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ANCILLARY_CODE_DEPENDENCY_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ANCILLARY_CODE_DEPENDENCY_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteAncillaryCode_whenException() throws Exception {
        TracfoneOneAncillaryCode tracfoneOneChildPlan = new TracfoneOneAncillaryCode();
        tracfoneOneChildPlan.setDbEnv(DBENV);
        tracfoneOneChildPlan.setAncillaryCode(SAMPLE);
        tracfoneOneChildPlan.setDescription(SAMPLE);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).deleteAncillaryCode(any(TracfoneOneAncillaryCode.class), anyInt());
        try {
            tracfoneProfileController.deleteAncillaryCode(tracfoneOneChildPlan, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_ANCILLARY_CODE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_ANCILLARY_CODE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertAncillaryCode() throws Exception {
        TracfoneOneAncillaryCode tracfoneOneAncillaryCode = new TracfoneOneAncillaryCode();
        tracfoneOneAncillaryCode.setDbEnv(DBENV);
        tracfoneOneAncillaryCode.setDescription(SAMPLE);
        tracfoneOneAncillaryCode.setAncillaryCode(SAMPLE);
        when(tracfoneProfileLocalAction.searchAncillaryCodes(any())).thenReturn(new ArrayList<>());
        when(tracfoneProfileLocalAction.insertAncillaryCode(any(TracfoneOneAncillaryCode.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.insertAncillaryCode(tracfoneOneAncillaryCode, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneAncillaryCode.getDescription());
    }

    @Test
    public void testInsertAncillaryCode_whenException() throws Exception {
        TracfoneOneAncillaryCode tracfoneOneAncillaryCode = new TracfoneOneAncillaryCode();
        tracfoneOneAncillaryCode.setDbEnv(DBENV);
        tracfoneOneAncillaryCode.setAncillaryCode(SAMPLE);
        tracfoneOneAncillaryCode.setDescription(SAMPLE);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).insertAncillaryCode(any(TracfoneOneAncillaryCode.class), anyInt());
        try {
            tracfoneProfileController.insertAncillaryCode(tracfoneOneAncillaryCode, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_ANCILLARY_CODE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_ANCILLARY_CODE_ERROR_MESSAGE, e.getErrorMessage());
        }

        // duplicate check
        List<TFOneAncillaryCode> ancillaryCodes = new ArrayList<>();
        ancillaryCodes.add(new TFOneAncillaryCode());
        when(tracfoneProfileLocalAction.searchAncillaryCodes(any())).thenReturn(ancillaryCodes);
        try {
            tracfoneProfileController.insertAncillaryCode(tracfoneOneAncillaryCode, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DUPLICATE_ANCILLARY_CODE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DUPLICATE_ANCILLARY_CODE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchAncillaryCodes() throws Exception {
        List<TFOneAncillaryCode> tfOneAncillaryCodes = new ArrayList<>();
        TFOneAncillaryCode tfOneAncillaryCode = new TFOneAncillaryCode();
        tfOneAncillaryCode.setDescription(SAMPLE);
        tfOneAncillaryCode.setAncillaryCode(SAMPLE);
        tfOneAncillaryCodes.add(tfOneAncillaryCode);
        TracfoneOneAncillaryCode tracfoneOneAncillaryCode = new TracfoneOneAncillaryCode();
        when(tracfoneProfileLocalAction.searchAncillaryCodes(any(TracfoneOneAncillaryCode.class))).thenReturn(tfOneAncillaryCodes);
        List<TFOneAncillaryCode> response = tracfoneProfileController.searchAncillaryCodes(tracfoneOneAncillaryCode);
        assertEquals(response.get(0).getDescription(), tfOneAncillaryCode.getDescription());
        assertEquals(response.get(0).getAncillaryCode(), tfOneAncillaryCode.getAncillaryCode());
    }

    @Test
    public void testSearchAncillaryCodes_whenException() throws Exception {
        TracfoneOneAncillaryCode tracfoneOneChildPlan = new TracfoneOneAncillaryCode();
        tracfoneOneChildPlan.setDbEnv(DBENV);
        tracfoneOneChildPlan.setAncillaryCode(SAMPLE);
        tracfoneOneChildPlan.setDescription(SAMPLE);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).searchAncillaryCodes(any(TracfoneOneAncillaryCode.class));
        try {
            tracfoneProfileController.searchAncillaryCodes(tracfoneOneChildPlan);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_ANCILLARY_CODE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_ANCILLARY_CODE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateAncillaryCode() throws Exception {
        TracfoneOneAncillaryCode ancillaryCode = new TracfoneOneAncillaryCode();
        ancillaryCode.setDbEnv(DBENV);
        ancillaryCode.setAncillaryCode("SAMPLE");
        ancillaryCode.setDescription("DESCRIPTION");
        when(tracfoneProfileLocalAction.updateAncillaryCode(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.updateAncillaryCode(ancillaryCode, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), ancillaryCode.getAncillaryCode());
    }

    @Test
    public void testUpdateAncillaryCode_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).updateAncillaryCode(any(), anyInt());
        try {
            tracfoneProfileController.updateAncillaryCode(null, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_ANCILLARY_DESC_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_ANCILLARY_DESC_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteRpExtension() throws Exception {
        TracfoneOneRatePlanExtension tracfoneOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tracfoneOneRatePlanExtension.setAncillaryCode(SAMPLE);
        tracfoneOneRatePlanExtension.setDbEnv(DBENV);
        when(tracfoneProfileLocalAction.checkRpExtensionDependencies(any())).thenReturn(false);
        when(tracfoneProfileLocalAction.deleteRpExtension(any(TracfoneOneRatePlanExtension.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.deleteRpExtension(tracfoneOneRatePlanExtension, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneRatePlanExtension.getAncillaryCode());
    }

    @Test
    public void testDeleteRpExtension_whenException() throws Exception {
        TracfoneOneRatePlanExtension tracfoneOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tracfoneOneRatePlanExtension.setAncillaryCode(SAMPLE);
        tracfoneOneRatePlanExtension.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).deleteRpExtension(any(TracfoneOneRatePlanExtension.class), anyInt());
        try {
            tracfoneProfileController.deleteRpExtension(tracfoneOneRatePlanExtension, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_RP_EXTENSION_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_RP_EXTENSION_ERROR_MESSAGE, e.getErrorMessage());
        }

        // with dependencies
        when(tracfoneProfileLocalAction.checkRpExtensionDependencies(any())).thenReturn(true);
        try {
            tracfoneProfileController.deleteRpExtension(tracfoneOneRatePlanExtension, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_RP_EXTENSION_DEPENDENCY_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_RP_EXTENSION_DEPENDENCY_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertRpExtension() throws Exception {
        TracfoneOneRatePlanExtension tracfoneOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tracfoneOneRatePlanExtension.setAncillaryCode(SAMPLE);
        tracfoneOneRatePlanExtension.setDbEnv(DBENV);
        when(tracfoneProfileLocalAction.searchRpExtensions(any())).thenReturn(new ArrayList<>());
        when(tracfoneProfileLocalAction.insertRpExtension(any(TracfoneOneRatePlanExtension.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.insertRpExtension(tracfoneOneRatePlanExtension, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneRatePlanExtension.getAncillaryCode());
    }

    @Test
    public void testInsertRpExtension_whenException() throws Exception {
        TracfoneOneRatePlanExtension tracfoneOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tracfoneOneRatePlanExtension.setAncillaryCode(SAMPLE);
        tracfoneOneRatePlanExtension.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).insertRpExtension(any(TracfoneOneRatePlanExtension.class), anyInt());
        try {
            tracfoneProfileController.insertRpExtension(tracfoneOneRatePlanExtension, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_RP_EXTENSION_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_RP_EXTENSION_ERROR_MESSAGE, e.getErrorMessage());
        }

        // duplicate check
        List<TFOneRatePlanExtension> extensionList = new ArrayList<>();
        extensionList.add(new TFOneRatePlanExtension());
        when(tracfoneProfileLocalAction.searchRpExtensions(any())).thenReturn(extensionList);
        try {
            tracfoneProfileController.insertRpExtension(tracfoneOneRatePlanExtension, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DUPLICATE_RP_EXTENSION_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DUPLICATE_RP_EXTENSION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchRpExtensions() throws Exception {
        List<TFOneRatePlanExtension> tfOneRatePlanExtensionList = new ArrayList<>();
        TFOneRatePlanExtension tfOneRatePlanExtension = new TFOneRatePlanExtension();
        tfOneRatePlanExtension.setAncillaryCode(SAMPLE);
        tfOneRatePlanExtension.setLineStatusCode(ACTIVE_FLAG);
        tfOneRatePlanExtensionList.add(tfOneRatePlanExtension);
        TracfoneOneRatePlanExtension tracfoneOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tracfoneOneRatePlanExtension.setAncillaryCode(SAMPLE);
        tracfoneOneRatePlanExtension.setDbEnv(DBENV);
        when(tracfoneProfileLocalAction.searchRpExtensions(any(TracfoneOneRatePlanExtension.class))).thenReturn(tfOneRatePlanExtensionList);
        List<TFOneRatePlanExtension> response = tracfoneProfileController.searchRpExtensions(tracfoneOneRatePlanExtension);
        assertEquals(response.get(0).getAncillaryCode(), tfOneRatePlanExtension.getAncillaryCode());
        assertEquals(response.get(0).getLineStatusCode(), tfOneRatePlanExtension.getLineStatusCode());
    }

    @Test
    public void testSearchRpExtensions_whenException() throws Exception {
        TracfoneOneRatePlanExtension tracfoneOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tracfoneOneRatePlanExtension.setAncillaryCode(SAMPLE);
        tracfoneOneRatePlanExtension.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).searchRpExtensions(any(TracfoneOneRatePlanExtension.class));
        try {
            tracfoneProfileController.searchRpExtensions(tracfoneOneRatePlanExtension);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_RP_EXTENSION_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_RP_EXTENSION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertRpExtensionLink() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionLink tfRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfRpExtensionLink.setCarrierFeatureId("CARRIER_FEATURE_ID");
        tfRpExtensionLink.setProfileId("PROFILE_ID");
        tfRpExtensionLink.setRatePlanExtensionId("RATE_PLAN_EXTENSION_ID");
        tfRpExtensionLink.setObjId(SAMPLE);
        tfRpExtensionLink.setDbEnv(DBENV);

        when(tracfoneProfileLocalAction.insertRpExtensionLink(any(TracfoneOneRatePlanExtensionLink.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.insertRpExtensionLink(tfRpExtensionLink, 1000);
        assertEquals(SAMPLE, response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testInsertRpExtensionLink_whenException() throws Exception {
        TracfoneOneRatePlanExtensionLink tfRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfRpExtensionLink.setRatePlanExtensionId("RATE_PLAEXTENSION_ID");
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).insertRpExtensionLink(any(TracfoneOneRatePlanExtensionLink.class), anyInt());
        try {
            tracfoneProfileController.insertRpExtensionLink(tfRpExtensionLink, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_PROFILE_EXTENSION_LINK_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_PROFILE_EXTENSION_LINK_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteRpExtensionLink() throws Exception {
        TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfOneRpExtensionLink.setObjId(SAMPLE);
        tfOneRpExtensionLink.setDbEnv(DBENV);
        when(tracfoneProfileLocalAction.deleteRpExtensionLink(any(TracfoneOneRatePlanExtensionLink.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.deleteRpExtensionLink(tfOneRpExtensionLink, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfOneRpExtensionLink.getObjId());
    }

    @Test
    public void testDeleteRpExtensionLink_whenException() throws Exception {
        TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfOneRpExtensionLink.setObjId(SAMPLE);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).deleteRpExtensionLink(any(TracfoneOneRatePlanExtensionLink.class), anyInt());
        try {
            tracfoneProfileController.deleteRpExtensionLink(tfOneRpExtensionLink, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_RP_EXTENSION_LINK_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_RP_EXTENSION_LINK_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateRpExtensionLink() throws Exception {
        TracfoneOneRatePlanExtensionLink tfRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfRpExtensionLink.setCarrierFeatureId("CARRIER_FEATURE_ID");
        tfRpExtensionLink.setProfileId("PROFILE_ID");
        tfRpExtensionLink.setRatePlanExtensionId("RATE_PLAEXTENSION_ID");
        tfRpExtensionLink.setObjId(SAMPLE);
        tfRpExtensionLink.setDbEnv(DBENV);
        when(tracfoneProfileLocalAction.updateRpExtensionLink(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.updateRpExtensionLink(tfRpExtensionLink, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfRpExtensionLink.getObjId());
    }

    @Test
    public void testUpdateRpExtensionLink_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).updateRpExtensionLink(any(), anyInt());
        try {
            tracfoneProfileController.updateRpExtensionLink(null, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_RP_EXTENSION_LINK_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_RP_EXTENSION_LINK_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllCarrierIds() throws Exception {
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan servicePlan = new TFOneCarrierServicePlan();
        servicePlan.setServicePlanId("500");
        servicePlan.setDescription("SAFELINK");
        carrierServicePlans.add(servicePlan);
        when(tracfoneProfileLocalAction.getProfileServicePlans(any(), any())).thenReturn(carrierServicePlans);
        List<TFOneCarrierServicePlan> response = tracfoneProfileController.getProfileServicePlans(DBENV, "100");
        assertEquals("[TFOneCarrierServicePlan{carrierName='null', servicePlanId='500', mktName='null', description='SAFELINK', servicePlanPurchase='null', parentName='null', servicePlans=null}]", response.toString());
    }

    @Test
    public void testGetAllCarrierIds_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).getProfileServicePlans(any(), any());
        try {
            tracfoneProfileController.getProfileServicePlans(DBENV, "100");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_GET_PROFILE_SERVICE_PLANS_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_GET_PROFILE_SERVICE_PLANS_ERROR_MESSAGE);
        }
    }

    @Test
    public void testGetRatePlanServicePlans() throws Exception {
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan servicePlan = new TFOneCarrierServicePlan();
        servicePlan.setServicePlanId("500");
        servicePlan.setDescription("SAFELINK");
        carrierServicePlans.add(servicePlan);
        when(tracfoneProfileLocalAction.getRatePlanServicePlans(any(), any())).thenReturn(carrierServicePlans);
        List<TFOneCarrierServicePlan> response = tracfoneProfileController.getRatePlanServicePlans(DBENV, "100");
        assertEquals("[TFOneCarrierServicePlan{carrierName='null', servicePlanId='500', mktName='null', description='SAFELINK', servicePlanPurchase='null', parentName='null', servicePlans=null}]", response.toString());
    }

    @Test
    public void testGetRatePlanServicePlans_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).getRatePlanServicePlans(any(), any());
        try {
            tracfoneProfileController.getRatePlanServicePlans(DBENV, "100");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_GET_RP_SERVICE_PLANS_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_GET_RP_SERVICE_PLANS_ERROR_MESSAGE);
        }
    }

    @Test
    public void testInsertAncillaryCodeConfig() throws Exception {
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        tfAncillaryCodeConfig.setDbEnv(DBENV);
        tfAncillaryCodeConfig.setExtensionObjId("SAMPLE");
        tfAncillaryCodeConfig.setProfileId("1000");
        when(tracfoneProfileLocalAction.insertAncillaryCodeConfig(any(TracfoneOneAncillaryCodeConfig.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.insertAncillaryCodeConfig(tfAncillaryCodeConfig, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfAncillaryCodeConfig.getExtensionObjId());
    }

    @Test
    public void testInsertAncillaryCodeConfig_whenException() throws Exception {
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        tfAncillaryCodeConfig.setDbEnv(DBENV);
        tfAncillaryCodeConfig.setDisplaySUIFlag("Y");
        tfAncillaryCodeConfig.setProfileId("1000");
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).insertAncillaryCodeConfig(any(TracfoneOneAncillaryCodeConfig.class), anyInt());
        try {
            tracfoneProfileController.insertAncillaryCodeConfig(tfAncillaryCodeConfig, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(tracfoneOneException.getErrorCode(), e.getErrorCode());
            assertEquals(tracfoneOneException.getErrorMessage(), e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateAncillaryCodeConfig() throws Exception {
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        tfAncillaryCodeConfig.setDbEnv(DBENV);
        tfAncillaryCodeConfig.setExtensionObjId("SAMPLE");
        tfAncillaryCodeConfig.setProfileId("1000");
        when(tracfoneProfileLocalAction.updateAncillaryCodeConfig(any(TracfoneOneAncillaryCodeConfig.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.updateAncillaryCodeConfig(tfAncillaryCodeConfig, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfAncillaryCodeConfig.getExtensionObjId());
    }

    @Test
    public void testUpdateAncillaryCodeConfig_whenException() throws Exception {
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        tfAncillaryCodeConfig.setDbEnv(DBENV);
        tfAncillaryCodeConfig.setDisplaySUIFlag("Y");
        tfAncillaryCodeConfig.setProfileId("1000");
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).updateAncillaryCodeConfig(any(TracfoneOneAncillaryCodeConfig.class), anyInt());
        try {
            tracfoneProfileController.updateAncillaryCodeConfig(tfAncillaryCodeConfig, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(tracfoneOneException.getErrorCode(), e.getErrorCode());
            assertEquals(tracfoneOneException.getErrorMessage(), e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteAncillaryCodeConfig() throws Exception {
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        tfAncillaryCodeConfig.setDbEnv(DBENV);
        tfAncillaryCodeConfig.setExtensionObjId("SAMPLE");
        tfAncillaryCodeConfig.setProfileId("1000");
        when(tracfoneProfileLocalAction.deleteAncillaryCodeConfig(any(TracfoneOneAncillaryCodeConfig.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.deleteAncillaryCodeConfig(tfAncillaryCodeConfig, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfAncillaryCodeConfig.getExtensionObjId());
    }

    @Test
    public void testDeleteAncillaryCodeConfig_whenException() throws Exception {
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        tfAncillaryCodeConfig.setDbEnv(DBENV);
        tfAncillaryCodeConfig.setDisplaySUIFlag("Y");
        tfAncillaryCodeConfig.setProfileId("1000");
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).deleteAncillaryCodeConfig(any(TracfoneOneAncillaryCodeConfig.class), anyInt());
        try {
            tracfoneProfileController.deleteAncillaryCodeConfig(tfAncillaryCodeConfig, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_ANCILLARY_CODE_CONFIG_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAncillaryCodeConfig() throws Exception {
        List<TFOneAncillaryCodeConfig> tfAncillaryCodeConfigs = new ArrayList<>();
        TFOneAncillaryCodeConfig tfOneAncillaryCodeConfig = new TFOneAncillaryCodeConfig();
        tfOneAncillaryCodeConfig.setDisplaySUIFlag("Y");
        tfOneAncillaryCodeConfig.setDisplaySUIFlag("Y");
        tfOneAncillaryCodeConfig.setProfileId("1000");
        tfOneAncillaryCodeConfig.setExtensionObjId("1000");
        tfAncillaryCodeConfigs.add(tfOneAncillaryCodeConfig);
        TracfoneOneAncillaryCodeConfig ancillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        ancillaryCodeConfig.setExtensionObjId("1000");
        ancillaryCodeConfig.setProfileId("1000");
        when(tracfoneProfileLocalAction.getAncillaryCodeConfig(any(TracfoneOneAncillaryCodeConfig.class))).thenReturn(tfAncillaryCodeConfigs);
        List<TFOneAncillaryCodeConfig> response = tracfoneProfileController.getAncillaryCodeConfig(ancillaryCodeConfig);
        assertEquals("[TFOneAncillaryCodeConfig{extensionObjId='1000', profileId='1000', featureName='null', featureValue='null', featureRequirement='null', toggleFlag='null', notes='null', restrictSUIFlag='null', displaySUIFlag='Y'}]", response.toString());
    }

    @Test
    public void testGetAncillaryCodeConfig_whenException() throws Exception {
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        tfAncillaryCodeConfig.setDbEnv(DBENV);
        tfAncillaryCodeConfig.setDisplaySUIFlag("Y");
        tfAncillaryCodeConfig.setProfileId("1000");
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).getAncillaryCodeConfig(any(TracfoneOneAncillaryCodeConfig.class));
        try {
            tracfoneProfileController.getAncillaryCodeConfig(tfAncillaryCodeConfig);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ANCILLARY_CODE_CONFIG_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertAncillaryCodeDiscount() throws Exception {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("SAMPLE");
        tfAncillaryCodeDiscount.setNewBrmEquivalent("NEW_BRM_EQUIVALENT");
        when(tracfoneProfileLocalAction.insertAncillaryCodeDiscount(any(TracfoneOneAncillaryCodeDiscount.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.insertAncillaryCodeDiscount(tfAncillaryCodeDiscount, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfAncillaryCodeDiscount.getAncillaryCode());
    }

    @Test
    public void testInsertAncillaryCodeDiscount_whenException() throws Exception {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        tfAncillaryCodeDiscount.setNewBrmEquivalent("NEW_BRM_EQUIVALENT");
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).insertAncillaryCodeDiscount(any(TracfoneOneAncillaryCodeDiscount.class), anyInt());
        try {
            tracfoneProfileController.insertAncillaryCodeDiscount(tfAncillaryCodeDiscount, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_ANCILLARY_CODE_DISCOUNT_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateAncillaryCodeDiscount() throws Exception {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("SAMPLE");
        tfAncillaryCodeDiscount.setNewBrmEquivalent("NEW_BRM_EQUIVALENT");
        when(tracfoneProfileLocalAction.updateAncillaryCodeDiscount(any(TracfoneOneAncillaryCodeDiscount.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.updateAncillaryCodeDiscount(tfAncillaryCodeDiscount, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfAncillaryCodeDiscount.getAncillaryCode());
    }

    @Test
    public void testUpdateAncillaryCodeDiscount_whenException() throws Exception {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        tfAncillaryCodeDiscount.setNewBrmEquivalent("NEW_BRM_EQUIVALENT");
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).updateAncillaryCodeDiscount(any(TracfoneOneAncillaryCodeDiscount.class), anyInt());
        try {
            tracfoneProfileController.updateAncillaryCodeDiscount(tfAncillaryCodeDiscount, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_ANCILLARY_CODE_DISCOUNT_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteAncillaryCodeDiscountDeleteTrue() throws Exception {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("SAMPLE");
        tfAncillaryCodeDiscount.setDelete(true);
        when(tracfoneProfileLocalAction.deleteAncillaryCodeDiscount(any(TracfoneOneAncillaryCodeDiscount.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.deleteAncillaryCodeDiscount(tfAncillaryCodeDiscount, 1000);
        assertEquals(tFOneGeneralResponse.getStatus(), response.getStatus());
        assertEquals(response.getMessage(), tfAncillaryCodeDiscount.getAncillaryCode());
    }

    @Test
    public void testDeleteAncillaryCodeDiscountDeleteFalse() throws Exception {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("0");
        tfAncillaryCodeDiscount.setDelete(false);
        long totalAssociatedProfiles = 5;
        when(tracfoneProfileLocalAction.checkAncillaryCodeDiscountDependencies(any(TracfoneOneAncillaryCodeDiscount.class))).thenReturn(totalAssociatedProfiles);
        TFOneGeneralResponse response = tracfoneProfileController.deleteAncillaryCodeDiscount(tfAncillaryCodeDiscount, 1000);
        assertEquals("Success", response.getStatus());
        assertEquals(String.valueOf(totalAssociatedProfiles), response.getMessage());
    }

    @Test
    public void testDeleteAncillaryCodeDiscount_whenException() throws Exception {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("SAMPLE");
        tfAncillaryCodeDiscount.setDelete(true);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).deleteAncillaryCodeDiscount(any(TracfoneOneAncillaryCodeDiscount.class), anyInt());
        try {
            tracfoneProfileController.deleteAncillaryCodeDiscount(tfAncillaryCodeDiscount, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_ANCILLARY_CODE_DISCOUNT_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchAncillaryCodeDiscount() throws Exception {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("SAMPLE");
        List<TFOneAncillaryCodeDiscount> tfAncillaryCodeDiscounts = new ArrayList<>();
        TFOneAncillaryCodeDiscount tfOneAncillaryCodeDiscount = new TFOneAncillaryCodeDiscount();
        tfOneAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        tfAncillaryCodeDiscounts.add(tfOneAncillaryCodeDiscount);
        when(tracfoneProfileLocalAction.searchAncillaryCodeDiscount(any(TracfoneOneAncillaryCodeDiscount.class))).thenReturn(tfAncillaryCodeDiscounts);
        List<TFOneAncillaryCodeDiscount> response = tracfoneProfileController.searchAncillaryCodeDiscount(tfAncillaryCodeDiscount);
        assertEquals("[TFOneAncillaryCodeDiscount{ancillaryCode='ANCILLARY_CODE', brmEquivalent='null'}]", response.toString());
    }

    @Test
    public void testSearchAncillaryCodeDiscount_whenException() throws Exception {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).searchAncillaryCodeDiscount(any(TracfoneOneAncillaryCodeDiscount.class));
        try {
            tracfoneProfileController.searchAncillaryCodeDiscount(tfAncillaryCodeDiscount);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_ANCILLARY_CODE_DISCOUNT_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteLineStatusCode() throws Exception {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DBENV);
        tfOneLineStatus.setLineStatusCode("SAMPLE");
        when(tracfoneProfileLocalAction.deleteLineStatusCode(any(TracfoneOneLineStatusCode.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.deleteLineStatusCode(tfOneLineStatus, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfOneLineStatus.getLineStatusCode());
    }

    @Test
    public void testDeleteLineStatusCode_whenCheckAncillaryCodeDependencyIsTrue() throws Exception {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DBENV);
        tfOneLineStatus.setLineStatusCode("LINE_STATUS_CODE");
        when(tracfoneProfileLocalAction.checkRpExtensionCodeDependencies(any(TracfoneOneRatePlanExtension.class))).thenReturn(true);
        try {
            tracfoneProfileController.deleteLineStatusCode(tfOneLineStatus, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ANCILLARY_CODE_DEPENDENCY_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ANCILLARY_CODE_DEPENDENCY_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteLineStatusCode_whenException() throws Exception {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DBENV);
        tfOneLineStatus.setLineStatusCode("LINE_STATUS_CODE");
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).deleteLineStatusCode(any(TracfoneOneLineStatusCode.class), anyInt());
        try {
            tracfoneProfileController.deleteLineStatusCode(tfOneLineStatus, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_LINE_STATUS_CODE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_LINE_STATUS_CODE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteThrottleStatusCode() throws Exception {
        TracfoneOneThrottleStatusCode tfOneThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfOneThrottleStatusCode.setThrottleStatusCode("SAMPLE");
        tfOneThrottleStatusCode.setDbEnv(DBENV);
        when(tracfoneProfileLocalAction.deleteThrottleStatusCode(any(TracfoneOneThrottleStatusCode.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.deleteThrottleStatusCode(tfOneThrottleStatusCode, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfOneThrottleStatusCode.getThrottleStatusCode());
    }

    @Test
    public void testDeleteThrottleStatusCode_whenCheckAncillaryCodeDependencyIsTrue() throws Exception {
        TracfoneOneThrottleStatusCode tfOneThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfOneThrottleStatusCode.setThrottleStatusCode("SAMPLE");
        tfOneThrottleStatusCode.setDbEnv(DBENV);
        when(tracfoneProfileLocalAction.checkRpExtensionCodeDependencies(any(TracfoneOneRatePlanExtension.class))).thenReturn(true);
        try {
            tracfoneProfileController.deleteThrottleStatusCode(tfOneThrottleStatusCode, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ANCILLARY_CODE_DEPENDENCY_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ANCILLARY_CODE_DEPENDENCY_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteThrottleStatusCode_whenException() throws Exception {
        TracfoneOneThrottleStatusCode tfOneThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfOneThrottleStatusCode.setThrottleStatusCode("SAMPLE");
        tfOneThrottleStatusCode.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).deleteThrottleStatusCode(any(TracfoneOneThrottleStatusCode.class), anyInt());
        try {
            tracfoneProfileController.deleteThrottleStatusCode(tfOneThrottleStatusCode, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_THROTTLE_STATUS_CODE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_THROTTLE_STATUS_CODE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertMultiRatePlanEsns() throws Exception {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsns.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsns.setDelFlag("ESN");
        tracfoneOneMultiRatePlanEsns.setxServicePlanId("SAMPLE");
        when(tracfoneProfileLocalAction.insertMultiRatePlanEsn(any(), anyInt(), any())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.insertMultiRatePlanEsn(tracfoneOneMultiRatePlanEsns, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneMultiRatePlanEsns.getxServicePlanId());
    }

    @Test
    public void testInsertMultiRatePlanEsns_whenException() throws Exception {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsns.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsns.setDelFlag("ESN");
        tracfoneOneMultiRatePlanEsns.setxServicePlanId("185");
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).insertMultiRatePlanEsn(any(), anyInt(), any());
        try {
            tracfoneProfileController.insertMultiRatePlanEsn(tracfoneOneMultiRatePlanEsns, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_MULTI_RATE_PLAN_ESNS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateMultiRatePlanEsns() throws Exception {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsns.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsns.setDelFlag("ESN");
        tracfoneOneMultiRatePlanEsns.setxServicePlanId("SAMPLE");
        when(tracfoneProfileLocalAction.updateMultiRatePlanEsn(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.updateMultiRatePlanEsn(tracfoneOneMultiRatePlanEsns, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneMultiRatePlanEsns.getxServicePlanId());
    }

    @Test
    public void testUpdateMultiRatePlanEsns_whenException() throws Exception {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsns.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsns.setDelFlag("ESN");
        tracfoneOneMultiRatePlanEsns.setxServicePlanId("185");
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).updateMultiRatePlanEsn(any(), anyInt());
        try {
            tracfoneProfileController.updateMultiRatePlanEsn(tracfoneOneMultiRatePlanEsns, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_MULTI_RATE_PLAN_ESNS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteMultiRatePlanEsns() throws Exception {
        List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsns = new ArrayList<>();
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsn.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsn.setDelFlag("ESN");
        tracfoneOneMultiRatePlanEsn.setxServicePlanId("SAMPLE");
        tracfoneOneMultiRatePlanEsns.add(tracfoneOneMultiRatePlanEsn);
        when(tracfoneProfileLocalAction.deleteMultiRatePlanEsn(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneProfileController.deleteMultiRatePlanEsn(tracfoneOneMultiRatePlanEsns, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneMultiRatePlanEsn.getxServicePlanId());
    }

    @Test
    public void testDeleteMultiRatePlanEsns_whenException() throws Exception {
        List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsns = new ArrayList<>();
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsn.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsn.setDelFlag("ESN");
        tracfoneOneMultiRatePlanEsn.setxServicePlanId("185");
        tracfoneOneMultiRatePlanEsns.add(tracfoneOneMultiRatePlanEsn);
        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).deleteMultiRatePlanEsn(any(), anyInt());
        try {
            tracfoneProfileController.deleteMultiRatePlanEsn(tracfoneOneMultiRatePlanEsns, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_MULTI_RATE_PLAN_ESNS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchMultiRatePlanEsns() throws Exception {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsns.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsns.setDelFlag("ESN");
        tracfoneOneMultiRatePlanEsns.setxServicePlanId("SAMPLE");

        List<TFOneMultiRatePlanEsn> tfOneMultiRatePlanEsnss = new ArrayList<>();
        TFOneMultiRatePlanEsn tfOneMultiRatePlanEsns = new TFOneMultiRatePlanEsn();
        tfOneMultiRatePlanEsns.setxReason("REASON");
        tfOneMultiRatePlanEsns.setxServicePlanId("185");
        tfOneMultiRatePlanEsnss.add(tfOneMultiRatePlanEsns);

        when(tracfoneProfileLocalAction.searchMultiRatePlanEsns(any())).thenReturn(tfOneMultiRatePlanEsnss);
        List<TFOneMultiRatePlanEsn> response = tracfoneProfileController.searchMultiRatePlanEsns(tracfoneOneMultiRatePlanEsns);
        assertEquals("[TFOneMultiRatePlanEsns{xEsn='null', xPrority='null', xServicePlanId='185', xDateAdded='null', xReason='REASON', delFlag='null', xProductId='null'}]", response.toString());
    }

    @Test
    public void testSearchMultiRatePlanEsns_whenException() throws Exception {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsns.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsns.setDelFlag("ESN");
        tracfoneOneMultiRatePlanEsns.setxServicePlanId("185");

        doThrow(tracfoneOneException).when(tracfoneProfileLocalAction).searchMultiRatePlanEsns(any());
        try {
            tracfoneProfileController.searchMultiRatePlanEsns(tracfoneOneMultiRatePlanEsns);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_MULTI_RATE_PLAN_ESNS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}