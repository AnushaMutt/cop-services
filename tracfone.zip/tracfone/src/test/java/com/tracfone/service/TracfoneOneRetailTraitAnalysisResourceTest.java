package com.tracfone.service;

import com.tracfone.service.controller.retail.TracfoneOneRetailAdminActionLocal;
import com.tracfone.service.controller.retail.TracfoneOneRetailStoreControllerLocal;
import com.tracfone.service.controller.retail.TracfoneOneRetailTraitActionLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.retail.request.TracfoneOneRetailLocation;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTraitSearchModel;
import com.tracfone.service.model.retail.response.TFOneRetailBrand;
import com.tracfone.service.model.retail.response.TFOneRetailCarrier;
import com.tracfone.service.model.retail.response.TFOneRetailLocation;
import com.tracfone.service.model.retail.response.TFOneRetailMaster;
import com.tracfone.service.model.retail.response.TFOneRetailParent;
import com.tracfone.service.model.retail.response.TFOneTraitDetail;
import com.tracfone.service.model.retail.response.TracfoneOneRetailAvailability;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneRetailTraitAnalysisResourceTest {
    public final String JSON = "application/json";
    @InjectMocks
    private TracfoneOneRetailTraitAnalysisResource retailTraitAnalysisResource;

    @Mock
    private TracfoneOneRetailTraitActionLocal tracfoneOneRetailTraitAction;

    @Mock
    private TracfoneOneRetailAdminActionLocal tracfoneOneRetailAdminAction;

    @Mock
    private TracfoneOneRetailStoreControllerLocal tracfoneOneRetailStoreController;

    @Mock
    private SecurityContext securityContext;
    @Mock
    private TracfoneOnePrincipal principal;
    @Mock
    private TFOneAdminUser user;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    @Before
    public void setUp() {
        initMocks(this);
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
        when(securityContext.getUserPrincipal()).thenReturn(principal);
        when(principal.getTFUser()).thenReturn(user);
    }

    @Test
    public void testGetBrands() throws TracfoneOneException {
        List<TFOneRetailBrand> tfOneCRtlBrands = new ArrayList<>();
        TFOneRetailBrand tfOneCRtlBrand = new TFOneRetailBrand();
        tfOneCRtlBrand.setObjId("100");
        tfOneCRtlBrands.add(tfOneCRtlBrand);
        when(tracfoneOneRetailAdminAction.getBrands()).thenReturn(tfOneCRtlBrands);
        Response response = retailTraitAnalysisResource.getBrands();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"100\",\"oneSecUserId\":null,\"status\":null,\"brand\":null,\"brandLong\":null,\"insertDate\":null,\"updateDate\":null,\"cRtlTraitLogicRuleId\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetParents() throws TracfoneOneException {
        List<TFOneRetailParent> tfOneRetailParents = new ArrayList<>();
        TFOneRetailParent tfOneRetailParent = new TFOneRetailParent();
        tfOneRetailParent.setObjId("1000");
        tfOneRetailParent.setRetailer("REATAILER");
        tfOneRetailParent.setSecUserId("1000");
        tfOneRetailParent.setStatus("STATUS");
        tfOneRetailParents.add(tfOneRetailParent);
        when(tracfoneOneRetailAdminAction.getParents()).thenReturn(tfOneRetailParents);
        Response response = retailTraitAnalysisResource.getParents();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"status\":\"STATUS\",\"retailer\":\"REATAILER\",\"secUserId\":\"1000\",\"insertDate\":null,\"updateDate\":null,\"lastTraitRunDate\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetParents_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getParents();
        Response response = retailTraitAnalysisResource.getParents();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1407-Unable to get all Parents\"}", response.getEntity().toString());
    }

    @Test
    public void testGetBrands_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getBrands();
        Response response = retailTraitAnalysisResource.getBrands();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1401-Unable to get all Brand\"}", response.getEntity().toString());
    }

    @Test
    public void testGetCarriers() throws TracfoneOneException {
        List<TFOneRetailCarrier> tfCRtlCarriers = new ArrayList<>();
        TFOneRetailCarrier tfOneCRtlCarrier = new TFOneRetailCarrier();
        tfOneCRtlCarrier.setObjId("100");
        tfCRtlCarriers.add(tfOneCRtlCarrier);
        when(tracfoneOneRetailAdminAction.getCarriers()).thenReturn(tfCRtlCarriers);
        Response response = retailTraitAnalysisResource.getCarriers();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"100\",\"secUserId\":null,\"status\":null,\"carrier\":null,\"carrierLong\":null,\"insertDate\":null,\"updateDate\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarriers_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getCarriers();
        Response response = retailTraitAnalysisResource.getCarriers();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1400-Unable to get all Carrier\"}", response.getEntity().toString());
    }

    @Test
    public void testGetMasters() throws TracfoneOneException {
        List<TFOneRetailMaster> tfOneRetailMasters = new ArrayList<>();
        TFOneRetailMaster tfOneRetailMaster = new TFOneRetailMaster();
        tfOneRetailMaster.setMaster2Parent("1000");
        tfOneRetailMaster.setObjId("1000");
        tfOneRetailMaster.setSecUserId("1000");
        tfOneRetailMaster.setStatus("STATUS");
        tfOneRetailMaster.setStoreName("STORE_NAME");
        tfOneRetailMasters.add(tfOneRetailMaster);
        when(tracfoneOneRetailAdminAction.getMasters(any())).thenReturn(tfOneRetailMasters);
        Response response = retailTraitAnalysisResource.getMasters("1000");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"status\":\"STATUS\",\"storeName\":\"STORE_NAME\",\"master2Parent\":\"1000\",\"secUserId\":\"1000\",\"insertDate\":null,\"updateDate\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetMasters_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getMasters(any());
        Response response = retailTraitAnalysisResource.getMasters("1000");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1408-Unable to get all Masters\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchRetailLocations() throws TracfoneOneException {
        List<TFOneRetailLocation> retailMasters = new ArrayList<>();
        TFOneRetailLocation retailMaster = new TFOneRetailLocation();
        retailMaster.setRadius("15");
        retailMaster.setBrand("BRAND");
        retailMaster.setState("STATE");
        retailMaster.setStoreName("STORE_NAME");
        retailMaster.setStoreNum("STORE_NUM");
        retailMaster.setZip("00900");
        retailMasters.add(retailMaster);

        TracfoneOneRetailTraitSearchModel tracfoneOneSearchRetailTraitModel = new TracfoneOneRetailTraitSearchModel();
        tracfoneOneSearchRetailTraitModel.setBrand("BRAND");
        tracfoneOneSearchRetailTraitModel.setParentId("15");
        tracfoneOneSearchRetailTraitModel.setZips("12345");
        when(tracfoneOneRetailTraitAction.searchRetailLocations(any())).thenReturn(retailMasters);
        Response response = retailTraitAnalysisResource.searchRetailLocations(tracfoneOneSearchRetailTraitModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"masterId\":null,\"parentId\":null,\"storeName\":\"STORE_NAME\",\"storeNum\":\"STORE_NUM\",\"zip\":\"00900\",\"brand\":\"BRAND\",\"radius\":\"15\",\"state\":\"STATE\",\"lastUpdateDate\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchRetailLocations_whenException() throws TracfoneOneException {
        TracfoneOneRetailTraitSearchModel tracfoneOneSearchRetailTraitModel = new TracfoneOneRetailTraitSearchModel();
        tracfoneOneSearchRetailTraitModel.setBrand("BRAND");
        tracfoneOneSearchRetailTraitModel.setParentId("15");
        doThrow(tracfoneOneException).when(tracfoneOneRetailTraitAction).searchRetailLocations(any());
        Response response = retailTraitAnalysisResource.searchRetailLocations(tracfoneOneSearchRetailTraitModel);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1430-Unable to search for Retail Locations\"}", response.getEntity().toString());
    }

    @Test
    public void testOpenStores() throws TracfoneOneException {
        List<TracfoneOneRetailLocation> tfOneRetailLocations = new ArrayList<>();
        TracfoneOneRetailLocation tfOneRetailLocation = new TracfoneOneRetailLocation();
        tfOneRetailLocation.setZip("330101");
        tfOneRetailLocation.setRadius("56");
        tfOneRetailLocation.setStoreName("DOLLAR EXPRESS");
        tfOneRetailLocation.setStoreNum("5827");
        tfOneRetailLocations.add(tfOneRetailLocation);

        when(tracfoneOneRetailStoreController.openStores(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailTraitAnalysisResource.openStores(tfOneRetailLocations);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testOpenStore_whenException() throws TracfoneOneException {
        List<TracfoneOneRetailLocation> tfOneRetailLocations = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneOneRetailStoreController).openStores(any(), anyInt());
        Response response = retailTraitAnalysisResource.openStores(tfOneRetailLocations);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1429-Unable to open Stores\"}", response.getEntity().toString());
    }

    @Test
    public void testCloseStores() throws TracfoneOneException {
        when(tracfoneOneRetailTraitAction.closeStores(any(), anyString(), anyInt())).thenReturn(tFOneGeneralResponse);
        TracfoneOneRetailLocation tfOneRetailLocation = new TracfoneOneRetailLocation();
        tfOneRetailLocation.setObjIds("57");
        tfOneRetailLocation.setParentId("57");
        Response response = retailTraitAnalysisResource.closeStores(tfOneRetailLocation);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testCloseStores_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailTraitAction).closeStores(any(), anyString(), anyInt());
        TracfoneOneRetailLocation tfOneRetailLocation = new TracfoneOneRetailLocation();
        tfOneRetailLocation.setObjIds("57");
        tfOneRetailLocation.setParentId("57");
        Response response = retailTraitAnalysisResource.closeStores(tfOneRetailLocation);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1428-Unable to close Stores\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteStores() throws TracfoneOneException {
        when(tracfoneOneRetailTraitAction.deleteStores(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TracfoneOneRetailLocation tfOneRetailLocation = new TracfoneOneRetailLocation();
        tfOneRetailLocation.setObjIds("57");
        Response response = retailTraitAnalysisResource.deleteStores(tfOneRetailLocation);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteStores_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailTraitAction).deleteStores(any(), anyInt());
        TracfoneOneRetailLocation tfOneRetailLocation = new TracfoneOneRetailLocation();
        tfOneRetailLocation.setObjIds("57");
        Response response = retailTraitAnalysisResource.deleteStores(tfOneRetailLocation);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1436-Unable to delete Stores\"}", response.getEntity().toString());
    }

    @Test
    public void testReopenStores() throws TracfoneOneException {
        TracfoneOneRetailLocation tracfoneOneRetailLocation = new TracfoneOneRetailLocation();
        tracfoneOneRetailLocation.setObjIds("1,2,3");
        tracfoneOneRetailLocation.setParentId("1");
        when(tracfoneOneRetailTraitAction.reopenStores(any(), anyString(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailTraitAnalysisResource.reopenStores(tracfoneOneRetailLocation);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testReOpenStores_whenException() throws TracfoneOneException {
        TracfoneOneRetailLocation tracfoneOneRetailLocation = new TracfoneOneRetailLocation();
        tracfoneOneRetailLocation.setParentId("1");
        tracfoneOneRetailLocation.setObjIds("1");
        doThrow(tracfoneOneException).when(tracfoneOneRetailTraitAction).reopenStores(any(), anyString(), anyInt());
        Response response = retailTraitAnalysisResource.reopenStores(tracfoneOneRetailLocation);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1434-Unable to reopen Stores\"}", response.getEntity().toString());
    }

    @Test
    public void testGetTraitDetails() throws TracfoneOneException {
        List<TFOneTraitDetail> traitDetails = new ArrayList<>();
        TFOneTraitDetail traitDetail = new TFOneTraitDetail();
        traitDetail.setBrand("BRAND");
        traitDetail.setBufferZips("1000");
        traitDetail.setCarrier("CARRIER");
        traitDetail.setDplyd("1");
        traitDetail.setExtPercDplyd("1");
        traitDetail.setExtPercPopDplyd("1");
        traitDetail.setExtPopDplyd("1");
        traitDetail.setExtZipDplyd("1");
        traitDetail.setPercPopDplyd("1");
        traitDetail.setPercZipDplyd("1");
        traitDetail.setPop("1");
        traitDetail.setPopDplyd("1");
        traitDetail.setRadius("10");
        traitDetail.setTech("TECH");
        traitDetail.setTraits("10");
        traitDetail.setZipsDplyd("1");
        traitDetails.add(traitDetail);
        when(tracfoneOneRetailTraitAction.getTraitDetails(anyString())).thenReturn(traitDetails);
        Response response = retailTraitAnalysisResource.getTraitDetails("100");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"radius\":\"10\",\"traits\":\"10\",\"brand\":\"BRAND\",\"carrier\":\"CARRIER\",\"tech\":\"TECH\",\"dplyd\":\"1\",\"bufferZips\":\"1000\",\"pop\":\"1\",\"zipsDplyd\":\"1\",\"percZipDplyd\":\"1\",\"popDplyd\":\"1\",\"percPopDplyd\":\"1\",\"extZipDplyd\":\"1\",\"extPercDplyd\":\"1\",\"extPopDplyd\":\"1\",\"extPercPopDplyd\":\"1\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetTraitDetails_whenException() throws TracfoneOneException {
        doThrow(RuntimeException.class).when(tracfoneOneRetailTraitAction).getTraitDetails(anyString());
        Response response = retailTraitAnalysisResource.getTraitDetails("100");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1435-Unable to get Trait Details for the Location\"}", response.getEntity().toString());
    }

    @Test
    public void testGetRadius() throws TracfoneOneException {
        List<String> radius = new ArrayList<>();
        radius.add("56");
        radius.add("75");
        when(tracfoneOneRetailTraitAction.getRadius()).thenReturn(radius);
        Response response = retailTraitAnalysisResource.getRadius();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[\"56\",\"75\"]", response.getEntity().toString());
    }

    @Test
    public void testGetRadius_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailTraitAction).getRadius();
        Response response = retailTraitAnalysisResource.getRadius();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1438-Unable to get all Radius\"}", response.getEntity().toString());
    }

    @Test
    public void testViewAvailability() throws TracfoneOneException {
        List<TracfoneOneRetailAvailability> availabilities = new ArrayList<>();
        TracfoneOneRetailAvailability retailAvailability = new TracfoneOneRetailAvailability();
        retailAvailability.setBrand("NT");
        retailAvailability.setRadius("15");
        retailAvailability.setState("AK");
        retailAvailability.setZip("12345");
        retailAvailability.setRetailer("WALLMART");
        retailAvailability.setStoreName("BUCKY'S");
        retailAvailability.setStoreNum("1234");
        availabilities.add(retailAvailability);

        TracfoneOneRetailTraitSearchModel retailTraitSearchModel = new TracfoneOneRetailTraitSearchModel();
        retailTraitSearchModel.setObjIds("10000");
        when(tracfoneOneRetailTraitAction.viewAvailability(any())).thenReturn(availabilities);
        Response response = retailTraitAnalysisResource.viewAvailability(retailTraitSearchModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"retailer\":\"WALLMART\",\"storeName\":\"BUCKY\\u0027S\",\"storeNum\":\"1234\",\"zip\":\"12345\",\"state\":\"AK\",\"brand\":\"NT\",\"radius\":\"15\",\"carrierTechs\":{}}]", response.getEntity().toString());
    }

    @Test
    public void testViewAvailability_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailTraitAction).viewAvailability(any());
        TracfoneOneRetailTraitSearchModel retailTraitSearchModel = new TracfoneOneRetailTraitSearchModel();
        Response response = retailTraitAnalysisResource.viewAvailability(retailTraitSearchModel);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1427-Unable to view Availability\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateRetailLocationRadius() throws TracfoneOneException {
        List<TracfoneOneRetailLocation> tfOneRetailLocations = new ArrayList<>();
        TracfoneOneRetailLocation tfOneRetailLocation = new TracfoneOneRetailLocation();
        tfOneRetailLocation.setZip("330101");
        tfOneRetailLocation.setRadius("56");
        tfOneRetailLocation.setStoreName("DOLLAR EXPRESS");
        tfOneRetailLocation.setStoreNum("5827");
        tfOneRetailLocations.add(tfOneRetailLocation);

        when(tracfoneOneRetailStoreController.updateRetailLocationRadius(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailTraitAnalysisResource.updateRetailLocationRadius(tfOneRetailLocations);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateRetailLocationRadius_withException() throws TracfoneOneException {
        List<TracfoneOneRetailLocation> tfOneRetailLocations = new ArrayList<>();
        TracfoneOneRetailLocation tfOneRetailLocation = new TracfoneOneRetailLocation();
        tfOneRetailLocation.setZip("330101");
        tfOneRetailLocation.setRadius("56");
        tfOneRetailLocation.setStoreName("DOLLAR EXPRESS");
        tfOneRetailLocation.setStoreNum("5827");
        tfOneRetailLocations.add(tfOneRetailLocation);

        doThrow(tracfoneOneException).when(tracfoneOneRetailStoreController).updateRetailLocationRadius(any(), anyInt());
        Response response = retailTraitAnalysisResource.updateRetailLocationRadius(tfOneRetailLocations);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE1431-Unable to update radius for Retail Locations\"}", response.getEntity().toString());
    }

    @Test
    public void testAnalyseTraits() throws TracfoneOneException {
        TracfoneOneRetailTraitSearchModel tracfoneOneSearchRetailTraitModel = new TracfoneOneRetailTraitSearchModel();
        tracfoneOneSearchRetailTraitModel.setBrand("BRAND");
        tracfoneOneSearchRetailTraitModel.setObjIds("15");
        tracfoneOneSearchRetailTraitModel.setZips("12345");

        Map<String, String> traitAnalysis = new HashMap<>();
        traitAnalysis.put("15", "[ATT_PREF]");
        when(tracfoneOneRetailTraitAction.analyseTraits(any(), anyInt())).thenReturn(traitAnalysis);
        Response response = retailTraitAnalysisResource.analyseTraits(tracfoneOneSearchRetailTraitModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"15\":\"[ATT_PREF]\"}", response.getEntity().toString());
    }

    @Test
    public void testAnalyseTraits_withException() throws TracfoneOneException {
        TracfoneOneRetailTraitSearchModel tracfoneOneSearchRetailTraitModel = new TracfoneOneRetailTraitSearchModel();

        doThrow(tracfoneOneException).when(tracfoneOneRetailTraitAction).analyseTraits(any(), anyInt());
        Response response = retailTraitAnalysisResource.analyseTraits(tracfoneOneSearchRetailTraitModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE1439-Unable to analyse Traits\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchClosedStores() throws TracfoneOneException {
        List<TFOneRetailLocation> retailMasters = new ArrayList<>();
        TFOneRetailLocation retailMaster = new TFOneRetailLocation();
        retailMaster.setRadius("15");
        retailMaster.setBrand("BRAND");
        retailMaster.setState("STATE");
        retailMaster.setStoreName("STORE_NAME");
        retailMaster.setStoreNum("STORE_NUM");
        retailMaster.setZip("00900");
        retailMasters.add(retailMaster);

        TracfoneOneRetailTraitSearchModel tracfoneOneSearchRetailTraitModel = new TracfoneOneRetailTraitSearchModel();
        tracfoneOneSearchRetailTraitModel.setBrand("BRAND");
        tracfoneOneSearchRetailTraitModel.setParentId("15");
        tracfoneOneSearchRetailTraitModel.setZips("12345");
        when(tracfoneOneRetailTraitAction.searchClosedStores(any())).thenReturn(retailMasters);
        Response response = retailTraitAnalysisResource.searchClosedStores(tracfoneOneSearchRetailTraitModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"masterId\":null,\"parentId\":null,\"storeName\":\"STORE_NAME\",\"storeNum\":\"STORE_NUM\",\"zip\":\"00900\",\"brand\":\"BRAND\",\"radius\":\"15\",\"state\":\"STATE\",\"lastUpdateDate\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchClosedStores_whenException() throws TracfoneOneException {
        TracfoneOneRetailTraitSearchModel tracfoneOneSearchRetailTraitModel = new TracfoneOneRetailTraitSearchModel();
        tracfoneOneSearchRetailTraitModel.setBrand("BRAND");
        tracfoneOneSearchRetailTraitModel.setParentId("15");
        doThrow(tracfoneOneException).when(tracfoneOneRetailTraitAction).searchClosedStores(any());
        Response response = retailTraitAnalysisResource.searchClosedStores(tracfoneOneSearchRetailTraitModel);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1440-Unable to search for Closed Stores\"}", response.getEntity().toString());
    }


    @Test
    public void testGetLastTraitRunDate() throws TracfoneOneException {
        String endRun = "2020/09/09";
        when(tracfoneOneRetailAdminAction.getLastTraitRunDate(anyString())).thenReturn(endRun);
        Response response = retailTraitAnalysisResource.getLastTraitRunDate("571");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"Success\",\"message\":\"2020/09/09\"}", response.getEntity().toString());
    }

    @Test
    public void testGetLastTraitRunDate_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getLastTraitRunDate(anyString());
        Response response = retailTraitAnalysisResource.getLastTraitRunDate("571");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1441-Unable to get last Trait run Date\"}", response.getEntity().toString());
    }


    @Test
    public void testRunStoreTraits() throws TracfoneOneException {
        TracfoneOneRetailLocation tracfoneOneRetailLocation = new TracfoneOneRetailLocation();
        tracfoneOneRetailLocation.setObjIds("122");
        tracfoneOneRetailLocation.setStoreNum("122332");
        when(tracfoneOneRetailAdminAction.runStoreTraits(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailTraitAnalysisResource.runStoreTraits(tracfoneOneRetailLocation);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testRunStoreTraits_whenException() throws TracfoneOneException {
        TracfoneOneRetailLocation tracfoneOneRetailLocation = new TracfoneOneRetailLocation();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).runStoreTraits(any(), anyInt());
        Response response = retailTraitAnalysisResource.runStoreTraits(tracfoneOneRetailLocation);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE1442-Unable to Run Store Trait\"}", response.getEntity().toString());
    }

    @Test
    public void testCountStores() throws TracfoneOneException {
        when(tracfoneOneRetailTraitAction.countStores(anyString(), anyInt())).thenReturn(tFOneGeneralResponse);
        TracfoneOneRetailLocation tfOneRetailLocation = new TracfoneOneRetailLocation();
        tfOneRetailLocation.setObjIds("57");
        tfOneRetailLocation.setParentId("57");
        Response response = retailTraitAnalysisResource.countStores(tfOneRetailLocation);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testCountStores_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailTraitAction).countStores(anyString(), anyInt());
        TracfoneOneRetailLocation tfOneRetailLocation = new TracfoneOneRetailLocation();
        tfOneRetailLocation.setObjIds("57");
        tfOneRetailLocation.setParentId("57");
        Response response = retailTraitAnalysisResource.countStores(tfOneRetailLocation);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1445-Unable to count Stores\"}", response.getEntity().toString());
    }
}