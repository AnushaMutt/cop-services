package com.tracfone.service;

import com.tracfone.service.controller.TracfoneCarrierMaintenanceControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.controller.TracfoneRatePlanControllerLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneArUsaMarket;
import com.tracfone.service.model.request.TracfoneOneArUsaPostalZips;
import com.tracfone.service.model.request.TracfoneOneCarrier;
import com.tracfone.service.model.request.TracfoneOneCarrierGroup;
import com.tracfone.service.model.request.TracfoneOneCarrierPref;
import com.tracfone.service.model.request.TracfoneOneCarrierRule;
import com.tracfone.service.model.request.TracfoneOneCarrierSimPref;
import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;
import com.tracfone.service.model.request.TracfoneOneDataConfig;
import com.tracfone.service.model.request.TracfoneOneDataConfigMapping;
import com.tracfone.service.model.request.TracfoneOneGeoLoc;
import com.tracfone.service.model.request.TracfoneOneIgOrderType;
import com.tracfone.service.model.request.TracfoneOneNotCertifyModel;
import com.tracfone.service.model.request.TracfoneOneNpanxx2Carrierzones;
import com.tracfone.service.model.request.TracfoneOneOrderType;
import com.tracfone.service.model.request.TracfoneOneParent;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneThrottleFeature;
import com.tracfone.service.model.request.TracfoneOneThrottlePolicy;
import com.tracfone.service.model.request.TracfoneOneThrottleRule;
import com.tracfone.service.model.request.TracfoneOneTmoZipNgp;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.request.TracfoneOneVerizonZipNPANXX;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneArUsaMarket;
import com.tracfone.service.model.response.TFOneArUsaMarketSearchResult;
import com.tracfone.service.model.response.TFOneArUsaPostalZips;
import com.tracfone.service.model.response.TFOneBulkInsertReport;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierGroup;
import com.tracfone.service.model.response.TFOneCarrierPref;
import com.tracfone.service.model.response.TFOneCarrierRule;
import com.tracfone.service.model.response.TFOneCarrierZones;
import com.tracfone.service.model.response.TFOneCarriersimpref;
import com.tracfone.service.model.response.TFOneCingularMrktInfo;
import com.tracfone.service.model.response.TFOneDataConfig;
import com.tracfone.service.model.response.TFOneDataConfigMapping;
import com.tracfone.service.model.response.TFOneDatabaseEnvironment;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneGeoLoc;
import com.tracfone.service.model.response.TFOneIgOrderType;
import com.tracfone.service.model.response.TFOneNotCertifyModel;
import com.tracfone.service.model.response.TFOneNpaNxx2CarrierZonesSearchResult;
import com.tracfone.service.model.response.TFOneNpanxx2Carrierzones;
import com.tracfone.service.model.response.TFOneOrderType;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOnePartClass;
import com.tracfone.service.model.response.TFOneThrottleFeature;
import com.tracfone.service.model.response.TFOneThrottlePolicy;
import com.tracfone.service.model.response.TFOneThrottleRule;
import com.tracfone.service.model.response.TFOneTmoZipNgp;
import com.tracfone.service.model.response.TFOneVerizonZipNPANXX;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Testing the services that are associated with Carrier Maintenance Wizard.
 *
 * @author Pritesh Singh
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneCarrierWizardResourceTest {

    public final String JSON = "application/json";
    public final String DBENV = "dbEnv";

    @InjectMocks
    private TracfoneOneCarrierWizardResource tracfoneOneCarrierWizardResource;

    @Mock
    private TracfoneCarrierMaintenanceControllerLocal tracfoneCarrierMaintenanceController;

    @Mock
    private TracfoneRatePlanControllerLocal tracfoneRatePlanController;

    @Mock
    private SecurityContext securityContext;

    @Mock
    private TracfoneOnePrincipal principal;

    @Mock
    private TFOneAdminUser user;

    @Mock
    private TracfoneControllerLocalAction tracfoneControllerAction;

    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    public TracfoneOneCarrierWizardResourceTest() {
    }

    @Before
    public void setUp() {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        when(securityContext.getUserPrincipal()).thenReturn(principal);
        when(principal.getTFUser()).thenReturn(user);
    }

//    @Test
//    public void testGetDatabaseEnvironments() throws TracfoneOneException {
//        List<TFOneDatabaseEnvironment> tfOneDatabaseEnvironments = new ArrayList<>();
//        TFOneDatabaseEnvironment tfOneDatabaseEnvironment = new TFOneDatabaseEnvironment();
//        tfOneDatabaseEnvironment.setName("SIT1");
//        tfOneDatabaseEnvironments.add(tfOneDatabaseEnvironment);
//        when(tracfoneController.getDatabaseEnvironments(user.getUserId())).thenReturn(tfOneDatabaseEnvironments);
//        Response response = tracfoneOneCarrierWizardResource.getDatabaseEnvironments();
//        assertEquals(response.getStatus(), 200);
//        assertEquals(response.getMediaType().toString(), JSON);
//        assertEquals("[{\"id\":0,\"name\":\"SIT1\",\"description\":null}]", response.getEntity().toString());
//    }
//
//    @Test
//    public void testGetDatabaseEnvironments_whenException() throws TracfoneOneException {
//        doThrow(tracfoneOneException).when(tracfoneController).getDatabaseEnvironments(anyInt());
//        Response response = tracfoneOneCarrierWizardResource.getDatabaseEnvironments();
//        assertEquals(response.getStatus(), 200);
//        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
//    }

    @Test
    public void testSearchParent() throws TracfoneOneException {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        tracfoneOneParent.setDbEnv(DBENV);
        tracfoneOneParent.setParentId("1000");

        List<TFOneParent> tfOneParents = new ArrayList<>();
        TFOneParent tfOneParent = new TFOneParent();
        tfOneParent.setParentId("1000");
        tfOneParent.setxParentName("PARENT_NAME");
        tfOneParents.add(tfOneParent);
        when(tracfoneCarrierMaintenanceController.searchParent(any())).thenReturn(tfOneParents);
        Response response = tracfoneOneCarrierWizardResource.searchParent(tracfoneOneParent);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"xParentName\":\"PARENT_NAME\",\"parentId\":\"1000\",\"status\":null,\"holdAnalogDeac\":null,\"holdDigitalDeac\":null,\"parent2TempQueue\":null,\"noInventory\":null,\"vmAccessNum\":null,\"autoPortIn\":null,\"autoPortOut\":null,\"noMsid\":null,\"otaCarrier\":null,\"otaEndDate\":null,\"otaPsmsAddress\":null,\"otaStartDate\":null,\"nextAvailable\":null,\"queueName\":null,\"blockPortIn\":null,\"meidCarrier\":null,\"otaReact\":null,\"aggCarrCode\":null,\"suiRuleObjId\":null,\"deactSimExpDays\":null,\"overrideSmsAddress\":null,\"triggerId\":null,\"parentShortName\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchParent_whenException() throws TracfoneOneException {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchParent(any());
        Response response = tracfoneOneCarrierWizardResource.searchParent(tracfoneOneParent);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierGroups() throws TracfoneOneException {
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setCarrierName("CARRIER_NAME");
        tracfoneOneCarrierGroup.setDbEnv(DBENV);

        List<TFOneCarrierGroup> carrierGroups = new ArrayList<>();
        TFOneCarrierGroup carrierGroup = new TFOneCarrierGroup();
        carrierGroup.setObjId("1000");
        carrierGroup.setCarrierName("CARRIER_NAME");
        carrierGroups.add(carrierGroup);
        when(tracfoneCarrierMaintenanceController.searchCarrierGroups(any())).thenReturn(carrierGroups);
        Response response = tracfoneOneCarrierWizardResource.searchCarrierGroups(tracfoneOneCarrierGroup);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"carrierGroupId\":null,\"carrierName\":\"CARRIER_NAME\",\"group2Address\":null,\"status\":null,\"carrierGroup2Parent\":null,\"noAutoPart\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierGroups_whenException() throws TracfoneOneException {
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchCarrierGroups(any());
        Response response = tracfoneOneCarrierWizardResource.searchCarrierGroups(tracfoneOneCarrierGroup);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrier() throws TracfoneOneException {
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setCarrierId("1000");

        List<TFOneCarrier> tfOneCarriers = new ArrayList<>();
        TFOneCarrier tfOneCarrier = new TFOneCarrier();
        tfOneCarrier.setObjId("1000");
        tfOneCarrier.setActTechnology("CDMA");
        tfOneCarriers.add(tfOneCarrier);

        when(tracfoneCarrierMaintenanceController.searchCarrier(any())).thenReturn(tfOneCarriers);
        Response response = tracfoneOneCarrierWizardResource.searchCarrier(tracfoneOneCarrier);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"carrierId\":null,\"submarketName\":null,\"submarketOf\":null,\"city\":null,\"state\":null,\"tapeReturnCharge\":null,\"countryCode\":null,\"activeLinePercent\":null,\"status\":null,\"ldProvider\":null,\"ldAccount\":null,\"ldPicCode\":null,\"ratePlan\":null,\"dummyEsn\":null,\"billDate\":null,\"voiceMail\":null,\"vmCode\":null,\"vmPackage\":null,\"callerId\":null,\"idCode\":null,\"idPackage\":null,\"callWaiting\":null,\"cwCode\":null,\"cwPackage\":null,\"reactTechnology\":null,\"reactAnalog\":null,\"actTechnology\":\"CDMA\",\"actAnalog\":null,\"digitalRatePlan\":null,\"digitalFeature\":null,\"prlPreLoaded\":null,\"carrier2CarrierGroup\":null,\"tapeReturnAddr2Address\":null,\"carrier2Provider\":null,\"carrier2Address\":null,\"carrier2Personality\":null,\"carrier2Rule\":null,\"carrier2CarrScript\":null,\"specialMkt\":null,\"newAnalogPlan\":null,\"newDigitalPlan\":null,\"sms\":null,\"smsCode\":null,\"smsPackage\":null,\"vmSetUpLandLine\":null,\"carrier2RulesCdma\":null,\"carrier2RulesGsm\":null,\"carrier2RulesTdma\":null,\"dataService\":null,\"automated\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrier_whenException() throws TracfoneOneException {
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchCarrier(any());
        Response response = tracfoneOneCarrierWizardResource.searchCarrier(tracfoneOneCarrier);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierRules() throws TracfoneOneException {
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        tracfoneOneCarrierRule.setDbEnv(DBENV);
        tracfoneOneCarrierRule.setObjId("1000");

        List<TFOneCarrierRule> tfOneCarrierRules = new ArrayList<>();
        TFOneCarrierRule tfOneCarrierRule = new TFOneCarrierRule();
        tfOneCarrierRule.setCoolingPeriod("COOLING_PERIOD");
        tfOneCarrierRules.add(tfOneCarrierRule);
        when(tracfoneCarrierMaintenanceController.searchCarrierRules(any())).thenReturn(tfOneCarrierRules);
        Response response = tracfoneOneCarrierWizardResource.searchCarrierRules(tracfoneOneCarrierRule);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"coolingPeriod\":\"COOLING_PERIOD\",\"esnChangeDays\":null,\"lineExpireDays\":null,\"lineReturnDays\":null,\"coolingAfterInsert\":null,\"npaNxxFlag\":null,\"usedLineExpireDays\":null,\"gsmGracePeriod\":null,\"technology\":null,\"reserveOnSuspend\":null,\"reservePeriod\":null,\"deacAfterGrace\":null,\"cancelSuspendDays\":null,\"cancelSuspend\":null,\"blockCreateActItem\":null,\"allow2gAct\":null,\"allow2gReact\":null,\"allowNonHdActs\":null,\"allowNonHdReacts\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierRules_whenException() throws TracfoneOneException {
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchCarrierRules(any());
        Response response = tracfoneOneCarrierWizardResource.searchCarrierRules(tracfoneOneCarrierRule);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetOrderTypes() throws TracfoneOneException {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setOrderType2xCarrier("CARRIER");

        List<TFOneOrderType> orderTypes = new ArrayList<>();
        TFOneOrderType orderType = new TFOneOrderType();
        orderType.setObjId("1000");
        orderType.setNpa("NPA");
        orderTypes.add(orderType);

        when(tracfoneCarrierMaintenanceController.searchOrderTypes(any())).thenReturn(orderTypes);
        Response response = tracfoneOneCarrierWizardResource.searchOrderTypes(tracfoneOneOrderType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"orderType\":null,\"npa\":\"NPA\",\"nxx\":null,\"billCycle\":null,\"dealerCode\":null,\"ldAccountNum\":null,\"marketCode\":null,\"orderType2xTransProfile\":null,\"orderType2xCarrier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetOrderTypes_whenException() throws TracfoneOneException {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchOrderTypes(any());
        Response response = tracfoneOneCarrierWizardResource.searchOrderTypes(tracfoneOneOrderType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchDataConfigMapping() throws TracfoneOneException {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");

        List<TFOneDataConfigMapping> tfOneDataConfigMappings = new ArrayList<>();
        TFOneDataConfigMapping tfOneDataConfigMapping = new TFOneDataConfigMapping();
        tfOneDataConfigMapping.setRatePlan("RATE_PLAN");
        tfOneDataConfigMappings.add(tfOneDataConfigMapping);

        when(tracfoneCarrierMaintenanceController.searchDataConfigMapping(any())).thenReturn(tfOneDataConfigMappings);
        Response response = tracfoneOneCarrierWizardResource.searchDataConfigMapping(tfDataConfigMapping);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"parentId\":null,\"partClassObjId\":null,\"ratePlan\":\"RATE_PLAN\",\"dataConfigObjId\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchDataConfigMapping_whenException() throws TracfoneOneException {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchDataConfigMapping(any());
        Response response = tracfoneOneCarrierWizardResource.searchDataConfigMapping(tfDataConfigMapping);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertDataConfigMapping() throws TracfoneOneException {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");
        when(tracfoneCarrierMaintenanceController.insertDataConfigMapping(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertDataConfigMapping(tfDataConfigMapping);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertDataConfigMapping_whenException() throws TracfoneOneException {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertDataConfigMapping(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertDataConfigMapping(tfDataConfigMapping);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteDataConfigMapping() throws TracfoneOneException {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");
        when(tracfoneCarrierMaintenanceController.deleteDataConfigMapping(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.deleteDataConfigMapping(tfDataConfigMapping);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteDataConfigMapping_whenException() throws TracfoneOneException {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).deleteDataConfigMapping(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.deleteDataConfigMapping(tfDataConfigMapping);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateDataConfigMapping() throws TracfoneOneException {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");
        when(tracfoneCarrierMaintenanceController.updateDataConfigMapping(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateDataConfigMapping(tfDataConfigMapping);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateDataConfigMapping_whenException() throws TracfoneOneException {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateDataConfigMapping(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateDataConfigMapping(tfDataConfigMapping);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateParent() throws TracfoneOneException {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        tracfoneOneParent.setDbEnv(DBENV);
        tracfoneOneParent.setParentId("1000");
        tracfoneOneParent.setParentName("PARENT_NAME");
        when(tracfoneCarrierMaintenanceController.updateParent(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateParent(tracfoneOneParent);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateParent_whenException() throws TracfoneOneException {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateParent(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateParent(tracfoneOneParent);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierGroup() throws TracfoneOneException {
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setDbEnv(DBENV);
        tracfoneOneCarrierGroup.setObjId("1000");
        tracfoneOneCarrierGroup.setStatus("STATUS");
        when(tracfoneCarrierMaintenanceController.updateCarrierGroup(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateCarrierGroup(tracfoneOneCarrierGroup);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierGroup_whenException() throws TracfoneOneException {
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateCarrierGroup(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateCarrierGroup(tracfoneOneCarrierGroup);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrier() throws TracfoneOneException {
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setObjId("100");
        tracfoneOneCarrier.setStatus("STATUS");
        when(tracfoneCarrierMaintenanceController.updateCarrier(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateCarrier(tracfoneOneCarrier);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrier_whenException() throws TracfoneOneException {
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateCarrier(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateCarrier(tracfoneOneCarrier);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierRule() throws TracfoneOneException {
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        tracfoneOneCarrierRule.setDbEnv(DBENV);
        tracfoneOneCarrierRule.setObjId("1000");
        tracfoneOneCarrierRule.setTechnology("CDMA");
        when(tracfoneCarrierMaintenanceController.updateCarrierRule(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateCarrierRule(tracfoneOneCarrierRule);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierRule_whenException() throws TracfoneOneException {
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateCarrierRule(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateCarrierRule(tracfoneOneCarrierRule);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateOrderType() throws TracfoneOneException {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("1000");
        tracfoneOneOrderType.setNpa("NPA");
        when(tracfoneCarrierMaintenanceController.updateOrderType(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateOrderType(tracfoneOneOrderType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateOrderType_whenException() throws TracfoneOneException {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateOrderType(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateOrderType(tracfoneOneOrderType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertParent() throws TracfoneOneException {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        tracfoneOneParent.setDbEnv(DBENV);
        tracfoneOneParent.setParentId("1000");
        tracfoneOneParent.setParentName("PARENT_NAME");
        when(tracfoneCarrierMaintenanceController.insertParent(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertParent(tracfoneOneParent);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertParent_whenException() throws TracfoneOneException {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertParent(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertParent(tracfoneOneParent);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierGroups() throws TracfoneOneException {
        List<TracfoneOneCarrierGroup> tracfoneOneCarrierGroups = new ArrayList<>();
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setDbEnv(DBENV);
        tracfoneOneCarrierGroup.setObjId("1000");
        tracfoneOneCarrierGroup.setStatus("STATUS");
        tracfoneOneCarrierGroups.add(tracfoneOneCarrierGroup);
        when(tracfoneCarrierMaintenanceController.insertCarrierGroups(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertCarrierGroups(tracfoneOneCarrierGroups);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierGroups_whenException() throws TracfoneOneException {
        List<TracfoneOneCarrierGroup> tracfoneOneCarrierGroups = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertCarrierGroups(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertCarrierGroups(tracfoneOneCarrierGroups);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarriers() throws TracfoneOneException {
        List<TracfoneOneCarrier> tracfoneOneCarriers = new ArrayList<>();
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setObjId("100");
        tracfoneOneCarrier.setStatus("STATUS");
        tracfoneOneCarriers.add(tracfoneOneCarrier);
        when(tracfoneCarrierMaintenanceController.insertCarriers(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertCarriers(tracfoneOneCarriers);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarriers_whenException() throws TracfoneOneException {
        List<TracfoneOneCarrier> tracfoneOneCarriers = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertCarriers(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertCarriers(tracfoneOneCarriers);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierRule() throws TracfoneOneException {
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        tracfoneOneCarrierRule.setDbEnv(DBENV);
        tracfoneOneCarrierRule.setObjId("1000");
        tracfoneOneCarrierRule.setTechnology("CDMA");
        when(tracfoneCarrierMaintenanceController.insertCarrierRule(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertCarrierRule(tracfoneOneCarrierRule);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierRule_whenException() throws TracfoneOneException {
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertCarrierRule(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertCarrierRule(tracfoneOneCarrierRule);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertOrderType() throws TracfoneOneException {
        List<TracfoneOneOrderType> tracfoneOneOrderTypes = new ArrayList<>();
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("1000");
        tracfoneOneOrderType.setNpa("NPA");
        tracfoneOneOrderTypes.add(tracfoneOneOrderType);

        List<TFOneOrderType> tfOneOrderTypes = new ArrayList<>();
        TFOneOrderType tfOneOrderType = new TFOneOrderType();
        tfOneOrderType.setObjId("1000");
        tfOneOrderType.setNpa("NPA");
        tfOneOrderTypes.add(tfOneOrderType);

        when(tracfoneCarrierMaintenanceController.insertOrderType(any(), anyInt())).thenReturn(tfOneOrderTypes);
        Response response = tracfoneOneCarrierWizardResource.insertOrderType(tracfoneOneOrderTypes);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"orderType\":null,\"npa\":\"NPA\",\"nxx\":null,\"billCycle\":null,\"dealerCode\":null,\"ldAccountNum\":null,\"marketCode\":null,\"orderType2xTransProfile\":null,\"orderType2xCarrier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testInsertOrderType_whenException() throws TracfoneOneException {
        List<TracfoneOneOrderType> tracfoneOneOrderTypes = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertOrderType(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertOrderType(tracfoneOneOrderTypes);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }


    @Test
    public void testSearchDataConfigs() throws TracfoneOneException {
        TracfoneOneDataConfig tracfoneOneDataConfig = new TracfoneOneDataConfig();
        tracfoneOneDataConfig.setDbEnv(DBENV);
        tracfoneOneDataConfig.setApn("APN");

        List<TFOneDataConfig> dataConfigs = new ArrayList<>();
        TFOneDataConfig dataConfig = new TFOneDataConfig();
        dataConfig.setApn("APN");
        dataConfigs.add(dataConfig);
        when(tracfoneCarrierMaintenanceController.searchDataConfigs(any())).thenReturn(dataConfigs);
        Response response = tracfoneOneCarrierWizardResource.searchDataConfigs(tracfoneOneDataConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"dev\":null,\"parentId\":null,\"partClassObjId\":null,\"xDefault\":null,\"ipAddress\":null,\"apn\":\"APN\",\"homePage\":null,\"mmsc\":null,\"cmd148CarrierDataSwitch\":null,\"dataSwitch\":null,\"cmd71GprsApn\":null,\"cmd150ClearProxy\":null,\"cmd121GatewayPortUpdate\":null,\"cmd121GatewayIpUpdate\":null,\"cmd71MmscUpdate\":null,\"cmd71GatewayHome\":null,\"cmd121GatewayIpPortUpdate\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchDataConfigs_whenException() throws TracfoneOneException {
        TracfoneOneDataConfig tracfoneOneDataConfig = new TracfoneOneDataConfig();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchDataConfigs(any());
        Response response = tracfoneOneCarrierWizardResource.searchDataConfigs(tracfoneOneDataConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllPartClasses() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);

        List<TFOnePartClass> allPartClasses = new ArrayList<>();
        TFOnePartClass allPartClass = new TFOnePartClass();
        allPartClass.setName("NAME");
        allPartClass.setObjId("100");
        allPartClasses.add(allPartClass);
        when(tracfoneCarrierMaintenanceController.getAllPartClasses(any())).thenReturn(allPartClasses);
        Response response = tracfoneOneCarrierWizardResource.getAllPartClasses(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"100\",\"name\":\"NAME\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllPartClasses_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).getAllPartClasses(any());
        Response response = tracfoneOneCarrierWizardResource.getAllPartClasses(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllParentNames() throws TracfoneOneException {
        List<TFOneParent> allParents = new ArrayList<>();
        TFOneParent tFOneParent = new TFOneParent();
        tFOneParent.setObjId("1000");
        allParents.add(tFOneParent);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        when(tracfoneRatePlanController.getAllParentNames(any(), any())).thenReturn(allParents);
        Response response = tracfoneOneCarrierWizardResource.getAllParentNames(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"xParentName\":null,\"parentId\":null,\"status\":null,\"holdAnalogDeac\":null,\"holdDigitalDeac\":null,\"parent2TempQueue\":null,\"noInventory\":null,\"vmAccessNum\":null,\"autoPortIn\":null,\"autoPortOut\":null,\"noMsid\":null,\"otaCarrier\":null,\"otaEndDate\":null,\"otaPsmsAddress\":null,\"otaStartDate\":null,\"nextAvailable\":null,\"queueName\":null,\"blockPortIn\":null,\"meidCarrier\":null,\"otaReact\":null,\"aggCarrCode\":null,\"suiRuleObjId\":null,\"deactSimExpDays\":null,\"overrideSmsAddress\":null,\"triggerId\":null,\"parentShortName\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllParentNames_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getAllParentNames(any(), any());
        Response response = tracfoneOneCarrierWizardResource.getAllParentNames(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteOrderType() throws TracfoneOneException {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("1000");
        when(tracfoneCarrierMaintenanceController.deleteOrderType(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.deleteOrderType(tracfoneOneOrderType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteOrderType_whenException() throws TracfoneOneException {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).deleteOrderType(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.deleteOrderType(tracfoneOneOrderType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertIgOrderTypes() throws TracfoneOneException {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        when(tracfoneCarrierMaintenanceController.insertIgOrderTypes(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertIgOrderTypes(tracfoneOneIgOrderType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertIgOrderTypes_whenException() throws TracfoneOneException {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertIgOrderTypes(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertIgOrderTypes(tracfoneOneIgOrderType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateIgOrderTypes() throws TracfoneOneException {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        tracfoneOneIgOrderType.setProgrammeName("TEST");
        tracfoneOneIgOrderType.setIgOrderType("ORDER");
        tracfoneOneIgOrderType.setPriority("1");
        when(tracfoneCarrierMaintenanceController.updateIgOrderTypes(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateIgOrderTypes(tracfoneOneIgOrderType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateIgOrderTypes_whenException() throws TracfoneOneException {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateIgOrderTypes(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateIgOrderTypes(tracfoneOneIgOrderType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchIgOrderTypes() throws TracfoneOneException {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        tracfoneOneIgOrderType.setProgrammeName("TEST");
        tracfoneOneIgOrderType.setIgOrderType("ORDER");
        tracfoneOneIgOrderType.setPriority("1");

        List<TFOneIgOrderType> tfOneIgOrderTypes = new ArrayList<>();
        TFOneIgOrderType tfOneIGOrderType = new TFOneIgOrderType();
        tfOneIGOrderType.setProgrammeName("TEST");
        tfOneIGOrderType.setIgOrderType("ORDER");
        tfOneIGOrderType.setPriority("1");
        tfOneIgOrderTypes.add(tfOneIGOrderType);
        when(tracfoneCarrierMaintenanceController.searchIgOrderTypes(any(), anyBoolean())).thenReturn(tfOneIgOrderTypes);
        Response response = tracfoneOneCarrierWizardResource.searchIgOrderTypes(tracfoneOneIgOrderType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"programmeName\":\"TEST\",\"actualOrderType\":null,\"igOrderType\":\"ORDER\",\"sqlText\":null,\"priority\":\"1\",\"createSOGencodeFlag\":null,\"createMFormIGFlag\":null,\"createMFormPortFlag\":null,\"skipMinValidationForm\":null,\"skipESNValidationFlag\":null,\"createIGAPNFlag\":null,\"insertILDTransFlag\":null,\"bogoConfigFlag\":null,\"sUIActionType\":null,\"updateMSIDFlag\":null,\"addonCashCardFlag\":null,\"contactPinUpdateFlag\":null,\"brmNotificationFlag\":null,\"newerTransFlag\":null,\"skipMinUpdateFlag\":null,\"safeLinkBatchFlag\":null,\"createBucketsFlag\":null,\"processIgateIN3Flag\":null,\"processIgateIN3LiteFlag\":null,\"updateXCase2TaskFlag\":null,\"depIGTransFlag\":null,\"generateAccountFlag\":null,\"createIGACMFlag\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchIgOrderTypes_whenException() throws TracfoneOneException {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchIgOrderTypes(any(), anyBoolean());
        Response response = tracfoneOneCarrierWizardResource.searchIgOrderTypes(tracfoneOneIgOrderType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertThrottlePolicy() throws TracfoneOneException {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        tracfoneOneThrottlePolicy.setDbEnv(DBENV);
        tracfoneOneThrottlePolicy.setPolicyName("TEST");
        tracfoneOneThrottlePolicy.setPolicyDesc("DESC");
        when(tracfoneCarrierMaintenanceController.insertThrottlePolicy(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertThrottlePolicy(tracfoneOneThrottlePolicy);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertThrottlePolicy_whenException() throws TracfoneOneException {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertThrottlePolicy(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertThrottlePolicy(tracfoneOneThrottlePolicy);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertThrottleRule() throws TracfoneOneException {
        List<TracfoneOneThrottleRule> rules = new ArrayList<>();
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        tracfoneOneThrottleRule.setDbEnv(DBENV);
        tracfoneOneThrottleRule.setParentId("123");
        tracfoneOneThrottleRule.setPolicyId("123");
        tracfoneOneThrottleRule.setRuleDesc("DESC");
        rules.add(tracfoneOneThrottleRule);
        when(tracfoneCarrierMaintenanceController.insertThrottleRules(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertThrottleRules(rules);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertThrottleRule_whenException() throws TracfoneOneException {
        List<TracfoneOneThrottleRule> rules = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertThrottleRules(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertThrottleRules(rules);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertThrottleFeature() throws TracfoneOneException {
        List<TracfoneOneThrottleFeature> features = new ArrayList<>();
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        tracfoneOneThrottleFeature.setDbEnv(DBENV);
        tracfoneOneThrottleFeature.setRuleId("123");
        tracfoneOneThrottleFeature.setFeatureFlagValue("TEST");
        tracfoneOneThrottleFeature.setFeatureName("TEST");
        features.add(tracfoneOneThrottleFeature);
        when(tracfoneCarrierMaintenanceController.insertThrottleFeatures(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertThrottleFeatures(features);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertThrottleFeature_whenException() throws TracfoneOneException {
        List<TracfoneOneThrottleFeature> features = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertThrottleFeatures(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertThrottleFeatures(features);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchThrottlePolicy() throws TracfoneOneException {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        tracfoneOneThrottlePolicy.setDbEnv(DBENV);
        tracfoneOneThrottlePolicy.setPolicyName("TEST");
        tracfoneOneThrottlePolicy.setPolicyDesc("DESC");

        List<TFOneThrottlePolicy> tfOneThrottlePolicies = new ArrayList<>();
        TFOneThrottlePolicy tfOneThrottlePolicy = new TFOneThrottlePolicy();
        tfOneThrottlePolicy.setPolicyName("TEST");
        tfOneThrottlePolicy.setPolicyDesc("DESC");
        tfOneThrottlePolicies.add(tfOneThrottlePolicy);
        when(tracfoneCarrierMaintenanceController.searchThrottlePolicies(any())).thenReturn(tfOneThrottlePolicies);
        Response response = tracfoneOneCarrierWizardResource.searchThrottlePolicies(tracfoneOneThrottlePolicy);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"policyName\":\"TEST\",\"policyDesc\":\"DESC\",\"bypassTransQueue\":null,\"dataSuspendedFlag\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchThrottlePolicy_whenException() throws TracfoneOneException {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchThrottlePolicies(any());
        Response response = tracfoneOneCarrierWizardResource.searchThrottlePolicies(tracfoneOneThrottlePolicy);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchThrottleRule() throws TracfoneOneException {
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        tracfoneOneThrottleRule.setDbEnv(DBENV);
        tracfoneOneThrottleRule.setParentId("123");
        tracfoneOneThrottleRule.setPolicyId("123");
        tracfoneOneThrottleRule.setRuleDesc("DESC");

        List<TFOneThrottleRule> tfOneThrottleRules = new ArrayList<>();
        TFOneThrottleRule tfOneThrottleRule = new TFOneThrottleRule();
        tfOneThrottleRule.setParentId("123");
        tfOneThrottleRule.setPolicyId("123");
        tfOneThrottleRule.setRuleDesc("DESC");
        tfOneThrottleRules.add(tfOneThrottleRule);
        when(tracfoneCarrierMaintenanceController.searchThrottleRules(any())).thenReturn(tfOneThrottleRules);
        Response response = tracfoneOneCarrierWizardResource.searchThrottleRules(tracfoneOneThrottleRule);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"parentId\":\"123\",\"policyId\":\"123\",\"ruleDesc\":\"DESC\",\"status\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchThrottleRule_whenException() throws TracfoneOneException {
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchThrottleRules(any());
        Response response = tracfoneOneCarrierWizardResource.searchThrottleRules(tracfoneOneThrottleRule);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchThrottleFeatures() throws TracfoneOneException {
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        tracfoneOneThrottleFeature.setDbEnv(DBENV);
        tracfoneOneThrottleFeature.setRuleId("123");
        tracfoneOneThrottleFeature.setFeatureFlagValue("TEST");
        tracfoneOneThrottleFeature.setFeatureName("TEST");

        List<TFOneThrottleFeature> tfOneThrottleFeatures = new ArrayList<>();
        TFOneThrottleFeature tfOneThrottleFeature = new TFOneThrottleFeature();
        tfOneThrottleFeature.setRuleId("123");
        tfOneThrottleFeature.setFeatureFlagName("TEST");
        tfOneThrottleFeature.setFeatureName("TEST");
        tfOneThrottleFeatures.add(tfOneThrottleFeature);
        when(tracfoneCarrierMaintenanceController.searchThrottleFeatures(any())).thenReturn(tfOneThrottleFeatures);
        Response response = tracfoneOneCarrierWizardResource.searchThrottleFeatures(tracfoneOneThrottleFeature);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"ruleId\":\"123\",\"featureFlagName\":\"TEST\",\"featureFlagValue\":null,\"featureName\":\"TEST\",\"featureValue\":null,\"status\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchThrottleFeatures_whenException() throws TracfoneOneException {
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchThrottleFeatures(any());
        Response response = tracfoneOneCarrierWizardResource.searchThrottleFeatures(tracfoneOneThrottleFeature);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateThrottlePolicy() throws TracfoneOneException {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        tracfoneOneThrottlePolicy.setDbEnv(DBENV);
        tracfoneOneThrottlePolicy.setPolicyName("TEST");
        tracfoneOneThrottlePolicy.setPolicyDesc("DESC");
        when(tracfoneCarrierMaintenanceController.updateThrottlePolicy(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateThrottlePolicy(tracfoneOneThrottlePolicy);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateThrottlePolicy_whenException() throws TracfoneOneException {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateThrottlePolicy(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateThrottlePolicy(tracfoneOneThrottlePolicy);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateThrottleRule() throws TracfoneOneException {
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        tracfoneOneThrottleRule.setDbEnv(DBENV);
        tracfoneOneThrottleRule.setParentId("123");
        tracfoneOneThrottleRule.setPolicyId("123");
        tracfoneOneThrottleRule.setRuleDesc("DESC");
        when(tracfoneCarrierMaintenanceController.updateThrottleRule(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateThrottleRule(tracfoneOneThrottleRule);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateThrottleRule_whenException() throws TracfoneOneException {
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateThrottleRule(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateThrottleRule(tracfoneOneThrottleRule);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateThrottleFeature() throws TracfoneOneException {
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        tracfoneOneThrottleFeature.setDbEnv(DBENV);
        tracfoneOneThrottleFeature.setRuleId("123");
        tracfoneOneThrottleFeature.setFeatureFlagValue("TEST");
        tracfoneOneThrottleFeature.setFeatureName("TEST");
        when(tracfoneCarrierMaintenanceController.updateThrottleFeature(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateThrottleFeature(tracfoneOneThrottleFeature);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateThrottleFeature_whenException() throws TracfoneOneException {
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateThrottleFeature(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateThrottleFeature(tracfoneOneThrottleFeature);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchVerizonZipNPANXX() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("TEST");
        tracfoneOneVerizonZipNPANXX.setZip("07832");

        List<TFOneVerizonZipNPANXX> tfOneVerizonZipNPANXXs = new ArrayList<>();
        TFOneVerizonZipNPANXX tfOneVerizonZipNPANXX = new TFOneVerizonZipNPANXX();
        tfOneVerizonZipNPANXX.setAccountNum("123");
        tfOneVerizonZipNPANXX.setnPANXX("TEST");
        tfOneVerizonZipNPANXX.setZip("07832");
        tfOneVerizonZipNPANXXs.add(tfOneVerizonZipNPANXX);
        when(tracfoneCarrierMaintenanceController.searchVerizonZipNPANXX(any())).thenReturn(tfOneVerizonZipNPANXXs);
        Response response = tracfoneOneCarrierWizardResource.searchVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"zip\":\"07832\",\"nPA\":null,\"nXX\":null,\"nPANXX\":\"TEST\",\"accountNum\":\"123\",\"template\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchVerizonZipNPANXX_whenException() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchVerizonZipNPANXX(any());
        Response response = tracfoneOneCarrierWizardResource.searchVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertVerizonZipNPANXX() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("TEST");
        tracfoneOneVerizonZipNPANXX.setZip("07832");
        when(tracfoneCarrierMaintenanceController.insertVerizonZipNPANXX(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertVerizonZipNPANXX_whenException() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertVerizonZipNPANXX(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertVerizonZipNPANXX() throws TracfoneOneException {
        doNothing().when(tracfoneCarrierMaintenanceController).bulkInsertVerizonZipNPANXX(anyList(), anyInt());
        List<TracfoneOneVerizonZipNPANXX> tracfoneOneVerizonZipNPANXXs = new ArrayList<>();
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("TEST");
        tracfoneOneVerizonZipNPANXX.setZip("07832");
        tracfoneOneVerizonZipNPANXXs.add(tracfoneOneVerizonZipNPANXX);
        Response response = tracfoneOneCarrierWizardResource.bulkInsertVerizonZipNPANXX(tracfoneOneVerizonZipNPANXXs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"Success\",\"message\":\"Success\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertVerizonZipNPANXX_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkInsertVerizonZipNPANXX(anyList(), anyInt());
        List<TracfoneOneVerizonZipNPANXX> tracfoneOneVerizonZipNPANXXs = new ArrayList<>();
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXXs.add(tracfoneOneVerizonZipNPANXX);
        Response response = tracfoneOneCarrierWizardResource.bulkInsertVerizonZipNPANXX(tracfoneOneVerizonZipNPANXXs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateVerizonZipNPANXX() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("TEST");
        tracfoneOneVerizonZipNPANXX.setZip("07832");
        when(tracfoneCarrierMaintenanceController.updateVerizonZipNPANXX(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateVerizonZipNPANXX_whenException() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateVerizonZipNPANXX(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteVerizonZipNPANXX() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("TEST");
        tracfoneOneVerizonZipNPANXX.setZip("07832");
        when(tracfoneCarrierMaintenanceController.deleteVerizonZipNPANXX(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.deleteVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteVerizonZipNPANXX_whenException() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).deleteVerizonZipNPANXX(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.deleteVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertVznSummary() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv(DBENV);
        List<TFOneBulkInsertReport> tfOneBulkInsertReports = new ArrayList<>();
        TFOneBulkInsertReport tfOneBulkInsertReport = new TFOneBulkInsertReport();
        tfOneBulkInsertReport.setId("100");
        tfOneBulkInsertReport.setStatus("SUCCESS");
        tfOneBulkInsertReports.add(tfOneBulkInsertReport);
        when(tracfoneControllerAction.getBulkInsertSummary(any(), any(), anyInt())).thenReturn(tfOneBulkInsertReports);
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertVznSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"100\",\"createDate\":null,\"status\":\"SUCCESS\",\"totalRecord\":null,\"successCount\":null,\"errorCount\":null,\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertVznSummary_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(any(), any(), anyInt());
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertVznSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetErrorRecordDetail() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> errorDeatils = new ArrayList<>();
        TFOneBulkInsertReport errorDetail = new TFOneBulkInsertReport();
        errorDetail.setStatus("COMPLETE");
        errorDetail.setSuccessCount("5");
        errorDetail.setErrorCount("0");
        errorDetail.setTotalRecord("5");
        errorDeatils.add(errorDetail);
        when(tracfoneControllerAction.getErrorRecordDetails(any())).thenReturn(errorDeatils);
        Response response = tracfoneOneCarrierWizardResource.getErrorRecordDetails(tracfoneOneUserHistory);
        assertNotNull(response);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":\"5\",\"successCount\":\"5\",\"errorCount\":\"0\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetErrorRecordDetails_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getErrorRecordDetails(any());
        Response response = tracfoneOneCarrierWizardResource.getErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    /**
     * Junits for Srint-25
     */

    @Test
    public void testSearchTmoZipNgp() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");

        List<TFOneTmoZipNgp> tfOneTmoZipNgps = new ArrayList<>();
        TFOneTmoZipNgp tfOneTmoZipNgp = new TFOneTmoZipNgp();
        tfOneTmoZipNgp.setNgp("TEST");
        tfOneTmoZipNgp.setPriority("1");
        tfOneTmoZipNgp.setZip("07832");
        tfOneTmoZipNgps.add(tfOneTmoZipNgp);
        when(tracfoneCarrierMaintenanceController.searchTmoZipNgp(any())).thenReturn(tfOneTmoZipNgps);
        Response response = tracfoneOneCarrierWizardResource.searchTmoZipNgp(tracfoneOneTmoZipNgp);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"zip\":\"07832\",\"ngp\":\"TEST\",\"ngpName\":null,\"priority\":\"1\"}]", response.getEntity().toString());
    }

    @Test
    public void testSearchTmoZipNgp_whenException() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchTmoZipNgp(any());
        Response response = tracfoneOneCarrierWizardResource.searchTmoZipNgp(tracfoneOneTmoZipNgp);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertTmoZipNgp() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        when(tracfoneCarrierMaintenanceController.insertTmoZipNgp(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertTmoZipNgp(tracfoneOneTmoZipNgp);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertTmoZipNgp_whenException() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertTmoZipNgp(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertTmoZipNgp(tracfoneOneTmoZipNgp);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertTmoZipNgp() throws TracfoneOneException {
        doNothing().when(tracfoneCarrierMaintenanceController).bulkInsertTmoZipNgp(anyList(), anyInt());
        List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNgps = new ArrayList<>();
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        tracfoneOneTmoZipNgps.add(tracfoneOneTmoZipNgp);
        Response response = tracfoneOneCarrierWizardResource.bulkInsertTmoZipNgp(tracfoneOneTmoZipNgps);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"Success\",\"message\":\"Success\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertTmoZipNgp_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkInsertTmoZipNgp(anyList(), anyInt());
        List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNgps = new ArrayList<>();
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        tracfoneOneTmoZipNgps.add(tracfoneOneTmoZipNgp);
        Response response = tracfoneOneCarrierWizardResource.bulkInsertTmoZipNgp(tracfoneOneTmoZipNgps);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateTmoZipNgp() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        when(tracfoneCarrierMaintenanceController.updateTmoZipNgp(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateTmoZipNgp(tracfoneOneTmoZipNgp);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateTmoZipNgp_whenException() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateTmoZipNgp(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateTmoZipNgp(tracfoneOneTmoZipNgp);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteTmoZipNgp() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        when(tracfoneCarrierMaintenanceController.deleteTmoZipNgp(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.deleteTmoZipNgp(tracfoneOneTmoZipNgp);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteTmoZipNgp_whenException() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).deleteTmoZipNgp(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.deleteTmoZipNgp(tracfoneOneTmoZipNgp);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertTmoZipNgpSummary() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv(DBENV);
        List<TFOneBulkInsertReport> tfOneBulkInsertReports = new ArrayList<>();
        TFOneBulkInsertReport tfOneBulkInsertReport = new TFOneBulkInsertReport();
        tfOneBulkInsertReport.setId("100");
        tfOneBulkInsertReport.setStatus("SUCCESS");
        tfOneBulkInsertReports.add(tfOneBulkInsertReport);
        when(tracfoneControllerAction.getBulkInsertSummary(any(), any(), anyInt())).thenReturn(tfOneBulkInsertReports);
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertTmoZipNgpSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"100\",\"createDate\":null,\"status\":\"SUCCESS\",\"totalRecord\":null,\"successCount\":null,\"errorCount\":null,\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertTmoZipNgpSummary_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(any(), any(), anyInt());
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertTmoZipNgpSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetTmoZipNgpErrorRecordDetails() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> errorDeatils = new ArrayList<>();
        TFOneBulkInsertReport errorDetail = new TFOneBulkInsertReport();
        errorDetail.setStatus("COMPLETE");
        errorDetail.setSuccessCount("5");
        errorDetail.setErrorCount("0");
        errorDetail.setTotalRecord("5");
        errorDeatils.add(errorDetail);
        when(tracfoneControllerAction.getErrorRecordDetails(any())).thenReturn(errorDeatils);
        Response response = tracfoneOneCarrierWizardResource.getTmoZipNgpErrorRecordDetails(tracfoneOneUserHistory);
        assertNotNull(response);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":\"5\",\"successCount\":\"5\",\"errorCount\":\"0\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetTmoZipNgpErrorRecordDetails_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getErrorRecordDetails(any());
        Response response = tracfoneOneCarrierWizardResource.getTmoZipNgpErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCingularMrktInfo() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");

        List<TFOneCingularMrktInfo> info = new ArrayList<>();
        TFOneCingularMrktInfo tfOneCingularMrktInfo = new TFOneCingularMrktInfo();
        tfOneCingularMrktInfo.setMkt("TEST");
        tfOneCingularMrktInfo.setNpanxx("1");
        tfOneCingularMrktInfo.setZip("07832");
        tfOneCingularMrktInfo.setRcState("TEST");
        tfOneCingularMrktInfo.setRcName("TEST");
        tfOneCingularMrktInfo.setRcNumber("TEST");
        tfOneCingularMrktInfo.setTemplate("TEST");
        info.add(tfOneCingularMrktInfo);
        when(tracfoneCarrierMaintenanceController.searchCingularMrktInfo(any())).thenReturn(info);
        Response response = tracfoneOneCarrierWizardResource.searchCingularMrktInfo(tracfoneOneCingularMrktInfo);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"mkt\":\"TEST\",\"npa\":null,\"nxx\":null,\"npanxx\":\"1\",\"rcNumber\":\"TEST\",\"rcName\":\"TEST\",\"rcState\":\"TEST\",\"zip\":\"07832\",\"mktType\":null,\"accountNum\":null,\"marketCode\":null,\"dealerCode\":null,\"subMarketId\":null,\"template\":\"TEST\"}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCingularMrktInfo_whenException() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchCingularMrktInfo(any());
        Response response = tracfoneOneCarrierWizardResource.searchCingularMrktInfo(tracfoneOneCingularMrktInfo);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCingularMrktInfo() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        when(tracfoneCarrierMaintenanceController.insertCingularMrktInfo(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertCingularMrktInfo(tracfoneOneCingularMrktInfo);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCingularMrktInfo_whenException() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertCingularMrktInfo(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertCingularMrktInfo(tracfoneOneCingularMrktInfo);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertCingularMrktInfo() throws TracfoneOneException {
        doNothing().when(tracfoneCarrierMaintenanceController).bulkInsertCingularMrktInfo(anyList(), anyInt());
        List<TracfoneOneCingularMrktInfo> info = new ArrayList<>();
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        info.add(tracfoneOneCingularMrktInfo);
        Response response = tracfoneOneCarrierWizardResource.bulkInsertCingularMrktInfo(info);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"Success\",\"message\":\"Success\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertCingularMrktInfo_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkInsertCingularMrktInfo(anyList(), anyInt());
        List<TracfoneOneCingularMrktInfo> info = new ArrayList<>();
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        info.add(tracfoneOneCingularMrktInfo);
        Response response = tracfoneOneCarrierWizardResource.bulkInsertCingularMrktInfo(info);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCingularMrktInfo() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        when(tracfoneCarrierMaintenanceController.updateCingularMrktInfo(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateCingularMrktInfo(tracfoneOneCingularMrktInfo);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCingularMrktInfo_whenException() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateCingularMrktInfo(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateCingularMrktInfo(tracfoneOneCingularMrktInfo);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteCingularMrktInfo() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        when(tracfoneCarrierMaintenanceController.deleteCingularMrktInfo(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.deleteCingularMrktInfo(tracfoneOneCingularMrktInfo);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteCingularMrktInfo_whenException() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).deleteCingularMrktInfo(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.deleteCingularMrktInfo(tracfoneOneCingularMrktInfo);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertCingularMrktInfoSummary() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv(DBENV);
        List<TFOneBulkInsertReport> tfOneBulkInsertReports = new ArrayList<>();
        TFOneBulkInsertReport tfOneBulkInsertReport = new TFOneBulkInsertReport();
        tfOneBulkInsertReport.setId("100");
        tfOneBulkInsertReport.setStatus("SUCCESS");
        tfOneBulkInsertReports.add(tfOneBulkInsertReport);
        when(tracfoneControllerAction.getBulkInsertSummary(any(), any(), anyInt())).thenReturn(tfOneBulkInsertReports);
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertCingularMrktInfoSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"100\",\"createDate\":null,\"status\":\"SUCCESS\",\"totalRecord\":null,\"successCount\":null,\"errorCount\":null,\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertCingularMrktInfoSummary_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(any(), any(), anyInt());
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertCingularMrktInfoSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetCingularMrktInfoErrorRecordDetails() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> errorDeatils = new ArrayList<>();
        TFOneBulkInsertReport errorDetail = new TFOneBulkInsertReport();
        errorDetail.setStatus("COMPLETE");
        errorDetail.setSuccessCount("5");
        errorDetail.setErrorCount("0");
        errorDetail.setTotalRecord("5");
        errorDeatils.add(errorDetail);
        when(tracfoneControllerAction.getErrorRecordDetails(any())).thenReturn(errorDeatils);
        Response response = tracfoneOneCarrierWizardResource.getCingularMrktInfoErrorRecordDetails(tracfoneOneUserHistory);
        assertNotNull(response);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":\"5\",\"successCount\":\"5\",\"errorCount\":\"0\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetCingularMrktInfoErrorRecordDetails_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getErrorRecordDetails(any());
        Response response = tracfoneOneCarrierWizardResource.getCingularMrktInfoErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    /**
     * Junits for Srint-26
     */

    @Test
    public void testSearchNotCertifyModel() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");

        List<TFOneNotCertifyModel> tfOneNotCertifyModels = new ArrayList<>();
        TFOneNotCertifyModel tfOneNotCertifyModel = new TFOneNotCertifyModel();
        tfOneNotCertifyModel.setParentId("100");
        tfOneNotCertifyModel.setDev("1");
        tfOneNotCertifyModel.setPartClassObjId("07832");
        tfOneNotCertifyModels.add(tfOneNotCertifyModel);
        when(tracfoneCarrierMaintenanceController.searchNotCertifyModel(any())).thenReturn(tfOneNotCertifyModels);
        Response response = tracfoneOneCarrierWizardResource.searchNotCertifyModel(tracfoneOneNotCertifyModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"dev\":\"1\",\"parentId\":\"100\",\"partClassObjId\":\"07832\"}]", response.getEntity().toString());
    }

    @Test
    public void testSearchNotCertifyModel_whenException() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchNotCertifyModel(any());
        Response response = tracfoneOneCarrierWizardResource.searchNotCertifyModel(tracfoneOneNotCertifyModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertNotCertifyModel() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        when(tracfoneCarrierMaintenanceController.insertNotCertifyModel(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertNotCertifyModel(tracfoneOneNotCertifyModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertNotCertifyModel_whenException() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertNotCertifyModel(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertNotCertifyModel(tracfoneOneNotCertifyModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertNotCertifyModel() throws TracfoneOneException {
        doNothing().when(tracfoneCarrierMaintenanceController).bulkInsertNotCertifyModel(anyList(), anyInt());
        List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModels = new ArrayList<>();
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        tracfoneOneNotCertifyModels.add(tracfoneOneNotCertifyModel);
        Response response = tracfoneOneCarrierWizardResource.bulkInsertNotCertifyModel(tracfoneOneNotCertifyModels);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"Success\",\"message\":\"Success\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertNotCertifyModel_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkInsertNotCertifyModel(anyList(), anyInt());
        List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModels = new ArrayList<>();
        Response response = tracfoneOneCarrierWizardResource.bulkInsertNotCertifyModel(tracfoneOneNotCertifyModels);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateNotCertifyModel() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        when(tracfoneCarrierMaintenanceController.updateNotCertifyModel(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateNotCertifyModel(tracfoneOneNotCertifyModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateNotCertifyModel_whenException() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateNotCertifyModel(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateNotCertifyModel(tracfoneOneNotCertifyModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteNotCertifyModel() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        when(tracfoneCarrierMaintenanceController.deleteNotCertifyModel(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.deleteNotCertifyModel(tracfoneOneNotCertifyModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteNotCertifyModel_whenException() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).deleteNotCertifyModel(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.deleteNotCertifyModel(tracfoneOneNotCertifyModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertNotCertifyModelSummary() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv(DBENV);
        List<TFOneBulkInsertReport> tfOneBulkInsertReports = new ArrayList<>();
        TFOneBulkInsertReport tfOneBulkInsertReport = new TFOneBulkInsertReport();
        tfOneBulkInsertReport.setId("100");
        tfOneBulkInsertReport.setStatus("SUCCESS");
        tfOneBulkInsertReports.add(tfOneBulkInsertReport);
        when(tracfoneControllerAction.getBulkInsertSummary(any(), any(), anyInt())).thenReturn(tfOneBulkInsertReports);
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertNotCertifyModelSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"100\",\"createDate\":null,\"status\":\"SUCCESS\",\"totalRecord\":null,\"successCount\":null,\"errorCount\":null,\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertNotCertifyModelSummary_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(any(), any(), anyInt());
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertNotCertifyModelSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetNotCertifyModelErrorRecordDetails() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> errorDeatils = new ArrayList<>();
        TFOneBulkInsertReport errorDetail = new TFOneBulkInsertReport();
        errorDetail.setStatus("COMPLETE");
        errorDetail.setSuccessCount("5");
        errorDetail.setErrorCount("0");
        errorDetail.setTotalRecord("5");
        errorDeatils.add(errorDetail);
        when(tracfoneControllerAction.getErrorRecordDetails(any())).thenReturn(errorDeatils);
        Response response = tracfoneOneCarrierWizardResource.getNotCertifyModelErrorRecordDetails(tracfoneOneUserHistory);
        assertNotNull(response);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":\"5\",\"successCount\":\"5\",\"errorCount\":\"0\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetNotCertifyModelErrorRecordDetails_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getErrorRecordDetails(any());
        Response response = tracfoneOneCarrierWizardResource.getNotCertifyModelErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkUpdateNotCertifyModel() throws TracfoneOneException {
        List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModels = new ArrayList<>();
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        tracfoneOneNotCertifyModels.add(tracfoneOneNotCertifyModel);
        when(tracfoneCarrierMaintenanceController.bulkUpdateNotCertifyModel(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.bulkUpdateNotCertifyModel(tracfoneOneNotCertifyModels);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkUpdateNotCertifyModel_whenException() throws TracfoneOneException {
        List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModels = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkUpdateNotCertifyModel(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.bulkUpdateNotCertifyModel(tracfoneOneNotCertifyModels);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }


    /**
     * Junits for Srint-27
     */

    @Test
    public void testBulkUpdateTmoZipNgp() throws TracfoneOneException {
        List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNgps = new ArrayList<>();
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        tracfoneOneTmoZipNgps.add(tracfoneOneTmoZipNgp);
        when(tracfoneCarrierMaintenanceController.bulkUpdateTmoZipNgp(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.bulkUpdateTmoZipNgp(tracfoneOneTmoZipNgps);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkUpdateTmoZipNgp_whenException() throws TracfoneOneException {
        List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNgps = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkUpdateTmoZipNgp(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.bulkUpdateTmoZipNgp(tracfoneOneTmoZipNgps);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierSimPref() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");

        List<TFOneCarriersimpref> tfOneCarriersimprefs = new ArrayList<>();
        TFOneCarriersimpref tfOneCarriersimpref = new TFOneCarriersimpref();
        tfOneCarriersimpref.setCarrierName("TEST");
        tfOneCarriersimpref.setRank("1");
        tfOneCarriersimpref.setSimProfile("TEST");
        tfOneCarriersimpref.setMinDllExch("1");
        tfOneCarriersimpref.setMaxDllExch("1");
        tfOneCarriersimprefs.add(tfOneCarriersimpref);
        when(tracfoneCarrierMaintenanceController.searchCarrierSimPref(any())).thenReturn(tfOneCarriersimprefs);
        Response response = tracfoneOneCarrierWizardResource.searchCarrierSimPref(tracfoneOneCarriersimpref);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"rank\":\"1\",\"minDllExch\":\"1\",\"maxDllExch\":\"1\",\"carrierName\":\"TEST\",\"simProfile\":\"TEST\",\"dbEnv\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierSimPref_whenException() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchCarrierSimPref(any());
        Response response = tracfoneOneCarrierWizardResource.searchCarrierSimPref(tracfoneOneCarriersimpref);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierSimPref() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        when(tracfoneCarrierMaintenanceController.insertCarrierSimPref(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertCarrierSimPref(tracfoneOneCarriersimpref);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierSimPref_whenException() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertCarrierSimPref(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertCarrierSimPref(tracfoneOneCarriersimpref);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertCarrierSimPref() throws TracfoneOneException {
        doNothing().when(tracfoneCarrierMaintenanceController).bulkInsertCarrierSimPref(anyList(), anyInt());
        List<TracfoneOneCarrierSimPref> tracfoneOneCarrierSimPrefs = new ArrayList<>();
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        tracfoneOneCarrierSimPrefs.add(tracfoneOneCarriersimpref);
        Response response = tracfoneOneCarrierWizardResource.bulkInsertCarrierSimPref(tracfoneOneCarrierSimPrefs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"Success\",\"message\":\"Success\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertCarrierSimPref_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkInsertCarrierSimPref(anyList(), anyInt());
        List<TracfoneOneCarrierSimPref> tracfoneOneCarrierSimPrefs = new ArrayList<>();
        Response response = tracfoneOneCarrierWizardResource.bulkInsertCarrierSimPref(tracfoneOneCarrierSimPrefs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierSimPref() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        when(tracfoneCarrierMaintenanceController.updateCarrierSimPref(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateCarrierSimPref(tracfoneOneCarriersimpref);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierSimPref_whenException() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateCarrierSimPref(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateCarrierSimPref(tracfoneOneCarriersimpref);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteCarrierSimPref() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        when(tracfoneCarrierMaintenanceController.deleteCarrierSimPref(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.deleteCarrierSimPref(tracfoneOneCarriersimpref);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteCarrierSimPref_whenException() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).deleteCarrierSimPref(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.deleteCarrierSimPref(tracfoneOneCarriersimpref);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertCarrierSimPrefSummary() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv(DBENV);
        List<TFOneBulkInsertReport> tfOneBulkInsertReports = new ArrayList<>();
        TFOneBulkInsertReport tfOneBulkInsertReport = new TFOneBulkInsertReport();
        tfOneBulkInsertReport.setId("100");
        tfOneBulkInsertReport.setStatus("SUCCESS");
        tfOneBulkInsertReports.add(tfOneBulkInsertReport);
        when(tracfoneControllerAction.getBulkInsertSummary(any(), any(), anyInt())).thenReturn(tfOneBulkInsertReports);
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertCarrierSimPrefSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"100\",\"createDate\":null,\"status\":\"SUCCESS\",\"totalRecord\":null,\"successCount\":null,\"errorCount\":null,\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertCarrierSimPrefSummary_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(any(), any(), anyInt());
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertCarrierSimPrefSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierSimPrefErrorRecordDetails() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> errorDeatils = new ArrayList<>();
        TFOneBulkInsertReport errorDetail = new TFOneBulkInsertReport();
        errorDetail.setStatus("COMPLETE");
        errorDetail.setSuccessCount("5");
        errorDetail.setErrorCount("0");
        errorDetail.setTotalRecord("5");
        errorDeatils.add(errorDetail);
        when(tracfoneControllerAction.getErrorRecordDetails(any())).thenReturn(errorDeatils);
        Response response = tracfoneOneCarrierWizardResource.getCarrierSimPrefErrorRecordDetails(tracfoneOneUserHistory);
        assertNotNull(response);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":\"5\",\"successCount\":\"5\",\"errorCount\":\"0\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierSimPrefErrorRecordDetails_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getErrorRecordDetails(any());
        Response response = tracfoneOneCarrierWizardResource.getCarrierSimPrefErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkUpdateCarrierSimPref() throws TracfoneOneException {
        List<TracfoneOneCarrierSimPref> tracfoneOneCarrierSimPrefs = new ArrayList<>();
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        tracfoneOneCarrierSimPrefs.add(tracfoneOneCarriersimpref);
        when(tracfoneCarrierMaintenanceController.bulkUpdateCarrierSimPref(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.bulkUpdateCarrierSimPref(tracfoneOneCarrierSimPrefs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkUpdateCarrierSimPref_whenException() throws TracfoneOneException {
        List<TracfoneOneCarrierSimPref> tracfoneOneCarrierSimPrefs = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkUpdateCarrierSimPref(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.bulkUpdateCarrierSimPref(tracfoneOneCarrierSimPrefs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchNpanxx2Carrierzones() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        tracfoneOneNpanxx2Carrierzones.setState("1");

        TFOneNpaNxx2CarrierZonesSearchResult tfOneNpanxx2Carrierzones = new TFOneNpaNxx2CarrierZonesSearchResult();
        TFOneNpanxx2Carrierzones tfOneNpanxx2Carrierzone = new TFOneNpanxx2Carrierzones();
        tfOneNpanxx2Carrierzone.setNpa("1");
        tfOneNpanxx2Carrierzone.setNxx("2");
        tfOneNpanxx2Carrierzone.setCarrierId("1");
        tfOneNpanxx2Carrierzone.setZone("1");
        tfOneNpanxx2Carrierzone.setSid("1");
        tfOneNpanxx2Carrierzone.setRateCenter("1");
        tfOneNpanxx2Carrierzone.setState("1");
        tfOneNpanxx2Carrierzones.getNpanxx2Carrierzones().add(tfOneNpanxx2Carrierzone);
        when(tracfoneCarrierMaintenanceController.searchNpanxx2Carrierzones(any())).thenReturn(tfOneNpanxx2Carrierzones);
        Response response = tracfoneOneCarrierWizardResource.searchNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"paginationSearch\":null,\"npanxx2Carrierzones\":[{\"npa\":\"1\",\"nxx\":\"2\",\"carrierId\":\"1\",\"carrierName\":null,\"leadTime\":null,\"targetLevel\":null,\"rateCenter\":\"1\",\"state\":\"1\",\"carrierIdDescription\":null,\"zone\":\"1\",\"county\":null,\"marketId\":null,\"mrktArea\":null,\"sid\":\"1\",\"technology\":null,\"frequency1\":null,\"frequency2\":null,\"btaMktNumber\":null,\"btaMktName\":null,\"gsmTech\":null,\"cdmaTech\":null,\"tdmaTech\":null,\"mnc\":null,\"dbEnv\":null,\"paginationSearch\":null}]}", response.getEntity().toString());
    }

    @Test
    public void testSearchNpanxx2Carrierzones_whenException() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchNpanxx2Carrierzones(any());
        Response response = tracfoneOneCarrierWizardResource.searchNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testinsertNpanxx2Carrierzones() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        tracfoneOneNpanxx2Carrierzones.setState("1");
        when(tracfoneCarrierMaintenanceController.insertNpanxx2Carrierzones(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testinsertNpanxx2Carrierzones_whenException() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertNpanxx2Carrierzones(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testBulkinsertNpanxx2Carrierzones() throws TracfoneOneException {

        doNothing().when(tracfoneCarrierMaintenanceController).bulkInsertNpanxx2Carrierzones(any(), anyInt(), any());
        List<TracfoneOneNpanxx2Carrierzones> tracfoneOneNpanxx2Carrierzones = new ArrayList<>();
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzone = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzone.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzone.setNpa("1");
        tracfoneOneNpanxx2Carrierzone.setNxx("2");
        tracfoneOneNpanxx2Carrierzone.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzone.setZone("1");
        tracfoneOneNpanxx2Carrierzone.setSid("1");
        tracfoneOneNpanxx2Carrierzone.setRateCenter("1");
        tracfoneOneNpanxx2Carrierzone.setState("1");
        tracfoneOneNpanxx2Carrierzones.add(tracfoneOneNpanxx2Carrierzone);
        Response response = tracfoneOneCarrierWizardResource.bulkInsertNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"Success\",\"message\":\"Success\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkinsertNpanxx2Carrierzones_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkInsertNpanxx2Carrierzones(any(), anyInt(), any());
        List<TracfoneOneNpanxx2Carrierzones> tracfoneOneNpanxx2Carrierzones = new ArrayList<>();
        Response response = tracfoneOneCarrierWizardResource.bulkInsertNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testdeleteNpanxx2Carrierzones() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        tracfoneOneNpanxx2Carrierzones.setState("1");
        when(tracfoneCarrierMaintenanceController.deleteNpanxx2Carrierzones(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.deleteNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testdeleteNpanxx2Carrierzones_whenException() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).deleteNpanxx2Carrierzones(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.deleteNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testUpdateNpanxx2Carrierzones() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        tracfoneOneNpanxx2Carrierzones.setState("1");
        when(tracfoneCarrierMaintenanceController.updateNpanxx2Carrierzones(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateeNpanxx2Carrierzones_whenException() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateNpanxx2Carrierzones(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertNpanxx2CarrierzonesSummary() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv(DBENV);
        List<TFOneBulkInsertReport> tfOneBulkInsertReports = new ArrayList<>();
        TFOneBulkInsertReport tfOneBulkInsertReport = new TFOneBulkInsertReport();
        tfOneBulkInsertReport.setId("100");
        tfOneBulkInsertReport.setStatus("SUCCESS");
        tfOneBulkInsertReports.add(tfOneBulkInsertReport);
        when(tracfoneControllerAction.getBulkInsertSummary(any(), any(), anyInt())).thenReturn(tfOneBulkInsertReports);
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertNpanxx2CarrierzonesSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"100\",\"createDate\":null,\"status\":\"SUCCESS\",\"totalRecord\":null,\"successCount\":null,\"errorCount\":null,\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertNpanxx2CarrierzonesSummary_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(any(), any(), anyInt());
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertNpanxx2CarrierzonesSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetNpanxx2CarrierzonesErrorRecordDetails() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> errorDeatils = new ArrayList<>();
        TFOneBulkInsertReport errorDetail = new TFOneBulkInsertReport();
        errorDetail.setStatus("COMPLETE");
        errorDetail.setSuccessCount("5");
        errorDetail.setErrorCount("0");
        errorDetail.setTotalRecord("5");
        errorDeatils.add(errorDetail);
        when(tracfoneControllerAction.getErrorRecordDetails(any())).thenReturn(errorDeatils);
        Response response = tracfoneOneCarrierWizardResource.getNpanxx2CarrierzonesErrorRecordDetails(tracfoneOneUserHistory);
        assertNotNull(response);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":\"5\",\"successCount\":\"5\",\"errorCount\":\"0\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetNpanxx2CarrierzonesErrorRecordDetails_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getErrorRecordDetails(any());
        Response response = tracfoneOneCarrierWizardResource.getNpanxx2CarrierzonesErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    /**
     * Sprint - 31
     */

    @Test
    public void testSearchArUsaPostalZips() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        tracfoneOneArUsaPostalZips.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZips.setKeyCode("1");
        tracfoneOneArUsaPostalZips.setPostalCode("2");
        tracfoneOneArUsaPostalZips.setState("SD");
        tracfoneOneArUsaPostalZips.setCity("sd");


        List<TFOneArUsaPostalZips> tfOneArUsaPostalZips = new ArrayList<>();
        TFOneArUsaPostalZips tfOneArUsaPostalZip = new TFOneArUsaPostalZips();
        tfOneArUsaPostalZip.setKeyCode("1");
        tfOneArUsaPostalZip.setPostalCode("2");
        tfOneArUsaPostalZip.setState("SD");
        tfOneArUsaPostalZip.setCity("sd");
        tfOneArUsaPostalZips.add(tfOneArUsaPostalZip);
        when(tracfoneCarrierMaintenanceController.getArUsaPostalZips(any())).thenReturn(tfOneArUsaPostalZips);
        Response response = tracfoneOneCarrierWizardResource.getArUsaPostalZips(tracfoneOneArUsaPostalZips);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"postalCode\":\"2\",\"keyCode\":\"1\",\"state\":\"SD\",\"city\":\"sd\"}]", response.getEntity().toString());
    }

    @Test
    public void testSearchArUsaPostalZips_whenException() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).getArUsaPostalZips(any());
        Response response = tracfoneOneCarrierWizardResource.getArUsaPostalZips(tracfoneOneArUsaPostalZips);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testinsertArUsaPostalZips() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        tracfoneOneArUsaPostalZips.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZips.setKeyCode("1");
        tracfoneOneArUsaPostalZips.setPostalCode("2");
        tracfoneOneArUsaPostalZips.setState("SD");
        tracfoneOneArUsaPostalZips.setCity("sd");
        when(tracfoneCarrierMaintenanceController.insertArUsaPostalZips(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertArUsaPostalZips(tracfoneOneArUsaPostalZips);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testinsertArUsaPostalZips_whenException() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertArUsaPostalZips(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertArUsaPostalZips(tracfoneOneArUsaPostalZips);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testdeleteArUsaPostalZips() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        tracfoneOneArUsaPostalZips.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZips.setKeyCode("1");
        tracfoneOneArUsaPostalZips.setPostalCode("2");
        tracfoneOneArUsaPostalZips.setState("SD");
        tracfoneOneArUsaPostalZips.setCity("sd");
        when(tracfoneCarrierMaintenanceController.deleteArUsaPostalZips(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.deleteArUsaPostalZips(tracfoneOneArUsaPostalZips);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testdeleteArUsaPostalZips_whenException() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).deleteArUsaPostalZips(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.deleteArUsaPostalZips(tracfoneOneArUsaPostalZips);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testUpdateArUsaPostalZips() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        tracfoneOneArUsaPostalZips.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZips.setKeyCode("1");
        tracfoneOneArUsaPostalZips.setPostalCode("2");
        tracfoneOneArUsaPostalZips.setState("SD");
        tracfoneOneArUsaPostalZips.setCity("sd");
        when(tracfoneCarrierMaintenanceController.updateArUsaPostalZips(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateArUsaPostalZips(tracfoneOneArUsaPostalZips);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateArUsaPostalZips_whenException() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateArUsaPostalZips(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateArUsaPostalZips(tracfoneOneArUsaPostalZips);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testbulkUpdateArUsaPostalZips() throws TracfoneOneException {
        List<TracfoneOneArUsaPostalZips> tracfoneOneArUsaPostalZips = new ArrayList<>();
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZip = new TracfoneOneArUsaPostalZips();
        tracfoneOneArUsaPostalZip.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZip.setKeyCode("1");
        tracfoneOneArUsaPostalZip.setPostalCode("2");
        tracfoneOneArUsaPostalZip.setState("SD");
        tracfoneOneArUsaPostalZip.setCity("sd");
        tracfoneOneArUsaPostalZip.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZip.setKeyCode("2");
        tracfoneOneArUsaPostalZip.setPostalCode("2");
        tracfoneOneArUsaPostalZip.setState("SD");
        tracfoneOneArUsaPostalZip.setCity("sd");
        tracfoneOneArUsaPostalZips.add(tracfoneOneArUsaPostalZip);
        when(tracfoneCarrierMaintenanceController.bulkUpdateArUsaPostalZips(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.bulkUpdateArUsaPostalZips(tracfoneOneArUsaPostalZips);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testbulkUpdateArUsaPostalZips_whenException() throws TracfoneOneException {
        List<TracfoneOneArUsaPostalZips> tracfoneOneArUsaPostalZips = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkUpdateArUsaPostalZips(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.bulkUpdateArUsaPostalZips(tracfoneOneArUsaPostalZips);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }


    @Test
    public void testSearchArUsaMarketDetails() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        tracfoneOneArUsaMarket.setDbEnv(DBENV);
        tracfoneOneArUsaMarket.setKeyCode("8404611100");
        tracfoneOneArUsaMarket.setCarrierEntity("T-Mobile USA");


        TFOneArUsaMarketSearchResult arUsaMarketSearch = new TFOneArUsaMarketSearchResult();
        TFOneArUsaMarket tfOneArUsaMarket = new TFOneArUsaMarket();
        tfOneArUsaMarket.setKeyCode("8404611100");
        tfOneArUsaMarket.setCarrierEntity("T-Mobile USA");
        arUsaMarketSearch.getArUsaMarkets().add(tfOneArUsaMarket);
        when(tracfoneCarrierMaintenanceController.getArUsaMarketDetails(any())).thenReturn(arUsaMarketSearch);
        Response response = tracfoneOneCarrierWizardResource.getArUsaMarketDetails(tracfoneOneArUsaMarket);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"paginationSearch\":null,\"arUsaMarkets\":[{\"keyCode\":\"8404611100\",\"nation\":null,\"state\":null,\"county\":null,\"carrierEntity\":\"T-Mobile USA\",\"marketingName\":null,\"mhzTotal\":null,\"spectrumBlocks\":null,\"cmaMktCode\":null,\"cmaMktState\":null,\"cmaMktName\":null,\"cmaMktNameAlternate\":null,\"cmaMktMultiState\":null,\"btaMktCode\":null,\"btaMktState\":null,\"btaMktName\":null,\"btaMktNameAlternate\":null,\"btaMktMultiState\":null,\"beaMktCode\":null,\"beaMktState\":null,\"beaMktName\":null,\"beaMktNameAlternate\":null,\"beaMktMultiState\":null,\"protocol\":null,\"extendedServices\":null,\"bid1\":null,\"bid1Name\":null,\"bid1Bsid1\":null,\"bid1Bsid2\":null,\"bid1Bsid3\":null,\"bid1Mnc\":null,\"bid2\":null,\"bid2Name\":null,\"bid2Bsid1\":null,\"bid2Bsid2\":null,\"bid2Bsid3\":null,\"bid2Mnc\":null,\"bid3\":null,\"bid3Name\":null,\"bid3Bsid1\":null,\"bid3Bsid2\":null,\"bid3Bsid3\":null,\"bid3Mnc\":null,\"bid4\":null,\"bid4Name\":null,\"bid4Bsid1\":null,\"bid4Bsid2\":null,\"bid4Bsid3\":null,\"bid4Mnc\":null,\"oldKeyCode\":null,\"oldCarrierEntity\":null}]}", response.getEntity().toString());
    }

    @Test
    public void testSearchArUsaMarketDetails_whenException() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).getArUsaMarketDetails(any());
        Response response = tracfoneOneCarrierWizardResource.getArUsaMarketDetails(tracfoneOneArUsaMarket);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testinsertArUsaMarketDetails() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        tracfoneOneArUsaMarket.setDbEnv(DBENV);
        tracfoneOneArUsaMarket.setKeyCode("8404611100");
        tracfoneOneArUsaMarket.setCarrierEntity("T-Mobile USA");
        when(tracfoneCarrierMaintenanceController.insertArUsaMarketDetails(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertArUsaMarketDetails(tracfoneOneArUsaMarket);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testinsertArUsaMarketDetails_whenException() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertArUsaMarketDetails(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertArUsaMarketDetails(tracfoneOneArUsaMarket);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testdeleteArUsaMarketDetails() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        tracfoneOneArUsaMarket.setDbEnv(DBENV);
        tracfoneOneArUsaMarket.setKeyCode("8404611100");
        tracfoneOneArUsaMarket.setCarrierEntity("T-Mobile USA");
        when(tracfoneCarrierMaintenanceController.deleteArUsaMarketDetails(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.deleteArUsaMarketDetails(tracfoneOneArUsaMarket);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testdeleteArUsaMarketDetails_whenException() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).deleteArUsaMarketDetails(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.deleteArUsaMarketDetails(tracfoneOneArUsaMarket);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testUpdateArUsaMarketDetails() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        tracfoneOneArUsaMarket.setDbEnv(DBENV);
        tracfoneOneArUsaMarket.setKeyCode("8404611100");
        tracfoneOneArUsaMarket.setCarrierEntity("T-Mobile USA");
        tracfoneOneArUsaMarket.setOldKeyCode("8404611101");
        tracfoneOneArUsaMarket.setOldCarrierEntity("T-Mobile USA");
        when(tracfoneCarrierMaintenanceController.updateArUsaMarketDetails(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateArUsaMarketDetails(tracfoneOneArUsaMarket);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateArUsaMarketDetails_whenException() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateArUsaMarketDetails(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateArUsaMarketDetails(tracfoneOneArUsaMarket);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testBulkinsertArUsaMarket() throws TracfoneOneException {
        doNothing().when(tracfoneCarrierMaintenanceController).bulkInsertArUsaMarket(any(), anyInt(), any());
        List<TracfoneOneArUsaMarket> tracfoneOneArUsaMarkets = new ArrayList<>();
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        tracfoneOneArUsaMarket.setDbEnv(DBENV);
        tracfoneOneArUsaMarket.setKeyCode("8404611100");
        tracfoneOneArUsaMarket.setCarrierEntity("T-Mobile USA");
        tracfoneOneArUsaMarkets.add(tracfoneOneArUsaMarket);
        Response response = tracfoneOneCarrierWizardResource.bulkInsertArUsaMarket(tracfoneOneArUsaMarkets);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"Success\",\"message\":\"Success\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkinserArUsaMarket_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkInsertArUsaMarket(any(), anyInt(), any());
        List<TracfoneOneArUsaMarket> tracfoneOneArUsaMarkets = new ArrayList<>();
        Response response = tracfoneOneCarrierWizardResource.bulkInsertArUsaMarket(tracfoneOneArUsaMarkets);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertArUsaMarketSummary() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv(DBENV);
        List<TFOneBulkInsertReport> tfOneBulkInsertReports = new ArrayList<>();
        TFOneBulkInsertReport tfOneBulkInsertReport = new TFOneBulkInsertReport();
        tfOneBulkInsertReport.setId("100");
        tfOneBulkInsertReport.setStatus("SUCCESS");
        tfOneBulkInsertReports.add(tfOneBulkInsertReport);
        when(tracfoneControllerAction.getBulkInsertSummary(any(), any(), anyInt())).thenReturn(tfOneBulkInsertReports);
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertArUsaMarketSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"100\",\"createDate\":null,\"status\":\"SUCCESS\",\"totalRecord\":null,\"successCount\":null,\"errorCount\":null,\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertArUsaMarketSummary_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(any(), any(), anyInt());
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertArUsaMarketSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetArUsaMarketCarrierzonesErrorRecordDetails() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> errorDeatils = new ArrayList<>();
        TFOneBulkInsertReport errorDetail = new TFOneBulkInsertReport();
        errorDetail.setStatus("COMPLETE");
        errorDetail.setSuccessCount("5");
        errorDetail.setErrorCount("0");
        errorDetail.setTotalRecord("5");
        errorDeatils.add(errorDetail);
        when(tracfoneControllerAction.getErrorRecordDetails(any())).thenReturn(errorDeatils);
        Response response = tracfoneOneCarrierWizardResource.getArUsaMarketErrorRecordDetails(tracfoneOneUserHistory);
        assertNotNull(response);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":\"5\",\"successCount\":\"5\",\"errorCount\":\"0\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetArUsaMarketCarrierzonesErrorRecordDetails_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getErrorRecordDetails(any());
        Response response = tracfoneOneCarrierWizardResource.getArUsaMarketErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testBulkinsertArUsaPostalZips() throws TracfoneOneException {
        doNothing().when(tracfoneCarrierMaintenanceController).bulkInsertArUsaPostalZips(any(), anyInt(), any());
        List<TracfoneOneArUsaPostalZips> tracfoneOneArUsaPostalZips = new ArrayList<>();
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZip = new TracfoneOneArUsaPostalZips();
        tracfoneOneArUsaPostalZip.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZip.setKeyCode("1");
        tracfoneOneArUsaPostalZip.setPostalCode("2");
        tracfoneOneArUsaPostalZip.setState("SD");
        tracfoneOneArUsaPostalZip.setCity("sd");
        tracfoneOneArUsaPostalZip.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZip.setKeyCode("2");
        tracfoneOneArUsaPostalZip.setPostalCode("2");
        tracfoneOneArUsaPostalZip.setState("SD");
        tracfoneOneArUsaPostalZip.setCity("sd");
        tracfoneOneArUsaPostalZips.add(tracfoneOneArUsaPostalZip);
        Response response = tracfoneOneCarrierWizardResource.bulkInsertArUsaPostalZips(tracfoneOneArUsaPostalZips);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"Success\",\"message\":\"Success\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkinserCarrierzones_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkInsertArUsaPostalZips(any(), anyInt(), any());
        List<TracfoneOneArUsaPostalZips> tracfoneOneArUsaPostalZips = new ArrayList<>();
        Response response = tracfoneOneCarrierWizardResource.bulkInsertArUsaPostalZips(tracfoneOneArUsaPostalZips);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertArUsaPostalZipsSummary() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv(DBENV);
        List<TFOneBulkInsertReport> tfOneBulkInsertReports = new ArrayList<>();
        TFOneBulkInsertReport tfOneBulkInsertReport = new TFOneBulkInsertReport();
        tfOneBulkInsertReport.setId("100");
        tfOneBulkInsertReport.setStatus("SUCCESS");
        tfOneBulkInsertReports.add(tfOneBulkInsertReport);
        when(tracfoneControllerAction.getBulkInsertSummary(any(), any(), anyInt())).thenReturn(tfOneBulkInsertReports);
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertArUsaPostalZipsSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"100\",\"createDate\":null,\"status\":\"SUCCESS\",\"totalRecord\":null,\"successCount\":null,\"errorCount\":null,\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertArUsaPostalZipsSummary_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(any(), any(), anyInt());
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertArUsaPostalZipsSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetArUsaPostalZipsCarrierzonesErrorRecordDetails() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> errorDeatils = new ArrayList<>();
        TFOneBulkInsertReport errorDetail = new TFOneBulkInsertReport();
        errorDetail.setStatus("COMPLETE");
        errorDetail.setSuccessCount("5");
        errorDetail.setErrorCount("0");
        errorDetail.setTotalRecord("5");
        errorDeatils.add(errorDetail);
        when(tracfoneControllerAction.getErrorRecordDetails(any())).thenReturn(errorDeatils);
        Response response = tracfoneOneCarrierWizardResource.getArUsaPostalZipsErrorRecordDetails(tracfoneOneUserHistory);
        assertNotNull(response);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":\"5\",\"successCount\":\"5\",\"errorCount\":\"0\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetArUsaPostalZipsCarrierzonesErrorRecordDetails_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getErrorRecordDetails(any());
        Response response = tracfoneOneCarrierWizardResource.getArUsaPostalZipsErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testAddGeoLoc() throws TracfoneOneException {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        tfOneGeoLoc.setZip("11122");
        tfOneGeoLoc.setRzg2user("1");
        tfOneGeoLoc.setCrlatitude("11122");
        tfOneGeoLoc.setLongitude("11122");
        when(tracfoneCarrierMaintenanceController.insertGeoLoc(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.addGeoLoc(tfOneGeoLoc);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testAddGeoLoc_whenException() throws TracfoneOneException {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertGeoLoc(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.addGeoLoc(tfOneGeoLoc);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testDeleteGeoLoc() throws TracfoneOneException {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        tfOneGeoLoc.setZip("11122");
        tfOneGeoLoc.setRzg2user("1");
        tfOneGeoLoc.setCrlatitude("11122");
        tfOneGeoLoc.setLongitude("11122");
        when(tracfoneCarrierMaintenanceController.deleteGeoLoc(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.deleteGeoLoc(tfOneGeoLoc);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteGeoLoc_whenException() throws TracfoneOneException {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).deleteGeoLoc(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.deleteGeoLoc(tfOneGeoLoc);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetUsers() throws TracfoneOneException {
        List<String> userData = new ArrayList<>();
        userData.add("1");
        userData.add("2");
        when(tracfoneCarrierMaintenanceController.getUsers()).thenReturn(userData);
        Response response = tracfoneOneCarrierWizardResource.getUsers();
        assertNotNull(response);
        assertEquals("[\"1\",\"2\"]", response.getEntity().toString());
    }

    @Test
    public void testGetUsers_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).getUsers();
        Response response = tracfoneOneCarrierWizardResource.getUsers();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertGeoLocSummary() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv(DBENV);
        List<TFOneBulkInsertReport> tfOneBulkInsertReports = new ArrayList<>();
        TFOneBulkInsertReport tfOneBulkInsertReport = new TFOneBulkInsertReport();
        tfOneBulkInsertReport.setId("100");
        tfOneBulkInsertReport.setStatus("SUCCESS");
        tfOneBulkInsertReports.add(tfOneBulkInsertReport);
        when(tracfoneControllerAction.getBulkInsertSummary(any(), any(), anyInt())).thenReturn(tfOneBulkInsertReports);
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertNpanxx2CarrierzonesSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"100\",\"createDate\":null,\"status\":\"SUCCESS\",\"totalRecord\":null,\"successCount\":null,\"errorCount\":null,\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertGeoLocSummary_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(any(), any(), anyInt());
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertNpanxx2CarrierzonesSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetGeoLocErrorRecordDetails() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> errorDeatils = new ArrayList<>();
        TFOneBulkInsertReport errorDetail = new TFOneBulkInsertReport();
        errorDetail.setStatus("COMPLETE");
        errorDetail.setSuccessCount("5");
        errorDetail.setErrorCount("0");
        errorDetail.setTotalRecord("5");
        errorDeatils.add(errorDetail);
        when(tracfoneControllerAction.getErrorRecordDetails(any())).thenReturn(errorDeatils);
        Response response = tracfoneOneCarrierWizardResource.getNpanxx2CarrierzonesErrorRecordDetails(tracfoneOneUserHistory);
        assertNotNull(response);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":\"5\",\"successCount\":\"5\",\"errorCount\":\"0\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetGeoLocErrorRecordDetails_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getErrorRecordDetails(any());
        Response response = tracfoneOneCarrierWizardResource.getNpanxx2CarrierzonesErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testSearchGeoLoc() throws TracfoneOneException {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        tfOneGeoLoc.setZip("1231");

        List<TFOneGeoLoc> tfOneGeoLocs = new ArrayList<>(1);
        TFOneGeoLoc tfGeoLoc = new TFOneGeoLoc();
        tfGeoLoc.setRzg2user("121");
        tfOneGeoLocs.add(tfGeoLoc);
        when(tracfoneCarrierMaintenanceController.searchGeoLoc(any())).thenReturn(tfOneGeoLocs);
        Response response = tracfoneOneCarrierWizardResource.searchGeoLoc(tfOneGeoLoc);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"zip\":null,\"state\":null,\"popcy\":null,\"pop05\":null,\"latitude\":null,\"longitude\":null,\"rlatitude\":null,\"rlongitude\":null,\"srlatitude\":null,\"crlatitude\":null,\"rzg2user\":\"121\",\"insertDate\":null,\"updateDate\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchGeoLoc_whenException() throws TracfoneOneException {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchGeoLoc(any());
        Response response = tracfoneOneCarrierWizardResource.searchGeoLoc(tfOneGeoLoc);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateGeoLoc() throws TracfoneOneException {
        TracfoneOneGeoLoc tfGeoLoc = new TracfoneOneGeoLoc();
        tfGeoLoc.setZip("1231");
        tfGeoLoc.setOldZip("1223");
        when(tracfoneCarrierMaintenanceController.updateGeoLoc(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateGeoLoc(tfGeoLoc);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateGeoLoc_whenException() throws TracfoneOneException {
        TracfoneOneGeoLoc tfGeoLoc = new TracfoneOneGeoLoc();
        tfGeoLoc.setOldZip("213");
        tfGeoLoc.setZip("213");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateGeoLoc(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateGeoLoc(tfGeoLoc);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testBulkUpdateGeoLoc() throws TracfoneOneException {
        List<TracfoneOneGeoLoc> geoLocs = new ArrayList<>();
        TracfoneOneGeoLoc tfGeoLoc = new TracfoneOneGeoLoc();
        tfGeoLoc.setZip("1231");
        tfGeoLoc.setOldZip("1223");
        geoLocs.add(tfGeoLoc);
        when(tracfoneCarrierMaintenanceController.bulkUpdateGeoLoc(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.bulkUpdateGeoLoc(geoLocs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkUpdateGeoLoc_whenException() throws TracfoneOneException {
        List<TracfoneOneGeoLoc> geoLocs = new ArrayList<>();
        TracfoneOneGeoLoc tfGeoLoc = new TracfoneOneGeoLoc();
        tfGeoLoc.setZip("1231");
        tfGeoLoc.setOldZip("1223");
        geoLocs.add(tfGeoLoc);
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkUpdateGeoLoc(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.bulkUpdateGeoLoc(geoLocs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierzones() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");

        List<TFOneCarrierZones> tfOneCarrierzones = new ArrayList<>();
        TFOneCarrierZones tfOneCarrierzone = new TFOneCarrierZones();
        tfOneCarrierzone.setZipCode("4");
        tfOneCarrierzone.setState("1");
        tfOneCarrierzone.setZone("2");
        tfOneCarrierzone.setCounty("1");
        tfOneCarrierzone.setCarrierName("1");
        tfOneCarrierzones.add(tfOneCarrierzone);
        when(tracfoneCarrierMaintenanceController.searchCarrierzones(any())).thenReturn(tfOneCarrierzones);
        Response response = tracfoneOneCarrierWizardResource.searchCarrierzones(tracfoneOneCarrierZones);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"zipCode\":\"4\",\"state\":\"1\",\"county\":\"1\",\"zone\":\"2\",\"rateCente\":null,\"marketId\":null,\"marketArea\":null,\"city\":null,\"btaMarketNumber\":null,\"btaMarketName\":null,\"carrierId\":null,\"carrierName\":\"1\",\"zipStatus\":null,\"simProfile\":null,\"simProfile2\":null,\"planType\":null}]", response.getEntity().toString());
    }

    @Test
    public void testCarrierzones_whenException() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchCarrierzones(any());
        Response response = tracfoneOneCarrierWizardResource.searchCarrierzones(tracfoneOneCarrierZones);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierzones() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        when(tracfoneCarrierMaintenanceController.insertCarrierzones(any(),anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertCarrierzones(tracfoneOneCarrierZones);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierzones_whenException() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertCarrierzones(any(),anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertCarrierzones(tracfoneOneCarrierZones);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testDeleteCarrierzones() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        when(tracfoneCarrierMaintenanceController.deleteCarrierzones(any(),anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.deleteCarrierzones(tracfoneOneCarrierZones);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteCarrierzones_whenException() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).deleteCarrierzones(any(),anyInt());
        Response response = tracfoneOneCarrierWizardResource.deleteCarrierzones(tracfoneOneCarrierZones);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierzones() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        when(tracfoneCarrierMaintenanceController.updateCarrierzones(any(),anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateCarrierzones(tracfoneOneCarrierZones);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierzones_whenException() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateCarrierzones(any(),anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateCarrierzones(tracfoneOneCarrierZones);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testbulkUpdateCarrierzones() throws TracfoneOneException {
        List<TracfoneOneCarrierZones> tracfoneOneCarrierZone = new ArrayList<>();
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        tracfoneOneCarrierZone.add(tracfoneOneCarrierZones);
        when(tracfoneCarrierMaintenanceController.bulkUpdateCarrierZones(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.bulkUpdateCarrierZones(tracfoneOneCarrierZone);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testbulkUpdateCarrierzones_whenException() throws TracfoneOneException {
        List<TracfoneOneCarrierZones> tracfoneOneCarrierZone = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkUpdateCarrierZones(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.bulkUpdateCarrierZones(tracfoneOneCarrierZone);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInserCarrierzonesSummary() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv(DBENV);
        List<TFOneBulkInsertReport> tfOneBulkInsertReports = new ArrayList<>();
        TFOneBulkInsertReport tfOneBulkInsertReport = new TFOneBulkInsertReport();
        tfOneBulkInsertReport.setId("100");
        tfOneBulkInsertReport.setStatus("SUCCESS");
        tfOneBulkInsertReports.add(tfOneBulkInsertReport);
        when(tracfoneControllerAction.getBulkInsertSummary(any(), any(), anyInt())).thenReturn(tfOneBulkInsertReports);
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertCarrierzonesSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"100\",\"createDate\":null,\"status\":\"SUCCESS\",\"totalRecord\":null,\"successCount\":null,\"errorCount\":null,\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertCarrierzonesSummary_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(any(), any(), anyInt());
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        Response response = tracfoneOneCarrierWizardResource.getBulkInsertCarrierzonesSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierzonesErrorRecordDetails() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> errorDeatils = new ArrayList<>();
        TFOneBulkInsertReport errorDetail = new TFOneBulkInsertReport();
        errorDetail.setStatus("COMPLETE");
        errorDetail.setSuccessCount("5");
        errorDetail.setErrorCount("0");
        errorDetail.setTotalRecord("5");
        errorDeatils.add(errorDetail);
        when(tracfoneControllerAction.getErrorRecordDetails(any())).thenReturn(errorDeatils);
        Response response = tracfoneOneCarrierWizardResource.getCarrierzonesErrorRecordDetails(tracfoneOneUserHistory);
        assertNotNull(response);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":\"5\",\"successCount\":\"5\",\"errorCount\":\"0\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierzonesErrorRecordDetails_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getErrorRecordDetails(any());
        Response response = tracfoneOneCarrierWizardResource.getCarrierzonesErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierPref() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        List<TFOneCarrierPref> tfOneCarrierPrefs = new ArrayList<>();
        TFOneCarrierPref tfOneCarrierPref = new TFOneCarrierPref();
        tfOneCarrierPref.setState("SD");
        tfOneCarrierPref.setCounty("TEST");
        tfOneCarrierPref.setCarrierId("1235");
        tfOneCarrierPref.setCarrierName("test");
        tfOneCarrierPref.setCarrierRank("test");
        tfOneCarrierPref.setNewRank("123");
        tfOneCarrierPrefs.add(tfOneCarrierPref);
        when(tracfoneCarrierMaintenanceController.searchCarrierpref(any())).thenReturn(tfOneCarrierPrefs);
        Response response = tracfoneOneCarrierWizardResource.searchCarrierpref(tracfoneOneCarrierPref);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"state\":\"SD\",\"county\":\"TEST\",\"carrierId\":\"1235\",\"carrierName\":\"test\",\"carrierRank\":\"test\",\"newRank\":\"123\"}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierPref_whenException() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchCarrierpref(any());
        Response response = tracfoneOneCarrierWizardResource.searchCarrierpref(tracfoneOneCarrierPref);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testinsertCarrierPref() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        when(tracfoneCarrierMaintenanceController.insertCarrierpref(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.insertCarrierpref(tracfoneOneCarrierPref);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testinsertCarrierPref_whenException() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).insertCarrierpref(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.insertCarrierpref(tracfoneOneCarrierPref);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testdeleteCarrierPref() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        when(tracfoneCarrierMaintenanceController.deleteCarrierpref(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.deleteCarrierpref(tracfoneOneCarrierPref);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testdeleteCarrierPref_whenException() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).deleteCarrierpref(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.deleteCarrierpref(tracfoneOneCarrierPref);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierPref() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        when(tracfoneCarrierMaintenanceController.updateCarrierpref(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.updateCarrierpref(tracfoneOneCarrierPref);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierPref_whenException() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).updateCarrierpref(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.updateCarrierpref(tracfoneOneCarrierPref);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testbulkUpdateCarrierPref() throws TracfoneOneException {
        List<TracfoneOneCarrierPref> tracfoneOneCarrierPrefs = new ArrayList<>();
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        tracfoneOneCarrierPrefs.add(tracfoneOneCarrierPref);
        when(tracfoneCarrierMaintenanceController.bulkUpdateCarrierpref(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneCarrierWizardResource.bulkUpdateCarrierpref(tracfoneOneCarrierPrefs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testbulkUpdateCarrierPref_whenException() throws TracfoneOneException {
        List<TracfoneOneCarrierPref> tracfoneOneCarrierPrefs = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkUpdateCarrierpref(any(), anyInt());
        Response response = tracfoneOneCarrierWizardResource.bulkUpdateCarrierpref(tracfoneOneCarrierPrefs);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkinsertCarrierPref() throws TracfoneOneException {
        doNothing().when(tracfoneCarrierMaintenanceController).bulkInsertCarrierpref(any(), anyInt(),any());
        List<TracfoneOneCarrierPref> tracfoneOneCarrierPrefs = new ArrayList<>();
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        tracfoneOneCarrierPrefs.add(tracfoneOneCarrierPref);
        Response response = tracfoneOneCarrierWizardResource.bulkInsertCarrierpref(tracfoneOneCarrierPrefs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"Success\",\"message\":\"Success\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkinserCarrierPref_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).bulkInsertCarrierpref(any(), anyInt(),any());
        List<TracfoneOneCarrierPref> tracfoneOneCarrierPrefs = new ArrayList<>();
        Response response = tracfoneOneCarrierWizardResource.bulkInsertCarrierpref(tracfoneOneCarrierPrefs);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierPrefErrorRecordDetails() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> errorDeatils = new ArrayList<>();
        TFOneBulkInsertReport errorDetail = new TFOneBulkInsertReport();
        errorDetail.setStatus("COMPLETE");
        errorDetail.setSuccessCount("5");
        errorDetail.setErrorCount("0");
        errorDetail.setTotalRecord("5");
        errorDeatils.add(errorDetail);
        when(tracfoneControllerAction.getErrorRecordDetails(any())).thenReturn(errorDeatils);
        Response response = tracfoneOneCarrierWizardResource.getCarrierprefErrorRecordDetails(tracfoneOneUserHistory);
        assertNotNull(response);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":\"5\",\"successCount\":\"5\",\"errorCount\":\"0\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierPrefErrorRecordDetails_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getErrorRecordDetails(any());
        Response response = tracfoneOneCarrierWizardResource.getCarrierprefErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

}