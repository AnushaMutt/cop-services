package com.tracfone.service;

import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.controller.TracfoneOneUserReportingControllerLocal;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneUserTask;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneUserReporting;
import com.tracfone.service.model.response.TFOneUserTask;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneUserReportingResourceTest {

    public final String JSON = "application/json";

    @InjectMocks
    TracfoneOneUserReportingResource tracfoneOneUserReportingResource;

    @Mock
    private TracfoneControllerLocal tracfoneController;

    @Mock
    private SecurityContext securityContext;
    @Mock
    private TracfoneOnePrincipal principal;
    @Mock
    private TFOneAdminUser user;

    @Mock
    private TracfoneControllerLocalAction tracfoneControllerAction;

    @Mock
    private TracfoneOneUserReportingControllerLocal tracfoneOneUserReportingController;

    private TracfoneOneException tracfoneOneException;
    private TracfoneOneAuthorizationException tracfoneOneAuthorizationException;
    private TFOneGeneralResponse tFOneGeneralResponse;

    @Before
    public void setUp() {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        tracfoneOneAuthorizationException = new TracfoneOneAuthorizationException("TFE0", "dummy_auth_error_message");
        when(securityContext.getUserPrincipal()).thenReturn(principal);
        when(principal.getTFUser()).thenReturn(user);
    }

    @Test
    public void testGetAllUsers() throws TracfoneOneException, TracfoneOneAuthorizationException {
        List<TFOneAdminUser> tfOneAdminUsers = new ArrayList<>();
        TFOneAdminUser tfOneAdminUser = new TFOneAdminUser();
        tfOneAdminUser.setUserName("GSHARMA");
        tfOneAdminUser.setUserId(543);
        tfOneAdminUser.setDescription("DESC");
        tfOneAdminUsers.add(tfOneAdminUser);
        when(tracfoneController.getAllUsers(any())).thenReturn(tfOneAdminUsers);
        Response response = tracfoneOneUserReportingResource.getAllUsers();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"userId\":543,\"userName\":\"GSHARMA\",\"email\":null,\"token\":null,\"description\":\"DESC\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllUsers_whenException() throws TracfoneOneException, TracfoneOneAuthorizationException {
        doThrow(tracfoneOneException).when(tracfoneController).getAllUsers(any());
        Response response = tracfoneOneUserReportingResource.getAllUsers();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetAllUsers_whenAuthException() throws TracfoneOneException, TracfoneOneAuthorizationException {
        doThrow(tracfoneOneAuthorizationException).when(tracfoneController).getAllUsers(any());
        Response response = tracfoneOneUserReportingResource.getAllUsers();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_auth_error_message\",\"httpCode\":401}", response.getEntity().toString());
    }

    @Test
    public void updateUserTask() throws TracfoneOneException {
        List<String> status = new ArrayList<>();
        status.add("COMPLETED");
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setAssignedUserId("381");
        tfOneUserTask.setDescription("DESC");
        tfOneUserTask.setId("381");
        tfOneUserTask.setStatus(status);
        tfOneUserTask.setTaskName("TASK_NAME");
        tfOneUserTask.setType("TYPE");
        tfOneUserTask.setUserId("381");

        TFOneUserTask tfUserTask = new TFOneUserTask();
        tfUserTask.setAssignedUserId("381");
        tfUserTask.setDescription("DESC");
        tfUserTask.setId("381");
        tfUserTask.setStatus(status);
        tfUserTask.setTaskName("TASK_NAME");
        tfUserTask.setType("TYPE");
        tfUserTask.setUserId("381");
        when(tracfoneControllerAction.updateUserTask(any(), anyInt())).thenReturn(tfUserTask);
        Response response = tracfoneOneUserReportingResource.updateUserTask(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"id\":\"381\",\"taskName\":\"TASK_NAME\",\"description\":\"DESC\",\"userId\":\"381\",\"assignedUserId\":\"381\",\"assignedUserName\":null,\"type\":\"TYPE\",\"status\":[\"COMPLETED\"],\"creationDate\":null,\"tfOneUserTaskDetail\":[]}", response.getEntity().toString());
    }

    @Test
    public void testUpdateEndTime_whenException() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        doThrow(tracfoneOneException).when(tracfoneControllerAction).updateUserTask(any(), anyInt());
        Response response = tracfoneOneUserReportingResource.updateUserTask(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetUserTask() throws TracfoneOneException {
        List<String> status = new ArrayList<>();
        status.add("COMPLETED");
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setAssignedUserId("381");
        tfOneUserTask.setDescription("DESC");
        tfOneUserTask.setId("381");
        tfOneUserTask.setStatus(status);
        tfOneUserTask.setTaskName("TASK_NAME");
        tfOneUserTask.setType("TYPE");
        tfOneUserTask.setUserId("381");

        List<TFOneUserTask> tfUserTasks = new ArrayList<>();
        TFOneUserTask tfUserTask = new TFOneUserTask();
        tfUserTask.setAssignedUserId("381");
        tfUserTask.setDescription("DESC");
        tfUserTask.setId("381");
        tfUserTask.setStatus(status);
        tfUserTask.setTaskName("TASK_NAME");
        tfUserTask.setType("TYPE");
        tfUserTask.setUserId("381");
        tfUserTasks.add(tfUserTask);
        when(tracfoneOneUserReportingController.getAllUserTasks(any())).thenReturn(tfUserTasks);
        Response response = tracfoneOneUserReportingResource.getAllUserTasks(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"381\",\"taskName\":\"TASK_NAME\",\"description\":\"DESC\",\"userId\":\"381\",\"assignedUserId\":\"381\",\"assignedUserName\":null,\"type\":\"TYPE\",\"status\":[\"COMPLETED\"],\"creationDate\":null,\"tfOneUserTaskDetail\":[]}]", response.getEntity().toString());
    }

    @Test
    public void testGetUserTask_whenException() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        doThrow(tracfoneOneException).when(tracfoneOneUserReportingController).getAllUserTasks(any());
        Response response = tracfoneOneUserReportingResource.getAllUserTasks(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testReassignTransaction() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setAssignedUserId("381");
        tfOneUserTask.setId("381");
        when(tracfoneOneUserReportingController.reassignTransaction(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneUserReportingResource.reassignTransaction(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testReassignTransaction_whenException() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        doThrow(tracfoneOneException).when(tracfoneOneUserReportingController).reassignTransaction(any(), anyInt());
        Response response = tracfoneOneUserReportingResource.reassignTransaction(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testAssignTransactionReport() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setDbEnv("DB");
        tfOneUserTask.setAssignedUserId("381");
        tfOneUserTask.setToCreationDate("1/9/2020");
        tfOneUserTask.setFromCreationDate("1/10/2020");
        List<TFOneUserReporting> reports = new ArrayList<>();
        TFOneUserReporting report = new TFOneUserReporting();
        report.setStatus("ASSIGNED");
        report.setTasks(12L);
        report.setTransactions(34L);
        reports.add(report);
        when(tracfoneOneUserReportingController.assignTransactionReport(any())).thenReturn(reports);
        Response response = tracfoneOneUserReportingResource.assignTransactionReport(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"status\":\"ASSIGNED\",\"tasks\":12,\"transactions\":34}]", response.getEntity().toString());
    }

    @Test
    public void testAssignTransactionReport_whenException() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        doThrow(tracfoneOneException).when(tracfoneOneUserReportingController).assignTransactionReport(any());
        Response response = tracfoneOneUserReportingResource.assignTransactionReport(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testTransactionTypeReport() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setDbEnv("DB");
        tfOneUserTask.setAssignedUserId("381");
        tfOneUserTask.setToCreationDate("1/9/2020");
        tfOneUserTask.setFromCreationDate("1/10/2020");

        List<TFOneUserReporting> reports = new ArrayList<>();
        TFOneUserReporting report = new TFOneUserReporting();
        report.setStatus("INSERT");
        report.setTasks(12L);
        report.setTransactions(34L);
        reports.add(report);

        when(tracfoneOneUserReportingController.transactionTypeReport(any())).thenReturn(reports);
        Response response = tracfoneOneUserReportingResource.transactionTypeReport(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"status\":\"INSERT\",\"tasks\":12,\"transactions\":34}]", response.getEntity().toString());
    }

    @Test
    public void testTransactionTypeReport_whenException() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        doThrow(tracfoneOneException).when(tracfoneOneUserReportingController).transactionTypeReport(any());
        Response response = tracfoneOneUserReportingResource.transactionTypeReport(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }
}