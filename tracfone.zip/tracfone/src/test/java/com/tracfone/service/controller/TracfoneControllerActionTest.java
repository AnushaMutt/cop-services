package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneColumnDesc;
import com.tracfone.service.model.request.TracfoneOneNewTransaction;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.response.TFOneAdminActionItem;
import com.tracfone.service.model.response.TFOneBulkInsertReport;
import com.tracfone.service.model.response.TFOneColumnDesc;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGFailLogs;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneControllerActionTest {

    @InjectMocks
    TracfoneControllerAction tracfoneControllerAction;
    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private ResultSet resultSet;
    @Mock
    private TracfoneAudit audit;

    private TFOneGeneralResponse tfOneGeneralResponse;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

    @Test
    public void testGetBulkInsertReport() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("12345").thenReturn("2020-9-15.3.21. 41. 0").thenReturn("5_SF901879160");
        List<TFOneBulkInsertReport> reports = tracfoneControllerAction.getBulkInsertSummary("DBENV", "Bulk IG Insert", 34);
        assertNotNull(reports);
        assertEquals(2, reports.size());
        assertEquals("[TFOneBulkInsertReport{id='12345', createDate='2020-9-15.3.21. 41. 0', status='IN PROGRESS', totalRecord='5', successCount='0', errorCount='0', details='null', uniqueIdentifier='SF901879160'}, TFOneBulkInsertReport{id='5_SF901879160', createDate='5_SF901879160', status='IN PROGRESS', totalRecord='5', successCount='0', errorCount='0', details='null', uniqueIdentifier='SF901879160'}]", reports.toString());
    }

    @Test
    public void testGetBulkInsertReport_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneControllerAction.getBulkInsertSummary(null, null, 324);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            // expected
        }

        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneControllerAction.getBulkInsertSummary("DBENV", "Bulk IG Insert", 435);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetErrorRecordDetails() throws TracfoneOneException, SQLException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        tracfoneOneUserHistory.setId("324");

        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("5_SF901879160");
        List<TFOneBulkInsertReport> details = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        assertNotNull(details);
        assertEquals(1, details.size());
        assertEquals("[TFOneBulkInsertReport{id='5_SF901879160', createDate='5_SF901879160', status='null', totalRecord='null', successCount='null', errorCount='null', details='5_SF901879160', uniqueIdentifier='null'}]", details.toString());
    }

    @Test
    public void testGetErrorRecordDetails_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneControllerAction.getErrorRecordDetails(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            // expected
        }

        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        tracfoneOneUserHistory.setId("324");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetIgTransactionsInProgress() throws TracfoneOneException, SQLException {
        TracfoneOneNewTransaction tracfoneOneNewTransaction = new TracfoneOneNewTransaction();
        tracfoneOneNewTransaction.setDbenv("DBENV");
        tracfoneOneNewTransaction.setTransactionId("324");

        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("IG");
        List<TFOneAdminActionItem> tfOneAdminActionItem = tracfoneControllerAction.getIgTransactionsInProgress(tracfoneOneNewTransaction);
        assertNotNull(tfOneAdminActionItem);
        assertEquals(4, tfOneAdminActionItem.size());
    }

    @Test
    public void testGetIgTransactionsInProgress_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneControllerAction.getIgTransactionsInProgress(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            // expected
        }

        TracfoneOneNewTransaction tracfoneOneNewTransaction = new TracfoneOneNewTransaction();
        tracfoneOneNewTransaction.setDbenv("DBENV");
        tracfoneOneNewTransaction.setTransactionId("324");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneControllerAction.getIgTransactionsInProgress(tracfoneOneNewTransaction);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteIgTransactionInProgress() throws TracfoneOneException {
        TracfoneOneNewTransaction tracfoneOneNewTransaction = new TracfoneOneNewTransaction();
        tracfoneOneNewTransaction.setDbenv("DBENV");
        tracfoneOneNewTransaction.setTransactionId("324");
        tfOneGeneralResponse = tracfoneControllerAction.deleteIgTransactionInProgress(tracfoneOneNewTransaction, 1);
        assertEquals(TFOneGeneralResponse.SUCCESS, tfOneGeneralResponse.getStatus());
        assertEquals(tracfoneOneNewTransaction.getTransactionId(), tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testDeleteIgTransactionInProgress_whenException() throws SQLException {
        TracfoneOneNewTransaction tracfoneOneNewTransaction = new TracfoneOneNewTransaction();
        tracfoneOneNewTransaction.setDbenv("DBENV");
        tracfoneOneNewTransaction.setTransactionId("324");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneControllerAction.deleteIgTransactionInProgress(tracfoneOneNewTransaction, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetUserHistoryDetailByIdType() throws TracfoneOneException, TracfoneOneAuthorizationException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        TFOneGeneralResponse response = tracfoneControllerAction.getUserHistoryDetailByIdType("DBENV", "UNIQUE_KEY", 100);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals(null, response.getMessage());
    }

    @Test
    public void testGetUserHistoryDetailByIdType_whenException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneControllerAction.getUserHistoryDetailByIdType("DBENV", "UNIQUE_KEY", 100);
            fail();
        } catch (TracfoneOneException e) {
        }
    }

    @Test
    public void testGetIgFailLogs() throws TracfoneOneException, SQLException {
        TracfoneOneNewTransaction tracfoneOneNewTransaction = new TracfoneOneNewTransaction();
        tracfoneOneNewTransaction.setDbenv("DBENV");
        tracfoneOneNewTransaction.setActionItemId("324");

        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("IG");
        List<TFOneIGFailLogs> tfOneAdminActionItem = tracfoneControllerAction.getIgFailLogs(tracfoneOneNewTransaction);
        assertNotNull(tfOneAdminActionItem);
        assertEquals(4, tfOneAdminActionItem.size());
    }

    @Test
    public void testGetIgFailLogs_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneControllerAction.getIgTransactionsInProgress(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            // expected
        }

        TracfoneOneNewTransaction tracfoneOneNewTransaction = new TracfoneOneNewTransaction();
        tracfoneOneNewTransaction.setDbenv("DBENV");
        tracfoneOneNewTransaction.setActionItemId("324");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneControllerAction.getIgFailLogs(tracfoneOneNewTransaction);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetTableDesc() throws TracfoneOneException, SQLException {
        TracfoneOneColumnDesc tfColumnDesc = new TracfoneOneColumnDesc();
        tfColumnDesc.setDbEnv("DB");
        tfColumnDesc.setTableName("TABLE_NAME");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMAY_DATA");
        List<TFOneColumnDesc> columnDescList = tracfoneControllerAction.getTableDesc(tfColumnDesc);
        assertEquals("[TFOneColumnDesc{columnName='DUMMAY_DATA', dataType='DUMMAY_DATA', dataLength='DUMMAY_DATA', dataPrecision='DUMMAY_DATA', dataScale='DUMMAY_DATA'}]", columnDescList.toString());
    }

    @Test
    public void testGetTableDesc_withException() throws TracfoneOneException, SQLException {
        TracfoneOneColumnDesc tfColumnDesc = new TracfoneOneColumnDesc();
        tfColumnDesc.setDbEnv("DB");
        tfColumnDesc.setTableName("TABLE_NAME");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneControllerAction.getTableDesc(tfColumnDesc);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}