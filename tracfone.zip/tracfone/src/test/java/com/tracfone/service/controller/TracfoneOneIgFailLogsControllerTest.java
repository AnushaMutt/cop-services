package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneIgFailLogs;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGFailLogs;
import com.tracfone.service.model.response.TFOneIgFailLogSearchModel;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantIgFailLags.TRACFONE_GET_IG_FAIL_LOGS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantIgFailLags.TRACFONE_GET_IG_FAIL_LOGS_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneIgFailLogsControllerTest {
    private static final String DBENV = "DBENV";

    @InjectMocks
    TracfoneOneIgFailLogsController controller;

    @Mock
    TracfoneOneIgFailLogsActionLocal action;

    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "100");
        tracfoneOneException = new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
    }

    @Test
    public void testGetIgFailLogs() throws Exception {
        TFOneIgFailLogSearchModel tfOneIgFailLogSearchModel = new TFOneIgFailLogSearchModel();
        TracfoneOneIgFailLogs tracfoneOneIgFailLogs = new TracfoneOneIgFailLogs();
        tracfoneOneIgFailLogs.setDbEnv(DBENV);
        List<TFOneIGFailLogs> tfOneIGFailLogs = new ArrayList<>();
        TFOneIGFailLogs tfOneIGFailLog = new TFOneIGFailLogs();
        tfOneIGFailLog.setActionItemId("100");
        tfOneIGFailLogs.add(tfOneIGFailLog);
        tfOneIgFailLogSearchModel.setiGFailLogs(tfOneIGFailLogs);
        when(action.getIgFailLogs(any())).thenReturn(tfOneIgFailLogSearchModel);
        TFOneIgFailLogSearchModel response = controller.getIgFailLogs(tracfoneOneIgFailLogs);
        assertEquals("TFOneIgFailLogSearchModel{paginationSearch=null, iGFailLogs=[TFOneIGFailLogs{callTransActionType='null', actionItemId='100', carrierId='null', orderType='null', min='null', esn='null', esnPartClassModel='null', esnHex='null', oldEsn='null', oldEsnHex='null', pin='null', phoneManf='null', endUser='null', accountNum='null', marketCode='null', ratePlan='null', ldProvider='null', sequenceNum='null', dealerCode='null', transmissionMethod='null', faxNum='null', onlineNum='null', email='null', networkLogin='null', networkPassword='null', systemLogin='null', systemPassword='null', template='null', exeName='null', comPort='null', status='null', statusMessage='null', faxBatchSize='null', faxBatchQtime='null', expidite='null', transProfKey='null', qTransaction='null', onlineNum2='null', faxNum2='null', creationDate='null', updateDate='null', igDbSecsToComp='null', blackoutWait='null', tuxItiServer='null', transactionId='null', technologyFlag='null', voiceMail='null', voiceMailPackage='null', callerId='null', carrierAccountId='null', tmoNextGenFlag='null', callerIdPackage='null', callWaiting='null', callWaitingPackage='null', rtpServer='null', digitalFeatureCode='null', stateField='null', zipCode='null', msid='null', newMsidFlag='null', sms='null', smsPackage='null', iccid='null', oldMin='null', digitalFeature='null', otaType='null', rateCenterNo='null', applicationSystem='null', subscriberUpdate='null', downloadDate='null', amount='null', balance='null', language='null', expDate='null', xMpn='null', xMpnCode='null', xPoolName='null', xMake='null', xModel='null', xMode='null', carrierInitialTransTime='null', carrierEndTransTime='null', loggedDate='null', loggedBy='null', prlNumber='null'}]}", response.toString());
    }

    @Test
   public void testGetIgFailLogs_whenException() throws TracfoneOneException {
        doThrow(RuntimeException.class).when(action).getIgFailLogs(any());
        try {
            controller.getIgFailLogs(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_IG_FAIL_LOGS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_IG_FAIL_LOGS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


}