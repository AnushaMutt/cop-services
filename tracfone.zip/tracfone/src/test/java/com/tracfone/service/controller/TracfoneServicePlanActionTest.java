package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchServicePlanModel;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import weblogic.utils.collections.ArraySet;

import javax.enterprise.event.Event;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneServicePlanActionTest {
    private static final String DB_ENV = "DBENV";
    @InjectMocks
    private TracfoneServicePlanAction tracfoneServicePlanAction;
    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private ResultSet resultSet;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

    @Test
    public void testSearchServicePlans() throws TracfoneOneException, SQLException {
        List<String> ratePlans = new ArrayList<>();
        ratePlans.add("RATE_PLAN_1");
        ratePlans.add("RATE_PLAN_2");
        List<TFOneCarrierServicePlan> servicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneServicePlanView = new TFOneCarrierServicePlan();
        tfOneServicePlanView.setParentName("PARENT_NAME");
        tfOneServicePlanView.setCarrierName("CARRIER_NAME");
        tfOneServicePlanView.setServicePlanId("185");
        servicePlans.add(tfOneServicePlanView);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setServicePlanId("185");
        tfServicePlanModel.setBrands(ratePlans);
        tfServicePlanModel.setBucketId("185");
        tfServicePlanModel.setBucketRequirement("BUCKET_REQUIREMENTS");
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENTS");
        tfServicePlanModel.setProfileDesc("PROFILE_DESCRIPTION");
        tfServicePlanModel.setProfileId("5401");
        tfServicePlanModel.setRatePlans(ratePlans);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        List<TFOneCarrierServicePlan> carrierFeatures = tracfoneServicePlanAction.searchServicePlans(tfServicePlanModel);
        assertEquals(1, carrierFeatures.size());
    }

    @Test
    public void testSearchServicePlans_For_Else_Block() throws TracfoneOneException, SQLException {
        List<String> ratePlans = new ArrayList<>();
        ratePlans.add("RATE_PLAN_1");
        ratePlans.add("RATE_PLAN_2");
        List<TFOneCarrierServicePlan> servicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneServicePlanView = new TFOneCarrierServicePlan();
        tfOneServicePlanView.setParentName("PARENT_NAME");
        tfOneServicePlanView.setCarrierName("CARRIER_NAME");
        tfOneServicePlanView.setServicePlanId("185");
        servicePlans.add(tfOneServicePlanView);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setServicePlanId("185");
        tfServicePlanModel.setBrands(ratePlans);
        tfServicePlanModel.setBucketRequirement("BUCKET_REQUIREMENTS");
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENTS");
        tfServicePlanModel.setProfileDesc("PROFILE_DESCRIPTION");
        tfServicePlanModel.setProfileId("5401");
        tfServicePlanModel.setRatePlans(ratePlans);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        List<TFOneCarrierServicePlan> carrierFeatures = tracfoneServicePlanAction.searchServicePlans(tfServicePlanModel);
        assertEquals(1, carrierFeatures.size());
    }

    @Test
    public void testSearchServicePlans_For_BucketId_Else_Block() throws TracfoneOneException, SQLException {
        List<String> ratePlans = new ArrayList<>();
        ratePlans.add("RATE_PLAN_1");
        ratePlans.add("RATE_PLAN_2");
        List<TFOneCarrierServicePlan> servicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneServicePlanView = new TFOneCarrierServicePlan();
        tfOneServicePlanView.setParentName("PARENT_NAME");
        tfOneServicePlanView.setCarrierName("CARRIER_NAME");
        tfOneServicePlanView.setServicePlanId("185");
        servicePlans.add(tfOneServicePlanView);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setServicePlanId("185");
        tfServicePlanModel.setBrands(ratePlans);
        tfServicePlanModel.setBucketId("BUCKET_ID");
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENTS");
        tfServicePlanModel.setProfileDesc("PROFILE_DESCRIPTION");
        tfServicePlanModel.setProfileId("5401");
        tfServicePlanModel.setRatePlans(ratePlans);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        List<TFOneCarrierServicePlan> carrierFeatures = tracfoneServicePlanAction.searchServicePlans(tfServicePlanModel);
        assertEquals(1, carrierFeatures.size());
    }

    @Test
    public void testSearchServicePlans_IfProfileFeatureStatementNull() throws TracfoneOneException, SQLException {
        List<String> ratePlans = new ArrayList<>();
        ratePlans.add("RATE_PLAN_1");
        ratePlans.add("RATE_PLAN_2");
        List<TFOneCarrierServicePlan> servicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneServicePlanView = new TFOneCarrierServicePlan();
        tfOneServicePlanView.setParentName("PARENT_NAME");
        tfOneServicePlanView.setCarrierName("CARRIER_NAME");
        tfOneServicePlanView.setServicePlanId("185");
        servicePlans.add(tfOneServicePlanView);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setServicePlanId("185");
        tfServicePlanModel.setBrands(ratePlans);
        tfServicePlanModel.setBucketId("BUCKET_ID");
        tfServicePlanModel.setLegacy(true);
        tfServicePlanModel.setRatePlans(ratePlans);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        List<TFOneCarrierServicePlan> carrierFeatures = tracfoneServicePlanAction.searchServicePlans(tfServicePlanModel);
        assertEquals(1, carrierFeatures.size());
    }

    @Test
    public void testSearchServicePlans_If_Block() throws TracfoneOneException, SQLException {
        List<String> ratePlans = new ArrayList<>();
        ratePlans.add("RATE_PLAN_1");
        ratePlans.add("RATE_PLAN_2");
        List<TFOneCarrierServicePlan> servicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneServicePlanView = new TFOneCarrierServicePlan();
        tfOneServicePlanView.setParentName("PARENT_NAME");
        tfOneServicePlanView.setCarrierName("CARRIER_NAME");
        tfOneServicePlanView.setServicePlanId("185");
        servicePlans.add(tfOneServicePlanView);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setLegacy(true);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setServicePlanId("185");
        tfServicePlanModel.setBrands(ratePlans);
        tfServicePlanModel.setBucketId("185");
        tfServicePlanModel.setBucketRequirement("BUCKET_REQUIREMENTS");
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENTS");
        tfServicePlanModel.setProfileDesc("PROFILE_DESCRIPTION");
        tfServicePlanModel.setProfileId("5401");
        tfServicePlanModel.setRatePlans(ratePlans);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        List<TFOneCarrierServicePlan> carrierFeatures = tracfoneServicePlanAction.searchServicePlans(tfServicePlanModel);
        assertEquals(1, carrierFeatures.size());
    }

    @Test
    public void testSearchServicePlans_ElseIf_Block() throws TracfoneOneException, SQLException {
        List<String> ratePlans = new ArrayList<>();
        ratePlans.add("RATE_PLAN_1");
        ratePlans.add("RATE_PLAN_2");
        List<TFOneCarrierServicePlan> servicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneServicePlanView = new TFOneCarrierServicePlan();
        tfOneServicePlanView.setParentName("PARENT_NAME");
        tfOneServicePlanView.setCarrierName("CARRIER_NAME");
        tfOneServicePlanView.setServicePlanId("185");
        servicePlans.add(tfOneServicePlanView);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setLegacy(true);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setServicePlanId("185");
        tfServicePlanModel.setBrands(ratePlans);
        tfServicePlanModel.setBucketRequirement("BUCKET_REQUIREMENTS");
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENTS");
        tfServicePlanModel.setProfileDesc("PROFILE_DESCRIPTION");
        tfServicePlanModel.setProfileId("5401");
        tfServicePlanModel.setRatePlans(ratePlans);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        List<TFOneCarrierServicePlan> carrierFeatures = tracfoneServicePlanAction.searchServicePlans(tfServicePlanModel);
        assertEquals(1, carrierFeatures.size());
    }

    @Test
    public void testSearchServicePlans_For_bucketId_ElseIf_Block() throws TracfoneOneException, SQLException {
        List<String> ratePlans = new ArrayList<>();
        ratePlans.add("RATE_PLAN_1");
        ratePlans.add("RATE_PLAN_2");
        List<TFOneCarrierServicePlan> servicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneServicePlanView = new TFOneCarrierServicePlan();
        tfOneServicePlanView.setParentName("PARENT_NAME");
        tfOneServicePlanView.setCarrierName("CARRIER_NAME");
        tfOneServicePlanView.setServicePlanId("185");
        servicePlans.add(tfOneServicePlanView);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setLegacy(true);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setServicePlanId("185");
        tfServicePlanModel.setBrands(ratePlans);
        tfServicePlanModel.setBucketId("185");
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENTS");
        tfServicePlanModel.setProfileDesc("PROFILE_DESCRIPTION");
        tfServicePlanModel.setProfileId("5401");
        tfServicePlanModel.setRatePlans(ratePlans);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        List<TFOneCarrierServicePlan> carrierFeatures = tracfoneServicePlanAction.searchServicePlans(tfServicePlanModel);
        assertEquals(1, carrierFeatures.size());
    }

    @Test
    public void testSearchServicePlans_withException() throws SQLException {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneServicePlanAction.searchServicePlans(tfServicePlanModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testViewServicePlanCarrierFeatures() throws TracfoneOneException, SQLException {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setServicePlanId("100");
        List<String> columnNames = new ArrayList<>();
        columnNames.add("X_RATE_PLAN");
        columnNames.add("X_TECHNOLOGY");
        columnNames.add("PRIORITY");
        columnNames.add("X_FEATURES2BUS_ORG");
        tfServicePlanModel.setCarrierFeatureColumns(columnNames);
        List<String> ratePlans = new ArrayList<>();
        ratePlans.add("RATE_PLAN_1");
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setBrands(ratePlans);
        tfServicePlanModel.setBucketId("185");
        tfServicePlanModel.setBucketRequirement("BUCKET_REQUIREMENTS");
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENTS");
        tfServicePlanModel.setProfileDesc("PROFILE_DESCRIPTION");
        tfServicePlanModel.setProfileId("5401");
        tfServicePlanModel.setCarrierFeatureColumns(columnNames);
        tfServicePlanModel.setRatePlans(ratePlans);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("ONE_RATE_PLAN");
        List<TFOneCarrierFeature> carrierFeatures = tracfoneServicePlanAction.viewServicePlanCarrierFeatures(tfServicePlanModel);
        assertEquals(1, carrierFeatures.size());
        assertEquals("ONE_RATE_PLAN", carrierFeatures.get(0).getxRatePlan());
    }

    @Test
    public void testViewServicePlanCarrierFeatures_whenBucketIdNull() throws TracfoneOneException, SQLException {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setServicePlanId("100");
        List<String> columnNames = new ArrayList<>();
        columnNames.add("X_RATE_PLAN");
        columnNames.add("X_TECHNOLOGY");
        columnNames.add("PRIORITY");
        columnNames.add("X_FEATURES2BUS_ORG");
        tfServicePlanModel.setCarrierFeatureColumns(columnNames);
        List<String> ratePlans = new ArrayList<>();
        ratePlans.add("RATE_PLAN_1");
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setBrands(ratePlans);
        tfServicePlanModel.setLegacy(true);
        tfServicePlanModel.setBucketRequirement("BUCKET_REQUIREMENTS");
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENTS");
        tfServicePlanModel.setProfileDesc("PROFILE_DESCRIPTION");
        tfServicePlanModel.setProfileId("5401");
        tfServicePlanModel.setCarrierFeatureColumns(columnNames);
        tfServicePlanModel.setRatePlans(ratePlans);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("ONE_RATE_PLAN");
        List<TFOneCarrierFeature> carrierFeatures = tracfoneServicePlanAction.viewServicePlanCarrierFeatures(tfServicePlanModel);
        assertEquals(1, carrierFeatures.size());
        assertEquals("ONE_RATE_PLAN", carrierFeatures.get(0).getxRatePlan());
    }

    @Test
    public void testViewServicePlanCarrierFeatures_whenBucketRequirementNull() throws TracfoneOneException, SQLException {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setServicePlanId("100");
        List<String> columnNames = new ArrayList<>();
        columnNames.add("X_RATE_PLAN");
        columnNames.add("X_TECHNOLOGY");
        columnNames.add("PRIORITY");
        columnNames.add("X_FEATURES2BUS_ORG");
        tfServicePlanModel.setCarrierFeatureColumns(columnNames);
        List<String> ratePlans = new ArrayList<>();
        ratePlans.add("RATE_PLAN_1");
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setBrands(ratePlans);
        tfServicePlanModel.setLegacy(true);
        tfServicePlanModel.setBucketId("185");
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENTS");
        tfServicePlanModel.setProfileDesc("PROFILE_DESCRIPTION");
        tfServicePlanModel.setProfileId("5401");
        tfServicePlanModel.setCarrierFeatureColumns(columnNames);
        tfServicePlanModel.setRatePlans(ratePlans);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("ONE_RATE_PLAN");
        List<TFOneCarrierFeature> carrierFeatures = tracfoneServicePlanAction.viewServicePlanCarrierFeatures(tfServicePlanModel);
        assertEquals(1, carrierFeatures.size());
        assertEquals("ONE_RATE_PLAN", carrierFeatures.get(0).getxRatePlan());
    }

    @Test
    public void testViewServicePlanCarrierFeatures_withException() throws SQLException {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setServicePlanId("100");
        List<String> columnNames = new ArrayList<>();
        columnNames.add("X_RATE_PLAN");
        tfServicePlanModel.setCarrierFeatureColumns(columnNames);
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneServicePlanAction.viewServicePlanCarrierFeatures(tfServicePlanModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllServicePlans() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("ONE");
        List<TFOneCarrierServicePlan> tfAllRatePlans = tracfoneServicePlanAction.getAllServicePlans(DB_ENV);
        assertEquals(2, tfAllRatePlans.size());
    }

    @Test
    public void testGetAllServicePlans_whenException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneServicePlanAction.getAllServicePlans(DB_ENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCarrierFeatureLinks() throws TracfoneOneException, SQLException {
        List<String> carrierFeatureColumns = new ArrayList<>();
        carrierFeatureColumns.add("DEV");
        carrierFeatureColumns.add("X_TECHNOLOGY");

        List<TracfoneOneCarrierFeature> selectedCarrierFeatures = new ArrayList<>();
        TracfoneOneCarrierFeature tfCarrierFeature = new TracfoneOneCarrierFeature();
        tfCarrierFeature.setDbEnv(DB_ENV);
        tfCarrierFeature.setObjId("100");

        selectedCarrierFeatures.add(tfCarrierFeature);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setProfileId("1000");
        tfServicePlanModel.setProfileDesc("PROFILE_DESCRIPTION");
        tfServicePlanModel.setBucketId("1000");
        tfServicePlanModel.setBucketRequirement("BUCKET_REQUIREMENT");
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENT");
        tfServicePlanModel.setSelectedCarrierFeatures(selectedCarrierFeatures);
        tfServicePlanModel.setCarrierFeatureColumns(carrierFeatureColumns);
        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("ONE");
        List<TFOneCarrierFeature> tfAllRatePlans = tracfoneServicePlanAction.getCarrierFeatureLinks(tfServicePlanModel);
        assertEquals(1, tfAllRatePlans.size());
    }

    @Test
    public void testGetCarrierFeatureLinks_WhenFeatureNameNull() throws TracfoneOneException, SQLException {
        List<String> carrierFeatureColumns = new ArrayList<>();
        carrierFeatureColumns.add("DEV");
        carrierFeatureColumns.add("X_TECHNOLOGY");

        List<TracfoneOneCarrierFeature> selectedCarrierFeatures = new ArrayList<>();
        TracfoneOneCarrierFeature tfCarrierFeature = new TracfoneOneCarrierFeature();
        tfCarrierFeature.setDbEnv(DB_ENV);
        tfCarrierFeature.setObjId("100");

        selectedCarrierFeatures.add(tfCarrierFeature);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setProfileId("1000");
        tfServicePlanModel.setProfileDesc("PROFILE_DESCRIPTION");
        tfServicePlanModel.setBucketId("1000");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENT");
        tfServicePlanModel.setSelectedCarrierFeatures(selectedCarrierFeatures);
        tfServicePlanModel.setCarrierFeatureColumns(carrierFeatureColumns);
        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("ONE");
        List<TFOneCarrierFeature> tfAllRatePlans = tracfoneServicePlanAction.getCarrierFeatureLinks(tfServicePlanModel);
        assertEquals(1, tfAllRatePlans.size());
    }

    @Test
    public void testGetCarrierFeatureLinks_WhenBucketIdNull() throws TracfoneOneException, SQLException {
        List<String> carrierFeatureColumns = new ArrayList<>();
        carrierFeatureColumns.add("DEV");
        carrierFeatureColumns.add("X_TECHNOLOGY");

        List<TracfoneOneCarrierFeature> selectedCarrierFeatures = new ArrayList<>();
        TracfoneOneCarrierFeature tfCarrierFeature = new TracfoneOneCarrierFeature();
        tfCarrierFeature.setDbEnv(DB_ENV);
        tfCarrierFeature.setObjId("100");

        selectedCarrierFeatures.add(tfCarrierFeature);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setProfileId("1000");
        tfServicePlanModel.setProfileDesc("PROFILE_DESCRIPTION");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENT");
        tfServicePlanModel.setBucketRequirement("BUCKET_REQUIREMENT");
        tfServicePlanModel.setSelectedCarrierFeatures(selectedCarrierFeatures);
        tfServicePlanModel.setCarrierFeatureColumns(carrierFeatureColumns);
        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("ONE");
        List<TFOneCarrierFeature> tfAllRatePlans = tracfoneServicePlanAction.getCarrierFeatureLinks(tfServicePlanModel);
        assertEquals(1, tfAllRatePlans.size());
    }


    @Test
    public void testGetCarrierFeatureLinks_whenException() throws SQLException {
        List<TracfoneOneCarrierFeature> selectedCarrierFeatures = new ArrayList<>();
        TracfoneOneCarrierFeature tfCarrierFeature = new TracfoneOneCarrierFeature();
        tfCarrierFeature.setDbEnv(DB_ENV);
        tfCarrierFeature.setObjId("100");
        selectedCarrierFeatures.add(tfCarrierFeature);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DB_ENV);
        tfServicePlanModel.setProfileId("1000");
        tfServicePlanModel.setSelectedCarrierFeatures(selectedCarrierFeatures);
        doThrow(SQLException.class).when(con).prepareStatement(anyString());
        try {
            tracfoneServicePlanAction.getCarrierFeatureLinks(tfServicePlanModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllServicePlanCarrierNames() throws TracfoneOneException, SQLException {
        String dbEnv = "datBase";
        String servicePlanId = "186";
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("ONE");
        List<String> carrierNames = tracfoneServicePlanAction.getAllServicePlanCarrierNames(dbEnv, servicePlanId, false);
        assertEquals(1, carrierNames.size());
    }

    @Test
    public void testGetAllServicePlanCarrierNames_whenException() throws SQLException {
        String dbEnv = "";
        String servicePlanId = "";
        doThrow(SQLException.class).when(con).prepareStatement(anyString());
        try {
            tracfoneServicePlanAction.getAllServicePlanCarrierNames(dbEnv, servicePlanId, true);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetServicePlansForCopy() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("ONE");
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DB_ENV);
        tracfoneOneSearchPlanModel.setCarrierName("185");
        tracfoneOneSearchPlanModel.setLegacy(true);
        List<TFOneCarrierServicePlan> tfOneCarrierServicePlans = tracfoneServicePlanAction.getServicePlansForCopy(tracfoneOneSearchPlanModel);
        assertEquals(1, tfOneCarrierServicePlans.size());
    }

    @Test
    public void testGetServicePlansForCopy_whenException() throws SQLException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DB_ENV);
        tracfoneOneSearchPlanModel.setCarrierName("185");
        doThrow(SQLException.class).when(con).prepareStatement(anyString());
        try {
            tracfoneServicePlanAction.getServicePlansForCopy(tracfoneOneSearchPlanModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testCountBucketsByLinkObjId() throws TracfoneOneException, SQLException {
        Set<String> profileIds = new ArraySet();
        profileIds.add("PROFILE_1");
        profileIds.add("PROFILE_2");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getInt(1)).thenReturn(1);
        int count = tracfoneServicePlanAction.countBucketsByLinkObjId(DB_ENV, profileIds, "SERVICE_PLAN");
        assertEquals(1, count);
    }

    @Test
    public void testCountBucketsByLinkObjId_whenException() throws SQLException {
        Set<String> profileIds = new ArraySet();
        doThrow(SQLException.class).when(con).prepareStatement(anyString());
        try {
            tracfoneServicePlanAction.countBucketsByLinkObjId(DB_ENV, profileIds, "");
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testCountChildBucketsByLinkObjId() throws TracfoneOneException, SQLException {
        Set<String> profileIds = new ArraySet();
        profileIds.add("PROFILE_1");
        profileIds.add("PROFILE_2");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getInt(1)).thenReturn(1);
        int count = tracfoneServicePlanAction.countChildBucketsByLinkObjId(DB_ENV, profileIds, "SERVICE_PLAN");
        assertEquals(1, count);
    }

    @Test
    public void testCountChildBucketsByLinkObjId_whenException() throws SQLException {
        Set<String> profileIds = new ArraySet();
        doThrow(SQLException.class).when(con).prepareStatement(anyString());
        try {
            tracfoneServicePlanAction.countChildBucketsByLinkObjId(DB_ENV, profileIds, "");
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteDummyCarrierFeature_whenException() throws SQLException {
        doThrow(SQLException.class).when(con).prepareStatement(anyString());
        try {
            tracfoneServicePlanAction.deleteDummyCarrierFeature(DB_ENV, "185", 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllLegacyPaygoPlans() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("ONE");
        List<TFOneCarrierServicePlan> tfAllRatePlans = tracfoneServicePlanAction.getAllLegacyPaygoPlans(DB_ENV, "CARRIER_NAME");
        assertEquals(2, tfAllRatePlans.size());
    }

    @Test
    public void testGetAllLegacyPaygoPlans_whenException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneServicePlanAction.getAllLegacyPaygoPlans(DB_ENV, "CARRIER_NAME");
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

}
