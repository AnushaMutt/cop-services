package com.tracfone.service.controller;

import com.tracfone.ejb.entity.retail.session.CRtlCarrierPrefFacadeLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import com.tracfone.service.model.request.TracfoneOneCarrierZonesDeployment;
import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;
import com.tracfone.service.model.request.TracfoneOneNpaNxx2Carrier;
import com.tracfone.service.model.response.TFOneCPrefResponse;
import com.tracfone.service.model.response.TFOneCarrierZonesDeployment;
import com.tracfone.service.model.response.TFOneCingularMrktInfo;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneMissingCarrierZones;
import com.tracfone.service.model.response.TFOneMissingCingularMktInfo;
import com.tracfone.service.model.response.TFOneNpaNxx2Carrier;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantCarrierZonesDeployment.TRACFONE_INSERT_CINGULAR_MRKT_INFO;
import static com.tracfone.service.util.TracfoneOneConstantCarrierZonesDeployment.TRACFONE_SEARCH_ZIPMKT_SUBMKT;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.event.Event;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.sql.DataSource;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;

import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import org.mockito.junit.MockitoJUnitRunner;

/**
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneCarrierZonesDeploymentActionTest {

    private static final String DBENV = "DBENV";
    @InjectMocks
    private TracfoneCarrierZonesDeploymentAction deploymentAction;
    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private ResultSet resultSet;

    @Mock
    private CRtlCarrierPrefFacadeLocal cRtlCarrierPrefFacade;

    @Mock
    EntityManager entityManager;

    @Mock
    Query query;

    private TFOneGeneralResponse tfOneGeneralResponse;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tfOneGeneralResponse = new TFOneGeneralResponse("Success", "100");
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

    @Test
    public void testValidateCarrierZones() throws TracfoneOneException, SQLException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
		carrierZonesDeployment.setCarrierName("VERIZON");
        //when(resultSet.next()).thenReturn(true).thenReturn(false);
        //when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        TFOneCarrierZonesDeployment response = deploymentAction.validateCarrierZones(carrierZonesDeployment);
        assertNotNull(response);
        assertEquals("TFOneCarrierZonesDeployment{newZipCodes=[12345, 33178], carrierZones=[], zipNPANXXs=[], arUsaData=[], cingularMrktInfos=[], zipMktSubMkts=[], tmoNextAvailable=[]}", response.toString());
    }

    @Test
    public void testValidateCarrierZones_withException() throws TracfoneOneException, SQLException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        // when SQLException occurs
        //doThrow(SQLException.class).when(resultSet).next();
        try {
            deploymentAction.validateCarrierZones(carrierZonesDeployment);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testValidateNpanxx() throws TracfoneOneException, SQLException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        TFOneCarrierZonesDeployment response = deploymentAction.validateNpaNxx(carrierZonesDeployment);
        assertNotNull(response);
        assertEquals("TFOneCarrierZonesDeployment{newZipCodes=[12345, 33178], carrierZones=[], zipNPANXXs=[TFOneVerizonZipNPANXX{zip='DUMMY_DATA', NPA='null', NXX='null', NPANXX='DUMMY_DATA', AccountNum='null', template='null'}], arUsaData=[], cingularMrktInfos=[], zipMktSubMkts=[], tmoNextAvailable=[]}", response.toString());
    }

    @Test
    public void testValidateNpanxx_withException() throws TracfoneOneException, SQLException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            deploymentAction.validateNpaNxx(carrierZonesDeployment);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierZones() throws Exception {
        List<TracfoneOneCarrierZones> carrierZoneses = new ArrayList<>();
        TracfoneOneCarrierZones oneCarrierZones = new TracfoneOneCarrierZones();
        oneCarrierZones.setState("TEST");
        oneCarrierZones.setCounty("COUNTY");
        oneCarrierZones.setCarrierId("12345");
        oneCarrierZones.setCarrierName("VZW");
        oneCarrierZones.setDbEnv(DBENV);
        carrierZoneses.add(oneCarrierZones);
        TFOneMissingCarrierZones response = new TFOneMissingCarrierZones();
        response.setFailedRecords(carrierZoneses);
        response.setSuccessRecords(carrierZoneses);
        TFOneMissingCarrierZones carrierZones = deploymentAction.insertMissingCarrierZones(carrierZoneses, 1000, "VERIZON");
        assertEquals(carrierZones, carrierZones);
    }

    @Test
    public void testInsertCarrierZones_withException() throws TracfoneOneException, SQLException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            deploymentAction.validateNpaNxx(carrierZonesDeployment);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertNpanxx() throws Exception {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        TFOneNpaNxx2Carrier response = new TFOneNpaNxx2Carrier();
        response.setFailedRecords(nxx2Carriers);
        response.setSuccessRecords(nxx2Carriers);
        TFOneNpaNxx2Carrier carrierZones = deploymentAction.insertNpaNxx(nxx2Carriers, 1000);
        assertEquals(carrierZones, carrierZones);
    }

    @Test
    public void testInsertNpanxx_withException() throws TracfoneOneException, SQLException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            deploymentAction.validateNpaNxx(carrierZonesDeployment);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCPref() throws Exception {
        List<TracfoneOneCarrierZones> carrierZoneses = new ArrayList<>();
        TracfoneOneCarrierZones oneCarrierZones = new TracfoneOneCarrierZones();
        oneCarrierZones.setState("TEST");
        oneCarrierZones.setCounty("COUNTY");
        oneCarrierZones.setCarrierId("12345");
        oneCarrierZones.setCarrierName("VZW");
        oneCarrierZones.setDbEnv(DBENV);
        carrierZoneses.add(oneCarrierZones);
        TFOneCPrefResponse response = new TFOneCPrefResponse();
        response.setFailedRecords(carrierZoneses);
        response.setSuccessRecords(carrierZoneses);
        TFOneCPrefResponse carrierZones = deploymentAction.insertCPref(carrierZoneses, 1000);
        assertEquals(carrierZones, carrierZones);
    }

    @Test
    public void testInsertCPref_withException() throws TracfoneOneException, SQLException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            deploymentAction.validateNpaNxx(carrierZonesDeployment);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testValidateCingularMrktInfo() throws TracfoneOneException, SQLException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        TFOneCarrierZonesDeployment response = deploymentAction.validateCingularMrktInfo(carrierZonesDeployment);
        assertNotNull(response);
        assertEquals("TFOneCarrierZonesDeployment{newZipCodes=[12345, 33178], carrierZones=[], zipNPANXXs=[], arUsaData=[], cingularMrktInfos=[TFOneCingularMrktInfo{mkt='DUMMY_DATA', npa='DUMMY_DATA', nxx='DUMMY_DATA', npanxx='DUMMY_DATA', rcNumber='DUMMY_DATA', rcName='DUMMY_DATA', rcState='DUMMY_DATA', zip='DUMMY_DATA', mktType='DUMMY_DATA', accountNum='DUMMY_DATA', marketCode='DUMMY_DATA', dealerCode='DUMMY_DATA', subMarketId='DUMMY_DATA', template='DUMMY_DATA'}], zipMktSubMkts=[], tmoNextAvailable=[]}", response.toString());
    }

    @Test
    public void testValidateCingularMrktInfo_withException() throws TracfoneOneException, SQLException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            deploymentAction.validateCingularMrktInfo(carrierZonesDeployment);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testValidateZipMktSubMkt() throws TracfoneOneException, SQLException {

        List<Object[]> objects = new ArrayList<>();
        Object[] object = {"CARRIER_0", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1",
                "CARRIER_0", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1",
                "CARRIER_0", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1"};
        objects.add(object);
        when(cRtlCarrierPrefFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(objects);

        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        TFOneCarrierZonesDeployment response = deploymentAction.validateZipMktSubMkt(carrierZonesDeployment);
        assertNotNull(response);
        assertEquals("TFOneCarrierZonesDeployment{newZipCodes=[12345, 33178], carrierZones=[], zipNPANXXs=[], arUsaData=[], cingularMrktInfos=[], zipMktSubMkts=[TFOneZipMktSubMkt{zipCode='CARRIER_0', city='CARRIER_1', county='CARRIER_1', state='CARRIER_1', billingSystem='CARRIER_1', market='CARRIER_1', marketDescription='CARRIER_1', subMarketSite='CARRIER_0', rateCenterServiceArea='CARRIER_1', rateCenterDescription='CARRIER_1', nbiLocalMarket='CARRIER_1', nbiMarketDescription='CARRIER_1', nbiSubMarket='CARRIER_1', nbiRateCenter='CARRIER_1', nbiRateCenterDescription='CARRIER_0', compassMarketCode='CARRIER_1', estoreId='CARRIER_1', addDate='CARRIER_1', updateDate='CARRIER_1'}], tmoNextAvailable=[]}", response.toString());
    }

    @Test
    public void testValidateZipMktSubMkt_withException() throws TracfoneOneException, SQLException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        // when SQLException occurs
        when(cRtlCarrierPrefFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        doThrow(RuntimeException.class).when(query).getResultList();
        try {
            deploymentAction.validateZipMktSubMkt(carrierZonesDeployment);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateDealerNan() throws TracfoneOneException, SQLException {
        List<TracfoneOneCingularMrktInfo> cingularMrktInfos = new ArrayList<>();
        TracfoneOneCingularMrktInfo cingularMrktInfo = new TracfoneOneCingularMrktInfo();
        cingularMrktInfo.setDealerCode("DEALER_CODE");
        cingularMrktInfo.setDbEnv("DBENV");
        cingularMrktInfos.add(cingularMrktInfo);
        List<TFOneCingularMrktInfo> response = deploymentAction.updateDealerNan(cingularMrktInfos);
        assertNotNull(response);
        assertEquals("[TFOneCingularMrktInfo{mkt='null', npa='null', nxx='null', npanxx='null', rcNumber='null', rcName='null', rcState='null', zip='null', mktType='null', accountNum='null', marketCode='null', dealerCode='DEALER_CODE', subMarketId='null', template='null'}]", response.toString());
    }

    @Test
    public void testUpdateDealerNan_withException() throws TracfoneOneException, SQLException {
        List<TracfoneOneCingularMrktInfo> cingularMrktInfos = new ArrayList<>();
        TracfoneOneCingularMrktInfo cingularMrktInfo = new TracfoneOneCingularMrktInfo();
        cingularMrktInfo.setDealerCode("DEALER_CODE");
        cingularMrktInfo.setDbEnv("DBENV");
        cingularMrktInfos.add(cingularMrktInfo);
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            deploymentAction.updateDealerNan(cingularMrktInfos);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCingularMktInfo() throws Exception {
        List<TracfoneOneCingularMrktInfo> mrktInfos = new ArrayList<>();
        TracfoneOneCingularMrktInfo mrktInfo = new TracfoneOneCingularMrktInfo();
        mrktInfo.setDealerCode("DEALER_CODE");
        mrktInfo.setMkt("MKT");
        mrktInfo.setMarketCode("MARKET_CODE");
        mrktInfo.setAccountNum("ACCOUNT_NUM");
        mrktInfo.setZip("ZIP");
        mrktInfo.setTemplate("TEMPLATE");
        mrktInfo.setSubMarketId("SUB_MARKET_ID");
        mrktInfo.setRcState("STATE");
        mrktInfo.setRcNumber("NUMBER");
        mrktInfo.setRcName("NAME");
        mrktInfo.setDbEnv("DBENV");
        mrktInfos.add(mrktInfo);
        TFOneMissingCingularMktInfo response = new TFOneMissingCingularMktInfo();
        response.setFailedRecords(mrktInfos);
        response.setSuccessRecords(mrktInfos);
        TFOneMissingCingularMktInfo res = deploymentAction.insertCingularMktInfo(mrktInfos, 1000);
        assertEquals("TFOneMissingCingularMktInfo{successRecords=[TracfoneOneCingularMrktInfo{mkt='MKT', npa='null', nxx='null', npanxx='null', rcNumber='NUMBER', rcName='NAME', rcState='STATE', zip='ZIP', mktType='null', accountNum='ACCOUNT_NUM', marketCode='MARKET_CODE', dealerCode='DEALER_CODE', subMarketId='SUB_MARKET_ID', template='TEMPLATE', oldZip='null', dbEnv='DBENV', reasonToFail='null', techReasonToFail='null'}], failedRecords=[]}", res.toString());
    }

    @Test
    public void testInsertCingularMktInfo_Duplicate() throws Exception {
        List<TracfoneOneCingularMrktInfo> mrktInfos = new ArrayList<>();
        TracfoneOneCingularMrktInfo mrktInfo = new TracfoneOneCingularMrktInfo();
        mrktInfo.setDealerCode("DEALER_CODE");
        mrktInfo.setMkt("MKT");
        mrktInfo.setMarketCode("MARKET_CODE");
        mrktInfo.setAccountNum("ACCOUNT_NUM");
        mrktInfo.setZip("ZIP");
        mrktInfo.setTemplate("TEMPLATE");
        mrktInfo.setSubMarketId("SUB_MARKET_ID");
        mrktInfo.setRcState("STATE");
        mrktInfo.setRcNumber("NUMBER");
        mrktInfo.setRcName("NAME");
        mrktInfo.setDbEnv("DBENV");
        mrktInfos.add(mrktInfo);
        TFOneMissingCingularMktInfo response = new TFOneMissingCingularMktInfo();
        response.setFailedRecords(mrktInfos);
        response.setSuccessRecords(mrktInfos);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getInt(1)).thenReturn(2);
        TFOneMissingCingularMktInfo res = deploymentAction.insertCingularMktInfo(mrktInfos, 1000);
        assertEquals("TFOneMissingCingularMktInfo{successRecords=[], failedRecords=[TracfoneOneCingularMrktInfo{mkt='MKT', npa='null', nxx='null', npanxx='null', rcNumber='NUMBER', rcName='NAME', rcState='STATE', zip='ZIP', mktType='null', accountNum='ACCOUNT_NUM', marketCode='MARKET_CODE', dealerCode='DEALER_CODE', subMarketId='SUB_MARKET_ID', template='TEMPLATE', oldZip='null', dbEnv='DBENV', reasonToFail='Duplicate Cingular Mkt Info found', techReasonToFail='Duplicate Cingular Mkt Info found'}]}", res.toString());
    }

    @Test
    public void testInsertCingularMktInfo_withException() throws SQLException {
        List<TracfoneOneCingularMrktInfo> mrktInfos = new ArrayList<>();
        TracfoneOneCingularMrktInfo mrktInfo = new TracfoneOneCingularMrktInfo();
        mrktInfo.setRcName("NAME");
        mrktInfo.setDbEnv("DBENV");
        mrktInfos.add(mrktInfo);
        // when SQLException occurs
        doThrow(SQLException.class).when(con).prepareStatement(TRACFONE_INSERT_CINGULAR_MRKT_INFO);
        try {
            deploymentAction.insertCingularMktInfo(mrktInfos, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertTmoNpaNxx() throws Exception {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        TFOneNpaNxx2Carrier response = new TFOneNpaNxx2Carrier();
        response.setFailedRecords(nxx2Carriers);
        response.setSuccessRecords(nxx2Carriers);
        TFOneNpaNxx2Carrier carrierZones = deploymentAction.insertTmoNpaNxx(nxx2Carriers, 1000);
        assertEquals(carrierZones, carrierZones);
    }

    @Test
    public void testInsertNpanxxAtt() throws Exception {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        TFOneNpaNxx2Carrier response = new TFOneNpaNxx2Carrier();
        response.setFailedRecords(nxx2Carriers);
        response.setSuccessRecords(nxx2Carriers);
        TFOneNpaNxx2Carrier carrierZones = deploymentAction.insertNpaNxxAtt(nxx2Carriers, 1000);
        assertEquals(carrierZones, carrierZones);
    }
}
