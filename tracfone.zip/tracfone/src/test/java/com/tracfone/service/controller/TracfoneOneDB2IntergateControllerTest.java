package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneDB2Intergate;
import com.tracfone.service.model.response.TFOneDB2Intergate;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantDB2Intergate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneDB2IntergateControllerTest implements TracfoneOneConstant, TracfoneOneConstantDB2Intergate {

    private static final String DBENV = "DBENV";

    @InjectMocks
    TracfoneOneDB2IntergateController controller;

    @Mock
    TracfoneOneDB2IntergateAction action;

    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "100");
        tracfoneOneException = new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
    }

    @Test
    public void testViewDB2IntergateTest() throws Exception {
        TracfoneOneDB2Intergate tracfoneOneDB2Intergate = new TracfoneOneDB2Intergate();
        tracfoneOneDB2Intergate.setDbEnv(DBENV);
        tracfoneOneDB2Intergate.setQueryName("APN");
        tracfoneOneDB2Intergate.setOrderTypes("A");

        List<TFOneDB2Intergate> viewData = new ArrayList<>();
        ;
        TFOneDB2Intergate dB2Intergate = new TFOneDB2Intergate();
        dB2Intergate.setActiveFlag("TRUE");
        dB2Intergate.setAppName("TEST");
        dB2Intergate.setExtraWhereClauseConditions("SONS");
        dB2Intergate.setIntervalTime("2020:02:02");
        dB2Intergate.setNumberOfRecords("2020:02:03");
        dB2Intergate.setOrderTypes("OUTAGE_TYPE");
        dB2Intergate.setQueryId("SERVICE_TYPE");
        dB2Intergate.setQueryName("1,2,3");
        dB2Intergate.setRemarks("CHANNEL");
        dB2Intergate.setSelectQueryClob("BRAND");
        dB2Intergate.setStartingRecord("PARENT_SHORT_NAME");
        dB2Intergate.setTemplates("BRAND");
        dB2Intergate.setUpdateQuery("PARENT_SHORT_NAME");
        dB2Intergate.setUseNewSql("BRAND");
        viewData.add(dB2Intergate);

        when(action.viewDB2Intergate(any())).thenReturn(viewData);
        List<TFOneDB2Intergate> response = controller.viewDB2Intergate(tracfoneOneDB2Intergate);
        assertEquals("[TFOneDB2Intergate{queryId='SERVICE_TYPE', queryName='1,2,3', activeFlag='TRUE', useNewSql='BRAND', intervalTime='2020:02:02', selectQueryClob='BRAND', numberOfRecords='2020:02:03', updateQuery='PARENT_SHORT_NAME', templates='BRAND', orderTypes='OUTAGE_TYPE', extraWhereClauseConditions='SONS', appName='TEST', startingRecord='PARENT_SHORT_NAME', remarks='CHANNEL'}]", response.toString());
    }

    @Test
    public void testViewDB2IntergateTest_whenException() throws TracfoneOneException {
        doThrow(RuntimeException.class).when(action).viewDB2Intergate(any());
        try {
            controller.viewDB2Intergate(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_DB2_INTERGATE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_DB2_INTERGATE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateServiceType() throws Exception {
        TracfoneOneDB2Intergate tracfoneOneDB2Intergate = new TracfoneOneDB2Intergate();
        tracfoneOneDB2Intergate.setDbEnv(DBENV);
        tracfoneOneDB2Intergate.setTemplates("TEST");
        tracfoneOneDB2Intergate.setAppName("APP_NAME");
        when(action.updateDB2Intergate(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = controller.updateDB2Intergate(tracfoneOneDB2Intergate, 100);
        assertEquals("200", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testUpdateServiceType_whenException() throws Exception {
        TracfoneOneDB2Intergate tracfoneOneDB2Intergate = new TracfoneOneDB2Intergate();
        tracfoneOneDB2Intergate.setDbEnv(DBENV);
        tracfoneOneDB2Intergate.setTemplates("TEST");
        doThrow(RuntimeException.class).when(action).updateDB2Intergate(any(), anyInt());
        try {
            controller.updateDB2Intergate(tracfoneOneDB2Intergate, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_DB2_INTERGATE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_DB2_INTERGATE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}
