package com.tracfone.service;

import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneOneCarrierOutageControllerLocal;
import com.tracfone.service.controller.TracfoneRatePlanControllerLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneCarrierOutage;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneServiceType;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneBusinessOrganization;
import com.tracfone.service.model.response.TFOneCarrierOutage;
import com.tracfone.service.model.response.TFOneDatabaseEnvironment;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOneServiceType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneCarrierOutageResourceTest {

    public final String JSON = "application/json";
    @InjectMocks
    private TracfoneOneCarrierOutageResource carrierOutageResource;

    @Mock
    private TracfoneOneCarrierOutageControllerLocal tracfoneOneCarrierOutageController;

    @Mock
    private SecurityContext securityContext;
    @Mock
    private TracfoneOnePrincipal principal;
    @Mock
    private TFOneAdminUser user;

    @Mock
    private TracfoneControllerLocal tracfoneController;

    @Mock
    private TracfoneRatePlanControllerLocal tracfoneRatePlanController;

    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    @Before
    public void setUp() {
        initMocks(this);
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
        when(securityContext.getUserPrincipal()).thenReturn(principal);
        when(principal.getTFUser()).thenReturn(user);
    }

    @Test
    public void testGetDatabaseEnvironments() throws TracfoneOneException {
        List<TFOneDatabaseEnvironment> tfOneDatabaseEnvironments = new ArrayList<>();
        TFOneDatabaseEnvironment tfOneDatabaseEnvironment = new TFOneDatabaseEnvironment();
        tfOneDatabaseEnvironment.setName("SIT1");
        tfOneDatabaseEnvironments.add(tfOneDatabaseEnvironment);
        when(tracfoneController.getDatabaseEnvironments(user.getUserId())).thenReturn(tfOneDatabaseEnvironments);
        Response response = carrierOutageResource.getDatabaseEnvironments();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":0,\"name\":\"SIT1\",\"description\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetDatabaseEnvironments_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneController).getDatabaseEnvironments(anyInt());
        Response response = carrierOutageResource.getDatabaseEnvironments();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetAllBusinessOrgs() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        searchPlanModel.setDbEnv("local");
        List<TFOneBusinessOrganization> allBusOrgs = new ArrayList<>();
        TFOneBusinessOrganization tFOneBusinessOrganization = new TFOneBusinessOrganization();
        tFOneBusinessOrganization.setOrgId("1000");
        allBusOrgs.add(tFOneBusinessOrganization);
        when(tracfoneRatePlanController.getAllBusinessOrgs(any())).thenReturn(allBusOrgs);
        Response response = carrierOutageResource.getAllBusinessOrgs(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"orgId\":\"1000\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllBusinessOrgs_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getAllBusinessOrgs(any());
        Response response = carrierOutageResource.getAllBusinessOrgs(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllParentNames() throws TracfoneOneException {
        List<TFOneParent> allParents = new ArrayList<>();
        TFOneParent tFOneParent = new TFOneParent();
        tFOneParent.setObjId("1000");
        allParents.add(tFOneParent);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv("DBENV");
        when(tracfoneRatePlanController.getAllParentNames(any(), any())).thenReturn(allParents);
        Response response = carrierOutageResource.getAllParentNames(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"xParentName\":null,\"parentId\":null,\"status\":null,\"holdAnalogDeac\":null,\"holdDigitalDeac\":null,\"parent2TempQueue\":null,\"noInventory\":null,\"vmAccessNum\":null,\"autoPortIn\":null,\"autoPortOut\":null,\"noMsid\":null,\"otaCarrier\":null,\"otaEndDate\":null,\"otaPsmsAddress\":null,\"otaStartDate\":null,\"nextAvailable\":null,\"queueName\":null,\"blockPortIn\":null,\"meidCarrier\":null,\"otaReact\":null,\"aggCarrCode\":null,\"suiRuleObjId\":null,\"deactSimExpDays\":null,\"overrideSmsAddress\":null,\"triggerId\":null,\"parentShortName\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllParentNames_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getAllParentNames(any(), any());
        Response response = carrierOutageResource.getAllParentNames(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierOutage() throws TracfoneOneException {
        TracfoneOneCarrierOutage tracfoneOneCarrierOutage = new TracfoneOneCarrierOutage();
        tracfoneOneCarrierOutage.setBrand("BRAND");
        tracfoneOneCarrierOutage.setCreatedBy("SONS");
        tracfoneOneCarrierOutage.setStartTime("2020:02:02");
        tracfoneOneCarrierOutage.setEndTime("2020:02:03");
        tracfoneOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");

        List<TFOneCarrierOutage> carrierOutages = new ArrayList<>();
        TFOneCarrierOutage tfOneCarrierOutage = new TFOneCarrierOutage();
        tfOneCarrierOutage.setScriptText("SCRIPT_TEXT");
        tfOneCarrierOutage.setScriptId("1000");
        tfOneCarrierOutage.setCreatedBy("SONS");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setStartTime("2020:02:03");
        tfOneCarrierOutage.setOutageType("OUTAGE_TYPE");
        tfOneCarrierOutage.setServiceType("SERVICE_TYPE");
        tfOneCarrierOutage.setZipCode("1,2,3");
        tfOneCarrierOutage.setChannel("CHANNEL");
        tfOneCarrierOutage.setBrand("BRAND");
        tfOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");
        carrierOutages.add(tfOneCarrierOutage);

        when(tracfoneOneCarrierOutageController.searchCarrierOutage(any())).thenReturn(carrierOutages);
        Response response = carrierOutageResource.searchCarrierOutage(tracfoneOneCarrierOutage);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"parentShortName\":\"PARENT_SHORT_NAME\",\"brand\":\"BRAND\",\"channel\":\"CHANNEL\",\"zipCode\":\"1,2,3\",\"serviceType\":\"SERVICE_TYPE\",\"outageType\":\"OUTAGE_TYPE\",\"startTime\":\"2020:02:03\",\"endTime\":\"2020:02:02\",\"createdBy\":\"SONS\",\"scriptId\":\"1000\",\"scriptText\":\"SCRIPT_TEXT\",\"outageDescription\":null,\"archived\":false}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierOutage_whenException() throws TracfoneOneException {
        TracfoneOneCarrierOutage tracfoneOneCarrierOutage = new TracfoneOneCarrierOutage();
        doThrow(tracfoneOneException).when(tracfoneOneCarrierOutageController).searchCarrierOutage(any());
        Response response = carrierOutageResource.searchCarrierOutage(tracfoneOneCarrierOutage);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierOutage() throws TracfoneOneException {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setScriptText("SCRIPT_TEXT");
        tfOneCarrierOutage.setScriptId("1000");
        tfOneCarrierOutage.setCreatedBy("SONS");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setStartTime("2020:02:03");
        tfOneCarrierOutage.setOutageType("OUTAGE_TYPE");
        tfOneCarrierOutage.setServiceType("SERVICE_TYPE");
        tfOneCarrierOutage.setZipCode("1,2,3");
        tfOneCarrierOutage.setChannel("CHANNEL");
        tfOneCarrierOutage.setBrand("BRAND");
        tfOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");
        when(tracfoneOneCarrierOutageController.insertCarrierOutage(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = carrierOutageResource.insertCarrierOutage(tfOneCarrierOutage);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierOutage_whenException() throws TracfoneOneException {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        doThrow(tracfoneOneException).when(tracfoneOneCarrierOutageController).insertCarrierOutage(any(), anyInt());
        Response response = carrierOutageResource.insertCarrierOutage(tfOneCarrierOutage);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierOutage() throws TracfoneOneException {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setScriptText("SCRIPT_TEXT");
        tfOneCarrierOutage.setScriptId("1000");
        tfOneCarrierOutage.setCreatedBy("SONS");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setStartTime("2020:02:03");
        tfOneCarrierOutage.setOutageType("OUTAGE_TYPE");
        tfOneCarrierOutage.setServiceType("SERVICE_TYPE");
        tfOneCarrierOutage.setZipCode("1,2,3");
        tfOneCarrierOutage.setChannel("CHANNEL");
        tfOneCarrierOutage.setBrand("BRAND");
        tfOneCarrierOutage.setObjId("100");
        tfOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");
        when(tracfoneOneCarrierOutageController.updateCarrierOutage(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = carrierOutageResource.updateCarrierOutage(tfOneCarrierOutage);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierOutage_whenException() throws TracfoneOneException {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        doThrow(tracfoneOneException).when(tracfoneOneCarrierOutageController).updateCarrierOutage(any(), anyInt());
        Response response = carrierOutageResource.updateCarrierOutage(tfOneCarrierOutage);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateEndTime() throws TracfoneOneException {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setObjIds("1000");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");
        when(tracfoneOneCarrierOutageController.bulkUpdateOutages(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = carrierOutageResource.bulkUpdateOutages(tfOneCarrierOutage);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateEndTime_whenException() throws TracfoneOneException {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        doThrow(tracfoneOneException).when(tracfoneOneCarrierOutageController).bulkUpdateOutages(any(), anyInt());
        Response response = carrierOutageResource.bulkUpdateOutages(tfOneCarrierOutage);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllServiceTypes() throws TracfoneOneException {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setDbEnv("local");
        List<TFOneServiceType> allServiceTypes = new ArrayList<>();
        TFOneServiceType tfServiceType = new TFOneServiceType();
        tfOneServiceType.setObjId("5");
        allServiceTypes.add(tfServiceType);
        when(tracfoneOneCarrierOutageController.viewAllServiceTypes(any())).thenReturn(allServiceTypes);
        Response response = carrierOutageResource.viewServiceTypes(tfOneServiceType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"serviceType\":null,\"serviceTypeCategory\":null,\"remarks\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllServiceTypes_whenException() throws TracfoneOneException {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        doThrow(tracfoneOneException).when(tracfoneOneCarrierOutageController).viewAllServiceTypes(any());
        Response response = carrierOutageResource.viewServiceTypes(tfOneServiceType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertServiceType() throws TracfoneOneException {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setServiceType("SERVICE_TYPE");
        tfOneServiceType.setServiceTypeCategory("SERVICE_TYPE_CATEGORY");
        tfOneServiceType.setRemarks("REMARKS");
        when(tracfoneOneCarrierOutageController.insertServiceType(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = carrierOutageResource.insertServiceType(tfOneServiceType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertServiceType_whenException() throws TracfoneOneException {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        doThrow(tracfoneOneException).when(tracfoneOneCarrierOutageController).insertServiceType(any(), anyInt());
        Response response = carrierOutageResource.insertServiceType(tfOneServiceType);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateServiceType() throws TracfoneOneException {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setServiceType("SERVICE_TYPE1");
        tfOneServiceType.setServiceTypeCategory("SERVICE_TYPE_CATEGORY1");
        tfOneServiceType.setRemarks("REMARKS1");
        tfOneServiceType.setObjId("100");
        when(tracfoneOneCarrierOutageController.updateServiceType(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = carrierOutageResource.updateServiceType(tfOneServiceType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateServiceType_whenException() throws TracfoneOneException {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        doThrow(tracfoneOneException).when(tracfoneOneCarrierOutageController).updateServiceType(any(), anyInt());
        Response response = carrierOutageResource.updateServiceType(tfOneServiceType);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteServiceType() throws TracfoneOneException {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setObjId("100");
        when(tracfoneOneCarrierOutageController.deleteServiceType(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = carrierOutageResource.deleteServiceType(tfOneServiceType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteServiceType_whenException() throws TracfoneOneException {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        doThrow(tracfoneOneException).when(tracfoneOneCarrierOutageController).deleteServiceType(any(), anyInt());
        Response response = carrierOutageResource.deleteServiceType(tfOneServiceType);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }
}