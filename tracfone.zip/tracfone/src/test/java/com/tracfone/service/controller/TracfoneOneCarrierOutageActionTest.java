package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneCarrierOutage;
import com.tracfone.service.model.request.TracfoneOneServiceType;
import com.tracfone.service.model.response.TFOneCarrierOutage;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneServiceType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneCarrierOutageActionTest {

    @InjectMocks
    TracfoneOneCarrierOutageAction tracfoneOneCarrierOutageAction;

    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private CallableStatement callableStatement;
    @Mock
    private ResultSet resultSet;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    private TFOneGeneralResponse tfOneGeneralResponse;

    @Before
    public void setUp() throws Exception {
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
        when(con.prepareCall(anyString())).thenReturn(callableStatement);
        when(callableStatement.execute()).thenReturn(true);
    }

    @Test
    public void testSearchCarrierOutage() throws Exception {
        TracfoneOneCarrierOutage tracfoneOneCarrierOutage = new TracfoneOneCarrierOutage();
        tracfoneOneCarrierOutage.setBrand("BRAND");
        tracfoneOneCarrierOutage.setShowArchivedOutage(true);
        tracfoneOneCarrierOutage.setCreatedBy("SONS");
        tracfoneOneCarrierOutage.setStartTime("2020:02:02");
        tracfoneOneCarrierOutage.setEndTime("2020:02:03");
        tracfoneOneCarrierOutage.setDbEnv("DBENV");
        tracfoneOneCarrierOutage.setOutageDescription("SF");
        tracfoneOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");

        List<TFOneCarrierOutage> carrierOutages = new ArrayList<>();
        TFOneCarrierOutage tfOneCarrierOutage = new TFOneCarrierOutage();
        tfOneCarrierOutage.setScriptText("SCRIPT_TEXT");
        tfOneCarrierOutage.setScriptId("1000");
        tfOneCarrierOutage.setCreatedBy("SONS");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setStartTime("2020:02:03");
        tfOneCarrierOutage.setOutageType("OUTAGE_TYPE");
        tfOneCarrierOutage.setServiceType("SERVICE_TYPE");
        tfOneCarrierOutage.setZipCode("1,2,3");
        tfOneCarrierOutage.setChannel("CHANNEL");
        tfOneCarrierOutage.setBrand("BRAND");
        tfOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");
        carrierOutages.add(tfOneCarrierOutage);

        when(stmt.executeQuery()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMY_DATA");
        List<TFOneCarrierOutage> response = tracfoneOneCarrierOutageAction.searchCarrierOutage(tracfoneOneCarrierOutage);
        assertEquals("[TFOneCarrierOutage{objId='DUMMY_DATA', parentShortName='DUMMY_DATA', brand='DUMMY_DATA', channel='DUMMY_DATA', zipCode='DUMMY_DATA', serviceType='DUMMY_DATA', outageType='DUMMY_DATA', startTime='DUMMY_DATA', endTime='DUMMY_DATA', createdBy='DUMMY_DATA', scriptId='DUMMY_DATA', scriptText='DUMMY_DATA', outageDescription='DUMMY_DATA', archived=false}]", response.toString());
    }

    @Test
    public void testSearchCarrierOutage_withException() throws SQLException {
        TracfoneOneCarrierOutage tracfoneOneCarrierOutage = new TracfoneOneCarrierOutage();
        tracfoneOneCarrierOutage.setBrand("BRAND");
        tracfoneOneCarrierOutage.setShowArchivedOutage(true);
        tracfoneOneCarrierOutage.setCreatedBy("SONS");
        tracfoneOneCarrierOutage.setStartTime("2020:02:02");
        tracfoneOneCarrierOutage.setEndTime("2020:02:03");
        tracfoneOneCarrierOutage.setOutageDescription("SF");
        tracfoneOneCarrierOutage.setDbEnv("DBENV");
        tracfoneOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneOneCarrierOutageAction.searchCarrierOutage(tracfoneOneCarrierOutage);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierOutage() throws TracfoneOneException, SQLException {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setScriptText("SCRIPT_TEXT");
        tfOneCarrierOutage.setDbEnv("DBENV");
        tfOneCarrierOutage.setScriptId("1000");
        tfOneCarrierOutage.setCreatedBy("SONS");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setStartTime("2020:02:03");
        tfOneCarrierOutage.setOutageType("OUTAGE_TYPE");
        tfOneCarrierOutage.setServiceType("SERVICE_TYPE");
        tfOneCarrierOutage.setZipCode("12345");
        tfOneCarrierOutage.setChannel("CHANNEL");
        tfOneCarrierOutage.setBrand("BRAND");
        tfOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");

        tracfoneOneCarrierOutageAction.insertCarrierOutage(tfOneCarrierOutage, 123);
        verify(stmt, times(1)).addBatch();
    }

    @Test
    public void testInsertCarrierOutage_whenException() throws TracfoneOneException, SQLException {
        // When NPE
        try {
            tracfoneOneCarrierOutageAction.insertCarrierOutage(null, 123);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setScriptText("SCRIPT_TEXT");
        tfOneCarrierOutage.setScriptId("1000");
        tfOneCarrierOutage.setZipCode("10000");
        tfOneCarrierOutage.setDbEnv("DBENV");
        tfOneCarrierOutage.setCreatedBy("SONS");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setObjId("100L");
        doThrow(SQLException.class).when(stmt).executeBatch();
        try {
            tracfoneOneCarrierOutageAction.insertCarrierOutage(tfOneCarrierOutage, 123);
            fail("Throws TracfoneOneExcepton");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierOutage() throws TracfoneOneException, SQLException {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setScriptId("1000");
        tfOneCarrierOutage.setObjId("1000");
        tfOneCarrierOutage.setDbEnv("DBENV");
        tfOneCarrierOutage.setCreatedBy("SONS");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setOutageType("OUTAGE_TYPE");
        tfOneCarrierOutage.setServiceType("SERVICE_TYPE");
        tfOneCarrierOutage.setChannel("CHANNEL");
        tfOneCarrierOutage.setBrand("BRAND");

        tfOneGeneralResponse = tracfoneOneCarrierOutageAction.updateCarrierOutage(tfOneCarrierOutage, 123);
        assertEquals("Success", tfOneGeneralResponse.getStatus());
        assertEquals("1000", tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testUpdateCarrierOutage_whenException() throws TracfoneOneException, SQLException {
        // When NPE
        try {
            tracfoneOneCarrierOutageAction.insertCarrierOutage(null, 123);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setScriptText("SCRIPT_TEXT");
        tfOneCarrierOutage.setScriptId("1000");
        tfOneCarrierOutage.setZipCode("10000");
        tfOneCarrierOutage.setDbEnv("DBENV");
        tfOneCarrierOutage.setCreatedBy("SONS");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setObjId("100");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneOneCarrierOutageAction.updateCarrierOutage(tfOneCarrierOutage, 123);
            fail("Throws TracfoneOneExcepton");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testCheckDuplicateCarrierOutage() throws Exception {
        TracfoneOneCarrierOutage tracfoneOneCarrierOutage = new TracfoneOneCarrierOutage();
        tracfoneOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");
        tracfoneOneCarrierOutage.setChannel("CHANNEL");
        tracfoneOneCarrierOutage.setBrand("BRNAD");
        tracfoneOneCarrierOutage.setDbEnv("DBENV");
        tracfoneOneCarrierOutage.setZipCode("12345,12346,12347");

        when(stmt.executeQuery()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("ZIPCODE");
        List<String> response = tracfoneOneCarrierOutageAction.findDuplicateCarrierOutageZips(tracfoneOneCarrierOutage);
        assertEquals("[ZIPCODE]", response.toString());
    }

    @Test
    public void testCheckDuplicateCarrierOutage_withException() throws SQLException {
        TracfoneOneCarrierOutage tracfoneOneCarrierOutage = new TracfoneOneCarrierOutage();
        tracfoneOneCarrierOutage.setBrand("BRAND");
        tracfoneOneCarrierOutage.setDbEnv("DBENV");
        tracfoneOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");
        tracfoneOneCarrierOutage.setZipCode("11111");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneOneCarrierOutageAction.findDuplicateCarrierOutageZips(tracfoneOneCarrierOutage);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateEndTime() throws TracfoneOneException {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setObjIds("1000,1002");
        tfOneCarrierOutage.setDbEnv("DBENV");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneGeneralResponse = tracfoneOneCarrierOutageAction.bulkUpdateOutages(tfOneCarrierOutage, 123);
        assertEquals("Success", tfOneGeneralResponse.getStatus());
        assertEquals("2", tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testUpdateEndTime_whenException() throws TracfoneOneException, SQLException {
        // When NPE
        try {
            tracfoneOneCarrierOutageAction.bulkUpdateOutages(null, 123);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setObjIds("1000,1002");
        tfOneCarrierOutage.setDbEnv("DBENV");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneOneCarrierOutageAction.bulkUpdateOutages(tfOneCarrierOutage, 123);
            fail("Throws TracfoneOneExcepton");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testViewAllServiceType() throws Exception {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setDbEnv("DBENV");
        List<TFOneServiceType> serviceType = new ArrayList<>();
        TFOneServiceType tfServcieType = new TFOneServiceType();
        tfServcieType.setServiceType("SERVICE_TYPE");
        tfServcieType.setServiceTypeCategory("SERVICE_TYPE_CATEGORY");
        tfServcieType.setRemarks("REMARKS");
        serviceType.add(tfServcieType);

        when(stmt.executeQuery()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMY_DATA");
        List<TFOneServiceType> response = tracfoneOneCarrierOutageAction.viewAllServiceTypes(tfOneServiceType);
        assertEquals("[TFOneServiceType{objId='DUMMY_DATA', serviceType='DUMMY_DATA', serviceTypeCategory='DUMMY_DATA', remarks='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testViewAllServiceType_withException() throws SQLException {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setDbEnv("DBENV");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneOneCarrierOutageAction.viewAllServiceTypes(tfOneServiceType);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertServiceType() throws TracfoneOneException, SQLException {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setServiceType("SERVICE_TYPE");
        tfOneServiceType.setServiceTypeCategory("SERVICE_TYPE_CATEGORY");
        tfOneServiceType.setRemarks("REMARKS");
        tfOneServiceType.setDbEnv("DBENV");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getLong(anyString())).thenReturn(1l);
        tfOneGeneralResponse = tracfoneOneCarrierOutageAction.insertServiceType(tfOneServiceType, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfOneServiceType.getObjId());
    }

    @Test
    public void testInsertServiceType_whenException() throws TracfoneOneException, SQLException {
        // When NPE
        try {
            tracfoneOneCarrierOutageAction.insertServiceType(null, 123);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setServiceType("SERVICE_TYPE");
        tfOneServiceType.setServiceTypeCategory("SERVICE_TYPE_CATEGORY");
        tfOneServiceType.setRemarks("REMARKS");
        tfOneServiceType.setDbEnv("DBENV");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getLong(anyString())).thenReturn(0l);
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneOneCarrierOutageAction.insertServiceType(tfOneServiceType, 123);
            fail("Throws TracfoneOneExcepton");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateServiceType() throws TracfoneOneException {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setServiceType("SERVICE_TYPE");
        tfOneServiceType.setServiceTypeCategory("SERVICE_TYPE_CATEGORY");
        tfOneServiceType.setRemarks("REMARKS");
        tfOneServiceType.setDbEnv("DBENV");
        tfOneServiceType.setObjId("100");
        tfOneGeneralResponse = tracfoneOneCarrierOutageAction.updateServiceType(tfOneServiceType, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfOneServiceType.getObjId());
    }

    @Test
    public void testUpdateServiceType_whenException() throws SQLException, TracfoneOneException {
        // When null is passed
        try {
            tracfoneOneCarrierOutageAction.updateServiceType(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setServiceType("SERVICE_TYPE");
        tfOneServiceType.setServiceTypeCategory("SERVICE_TYPE_CATEGORY");
        tfOneServiceType.setRemarks("REMARKS");
        tfOneServiceType.setDbEnv("DBENV");
        tfOneServiceType.setObjId("100");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneOneCarrierOutageAction.updateServiceType(tfOneServiceType, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteServiceType() throws TracfoneOneException {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setDbEnv("DBENV");
        tfOneServiceType.setObjId("100");
        tfOneGeneralResponse = tracfoneOneCarrierOutageAction.deleteServiceType(tfOneServiceType, 1);
        assertEquals(TFOneGeneralResponse.SUCCESS, tfOneGeneralResponse.getStatus());
        assertEquals("100", tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testDeleteServiceType_whenException() throws TracfoneOneException, SQLException {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setDbEnv("DBENV");
        tfOneServiceType.setObjId("100");
        // When dbEnv is null
        try {
            tracfoneOneCarrierOutageAction.deleteServiceType(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneOneCarrierOutageAction.deleteServiceType(tfOneServiceType, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testCheckServiceTypeDependencies() throws TracfoneOneException, SQLException {
        boolean dependencyExists = false;
        int count = 1;
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setDbEnv("DBENV");
        tfOneServiceType.setServiceType("DATA");
        doReturn(true).doReturn(false).when(resultSet).next();
        when(resultSet.getString("SERVICE_TYPE")).thenReturn("DATA,testing");
        dependencyExists = tracfoneOneCarrierOutageAction.checkServiceTypeDependencies(tfOneServiceType);
        assertTrue(dependencyExists);
        tfOneServiceType.setServiceType("help");
        dependencyExists = tracfoneOneCarrierOutageAction.checkServiceTypeDependencies(tfOneServiceType);
        assertFalse(dependencyExists);
    }

    @Test
    public void testCheckServiceTypeDependencies_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneOneCarrierOutageAction.checkServiceTypeDependencies(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setDbEnv("DBENV");
        tfOneServiceType.setServiceType("DATA");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneOneCarrierOutageAction.checkServiceTypeDependencies(tfOneServiceType);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}

