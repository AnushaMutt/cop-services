package com.tracfone.service.controller.retail;

import com.tracfone.ejb.entity.retail.CRtlBrand;
import com.tracfone.ejb.entity.retail.CRtlCarrier;
import com.tracfone.ejb.entity.retail.CRtlCarrierDtl;
import com.tracfone.ejb.entity.retail.CRtlCarrierPref;
import com.tracfone.ejb.entity.retail.CRtlCarrierPrefGrp;
import com.tracfone.ejb.entity.retail.CRtlMaster;
import com.tracfone.ejb.entity.retail.CRtlParent;
import com.tracfone.ejb.entity.retail.CRtlParentRule;
import com.tracfone.ejb.entity.retail.CRtlTech;
import com.tracfone.ejb.entity.retail.CRtlTpNorm;
import com.tracfone.ejb.entity.retail.CRtlTraitLogicRule;
import com.tracfone.ejb.entity.retail.session.CRtlBrandFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlCarrierDtlFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlCarrierFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlCarrierPrefFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlCarrierPrefGrpFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlMasterFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlParentFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlParentRuleFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlTechFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlTpNormFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlTraitLogicRuleFacadeLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneJobTask;
import com.tracfone.service.model.retail.request.TracfoneOneRetailBrand;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrier;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierDetail;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierPrefDetail;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierPrefGroup;
import com.tracfone.service.model.retail.request.TracfoneOneRetailLocation;
import com.tracfone.service.model.retail.request.TracfoneOneRetailMaster;
import com.tracfone.service.model.retail.request.TracfoneOneRetailParent;
import com.tracfone.service.model.retail.request.TracfoneOneRetailParentRule;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTech;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTpAdminSearchModel;
import com.tracfone.service.model.retail.request.TracfoneOneTraitLogicRule;
import com.tracfone.service.model.retail.response.TFOneRetailBrand;
import com.tracfone.service.model.retail.response.TFOneRetailCarrier;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierDetail;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierPrefDetail;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierPrefGroup;
import com.tracfone.service.model.retail.response.TFOneRetailMaster;
import com.tracfone.service.model.retail.response.TFOneRetailParent;
import com.tracfone.service.model.retail.response.TFOneRetailParentRule;
import com.tracfone.service.model.retail.response.TFOneRetailTech;
import com.tracfone.service.model.retail.response.TFOneRetailTpAdminSearchResults;
import com.tracfone.service.model.retail.response.TFOneTraitLogicRule;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_BRANDS;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_BRANDS_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_CARRIERS;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_CARRIERS_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_CARRIER_DETAILS;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_CARRIER_DETAILS_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_CARRIER_PREFS;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_CARRIER_PREFS_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_CARRIER_PREF_GROUPS;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_CARRIER_PREF_GROUPS_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_MASTERS;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_MASTERS_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_PARENTS;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_PARENTS_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_PARENT_RULES;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_PARENT_RULES_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_TECHS;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_TECHS_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_TRAIT_LOGIC_RULES;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_ALL_TRAIT_LOGIC_RULES_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_LAST_TRAIT_RUN_DATE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_LAST_TRAIT_RUN_DATE_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_RUN_STORE_TRAITS_SUCCESS;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_RUN_TRAITS_SUMMARY_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_RUN_TRAITS_SUMMARY;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneRetailAdminActionTest {
    @InjectMocks
    private TracfoneOneRetailAdminAction tracfoneOneRetailAdminAction;

    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @Mock
    private TracfoneAudit audit;
    @Mock
    CRtlCarrierFacadeLocal cRtlCarrierFacade;

    @Mock
    CRtlBrandFacadeLocal cRtlBrandFacade;

    @Mock
    CRtlTechFacadeLocal cRtlTechFacade;

    @Mock
    CRtlCarrierDtlFacadeLocal cRtlCarrierDtlFacade;

    @Mock
    CRtlTraitLogicRuleFacadeLocal cRtlTraitLogicRuleFacade;

    @Mock
    CRtlCarrierPrefGrpFacadeLocal cRtlCarrierPrefGrpFacade;

    @Mock
    CRtlTpNormFacadeLocal cRtlTpNormFacade;

    @Mock
    EntityManager entityManager;

    @Mock
    Query query;

    @Mock
    CRtlCarrierPrefFacadeLocal cRtlCarrierPrefFacade;

    @Mock
    CRtlParentFacadeLocal cRtlParentFacade;

    @Mock
    CRtlMasterFacadeLocal cRtlMasterFacade;

    @Mock
    CRtlParentRuleFacadeLocal cRtlParentRuleFacade;

    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "Success");
        tracfoneOneException = new TracfoneOneException("Error_Code", "Error_Message");
    }

    @Test
    public void testGetCarriers() throws Exception {
        List<CRtlCarrier> cRtlCarriers = new ArrayList<>();
        CRtlCarrier cRtlCarrier = new CRtlCarrier();
        cRtlCarrier.setSecUserId("100");
        cRtlCarriers.add(cRtlCarrier);
        when(cRtlCarrierFacade.findAll()).thenReturn(cRtlCarriers);
        List<TFOneRetailCarrier> response = tracfoneOneRetailAdminAction.getCarriers();
        assertEquals("[TFOneRetailCarrier{objId='null', secUserId=100, status='null', carrier='null', carrierLong='null', insertDate=null, updateDate=null}]", response.toString());
    }

    @Test
    public void testGetCarriers_whenException() {
        doThrow(RuntimeException.class).when(cRtlCarrierFacade).findAll();
        try {
            tracfoneOneRetailAdminAction.getCarriers();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_CARRIERS, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_CARRIERS_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrier() throws Exception {
        TracfoneOneRetailCarrier tfCRtlCarrier = new TracfoneOneRetailCarrier();
        tfCRtlCarrier.setCarrier("CARRIER");
        tfCRtlCarrier.setCarrierLong("CARRIER_LONG");
        tfCRtlCarrier.setSecUserId("1000");
        tfCRtlCarrier.setStatus("STATUS");
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.insertCarrier(tfCRtlCarrier, 318);
        assertEquals("Carrier created successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testInsertCarrier_whenException() throws Exception {
        TracfoneOneRetailCarrier tfCRtlCarrier = new TracfoneOneRetailCarrier();
        tfCRtlCarrier.setCarrier("CARRIER");
        tfCRtlCarrier.setCarrierLong("CARRIER_LONG");
        tfCRtlCarrier.setSecUserId("1000");
        tfCRtlCarrier.setStatus("STATUS");
        doThrow(RuntimeException.class).when(cRtlCarrierFacade).create(any());
        try {
            tracfoneOneRetailAdminAction.insertCarrier(tfCRtlCarrier, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetBrands() throws Exception {
        List<CRtlBrand> brands = new ArrayList<>();
        CRtlBrand cRtlBrand = new CRtlBrand();
        cRtlBrand.setStatus("OK");
        brands.add(cRtlBrand);
        when(cRtlBrandFacade.findAll()).thenReturn(brands);
        List<TFOneRetailBrand> response = tracfoneOneRetailAdminAction.getBrands();
        assertEquals("[TFOneRetailBrand{objId='null', oneSecUserId='null', status='OK', brand='null', brandLong='null', insertDate=null, updateDate=null, cRtlTraitLogicRuleId='null'}]", response.toString());
    }

    @Test
    public void testGetBrands_whenException() {
        doThrow(RuntimeException.class).when(cRtlBrandFacade).findAll();
        try {
            tracfoneOneRetailAdminAction.getBrands();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_BRANDS, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_BRANDS_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void insertBrand() throws Exception {
        TracfoneOneRetailBrand tfOneCRtlBrand = new TracfoneOneRetailBrand();
        tfOneCRtlBrand.setBrand("BRAND");
        tfOneCRtlBrand.setBrandLong("BRAND_LONG");
        tfOneCRtlBrand.setTraitLogicRuleId("1000");
        tfOneCRtlBrand.setSecUserId("1000");
        tfOneCRtlBrand.setStatus("STATUS");
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.insertBrand(tfOneCRtlBrand, 318);
        assertEquals("Brand created successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testInsertBrand_whenException() throws Exception {
        TracfoneOneRetailBrand tfOneCRtlBrand = new TracfoneOneRetailBrand();
        tfOneCRtlBrand.setBrand("BRAND");
        tfOneCRtlBrand.setBrandLong("BRAND_LONG");
        tfOneCRtlBrand.setTraitLogicRuleId("1000");
        tfOneCRtlBrand.setSecUserId("1000");
        tfOneCRtlBrand.setStatus("STATUS");
        doThrow(RuntimeException.class).when(cRtlBrandFacade).create(any());
        try {
            tracfoneOneRetailAdminAction.insertBrand(tfOneCRtlBrand, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetTechs() throws Exception {
        List<CRtlTech> cRtlTeches = new ArrayList<>();
        CRtlTech cRtlTech = new CRtlTech();
        cRtlTech.setTech("TECH");
        cRtlTech.setObjid(BigDecimal.valueOf(10));
        cRtlTeches.add(cRtlTech);
        when(cRtlTechFacade.findAll()).thenReturn(cRtlTeches);
        List<TFOneRetailTech> response = tracfoneOneRetailAdminAction.getTechs();
        assertEquals("[TFOneRetailTech{objId='10', secUserId='null', status='null', tech='TECH', techLong='null', insertDate=null, updateDate=null}]", response.toString());
    }

    @Test
    public void testGetTechs_whenException() {
        doThrow(RuntimeException.class).when(cRtlTechFacade).findAll();
        try {
            tracfoneOneRetailAdminAction.getTechs();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_TECHS, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_TECHS_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertTech() throws Exception {
        TracfoneOneRetailTech tfOneCRtlTech = new TracfoneOneRetailTech();
        tfOneCRtlTech.setSecUserId("1000");
        tfOneCRtlTech.setStatus("STATUS");
        tfOneCRtlTech.setTech("TECH");
        tfOneCRtlTech.setTechLong("TECH_LONG");
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.insertTech(tfOneCRtlTech, 318);
        assertEquals("Tech created successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }


    @Test
    public void testInsertTech_whenException() {
        TracfoneOneRetailTech tfOneCRtlTech = new TracfoneOneRetailTech();
        tfOneCRtlTech.setSecUserId("1000");
        tfOneCRtlTech.setStatus("STATUS");
        tfOneCRtlTech.setTech("TECH");
        tfOneCRtlTech.setTechLong("TECH_LONG");
        doThrow(RuntimeException.class).when(cRtlTechFacade).create(any());
        try {
            tracfoneOneRetailAdminAction.insertTech(tfOneCRtlTech, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierDetail() throws Exception {
        TracfoneOneRetailCarrierDetail tfOneCrtlCarrierDtl = new TracfoneOneRetailCarrierDetail();
        tfOneCrtlCarrierDtl.setStatus("STATUS");
        tfOneCrtlCarrierDtl.setCdtl2Brand("1000");
        tfOneCrtlCarrierDtl.setCdtl2Carrier("1000");
        tfOneCrtlCarrierDtl.setCdtl2Tech("1000");
        tfOneCrtlCarrierDtl.setCdtl2User("1000");
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.insertCarrierDetail(tfOneCrtlCarrierDtl, 318);
        assertEquals("Carrier Detail created successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testInsertCarrierDetail_whenException() {
        TracfoneOneRetailCarrierDetail tfOneCrtlCarrierDtl = new TracfoneOneRetailCarrierDetail();
        tfOneCrtlCarrierDtl.setStatus("STATUS");
        tfOneCrtlCarrierDtl.setCdtl2Brand("1000");
        tfOneCrtlCarrierDtl.setCdtl2Carrier("1000");
        tfOneCrtlCarrierDtl.setCdtl2Tech("1000");
        tfOneCrtlCarrierDtl.setCdtl2User("1000");
        doThrow(RuntimeException.class).when(cRtlCarrierDtlFacade).create(any());
        try {
            tracfoneOneRetailAdminAction.insertCarrierDetail(tfOneCrtlCarrierDtl, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCarrierDetails() throws Exception {
        List<CRtlCarrierDtl> cRtlCarrierDtls = new ArrayList<>();
        CRtlCarrierDtl cRtlCarrierDtl = new CRtlCarrierDtl();
        cRtlCarrierDtl.setObjid(BigDecimal.valueOf(1000));
        cRtlCarrierDtl.setStatus("STATUS");
        cRtlCarrierDtl.setcRtlBrandId("1000");
        cRtlCarrierDtl.setcRtlCarrierId("1000");
        cRtlCarrierDtl.setSecUserId("1000");
        cRtlCarrierDtl.setcRtlTechId("1000");
        cRtlCarrierDtls.add(cRtlCarrierDtl);
        when(cRtlCarrierDtlFacade.findAll()).thenReturn(cRtlCarrierDtls);
        List<TFOneRetailCarrierDetail> response = tracfoneOneRetailAdminAction.getCarrierDetails();
        assertEquals("[TFOneRetailCarrierDetail{objId='1000', status='STATUS', cdtl2Carrier='1000', cdtl2Brand='1000', cdtl2Tech='1000', cdtl2User='null', insertDate=null, updateDate=null}]", response.toString());
    }


    @Test
    public void testGetCarrierDetails_whenException() {
        doThrow(RuntimeException.class).when(cRtlCarrierDtlFacade).findAll();
        try {
            tracfoneOneRetailAdminAction.getCarrierDetails();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_CARRIER_DETAILS, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_CARRIER_DETAILS_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetTraitLogicRules() throws Exception {
        List<CRtlTraitLogicRule> cRtlTraitLogicRules = new ArrayList<>();
        CRtlTraitLogicRule cRtlTraitLogicRule = new CRtlTraitLogicRule();
        cRtlTraitLogicRule.setInnerGeo(BigDecimal.valueOf(1000));
        cRtlTraitLogicRule.setInnerPop(BigDecimal.valueOf(1000));
        cRtlTraitLogicRule.setInnerRadius(BigDecimal.valueOf(1000));
        cRtlTraitLogicRule.setObjid(BigDecimal.valueOf(1000));
        cRtlTraitLogicRule.setOuterGeo(BigDecimal.valueOf(1000));
        cRtlTraitLogicRule.setOuterPop(BigDecimal.valueOf(1000));
        cRtlTraitLogicRule.setOuterRadius(BigDecimal.valueOf(1000));
        cRtlTraitLogicRule.setPrefAllCarr(BigDecimal.valueOf(1000));
        cRtlTraitLogicRule.setRule2Logic("1000");
        cRtlTraitLogicRule.setRuleName("1000");
        cRtlTraitLogicRule.setSecUserId("1000");
        cRtlTraitLogicRule.setUseOuterPop(BigDecimal.valueOf(1000));
        cRtlTraitLogicRules.add(cRtlTraitLogicRule);
        when(cRtlTraitLogicRuleFacade.findAll()).thenReturn(cRtlTraitLogicRules);
        List<TFOneTraitLogicRule> response = tracfoneOneRetailAdminAction.getTraitLogicRules();
        assertEquals("[TFOneTraitLogicRule{objId='1000', ruleName='1000', innerRadius='1000', innerPop='1000', innerGeo='1000', outerRadius='1000', outerPop='1000', outerGeo='1000', useOuterPop='1000', rule2Logic='1000', rule2User='1000', prefAllCarr='1000'}]", response.toString());
    }

    @Test
    public void testGetTraitLogicRules_whenException() {
        doThrow(RuntimeException.class).when(cRtlTraitLogicRuleFacade).findAll();
        try {
            tracfoneOneRetailAdminAction.getTraitLogicRules();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_TRAIT_LOGIC_RULES, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_TRAIT_LOGIC_RULES_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCarrierPrefGroups() throws Exception {
        List<CRtlCarrierPrefGrp> cRtlCarrierPrefGrps = new ArrayList<>();
        CRtlCarrierPrefGrp cRtlCarrierPrefGrp = new CRtlCarrierPrefGrp();
        cRtlCarrierPrefGrp.setcPrefGrp2Brand(BigDecimal.valueOf(100));
        cRtlCarrierPrefGrp.setDescription("DESC");
        cRtlCarrierPrefGrp.setStatus("STATUS");
        cRtlCarrierPrefGrp.setSecUserId(BigDecimal.valueOf(10));
        cRtlCarrierPrefGrp.setObjid(BigDecimal.valueOf(10));
        cRtlCarrierPrefGrps.add(cRtlCarrierPrefGrp);
        when(cRtlCarrierPrefGrpFacade.findAll()).thenReturn(cRtlCarrierPrefGrps);
        List<TFOneRetailCarrierPrefGroup> response = tracfoneOneRetailAdminAction.getCarrierPrefGroups();
        assertEquals("[TFOneRetailCarrierPrefGroup{objId='10', secUserId='10', status='STATUS', description='DESC', brand='100', insertDate=null, updateDate=null, carrierPrefDetails=[]}]", response.toString());
    }

    @Test
    public void testGetCarrierPrefGroups_whenException() {
        doThrow(RuntimeException.class).when(cRtlCarrierPrefGrpFacade).findAll();
        try {
            tracfoneOneRetailAdminAction.getCarrierPrefGroups();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_CARRIER_PREF_GROUPS, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_CARRIER_PREF_GROUPS_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCarrierPrefDetails() throws Exception {
        List<CRtlCarrierPrefGrp> cRtlCarrierPrefGrps = new ArrayList<>();
        CRtlCarrierPrefGrp cRtlCarrierPrefGrp = new CRtlCarrierPrefGrp();
        cRtlCarrierPrefGrp.setcPrefGrp2Brand(BigDecimal.valueOf(100));
        cRtlCarrierPrefGrp.setDescription("DESC");
        cRtlCarrierPrefGrp.setStatus("STATUS");
        cRtlCarrierPrefGrp.setSecUserId(BigDecimal.valueOf(10));
        cRtlCarrierPrefGrp.setObjid(BigDecimal.valueOf(10));
        cRtlCarrierPrefGrps.add(cRtlCarrierPrefGrp);

        List<Object[]> objects = new ArrayList<>();
        Object[] object = {"CARRIER_0", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1"};
        objects.add(object);
        when(cRtlCarrierPrefFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(objects);

        List<TFOneRetailCarrierPrefDetail> response = tracfoneOneRetailAdminAction.getCarrierPrefDetails("1000");
        assertEquals("[TFOneRetailCarrierPrefDetail{objId='CARRIER_0', carrierPrefGroupId='CARRIER_1', carrierDetailId='CARRIER_1', rank='CARRIER_1', carrier='CARRIER_1', brand='CARRIER_1', tech='CARRIER_1'}]", response.toString());
    }

    @Test
    public void testGetCarrierPrefDetails_whenException() {
        when(cRtlCarrierPrefFacade.getEntityManager()).thenReturn(entityManager);
        doThrow(RuntimeException.class).when(entityManager).createNativeQuery(anyString());
        try {
            tracfoneOneRetailAdminAction.getCarrierPrefDetails("1000");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_CARRIER_PREFS, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_CARRIER_PREFS_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierPrefGroup() throws Exception {
        TracfoneOneRetailCarrierPrefGroup tracfoneOneRetailCarrierPrefGroup = new TracfoneOneRetailCarrierPrefGroup();
        tracfoneOneRetailCarrierPrefGroup.setBrand("1000");
        tracfoneOneRetailCarrierPrefGroup.setDescription("DESC");
        tracfoneOneRetailCarrierPrefGroup.setStatus("STATUS");
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.insertCarrierPrefGroup(tracfoneOneRetailCarrierPrefGroup, 318);
        assertEquals("Carrier Pref Group created successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testInsertCarrierPrefGroup_whenException() {
        TracfoneOneRetailCarrierPrefGroup tracfoneOneRetailCarrierPrefGroup = new TracfoneOneRetailCarrierPrefGroup();
        tracfoneOneRetailCarrierPrefGroup.setBrand("1000");
        tracfoneOneRetailCarrierPrefGroup.setDescription("DESC");
        tracfoneOneRetailCarrierPrefGroup.setStatus("STATUS");
        doThrow(RuntimeException.class).when(cRtlCarrierPrefGrpFacade).create(any());
        try {
            tracfoneOneRetailAdminAction.insertCarrierPrefGroup(tracfoneOneRetailCarrierPrefGroup, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void getCarrierDetailsByBrand() throws Exception {
        List<Object[]> objects = new ArrayList<>();
        Object[] object = {"CARRIER_0", "CARRIER_1", Date.valueOf("2017-02-06"), Date.valueOf("2017-02-06"), "CARRIER_1", "CARRIER_1", "CARRIER_1"};
        objects.add(object);
        when(cRtlCarrierDtlFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(objects);
        List<TFOneRetailCarrierDetail> response = tracfoneOneRetailAdminAction.getCarrierDetailsByBrand("101");
        assertEquals("[TFOneRetailCarrierDetail{objId='CARRIER_0', status='CARRIER_1', cdtl2Carrier='CARRIER_1', cdtl2Brand='CARRIER_1', cdtl2Tech='CARRIER_1', cdtl2User='null', insertDate=2017:02:06 00:00:00, updateDate=2017:02:06 00:00:00}]", response.toString());
    }

    @Test
    public void testGetCarrierDetailsByBrand_whenException() {
        when(cRtlCarrierDtlFacade.getEntityManager()).thenReturn(entityManager);
        doThrow(RuntimeException.class).when(entityManager).createNativeQuery(anyString());
        try {
            tracfoneOneRetailAdminAction.getCarrierDetailsByBrand("1000");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_CARRIER_DETAILS, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_CARRIER_DETAILS_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrier() throws Exception {
        CRtlCarrier carrier = new CRtlCarrier();
        carrier.setCarrier("CARRIER");
        carrier.setStatus("STATUS");
        carrier.setSecUserId("1000");
        carrier.setObjid(BigDecimal.valueOf(1000));

        TracfoneOneRetailCarrier tfCRtlCarrier = new TracfoneOneRetailCarrier();
        tfCRtlCarrier.setCarrier("CARRIER");
        tfCRtlCarrier.setCarrierLong("CARRIER_LONG");
        tfCRtlCarrier.setStatus("STATUS");
        tfCRtlCarrier.setSecUserId("1000");
        tfCRtlCarrier.setObjId("1000");
        when(cRtlCarrierFacade.find(any())).thenReturn(carrier);
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.updateCarrier(tfCRtlCarrier, 318);
        assertEquals("Carrier updated successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testUpdateCarrier_whenException() {
        TracfoneOneRetailCarrier tfCRtlCarrier = new TracfoneOneRetailCarrier();
        tfCRtlCarrier.setCarrier("CARRIER");
        tfCRtlCarrier.setCarrierLong("CARRIER_LONG");
        tfCRtlCarrier.setStatus("STATUS");
        tfCRtlCarrier.setSecUserId("1000");
        tfCRtlCarrier.setObjId("1000");
        doThrow(RuntimeException.class).when(cRtlCarrierFacade).find(any());
        try {
            tracfoneOneRetailAdminAction.updateCarrier(tfCRtlCarrier, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateBrand() throws Exception {
        CRtlBrand brand = new CRtlBrand();
        brand.setBrand("BRAND");
        brand.setcRtlTraitLogicRuleId("1000");
        brand.setStatus("STATUS");
        brand.setSecUserId("1000");
        brand.setObjid(BigDecimal.valueOf(1000));
        brand.setBrandLong("BRAND_LONG");

        TracfoneOneRetailBrand tfOneCRtlBrand = new TracfoneOneRetailBrand();
        tfOneCRtlBrand.setBrand("BRAND");
        tfOneCRtlBrand.setBrandLong("BRAND_LONG");
        tfOneCRtlBrand.setTraitLogicRuleId("1000");
        tfOneCRtlBrand.setStatus("STATUS");
        tfOneCRtlBrand.setSecUserId("1000");
        tfOneCRtlBrand.setObjId("1000");
        tfOneCRtlBrand.setBrandLong("BRAND_LONG");

        when(cRtlBrandFacade.find(any())).thenReturn(brand);
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.updateBrand(tfOneCRtlBrand, 318);
        assertEquals("Brand updated successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testUpdateBrand_whenException() {
        TracfoneOneRetailBrand tfOneCRtlBrand = new TracfoneOneRetailBrand();
        tfOneCRtlBrand.setBrand("BRAND");
        tfOneCRtlBrand.setBrandLong("BRAND_LONG");
        tfOneCRtlBrand.setTraitLogicRuleId("1000");
        tfOneCRtlBrand.setStatus("STATUS");
        tfOneCRtlBrand.setSecUserId("1000");
        tfOneCRtlBrand.setObjId("1000");
        tfOneCRtlBrand.setBrandLong("BRAND_LONG");
        doThrow(RuntimeException.class).when(cRtlBrandFacade).find(any());
        try {
            tracfoneOneRetailAdminAction.updateBrand(tfOneCRtlBrand, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateTech() throws Exception {
        CRtlTech tech = new CRtlTech();
        tech.setSecUserId("1000");
        tech.setTechLong("TECH_LONG");
        tech.setTech("TECH");
        tech.setStatus("STATUS");
        tech.setObjid(BigDecimal.valueOf(1000));

        TracfoneOneRetailTech tfOneCRtlTech = new TracfoneOneRetailTech();
        tfOneCRtlTech.setSecUserId("1000");
        tfOneCRtlTech.setTechLong("TECH_LONG");
        tfOneCRtlTech.setTech("TECH");
        tfOneCRtlTech.setStatus("STATUS");
        tfOneCRtlTech.setObjId("1000");

        when(cRtlTechFacade.find(any())).thenReturn(tech);

        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.updateTech(tfOneCRtlTech, 318);
        assertEquals("Tech updated successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testUpdateTech_whenException() {
        TracfoneOneRetailTech tfOneCRtlTech = new TracfoneOneRetailTech();
        tfOneCRtlTech.setSecUserId("1000");
        tfOneCRtlTech.setTechLong("TECH_LONG");
        tfOneCRtlTech.setTech("TECH");
        tfOneCRtlTech.setStatus("STATUS");
        tfOneCRtlTech.setObjId("1000");

        doThrow(RuntimeException.class).when(cRtlTechFacade).find(any());
        try {
            tracfoneOneRetailAdminAction.updateTech(tfOneCRtlTech, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierDetail() throws Exception {
        TracfoneOneRetailCarrierDetail tfOneCrtlCarrierDtl = new TracfoneOneRetailCarrierDetail();
        tfOneCrtlCarrierDtl.setStatus("STATUS");
        tfOneCrtlCarrierDtl.setCdtl2Brand("BRAND");
        tfOneCrtlCarrierDtl.setCdtl2Carrier("CARRIER");
        tfOneCrtlCarrierDtl.setCdtl2Tech("TECH");
        tfOneCrtlCarrierDtl.setCdtl2User("1000");
        tfOneCrtlCarrierDtl.setObjId("1000");

        CRtlCarrierDtl carrierDtl = new CRtlCarrierDtl();
        carrierDtl.setcRtlTechId("1000");
        carrierDtl.setSecUserId("1000");
        carrierDtl.setcRtlCarrierId("1000");
        carrierDtl.setcRtlBrandId("1000");
        carrierDtl.setStatus("STATUS");
        carrierDtl.setObjid(BigDecimal.valueOf(1000));
        when(cRtlCarrierDtlFacade.find(any())).thenReturn(carrierDtl);

        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.updateCarrierDetail(tfOneCrtlCarrierDtl, 318);
        assertEquals("Carrier Detail updated successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testUpdateCarrierDetail_whenException() {
        TracfoneOneRetailCarrierDetail tfOneCrtlCarrierDtl = new TracfoneOneRetailCarrierDetail();
        tfOneCrtlCarrierDtl.setStatus("STATUS");
        tfOneCrtlCarrierDtl.setCdtl2Brand("BRAND");
        tfOneCrtlCarrierDtl.setCdtl2Carrier("CARRIER");
        tfOneCrtlCarrierDtl.setCdtl2Tech("TECH");
        tfOneCrtlCarrierDtl.setCdtl2User("1000");
        tfOneCrtlCarrierDtl.setObjId("1000");
        doThrow(RuntimeException.class).when(cRtlCarrierDtlFacade).find(any());
        try {
            tracfoneOneRetailAdminAction.updateCarrierDetail(tfOneCrtlCarrierDtl, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierPrefGroup() throws Exception {
        TracfoneOneRetailCarrierPrefGroup tracfoneOneRetailCarrierPrefGroup = new TracfoneOneRetailCarrierPrefGroup();
        tracfoneOneRetailCarrierPrefGroup.setBrand("1000");
        tracfoneOneRetailCarrierPrefGroup.setStatus("STATUS");
        tracfoneOneRetailCarrierPrefGroup.setDescription("DESCRIPTION");
        tracfoneOneRetailCarrierPrefGroup.setObjId("1000");

        CRtlCarrierPrefGrp carrierPrefGrp = new CRtlCarrierPrefGrp();
        carrierPrefGrp.setObjid(BigDecimal.valueOf(1000));
        carrierPrefGrp.setSecUserId(BigDecimal.valueOf(1000));
        carrierPrefGrp.setStatus("1000");
        carrierPrefGrp.setDescription("1000");
        carrierPrefGrp.setcPrefGrp2Brand(BigDecimal.valueOf(1000));
        when(cRtlCarrierPrefGrpFacade.find(any())).thenReturn(carrierPrefGrp);

        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.updateCarrierPrefGroup(tracfoneOneRetailCarrierPrefGroup, 318);
        assertEquals("Carrier Pref Group updated successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testUpdateCarrierPrefGroup_whenException() {
        TracfoneOneRetailCarrierPrefGroup tracfoneOneRetailCarrierPrefGroup = new TracfoneOneRetailCarrierPrefGroup();
        tracfoneOneRetailCarrierPrefGroup.setBrand("BRAND");
        tracfoneOneRetailCarrierPrefGroup.setStatus("STATUS");
        tracfoneOneRetailCarrierPrefGroup.setDescription("DESCRIPTION");
        tracfoneOneRetailCarrierPrefGroup.setObjId("1000");
        doThrow(RuntimeException.class).when(cRtlCarrierPrefGrpFacade).find(any());
        try {
            tracfoneOneRetailAdminAction.updateCarrierPrefGroup(tracfoneOneRetailCarrierPrefGroup, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetParents() throws Exception {
        List<Object[]> objects = new ArrayList<>();
        Object[] object = {"1000", "A", "CARRIER", "DUMMAY", "DUMMAY", "DUMMAY", "DUMMAY"};
        objects.add(object);
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(objects);

        List<TFOneRetailParent> response = tracfoneOneRetailAdminAction.getParents();
        assertEquals("[TFOneRetailParent{objId='1000', status='A', retailer='CARRIER', secUserId='DUMMAY', insertDate='DUMMAY', updateDate='DUMMAY', lastTraitRunDate='A'}]", response.toString());
    }


    @Test
    public void testGetParents_whenException() {
        doThrow(RuntimeException.class).when(cRtlTpNormFacade).getEntityManager();
        try {
            tracfoneOneRetailAdminAction.getParents();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_PARENTS, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_PARENTS_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetMasters() throws Exception {
        List<CRtlMaster> cRtlMasters = new ArrayList<>();
        CRtlMaster cRtlMaster = new CRtlMaster();
        cRtlMaster.setStatus("STATUS");
        cRtlMaster.setStoreName("SHORT_NAME");
        cRtlMaster.setMaster2Parent(BigDecimal.valueOf(1000));
        cRtlMaster.setSecUserId(BigDecimal.valueOf(1000));
        cRtlMaster.setObjid(BigDecimal.valueOf(1000));
        cRtlMasters.add(cRtlMaster);
        when(cRtlMasterFacade.findAllByParent(any())).thenReturn(cRtlMasters);
        List<TFOneRetailMaster> response = tracfoneOneRetailAdminAction.getMasters("1000");
        assertEquals("[TFOneRetailMaster{objId='1000', status='STATUS', storeName='SHORT_NAME', master2Parent='1000', secUserId='1000', insertDate=null, updateDate=null}]", response.toString());
    }


    @Test
    public void testGetMasters_whenException() {
        doThrow(RuntimeException.class).when(cRtlMasterFacade).findAllByParent(any());
        try {
            tracfoneOneRetailAdminAction.getMasters("1000");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_MASTERS, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_MASTERS_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertParent() throws Exception {
        TracfoneOneRetailParent tracfoneOneRetailParent = new TracfoneOneRetailParent();
        tracfoneOneRetailParent.setObjId("1000");
        tracfoneOneRetailParent.setRetailer("RETAILER");
        tracfoneOneRetailParent.setSecUserId("1000");
        tracfoneOneRetailParent.setStatus("STATUS");
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.insertParent(tracfoneOneRetailParent, 318);
        assertEquals("Parent created successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testInsertParent_whenException() {
        TracfoneOneRetailParent tracfoneOneRetailParent = new TracfoneOneRetailParent();
        tracfoneOneRetailParent.setObjId("1000");
        tracfoneOneRetailParent.setRetailer("RETAILER");
        tracfoneOneRetailParent.setSecUserId("1000");
        tracfoneOneRetailParent.setStatus("STATUS");
        doThrow(RuntimeException.class).when(cRtlParentFacade).create(any());
        try {
            tracfoneOneRetailAdminAction.insertParent(tracfoneOneRetailParent, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateParent() throws Exception {
        TracfoneOneRetailParent tracfoneOneRetailParent = new TracfoneOneRetailParent();
        tracfoneOneRetailParent.setObjId("1000");
        tracfoneOneRetailParent.setRetailer("RETAILER");
        tracfoneOneRetailParent.setSecUserId("1000");
        tracfoneOneRetailParent.setStatus("STATUS");
        CRtlParent cRtlParent = new CRtlParent();
        cRtlParent.setObjid(BigDecimal.valueOf(1000));
        cRtlParent.setRetailer("RETAILER");
        cRtlParent.setSecUserId(BigDecimal.valueOf(1000));
        cRtlParent.setStatus("STATUS");
        when(cRtlParentFacade.find(any())).thenReturn(cRtlParent);

        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.updateParent(tracfoneOneRetailParent, 318);
        assertEquals("Parent updated successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testUpdateParent_whenException() {
        TracfoneOneRetailParent tracfoneOneRetailParent = new TracfoneOneRetailParent();
        tracfoneOneRetailParent.setObjId("1000");
        tracfoneOneRetailParent.setRetailer("RETAILER");
        tracfoneOneRetailParent.setSecUserId("1000");
        tracfoneOneRetailParent.setStatus("STATUS");
        doThrow(RuntimeException.class).when(cRtlParentFacade).find(any());
        try {
            tracfoneOneRetailAdminAction.updateParent(tracfoneOneRetailParent, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertMaster() throws Exception {
        TracfoneOneRetailMaster tracfoneOneRetailMaster = new TracfoneOneRetailMaster();
        tracfoneOneRetailMaster.setMaster2Parent("1000");
        tracfoneOneRetailMaster.setObjId("1000");
        tracfoneOneRetailMaster.setSecUserId("1000");
        tracfoneOneRetailMaster.setStatus("STATUS");
        tracfoneOneRetailMaster.setStoreName("STORE_NAME");
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.insertMaster(tracfoneOneRetailMaster, 318);
        assertEquals("Master created successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testInsertMaster_whenException() {
        TracfoneOneRetailMaster tracfoneOneRetailMaster = new TracfoneOneRetailMaster();
        tracfoneOneRetailMaster.setMaster2Parent("1000");
        tracfoneOneRetailMaster.setObjId("1000");
        tracfoneOneRetailMaster.setSecUserId("1000");
        tracfoneOneRetailMaster.setStatus("STATUS");
        doThrow(RuntimeException.class).when(cRtlMasterFacade).create(any());
        try {
            tracfoneOneRetailAdminAction.insertMaster(tracfoneOneRetailMaster, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateMaster() throws Exception {
        TracfoneOneRetailMaster tracfoneOneRetailMaster = new TracfoneOneRetailMaster();
        tracfoneOneRetailMaster.setMaster2Parent("1000");
        tracfoneOneRetailMaster.setObjId("1000");
        tracfoneOneRetailMaster.setSecUserId("1000");
        tracfoneOneRetailMaster.setStatus("STATUS");
        tracfoneOneRetailMaster.setStoreName("STORE_NAME");

        CRtlMaster cRtlMaster = new CRtlMaster();
        cRtlMaster.setObjid(BigDecimal.valueOf(1000));
        cRtlMaster.setSecUserId(BigDecimal.valueOf(1000));
        cRtlMaster.setMaster2Parent(BigDecimal.valueOf(1000));
        cRtlMaster.setStoreName("SHORT_NAME");
        when(cRtlMasterFacade.find(any())).thenReturn(cRtlMaster);

        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.updateMaster(tracfoneOneRetailMaster, 318);
        assertEquals("Master updated successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testUpdateMaster_whenException() {
        TracfoneOneRetailMaster tracfoneOneRetailMaster = new TracfoneOneRetailMaster();
        tracfoneOneRetailMaster.setMaster2Parent("1000");
        tracfoneOneRetailMaster.setObjId("1000");
        tracfoneOneRetailMaster.setSecUserId("1000");
        tracfoneOneRetailMaster.setStatus("STATUS");
        doThrow(RuntimeException.class).when(cRtlMasterFacade).find(any());
        try {
            tracfoneOneRetailAdminAction.updateMaster(tracfoneOneRetailMaster, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetParentRules() throws Exception {
        List<CRtlParentRule> cRtlParentRules = new ArrayList<>();
        CRtlParentRule cRtlParentRule = new CRtlParentRule();
        cRtlParentRule.setRule2cPrefGrpRank(BigDecimal.valueOf(1000));
        cRtlParentRule.setRule2cPrefGrpTrait(BigDecimal.valueOf(1000));
        cRtlParentRule.setRule2TraitRule(BigDecimal.valueOf(1000));
        cRtlParentRule.setRule2Parent(BigDecimal.valueOf(1000));
        cRtlParentRule.setObjid(BigDecimal.valueOf(1000));
        cRtlParentRules.add(cRtlParentRule);
        when(cRtlParentRuleFacade.findAllByParent(any())).thenReturn(cRtlParentRules);
        List<TFOneRetailParentRule> response = tracfoneOneRetailAdminAction.getParentRules("1000");
        assertEquals("[TFOneRetailParentRule{objId='1000', rule2Parent='1000', rule2cPrefGrpTrait='1000', rule2cPrefGrpRank='1000', rule2TraitRule='1000'}]", response.toString());
    }

    @Test
    public void testGetParentRules_whenException() {
        doThrow(RuntimeException.class).when(cRtlParentRuleFacade).findAllByParent(any());
        try {
            tracfoneOneRetailAdminAction.getParentRules("1000");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_PARENT_RULES, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_PARENT_RULES_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertParentRule() throws Exception {
        TracfoneOneRetailParentRule tracfoneOneRetailParentRule = new TracfoneOneRetailParentRule();
        tracfoneOneRetailParentRule.setObjId("1000");
        tracfoneOneRetailParentRule.setRule2cPrefGrpRank("1000");
        tracfoneOneRetailParentRule.setRule2cPrefGrpTrait("1000");
        tracfoneOneRetailParentRule.setRule2Parent("1000");
        tracfoneOneRetailParentRule.setRule2TraitRule("1000");
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.insertParentRule(tracfoneOneRetailParentRule, 318);
        assertEquals("Parent Rule created successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testInsertParentRule_whenException() {
        TracfoneOneRetailParentRule tracfoneOneRetailParentRule = new TracfoneOneRetailParentRule();
        tracfoneOneRetailParentRule.setObjId("1000");
        tracfoneOneRetailParentRule.setRule2cPrefGrpRank("1000");
        tracfoneOneRetailParentRule.setRule2cPrefGrpTrait("1000");
        tracfoneOneRetailParentRule.setRule2Parent("1000");
        tracfoneOneRetailParentRule.setRule2TraitRule("1000");
        doThrow(RuntimeException.class).when(cRtlParentRuleFacade).create(any());
        try {
            tracfoneOneRetailAdminAction.insertParentRule(tracfoneOneRetailParentRule, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateParentRule() throws Exception {
        CRtlParentRule cRtlParentRule = new CRtlParentRule();
        cRtlParentRule.setObjid(BigDecimal.valueOf(1000));
        cRtlParentRule.setRule2cPrefGrpRank(BigDecimal.valueOf(1000));
        cRtlParentRule.setRule2cPrefGrpTrait(BigDecimal.valueOf(1000));
        cRtlParentRule.setRule2Parent(BigDecimal.valueOf(1000));
        cRtlParentRule.setRule2TraitRule(BigDecimal.valueOf(1000));

        TracfoneOneRetailParentRule tracfoneOneRetailParentRule = new TracfoneOneRetailParentRule();
        tracfoneOneRetailParentRule.setObjId("1000");
        tracfoneOneRetailParentRule.setRule2cPrefGrpRank("1000");
        tracfoneOneRetailParentRule.setRule2cPrefGrpTrait("1000");
        tracfoneOneRetailParentRule.setRule2Parent("1000");
        tracfoneOneRetailParentRule.setRule2TraitRule("1000");

        when(cRtlParentRuleFacade.find(any())).thenReturn(cRtlParentRule);
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.updateParentRule(tracfoneOneRetailParentRule, 318);
        assertEquals("Parent Rule update successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testUpdateParentRule_whenException() {
        TracfoneOneRetailParentRule tracfoneOneRetailParentRule = new TracfoneOneRetailParentRule();
        tracfoneOneRetailParentRule.setObjId("1000");
        tracfoneOneRetailParentRule.setRule2cPrefGrpRank("1000");
        tracfoneOneRetailParentRule.setRule2cPrefGrpTrait("1000");
        tracfoneOneRetailParentRule.setRule2Parent("1000");
        tracfoneOneRetailParentRule.setRule2TraitRule("1000");
        doThrow(RuntimeException.class).when(cRtlParentRuleFacade).find(any());
        try {
            tracfoneOneRetailAdminAction.updateParentRule(tracfoneOneRetailParentRule, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierPrefDetail() throws Exception {
        TracfoneOneRetailCarrierPrefDetail tracfoneOneRetailCarrierPrefDetail = new TracfoneOneRetailCarrierPrefDetail();
        tracfoneOneRetailCarrierPrefDetail.setRank("1000");
        tracfoneOneRetailCarrierPrefDetail.setCarrierPrefGroupId("1000");
        tracfoneOneRetailCarrierPrefDetail.setCarrierDetailId("1000");
        tracfoneOneRetailCarrierPrefDetail.setObjId("1000");
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.insertCarrierPrefDetail(tracfoneOneRetailCarrierPrefDetail, 318);
        assertEquals("Carrier Pref created successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testInsertCarrierPrefDetail_whenException() {
        TracfoneOneRetailCarrierPrefDetail tracfoneOneRetailCarrierPrefDetail = new TracfoneOneRetailCarrierPrefDetail();
        tracfoneOneRetailCarrierPrefDetail.setRank("1000");
        tracfoneOneRetailCarrierPrefDetail.setCarrierPrefGroupId("1000");
        tracfoneOneRetailCarrierPrefDetail.setCarrierDetailId("1000");
        tracfoneOneRetailCarrierPrefDetail.setObjId("1000");
        doThrow(RuntimeException.class).when(cRtlCarrierPrefFacade).create(any());
        try {
            tracfoneOneRetailAdminAction.insertCarrierPrefDetail(tracfoneOneRetailCarrierPrefDetail, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierPrefDetail() throws Exception {
        when(cRtlCarrierPrefFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);

        CRtlCarrierPref cRtlCarrierPref = new CRtlCarrierPref();
        cRtlCarrierPref.setcPref2CarrierDtl(BigDecimal.valueOf(1000));
        when(cRtlCarrierPrefFacade.find(any())).thenReturn(cRtlCarrierPref);

        CRtlCarrierDtl carrierDtl = new CRtlCarrierDtl();
        carrierDtl.setcRtlCarrierId("1000");
        carrierDtl.setStatus("STATUS");
        carrierDtl.setObjid(BigDecimal.valueOf(1000));
        when(cRtlCarrierDtlFacade.find(any())).thenReturn(carrierDtl);

        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.deleteCarrierPrefDetail("1000", 318);
        assertEquals("Carrier Pref removed successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testDeleteCarrierPrefDetail_whenException() {
        doThrow(RuntimeException.class).when(cRtlCarrierPrefFacade).getEntityManager();
        try {
            tracfoneOneRetailAdminAction.deleteCarrierPrefDetail("1000", 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testInsertTraitLogicRule() throws Exception {
        TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule = new TracfoneOneTraitLogicRule();
        tracfoneOneTraitLogicRule.setInnerGeo("1000");
        tracfoneOneTraitLogicRule.setInnerPop("1000");
        tracfoneOneTraitLogicRule.setInnerRadius("1000");
        tracfoneOneTraitLogicRule.setOuterGeo("1000");
        tracfoneOneTraitLogicRule.setInnerGeo("1000");
        tracfoneOneTraitLogicRule.setOuterPop("1000");
        tracfoneOneTraitLogicRule.setOuterRadius("1000");
        tracfoneOneTraitLogicRule.setPrefAllCarr("1000");
        tracfoneOneTraitLogicRule.setRule2Logic("1000");
        tracfoneOneTraitLogicRule.setRule2User("1000");
        tracfoneOneTraitLogicRule.setRuleName("RULE_NAME");
        tracfoneOneTraitLogicRule.setUseOuterPop("1000");
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.insertTraitLogicRule(tracfoneOneTraitLogicRule, 318);
        assertEquals("Trait Logic Rule created successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testInsertTraitLogicRule_whenException() {
        TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule = new TracfoneOneTraitLogicRule();
        tracfoneOneTraitLogicRule.setInnerGeo("1000");
        tracfoneOneTraitLogicRule.setInnerPop("1000");
        tracfoneOneTraitLogicRule.setInnerRadius("1000");
        tracfoneOneTraitLogicRule.setOuterGeo("1000");
        tracfoneOneTraitLogicRule.setInnerGeo("1000");
        tracfoneOneTraitLogicRule.setOuterPop("1000");
        tracfoneOneTraitLogicRule.setOuterRadius("1000");
        tracfoneOneTraitLogicRule.setPrefAllCarr("1000");
        tracfoneOneTraitLogicRule.setRule2Logic("1000");
        tracfoneOneTraitLogicRule.setRule2User("1000");
        tracfoneOneTraitLogicRule.setRuleName("RULE_NAME");
        tracfoneOneTraitLogicRule.setUseOuterPop("1000");
        doThrow(RuntimeException.class).when(cRtlTraitLogicRuleFacade).create(any());
        try {
            tracfoneOneRetailAdminAction.insertTraitLogicRule(tracfoneOneTraitLogicRule, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateTraitLogicRule() throws Exception {
        CRtlTraitLogicRule traitLogicRule = new CRtlTraitLogicRule();
        traitLogicRule.setInnerGeo(BigDecimal.valueOf(Integer.valueOf(1000)));
        traitLogicRule.setObjid(BigDecimal.valueOf(Integer.valueOf(1000)));
        traitLogicRule.setInnerPop(BigDecimal.valueOf(Integer.valueOf(1000)));
        traitLogicRule.setInnerRadius(BigDecimal.valueOf(Integer.valueOf(1000)));
        traitLogicRule.setOuterGeo(BigDecimal.valueOf(Integer.valueOf(1000)));
        traitLogicRule.setInnerGeo(BigDecimal.valueOf(Integer.valueOf(1000)));
        traitLogicRule.setOuterPop(BigDecimal.valueOf(Integer.valueOf(1000)));
        traitLogicRule.setOuterRadius(BigDecimal.valueOf(Integer.valueOf(1000)));
        traitLogicRule.setPrefAllCarr(BigDecimal.valueOf(Integer.valueOf(1000)));
        traitLogicRule.setRule2Logic("1000");
        traitLogicRule.setSecUserId("1000");
        traitLogicRule.setRuleName("RULE_NAME");
        traitLogicRule.setUseOuterPop(BigDecimal.valueOf(Integer.valueOf(1000)));

        TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule = new TracfoneOneTraitLogicRule();
        tracfoneOneTraitLogicRule.setInnerGeo("1000");
        tracfoneOneTraitLogicRule.setObjId("1000");
        tracfoneOneTraitLogicRule.setInnerPop("1000");
        tracfoneOneTraitLogicRule.setInnerRadius("1000");
        tracfoneOneTraitLogicRule.setOuterGeo("1000");
        tracfoneOneTraitLogicRule.setInnerGeo("1000");
        tracfoneOneTraitLogicRule.setOuterPop("1000");
        tracfoneOneTraitLogicRule.setOuterRadius("1000");
        tracfoneOneTraitLogicRule.setPrefAllCarr("1000");
        tracfoneOneTraitLogicRule.setRule2Logic("1000");
        tracfoneOneTraitLogicRule.setRule2User("1000");
        tracfoneOneTraitLogicRule.setRuleName("RULE_NAME");
        tracfoneOneTraitLogicRule.setUseOuterPop("1000");
        when(cRtlTraitLogicRuleFacade.find(any())).thenReturn(traitLogicRule);
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.updateTraitLogicRule(tracfoneOneTraitLogicRule, 318);
        assertEquals("Trait Logic Rule updated successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testUpdateTraitLogicRule_whenException() {
        TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule = new TracfoneOneTraitLogicRule();
        tracfoneOneTraitLogicRule.setInnerGeo("1000");
        tracfoneOneTraitLogicRule.setObjId("1000");
        tracfoneOneTraitLogicRule.setInnerPop("1000");
        tracfoneOneTraitLogicRule.setInnerRadius("1000");
        tracfoneOneTraitLogicRule.setOuterGeo("1000");
        tracfoneOneTraitLogicRule.setInnerGeo("1000");
        tracfoneOneTraitLogicRule.setOuterPop("1000");
        tracfoneOneTraitLogicRule.setOuterRadius("1000");
        tracfoneOneTraitLogicRule.setPrefAllCarr("1000");
        tracfoneOneTraitLogicRule.setRule2Logic("1000");
        tracfoneOneTraitLogicRule.setRule2User("1000");
        tracfoneOneTraitLogicRule.setRuleName("RULE_NAME");
        tracfoneOneTraitLogicRule.setUseOuterPop("1000");
        doThrow(RuntimeException.class).when(cRtlTraitLogicRuleFacade).find(any());
        try {
            tracfoneOneRetailAdminAction.updateTraitLogicRule(tracfoneOneTraitLogicRule, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetStates() throws Exception {
        List<String> states = new ArrayList<>();
        states.add("NY");
        states.add("MA");
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(states);
        List<String> response = tracfoneOneRetailAdminAction.getStates();
        assertEquals("[NY, MA]", response.toString());
    }

    @Test
    public void testGetStates_whenException() {
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        doThrow(RuntimeException.class).when(entityManager).createNativeQuery(anyString());
        try {
            tracfoneOneRetailAdminAction.getStates();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateTpNorms() throws Exception {
        CRtlTpNorm tpNorm = new CRtlTpNorm();
        tpNorm.setObjid(BigDecimal.valueOf(1000));
        tpNorm.setCoverage("GOOD");
        tpNorm.setCoverageNotes("NOTE");

        TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel = new TracfoneOneRetailTpAdminSearchModel();
        retailTpAdminSearchModel.setObjIds("1000");
        retailTpAdminSearchModel.setCoverage("GOOD");
        retailTpAdminSearchModel.setCoverageNotes("NOTE");

        when(cRtlTpNormFacade.find(any())).thenReturn(tpNorm);
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.updateTpNorms(retailTpAdminSearchModel, 318);
        assertEquals("TP Norms updated successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testUpdateTpNorms_IfBlock() throws Exception {
        CRtlTpNorm tpNorm = new CRtlTpNorm();
        tpNorm.setObjid(BigDecimal.valueOf(1000));
        tpNorm.setCoverage("GOOD");
        tpNorm.setCoverageNotes("NOTE");

        TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel = new TracfoneOneRetailTpAdminSearchModel();
        retailTpAdminSearchModel.setObjIds("1000");
        retailTpAdminSearchModel.setCarrierDetails("1000");
        retailTpAdminSearchModel.setStates("1000");
        retailTpAdminSearchModel.setZipCodes("10001,10002");
        retailTpAdminSearchModel.setCoverage("GOOD");
        retailTpAdminSearchModel.setCoverageNotes("NOTE");
        retailTpAdminSearchModel.setUpdateAll(true);

        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.updateTpNorms(retailTpAdminSearchModel, 318);
        assertEquals("TP Norms updated successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testUpdateAllTpNorms_ElseBlock() throws Exception {
        CRtlTpNorm tpNorm = new CRtlTpNorm();
        tpNorm.setObjid(BigDecimal.valueOf(1000));
        tpNorm.setCoverage("GOOD");
        tpNorm.setCoverageNotes("NOTE");

        TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel = new TracfoneOneRetailTpAdminSearchModel();
        retailTpAdminSearchModel.setObjIds("1000");
        retailTpAdminSearchModel.setZipCodes("10001,10002");
        retailTpAdminSearchModel.setUpdateAll(true);

        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.updateTpNorms(retailTpAdminSearchModel, 318);
        assertEquals("TP Norms updated successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testUpdateAllTpNorms_whenException() {
        TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel = new TracfoneOneRetailTpAdminSearchModel();
        retailTpAdminSearchModel.setObjIds("1000");
        retailTpAdminSearchModel.setCoverage("GOOD");
        retailTpAdminSearchModel.setCoverageNotes("NOTE");
        retailTpAdminSearchModel.setUpdateAll(true);
        doThrow(RuntimeException.class).when(cRtlTpNormFacade).getEntityManager();
        try {
            tracfoneOneRetailAdminAction.updateTpNorms(retailTpAdminSearchModel, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateTpNorms_whenException() {
        TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel = new TracfoneOneRetailTpAdminSearchModel();
        retailTpAdminSearchModel.setObjIds("1000");
        retailTpAdminSearchModel.setCoverage("GOOD");
        retailTpAdminSearchModel.setCoverageNotes("NOTE");
        doThrow(RuntimeException.class).when(cRtlTpNormFacade).find(any());
        try {
            tracfoneOneRetailAdminAction.updateTpNorms(retailTpAdminSearchModel, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testGetAllCarrierDetails() throws Exception {
        List<Object[]> objects = new ArrayList<>();
        Object[] object = {"1000", "A", Date.valueOf("2020-08-07"), Date.valueOf("2020-08-07"), "CARRIER", "BRAND", "TECH", "1"};
        objects.add(object);
        when(cRtlCarrierDtlFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(objects);
        List<TFOneRetailCarrierDetail> response = tracfoneOneRetailAdminAction.getAllCarrierDetails();
        assertEquals("[TFOneRetailCarrierDetail{objId='1000', status='A', cdtl2Carrier='CARRIER', cdtl2Brand='BRAND', " +
                "cdtl2Tech='TECH', cdtl2User='null', insertDate=2020:08:07 00:00:00, updateDate=2020:08:07 00:00:00}]", response.toString());
    }

    @Test
    public void testGetAllCarrierDetails_whenException() {
        when(cRtlCarrierDtlFacade.getEntityManager()).thenReturn(entityManager);
        doThrow(RuntimeException.class).when(entityManager).createNativeQuery(anyString());
        try {
            tracfoneOneRetailAdminAction.getAllCarrierDetails();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_CARRIER_DETAILS, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_CARRIER_DETAILS_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testGetTpNormStats() throws Exception {
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.getSingleResult()).thenReturn(Date.valueOf("2020-08-07")).thenReturn("5").thenReturn("9");
        TFOneRetailTpAdminSearchResults response = tracfoneOneRetailAdminAction.getTpNormStats();
        assertEquals("TFOneRetailTpAdminSearchResults{tfOneRetailTpNorms=[], count='null', startIndex='null', endIndex='null', lastUpdateDate='2020-08-07', updatedZipCount='5', updatedStoreCount='9'}", response.toString());
    }

    @Test
    public void testGetTpNormStats_whenException() {
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        doThrow(RuntimeException.class).when(entityManager).createNativeQuery(anyString());
        try {
            tracfoneOneRetailAdminAction.getTpNormStats();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchTpNorm() throws Exception {
        TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel = new TracfoneOneRetailTpAdminSearchModel();
        retailTpAdminSearchModel.setObjIds("1000");
        retailTpAdminSearchModel.setCoverage("GOOD");
        retailTpAdminSearchModel.setCoverageNotes("NOTE");
        retailTpAdminSearchModel.setStates("NY");
        retailTpAdminSearchModel.setStartIndex("1");
        retailTpAdminSearchModel.setEndIndex("10");
        retailTpAdminSearchModel.setZipCodes("33101");
        retailTpAdminSearchModel.setCarrierDetails("DETAIL");

        List<Object[]> objects = new ArrayList<>();
        Object[] object = {"1000", "33101", "CARRIER", "BRAND", "TECH", "GOOD", "NOTE", "1", "DETAIL", "NY"};
        objects.add(object);
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(objects);
        TFOneRetailTpAdminSearchResults response = tracfoneOneRetailAdminAction.searchTpNorm(retailTpAdminSearchModel);
        assertEquals("TFOneRetailTpAdminSearchResults{tfOneRetailTpNorms=[TFOneRetailTpNorm{objId='1000', secUserId='null', tp2Zip='33101', tp2CarrierDtl='null', rank='null', state='null', coverage='DETAIL', coverageNotes='NY', env='null', insertDate='null', updateDate='null', carrier='CARRIER', brand='TECH', tech='NOTE', carrierStatus='BRAND', brandStatus='GOOD', techStatus='1'}], count='null', startIndex='1', endIndex='10', lastUpdateDate='null', updatedZipCount='null', updatedStoreCount='null'}", response.toString());
    }

    @Test
    public void testSearchTpNorm_whenException() {
        TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel = new TracfoneOneRetailTpAdminSearchModel();
        retailTpAdminSearchModel.setObjIds("1000");
        retailTpAdminSearchModel.setCoverage("GOOD");
        retailTpAdminSearchModel.setCoverageNotes("NOTE");
        retailTpAdminSearchModel.setStates("NY");
        retailTpAdminSearchModel.setStartIndex("1");
        retailTpAdminSearchModel.setEndIndex("10");
        retailTpAdminSearchModel.setZipCodes("33101");
        retailTpAdminSearchModel.setCarrierDetails("DETAIL");
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        doThrow(RuntimeException.class).when(entityManager).createNativeQuery(anyString());
        try {
            tracfoneOneRetailAdminAction.searchTpNorm(retailTpAdminSearchModel);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetLastTraitRunDate() throws Exception {
        List<Object> result = new ArrayList<>();
        result.add("2020/09/09");
        when(cRtlCarrierDtlFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(result);
        Object response = tracfoneOneRetailAdminAction.getLastTraitRunDate("100");
        assertEquals("2020/09/09", response.toString());
    }

    @Test
    public void testGetLastTraitRunDate_whenException() {
        when(cRtlCarrierDtlFacade.getEntityManager()).thenReturn(entityManager);
        doThrow(RuntimeException.class).when(entityManager).createNativeQuery(anyString());
        try {
            tracfoneOneRetailAdminAction.getLastTraitRunDate("100");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_LAST_TRAIT_RUN_DATE, e.getErrorCode());
            assertEquals(TRACFONE_LAST_TRAIT_RUN_DATE_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testRunStoreTraits() throws Exception {
        TracfoneOneRetailLocation tracfoneOneRetailLocation = new TracfoneOneRetailLocation();
        tracfoneOneRetailLocation.setObjIds("122");
        tracfoneOneRetailLocation.setStoreNum("122332");
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.runStoreTraits(tracfoneOneRetailLocation, 100);
        assertEquals(TRACFONE_RUN_STORE_TRAITS_SUCCESS, response.getMessage());
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
    }

    @Test
    public void testRunStoreTraits_If_Block() throws Exception {
        TracfoneOneRetailLocation tracfoneOneRetailLocation = new TracfoneOneRetailLocation();
        tracfoneOneRetailLocation.setObjIds("122");
        tracfoneOneRetailLocation.setStoreNum("122332");
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        when(query.getSingleResult()).thenReturn(0);
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.runStoreTraits(tracfoneOneRetailLocation, 100);
        assertEquals(TRACFONE_RUN_STORE_TRAITS_SUCCESS, response.getMessage());
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
    }

    @Test
    public void testRunStoreTraits_whenException() {
        TracfoneOneRetailLocation tracfoneOneRetailLocation = new TracfoneOneRetailLocation();
        tracfoneOneRetailLocation.setStoreNum("1000");
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        doThrow(RuntimeException.class).when(query).executeUpdate();
        try {
            tracfoneOneRetailAdminAction.runStoreTraits(tracfoneOneRetailLocation, 100);
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateRank() throws Exception {
        when(cRtlCarrierDtlFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.updateRank("12", "22", 23);
        assertEquals("Success", response.getStatus());
        assertEquals("Rank updated successfully.", response.getMessage());
    }

    @Test
    public void testUpdateRank_whenException() {
        when(cRtlCarrierDtlFacade.getEntityManager()).thenReturn(entityManager);
        doThrow(RuntimeException.class).when(entityManager).createNativeQuery(anyString());
        try {
            tracfoneOneRetailAdminAction.updateRank("12", "22", 23);
        } catch (TracfoneOneException e) {
        }
    }

    @Test
    public void testRunTraitsSummary() throws Exception {
        List<Object[]> objects = new ArrayList<>();
        Object[] object = {"CARRIER_0", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1"};
        objects.add(object);

        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(objects);
        List<TFOneJobTask> response = tracfoneOneRetailAdminAction.runTraitsSummary();
        assertEquals("[TFOneJobTask{objId='CARRIER_0', status='CARRIER_1', name='CARRIER_1', description='CARRIER_1', startRun='CARRIER_1', endRun='CARRIER_1'}]", response.toString());
    }

    @Test
    public void testRunTraitsSummary_whenException() {
        doThrow(RuntimeException.class).when(cRtlTpNormFacade).getEntityManager();
        try {
            tracfoneOneRetailAdminAction.runTraitsSummary();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_RUN_TRAITS_SUMMARY, e.getErrorCode());
            assertEquals(TRACFONE_RUN_TRAITS_SUMMARY_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testUpdateNewRank() throws Exception {
        List<TracfoneOneRetailCarrierPrefDetail> carrierPrefDetails = new ArrayList<>();
        TracfoneOneRetailCarrierPrefDetail carrierPrefDetail = new TracfoneOneRetailCarrierPrefDetail();
        carrierPrefDetail.setObjId("12");
        carrierPrefDetail.setRank("2");
        carrierPrefDetails.add(carrierPrefDetail);
        when(cRtlCarrierDtlFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        TFOneGeneralResponse response = tracfoneOneRetailAdminAction.updateNewRank(carrierPrefDetails, 100);
        assertEquals("Rank updated successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testUpdateNewRank_whenException() {
        List<TracfoneOneRetailCarrierPrefDetail> carrierPrefDetails = new ArrayList<>();
        when(cRtlCarrierDtlFacade.getEntityManager()).thenReturn(entityManager);
        doThrow(RuntimeException.class).when(entityManager).createNativeQuery(anyString());
        try {
            tracfoneOneRetailAdminAction.updateNewRank(carrierPrefDetails, 1000);
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}