package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfig;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfigDetails;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGCarrierConfig;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.event.Event;
import javax.sql.DataSource;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.mockito.ArgumentMatchers.anyString;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import org.mockito.junit.MockitoJUnitRunner;

/**
 *
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneIGCarrierConfigActionTest {

    @InjectMocks
    TracfoneOneIGCarrierConfigAction action;
    private static final String DBENV = "DBENV";
    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private ResultSet resultSet;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    private TFOneGeneralResponse tfOneGeneralResponse;

    @Before
    public void setUp() throws Exception {
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

    @Test
    public void testGetCarriers() throws Exception {
        when(stmt.executeQuery()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMY_DATA");
        List<String> response = action.getCarriers("dbEnv");
        assertEquals("[DUMMY_DATA]", response.toString());
    }

    @Test
    public void testGetCarriers_withException() throws SQLException, TracfoneOneException {
        // When null is passed
        try {
            action.getCarriers(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            action.getCarriers(DBENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCarrierConfig() throws Exception {
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setDbEnv(DBENV);
        carrierConfig.setCarrier("TMOBILE");
        when(stmt.executeQuery()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMY_DATA");
        List<TFOneIGCarrierConfig> response = action.getCarrierConfig(carrierConfig);
        assertEquals("[TFOneIGCarrierConfig{configId=DUMMY_DATA, carrier=DUMMY_DATA, propName=DUMMY_DATA, propType=DUMMY_DATA, description=DUMMY_DATA, carrierDetails=TFOneIGCarrierDetails{configId=DUMMY_DATA, propKey=DUMMY_DATA, propValueType=DUMMY_DATA, propValue=DUMMY_DATA, propValueKey=DUMMY_DATA, propValueKeyType=DUMMY_DATA, propValueKeyKey=DUMMY_DATA, remarks=DUMMY_DATA}}]", response.toString());
    }

    @Test
    public void testGetCarrierConfig_withException() throws SQLException, TracfoneOneException {
        // When null is passed
        try {
            action.getCarrierConfig(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setDbEnv(DBENV);
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            action.getCarrierConfig(carrierConfig);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierDetails() throws Exception {
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setDbEnv(DBENV);
        carrierConfig.setPropType("MAP");
        carrierConfig.setConfigId("12212");
        TracfoneOneIGCarrierConfigDetails carrierDetails = new TracfoneOneIGCarrierConfigDetails();
        carrierDetails.setConfigId("12121");
        carrierDetails.setDbEnv(DBENV);
        carrierDetails.setPropKey("123");
        carrierDetails.setPropValue("TEST");
        carrierDetails.setPropValueType("STRING");
        carrierDetails.setOldPropKey("213");
        carrierDetails.setOldPropValue("TEST");
        carrierDetails.setOldPropValueType("STRING");
        carrierConfig.setIgCarrierDetails(carrierDetails);
        tfOneGeneralResponse = action.updateCarrierConfigDetails(carrierConfig, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), carrierConfig.getConfigId());
    }

    @Test
    public void testUpdateCarrierDetails_withException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeQuery();
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setDbEnv(DBENV);
        TracfoneOneIGCarrierConfigDetails carrierDetails = new TracfoneOneIGCarrierConfigDetails();
        carrierDetails.setConfigId("12121");
        carrierDetails.setDbEnv(DBENV);
        carrierDetails.setPropKey("123");
        carrierDetails.setPropValue("TEST");
        carrierDetails.setPropValueType("STRING");
        carrierDetails.setOldPropKey("213");
        carrierDetails.setOldPropValue("TEST");
        carrierDetails.setOldPropValueType("STRING");
        carrierConfig.setIgCarrierDetails(carrierDetails);
        try {
            action.updateCarrierConfigDetails(carrierConfig, 123);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierDetails() throws Exception {
        TracfoneOneIGCarrierConfigDetails carrierDetails = new TracfoneOneIGCarrierConfigDetails();
        carrierDetails.setConfigId("12121");
        carrierDetails.setDbEnv(DBENV);
        carrierDetails.setPropKey("123");
        carrierDetails.setPropValue("TEST");
        carrierDetails.setPropValueType("STRING");
        carrierDetails.setOldPropKey("213");
        carrierDetails.setOldPropValue("TEST");
        carrierDetails.setOldPropValueType("STRING");
        tfOneGeneralResponse = action.deleteCarrierConfigDetails(carrierDetails, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), carrierDetails.getConfigId());
    }

    @Test
    public void testDeleteCarrierDetails_withException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeQuery();
        TracfoneOneIGCarrierConfigDetails carrierDetails = new TracfoneOneIGCarrierConfigDetails();
        carrierDetails.setConfigId("12121");
        carrierDetails.setDbEnv(DBENV);
        carrierDetails.setPropKey("123");
        carrierDetails.setPropValue("TEST");
        carrierDetails.setPropValueType("STRING");
        carrierDetails.setOldPropKey("213");
        carrierDetails.setOldPropValue("TEST");
        carrierDetails.setOldPropValueType("STRING");
        try {
            action.deleteCarrierConfigDetails(carrierDetails, 123);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierDetails() throws Exception {
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setConfigId("12121");
        carrierConfig.setPropType("String");
        carrierConfig.setDbEnv(DBENV);
        TracfoneOneIGCarrierConfigDetails carrierDetails = new TracfoneOneIGCarrierConfigDetails();
        carrierDetails.setConfigId("12121");
        carrierDetails.setDbEnv(DBENV);
        carrierDetails.setPropKey("123");
        carrierDetails.setPropValue("TEST");
        carrierDetails.setPropValueType("STRING");
        carrierDetails.setOldPropKey("213");
        carrierDetails.setOldPropValue("TEST");
        carrierDetails.setOldPropValueType("STRING");
        carrierConfig.setIgCarrierDetails(carrierDetails);
        tfOneGeneralResponse = action.insertCarrierConfigDetails(carrierConfig, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), carrierDetails.getConfigId());
    }

    @Test
    public void testInsertCarrierDetails_withException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeQuery();
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setDbEnv(DBENV);
        carrierConfig.setPropType("String");
        TracfoneOneIGCarrierConfigDetails carrierDetails = new TracfoneOneIGCarrierConfigDetails();
        carrierDetails.setConfigId("12121");
        carrierDetails.setDbEnv(DBENV);
        carrierConfig.setIgCarrierDetails(carrierDetails);
        try {
            action.insertCarrierConfigDetails(carrierConfig, 123);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    /** Sprint - 32 */

    @Test
    public void testInsertCarrierConfig() throws Exception {
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setConfigId("12121");
        carrierConfig.setPropType("String");
        carrierConfig.setPropName("String");
        carrierConfig.setCarrier("TMO");
        carrierConfig.setDescription("TEST");
        carrierConfig.setDbEnv(DBENV);
        TracfoneOneIGCarrierConfigDetails carrierDetails = new TracfoneOneIGCarrierConfigDetails();
        carrierDetails.setConfigId("12121");
        carrierDetails.setDbEnv(DBENV);
        carrierDetails.setPropKey("123");
        carrierDetails.setPropValue("TEST");
        carrierDetails.setPropValueType("STRING");
        carrierDetails.setOldPropKey("213");
        carrierDetails.setOldPropValue("TEST");
        carrierDetails.setOldPropValueType("STRING");
        carrierConfig.setIgCarrierDetails(carrierDetails);
        List<TracfoneOneIGCarrierConfigDetails> details = new ArrayList<>();
        details.add(carrierDetails);
        carrierConfig.setIgCarrierDetailsArray(details);
        tfOneGeneralResponse = action.insertCarrierConfig(carrierConfig, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), carrierConfig.getConfigId());
    }

    @Test
    public void testInsertCarrierConfig_whenException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeQuery();
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setConfigId("12121");
        carrierConfig.setPropType("String");
        carrierConfig.setPropName("String");
        carrierConfig.setCarrier("TMO");
        carrierConfig.setDescription("TEST");
        carrierConfig.setDbEnv(DBENV);
        TracfoneOneIGCarrierConfigDetails carrierDetails = new TracfoneOneIGCarrierConfigDetails();
        carrierDetails.setConfigId("12121");
        carrierDetails.setDbEnv(DBENV);
        carrierDetails.setPropKey("123");
        carrierDetails.setPropValue("TEST");
        carrierDetails.setPropValueType("STRING");
        carrierDetails.setOldPropKey("213");
        carrierDetails.setOldPropValue("TEST");
        carrierDetails.setOldPropValueType("STRING");
        carrierConfig.setIgCarrierDetails(carrierDetails);
        try {
            action.insertCarrierConfig(carrierConfig, 123);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

}
