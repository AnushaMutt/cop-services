package com.tracfone.service;


import com.tracfone.service.controller.TracfoneCarrierMaintenanceControllerLocal;
import com.tracfone.service.controller.TracfoneOneDB2IntergateControllerLocal;
import com.tracfone.service.controller.TracfoneOneGeoCoderControllerLocal;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneGeoCoderAddress;
import com.tracfone.service.model.request.TracfoneOneGeoCoderToken;
import com.tracfone.service.model.request.TracfoneOneIgOrderType;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneGeoCodeAddress;
import com.tracfone.service.model.response.TFOneGeoCoder;
import com.tracfone.service.model.response.TFOneGeoCoderCandidates;
import com.tracfone.service.model.response.TFOneIgOrderType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * @author Thejaswini
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneGeoCoderResourceTest {

    private TracfoneOneException tracfoneOneException;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneAuthorizationException tracfoneOneAuthorizationException;
    public final String JSON = "application/json";

    @InjectMocks
    private TracfoneOneGeoCoderResource resource;

    @Mock
    private TracfoneOneGeoCoderControllerLocal tracfoneGeoCoderController;

    @Mock
    private SecurityContext securityContext;

    @Mock
    private TracfoneOnePrincipal principal;

    @Mock
    private TFOneAdminUser user;

    public final String DBENV = "dbEnv";

    @Mock
    private TracfoneOneDB2IntergateControllerLocal controllerLocal;


    @Before
    public void setUp() {
        initMocks(this);
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
        when(securityContext.getUserPrincipal()).thenReturn(principal);
        when(principal.getTFUser()).thenReturn(user);
    }

    @Test
    public void testGenerateToken() throws TracfoneOneException {
        TracfoneOneGeoCoderToken tracfoneOneGeoCoderToken = new TracfoneOneGeoCoderToken();
        tracfoneOneGeoCoderToken.setReferer("TEST");
        TFOneGeoCoder tfOneGeoCoder = new TFOneGeoCoder();
        tfOneGeoCoder.setSsl("true");
        tfOneGeoCoder.setExpires("60");
        tfOneGeoCoder.setToken("TEST");
        when(tracfoneGeoCoderController.generateToken(anyInt(), any())).thenReturn(tfOneGeoCoder);
        Response response = resource.generateToken(tracfoneOneGeoCoderToken);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
    }

    @Test
    public void testGetOrderTypes_whenException() throws TracfoneOneException {
        TracfoneOneGeoCoderToken tracfoneOneGeoCoderToken = new TracfoneOneGeoCoderToken();
        tracfoneOneGeoCoderToken.setReferer("TEST");
        doThrow(tracfoneOneException).when(tracfoneGeoCoderController).generateToken(anyInt(), any());
        Response response = resource.generateToken(tracfoneOneGeoCoderToken);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testFindGeoAddressLocation() throws TracfoneOneException {
        TracfoneOneGeoCoderAddress tracfoneOneGeoCoderAddress = new TracfoneOneGeoCoderAddress();
        tracfoneOneGeoCoderAddress.setAddress("ATLANTIC");
        TFOneGeoCodeAddress tfOneGeoCodeAddress = new TFOneGeoCodeAddress();
        List<TFOneGeoCoderCandidates> candidates = new ArrayList<>();
        TFOneGeoCoderCandidates tfOneGeoCoderCandidates = new TFOneGeoCoderCandidates();
        tfOneGeoCoderCandidates.setAddress("ATLANTIC");
        candidates.add(tfOneGeoCoderCandidates);
        tfOneGeoCodeAddress.setCandidates(candidates);
        when(tracfoneGeoCoderController.findGeoAddressLocation(anyInt(), any())).thenReturn(tfOneGeoCodeAddress);
        Response response = resource.findGeoAddressLocation(tracfoneOneGeoCoderAddress);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
    }

    @Test
    public void testFindGeoAddressLocation_whenException() throws TracfoneOneException {
        TracfoneOneGeoCoderAddress tracfoneOneGeoCoderAddress = new TracfoneOneGeoCoderAddress();
        doThrow(tracfoneOneException).when(tracfoneGeoCoderController).findGeoAddressLocation(anyInt(), any());
        Response response = resource.findGeoAddressLocation(tracfoneOneGeoCoderAddress);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

}