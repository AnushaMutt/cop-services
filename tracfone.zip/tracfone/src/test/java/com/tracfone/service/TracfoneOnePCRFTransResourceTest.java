package com.tracfone.service;

import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.controller.TracfoneOnePCRFTransControllerLocal;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOnePCRFTransaction;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.request.TracfoneOneUserTask;
import com.tracfone.service.model.request.TracfoneOneUserTaskDetail;
import com.tracfone.service.model.request.TracfoneonePaginationSearch;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOnePCRFTransSearchResult;
import com.tracfone.service.model.response.TFOnePCRFTransaction;
import com.tracfone.service.model.response.TFOneUserHistory;
import com.tracfone.service.model.response.TFOneUserHistoryDetail;
import com.tracfone.service.model.response.TFOneUserTask;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import org.mockito.ArgumentMatchers;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOnePCRFTransResourceTest {

    public final String JSON = "application/json";
    public final String DBENV = "dbEnv";
    private TracfoneOneException tracfoneOneException;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneAuthorizationException tracfoneOneAuthorizationException;

    @InjectMocks
    TracfoneOnePCRFTransResource tracfoneOnePCRFTransResource;

    @Mock
    private TracfoneOnePCRFTransControllerLocal cRFTransControllerLocal;

    @Mock
    private TracfoneControllerLocalAction tracfoneControllerAction;

    @Mock
    private TracfoneControllerLocal tracfoneController;

    @Mock
    private SecurityContext securityContext;

    @Mock
    private TracfoneOnePrincipal principal;

    @Mock
    private TFOneAdminUser user;

    @Before
    public void setUp() {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        tracfoneOneAuthorizationException = new TracfoneOneAuthorizationException("TFE0", "dummy_auth_error_message");
        when(securityContext.getUserPrincipal()).thenReturn(principal);
        when(principal.getTFUser()).thenReturn(user);
    }

    @Test
    public void testViewPCRFTransaction() throws TracfoneOneException {
        TracfoneOnePCRFTransaction cRFTransaction = new TracfoneOnePCRFTransaction();
        cRFTransaction.setDbEnv(DBENV);
        TFOnePCRFTransSearchResult cRFTransSearchResult = new TFOnePCRFTransSearchResult();
        List<TFOnePCRFTransaction> cRFTransactions = new ArrayList();
        TFOnePCRFTransaction cRFTransaction1 = new TFOnePCRFTransaction();
        cRFTransaction1.setActionType("ACTIion");
        cRFTransaction1.setAddonsFlag("flag");
        cRFTransaction1.setBlackoutWaitDate("2020/12/12");
        cRFTransaction1.setBrand("brand");
        cRFTransaction1.setEsn("ESN");
        cRFTransaction1.setGroupId("GROUPID");
        cRFTransaction1.setMin("MIN");
        cRFTransaction1.setCaseId("12");
        cRFTransaction1.setCharField1("12");
        cRFTransaction1.setCharField2("42");
        cRFTransaction1.setCharField3("41");
        cRFTransaction1.setContactObjId("21441");
        cRFTransaction1.setSubscriberId("15251");
        cRFTransaction1.setContentDeliveryFormat("THESH");
        cRFTransaction1.setConversionFactor("FACTOR");
        cRFTransaction1.setDataUsage("1234");
        cRFTransaction1.setDateField1("2020/12/12");
        cRFTransaction1.setDealerId("1414");
        cRFTransaction1.setDenomination("API");
        cRFTransaction1.setFutureTtl("2020/12/12");
        cRFTransaction1.setHiSpeedDataUsage("COS");
        cRFTransaction1.setImsi("ENTITLEMENT");
        cRFTransaction1.setMdn("ESN");
        cRFTransaction1.setOrderType("GROUPID");
        cRFTransaction1.setObjId("MIN");
        cRFTransaction1.setPartInstStatus("PARENT NAME");
        cRFTransaction1.setPcrfCos("POLICY NAME");
        cRFTransaction1.setPhoneManufacturer("PRIO");
        cRFTransaction1.setPhoneModel("FLAG");
        cRFTransaction1.setPosaFlag("RULE");
        cRFTransaction1.setProgramParameterId("STATUS");
        cRFTransaction1.setPropagateFlag("SUB ID");
        cRFTransaction1.setRatePlan("THESH");
        cRFTransaction1.setRcsEnableFlag("GROUP_TYPE");
        cRFTransaction1.setRedemptionDate("NUM");
        cRFTransaction1.setRetryCount("TYPE");
        cRFTransaction1.setServicePlanType("USAGE ID");
        cRFTransaction1.setSim("STATUS");
        cRFTransaction1.setSourceSystem("SUB ID");
        cRFTransaction1.setTtl("THESH");
        cRFTransaction1.setZipCode("GROUP_TYPE");
        cRFTransaction1.setInsertTimestamp("2020/12/12");
        cRFTransaction1.setUpdateTimestamp("2020/12/12");
        cRFTransaction1.setWebObjId("12456");

        cRFTransactions.add(cRFTransaction1);
        TracfoneonePaginationSearch tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
        tracfoneonePaginationSearch.setStartIndex(0);
        tracfoneonePaginationSearch.setEndIndex(100);
        tracfoneonePaginationSearch.setTotal(123);
        cRFTransSearchResult.setPaginationSearch(tracfoneonePaginationSearch);
        cRFTransSearchResult.setPcrfTransactions(cRFTransactions);

        when(cRFTransControllerLocal.viewPcrfTransaction(any())).thenReturn(cRFTransSearchResult);
        Response response = tracfoneOnePCRFTransResource.viewPcrfTransactions(cRFTransaction);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"paginationSearch\":{\"startIndex\":0,\"endIndex\":100,\"total\":123},\"pcrfTransactions\":[{\"objId\":\"MIN\",\"min\":\"MIN\",\"esn\":\"ESN\",\"subscriberId\":\"15251\",\"groupId\":\"GROUPID\",\"orderType\":\"GROUPID\",\"phoneManufacturer\":\"PRIO\",\"actionType\":\"ACTIion\",\"sim\":\"STATUS\",\"zipCode\":\"GROUP_TYPE\",\"servicePlanId\":null,\"caseId\":\"12\",\"pcrfStatusCode\":null,\"statusMessage\":null,\"webObjId\":\"12456\",\"brand\":\"brand\",\"sourceSystem\":\"SUB ID\",\"template\":null,\"ratePlan\":\"THESH\",\"blackoutWaitDate\":\"2020/12/12\",\"retryCount\":\"TYPE\",\"dataUsage\":\"1234\",\"hiSpeedDataUsage\":\"COS\",\"conversionFactor\":\"FACTOR\",\"dealerId\":\"1414\",\"denomination\":\"API\",\"pcrfParentName\":null,\"propagateFlag\":\"SUB ID\",\"servicePlanType\":\"USAGE ID\",\"partInstStatus\":\"PARENT NAME\",\"phoneModel\":\"FLAG\",\"contentDeliveryFormat\":\"THESH\",\"language\":null,\"wfMacId\":null,\"insertTimestamp\":\"2020/12/12\",\"updateTimestamp\":\"2020/12/12\",\"mdn\":\"ESN\",\"pcrfCos\":\"POLICY NAME\",\"ttl\":\"THESH\",\"futureTtl\":\"2020/12/12\",\"redemptionDate\":\"NUM\",\"contactObjId\":\"21441\",\"imsi\":\"ENTITLEMENT\",\"lifeLineId\":null,\"installDate\":null,\"programParameterId\":\"STATUS\",\"vmbcCertificationFlag\":null,\"charField1\":\"12\",\"charField2\":\"42\",\"charField3\":\"41\",\"dateField1\":\"2020/12/12\",\"addonsFlag\":\"flag\",\"rcsEnableFlag\":\"GROUP_TYPE\",\"posaFlag\":\"RULE\",\"unlockStatus\":null}]}", response.getEntity().toString());
    }

    @Test
    public void testViewPCRFTrans_whenException() throws TracfoneOneException {
        TracfoneOnePCRFTransaction cRFTransaction = new TracfoneOnePCRFTransaction();
        cRFTransaction.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(cRFTransControllerLocal).viewPcrfTransaction(any());
        Response response = tracfoneOnePCRFTransResource.viewPcrfTransactions(cRFTransaction);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetUserTaskByUserId() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setType("PCRF_TRANSACTION");
        tfOneUserTask.setId("1000");
        tfOneUserTask.setAssignedUserId("1000");

        List<String> status = new ArrayList<>();
        status.add("COMPLETED");
        List<TFOneUserTask> userTasks = new ArrayList<>();
        TFOneUserTask userTask = new TFOneUserTask();
        userTask.setType("PCRF_TRANSACTION");
        userTask.setAssignedUserId("1200");
        userTask.setUserId("1222");
        userTask.setDescription("DESCRIPTION");
        userTask.setTaskName("TASK_NAME");
        userTask.setStatus(status);
        userTasks.add(userTask);

        when(tracfoneControllerAction.getUserTaskByUserId(any())).thenReturn(userTasks);
        Response response = tracfoneOnePCRFTransResource.getUserTaskByUserId(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":null,\"taskName\":\"TASK_NAME\",\"description\":\"DESCRIPTION\",\"userId\":\"1222\",\"assignedUserId\":\"1200\",\"assignedUserName\":null,\"type\":\"PCRF_TRANSACTION\",\"status\":[\"COMPLETED\"],\"creationDate\":null,\"tfOneUserTaskDetail\":[]}]", response.getEntity().toString());
    }

    @Test
    public void testGetUserTaskByUserId_whenException() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getUserTaskByUserId(any());
        Response response = tracfoneOnePCRFTransResource.getUserTaskByUserId(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void updateUserTask() throws TracfoneOneException {
        List<String> status = new ArrayList<>();
        status.add("COMPLETED");
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setAssignedUserId("381");
        tfOneUserTask.setDescription("DESC");
        tfOneUserTask.setId("381");
        tfOneUserTask.setStatus(status);
        tfOneUserTask.setTaskName("TASK_NAME");
        tfOneUserTask.setType("TYPE");
        tfOneUserTask.setUserId("381");

        TFOneUserTask tfUserTask = new TFOneUserTask();
        tfUserTask.setAssignedUserId("381");
        tfUserTask.setDescription("DESC");
        tfUserTask.setId("381");
        tfUserTask.setStatus(status);
        tfUserTask.setTaskName("TASK_NAME");
        tfUserTask.setType("TYPE");
        tfUserTask.setUserId("381");
        when(tracfoneControllerAction.updateUserTask(any(), anyInt())).thenReturn(tfUserTask);
        Response response = tracfoneOnePCRFTransResource.updateUserTask(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"id\":\"381\",\"taskName\":\"TASK_NAME\",\"description\":\"DESC\",\"userId\":\"381\",\"assignedUserId\":\"381\",\"assignedUserName\":null,\"type\":\"TYPE\",\"status\":[\"COMPLETED\"],\"creationDate\":null,\"tfOneUserTaskDetail\":[]}", response.getEntity().toString());
    }

    @Test
    public void testUpdateEndTime_whenException() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        doThrow(tracfoneOneException).when(tracfoneControllerAction).updateUserTask(any(), anyInt());
        Response response = tracfoneOnePCRFTransResource.updateUserTask(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetUserHistoryByUserId() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        tracfoneOneUserHistory.setType("TYPE");
        tracfoneOneUserHistory.setFromCreationDate("2020:02:02");
        tracfoneOneUserHistory.setToCreationDate("2020:06:07");

        List<TFOneUserHistoryDetail> tfUserHistoryDetails = new ArrayList<>();
        TFOneUserHistoryDetail tfUserHistoryDetail = new TFOneUserHistoryDetail();
        tfUserHistoryDetail.setIdDetail("DETAILS");
        tfUserHistoryDetail.setIdType("TYPE");
        tfUserHistoryDetail.setUserHistoryDetailId("1200");
        tfUserHistoryDetail.setUserHistoryId("1");
        tfUserHistoryDetails.add(tfUserHistoryDetail);

        List<TFOneUserHistory> histories = new ArrayList<>();
        TFOneUserHistory history = new TFOneUserHistory();
        history.setCreationDate("2022:01:01");
        history.setId("1");
        history.setType("TT_INSERT");
        history.setTfUserHistoryDetail(tfUserHistoryDetails);
        histories.add(history);
        when(tracfoneControllerAction.getUserHistoryByUserId(any())).thenReturn(histories);
        Response response = tracfoneOnePCRFTransResource.getUserHistoryByUserId(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"1\",\"UserId\":null,\"type\":\"TT_INSERT\",\"creationDate\":\"2022:01:01\",\"tfUserHistoryDetail\":[{\"userHistoryDetailId\":\"1200\",\"userHistoryId\":\"1\",\"idType\":\"TYPE\",\"idDetail\":\"DETAILS\"}]}]", response.getEntity().toString());
    }

    @Test
    public void testGetUserHistoryByUserId_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getUserHistoryByUserId(any());
        Response response = tracfoneOnePCRFTransResource.getUserHistoryByUserId(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetAllFailuresForPCRF() throws TracfoneOneException {
        String jsonResponse = "[{\"ttObjid\":\"625842364\",\"xCarrier\":\"AT\\u0026T WIRELESS\",\"xTimeSegment\":\"2020:07:17 06:00:00\",\"orderTypeGroup\":\"TTOFF\",\"totalTransCount\":\"1\",\"percentFailure\":\"1\",\"failureCount\":\"1\",\"sumE\":\"1\"}]";
        when(tracfoneController.getAllFailures(anyString(), ArgumentMatchers.anyBoolean())).thenReturn(jsonResponse);
        Response response = tracfoneOnePCRFTransResource.getAllFailuresForPCRF(true);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals(jsonResponse, response.getEntity().toString());
    }

    @Test
    public void testGetAllFailuresForTT_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneController).getAllFailures(anyString(), ArgumentMatchers.anyBoolean());
        Response response = tracfoneOnePCRFTransResource.getAllFailuresForPCRF(true);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testInsertUserTask() throws TracfoneOneException {
        List<TracfoneOneUserTaskDetail> tfOneUserTaskDetails = new ArrayList<>();
        TracfoneOneUserTaskDetail tfOneUserTaskDetail = new TracfoneOneUserTaskDetail();
        tfOneUserTaskDetail.setTaskDetails("DETAILES");
        tfOneUserTaskDetail.setUserComments("COMMENT");
        tfOneUserTaskDetails.add(tfOneUserTaskDetail);
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setType("TT_TYPE");
        tfOneUserTask.setAssignedUserId("234");
        tfOneUserTask.setUserId("435");
        tfOneUserTask.setTaskName("TASK_NAME");
        tfOneUserTask.setDescription("DESC");
        tfOneUserTask.setTfOneUserTaskDetails(tfOneUserTaskDetails);

        when(tracfoneControllerAction.insertUserTask(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOnePCRFTransResource.insertUserTask(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertUserTask_whenException() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        doThrow(tracfoneOneException).when(tracfoneControllerAction).insertUserTask(any(), anyInt());
        Response response = tracfoneOnePCRFTransResource.insertUserTask(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetAllUsers() throws TracfoneOneException, TracfoneOneAuthorizationException {
        List<TFOneAdminUser> tfOneAdminUsers = new ArrayList<>();
        TFOneAdminUser tfOneAdminUser = new TFOneAdminUser();
        tfOneAdminUser.setUserName("GSHARMA");
        tfOneAdminUser.setUserId(543);
        tfOneAdminUser.setDescription("DESC");
        tfOneAdminUsers.add(tfOneAdminUser);
        when(tracfoneController.getAllUsers(any())).thenReturn(tfOneAdminUsers);
        Response response = tracfoneOnePCRFTransResource.getAllUsers();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"userId\":543,\"userName\":\"GSHARMA\",\"email\":null,\"token\":null,\"description\":\"DESC\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllUsers_whenException() throws TracfoneOneException, TracfoneOneAuthorizationException {
        doThrow(tracfoneOneException).when(tracfoneController).getAllUsers(any());
        Response response = tracfoneOnePCRFTransResource.getAllUsers();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetAllUsers_whenAuthException() throws TracfoneOneException, TracfoneOneAuthorizationException {
        doThrow(tracfoneOneAuthorizationException).when(tracfoneController).getAllUsers(any());
        Response response = tracfoneOnePCRFTransResource.getAllUsers();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_auth_error_message\",\"httpCode\":401}", response.getEntity().toString());
    }

}
