package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneIgFailLogs;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGFailLogs;
import com.tracfone.service.model.response.TFOneIgFailLogSearchModel;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * @author Thejaswini
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneIgFailLogsActionTest {
    @InjectMocks
    TracfoneOneIgFailLogsAction action;
    private static final String DBENV = "DBENV";
    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private CallableStatement callableStatement;
    @Mock
    private ResultSet resultSet;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    private TFOneGeneralResponse tfOneGeneralResponse;

    @Before
    public void setUp() throws Exception {
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

   @Test
   public void testGetIgFailLogs() throws Exception {
        TracfoneOneIgFailLogs tracfoneOneIgFailLogs = new TracfoneOneIgFailLogs();
        tracfoneOneIgFailLogs.setDbEnv(DBENV);
        List<TFOneIGFailLogs> tfOneIGFailLogs = new ArrayList<>();
        TFOneIGFailLogs tfOneIGFailLog = new TFOneIGFailLogs();
        tfOneIGFailLog.setActionItemId("100");
        tfOneIGFailLogs.add(tfOneIGFailLog);

        when(stmt.executeQuery()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMY_DATA");
        TFOneIgFailLogSearchModel response = action.getIgFailLogs(tracfoneOneIgFailLogs);
        assertEquals("TFOneIgFailLogSearchModel{paginationSearch=TracfoneonePaginationSearch{startIndex=1, endIndex=1000, total=0}, iGFailLogs=[TFOneIGFailLogs{callTransActionType='null', actionItemId='DUMMY_DATA', carrierId='DUMMY_DATA', orderType='DUMMY_DATA', min='DUMMY_DATA', esn='DUMMY_DATA', esnPartClassModel='null', esnHex='DUMMY_DATA', oldEsn='DUMMY_DATA', oldEsnHex='DUMMY_DATA', pin='DUMMY_DATA', phoneManf='DUMMY_DATA', endUser='DUMMY_DATA', accountNum='DUMMY_DATA', marketCode='DUMMY_DATA', ratePlan='DUMMY_DATA', ldProvider='DUMMY_DATA', sequenceNum='DUMMY_DATA', dealerCode='DUMMY_DATA', transmissionMethod='DUMMY_DATA', faxNum='DUMMY_DATA', onlineNum='DUMMY_DATA', email='DUMMY_DATA', networkLogin='DUMMY_DATA', networkPassword='DUMMY_DATA', systemLogin='DUMMY_DATA', systemPassword='DUMMY_DATA', template='DUMMY_DATA', exeName='null', comPort='DUMMY_DATA', status='DUMMY_DATA', statusMessage='DUMMY_DATA', faxBatchSize='null', faxBatchQtime='null', expidite='null', transProfKey='DUMMY_DATA', qTransaction='DUMMY_DATA', onlineNum2='null', faxNum2='DUMMY_DATA', creationDate='DUMMY_DATA', updateDate='DUMMY_DATA', igDbSecsToComp='null', blackoutWait='DUMMY_DATA', tuxItiServer='null', transactionId='DUMMY_DATA', technologyFlag='DUMMY_DATA', voiceMail='DUMMY_DATA', voiceMailPackage='DUMMY_DATA', callerId='DUMMY_DATA', carrierAccountId='null', tmoNextGenFlag='null', callerIdPackage='DUMMY_DATA', callWaiting='DUMMY_DATA', callWaitingPackage='DUMMY_DATA', rtpServer='null', digitalFeatureCode='DUMMY_DATA', stateField='DUMMY_DATA', zipCode='DUMMY_DATA', msid='DUMMY_DATA', newMsidFlag='DUMMY_DATA', sms='DUMMY_DATA', smsPackage='DUMMY_DATA', iccid='DUMMY_DATA', oldMin='DUMMY_DATA', digitalFeature='DUMMY_DATA', otaType='DUMMY_DATA', rateCenterNo='DUMMY_DATA', applicationSystem='DUMMY_DATA', subscriberUpdate='DUMMY_DATA', downloadDate='DUMMY_DATA', amount='DUMMY_DATA', balance='DUMMY_DATA', language='DUMMY_DATA', expDate='DUMMY_DATA', xMpn='DUMMY_DATA', xMpnCode='DUMMY_DATA', xPoolName='DUMMY_DATA', xMake='DUMMY_DATA', xModel='DUMMY_DATA', xMode='DUMMY_DATA', carrierInitialTransTime='DUMMY_DATA', carrierEndTransTime='DUMMY_DATA', loggedDate='DUMMY_DATA', loggedBy='DUMMY_DATA', prlNumber='DUMMY_DATA'}]}", response.toString());
  }

   @Test
   public void testGetIgFailLogs_whenException() throws SQLException {
        TracfoneOneIgFailLogs tracfoneOneIgFailLogs = new TracfoneOneIgFailLogs();
        tracfoneOneIgFailLogs.setDbEnv(DBENV);
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            action.getIgFailLogs(tracfoneOneIgFailLogs);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
   }

}