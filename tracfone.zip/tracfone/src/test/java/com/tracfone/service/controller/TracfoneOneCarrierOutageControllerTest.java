package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneCarrierOutage;
import com.tracfone.service.model.request.TracfoneOneServiceType;
import com.tracfone.service.model.response.TFOneCarrierOutage;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneServiceType;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantCarrierOutage;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneCarrierOutageControllerTest implements TracfoneOneConstant, TracfoneOneConstantCarrierOutage {

    private static final String DBENV = "DBENV";

    @InjectMocks
    TracfoneOneCarrierOutageController tracfoneOneCarrierOutageController;

    @Mock
    TracfoneOneCarrierOutageLocalAction tracfoneOneCarrierOutageAction;

    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "100");
        tracfoneOneException = new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
    }

    @Test
    public void testSearchCarrierOutage() throws Exception {
        TracfoneOneCarrierOutage tracfoneOneCarrierOutage = new TracfoneOneCarrierOutage();
        tracfoneOneCarrierOutage.setBrand("BRAND");
        tracfoneOneCarrierOutage.setCreatedBy("SONS");
        tracfoneOneCarrierOutage.setStartTime("2020:02:02");
        tracfoneOneCarrierOutage.setEndTime("2020:02:03");
        tracfoneOneCarrierOutage.setDbEnv(DBENV);
        tracfoneOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");

        List<TFOneCarrierOutage> carrierOutages = new ArrayList<>();
        TFOneCarrierOutage tfOneCarrierOutage = new TFOneCarrierOutage();
        tfOneCarrierOutage.setScriptText("SCRIPT_TEXT");
        tfOneCarrierOutage.setScriptId("1000");
        tfOneCarrierOutage.setCreatedBy("SONS");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setStartTime("2020:02:03");
        tfOneCarrierOutage.setOutageType("OUTAGE_TYPE");
        tfOneCarrierOutage.setServiceType("SERVICE_TYPE");
        tfOneCarrierOutage.setZipCode("1,2,3");
        tfOneCarrierOutage.setChannel("CHANNEL");
        tfOneCarrierOutage.setBrand("BRAND");
        tfOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");
        carrierOutages.add(tfOneCarrierOutage);

        when(tracfoneOneCarrierOutageAction.searchCarrierOutage(any())).thenReturn(carrierOutages);
        List<TFOneCarrierOutage> response = tracfoneOneCarrierOutageController.searchCarrierOutage(tracfoneOneCarrierOutage);
        assertEquals("[TFOneCarrierOutage{objId='null', parentShortName='PARENT_SHORT_NAME', brand='BRAND', channel='CHANNEL', zipCode='1,2,3', serviceType='SERVICE_TYPE', outageType='OUTAGE_TYPE', startTime='2020:02:03', endTime='2020:02:02', createdBy='SONS', scriptId='1000', scriptText='SCRIPT_TEXT', outageDescription='null', archived=false}]", response.toString());
    }

    @Test
    public void testSearchCarrierOutage_whenException() throws TracfoneOneException {
        doThrow(RuntimeException.class).when(tracfoneOneCarrierOutageAction).searchCarrierOutage(any());
        try {
            tracfoneOneCarrierOutageController.searchCarrierOutage(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_CARRIER_OUTAGES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_CARRIER_OUTAGES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierOutage() throws Exception {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setScriptText("SCRIPT_TEXT");
        tfOneCarrierOutage.setScriptId("1000");
        tfOneCarrierOutage.setCreatedBy("SONS");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setStartTime("2020:02:03");
        tfOneCarrierOutage.setOutageType("OUTAGE_TYPE");
        tfOneCarrierOutage.setServiceType("SERVICE_TYPE");
        tfOneCarrierOutage.setZipCode("1,2,3");
        tfOneCarrierOutage.setChannel("CHANNEL");
        tfOneCarrierOutage.setBrand("BRAND");
        tfOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");
        tfOneCarrierOutage.setDbEnv(DBENV);

        List<String> duplicateZips = new ArrayList<>();
        duplicateZips.add("1");
        when(tracfoneOneCarrierOutageAction.findDuplicateCarrierOutageZips(any())).thenReturn(duplicateZips);
        doNothing().when(tracfoneOneCarrierOutageAction).insertCarrierOutage(any(), anyInt());
        TFOneGeneralResponse response = tracfoneOneCarrierOutageController.insertCarrierOutage(tfOneCarrierOutage, 100);
        assertEquals("Success", response.getStatus());
        assertEquals("[1]", response.getMessage());
    }

    @Test
    public void testInsertCarrierOutage_whenException() throws Exception {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setScriptText("SCRIPT_TEXT");
        tfOneCarrierOutage.setScriptId("1000");
        tfOneCarrierOutage.setCreatedBy("SONS");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setStartTime("2020:02:03");
        tfOneCarrierOutage.setOutageType("OUTAGE_TYPE");
        tfOneCarrierOutage.setServiceType("SERVICE_TYPE");
        tfOneCarrierOutage.setZipCode("1,2,3");
        tfOneCarrierOutage.setChannel("CHANNEL");
        tfOneCarrierOutage.setBrand("BRAND");
        tfOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");
        doThrow(RuntimeException.class).when(tracfoneOneCarrierOutageAction).findDuplicateCarrierOutageZips(any());
        try {
            tracfoneOneCarrierOutageController.insertCarrierOutage(tfOneCarrierOutage, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_CARRIER_OUTAGE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_CARRIER_OUTAGE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierOutage() throws Exception {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setScriptText("SCRIPT_TEXT");
        tfOneCarrierOutage.setScriptId("1000");
        tfOneCarrierOutage.setObjId("100");
        tfOneCarrierOutage.setCreatedBy("SONS");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setStartTime("2020:02:03");
        tfOneCarrierOutage.setOutageType("OUTAGE_TYPE");
        tfOneCarrierOutage.setServiceType("SERVICE_TYPE");
        tfOneCarrierOutage.setZipCode("1,2,3");
        tfOneCarrierOutage.setChannel("CHANNEL");
        tfOneCarrierOutage.setBrand("BRAND");
        tfOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");
        tfOneCarrierOutage.setDbEnv(DBENV);
        when(tracfoneOneCarrierOutageAction.updateCarrierOutage(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneOneCarrierOutageController.updateCarrierOutage(tfOneCarrierOutage, 100);
        assertEquals("200", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testUpdateCarrierOutage_whenException() throws Exception {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setScriptText("SCRIPT_TEXT");
        tfOneCarrierOutage.setScriptId("1000");
        tfOneCarrierOutage.setCreatedBy("SONS");
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setStartTime("2020:02:03");
        tfOneCarrierOutage.setOutageType("OUTAGE_TYPE");
        tfOneCarrierOutage.setServiceType("SERVICE_TYPE");
        tfOneCarrierOutage.setZipCode("1,2,3");
        tfOneCarrierOutage.setChannel("CHANNEL");
        tfOneCarrierOutage.setBrand("BRAND");
        tfOneCarrierOutage.setParentShortName("PARENT_SHORT_NAME");
        doThrow(RuntimeException.class).when(tracfoneOneCarrierOutageAction).updateCarrierOutage(any(), anyInt());
        try {
            tracfoneOneCarrierOutageController.updateCarrierOutage(tfOneCarrierOutage, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CARRIER_OUTAGE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CARRIER_OUTAGE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateEndTime() throws Exception {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setObjIds("101,102");
        tfOneCarrierOutage.setDbEnv(DBENV);
        when(tracfoneOneCarrierOutageAction.bulkUpdateOutages(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneOneCarrierOutageController.bulkUpdateOutages(tfOneCarrierOutage, 100);
        assertEquals("200", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testUpdateEndTime_whenException() throws Exception {
        TracfoneOneCarrierOutage tfOneCarrierOutage = new TracfoneOneCarrierOutage();
        tfOneCarrierOutage.setEndTime("2020:02:02");
        tfOneCarrierOutage.setObjIds("101,102");
        doThrow(RuntimeException.class).when(tracfoneOneCarrierOutageAction).bulkUpdateOutages(any(), anyInt());
        try {
            tracfoneOneCarrierOutageController.bulkUpdateOutages(tfOneCarrierOutage, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_BULK_UPDATE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_BULK_UPDATE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testViewAllServiceType() throws Exception {
        TracfoneOneServiceType tracfoneServiceType = new TracfoneOneServiceType();
        tracfoneServiceType.setDbEnv(DBENV);
        List<TFOneServiceType> serviceType = new ArrayList<>();
        TFOneServiceType tfOneServiceType = new TFOneServiceType();
        tfOneServiceType.setObjId("100");
        tfOneServiceType.setServiceType("SERVICE_TYPE");
        tfOneServiceType.setServiceTypeCategory("SERVICE_TYPE_CATEGORY");
        tfOneServiceType.setRemarks("REMARKS");
        serviceType.add(tfOneServiceType);
        when(tracfoneOneCarrierOutageAction.viewAllServiceTypes(any())).thenReturn(serviceType);
        List<TFOneServiceType> response = tracfoneOneCarrierOutageController.viewAllServiceTypes(tracfoneServiceType);
        assertEquals("[TFOneServiceType{objId='100', serviceType='SERVICE_TYPE', serviceTypeCategory='SERVICE_TYPE_CATEGORY', remarks='REMARKS'}]", response.toString());
    }

    @Test
    public void testViewAllServiceType_whenException() throws TracfoneOneException {
        doThrow(RuntimeException.class).when(tracfoneOneCarrierOutageAction).viewAllServiceTypes(any());
        try {
            tracfoneOneCarrierOutageController.viewAllServiceTypes(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_SERVICE_TYPES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_SERVICE_TYPES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertServiceType() throws Exception {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setServiceType("SERVICE_TYPE");
        tfOneServiceType.setServiceTypeCategory("SERVICE_TYPE_CATEGORY");
        tfOneServiceType.setRemarks("REMARKS");
        tfOneServiceType.setDbEnv(DBENV);
        when(tracfoneOneCarrierOutageAction.insertServiceType(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneOneCarrierOutageController.insertServiceType(tfOneServiceType, 100);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "100");
    }

    @Test
    public void testInsertServiceType_whenException() throws Exception {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setServiceType("SERVICE_TYPE");
        tfOneServiceType.setServiceTypeCategory("SERVICE_TYPE_CATEGORY");
        tfOneServiceType.setRemarks("REMARKS");
        doThrow(tracfoneOneException).when(tracfoneOneCarrierOutageAction).insertServiceType(any(), anyInt());
        try {
            tracfoneOneCarrierOutageController.insertServiceType(tfOneServiceType, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_SERVICE_TYPES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_SERVICE_TYPES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateServiceType() throws Exception {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setServiceType("SERVICE_TYPE");
        tfOneServiceType.setServiceTypeCategory("SERVICE_TYPE_CATEGORY");
        tfOneServiceType.setObjId("100");
        tfOneServiceType.setRemarks("REMARKS");
        tfOneServiceType.setDbEnv(DBENV);
        when(tracfoneOneCarrierOutageAction.updateServiceType(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneOneCarrierOutageController.updateServiceType(tfOneServiceType, 100);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testUpdateServiceType_whenException() throws Exception {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setServiceType("SERVICE_TYPE");
        tfOneServiceType.setServiceTypeCategory("SERVICE_TYPE_CATEGORY");
        tfOneServiceType.setRemarks("REMARKS");
        doThrow(RuntimeException.class).when(tracfoneOneCarrierOutageAction).updateServiceType(any(), anyInt());
        try {
            tracfoneOneCarrierOutageController.updateServiceType(tfOneServiceType, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_SERVICE_TYPES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_SERVICE_TYPES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteServiceType() throws Exception {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setObjId("100");
        tfOneServiceType.setDbEnv(DBENV);
        when(tracfoneOneCarrierOutageAction.deleteServiceType(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneOneCarrierOutageController.deleteServiceType(tfOneServiceType, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfOneServiceType.getObjId());
    }

    @Test
    public void testDeleteServiceType_whenException() throws Exception {
        TracfoneOneServiceType tfOneServiceType = new TracfoneOneServiceType();
        tfOneServiceType.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneOneCarrierOutageAction).deleteServiceType(any(), anyInt());
        try {
            tracfoneOneCarrierOutageController.deleteServiceType(tfOneServiceType, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_SERVICE_TYPES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_SERVICE_TYPES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}
