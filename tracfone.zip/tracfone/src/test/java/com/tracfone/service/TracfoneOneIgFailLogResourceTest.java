package com.tracfone.service;

import com.tracfone.service.controller.TracfoneOneIgFailLogsControllerLocal;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneIgFailLogs;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGFailLogs;
import com.tracfone.service.model.response.TFOneIgFailLogSearchModel;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * @author Thejaswini
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneIgFailLogResourceTest {

    public final String JSON = "application/json";
    public final String DBENV = "dbEnv";
    private TracfoneOneException tracfoneOneException;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneAuthorizationException tracfoneOneAuthorizationException;

    @InjectMocks
    private TracfoneOneIgFailLogResource viewResource;

    @Mock
    private TracfoneOneIgFailLogsControllerLocal controllerLocal;
    @Mock
    private SecurityContext securityContext;
    @Mock
    private TracfoneOnePrincipal principal;
    @Mock
    private TFOneAdminUser user;

    @Before
    public void setUp() {
        initMocks(this);
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
    }

    @Test
    public void testGetIgFailLogs() throws TracfoneOneException {
        TFOneIgFailLogSearchModel tfOneIgFailLogSearchModel = new TFOneIgFailLogSearchModel();
        TracfoneOneIgFailLogs tracfoneOneIgFailLogs = new TracfoneOneIgFailLogs();
        tracfoneOneIgFailLogs.setDbEnv(DBENV);
        List<TFOneIGFailLogs> tfOneIGFailLogs = new ArrayList<>();
        TFOneIGFailLogs tfOneIGFailLog = new TFOneIGFailLogs();
        tfOneIGFailLog.setActionItemId("100");
        tfOneIGFailLogs.add(tfOneIGFailLog);
        tfOneIgFailLogSearchModel.setiGFailLogs(tfOneIGFailLogs);
        when(controllerLocal.getIgFailLogs(any())).thenReturn(tfOneIgFailLogSearchModel);
        Response response = viewResource.getIgFailLogs(tracfoneOneIgFailLogs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"paginationSearch\":null,\"iGFailLogs\":[{\"callTransActionType\":null,\"actionItemId\":\"100\",\"carrierId\":null,\"orderType\":null,\"min\":null,\"esn\":null,\"esnPartClassModel\":null,\"esnHex\":null,\"oldEsn\":null,\"oldEsnHex\":null,\"pin\":null,\"phoneManf\":null,\"endUser\":null,\"accountNum\":null,\"marketCode\":null,\"ratePlan\":null,\"ldProvider\":null,\"sequenceNum\":null,\"dealerCode\":null,\"transmissionMethod\":null,\"faxNum\":null,\"onlineNum\":null,\"email\":null,\"networkLogin\":null,\"networkPassword\":null,\"systemLogin\":null,\"systemPassword\":null,\"template\":null,\"exeName\":null,\"comPort\":null,\"status\":null,\"statusMessage\":null,\"faxBatchSize\":null,\"faxBatchQtime\":null,\"expidite\":null,\"transProfKey\":null,\"qTransaction\":null,\"onlineNum2\":null,\"faxNum2\":null,\"creationDate\":null,\"updateDate\":null,\"igDbSecsToComp\":null,\"blackoutWait\":null,\"tuxItiServer\":null,\"transactionId\":null,\"technologyFlag\":null,\"voiceMail\":null,\"voiceMailPackage\":null,\"callerId\":null,\"carrierAccountId\":null,\"tmoNextGenFlag\":null,\"callerIdPackage\":null,\"callWaiting\":null,\"callWaitingPackage\":null,\"rtpServer\":null,\"digitalFeatureCode\":null,\"stateField\":null,\"zipCode\":null,\"msid\":null,\"newMsidFlag\":null,\"sms\":null,\"smsPackage\":null,\"iccid\":null,\"oldMin\":null,\"digitalFeature\":null,\"otaType\":null,\"rateCenterNo\":null,\"applicationSystem\":null,\"subscriberUpdate\":null,\"downloadDate\":null,\"amount\":null,\"balance\":null,\"language\":null,\"expDate\":null,\"xMpn\":null,\"xMpnCode\":null,\"xPoolName\":null,\"xMake\":null,\"xModel\":null,\"xMode\":null,\"carrierInitialTransTime\":null,\"carrierEndTransTime\":null,\"loggedDate\":null,\"loggedBy\":null,\"prlNumber\":null}]}", response.getEntity().toString());
    }

    @Test
    public void testGetIgFailLogs_whenException() throws TracfoneOneException {
        TracfoneOneIgFailLogs tracfoneOneIgFailLogs = new TracfoneOneIgFailLogs();
        tracfoneOneIgFailLogs.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(controllerLocal).getIgFailLogs(any());
        Response response = viewResource.getIgFailLogs(tracfoneOneIgFailLogs);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

}