package com.tracfone.service;

import com.tracfone.service.controller.retail.TracfoneOneRetailAdminActionLocal;
import com.tracfone.service.controller.retail.TracfoneOneRetailStoreControllerLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneJobTask;
import com.tracfone.service.model.retail.request.TracfoneOneRetailBrand;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrier;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierDetail;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierPrefDetail;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierPrefGroup;
import com.tracfone.service.model.retail.request.TracfoneOneRetailMaster;
import com.tracfone.service.model.retail.request.TracfoneOneRetailParent;
import com.tracfone.service.model.retail.request.TracfoneOneRetailParentRule;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTech;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTpAdminSearchModel;
import com.tracfone.service.model.retail.request.TracfoneOneTraitLogicRule;
import com.tracfone.service.model.retail.response.TFOneRetailBrand;
import com.tracfone.service.model.retail.response.TFOneRetailCarrier;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierDetail;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierPrefDetail;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierPrefGroup;
import com.tracfone.service.model.retail.response.TFOneRetailMaster;
import com.tracfone.service.model.retail.response.TFOneRetailParent;
import com.tracfone.service.model.retail.response.TFOneRetailParentRule;
import com.tracfone.service.model.retail.response.TFOneRetailTech;
import com.tracfone.service.model.retail.response.TFOneRetailTpAdminSearchResults;
import com.tracfone.service.model.retail.response.TFOneTraitLogicRule;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneRetailStoreAdminResourceTest {

    public final String JSON = "application/json";
    @InjectMocks
    private TracfoneOneRetailStoreAdminResource retailStoreAdminResource;

    @Mock
    private TracfoneOneRetailAdminActionLocal tracfoneOneRetailAdminAction;

    @Mock
    private TracfoneOneRetailStoreControllerLocal tracfoneOneRetailStoreController;

    @Mock
    private SecurityContext securityContext;
    @Mock
    private TracfoneOnePrincipal principal;
    @Mock
    private TFOneAdminUser user;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    @Before
    public void setUp() {
        initMocks(this);
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
        when(securityContext.getUserPrincipal()).thenReturn(principal);
        when(principal.getTFUser()).thenReturn(user);
    }

    @Test
    public void testGetCarriers() throws TracfoneOneException {
        List<TFOneRetailCarrier> tfCRtlCarriers = new ArrayList<>();
        TFOneRetailCarrier tfOneCRtlCarrier = new TFOneRetailCarrier();
        tfOneCRtlCarrier.setObjId("100");
        tfCRtlCarriers.add(tfOneCRtlCarrier);
        when(tracfoneOneRetailAdminAction.getCarriers()).thenReturn(tfCRtlCarriers);
        Response response = retailStoreAdminResource.getCarriers();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"100\",\"secUserId\":null,\"status\":null,\"carrier\":null,\"carrierLong\":null,\"insertDate\":null,\"updateDate\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarriers_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getCarriers();
        Response response = retailStoreAdminResource.getCarriers();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1400-Unable to get all Carrier\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrier() throws TracfoneOneException {
        TracfoneOneRetailCarrier tracfoneOneRetailCarrier = new TracfoneOneRetailCarrier();
        tracfoneOneRetailCarrier.setSecUserId("1000");
        tracfoneOneRetailCarrier.setStatus("STATUS");
        tracfoneOneRetailCarrier.setCarrierLong("CARRIER_LONG");
        tracfoneOneRetailCarrier.setCarrier("CARRIER");
        when(tracfoneOneRetailAdminAction.insertCarrier(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.insertCarrier(tracfoneOneRetailCarrier);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrier_whenException() throws TracfoneOneException {
        TracfoneOneRetailCarrier tracfoneOneRetailCarrier = new TracfoneOneRetailCarrier();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).insertCarrier(any(), anyInt());
        Response response = retailStoreAdminResource.insertCarrier(tracfoneOneRetailCarrier);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1410-Unable to add a Carrier\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrier() throws TracfoneOneException {
        TracfoneOneRetailCarrier tracfoneOneRetailCarrier = new TracfoneOneRetailCarrier();
        tracfoneOneRetailCarrier.setSecUserId("1000");
        tracfoneOneRetailCarrier.setStatus("STATUS");
        tracfoneOneRetailCarrier.setCarrierLong("CARRIER_LONG");
        tracfoneOneRetailCarrier.setCarrier("CARRIER");
        when(tracfoneOneRetailAdminAction.updateCarrier(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.updateCarrier(tracfoneOneRetailCarrier);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrier_whenException() throws TracfoneOneException {
        TracfoneOneRetailCarrier tracfoneOneRetailCarrier = new TracfoneOneRetailCarrier();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).updateCarrier(any(), anyInt());
        Response response = retailStoreAdminResource.updateCarrier(tracfoneOneRetailCarrier);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1410-Unable to update a Carrier\"}", response.getEntity().toString());
    }

    @Test
    public void testGetBrands() throws TracfoneOneException {
        List<TFOneRetailBrand> tfOneCRtlBrands = new ArrayList<>();
        TFOneRetailBrand tfOneCRtlBrand = new TFOneRetailBrand();
        tfOneCRtlBrand.setObjId("100");
        tfOneCRtlBrands.add(tfOneCRtlBrand);
        when(tracfoneOneRetailAdminAction.getBrands()).thenReturn(tfOneCRtlBrands);
        Response response = retailStoreAdminResource.getBrands();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"100\",\"oneSecUserId\":null,\"status\":null,\"brand\":null,\"brandLong\":null,\"insertDate\":null,\"updateDate\":null,\"cRtlTraitLogicRuleId\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBrands_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getBrands();
        Response response = retailStoreAdminResource.getBrands();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1401-Unable to get all Brand\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertBrand() throws TracfoneOneException {
        TracfoneOneRetailBrand tracfoneOneRetailBrand = new TracfoneOneRetailBrand();
        tracfoneOneRetailBrand.setBrandLong("BRAND_LONG");
        tracfoneOneRetailBrand.setBrand("BRAND");
        tracfoneOneRetailBrand.setSecUserId("1000");
        tracfoneOneRetailBrand.setStatus("STATUS");
        tracfoneOneRetailBrand.setTraitLogicRuleId("1000");
        when(tracfoneOneRetailAdminAction.insertBrand(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.insertBrand(tracfoneOneRetailBrand);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertBrand_whenException() throws TracfoneOneException {
        TracfoneOneRetailBrand tracfoneOneRetailBrand = new TracfoneOneRetailBrand();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).insertBrand(any(), anyInt());
        Response response = retailStoreAdminResource.insertBrand(tracfoneOneRetailBrand);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1411-Unable to add a Brand\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateBrand() throws TracfoneOneException {
        TracfoneOneRetailBrand tracfoneOneRetailBrand = new TracfoneOneRetailBrand();
        tracfoneOneRetailBrand.setBrandLong("BRAND_LONG");
        tracfoneOneRetailBrand.setBrand("BRAND");
        tracfoneOneRetailBrand.setSecUserId("1000");
        tracfoneOneRetailBrand.setStatus("STATUS");
        tracfoneOneRetailBrand.setTraitLogicRuleId("1000");
        tracfoneOneRetailBrand.setObjId("1000");
        when(tracfoneOneRetailAdminAction.updateBrand(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.updateBrand(tracfoneOneRetailBrand);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateBrand_whenException() throws TracfoneOneException {
        TracfoneOneRetailBrand tracfoneOneRetailBrand = new TracfoneOneRetailBrand();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).updateBrand(any(), anyInt());
        Response response = retailStoreAdminResource.updateBrand(tracfoneOneRetailBrand);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1411-Unable to update a Brand\"}", response.getEntity().toString());
    }

    @Test
    public void testGetTraitLogicRules() throws TracfoneOneException {
        List<TFOneTraitLogicRule> tfOneTraitLogicRules = new ArrayList<>();
        TFOneTraitLogicRule tfOneTraitLogicRule = new TFOneTraitLogicRule();
        tfOneTraitLogicRule.setObjId("1000");
        tfOneTraitLogicRule.setInnerGeo("1000");
        tfOneTraitLogicRule.setInnerPop("1000");
        tfOneTraitLogicRule.setOuterGeo("1000");
        tfOneTraitLogicRule.setOuterPop("1000");
        tfOneTraitLogicRule.setOuterRadius("1000");
        tfOneTraitLogicRule.setInnerRadius("1000");
        tfOneTraitLogicRule.setPrefAllCarr("1000");
        tfOneTraitLogicRule.setRule2Logic("1000");
        tfOneTraitLogicRule.setRule2User("1000");
        tfOneTraitLogicRule.setRuleName("1000");
        tfOneTraitLogicRule.setUseOuterPop("1000");
        tfOneTraitLogicRules.add(tfOneTraitLogicRule);
        when(tracfoneOneRetailAdminAction.getTraitLogicRules()).thenReturn(tfOneTraitLogicRules);
        Response response = retailStoreAdminResource.getTraitLogicRules();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"ruleName\":\"1000\",\"innerRadius\":\"1000\",\"innerPop\":\"1000\",\"innerGeo\":\"1000\",\"outerRadius\":\"1000\",\"outerPop\":\"1000\",\"outerGeo\":\"1000\",\"useOuterPop\":\"1000\",\"rule2Logic\":\"1000\",\"rule2User\":\"1000\",\"prefAllCarr\":\"1000\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetTraitLogicRules_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getTraitLogicRules();
        Response response = retailStoreAdminResource.getTraitLogicRules();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1404-Unable to get all Trait Logic Rules\"}", response.getEntity().toString());
    }

    @Test
    public void testGetTechs() throws TracfoneOneException {
        List<TFOneRetailTech> tfOneCRtlTechs = new ArrayList<>();
        TFOneRetailTech tfOneCRtlTech = new TFOneRetailTech();
        tfOneCRtlTech.setObjId("100");
        tfOneCRtlTechs.add(tfOneCRtlTech);
        when(tracfoneOneRetailAdminAction.getTechs()).thenReturn(tfOneCRtlTechs);
        Response response = retailStoreAdminResource.getTechs();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"100\",\"secUserId\":null,\"status\":null,\"tech\":null,\"techLong\":null,\"insertDate\":null,\"updateDate\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetTechs_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getTechs();
        Response response = retailStoreAdminResource.getTechs();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1402-Unable to get all Techs\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertTech() throws TracfoneOneException {
        TracfoneOneRetailTech tracfoneOneRetailTech = new TracfoneOneRetailTech();
        tracfoneOneRetailTech.setSecUserId("1000");
        tracfoneOneRetailTech.setStatus("STATUS");
        tracfoneOneRetailTech.setTech("TECH");
        tracfoneOneRetailTech.setTechLong("TECH_LONG");
        when(tracfoneOneRetailAdminAction.insertTech(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.insertTech(tracfoneOneRetailTech);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertTech_whenException() throws TracfoneOneException {
        TracfoneOneRetailTech tracfoneOneRetailTech = new TracfoneOneRetailTech();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).insertTech(any(), anyInt());
        Response response = retailStoreAdminResource.insertTech(tracfoneOneRetailTech);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1412-Unable to add a Tech\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateTech() throws TracfoneOneException {
        TracfoneOneRetailTech tracfoneOneRetailTech = new TracfoneOneRetailTech();
        tracfoneOneRetailTech.setSecUserId("1000");
        tracfoneOneRetailTech.setObjId("1000");
        tracfoneOneRetailTech.setStatus("STATUS");
        tracfoneOneRetailTech.setTech("TECH");
        tracfoneOneRetailTech.setTechLong("TECH_LONG");
        when(tracfoneOneRetailAdminAction.updateTech(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.updateTech(tracfoneOneRetailTech);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateTech_whenException() throws TracfoneOneException {
        TracfoneOneRetailTech tracfoneOneRetailTech = new TracfoneOneRetailTech();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).updateTech(any(), anyInt());
        Response response = retailStoreAdminResource.updateTech(tracfoneOneRetailTech);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1412-Unable to update a Tech\"}", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierDetails() throws TracfoneOneException {
        List<TFOneRetailCarrierDetail> carrierDtls = new ArrayList<>();
        TFOneRetailCarrierDetail carrierDtl = new TFOneRetailCarrierDetail();
        carrierDtl.setObjId("100");
        carrierDtls.add(carrierDtl);
        when(tracfoneOneRetailAdminAction.getCarrierDetails()).thenReturn(carrierDtls);
        Response response = retailStoreAdminResource.getCarrierDetails();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"100\",\"status\":null,\"cdtl2Carrier\":null,\"cdtl2Brand\":null,\"cdtl2Tech\":null,\"cdtl2User\":null,\"insertDate\":null,\"updateDate\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierDetails_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getCarrierDetails();
        Response response = retailStoreAdminResource.getCarrierDetails();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1403-Unable to get all Carrier Detail\"}", response.getEntity().toString());
    }


    @Test
    public void testGetCarrierDetailsByBrand() throws TracfoneOneException {
        List<TFOneRetailCarrierDetail> carrierDtls = new ArrayList<>();
        TFOneRetailCarrierDetail carrierDtl = new TFOneRetailCarrierDetail();
        carrierDtl.setObjId("100");
        carrierDtls.add(carrierDtl);
        when(tracfoneOneRetailAdminAction.getCarrierDetailsByBrand(anyString())).thenReturn(carrierDtls);
        Response response = retailStoreAdminResource.getCarrierDetailsByBrand("BRAND_ID");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"100\",\"status\":null,\"cdtl2Carrier\":null,\"cdtl2Brand\":null,\"cdtl2Tech\":null,\"cdtl2User\":null,\"insertDate\":null,\"updateDate\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierDetailsByBrand_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getCarrierDetailsByBrand(anyString());
        Response response = retailStoreAdminResource.getCarrierDetailsByBrand("BRAND_ID");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1403-Unable to get all Carrier Detail\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierDetail() throws TracfoneOneException {
        TracfoneOneRetailCarrierDetail tracfoneOneRetailCarrierDetail = new TracfoneOneRetailCarrierDetail();
        tracfoneOneRetailCarrierDetail.setStatus("STATUS");
        when(tracfoneOneRetailAdminAction.insertCarrierDetail(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.insertCarrierDetail(tracfoneOneRetailCarrierDetail);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierDetail_whenException() throws TracfoneOneException {
        TracfoneOneRetailCarrierDetail tracfoneOneRetailCarrierDetail = new TracfoneOneRetailCarrierDetail();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).insertCarrierDetail(any(), anyInt());
        Response response = retailStoreAdminResource.insertCarrierDetail(tracfoneOneRetailCarrierDetail);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1413-Unable to add a Carrier Detail\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierDetail() throws TracfoneOneException {
        TracfoneOneRetailCarrierDetail tracfoneOneRetailCarrierDetail = new TracfoneOneRetailCarrierDetail();
        tracfoneOneRetailCarrierDetail.setStatus("STATUS");
        when(tracfoneOneRetailAdminAction.updateCarrierDetail(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.updateCarrierDetail(tracfoneOneRetailCarrierDetail);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierDetail_whenException() throws TracfoneOneException {
        TracfoneOneRetailCarrierDetail tracfoneOneRetailCarrierDetail = new TracfoneOneRetailCarrierDetail();
        tracfoneOneRetailCarrierDetail.setObjId("1000");
        tracfoneOneRetailCarrierDetail.setCdtl2User("1000");
        tracfoneOneRetailCarrierDetail.setCdtl2Tech("1000");
        tracfoneOneRetailCarrierDetail.setCdtl2Carrier("1000");
        tracfoneOneRetailCarrierDetail.setCdtl2Brand("1000");
        tracfoneOneRetailCarrierDetail.setStatus("STATUS");
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).updateCarrierDetail(any(), anyInt());
        Response response = retailStoreAdminResource.updateCarrierDetail(tracfoneOneRetailCarrierDetail);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1413-Unable to update a Carrier Detail\"}", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierPrefGroups() throws TracfoneOneException {
        List<TFOneRetailCarrierPrefGroup> tfOneRetailCarrierPrefGroups = new ArrayList<>();
        TFOneRetailCarrierPrefGroup tfOneRetailCarrierPrefGroup = new TFOneRetailCarrierPrefGroup();
        tfOneRetailCarrierPrefGroup.setBrand("BRAND");
        tfOneRetailCarrierPrefGroups.add(tfOneRetailCarrierPrefGroup);
        when(tracfoneOneRetailAdminAction.getCarrierPrefGroups()).thenReturn(tfOneRetailCarrierPrefGroups);
        Response response = retailStoreAdminResource.getCarrierPrefGroups();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"secUserId\":null,\"status\":null,\"description\":null,\"brand\":\"BRAND\",\"insertDate\":null,\"updateDate\":null,\"carrierPrefDetails\":[]}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierPrefGroups_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getCarrierPrefGroups();
        Response response = retailStoreAdminResource.getCarrierPrefGroups();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1405-Unable to get all Carrier Pref Groups\"}", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierPrefDetails() throws TracfoneOneException {
        List<TFOneRetailCarrierPrefDetail> tfOneRetailCarrierPrefDetails = new ArrayList<>();
        TFOneRetailCarrierPrefDetail tfOneRetailCarrierPrefDetail = new TFOneRetailCarrierPrefDetail();
        tfOneRetailCarrierPrefDetail.setBrand("BRAND");
        tfOneRetailCarrierPrefDetails.add(tfOneRetailCarrierPrefDetail);
        when(tracfoneOneRetailAdminAction.getCarrierPrefDetails(anyString())).thenReturn(tfOneRetailCarrierPrefDetails);
        Response response = retailStoreAdminResource.getCarrierPrefDetails("CARRIER_GROUP_ID");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"carrierPrefGroupId\":null,\"carrierDetailId\":null,\"rank\":null,\"carrier\":null,\"brand\":\"BRAND\",\"tech\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierPrefDetails_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getCarrierPrefDetails(anyString());
        Response response = retailStoreAdminResource.getCarrierPrefDetails("CARRIER_GROUP_ID");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1403-Unable to get all Carrier Detail\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierPrefDetail() throws TracfoneOneException {
        TracfoneOneRetailCarrierPrefDetail tracfoneOneRetailCarrierPrefDetail = new TracfoneOneRetailCarrierPrefDetail();
        tracfoneOneRetailCarrierPrefDetail.setObjId("1000");
        tracfoneOneRetailCarrierPrefDetail.setCarrierDetailId("1000");
        tracfoneOneRetailCarrierPrefDetail.setCarrierPrefGroupId("1000");
        tracfoneOneRetailCarrierPrefDetail.setRank("1000");
        when(tracfoneOneRetailAdminAction.insertCarrierPrefDetail(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.insertCarrierPrefDetail(tracfoneOneRetailCarrierPrefDetail);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierPrefDetail_whenException() throws TracfoneOneException {
        TracfoneOneRetailCarrierPrefDetail tracfoneOneRetailCarrierPrefDetail = new TracfoneOneRetailCarrierPrefDetail();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).insertCarrierPrefDetail(any(), anyInt());
        Response response = retailStoreAdminResource.insertCarrierPrefDetail(tracfoneOneRetailCarrierPrefDetail);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1416-Unable to add a Carrier Pref Detail\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteCarrierPrefDetail() throws TracfoneOneException {
        when(tracfoneOneRetailAdminAction.deleteCarrierPrefDetail(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.deleteCarrierPrefDetail("1000");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteCarrierPrefDetail_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).deleteCarrierPrefDetail(any(), anyInt());
        Response response = retailStoreAdminResource.deleteCarrierPrefDetail("1000");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1416-Unable to delete a Carrier Pref Detail\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierPrefGroup() throws TracfoneOneException {
        TracfoneOneRetailCarrierPrefGroup tracfoneOneRetailCarrierPrefGroup = new TracfoneOneRetailCarrierPrefGroup();
        tracfoneOneRetailCarrierPrefGroup.setBrand("BRAND");
        when(tracfoneOneRetailAdminAction.insertCarrierPrefGroup(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.insertCarrierPrefGroup(tracfoneOneRetailCarrierPrefGroup);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierPrefGroup_whenException() throws TracfoneOneException {
        TracfoneOneRetailCarrierPrefGroup tracfoneOneRetailCarrierPrefGroup = new TracfoneOneRetailCarrierPrefGroup();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).insertCarrierPrefGroup(any(), anyInt());
        Response response = retailStoreAdminResource.insertCarrierPrefGroup(tracfoneOneRetailCarrierPrefGroup);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1415-Unable to add a Carrier Pref Group\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierPrefGroup() throws TracfoneOneException {
        TracfoneOneRetailCarrierPrefGroup tracfoneOneRetailCarrierPrefGroup = new TracfoneOneRetailCarrierPrefGroup();
        tracfoneOneRetailCarrierPrefGroup.setBrand("BRAND");
        when(tracfoneOneRetailAdminAction.updateCarrierPrefGroup(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.updateCarrierPrefGroup(tracfoneOneRetailCarrierPrefGroup);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierPrefGroup_whenException() throws TracfoneOneException {
        TracfoneOneRetailCarrierPrefGroup tracfoneOneRetailCarrierPrefGroup = new TracfoneOneRetailCarrierPrefGroup();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).updateCarrierPrefGroup(any(), anyInt());
        Response response = retailStoreAdminResource.updateCarrierPrefGroup(tracfoneOneRetailCarrierPrefGroup);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1415-Unable to update a Carrier Pref Group\"}", response.getEntity().toString());
    }

    @Test
    public void testGetParents() throws TracfoneOneException {
        List<TFOneRetailParent> tfOneRetailParents = new ArrayList<>();
        TFOneRetailParent tfOneRetailParent = new TFOneRetailParent();
        tfOneRetailParent.setObjId("1000");
        tfOneRetailParent.setRetailer("REATAILER");
        tfOneRetailParent.setSecUserId("1000");
        tfOneRetailParent.setStatus("STATUS");
        tfOneRetailParents.add(tfOneRetailParent);
        when(tracfoneOneRetailAdminAction.getParents()).thenReturn(tfOneRetailParents);
        Response response = retailStoreAdminResource.getParents();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"status\":\"STATUS\",\"retailer\":\"REATAILER\",\"secUserId\":\"1000\",\"insertDate\":null,\"updateDate\":null,\"lastTraitRunDate\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetParents_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getParents();
        Response response = retailStoreAdminResource.getParents();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1407-Unable to get all Parents\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertParent() throws TracfoneOneException {
        TracfoneOneRetailParent tracfoneOneRetailParent = new TracfoneOneRetailParent();
        tracfoneOneRetailParent.setStatus("STATUS");
        tracfoneOneRetailParent.setSecUserId("1000");
        tracfoneOneRetailParent.setRetailer("RETAILER");
        when(tracfoneOneRetailAdminAction.insertParent(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.insertParent(tracfoneOneRetailParent);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertParent_whenException() throws TracfoneOneException {
        TracfoneOneRetailParent tracfoneOneRetailParent = new TracfoneOneRetailParent();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).insertParent(any(), anyInt());
        Response response = retailStoreAdminResource.insertParent(tracfoneOneRetailParent);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1417-Unable to add a Parent\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateParent() throws TracfoneOneException {
        TracfoneOneRetailParent tracfoneOneRetailParent = new TracfoneOneRetailParent();
        tracfoneOneRetailParent.setStatus("STATUS");
        tracfoneOneRetailParent.setSecUserId("1000");
        tracfoneOneRetailParent.setRetailer("RETAILER");
        when(tracfoneOneRetailAdminAction.updateParent(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.updateParent(tracfoneOneRetailParent);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateParent_whenException() throws TracfoneOneException {
        TracfoneOneRetailParent tracfoneOneRetailParent = new TracfoneOneRetailParent();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).updateParent(any(), anyInt());
        Response response = retailStoreAdminResource.updateParent(tracfoneOneRetailParent);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1417-Unable to update a Parent\"}", response.getEntity().toString());
    }

    @Test
    public void testGetMasters() throws TracfoneOneException {
        List<TFOneRetailMaster> tfOneRetailMasters = new ArrayList<>();
        TFOneRetailMaster tfOneRetailMaster = new TFOneRetailMaster();
        tfOneRetailMaster.setMaster2Parent("1000");
        tfOneRetailMaster.setObjId("1000");
        tfOneRetailMaster.setSecUserId("1000");
        tfOneRetailMaster.setStatus("STATUS");
        tfOneRetailMaster.setStoreName("STORE_NAME");
        tfOneRetailMasters.add(tfOneRetailMaster);
        when(tracfoneOneRetailAdminAction.getMasters(any())).thenReturn(tfOneRetailMasters);
        Response response = retailStoreAdminResource.getMasters("1000");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"status\":\"STATUS\",\"storeName\":\"STORE_NAME\",\"master2Parent\":\"1000\",\"secUserId\":\"1000\",\"insertDate\":null,\"updateDate\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetMasters_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getMasters(any());
        Response response = retailStoreAdminResource.getMasters("1000");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1408-Unable to get all Masters\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertMaster() throws TracfoneOneException {
        TracfoneOneRetailMaster tfOneRetailMaster = new TracfoneOneRetailMaster();
        tfOneRetailMaster.setMaster2Parent("1000");
        tfOneRetailMaster.setObjId("1000");
        tfOneRetailMaster.setSecUserId("1000");
        tfOneRetailMaster.setStatus("STATUS");
        tfOneRetailMaster.setStoreName("STORE_NAME");
        when(tracfoneOneRetailAdminAction.insertMaster(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.insertMaster(tfOneRetailMaster);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertMaster_whenException() throws TracfoneOneException {
        TracfoneOneRetailMaster tfOneRetailMaster = new TracfoneOneRetailMaster();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).insertMaster(any(), anyInt());
        Response response = retailStoreAdminResource.insertMaster(tfOneRetailMaster);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1418-Unable to add a Master\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateMaster() throws TracfoneOneException {
        TracfoneOneRetailMaster tfOneRetailMaster = new TracfoneOneRetailMaster();
        tfOneRetailMaster.setMaster2Parent("1000");
        tfOneRetailMaster.setObjId("1000");
        tfOneRetailMaster.setSecUserId("1000");
        tfOneRetailMaster.setStatus("STATUS");
        tfOneRetailMaster.setStoreName("STORE_NAME");
        when(tracfoneOneRetailAdminAction.updateMaster(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.updateMaster(tfOneRetailMaster);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateMaster_whenException() throws TracfoneOneException {
        TracfoneOneRetailMaster tfOneRetailMaster = new TracfoneOneRetailMaster();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).updateMaster(any(), anyInt());
        Response response = retailStoreAdminResource.updateMaster(tfOneRetailMaster);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1418-Unable to update a Master\"}", response.getEntity().toString());
    }

    @Test
    public void testGetParentRules() throws TracfoneOneException {
        List<TFOneRetailParentRule> tfOneRetailParentRules = new ArrayList<>();
        TFOneRetailParentRule tfOneRetailParentRule = new TFOneRetailParentRule();
        tfOneRetailParentRule.setObjId("1000");
        tfOneRetailParentRule.setRule2cPrefGrpRank("1000");
        tfOneRetailParentRule.setRule2cPrefGrpTrait("1000");
        tfOneRetailParentRule.setRule2Parent("1000");
        tfOneRetailParentRule.setRule2TraitRule("1000");
        tfOneRetailParentRules.add(tfOneRetailParentRule);
        when(tracfoneOneRetailAdminAction.getParentRules(any())).thenReturn(tfOneRetailParentRules);
        Response response = retailStoreAdminResource.getParentRules("1000");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"rule2Parent\":\"1000\",\"rule2cPrefGrpTrait\":\"1000\",\"rule2cPrefGrpRank\":\"1000\",\"rule2TraitRule\":\"1000\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetParentRules_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getParentRules(any());
        Response response = retailStoreAdminResource.getParentRules("1000");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1409-Unable to get all Parent Rules\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertParentRule() throws TracfoneOneException {
        TracfoneOneRetailParentRule tracfoneOneRetailParentRule = new TracfoneOneRetailParentRule();
        tracfoneOneRetailParentRule.setRule2TraitRule("1000");
        tracfoneOneRetailParentRule.setRule2Parent("1000");
        tracfoneOneRetailParentRule.setRule2cPrefGrpTrait("1000");
        tracfoneOneRetailParentRule.setRule2cPrefGrpRank("1000");
        when(tracfoneOneRetailAdminAction.insertParentRule(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.insertParentRule(tracfoneOneRetailParentRule);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertParentRule_whenException() throws TracfoneOneException {
        TracfoneOneRetailParentRule tracfoneOneRetailParentRule = new TracfoneOneRetailParentRule();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).insertParentRule(any(), anyInt());
        Response response = retailStoreAdminResource.insertParentRule(tracfoneOneRetailParentRule);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1419-Unable to add a Parent Rule\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateParentRule() throws TracfoneOneException {
        TracfoneOneRetailParentRule tracfoneOneRetailParentRule = new TracfoneOneRetailParentRule();
        tracfoneOneRetailParentRule.setRule2TraitRule("1000");
        tracfoneOneRetailParentRule.setRule2Parent("1000");
        tracfoneOneRetailParentRule.setObjId("1000");
        tracfoneOneRetailParentRule.setRule2cPrefGrpTrait("1000");
        tracfoneOneRetailParentRule.setRule2cPrefGrpRank("1000");
        when(tracfoneOneRetailAdminAction.updateParentRule(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.updateParentRule(tracfoneOneRetailParentRule);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateParentRule_whenException() throws TracfoneOneException {
        TracfoneOneRetailParentRule tracfoneOneRetailParentRule = new TracfoneOneRetailParentRule();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).updateParentRule(any(), anyInt());
        Response response = retailStoreAdminResource.updateParentRule(tracfoneOneRetailParentRule);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1419-Unable to update a Parent Rule\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertTraitLogicRule() throws TracfoneOneException {
        TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule = new TracfoneOneTraitLogicRule();
        tracfoneOneTraitLogicRule.setInnerGeo("1000");
        tracfoneOneTraitLogicRule.setInnerPop("1000");
        tracfoneOneTraitLogicRule.setInnerRadius("1000");
        tracfoneOneTraitLogicRule.setOuterGeo("1000");
        tracfoneOneTraitLogicRule.setInnerGeo("1000");
        tracfoneOneTraitLogicRule.setOuterPop("1000");
        tracfoneOneTraitLogicRule.setOuterRadius("1000");
        tracfoneOneTraitLogicRule.setPrefAllCarr("1000");
        tracfoneOneTraitLogicRule.setRule2Logic("1000");
        tracfoneOneTraitLogicRule.setRule2User("1000");
        tracfoneOneTraitLogicRule.setRuleName("RULE_NAME");
        tracfoneOneTraitLogicRule.setUseOuterPop("1000");
        when(tracfoneOneRetailAdminAction.insertTraitLogicRule(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.insertTraitLogicRule(tracfoneOneTraitLogicRule);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertTraitLogicRule_whenException() throws TracfoneOneException {
        TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule = new TracfoneOneTraitLogicRule();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).insertTraitLogicRule(any(), anyInt());
        Response response = retailStoreAdminResource.insertTraitLogicRule(tracfoneOneTraitLogicRule);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1420-Unable to add a Trait Logic Rule\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateTraitLogicRule() throws TracfoneOneException {
        TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule = new TracfoneOneTraitLogicRule();
        tracfoneOneTraitLogicRule.setInnerGeo("1000");
        tracfoneOneTraitLogicRule.setInnerPop("1000");
        tracfoneOneTraitLogicRule.setInnerRadius("1000");
        tracfoneOneTraitLogicRule.setOuterGeo("1000");
        tracfoneOneTraitLogicRule.setInnerGeo("1000");
        tracfoneOneTraitLogicRule.setOuterPop("1000");
        tracfoneOneTraitLogicRule.setOuterRadius("1000");
        tracfoneOneTraitLogicRule.setPrefAllCarr("1000");
        tracfoneOneTraitLogicRule.setRule2Logic("1000");
        tracfoneOneTraitLogicRule.setRule2User("1000");
        tracfoneOneTraitLogicRule.setRuleName("RULE_NAME");
        tracfoneOneTraitLogicRule.setUseOuterPop("1000");
        when(tracfoneOneRetailAdminAction.updateTraitLogicRule(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.updateTraitLogicRule(tracfoneOneTraitLogicRule);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateTraitLogicRule_whenException() throws TracfoneOneException {
        TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule = new TracfoneOneTraitLogicRule();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).updateTraitLogicRule(any(), anyInt());
        Response response = retailStoreAdminResource.updateTraitLogicRule(tracfoneOneTraitLogicRule);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1421-Unable to update a Trait Logic Rule\"}", response.getEntity().toString());
    }

    @Test
    public void testGetStates() throws TracfoneOneException {
        List<String> states = new ArrayList<>();
        states.add("NY");
        states.add("MA");
        when(tracfoneOneRetailAdminAction.getStates()).thenReturn(states);
        Response response = retailStoreAdminResource.getStates();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[\"NY\",\"MA\"]", response.getEntity().toString());
    }

    @Test
    public void testGetStates_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getStates();
        Response response = retailStoreAdminResource.getStates();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1423-Unable to get all States\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateTpNorms() throws TracfoneOneException {
        TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel = new TracfoneOneRetailTpAdminSearchModel();
        retailTpAdminSearchModel.setCoverage("GOOD");
        retailTpAdminSearchModel.setCoverageNotes("NOTE");
        when(tracfoneOneRetailAdminAction.updateTpNorms(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.updateTpNorms(retailTpAdminSearchModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateTpNorms_whenException() throws TracfoneOneException {
        TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel = new TracfoneOneRetailTpAdminSearchModel();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).updateTpNorms(any(), anyInt());
        Response response = retailStoreAdminResource.updateTpNorms(retailTpAdminSearchModel);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1424-Unable to update TP Norms\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllCarrierDetails() throws TracfoneOneException {
        List<TFOneRetailCarrierDetail> tfOneRetailCarrierDetails = new ArrayList<>();
        TFOneRetailCarrierDetail tfOneRetailCarrierDetail = new TFOneRetailCarrierDetail();
        tfOneRetailCarrierDetail.setObjId("1000");
        tfOneRetailCarrierDetail.setCdtl2Brand("BRAND");
        tfOneRetailCarrierDetail.setCdtl2Carrier("CARRIER");
        tfOneRetailCarrierDetail.setCdtl2Tech("TECH");
        tfOneRetailCarrierDetail.setStatus("A");
        tfOneRetailCarrierDetail.setCdtl2User("1");
        tfOneRetailCarrierDetails.add(tfOneRetailCarrierDetail);
        when(tracfoneOneRetailAdminAction.getAllCarrierDetails()).thenReturn(tfOneRetailCarrierDetails);
        Response response = retailStoreAdminResource.getAllCarrierDetails();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"status\":\"A\",\"cdtl2Carrier\":\"CARRIER\",\"cdtl2Brand\":\"BRAND\",\"cdtl2Tech\":\"TECH\",\"cdtl2User\":\"1\",\"insertDate\":null,\"updateDate\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllCarrierDetails_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getAllCarrierDetails();
        Response response = retailStoreAdminResource.getAllCarrierDetails();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1403-Unable to get all Carrier Detail\"}", response.getEntity().toString());
    }

    @Test
    public void testGetTpNormStats() throws TracfoneOneException {
        TFOneRetailTpAdminSearchResults tfOneRetailTpAdminSearchResults = new TFOneRetailTpAdminSearchResults();
        tfOneRetailTpAdminSearchResults.setCount("100");
        tfOneRetailTpAdminSearchResults.setLastUpdateDate("2020-08-07");
        tfOneRetailTpAdminSearchResults.setUpdatedStoreCount("20");
        tfOneRetailTpAdminSearchResults.setUpdatedZipCount("25");
        when(tracfoneOneRetailAdminAction.getTpNormStats()).thenReturn(tfOneRetailTpAdminSearchResults);
        Response response = retailStoreAdminResource.getTpNormStats();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"tfOneRetailTpNorms\":[],\"count\":\"100\",\"startIndex\":null,\"endIndex\":null,\"lastUpdateDate\":\"2020-08-07\",\"updatedZipCount\":\"25\",\"updatedStoreCount\":\"20\"}", response.getEntity().toString());

    }

    @Test
    public void testGetTpNormStats_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).getTpNormStats();
        Response response = retailStoreAdminResource.getTpNormStats();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1433-Unable to get TP Norm Stats\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchTpNorm() throws TracfoneOneException {
        TFOneRetailTpAdminSearchResults tfOneRetailTpAdminSearchResults = new TFOneRetailTpAdminSearchResults();
        tfOneRetailTpAdminSearchResults.setCount("100");
        tfOneRetailTpAdminSearchResults.setStartIndex("1");
        tfOneRetailTpAdminSearchResults.setEndIndex("100");
        tfOneRetailTpAdminSearchResults.setUpdatedStoreCount("20");
        tfOneRetailTpAdminSearchResults.setUpdatedZipCount("25");

        TracfoneOneRetailTpAdminSearchModel tracfoneOneRetailTpAdminSearchModel = new TracfoneOneRetailTpAdminSearchModel();
        tracfoneOneRetailTpAdminSearchModel.setObjIds("1000");
        tracfoneOneRetailTpAdminSearchModel.setCarrierDetails("DETAILS");
        tracfoneOneRetailTpAdminSearchModel.setCoverage("GOOD");
        tracfoneOneRetailTpAdminSearchModel.setCoverageNotes("NOTE");
        tracfoneOneRetailTpAdminSearchModel.setStates("NY");
        tracfoneOneRetailTpAdminSearchModel.setStartIndex("1");
        tracfoneOneRetailTpAdminSearchModel.setEndIndex("10");
        tracfoneOneRetailTpAdminSearchModel.setZipCodes("33101");
        when(tracfoneOneRetailAdminAction.searchTpNorm(any())).thenReturn(tfOneRetailTpAdminSearchResults);
        Response response = retailStoreAdminResource.searchTpNorm(tracfoneOneRetailTpAdminSearchModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"tfOneRetailTpNorms\":[],\"count\":\"100\",\"startIndex\":\"1\",\"endIndex\":\"100\",\"lastUpdateDate\":null,\"updatedZipCount\":\"25\",\"updatedStoreCount\":\"20\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchTpNorm_whenException() throws TracfoneOneException {
        TracfoneOneRetailTpAdminSearchModel tracfoneOneRetailTpAdminSearchModel = new TracfoneOneRetailTpAdminSearchModel();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).searchTpNorm(any());
        Response response = retailStoreAdminResource.searchTpNorm(tracfoneOneRetailTpAdminSearchModel);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1422-Unable to search for TP Norms\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertTpNorms() throws TracfoneOneException {
        TracfoneOneRetailTpAdminSearchModel tracfoneOneRetailTpAdminSearchModel = new TracfoneOneRetailTpAdminSearchModel();
        tracfoneOneRetailTpAdminSearchModel.setObjIds("1000");
        tracfoneOneRetailTpAdminSearchModel.setCarrierDetails("DETAILS");
        tracfoneOneRetailTpAdminSearchModel.setCoverage("GOOD");
        tracfoneOneRetailTpAdminSearchModel.setCoverageNotes("NOTE");
        tracfoneOneRetailTpAdminSearchModel.setStates("NY");
        tracfoneOneRetailTpAdminSearchModel.setStartIndex("1");
        tracfoneOneRetailTpAdminSearchModel.setEndIndex("10");
        tracfoneOneRetailTpAdminSearchModel.setZipCodes("33101");
        when(tracfoneOneRetailStoreController.insertTpNorms(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.insertTpNorms(tracfoneOneRetailTpAdminSearchModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertTpNorms_whenException() throws TracfoneOneException {
        TracfoneOneRetailTpAdminSearchModel tracfoneOneRetailTpAdminSearchModel = new TracfoneOneRetailTpAdminSearchModel();
        doThrow(tracfoneOneException).when(tracfoneOneRetailStoreController).insertTpNorms(any(), anyInt());
        Response response = retailStoreAdminResource.insertTpNorms(tracfoneOneRetailTpAdminSearchModel);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1426-Unable to insert TP Norms\"}", response.getEntity().toString());
    }

    @Test
    public void testRunTraits() throws TracfoneOneException {
        when(tracfoneOneRetailAdminAction.runTraits(anyString(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.runTraits("parentid");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testRunTraits_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).runTraits(anyString(), anyInt());
        Response response = retailStoreAdminResource.runTraits("parentid");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE1425-Unable to Run Traits\"}", response.getEntity().toString());
    }

    @Test
    public void testRunTpNormTraits() throws TracfoneOneException {
        when(tracfoneOneRetailAdminAction.runTpNormTraits(anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.runTpNormTraits();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateRunTpNormTraits_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).runTpNormTraits(anyInt());
        Response response = retailStoreAdminResource.runTpNormTraits();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1432-Unable to Run TP Norm Traits\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateRank() throws TracfoneOneException {
        when(tracfoneOneRetailAdminAction.updateRank(any(), any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.updateRank("12", "12");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateRank_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).updateRank(any(), any(), anyInt());
        Response response = retailStoreAdminResource.updateRank("12", "12");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1443-Unable to update a Rank\"}", response.getEntity().toString());
    }

    @Test
    public void testRunTraitsSummary() throws TracfoneOneException {
        List<TFOneJobTask> jobTasks = new ArrayList<>();
        jobTasks.add(new TFOneJobTask("12", "", "COMPLETED", "", "21", ""));
        when(tracfoneOneRetailAdminAction.runTraitsSummary()).thenReturn(jobTasks);
        Response response = retailStoreAdminResource.runTraitsSummary();
        assertEquals("OutboundJaxrsResponse{status=200, reason=OK, hasEntity=true, closed=false, buffered=false}", response.toString());
    }

    @Test
    public void testRunTraitsSummary_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).runTraitsSummary();
        Response response = retailStoreAdminResource.runTraitsSummary();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE1444-Unable to get run Traits Summary\"}", response.getEntity().toString());
    }


    @Test
    public void testUpdateNewRank() throws TracfoneOneException {
        List<TracfoneOneRetailCarrierPrefDetail> carrierPrefDetails = new ArrayList<>();
        TracfoneOneRetailCarrierPrefDetail carrierPrefDetail = new TracfoneOneRetailCarrierPrefDetail();
        carrierPrefDetail.setObjId("12");
        carrierPrefDetail.setRank("2");
        carrierPrefDetails.add(carrierPrefDetail);
        when(tracfoneOneRetailAdminAction.updateNewRank(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = retailStoreAdminResource.updateNewRank(carrierPrefDetails);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateNewRank_whenException() throws TracfoneOneException {
        List<TracfoneOneRetailCarrierPrefDetail> carrierPrefDetails = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneOneRetailAdminAction).updateNewRank(any(), anyInt());
        Response response = retailStoreAdminResource.updateNewRank(carrierPrefDetails);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE1443-Unable to update a Rank\"}", response.getEntity().toString());
    }
}