package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOnePCRFTransaction;
import com.tracfone.service.model.request.TracfoneOneSearchAdditionalModel;
import com.tracfone.service.model.request.TracfoneonePaginationSearch;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOnePCRFTransSearchResult;
import com.tracfone.service.model.response.TFOnePCRFTransaction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOnePCRFTransActionTest {

    @InjectMocks
    private TracfoneOnePCRFTransAction action;
    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private ResultSet resultSet;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    private TFOneGeneralResponse tfOneGeneralResponse;
    public final String DBENV = "dbEnv";

    @Before
    public void setUp() throws Exception {
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

    @Test
    public void testViewThrottleTransAction() throws Exception {
        List<String> mdn = new ArrayList<>();
        List<String> min = new ArrayList<>();
        List<String> esn = new ArrayList<>();
        List<String> groupIdValue = new ArrayList<>();
        mdn.add("TEST");
        min.add("12345");
        esn.add("54332");
        groupIdValue.add("NULL");
        TracfoneonePaginationSearch paginationSearch = new TracfoneonePaginationSearch();
        paginationSearch.setEndIndex(200);
        paginationSearch.setStartIndex(0);
        List<TracfoneOneSearchAdditionalModel> searchColumns = new ArrayList<>();
        TracfoneOneSearchAdditionalModel addColumn = new TracfoneOneSearchAdditionalModel();
        addColumn.setSearchColumnName("mdn");
        addColumn.setSearchColumnType("string");
        addColumn.setSearchValues(mdn);
        addColumn.setSearchIsColumnNotIn(false);
        addColumn.setSearchIsColumnLike(false);
        TracfoneOneSearchAdditionalModel addColumn1 = new TracfoneOneSearchAdditionalModel();
        addColumn1.setSearchColumnName("min");
        addColumn1.setSearchColumnType("string");
        addColumn1.setSearchValues(min);
        addColumn1.setSearchIsColumnNotIn(false);
        addColumn1.setSearchIsColumnLike(false);
        TracfoneOneSearchAdditionalModel addColumn2 = new TracfoneOneSearchAdditionalModel();
        addColumn2.setSearchColumnName("groupId");
        addColumn2.setSearchColumnType("string");
        addColumn2.setSearchValues(groupIdValue);
        addColumn2.setSearchIsColumnNotIn(false);
        addColumn2.setSearchIsColumnLike(false);
        TracfoneOneSearchAdditionalModel addColumn3 = new TracfoneOneSearchAdditionalModel();
        addColumn3.setSearchColumnName("esn");
        addColumn3.setSearchColumnType("string");
        addColumn3.setSearchValues(esn);
        addColumn3.setSearchIsColumnNotIn(true);
        addColumn3.setSearchIsColumnLike(false);

        searchColumns.add(addColumn);
        searchColumns.add(addColumn1);
        searchColumns.add(addColumn2);
        searchColumns.add(addColumn3);
        TracfoneOnePCRFTransaction cRFTransaction = new TracfoneOnePCRFTransaction();
        cRFTransaction.setDbEnv(DBENV);
        cRFTransaction.setSearchColumns(searchColumns);
        cRFTransaction.setPaginationSearch(paginationSearch);
        cRFTransaction.setFromInsertTimestamp("12-01-2020");
        cRFTransaction.setToInsertTimestamp("12-30-2020");
        cRFTransaction.setFromUpdateTimestamp("06-01-2020");
        cRFTransaction.setToUpdateTimestamp("06-30-2020");
        cRFTransaction.setInstallDate("12-01-2020");
        cRFTransaction.setTtl("12-30-2020");
        cRFTransaction.setFutureTtl("06-01-2020");
        cRFTransaction.setBlackoutWaitDate("06-30-2020");
        cRFTransaction.setDateField1("06-01-2020");
        cRFTransaction.setRedemptionDate("06-30-2020");

        TFOnePCRFTransSearchResult cRFTransSearchResult = new TFOnePCRFTransSearchResult();
        List<TFOnePCRFTransaction> cRFTransactions = new ArrayList<>();
        TFOnePCRFTransaction cRFTransaction1 = new TFOnePCRFTransaction();
        cRFTransaction1.setActionType("ACTIion");
        cRFTransaction1.setAddonsFlag("flag");
        cRFTransaction1.setBlackoutWaitDate("2020/12/12");
        cRFTransaction1.setBrand("brand");
        cRFTransaction1.setEsn("ESN");
        cRFTransaction1.setGroupId("GROUPID");
        cRFTransaction1.setMin("MIN");
        cRFTransaction1.setCaseId("12");
        cRFTransaction1.setCharField1("12");
        cRFTransaction1.setCharField2("42");
        cRFTransaction1.setCharField3("41");
        cRFTransaction1.setContactObjId("21441");
        cRFTransaction1.setSubscriberId("15251");
        cRFTransaction1.setContentDeliveryFormat("THESH");
        cRFTransaction1.setConversionFactor("FACTOR");
        cRFTransaction1.setDataUsage("1234");
        cRFTransaction1.setDateField1("2020/12/12");
        cRFTransaction1.setDealerId("1414");
        cRFTransaction1.setDenomination("API");
        cRFTransaction1.setFutureTtl("2020/12/12");
        cRFTransaction1.setHiSpeedDataUsage("COS");
        cRFTransaction1.setImsi("ENTITLEMENT");
        cRFTransaction1.setMdn("ESN");
        cRFTransaction1.setOrderType("GROUPID");
        cRFTransaction1.setObjId("MIN");
        cRFTransaction1.setPartInstStatus("PARENT NAME");
        cRFTransaction1.setPcrfCos("POLICY NAME");
        cRFTransaction1.setPhoneManufacturer("PRIO");
        cRFTransaction1.setPhoneModel("FLAG");
        cRFTransaction1.setPosaFlag("RULE");
        cRFTransaction1.setProgramParameterId("STATUS");
        cRFTransaction1.setPropagateFlag("SUB ID");
        cRFTransaction1.setRatePlan("THESH");
        cRFTransaction1.setRcsEnableFlag("GROUP_TYPE");
        cRFTransaction1.setRedemptionDate("THROTTLE NUM");
        cRFTransaction1.setRetryCount("TYPE");
        cRFTransaction1.setServicePlanType("USAGE ID");
        cRFTransaction1.setSim("STATUS");
        cRFTransaction1.setSourceSystem("SUB ID");
        cRFTransaction1.setTtl("THESH");
        cRFTransaction1.setZipCode("GROUP_TYPE");
        cRFTransaction1.setInsertTimestamp("2020/12/12");
        cRFTransaction1.setUpdateTimestamp("2020/12/12");
        cRFTransaction1.setWebObjId("12456");
        cRFTransactions.add(cRFTransaction1);
        TracfoneonePaginationSearch tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
        tracfoneonePaginationSearch.setStartIndex(0);
        tracfoneonePaginationSearch.setEndIndex(100);
        tracfoneonePaginationSearch.setTotal(123);
        cRFTransSearchResult.setPaginationSearch(tracfoneonePaginationSearch);
        cRFTransSearchResult.setPcrfTransactions(cRFTransactions);

        when(stmt.executeQuery()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMY_DATA");
        TFOnePCRFTransSearchResult response = action.viewPcrfTransaction(cRFTransaction);
        assertEquals("TFOnePCRFTransSearchResult{paginationSearch=TracfoneonePaginationSearch{startIndex=0, endIndex=200, total=0}, pcrfTransactions=[TFOnePCRFTransaction{objId='DUMMY_DATA', min='DUMMY_DATA', esn='DUMMY_DATA', subscriberId='DUMMY_DATA', groupId='DUMMY_DATA', orderType='DUMMY_DATA', phoneManufacturer='DUMMY_DATA', actionType='DUMMY_DATA', sim='DUMMY_DATA', zipCode='DUMMY_DATA', servicePlanId='DUMMY_DATA', caseId='DUMMY_DATA', pcrfStatusCode='DUMMY_DATA', statusMessage='DUMMY_DATA', webObjId='DUMMY_DATA', brand='DUMMY_DATA', sourceSystem='DUMMY_DATA', template='DUMMY_DATA', ratePlan='DUMMY_DATA', blackoutWaitDate='DUMMY_DATA', retryCount='DUMMY_DATA', dataUsage='DUMMY_DATA', hiSpeedDataUsage='DUMMY_DATA', conversionFactor='DUMMY_DATA', dealerId='DUMMY_DATA', denomination='DUMMY_DATA', pcrfParentName='DUMMY_DATA', propagateFlag='DUMMY_DATA', servicePlanType='DUMMY_DATA', partInstStatus='DUMMY_DATA', phoneModel='DUMMY_DATA', contentDeliveryFormat='DUMMY_DATA', language='DUMMY_DATA', wfMacId='DUMMY_DATA', insertTimestamp='DUMMY_DATA', updateTimestamp='DUMMY_DATA', mdn='DUMMY_DATA', pcrfCos='DUMMY_DATA', ttl='DUMMY_DATA', futureTtl='DUMMY_DATA', redemptionDate='DUMMY_DATA', contactObjId='DUMMY_DATA', imsi='DUMMY_DATA', lifeLineId='DUMMY_DATA', installDate='DUMMY_DATA', programParameterId='DUMMY_DATA', vmbcCertificationFlag='DUMMY_DATA', charField1='DUMMY_DATA', charField2='DUMMY_DATA', charField3='DUMMY_DATA', dateField1='DUMMY_DATA', addonsFlag='DUMMY_DATA', rcsEnableFlag='DUMMY_DATA', posaFlag='DUMMY_DATA', unlockStatus='DUMMY_DATA'}]}", response.toString());
    }

    @Test
    public void testViewThrottleTransForElseBlocks() throws Exception {
        TracfoneOnePCRFTransaction cRFTransaction = new TracfoneOnePCRFTransaction();
        cRFTransaction.setDbEnv(DBENV);
        cRFTransaction.setFromInsertTimestamp("12-01-2020");
        cRFTransaction.setFromUpdateTimestamp("06-01-2020");

        when(stmt.executeQuery()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMY_DATA");
        TFOnePCRFTransSearchResult response = action.viewPcrfTransaction(cRFTransaction);
        assertEquals("TFOnePCRFTransSearchResult{paginationSearch=TracfoneonePaginationSearch{startIndex=1, endIndex=1000, total=0}, pcrfTransactions=[TFOnePCRFTransaction{objId='DUMMY_DATA', min='DUMMY_DATA', esn='DUMMY_DATA', subscriberId='DUMMY_DATA', groupId='DUMMY_DATA', orderType='DUMMY_DATA', phoneManufacturer='DUMMY_DATA', actionType='DUMMY_DATA', sim='DUMMY_DATA', zipCode='DUMMY_DATA', servicePlanId='DUMMY_DATA', caseId='DUMMY_DATA', pcrfStatusCode='DUMMY_DATA', statusMessage='DUMMY_DATA', webObjId='DUMMY_DATA', brand='DUMMY_DATA', sourceSystem='DUMMY_DATA', template='DUMMY_DATA', ratePlan='DUMMY_DATA', blackoutWaitDate='DUMMY_DATA', retryCount='DUMMY_DATA', dataUsage='DUMMY_DATA', hiSpeedDataUsage='DUMMY_DATA', conversionFactor='DUMMY_DATA', dealerId='DUMMY_DATA', denomination='DUMMY_DATA', pcrfParentName='DUMMY_DATA', propagateFlag='DUMMY_DATA', servicePlanType='DUMMY_DATA', partInstStatus='DUMMY_DATA', phoneModel='DUMMY_DATA', contentDeliveryFormat='DUMMY_DATA', language='DUMMY_DATA', wfMacId='DUMMY_DATA', insertTimestamp='DUMMY_DATA', updateTimestamp='DUMMY_DATA', mdn='DUMMY_DATA', pcrfCos='DUMMY_DATA', ttl='DUMMY_DATA', futureTtl='DUMMY_DATA', redemptionDate='DUMMY_DATA', contactObjId='DUMMY_DATA', imsi='DUMMY_DATA', lifeLineId='DUMMY_DATA', installDate='DUMMY_DATA', programParameterId='DUMMY_DATA', vmbcCertificationFlag='DUMMY_DATA', charField1='DUMMY_DATA', charField2='DUMMY_DATA', charField3='DUMMY_DATA', dateField1='DUMMY_DATA', addonsFlag='DUMMY_DATA', rcsEnableFlag='DUMMY_DATA', posaFlag='DUMMY_DATA', unlockStatus='DUMMY_DATA'}]}", response.toString());
    }

    @Test
    public void testViewThrottleTrans_withException() throws SQLException {
        List<String> values = new ArrayList<>();
        values.add("TEST");
        TracfoneonePaginationSearch paginationSearch = new TracfoneonePaginationSearch();
        paginationSearch.setEndIndex(200);
        paginationSearch.setStartIndex(0);
        List<TracfoneOneSearchAdditionalModel> searchColumns = new ArrayList<>();
        TracfoneOneSearchAdditionalModel addColumn = new TracfoneOneSearchAdditionalModel();
        addColumn.setSearchColumnName("mdn");
        addColumn.setSearchColumnType("string");
        addColumn.setSearchValues(values);
        addColumn.setSearchIsColumnNotIn(false);
        addColumn.setSearchIsColumnLike(false);

        searchColumns.add(addColumn);
        TracfoneOnePCRFTransaction cRFTransaction = new TracfoneOnePCRFTransaction();
        cRFTransaction.setDbEnv(DBENV);
        cRFTransaction.setSearchColumns(searchColumns);
        cRFTransaction.setPaginationSearch(paginationSearch);
        cRFTransaction.setFromInsertTimestamp("12-01-2020");
        cRFTransaction.setFromUpdateTimestamp("06-01-2020");

        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            action.viewPcrfTransaction(cRFTransaction);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}
