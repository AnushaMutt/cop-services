package com.tracfone.service.controller.retail;

import com.tracfone.ejb.entity.retail.session.CRtlTpNormFacadeLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.retail.request.TracfoneOneRetailLocation;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTraitSearchModel;
import com.tracfone.service.model.retail.response.TFOneRetailLocation;
import com.tracfone.service.model.retail.response.TFOneTraitDetail;
import com.tracfone.service.model.retail.response.TracfoneOneRetailAvailability;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_TRAIT_DETAILS;
import static com.tracfone.service.util.TracfoneOneConstantRetailStore.TRACFONE_GET_TRAIT_DETAILS_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneRetailTraitActionTest {
    @InjectMocks
    private TracfoneOneRetailTraitAction tracfoneOneRetailTraitAction;

    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @Mock
    private TracfoneAudit audit;

    @Mock
    EntityManager entityManager;

    @Mock
    Query query;

    @Mock
    CRtlTpNormFacadeLocal cRtlTpNormFacade;

    @Mock
    StoredProcedureQuery storedProcedureQuery;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "Success");
        tracfoneOneException = new TracfoneOneException("Error_Code", "Error_Message");
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
    }

    @Test
    public void testViewAvailability() throws Exception {
        Object[] object1 = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13"};
        List<Object[]> brands = new ArrayList<>();
        brands.add(object1);

        List<Object[]> brandMappings = new ArrayList<>();
        Object[] object2 = {"1 ", "2_", "3 ", "4_", "5 ", "6_"};
        brandMappings.add(object2);
        TracfoneOneRetailTraitSearchModel tracfoneOneSearchRetailTraitModel = new TracfoneOneRetailTraitSearchModel();
        tracfoneOneSearchRetailTraitModel.setBrand("100");
        tracfoneOneSearchRetailTraitModel.setParentId("15");
        tracfoneOneSearchRetailTraitModel.setZips("12345");
        tracfoneOneSearchRetailTraitModel.setObjIds("12345");

        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(brandMappings).thenReturn(brands);

        List<TracfoneOneRetailAvailability> response = tracfoneOneRetailTraitAction.viewAvailability(tracfoneOneSearchRetailTraitModel);
        assertEquals("[TracfoneOneRetailAvailability{retailer='1', storeName='2', storeNum='3', zip='4', state='5', brand='6', radius='7', carrierTechs={2__3_=8}}]", response.toString());
    }

    @Test
    public void testViewAvailability_CarrierDetailElseBlock() throws Exception {
        Object[] object1 = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13"};
        List<Object[]> brands = new ArrayList<>();
        brands.add(object1);

        List<Object[]> brandMappings = new ArrayList<>();
        Object[] object2 = {"1 ", "2", "3 ", "4", "5 ", "6"};
        brandMappings.add(object2);
        List<BigDecimal> brand = new ArrayList<>();
        brand.add(BigDecimal.valueOf(1));
        brand.add(BigDecimal.valueOf(2));
        brand.add(BigDecimal.valueOf(3));

        TracfoneOneRetailTraitSearchModel tracfoneOneSearchRetailTraitModel = new TracfoneOneRetailTraitSearchModel();
        tracfoneOneSearchRetailTraitModel.setParentId("15");
        tracfoneOneSearchRetailTraitModel.setZips("12345");
        tracfoneOneSearchRetailTraitModel.setObjIds("12345");

        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(brandMappings).thenReturn(brand).thenReturn(brands);

        List<TracfoneOneRetailAvailability> response = tracfoneOneRetailTraitAction.viewAvailability(tracfoneOneSearchRetailTraitModel);
        assertEquals("[TracfoneOneRetailAvailability{retailer='1', storeName='2', storeNum='3', zip='4', state='5', brand='6', radius='7', carrierTechs={2_3_=8}}]", response.toString());
    }

    @Test
    public void testViewAvailability_whenException() {
        TracfoneOneRetailTraitSearchModel tracfoneOneSearchRetailTraitModel = new TracfoneOneRetailTraitSearchModel();
        tracfoneOneSearchRetailTraitModel.setBrand("BRAND");
        tracfoneOneSearchRetailTraitModel.setParentId("15");
        tracfoneOneSearchRetailTraitModel.setZips("15234");
        doThrow(RuntimeException.class).when(cRtlTpNormFacade).getEntityManager();
        try {
            tracfoneOneRetailTraitAction.viewAvailability(tracfoneOneSearchRetailTraitModel);
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchRetailLocations() throws Exception {
        Object[] object1 = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13"};
        List<Object[]> brands = new ArrayList<>();
        brands.add(object1);
        TracfoneOneRetailTraitSearchModel tracfoneOneSearchRetailTraitModel = new TracfoneOneRetailTraitSearchModel();
        tracfoneOneSearchRetailTraitModel.setBrand("BRAND");
        tracfoneOneSearchRetailTraitModel.setCarrier("CARRIER");
        tracfoneOneSearchRetailTraitModel.setParentId("15");
        tracfoneOneSearchRetailTraitModel.setZips("12345");

        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(brands);

        List<TFOneRetailLocation> response = tracfoneOneRetailTraitAction.searchRetailLocations(tracfoneOneSearchRetailTraitModel);
        assertEquals("[TFOneRetailLocation{objId='1', masterId='2', parentId='3', storeName='4', storeNum='5', zip='7', brand='null', radius='8', state='6', lastUpdateDate='9'}]", response.toString());
    }

    @Test
    public void testSearchRetailLocations_whenException() {
        TracfoneOneRetailTraitSearchModel tracfoneOneSearchRetailTraitModel = new TracfoneOneRetailTraitSearchModel();
        tracfoneOneSearchRetailTraitModel.setBrand("BRAND");
        tracfoneOneSearchRetailTraitModel.setParentId("15");
        tracfoneOneSearchRetailTraitModel.setZips("15234");
        doThrow(RuntimeException.class).when(cRtlTpNormFacade).getEntityManager();
        try {
            tracfoneOneRetailTraitAction.searchRetailLocations(tracfoneOneSearchRetailTraitModel);
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testApproveTraits() {
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        when(query.getSingleResult()).thenReturn(0);
        TFOneGeneralResponse response = tracfoneOneRetailTraitAction.approveTraits("1", 318);
        assertEquals("Approved Traits for radius updates successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testCloseStores() throws Exception {
        List<Object[]> objects = new ArrayList<>();
        Object[] object = {"0"};
        objects.add(object);
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);

        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(objects);

        TFOneGeneralResponse response = tracfoneOneRetailTraitAction.closeStores("1,2,3", "1", 318);
        assertEquals("Stores closed successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testCloseStores_whenException() {
        doThrow(RuntimeException.class).when(cRtlTpNormFacade).getEntityManager();
        try {
            tracfoneOneRetailTraitAction.closeStores("1,2,3", "1", 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testReOpenStores() throws Exception {
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        TFOneGeneralResponse response = tracfoneOneRetailTraitAction.reopenStores("1,2,3", "1", 318);
        assertEquals("Stores reopened successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testReOpenStores_whenException() {
        doThrow(RuntimeException.class).when(cRtlTpNormFacade).getEntityManager();
        try {
            tracfoneOneRetailTraitAction.reopenStores("1,2,3", "1", 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetTraitDetails() throws Exception {
        List<TFOneTraitDetail> traitDetails = new ArrayList<>();
        TFOneTraitDetail traitDetail = new TFOneTraitDetail();
        traitDetail.setBrand("BRAND");
        traitDetail.setBufferZips("1000");
        traitDetail.setCarrier("CARRIER");
        traitDetail.setDplyd("1");
        traitDetail.setExtPercDplyd("1");
        traitDetail.setExtPercPopDplyd("1");
        traitDetail.setExtPopDplyd("1");
        traitDetail.setExtZipDplyd("1");
        traitDetail.setPercPopDplyd("1");
        traitDetail.setPercZipDplyd("1");
        traitDetail.setPop("1");
        traitDetail.setPopDplyd("1");
        traitDetail.setRadius("10");
        traitDetail.setTech("TECH");
        traitDetail.setTraits("10");
        traitDetail.setZipsDplyd("1");
        traitDetails.add(traitDetail);

        List<Object[]> objects = new ArrayList<>();
        Object[] object = {"CARRIER_0", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_0", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_1", "CARRIER_0", "CARRIER_1", "CARRIER_1"};
        objects.add(object);
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(objects);

        List<TFOneTraitDetail> response = tracfoneOneRetailTraitAction.getTraitDetails("1000");
        assertEquals("[TFOneTraitDetail{radius='CARRIER_0', traits='CARRIER_1', brand='CARRIER_0', carrier='CARRIER_1', tech='CARRIER_1', dplyd='CARRIER_1', bufferZips='CARRIER_1', pop='CARRIER_1', zipsDplyd='CARRIER_1', percZipDplyd='CARRIER_1', popDplyd='CARRIER_0', percPopDplyd='CARRIER_1', extZipDplyd='null', extPercDplyd='null', extPopDplyd='null', extPercPopDplyd='null'}]", response.toString());
    }

    @Test
    public void testGetTraitDetails_whenException() {
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        doThrow(RuntimeException.class).when(entityManager).createNativeQuery(anyString());
        try {
            tracfoneOneRetailTraitAction.getTraitDetails("1000");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_TRAIT_DETAILS, e.getErrorCode());
            assertEquals(TRACFONE_GET_TRAIT_DETAILS_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetRadius() throws Exception {
        List<String> radius = new ArrayList<>();
        radius.add("56");
        radius.add("75");
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(radius);
        List<String> response = tracfoneOneRetailTraitAction.getRadius();
        assertEquals("[56, 75]", response.toString());
    }

    @Test
    public void testGetRadius_whenException() {
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        doThrow(RuntimeException.class).when(entityManager).createNativeQuery(anyString());
        try {
            tracfoneOneRetailTraitAction.getRadius();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testAnalyseTraits() throws Exception {
        List<String> rslts = new ArrayList<>();
        rslts.add("rslts1");
        rslts.add("rslts2");
        TracfoneOneRetailTraitSearchModel retailTraitSearchModel = new TracfoneOneRetailTraitSearchModel();
        retailTraitSearchModel.setCarrier("BRAND");
        retailTraitSearchModel.setObjIds("1,2,3");
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(rslts);
        when(entityManager.createStoredProcedureQuery("C_RTL_TRAIT_SP_N")).thenReturn(storedProcedureQuery);
        when(storedProcedureQuery.registerStoredProcedureParameter(any(), any(), any())).thenReturn(storedProcedureQuery);
        when(storedProcedureQuery.setParameter(anyString(), any())).thenReturn(storedProcedureQuery).thenReturn(storedProcedureQuery);
        Map<String, String> response = tracfoneOneRetailTraitAction.analyseTraits(retailTraitSearchModel, 321);
        assertEquals("{1=[rslts1] [rslts2] , 2=[rslts1] [rslts2] , 3=[rslts1] [rslts2] }", response.toString());
    }

    @Test
    public void testAnalyseTraits_whenException() {
        TracfoneOneRetailTraitSearchModel retailTraitSearchModel = new TracfoneOneRetailTraitSearchModel();
        retailTraitSearchModel.setCarrier("BRAND");
        retailTraitSearchModel.setObjIds("1,2,3");
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        doThrow(RuntimeException.class).when(entityManager).createNativeQuery(anyString());
        try {
            tracfoneOneRetailTraitAction.analyseTraits(retailTraitSearchModel, 231);
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetTraitCountForLocation() throws Exception {
        Object count = 1;
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(1, "1")).thenReturn(query);
        when(query.getSingleResult()).thenReturn(count);
        int response = tracfoneOneRetailTraitAction.getTraitCountForLocation("1");
        assertEquals(1, response);
    }

    @Test
    public void testDeleteStores() throws Exception {
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        TFOneGeneralResponse response = tracfoneOneRetailTraitAction.deleteStores("3", 318);
        assertEquals("Stores deleted successfully.", response.getMessage());
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testDeleteStores_whenException() {
        doThrow(RuntimeException.class).when(cRtlTpNormFacade).getEntityManager();
        try {
            tracfoneOneRetailTraitAction.deleteStores("3", 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testAddUpdateRetailStore() throws Exception {
        TracfoneOneRetailLocation tracfoneOneRetailLocation = new TracfoneOneRetailLocation();
        tracfoneOneRetailLocation.setParentId("100");
        tracfoneOneRetailLocation.setStoreName("STORE_NAME");
        tracfoneOneRetailLocation.setStoreNum("100");
        tracfoneOneRetailLocation.setZip("10011");
        tracfoneOneRetailLocation.setRadius("100");
        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createStoredProcedureQuery("C_RTL_STORE_SP_N")).thenReturn(storedProcedureQuery);
        when(storedProcedureQuery.registerStoredProcedureParameter(any(), any(), any())).thenReturn(storedProcedureQuery);
        when(storedProcedureQuery.setParameter(anyString(), any())).thenReturn(storedProcedureQuery).thenReturn(storedProcedureQuery);
        boolean isSuccess = tracfoneOneRetailTraitAction.addUpdateRetailStore(tracfoneOneRetailLocation, 321);
        assertTrue(isSuccess);
    }

    @Test
    public void testAddUpdateRetailStore_whenException() {
        TracfoneOneRetailLocation tracfoneOneRetailLocation = new TracfoneOneRetailLocation();
        tracfoneOneRetailLocation.setParentId("100");
        tracfoneOneRetailLocation.setStoreName("STORE_NAME");
        tracfoneOneRetailLocation.setStoreNum("100");
        tracfoneOneRetailLocation.setZip("10011");
        tracfoneOneRetailLocation.setRadius("100");
        doThrow(RuntimeException.class).when(cRtlTpNormFacade).getEntityManager();
        try {
            tracfoneOneRetailTraitAction.addUpdateRetailStore(tracfoneOneRetailLocation, 231);
        } catch (Exception e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getMessage());
        }
    }

    @Test
    public void testSearchClosedStores() throws Exception {
        Object[] object1 = {"1", "2", "3", "4", "5", "6", "7", "8", "02-08-20"};
        List<Object[]> brands = new ArrayList<>();
        brands.add(object1);
        TracfoneOneRetailTraitSearchModel tracfoneOneSearchRetailTraitModel = new TracfoneOneRetailTraitSearchModel();
        tracfoneOneSearchRetailTraitModel.setBrand("BRAND");
        tracfoneOneSearchRetailTraitModel.setCarrier("CARRIER");
        tracfoneOneSearchRetailTraitModel.setParentId("15");
        tracfoneOneSearchRetailTraitModel.setZips("12345");
        tracfoneOneSearchRetailTraitModel.setFromDate("02-02-20");
        tracfoneOneSearchRetailTraitModel.setToDate("02-08-20");

        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(brands);

        List<TFOneRetailLocation> response = tracfoneOneRetailTraitAction.searchClosedStores(tracfoneOneSearchRetailTraitModel);
        assertEquals("[TFOneRetailLocation{objId='1', masterId='2', parentId='3', storeName='4', storeNum='5', zip='7', brand='null', radius='8', state='6', lastUpdateDate='02-08-20'}]", response.toString());
    }

    @Test
    public void testSearchClosedStores_whenException() {
        TracfoneOneRetailTraitSearchModel tracfoneOneSearchRetailTraitModel = new TracfoneOneRetailTraitSearchModel();
        tracfoneOneSearchRetailTraitModel.setBrand("BRAND");
        tracfoneOneSearchRetailTraitModel.setParentId("15");
        tracfoneOneSearchRetailTraitModel.setZips("15234");
        doThrow(RuntimeException.class).when(cRtlTpNormFacade).getEntityManager();
        try {
            tracfoneOneRetailTraitAction.searchClosedStores(tracfoneOneSearchRetailTraitModel);
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testCountStores() throws Exception {
        List<Object[]> count = new ArrayList<>();
        Object[] object2 = {"1 ", "2"};
        count.add(object2);

        when(cRtlTpNormFacade.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(count);
        TFOneGeneralResponse response = tracfoneOneRetailTraitAction.countStores("1", 318);
        assertEquals("Success", response.getStatus());
    }

    @Test
    public void testCountStores_whenException() {
        doThrow(RuntimeException.class).when(cRtlTpNormFacade).getEntityManager();
        try {
            tracfoneOneRetailTraitAction.countStores("1", 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}