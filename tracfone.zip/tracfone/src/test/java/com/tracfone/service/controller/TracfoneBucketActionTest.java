package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneBucket;
import com.tracfone.service.model.request.TracfoneOneBucketList;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucketTier;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildTier;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.response.TFOneBucket;
import com.tracfone.service.model.response.TFOneBucketList;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneRatePlan;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Testing the services that are associated with TracfoneBucketAction.
 *
 * @author Pritesh Singh
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneBucketActionTest {

    private static final String DBENV = "DBENV";
    @InjectMocks
    private TracfoneBucketAction tracfoneBucketAction;
    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private ResultSet resultSet;
    @Mock
    private TracfoneAudit audit;
    private TFOneGeneralResponse tfOneGeneralResponse;
    private List<String> idsToBeDeleted;
    private TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        idsToBeDeleted = new ArrayList<>();
        idsToBeDeleted.add("100");
        idsToBeDeleted.add("200");
        setSearchBucketModel();
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

    private void setSearchBucketModel() {
        List<String> names = new ArrayList<>();
        names.add("123");
        names.add("321");
        tracfoneOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tracfoneOneSearchBucketModel.setDbEnv(DBENV);
        tracfoneOneSearchBucketModel.setProfileIds(names);
        tracfoneOneSearchBucketModel.setRatePlanNames(names);
        tracfoneOneSearchBucketModel.setServicePlanIds(names);
    }

    @Test
    public void testInsertLegacyBucket() throws TracfoneOneException, SQLException {
        List<TracfoneOneBucket> tfBuckets = new ArrayList<>();
        TracfoneOneBucket tracfoneOneBucket = new TracfoneOneBucket();
        tracfoneOneBucket.setBucketId("BUCKET_ID");
        tracfoneOneBucket.setDbEnv("DBENV");
        tracfoneOneBucket.setRatePlan("RATE_PLAN");
        tracfoneOneBucket.setActiveFlag("Y");
        tracfoneOneBucket.setBucketDesc("BUCKET_DESC");
        tracfoneOneBucket.setBucketGroup("BUCKET_GROUP");
        tracfoneOneBucket.setBucketType("BUCKET_TYPE");
        tracfoneOneBucket.setMeasureUnit("UNIT");
        tracfoneOneBucket.setPriorityGroup("PRIORITY");
        tracfoneOneBucket.setSuiDisplayType("Y");
        tfBuckets.add(tracfoneOneBucket);
        when(resultSet.next()).thenReturn(false);
        int[] count = new int[]{1};
        when(stmt.executeBatch()).thenReturn(count);
        tfOneGeneralResponse = tracfoneBucketAction.insertLegacyBucket(tfBuckets, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfBuckets.get(0).getBucketId());
    }

    @Test
    public void testInsertLegacyBucket_whenException() throws TracfoneOneException, SQLException {
        // When NPE
        List<TracfoneOneBucket> tfBuckets = null;
        try {
            tfOneGeneralResponse = tracfoneBucketAction.insertLegacyBucket(tfBuckets, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // When Duplicate Bucket exists
        tfBuckets = new ArrayList<>();
        TracfoneOneBucket tracfoneOneBucket = new TracfoneOneBucket();
        tracfoneOneBucket.setBucketId("BUCKET_ID");
        tracfoneOneBucket.setDbEnv(DBENV);
        tracfoneOneBucket.setRatePlan("RATE_PLAN");
        tracfoneOneBucket.setActiveFlag("Y");
        tfBuckets.add(tracfoneOneBucket);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString("BUCKET_ID")).thenReturn("BUCKET_ID");
        int[] count = new int[]{0};
        when(stmt.executeBatch()).thenReturn(count);
        tfOneGeneralResponse = tracfoneBucketAction.insertLegacyBucket(tfBuckets, 100);
        verify(stmt, never()).addBatch();
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfBuckets.get(0).getBucketId());

        // When SQL Exception in this method
        when(resultSet.next()).thenReturn(false);
        doThrow(SQLException.class).when(stmt).executeBatch();
        try {
            tfOneGeneralResponse = tracfoneBucketAction.insertLegacyBucket(tfBuckets, 100);
            fail("Throws TracfoneOneExcepton");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllBucketList() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyInt())).thenReturn("BUCKET_ID").thenReturn("BUCKET_DESC").thenReturn("Y").thenReturn("PARENT");
        List<TracfoneOneBucketList> bucketList = tracfoneBucketAction.getAllBucketList(DBENV);
        assertNotNull(bucketList);
        assertEquals(1, bucketList.size());
        assertEquals("[TracfoneOneBucketList{bucketId=BUCKET_ID, description=BUCKET_DESC, activeFlag=Y, delete=false, parentShortName=PARENT}]", bucketList.toString());
    }

    @Test
    public void testGetAllBucketList_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            List<TracfoneOneBucketList> bucketList = tracfoneBucketAction.getAllBucketList(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneBucketAction.getAllBucketList(DBENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteIgBucket() throws TracfoneOneException {
        tfOneGeneralResponse = tracfoneBucketAction.deleteIgBucket(DBENV, "RATE_PLAN", idsToBeDeleted, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), idsToBeDeleted.toString());
    }

    @Test
    public void testDeleteIgBucket_withException() throws TracfoneOneException, SQLException {
        // When dbEnv is null
        try {
            tracfoneBucketAction.deleteIgBucket(null, "RATE_PLAN", idsToBeDeleted, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneBucketAction.deleteIgBucket(DBENV, "RATE_PLAN", idsToBeDeleted, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierProfileBuckets() throws TracfoneOneException {
        tfOneGeneralResponse = tracfoneBucketAction.deleteCarrierProfileBuckets(DBENV, idsToBeDeleted, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), idsToBeDeleted.toString());
    }

    @Test
    public void testDeleteCarrierProfileBuckets_withException() throws TracfoneOneException, SQLException {
        // When dbEnv is null
        try {
            tracfoneBucketAction.deleteCarrierProfileBuckets(null, idsToBeDeleted, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneBucketAction.deleteCarrierProfileBuckets(DBENV, idsToBeDeleted, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierProfileChildBuckets() throws TracfoneOneException {
        tfOneGeneralResponse = tracfoneBucketAction.deleteCarrierProfileChildBuckets(DBENV, idsToBeDeleted, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), idsToBeDeleted.toString());
    }

    @Test
    public void testDeleteCarrierProfileChildBuckets_withException() throws SQLException, TracfoneOneException {
        // When dbEnv is null
        try {
            tracfoneBucketAction.deleteCarrierProfileChildBuckets(null, idsToBeDeleted, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneBucketAction.deleteCarrierProfileChildBuckets(DBENV, idsToBeDeleted, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateIgBucket() throws TracfoneOneException {
        TracfoneOneBucket igBucket = new TracfoneOneBucket();
        igBucket.setDbEnv(DBENV);
        igBucket.setBucketId("BUCKET_ID");
        igBucket.setRatePlan("RATE_PLAN");
        igBucket.setActiveFlag("N");
        igBucket.setBucketDesc("BUCKET_DESC");
        igBucket.setBucketGroup("BUCKET_GROUP");
        igBucket.setBucketType("BUCKET_TYPE");
        igBucket.setMeasureUnit("UNIT");
        igBucket.setPriorityGroup("PRIORITY");
        igBucket.setSuiDisplayType("Y");
        tfOneGeneralResponse = tracfoneBucketAction.updateIgBucket(igBucket, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), igBucket.getBucketId());
    }

    @Test
    public void testUpdateIgBucket_withException() throws TracfoneOneException, SQLException {
        // When dbEnv is null
        TracfoneOneBucket igBucket = new TracfoneOneBucket();
        try {
            tracfoneBucketAction.updateIgBucket(igBucket, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        igBucket.setDbEnv(DBENV);
        igBucket.setBucketId("BUCKET_ID");
        igBucket.setRatePlan("RATE_PLAN");
        igBucket.setActiveFlag("Y");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneBucketAction.updateIgBucket(igBucket, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierProfileBucket() throws TracfoneOneException {
        TracfoneOneCarrierProfileBucket bucket = new TracfoneOneCarrierProfileBucket();
        bucket.setObjectId("100");
        bucket.setDbEnv(DBENV);
        bucket.setBucketId("BUCKET_ID");
        bucket.setActiveFlag("Y");
        bucket.setProfileId("10");
        bucket.setAutoRenewValue("Y");
        bucket.setServicePlanId("20");
        bucket.setAutoRenewDay("DAY");
        bucket.setAutoRenewFlag("N");
        bucket.setAutoRenewFrequency("FREQUENCY");
        bucket.setUnitOfMeasure("UNIT");
        bucket.setPriority("1");
        bucket.setHideUbiFlag("Y");
        bucket.setSuiDisplayType("Y");
        bucket.setBucketValue("30");
        bucket.setBucketType("BUCKET_TYPE");
        bucket.setBucketRequirement("BUCKET_REQUIREMENT");
        bucket.setBucketGroup("BUCKET_GROUP");
        bucket.setBenefitType("BENEFIT_TYPE");
        tfOneGeneralResponse = tracfoneBucketAction.updateCarrierProfileBucket(bucket, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), bucket.getObjectId());
    }

    @Test
    public void testUpdateCarrierProfileBucket_withException() throws SQLException, TracfoneOneException {
        // When dbEnv is null
        TracfoneOneCarrierProfileBucket bucket = new TracfoneOneCarrierProfileBucket();
        bucket.setBucketId("BUCKET_ID");
        try {
            tracfoneBucketAction.updateCarrierProfileBucket(bucket, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        bucket.setDbEnv(DBENV);
        bucket.setBucketId("BUCKET_ID");
        bucket.setObjectId("100");
        bucket.setActiveFlag("Y");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneBucketAction.updateCarrierProfileBucket(bucket, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierProfileBucketTier() throws TracfoneOneException {
        TracfoneOneCarrierProfileBucketTier tier = new TracfoneOneCarrierProfileBucketTier();
        tier.setDbEnv(DBENV);
        tier.setObjId("100");
        tier.setCarrierProfileBucketsObjId("200");
        tier.setTierBehavior("TIER_BEHAVIOR1");
        tier.setUsageTierId("90");
        tier.setTierDescription("TIER_DESCRIPTION1");
        tier.setTierValue("80");
        tfOneGeneralResponse = tracfoneBucketAction.updateCarrierProfileBucketTier(tier, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tier.getObjId());
    }

    @Test
    public void testUpdateCarrierProfileBucketTier_withException() throws SQLException, TracfoneOneException {
        // When dbEnv is null
        TracfoneOneCarrierProfileBucketTier bucketTier = new TracfoneOneCarrierProfileBucketTier();
        bucketTier.setTierDescription("TIER_DESC_UPDATED");
        try {
            tracfoneBucketAction.updateCarrierProfileBucketTier(bucketTier, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        bucketTier.setDbEnv(DBENV);
        bucketTier.setObjId("100");
        bucketTier.setUsageTierId("100");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneBucketAction.updateCarrierProfileBucketTier(bucketTier, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierProfileBucketTier() throws TracfoneOneException {
        TracfoneOneCarrierProfileBucketTier tier = new TracfoneOneCarrierProfileBucketTier();
        tier.setDbEnv(DBENV);
        tier.setObjId("100");
        tier.setCarrierProfileBucketsObjId("200");
        tier.setTierBehavior("TIER_BEHAVIOR1");
        tier.setUsageTierId("90");
        tier.setTierDescription("TIER_DESCRIPTION1");
        tier.setTierValue("80");
        tfOneGeneralResponse = tracfoneBucketAction.deleteCarrierProfileBucketTier(tier, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tier.getObjId());
    }

    @Test
    public void testDeleteCarrierProfileBucketTier_withException() throws SQLException, TracfoneOneException {
        // When dbEnv is null
        TracfoneOneCarrierProfileBucketTier bucketTier = new TracfoneOneCarrierProfileBucketTier();
        bucketTier.setTierDescription("TIER_DESC_UPDATED");
        try {
            tracfoneBucketAction.deleteCarrierProfileBucketTier(bucketTier, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        bucketTier.setDbEnv(DBENV);
        bucketTier.setObjId("100");
        bucketTier.setUsageTierId("100");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneBucketAction.deleteCarrierProfileBucketTier(bucketTier, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchIgBuckets() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("BUCKET_ID").thenReturn("UNIT").thenReturn("BUCKET_DESC").thenReturn("BUCKET_TYPE").
                thenReturn("RATE_PLAN").thenReturn("Y").thenReturn("SUI").thenReturn("GROUP").thenReturn("PRIORITY");
        List<TFOneBucket> igBuckets = tracfoneBucketAction.searchIgBuckets(tracfoneOneSearchBucketModel);
        assertNotNull(igBuckets);
        assertEquals(1, igBuckets.size());
        assertEquals("[TFOneBucket{bucketId=BUCKET_ID, activeFlag=Y, measureUnit=UNIT, bucketDesc=BUCKET_DESC, bucketType=BUCKET_TYPE, ratePlan=RATE_PLAN, suiDisplayType=SUI, bucketGroup=GROUP, priorityGroup=PRIORITY, tfOneBucketList=null, bucketIdConfigurations=null, carrierProfileBuckets=null, carrierProfileChildBuckets=null}]", igBuckets.toString());
    }

    @Test
    public void testSearchIgBuckets_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneBucketAction.searchIgBuckets(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneBucketAction.searchIgBuckets(tracfoneOneSearchBucketModel);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierProfileBuckets() throws SQLException, TracfoneOneException {
        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("100");
        List<TFOneCarrierProfileBucket> carrierProfileBuckets = tracfoneBucketAction.searchCarrierProfileBuckets(tracfoneOneSearchBucketModel);
        assertNotNull(carrierProfileBuckets);
        assertEquals(1, carrierProfileBuckets.size());
        assertEquals("[TFOneCarrierProfileBucket{objid=100, profileId=100, bucketId=100, servicePlanId=100, activeFlag=100, unitOfMeasure=100, bucketType=100, bucketGroup=100, bucketRequirement=100, autoRenewFlag=100,autoRenewFrequency=100, autoRenewValue=100, autoRenewDay=100, benefitType=100, bucketValue=100, suiDisplayType=100, priority=100, hideUbiFlag=100, tfOneCarrierProfileBucketTiers=[TFOneCarrierProfileBucketTier{objId=100, carrierProfileBucketsObjId=100, usageTierId=100, tierDescription=100, tierValue=100, tierBehavior=100}]}]", carrierProfileBuckets.toString());
    }

    @Test
    public void testSearchCarrierProfileBuckets_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneBucketAction.searchCarrierProfileBuckets(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneBucketAction.searchCarrierProfileBuckets(tracfoneOneSearchBucketModel);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierProfileChildBuckets() throws SQLException, TracfoneOneException {
        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("100");
        List<TFOneCarrierProfileChildBucket> carrierProfileChildBuckets = tracfoneBucketAction.searchCarrierProfileChildBuckets(tracfoneOneSearchBucketModel);
        assertNotNull(carrierProfileChildBuckets);
        assertEquals(1, carrierProfileChildBuckets.size());
        assertEquals("[TFOneCarrierProfileChildBucket{objId=100, profileId=100, servicePlanId=100, childPlanId=100, bucketId=100, activeFlag=100, unitOfMeasure=100, bucketType=100, bucketGroup=100, bucketRequirement=100, autoRenewFlag=100, autoRenewFrequency=100, autoRenewValue=100, autoRenewDay=100, benefitType=100, bucketValue=100, priority=100, hideUbiFlag=100, tfOneCarrierProfileChildTiers=[TFOneCarrierProfileChildTier{objId=100, carrierProfileChildObjId=100, usageTierId=100, tierDescription=100, tierValue=100, tierBehavior=100}]}]", carrierProfileChildBuckets.toString());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneBucketAction.searchCarrierProfileChildBuckets(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneBucketAction.searchCarrierProfileChildBuckets(tracfoneOneSearchBucketModel);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierProfileChildBucket() throws TracfoneOneException {
        TracfoneOneCarrierProfileChildBucket bucket = new TracfoneOneCarrierProfileChildBucket();
        bucket.setObjId("100");
        bucket.setDbEnv(DBENV);
        bucket.setBucketId("BUCKET_ID");
        bucket.setActiveFlag("Y");
        bucket.setProfileId("10");
        bucket.setAutoRenewValue("Y");
        bucket.setServicePlanId("20");
        bucket.setAutoRenewDay("DAY");
        bucket.setAutoRenewFlag("N");
        bucket.setAutoRenewFrequency("FREQUENCY");
        bucket.setUnitOfMeasure("UNIT");
        bucket.setPriority("1");
        bucket.setChildPlanId("100");
        bucket.setHideUbiFlag("Y");
        bucket.setBucketValue("30");
        bucket.setBucketType("BUCKET_TYPE");
        bucket.setBucketRequirement("BUCKET_REQUIREMENT");
        bucket.setBucketGroup("BUCKET_GROUP");
        bucket.setBenefitType("BENEFIT_TYPE");
        tfOneGeneralResponse = tracfoneBucketAction.updateCarrierProfileChildBucket(bucket, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), bucket.getObjId());
    }

    @Test
    public void testUpdateCarrierProfileChildBucket_withException() throws SQLException, TracfoneOneException {
        // When dbEnv is null
        TracfoneOneCarrierProfileChildBucket bucket = new TracfoneOneCarrierProfileChildBucket();
        bucket.setBucketId("BUCKET_ID");
        try {
            tracfoneBucketAction.updateCarrierProfileChildBucket(bucket, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        bucket.setDbEnv(DBENV);
        bucket.setBucketId("BUCKET_ID");
        bucket.setActiveFlag("Y");
        bucket.setObjId("100");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneBucketAction.updateCarrierProfileChildBucket(bucket, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierProfileBucket() throws Exception {
        List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileBucket tracfoneOneCarrierProfileBucket = new TracfoneOneCarrierProfileBucket();
        tracfoneOneCarrierProfileBucket.setBucketId("BUCKET_ID");
        tracfoneOneCarrierProfileBucket.setDbEnv(DBENV);
        tracfoneOneCarrierProfileBucket.setActiveFlag("Y");
        tracfoneOneCarrierProfileBucket.setProfileId("10");
        tracfoneOneCarrierProfileBucket.setAutoRenewValue("Y");
        tracfoneOneCarrierProfileBucket.setServicePlanId("20");
        tracfoneOneCarrierProfileBucket.setAutoRenewDay("DAY");
        tracfoneOneCarrierProfileBucket.setAutoRenewFlag("N");
        tracfoneOneCarrierProfileBucket.setAutoRenewFrequency("FREQUENCY");
        tracfoneOneCarrierProfileBucket.setUnitOfMeasure("UNIT");
        tracfoneOneCarrierProfileBucket.setPriority("1");
        tracfoneOneCarrierProfileBucket.setHideUbiFlag("Y");
        tracfoneOneCarrierProfileBucket.setSuiDisplayType("Y");
        tracfoneOneCarrierProfileBucket.setBucketValue("30");
        tracfoneOneCarrierProfileBucket.setBucketType("BUCKET_TYPE");
        tracfoneOneCarrierProfileBucket.setBucketRequirement("BUCKET_REQUIREMENT");
        tracfoneOneCarrierProfileBucket.setBucketGroup("BUCKET_GROUP");
        tracfoneOneCarrierProfileBucket.setBenefitType("BENEFIT_TYPE");
        List<TracfoneOneCarrierProfileBucketTier> bucketTiers = new ArrayList<>();
        TracfoneOneCarrierProfileBucketTier tier = new TracfoneOneCarrierProfileBucketTier();
        tier.setTierBehavior("TIER_BEHAVIOR1");
        tier.setUsageTierId("90");
        tier.setTierDescription("TIER_DESCRIPTION1");
        tier.setTierValue("80");
        bucketTiers.add(tier);
        tier = new TracfoneOneCarrierProfileBucketTier();
        tier.setTierBehavior("TIER_BEHAVIOR2");
        tier.setUsageTierId("70");
        tier.setTierDescription("TIER_DESCRIPTION2");
        tier.setTierValue("60");
        bucketTiers.add(tier);
        tracfoneOneCarrierProfileBucket.setTracfoneOneCarrierProfileBucketTiers(bucketTiers);
        tfCarrierProfileBuckets.add(tracfoneOneCarrierProfileBucket);

        when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
                .thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
        when(resultSet.getString("CARRIER_PROFILE_BUCKETID_SEQ")).thenReturn("100");
        when(resultSet.getString("BUCKET_TIERID_SEQ")).thenReturn("10").thenReturn("20");

        List<TFOneCarrierProfileBucket> respnse = tracfoneBucketAction.insertCarrierProfileBuckets(tfCarrierProfileBuckets, 100);
        assertEquals("[TFOneCarrierProfileBucket{objid=100, profileId=10, bucketId=BUCKET_ID, servicePlanId=20, activeFlag=Y, unitOfMeasure=UNIT, bucketType=BUCKET_TYPE, bucketGroup=BUCKET_GROUP, bucketRequirement=BUCKET_REQUIREMENT, autoRenewFlag=N,autoRenewFrequency=FREQUENCY, autoRenewValue=Y, autoRenewDay=DAY, benefitType=BENEFIT_TYPE, bucketValue=30, suiDisplayType=Y, priority=1, hideUbiFlag=Y, tfOneCarrierProfileBucketTiers=[TFOneCarrierProfileBucketTier{objId=10, carrierProfileBucketsObjId=100, usageTierId=90, tierDescription=TIER_DESCRIPTION1, tierValue=80, tierBehavior=TIER_BEHAVIOR1}, TFOneCarrierProfileBucketTier{objId=20, carrierProfileBucketsObjId=100, usageTierId=70, tierDescription=TIER_DESCRIPTION2, tierValue=60, tierBehavior=TIER_BEHAVIOR2}]}]", respnse.toString());
    }

    @Test
    public void testInsertCarrierProfileBucket_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneBucketAction.insertCarrierProfileBuckets(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileBucket tracfoneOneCarrierProfileBucket = new TracfoneOneCarrierProfileBucket();
        tracfoneOneCarrierProfileBucket.setBucketId("1000");
        tracfoneOneCarrierProfileBucket.setDbEnv(DBENV);
        tracfoneOneCarrierProfileBucket.setObjectId("1000");
        tracfoneOneCarrierProfileBucket.setServicePlanId("1000");
        tracfoneOneCarrierProfileBucket.setProfileId("1000");
        tracfoneOneCarrierProfileBucket.setActiveFlag("Y");
        List<TracfoneOneCarrierProfileBucketTier> bucketTiers = new ArrayList<>();
        TracfoneOneCarrierProfileBucketTier tier = new TracfoneOneCarrierProfileBucketTier();
        tier.setUsageTierId("50");
        bucketTiers.add(tier);
        tracfoneOneCarrierProfileBucket.setTracfoneOneCarrierProfileBucketTiers(bucketTiers);
        tfCarrierProfileBuckets.add(tracfoneOneCarrierProfileBucket);
        when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
                .thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
        when(resultSet.getString("CARRIER_PROFILE_BUCKETID_SEQ")).thenReturn("100");
        doThrow(SQLException.class).when(stmt).execute();
        try {
            tracfoneBucketAction.insertCarrierProfileBuckets(tfCarrierProfileBuckets, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierProfileChildBucket() throws Exception {
        List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileChildBucket tracfoneOneCarrierProfileBucket = new TracfoneOneCarrierProfileChildBucket();
        tracfoneOneCarrierProfileBucket.setBucketId("BUCKET_ID");
        tracfoneOneCarrierProfileBucket.setDbEnv(DBENV);
        tracfoneOneCarrierProfileBucket.setActiveFlag("Y");
        tracfoneOneCarrierProfileBucket.setProfileId("10");
        tracfoneOneCarrierProfileBucket.setAutoRenewValue("Y");
        tracfoneOneCarrierProfileBucket.setServicePlanId("20");
        tracfoneOneCarrierProfileBucket.setAutoRenewDay("DAY");
        tracfoneOneCarrierProfileBucket.setAutoRenewFlag("N");
        tracfoneOneCarrierProfileBucket.setAutoRenewFrequency("FREQUENCY");
        tracfoneOneCarrierProfileBucket.setUnitOfMeasure("UNIT");
        tracfoneOneCarrierProfileBucket.setPriority("1");
        tracfoneOneCarrierProfileBucket.setHideUbiFlag("Y");
//        tracfoneOneCarrierProfileBucket.setSuiDisplayType("Y");
        tracfoneOneCarrierProfileBucket.setBucketValue("30");
        tracfoneOneCarrierProfileBucket.setBucketType("BUCKET_TYPE");
        tracfoneOneCarrierProfileBucket.setBucketRequirement("BUCKET_REQUIREMENT");
        tracfoneOneCarrierProfileBucket.setBucketGroup("BUCKET_GROUP");
        tracfoneOneCarrierProfileBucket.setBenefitType("BENEFIT_TYPE");
        List<TracfoneOneCarrierProfileChildTier> bucketTiers = new ArrayList<>();
        TracfoneOneCarrierProfileChildTier tier = new TracfoneOneCarrierProfileChildTier();
        tier.setTierBehavior("TIER_BEHAVIOR1");
        tier.setUsageTierId("90");
        tier.setTierDescription("TIER_DESCRIPTION1");
        tier.setTierValue("80");
        bucketTiers.add(tier);
        tier = new TracfoneOneCarrierProfileChildTier();
        tier.setTierBehavior("TIER_BEHAVIOR2");
        tier.setUsageTierId("70");
        tier.setTierDescription("TIER_DESCRIPTION2");
        tier.setTierValue("60");
        tracfoneOneCarrierProfileBucket.setTracfoneOneCarrierProfileChildTiers(bucketTiers);
        bucketTiers.add(tier);
        tracfoneOneCarrierProfileBucket.setTracfoneOneCarrierProfileChildTiers(bucketTiers);
        tfCarrierProfileBuckets.add(tracfoneOneCarrierProfileBucket);
        when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
                .thenReturn(true).thenReturn(false);
        when(resultSet.getString("CHILD_BUCKETID_SEQ")).thenReturn("100");
        when(resultSet.getString("CHILD_BUCKET_TIERID_SEQ")).thenReturn("10").thenReturn("20");
        List<TFOneCarrierProfileChildBucket> response = tracfoneBucketAction.insertCarrierProfileChildBuckets(tfCarrierProfileBuckets, 100);
        assertEquals("[TFOneCarrierProfileChildBucket{objId=100, profileId=10, servicePlanId=20, childPlanId=null, bucketId=BUCKET_ID, activeFlag=Y, unitOfMeasure=UNIT, bucketType=BUCKET_TYPE, bucketGroup=BUCKET_GROUP, bucketRequirement=BUCKET_REQUIREMENT, autoRenewFlag=N, autoRenewFrequency=FREQUENCY, autoRenewValue=Y, autoRenewDay=DAY, benefitType=BENEFIT_TYPE, bucketValue=30, priority=1, hideUbiFlag=Y, tfOneCarrierProfileChildTiers=[TFOneCarrierProfileChildTier{objId=10, carrierProfileChildObjId=100, usageTierId=90, tierDescription=TIER_DESCRIPTION1, tierValue=80, tierBehavior=TIER_BEHAVIOR1}, TFOneCarrierProfileChildTier{objId=20, carrierProfileChildObjId=100, usageTierId=70, tierDescription=TIER_DESCRIPTION2, tierValue=60, tierBehavior=TIER_BEHAVIOR2}]}]", response.toString());
    }

    @Test
    public void testInsertCarrierProfileChildBucket_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneBucketAction.insertCarrierProfileBuckets(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileChildBucket tracfoneOneCarrierProfileChildBucket = new TracfoneOneCarrierProfileChildBucket();
        tracfoneOneCarrierProfileChildBucket.setBucketId("1000");
        tracfoneOneCarrierProfileChildBucket.setDbEnv(DBENV);
        tracfoneOneCarrierProfileChildBucket.setServicePlanId("1000");
        tracfoneOneCarrierProfileChildBucket.setProfileId("1000");
        tracfoneOneCarrierProfileChildBucket.setActiveFlag("Y");
        List<TracfoneOneCarrierProfileChildTier> bucketTiers = new ArrayList<>();
        TracfoneOneCarrierProfileChildTier tier = new TracfoneOneCarrierProfileChildTier();
        tier.setUsageTierId("50");
        bucketTiers.add(tier);
        tfCarrierProfileBuckets.add(tracfoneOneCarrierProfileChildBucket);
        tracfoneOneCarrierProfileChildBucket.setTracfoneOneCarrierProfileChildTiers(bucketTiers);
        when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
        when(resultSet.getString("CHILD_BUCKETID_SEQ")).thenReturn("100");
        doThrow(SQLException.class).when(stmt).execute();
        try {
            tracfoneBucketAction.insertCarrierProfileChildBuckets(tfCarrierProfileBuckets, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierProfileChildBucketTier() throws TracfoneOneException {
        TracfoneOneCarrierProfileChildTier bucket = new TracfoneOneCarrierProfileChildTier();
        bucket.setObjId("100");
        bucket.setUsageTierId("100");
        bucket.setCarrierProfileChildObjId("100");
        bucket.setTierBehavior("TIER_BEHAVIOR");
        bucket.setTierValue("100");
        bucket.setTierDescription("TIER_DESCRIPTION");
        bucket.setDbEnv(DBENV);
        tfOneGeneralResponse = tracfoneBucketAction.updateCarrierProfileChildBucketTier(bucket, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), bucket.getObjId());
    }

    @Test
    public void testUpdateCarrierProfileChildBucketTier_withException() throws SQLException, TracfoneOneException {
        // When dbEnv is null
        try {
            tracfoneBucketAction.updateCarrierProfileChildBucketTier(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        TracfoneOneCarrierProfileChildTier bucket = new TracfoneOneCarrierProfileChildTier();
        bucket.setDbEnv(DBENV);
        bucket.setUsageTierId("100");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneBucketAction.updateCarrierProfileChildBucketTier(bucket, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierProfileChildBucketTier() throws TracfoneOneException {
        TracfoneOneCarrierProfileChildTier tfCarrierProfileChildTier = new TracfoneOneCarrierProfileChildTier();
        tfCarrierProfileChildTier.setDbEnv(DBENV);
        tfCarrierProfileChildTier.setObjId("100");
        tfOneGeneralResponse = tracfoneBucketAction.deleteCarrierProfileChildBucketTier(tfCarrierProfileChildTier, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfCarrierProfileChildTier.getObjId());
    }

    @Test
    public void testDeleteCarrierProfileChildBucketTier_withException() throws TracfoneOneException, SQLException {
        // When dbEnv is null
        try {
            tracfoneBucketAction.deleteCarrierProfileChildBucketTier(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        TracfoneOneCarrierProfileChildTier tfCarrierProfileChildTier = new TracfoneOneCarrierProfileChildTier();
        tfCarrierProfileChildTier.setDbEnv(DBENV);
        tfCarrierProfileChildTier.setTierValue("100");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneBucketAction.deleteCarrierProfileChildBucketTier(tfCarrierProfileChildTier, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteAllBucketsAndTiers() throws TracfoneOneException {
        List<String> profileIds = new ArrayList<>();
        profileIds.add("1000");
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add("1000");
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setDbEnv(DBENV);
        tfOneSearchBucketModel.setProfileIds(profileIds);
        tfOneSearchBucketModel.setServicePlanIds(servicePlanIds);
        tfOneSearchBucketModel.setOldProfileId("1001");

        tfOneGeneralResponse = tracfoneBucketAction.deleteAllBucketsAndTiers(tfOneSearchBucketModel, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfOneSearchBucketModel.getProfileIds().get(0));
    }

    @Test
    public void testDeleteAllBucketsAndTiers_withException() throws TracfoneOneException, SQLException {
        // When dbEnv is null
        try {
            tracfoneBucketAction.deleteAllBucketsAndTiers(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        List<String> profileIds = new ArrayList<>();
        profileIds.add("1000");
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add("1000");
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setProfileIds(profileIds);
        tfOneSearchBucketModel.setDbEnv(DBENV);
        tfOneSearchBucketModel.setServicePlanIds(servicePlanIds);
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneBucketAction.deleteAllBucketsAndTiers(tfOneSearchBucketModel, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateAllBucketsWithProfileId() throws TracfoneOneException {
        List<String> profileIds = new ArrayList<>();
        profileIds.add("1000");
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add("1000");
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setDbEnv(DBENV);
        tfOneSearchBucketModel.setProfileIds(profileIds);
        tfOneSearchBucketModel.setServicePlanIds(servicePlanIds);
        tfOneSearchBucketModel.setOldProfileId("1001");

        tfOneGeneralResponse = tracfoneBucketAction.updateAllBucketsWithProfileId(tfOneSearchBucketModel, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfOneSearchBucketModel.getProfileIds().get(0));
    }

    @Test
    public void testUpdateAllBucketsWithProfileId_withException() throws SQLException, TracfoneOneException {
        // When dbEnv is null
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setOldProfileId("1001");
        try {
            tracfoneBucketAction.updateAllBucketsWithProfileId(tfOneSearchBucketModel, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        List<String> profileIds = new ArrayList<>();
        profileIds.add("1000");
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add("1000");
        tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setDbEnv(DBENV);
        tfOneSearchBucketModel.setProfileIds(profileIds);
        tfOneSearchBucketModel.setServicePlanIds(servicePlanIds);
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneBucketAction.updateAllBucketsWithProfileId(tfOneSearchBucketModel, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertBucketList() throws TracfoneOneException {
        Collection<TracfoneOneBucketList> bucketLists = new ArrayList<>();
        TracfoneOneBucketList bucketList = new TracfoneOneBucketList();
        bucketList.setDbEnv(DBENV);
        bucketList.setParentShortName("PARENT_NAME");
        bucketList.setActiveFlag("Y");
        bucketList.setDescription("DESCRIPTION");
        bucketList.setBucketId("1000");
        bucketLists.add(bucketList);
        tracfoneBucketAction.insertBucketList(bucketLists, 100);
    }

    @Test
    public void testInsertBucketList_whenException() throws TracfoneOneException, SQLException {
        // When NPE
        List<TracfoneOneBucketList> bucketLists = null;
        try {
            tracfoneBucketAction.insertBucketList(bucketLists, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // When Duplicate Bucket exists
        bucketLists = new ArrayList<>();
        TracfoneOneBucketList bucketList = new TracfoneOneBucketList();
        bucketList.setDbEnv(DBENV);
        bucketList.setParentShortName("PARENT_NAME");
        bucketList.setActiveFlag("Y");
        bucketList.setDescription("DESCRIPTION");
        bucketList.setBucketId("1000");
        bucketLists.add(bucketList);

        tracfoneBucketAction.insertBucketList(bucketLists, 100);
        verify(stmt, times(1)).addBatch();

        // When SQL Exception in this method
        doThrow(SQLException.class).when(stmt).executeBatch();
        try {
            tracfoneBucketAction.insertBucketList(bucketLists, 100);
            fail("Throws TracfoneOneExcepton");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetIgBucketRatePlans() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("BUCKET");
        List<TFOneRatePlan> response = tracfoneBucketAction.getIgBucketRatePlans(DBENV);
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("[TFOneRatePlan{objId=BUCKET, ratePlanName=BUCKET, privateNetwork=null, espidUpdate=null, espidNum=null, propagateFlagValue=null, allowMformApnRequestFlag=null, calculateDataUnitsFlag=null, thresholdsToTmo=null, hotspotBucketsFlag=null, tmoNextGenFlag=null, ratePlanProfile=[], carrierFeatures=null}]", response.toString());
    }

    @Test
    public void testGetIgBucketRatePlans_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            List<TFOneRatePlan> tfRatePlans = tracfoneBucketAction.getIgBucketRatePlans(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneBucketAction.getIgBucketRatePlans(DBENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetBucketListByBucketId() throws TracfoneOneException, SQLException {
        Set<String> bucketIds = new HashSet<>();
        bucketIds.add("BUCKET_1");
        bucketIds.add("BUCKET_2");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("BUCKET_ID");
        List<String> bucketList = tracfoneBucketAction.getBucketListByBucketIds(bucketIds, DBENV);
        assertNotNull(bucketList);
        assertEquals(1, bucketList.size());
        assertEquals("[BUCKET_ID]", bucketList.toString());
    }

    @Test
    public void testGetBucketListByBucketId_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            List<String> bucketList = tracfoneBucketAction.getBucketListByBucketIds(null, DBENV);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        Set<String> bucketIds = new HashSet<>();
        bucketIds.add("BUCKET_1");
        bucketIds.add("BUCKET_2");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneBucketAction.getBucketListByBucketIds(bucketIds, DBENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateBucketList() throws TracfoneOneException {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDescription("DESCRIPTION");
        tracfoneOneBucketList.setActiveFlag("Y");
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketList.setParentShortName("PARENT_SHORT_NAME");
        tfOneGeneralResponse = tracfoneBucketAction.updateBucketList(tracfoneOneBucketList, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tracfoneOneBucketList.getBucketId());
    }

    @Test
    public void testUpdateBucketList_withException() throws TracfoneOneException, SQLException {
        // When dbEnv is null
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        try {
            tracfoneBucketAction.updateBucketList(tracfoneOneBucketList, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketList.setBucketId("BUCKET_ID");
        tracfoneOneBucketList.setActiveFlag("Y");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneBucketAction.updateBucketList(tracfoneOneBucketList, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchBucketList() throws TracfoneOneException, SQLException {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDescription("DESCRIPTION");
        tracfoneOneBucketList.setActiveFlag("Y");
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketList.setParentShortName("PARENT_SHORT_NAME");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMY_DATA");
        List<TFOneBucketList> response = tracfoneBucketAction.searchBucketList(tracfoneOneBucketList);
        assertEquals("DUMMY_DATA", response.get(0).getBucketId());
    }

    @Test
    public void testSearchBucketList_withException() throws TracfoneOneException, SQLException {
        // When dbEnv is null
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        try {
            tracfoneBucketAction.searchBucketList(tracfoneOneBucketList);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketList.setBucketId("BUCKET_ID");
        tracfoneOneBucketList.setActiveFlag("Y");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneBucketAction.searchBucketList(tracfoneOneBucketList);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteBucketList() throws TracfoneOneException, SQLException {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDescription("DESCRIPTION");
        tracfoneOneBucketList.setActiveFlag("Y");
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketList.setParentShortName("PARENT_SHORT_NAME");
        tfOneGeneralResponse = tracfoneBucketAction.deleteBucketList(tracfoneOneBucketList, 100);
        assertEquals("Success", tfOneGeneralResponse.getStatus());
        assertEquals(tracfoneOneBucketList.getBucketId(), tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testDeleteBucketList_withException() throws TracfoneOneException, SQLException {
        // When dbEnv is null
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        try {
            tracfoneBucketAction.deleteBucketList(tracfoneOneBucketList, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketList.setBucketId("BUCKET_ID");
        tracfoneOneBucketList.setActiveFlag("Y");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneBucketAction.deleteBucketList(tracfoneOneBucketList, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testCheckBucketListDependencies() throws TracfoneOneException, SQLException {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDbEnv(DBENV);
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn(1L).when(resultSet).getLong(1);
        Long response = tracfoneBucketAction.checkBucketListDependencies(tracfoneOneBucketList);
        assertEquals("1", response.toString());
    }

    @Test
    public void testCheckBucketListDependencies_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        long count = 1l;
        try {
            count = tracfoneBucketAction.checkBucketListDependencies(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDbEnv(DBENV);
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneBucketAction.checkBucketListDependencies(tracfoneOneBucketList);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testCheckBucketIdExist() throws TracfoneOneException, SQLException {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDbEnv(DBENV);
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn(1).when(resultSet).getInt(1);
        boolean response = tracfoneBucketAction.validateBucketIdExist(tracfoneOneBucketList);
        assertTrue(response);
    }

    @Test
    public void testCheckBucketIdExist_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        boolean bucketIdExists = false;
        try {
            bucketIdExists = tracfoneBucketAction.validateBucketIdExist(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDbEnv(DBENV);
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneBucketAction.validateBucketIdExist(tracfoneOneBucketList);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    /**
     Junits forSprint 30
     ***/

    @Test
    public void testGetBucketDetails() throws TracfoneOneException, SQLException {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketList.setBucketId("TEST");
        tracfoneOneBucketList.setParentShortName("TMO");
        tracfoneOneBucketList.setProfileId("100");
        tracfoneOneBucketList.setServicePlanId("100");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMY_DATA");
        TFOneCarrierProfileBucket response = tracfoneBucketAction.getBucketDetails(tracfoneOneBucketList);
        assertEquals("DUMMY_DATA", response.getBucketId());
    }

    @Test
    public void testGetBucketDetails_whenException() throws TracfoneOneException, SQLException {
        // When dbEnv is null
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        try {
            tracfoneBucketAction.getBucketDetails(tracfoneOneBucketList);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketList.setBucketId("BUCKET_ID");
        tracfoneOneBucketList.setActiveFlag("Y");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneBucketAction.getBucketDetails(tracfoneOneBucketList);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

}