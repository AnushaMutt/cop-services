package com.tracfone.service;

import com.tracfone.service.controller.TracfoneBucketControllerLocal;
import com.tracfone.service.controller.TracfoneFeatureControllerLocal;
import com.tracfone.service.controller.TracfoneRatePlanControllerLocal;
import com.tracfone.service.controller.TracfoneServicePlanControllerLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneBucketList;
import com.tracfone.service.model.request.TracfoneOneCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneFeatureRequirement;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchServicePlanModel;
import com.tracfone.service.model.response.TFOneBusinessOrganization;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileBucketTier;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildTier;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneFeatureRequirement;
import com.tracfone.service.model.response.TFOneRPFeatureNameList;
import com.tracfone.service.model.response.TFOneRatePlan;
import com.tracfone.service.model.response.TFOneRatePlanExtensionConfig;
import com.tracfone.service.model.response.TFOneRatePlanExtensionLink;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneViewServicePlanResourceTest {

    public final String JSON = "application/json";
    public final String DBENV = "dbEnv";
    @InjectMocks
    private TracfoneOneViewServicePlanResource servicePlanResource;
    @Mock
    private TracfoneRatePlanControllerLocal tracfoneRatePlanController;
    @Mock
    private TracfoneBucketControllerLocal tracfoneBucketController;
    @Mock
    private TracfoneFeatureControllerLocal tracfoneFeatureController;
    @Mock
    private TracfoneServicePlanControllerLocal tracfoneServicePlanController;

    private TracfoneOneException tracfoneOneException;
    private TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel;
    private TracfoneOneSearchServicePlanModel tracfoneOneSearchCarrierFeatureModel;
    private TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel;

    @Before
    public void setUp() {
        initMocks(this);
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        tracfoneOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tracfoneOneSearchCarrierFeatureModel = new TracfoneOneSearchServicePlanModel();
    }

    @Test
    public void testGetAllCarrierNames() throws TracfoneOneException {
        List<String> carrierNames = new ArrayList<>();
        carrierNames.add("First");
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setProfileId("5401");
        tracfoneOneSearchPlanModel.setCarrierName("CARRIER_NAME");
        when(tracfoneRatePlanController.getAllCarrierNames(any())).thenReturn(carrierNames);
        Response response = servicePlanResource.getAllCarrierNames(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[\"First\"]", response.getEntity().toString());
    }

    @Test
    public void testGetAllCarrierNames_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getAllCarrierNames(any());
        Response response = servicePlanResource.getAllCarrierNames(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetServicePlansForCarrier() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        searchPlanModel.setDbEnv("local");
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tFOneCarrierServicePlan = new TFOneCarrierServicePlan();
        tFOneCarrierServicePlan.setServicePlanId("185");
        carrierServicePlans.add(tFOneCarrierServicePlan);
        when(tracfoneServicePlanController.getServicePlansForCarrier(any())).thenReturn(carrierServicePlans);
        Response response = servicePlanResource.getServicePlansForCarrier(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"carrierName\":null,\"servicePlanId\":\"185\",\"mktName\":null,\"description\":null,\"servicePlanPurchase\":null,\"parentName\":null,\"servicePlans\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetServicePlansForCarrier_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneServicePlanController).getServicePlansForCarrier(any());
        Response response = servicePlanResource.getServicePlansForCarrier(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierRatePlans() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        searchPlanModel.setDbEnv(DBENV);
        List<TFOneRatePlan> ratePlans = new ArrayList<>();
        TFOneRatePlan tfOneRatePlan = new TFOneRatePlan();
        tfOneRatePlan.setObjId("1000");
        tfOneRatePlan.setRatePlanName("RATE_PLAN_NAME");
        tfOneRatePlan.setTmoNextGenFlag("Y");
        ratePlans.add(tfOneRatePlan);
        when(tracfoneServicePlanController.getCarrierRatePlans(any())).thenReturn(ratePlans);
        Response response = servicePlanResource.getCarrierRatePlans(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"ratePlanName\":\"RATE_PLAN_NAME\",\"privateNetwork\":null,\"espidUpdate\":null,\"espidNum\":null,\"propagateFlagValue\":null,\"allowMformApnRequestFlag\":null,\"calculateDataUnitsFlag\":null,\"thresholdsToTmo\":null,\"hotspotBucketsFlag\":null,\"tmoNextGenFlag\":\"Y\",\"ratePlanProfile\":[],\"carrierFeatures\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierRatePlans_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneServicePlanController).getCarrierRatePlans(any());
        Response response = servicePlanResource.getCarrierRatePlans(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllBusinessOrgs() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        searchPlanModel.setDbEnv("local");
        List<TFOneBusinessOrganization> allBusOrgs = new ArrayList<>();
        TFOneBusinessOrganization tFOneBusinessOrganization = new TFOneBusinessOrganization();
        tFOneBusinessOrganization.setOrgId("1000");
        allBusOrgs.add(tFOneBusinessOrganization);
        when(tracfoneRatePlanController.getAllBusinessOrgs(any())).thenReturn(allBusOrgs);
        Response response = servicePlanResource.getAllBusinessOrgs(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"orgId\":\"1000\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllBusinessOrgs_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getAllBusinessOrgs(any());
        Response response = servicePlanResource.getAllBusinessOrgs(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllBucketList() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setCarrierName("CARRIER_NAME");
        tracfoneOneSearchPlanModel.setCarrierFeatureId("185");
        List<TracfoneOneBucketList> tracfoneOneBucketLists = new ArrayList<>();
        when(tracfoneBucketController.getAllBucketList(any())).thenReturn(tracfoneOneBucketLists);
        Response response = servicePlanResource.getAllBucketList(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
    }

    @Test
    public void testGetAllBucketList_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneBucketController).getAllBucketList(any());
        Response response = servicePlanResource.getAllBucketList(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllMasterFeatures() throws TracfoneOneException {
        List<TFOneRPFeatureNameList> features = new ArrayList<>();
        TFOneRPFeatureNameList tFOneRPFeatureNameList = new TFOneRPFeatureNameList();
        tFOneRPFeatureNameList.setFeatureName("feature");
        features.add(tFOneRPFeatureNameList);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setCarrierName("CARRIER_NAME");
        tracfoneOneSearchPlanModel.setCarrierFeatureId("185");
        when(tracfoneFeatureController.getAllMasterFeatures(any())).thenReturn(features);
        Response response = servicePlanResource.getAllMasterFeatures(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"featureName\":\"feature\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllMasterFeatures_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).getAllMasterFeatures(any());
        Response response = servicePlanResource.getAllMasterFeatures(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchServicePlans() throws TracfoneOneException {
        List<TFOneCarrierServicePlan> servicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneServicePlanView = new TFOneCarrierServicePlan();
        tfOneServicePlanView.setParentName("PARENT_NAME");
        tfOneServicePlanView.setCarrierName("CARRIER_NAME");
        tfOneServicePlanView.setServicePlanId("185");
        servicePlans.add(tfOneServicePlanView);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setServicePlanId("185");
        when(tracfoneServicePlanController.searchServicePlans(any(TracfoneOneSearchServicePlanModel.class))).thenReturn(servicePlans);
        Response response = servicePlanResource.searchServicePlans(tfServicePlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[TFOneCarrierServicePlan{carrierName='CARRIER_NAME', servicePlanId='185', mktName='null', description='null', servicePlanPurchase='null', parentName='PARENT_NAME', servicePlans=null}]", servicePlans.toString());
    }

    @Test
    public void testSearchServicePlans_whenException() throws TracfoneOneException {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        doThrow(tracfoneOneException).when(tracfoneServicePlanController).searchServicePlans(any(TracfoneOneSearchServicePlanModel.class));
        Response response = servicePlanResource.searchServicePlans(tfServicePlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierFeatureLinks() throws TracfoneOneException {
        List<TFOneCarrierFeature> tfOneCarrierFeatures = new ArrayList<>();
        TFOneCarrierFeature tfOneCarrierFeature = new TFOneCarrierFeature();
        tfOneCarrierFeature.setObjId("1");
        tfOneCarrierFeature.setxRatePlan("RATE_PLAN");
        List<TFOneRatePlanExtensionLink> tfOneRatePlanExtensionLinks = new ArrayList<>();
        TFOneRatePlanExtensionLink link = new TFOneRatePlanExtensionLink();
        link.setAncillaryCode("AL");
        link.setLineStatusCode("AL");
        link.setThrottleStatusCode("AL");
        link.setRatePlanExtensionId("AL");
        link.setCarrierFeatureId("1");
        link.setObjId("100");
        link.setProfileDescription("PROFILE_DESC");
        link.setProfileId("10");
        tfOneRatePlanExtensionLinks.add(link);
        tfOneCarrierFeature.setRpExtensionLinks(tfOneRatePlanExtensionLinks);
        tfOneCarrierFeatures.add(tfOneCarrierFeature);
        when(tracfoneServicePlanController.getCarrierFeatureLinks(any())).thenReturn(tfOneCarrierFeatures);

        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setBucketId("1000");
        tfServicePlanModel.setProfileId("5401");
        Response response = servicePlanResource.getCarrierFeatureLinks(tfServicePlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1\",\"dev\":null,\"xTechnology\":null,\"xRatePlan\":\"RATE_PLAN\",\"xVoicemail\":null,\"xVmCode\":null,\"xVmPackage\":null,\"xCallerId\":null,\"xIdCode\":null,\"xIdPackage\":null,\"xSms\":null,\"xSmsCode\":null,\"xSmsPackage\":null,\"xCallWaiting\":null,\"xCwCode\":null,\"xCwPackage\":null,\"xDigitalFeature\":null,\"xDigFeature\":null,\"xFeature2xCarrier\":null,\"xSmscNumber\":null,\"xData\":null,\"xRestrictedUse\":null,\"xSwitchBaseRate\":null,\"xFeatures2BusOrg\":null,\"xIsSwbCarrier\":null,\"xMpn\":null,\"xMpnCode\":null,\"xPoolName\":null,\"createMformIgFlag\":null,\"useCfExtensionFlag\":null,\"dataSaver\":null,\"dataSaverCode\":null,\"useRpExtensionFlag\":null,\"tmoNextGenFlag\":null,\"servicePlanId\":null,\"brand\":null,\"servicePlanCarrierFeature\":null,\"rpExtensionLinks\":[{\"objId\":\"100\",\"carrierFeatureId\":\"1\",\"childPlanId\":null,\"childPlanDescription\":null,\"ratePlanExtensionId\":\"AL\",\"lineStatusCode\":\"AL\",\"throttleStatusCode\":\"AL\",\"ancillaryCode\":\"AL\",\"profileId\":\"10\",\"profileDescription\":\"PROFILE_DESC\"}],\"xCarrierId\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierFeatureLinks_whenException() throws TracfoneOneException {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        doThrow(tracfoneOneException).when(tracfoneServicePlanController).getCarrierFeatureLinks(any());
        List<TracfoneOneCarrierFeature> carrierFeatures = new ArrayList<>();
        Response response = servicePlanResource.getCarrierFeatureLinks(tfServicePlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllProfileFeatures() throws TracfoneOneException {
        List<TFOneRatePlanExtensionConfig> profileFeatures = new ArrayList<>();
        TFOneRatePlanExtensionConfig profileFeature = new TFOneRatePlanExtensionConfig();
        profileFeature.setDbEnv(DBENV);
        profileFeature.setProfileId("1501");
        profileFeature.setFeatureName("FEATURE_NAME");
        profileFeatures.add(profileFeature);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setBucketId("1000");
        tfServicePlanModel.setProfileId("5401");
        when(tracfoneServicePlanController.getAllProfileFeatures(any())).thenReturn(profileFeatures);
        Response response = servicePlanResource.getAllProfileFeatures(tfServicePlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[TFOneRatePlanExtensionConfig{objid=null, profileId=1501, profileDescription=null, featureName=FEATURE_NAME, featureValue=null, featureRequirement=null, toggleFlag=null, notes=null, displaySUIFlag=null, restrictSUIFlag=null, rowNum=null, errorMessages={}, dbEnv=dbEnv}]", profileFeatures.toString());
    }

    @Test
    public void testGetAllProfileFeatures_whenException() throws TracfoneOneException {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        doThrow(tracfoneOneException).when(tracfoneServicePlanController).getAllProfileFeatures(any());
        Response response = servicePlanResource.getAllProfileFeatures(tfServicePlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileBuckets() throws TracfoneOneException {
        List<TFOneCarrierProfileBucket> tfOneCarrierProfileBuckets = new ArrayList<>();
        TFOneCarrierProfileBucket carrierProfileBucket = new TFOneCarrierProfileBucket();
        carrierProfileBucket.setObjid("1");
        carrierProfileBucket.setActiveFlag("Y");
        carrierProfileBucket.setBucketId("BUCKET_ID");
        List<TFOneCarrierProfileBucketTier> tfOneCarrierProfileBucketTiers = new ArrayList<>();
        TFOneCarrierProfileBucketTier carrierProfileBucketTier = new TFOneCarrierProfileBucketTier();
        carrierProfileBucketTier.setObjId("100");
        carrierProfileBucketTier.setUsageTierId("101");
        carrierProfileBucketTier.setTierBehavior("TIER_BEHAVIOR");
        carrierProfileBucketTier.setTierDescription("TIER_DESC");
        tfOneCarrierProfileBucketTiers.add(carrierProfileBucketTier);
        carrierProfileBucket.setTfOneCarrierProfileBucketTiers(tfOneCarrierProfileBucketTiers);
        tfOneCarrierProfileBuckets.add(carrierProfileBucket);
        when(tracfoneServicePlanController.searchCarrierProfileBuckets(any())).thenReturn(tfOneCarrierProfileBuckets);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setBucketId("1000");
        tfServicePlanModel.setProfileId("5401");
        Response response = servicePlanResource.searchCarrierProfileBuckets(tfServicePlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objid\":\"1\",\"profileId\":null,\"bucketId\":\"BUCKET_ID\",\"servicePlanId\":null,\"activeFlag\":\"Y\",\"unitOfMeasure\":null,\"bucketType\":null,\"bucketGroup\":null,\"bucketRequirement\":null,\"autoRenewFlag\":null,\"autoRenewFrequency\":null,\"autoRenewValue\":null,\"autoRenewDay\":null,\"benefitType\":null,\"bucketValue\":null,\"suiDisplayType\":null,\"priority\":null,\"hideUbiFlag\":null,\"tfOneCarrierProfileBucketTiers\":[{\"objId\":\"100\",\"carrierProfileBucketsObjId\":null,\"usageTierId\":\"101\",\"tierDescription\":\"TIER_DESC\",\"tierValue\":null,\"tierBehavior\":\"TIER_BEHAVIOR\"}]}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileBuckets_whenException() throws TracfoneOneException {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        doThrow(tracfoneOneException).when(tracfoneServicePlanController).searchCarrierProfileBuckets(any());
        Response response = servicePlanResource.searchCarrierProfileBuckets(tfServicePlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets() throws TracfoneOneException {
        List<TFOneCarrierProfileChildBucket> carrierProfileChildBuckets = new ArrayList<>();
        TFOneCarrierProfileChildBucket childBucket = new TFOneCarrierProfileChildBucket();
        childBucket.setObjId("1");
        childBucket.setActiveFlag("Y");
        childBucket.setBucketId("BUCKET_ID");
        List<TFOneCarrierProfileChildTier> carrierProfileChildTiers = new ArrayList<>();
        TFOneCarrierProfileChildTier childTier = new TFOneCarrierProfileChildTier();
        childTier.setObjId("100");
        childTier.setUsageTierId("101");
        childTier.setTierBehavior("TIER_BEHAVIOR");
        childTier.setTierDescription("TIER_DESC");
        carrierProfileChildTiers.add(childTier);
        childBucket.setTfOneCarrierProfileChildTiers(carrierProfileChildTiers);
        carrierProfileChildBuckets.add(childBucket);
        when(tracfoneServicePlanController.searchCarrierProfileChildBuckets(any())).thenReturn(carrierProfileChildBuckets);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setBucketId("1000");
        tfServicePlanModel.setProfileId("5401");
        Response response = servicePlanResource.searchCarrierProfileChildBuckets(tfServicePlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1\",\"profileId\":null,\"servicePlanId\":null,\"childPlanId\":null,\"bucketId\":\"BUCKET_ID\",\"activeFlag\":\"Y\",\"unitOfMeasure\":null,\"bucketType\":null,\"bucketGroup\":null,\"bucketRequirement\":null,\"autoRenewFlag\":null,\"autoRenewFrequency\":null,\"autoRenewValue\":null,\"autoRenewDay\":null,\"benefitType\":null,\"bucketValue\":null,\"priority\":null,\"hideUbiFlag\":null,\"tfOneCarrierProfileChildTiers\":[{\"objId\":\"100\",\"carrierProfileChildObjId\":null,\"usageTierId\":\"101\",\"tierDescription\":\"TIER_DESC\",\"tierValue\":null,\"tierBehavior\":\"TIER_BEHAVIOR\"}]}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets_whenException() throws TracfoneOneException {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneServicePlanController).searchCarrierProfileChildBuckets(any(TracfoneOneSearchServicePlanModel.class));
        Response response = servicePlanResource.searchCarrierProfileChildBuckets(tfServicePlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testViewServicePlanCarrierFeatures() throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        TFOneCarrierFeature tFOneCarrierFeature = new TFOneCarrierFeature();
        tFOneCarrierFeature.setxTechnology("CDMA");
        carrierFeatures.add(tFOneCarrierFeature);
        when(tracfoneServicePlanController.viewServicePlanCarrierFeatures(any())).thenReturn(carrierFeatures);
        Response response = servicePlanResource.viewServicePlanCarrierFeatures(tracfoneOneSearchCarrierFeatureModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[TFOneCarrierFeature{objId='null', dev='null', xTechnology='CDMA', xRatePlan='null', xVoicemail='null', xVmCode='null', xVmPackage='null', xCallerId='null', xIdCode='null', xIdPackage='null', xSms='null', xSmsCode='null', xSmsPackage='null', xCallWaiting='null', xCwCode='null', xCwPackage='null', xDigitalFeature='null', xDigFeature='null', xFeature2xCarrier='null', xSmscNumber='null', xData='null', xRestrictedUse='null', xSwitchBaseRate='null', xFeatures2BusOrg='null', xIsSwbCarrier='null', xMpn='null', xMpnCode='null', xPoolName='null', createMformIgFlag='null', useCfExtensionFlag='null', dataSaver='null', dataSaverCode='null', useRpExtensionFlag='null', tmoNextGenFlag='null', servicePlanId='null', brand='null', xCarrierId='null', servicePlanCarrierFeature=null, rpExtensionLinks=[]}]", carrierFeatures.toString());
    }

    @Test
    public void testViewServicePlanCarrierFeatures_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneServicePlanController).viewServicePlanCarrierFeatures(any());
        Response response = servicePlanResource.viewServicePlanCarrierFeatures(tracfoneOneSearchCarrierFeatureModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllFeatureRequirements() throws TracfoneOneException {
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfFeatureRequirement.setDbEnv(DBENV);
        List<TFOneFeatureRequirement> tfFeatureRequirements = new ArrayList<>();
        TFOneFeatureRequirement featureRequirement = new TFOneFeatureRequirement();
        featureRequirement.setDescription("DESCRIPTION");
        tfFeatureRequirements.add(featureRequirement);
        when(tracfoneFeatureController.getAllFeatureRequirements(any())).thenReturn(tfFeatureRequirements);
        Response response = servicePlanResource.getAllFeatureRequirements(tfFeatureRequirement);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"featureRequirement\":null,\"description\":\"DESCRIPTION\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllFeatureRequirements_whenException() throws TracfoneOneException {
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).getAllFeatureRequirements(any());
        Response response = servicePlanResource.getAllFeatureRequirements(tfFeatureRequirement);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }
}