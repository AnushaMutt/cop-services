package com.tracfone.service.controller;

import com.tracfone.ejb.entity.retail.session.CRtlArUsaMarketFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlArUsaPostalZipsFacadeLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneArUsaMarket;
import com.tracfone.service.model.request.TracfoneOneArUsaPostalZips;
import com.tracfone.service.model.request.TracfoneOneCarrier;
import com.tracfone.service.model.request.TracfoneOneCarrierGroup;
import com.tracfone.service.model.request.TracfoneOneCarrierPref;
import com.tracfone.service.model.request.TracfoneOneCarrierRule;
import com.tracfone.service.model.request.TracfoneOneCarrierSimPref;
import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;
import com.tracfone.service.model.request.TracfoneOneDataConfig;
import com.tracfone.service.model.request.TracfoneOneDataConfigMapping;
import com.tracfone.service.model.request.TracfoneOneGeoLoc;
import com.tracfone.service.model.request.TracfoneOneIgOrderType;
import com.tracfone.service.model.request.TracfoneOneNotCertifyModel;
import com.tracfone.service.model.request.TracfoneOneNpanxx2Carrierzones;
import com.tracfone.service.model.request.TracfoneOneOrderType;
import com.tracfone.service.model.request.TracfoneOneParent;
import com.tracfone.service.model.request.TracfoneOneThrottleFeature;
import com.tracfone.service.model.request.TracfoneOneThrottlePolicy;
import com.tracfone.service.model.request.TracfoneOneThrottleRule;
import com.tracfone.service.model.request.TracfoneOneTmoZipNgp;
import com.tracfone.service.model.request.TracfoneOneVerizonZipNPANXX;
import com.tracfone.service.model.response.TFOneArUsaPostalZips;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierGroup;
import com.tracfone.service.model.response.TFOneCarrierPref;
import com.tracfone.service.model.response.TFOneCarrierRule;
import com.tracfone.service.model.response.TFOneCarrierZones;
import com.tracfone.service.model.response.TFOneCarriersimpref;
import com.tracfone.service.model.response.TFOneCingularMrktInfo;
import com.tracfone.service.model.response.TFOneDataConfig;
import com.tracfone.service.model.response.TFOneDataConfigMapping;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneGeoLoc;
import com.tracfone.service.model.response.TFOneIgOrderType;
import com.tracfone.service.model.response.TFOneNotCertifyModel;
import com.tracfone.service.model.response.TFOneNpaNxx2CarrierZonesSearchResult;
import com.tracfone.service.model.response.TFOneNpanxx2Carrierzones;
import com.tracfone.service.model.response.TFOneOrderType;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOnePartClass;
import com.tracfone.service.model.response.TFOneThrottleFeature;
import com.tracfone.service.model.response.TFOneThrottlePolicy;
import com.tracfone.service.model.response.TFOneThrottleRule;
import com.tracfone.service.model.response.TFOneVerizonZipNPANXX;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Testing the services that are associated with TracfoneCarrierMaintenanceAction.
 *
 * @author Pritesh Singh
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneCarrierMaintenanceActionTest {

    private static final String DBENV = "DBENV";
    @InjectMocks
    private TracfoneCarrierMaintenanceAction tracfoneCarrierMaintenanceAction;
    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private ResultSet resultSet;
    @Mock
    CRtlArUsaPostalZipsFacadeLocal cRtlArUsaPostalZipsFacadeLocal;
    @Mock
    CRtlArUsaMarketFacadeLocal cRtlArUsaMarketFacadeLocal;
    @Mock
    EntityManager entityManager;
    @Mock
    Query query;
    private TFOneGeneralResponse tfOneGeneralResponse;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tfOneGeneralResponse = new TFOneGeneralResponse("Success", "100");
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

    @Test
    public void testSearchCarrierGroups() throws TracfoneOneException, SQLException {
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setCarrierName("CARRIER_NAME");
        tracfoneOneCarrierGroup.setCarrierGroup2Parent("CARRIER_GROUP_2PARENT");
        tracfoneOneCarrierGroup.setCarrierGroupId("1000");
        tracfoneOneCarrierGroup.setStatus("STATUS");
        tracfoneOneCarrierGroup.setDbEnv(DBENV);

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneCarrierGroup> response = tracfoneCarrierMaintenanceAction.searchCarrierGroups(tracfoneOneCarrierGroup);
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("[TFOneCarrierGroup{objId='DUMMY_DATA', carrierGroupId='DUMMY_DATA', carrierName='DUMMY_DATA', group2Address='DUMMY_DATA', status='DUMMY_DATA', carrierGroup2Parent='DUMMY_DATA', noAutoPart='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testSearchCarrierGroups_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchCarrierGroups(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setCarrierName("CARRIER_NAME");
        tracfoneOneCarrierGroup.setCarrierGroup2Parent("CARRIER_GROUP_2PARENT");
        tracfoneOneCarrierGroup.setCarrierGroupId("1000");
        tracfoneOneCarrierGroup.setStatus("STATUS");
        tracfoneOneCarrierGroup.setDbEnv(DBENV);
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchCarrierGroups(tracfoneOneCarrierGroup);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetOrderTypes() throws TracfoneOneException, SQLException {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setOrderType2xCarrier("CARRIER");
        tracfoneOneOrderType.setOrderType("ORDER_TYPE");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneOrderType> response = tracfoneCarrierMaintenanceAction.searchOrderTypes(tracfoneOneOrderType);
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("[TracfoneOneOrderType{, objId='DUMMY_DATA', orderType='DUMMY_DATA', npa='DUMMY_DATA', nxx='DUMMY_DATA', billCycle='DUMMY_DATA', dealerCode='DUMMY_DATA', ldAccountNum='DUMMY_DATA', marketCode='DUMMY_DATA', orderType2xTransProfile='DUMMY_DATA', orderType2xCarrier='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testGetOrderTypes_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchOrderTypes(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setOrderType2xCarrier("CARRIER");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchOrderTypes(tracfoneOneOrderType);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchParent() throws TracfoneOneException, SQLException {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        tracfoneOneParent.setDbEnv(DBENV);
        tracfoneOneParent.setParentId("1000");
        tracfoneOneParent.setParentName("PARENT_NAME");
        tracfoneOneParent.setStatus("STATUS");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneParent> response = tracfoneCarrierMaintenanceAction.searchParent(tracfoneOneParent);
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("[TFOneParent{objId='DUMMY_DATA', xParentName='DUMMY_DATA', parentId='DUMMY_DATA', status='DUMMY_DATA', holdAnalogDeac='DUMMY_DATA', holdDigitalDeac='DUMMY_DATA', parent2TempQueue='DUMMY_DATA', noInventory='DUMMY_DATA', vmAccessNum='DUMMY_DATA', autoPortIn='DUMMY_DATA', autoPortOut='DUMMY_DATA', noMsid='DUMMY_DATA', otaCarrier='DUMMY_DATA', otaEndDate='DUMMY_DATA', otaPsmsAddress='DUMMY_DATA', otaStartDate='DUMMY_DATA', nextAvailable='DUMMY_DATA', queueName='DUMMY_DATA', blockPortIn='DUMMY_DATA', meidCarrier='DUMMY_DATA', otaReact='DUMMY_DATA', aggCarrCode='DUMMY_DATA', suiRuleObjId='DUMMY_DATA', deactSimExpDays='DUMMY_DATA', overrideSmsAddress='DUMMY_DATA', triggerId='DUMMY_DATA', parentShortName='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testSearchParent_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchParent(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        tracfoneOneParent.setDbEnv(DBENV);
        tracfoneOneParent.setParentId("1000");
        tracfoneOneParent.setParentName("PARENT_NAME");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchParent(tracfoneOneParent);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrier() throws TracfoneOneException, SQLException {
        List<String> carrier2CarrierGroup = new ArrayList<>();
        carrier2CarrierGroup.add("CARRIER_2CARRIER_GROUP_1");
        carrier2CarrierGroup.add("CARRIER_2CARRIER_GROUP_2");
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setCarrierId("1000");
        tracfoneOneCarrier.setSubmarketName("MARKET_NAME");
        tracfoneOneCarrier.setStatus("STATUS");
        tracfoneOneCarrier.setCarrier2CarrierGroups(carrier2CarrierGroup);

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneCarrier> response = tracfoneCarrierMaintenanceAction.searchCarrier(tracfoneOneCarrier);
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("[TFOneCarrier{objId='DUMMY_DATA', carrierId='DUMMY_DATA', submarketName='DUMMY_DATA', submarketOf='DUMMY_DATA', city='DUMMY_DATA', state='DUMMY_DATA', tapereturnCharge='DUMMY_DATA', countryCode='DUMMY_DATA', activelinePercent='DUMMY_DATA', status='DUMMY_DATA', ldProvider='DUMMY_DATA', ldAccount='DUMMY_DATA', ldPicCode='DUMMY_DATA', ratePlan='DUMMY_DATA', dummyEsn='DUMMY_DATA', billDate='DUMMY_DATA', voiceMail='DUMMY_DATA', vmCode='DUMMY_DATA', vmPackage='DUMMY_DATA', callerId='DUMMY_DATA', idCode='DUMMY_DATA', idPackage='DUMMY_DATA', callWaiting='DUMMY_DATA', cwCode='DUMMY_DATA', cwPackage='DUMMY_DATA', reactTechnology='DUMMY_DATA', reactAnalog='DUMMY_DATA', actTechnology='DUMMY_DATA', actAnalog='DUMMY_DATA', digitalRatePlan='DUMMY_DATA', digitalFeature='DUMMY_DATA', prlPreLoaded='DUMMY_DATA', carrier2CarrierGroup='DUMMY_DATA', tapereturnAddr2Address='DUMMY_DATA', carrier2Provider='DUMMY_DATA', carrier2Address='DUMMY_DATA', carrier2Personality='DUMMY_DATA', carrier2Rule='DUMMY_DATA', carrier2CarrScript='DUMMY_DATA', specialMkt='DUMMY_DATA', newAnalogPlan='DUMMY_DATA', newDigitalPlan='DUMMY_DATA', sms='DUMMY_DATA', smsCode='DUMMY_DATA', smsPackage='DUMMY_DATA', vmSetUpLandLine='DUMMY_DATA', carrier2RulesCdma='DUMMY_DATA', carrier2RulesGsm='DUMMY_DATA', carrier2RulesTdma='DUMMY_DATA', dataService='DUMMY_DATA', automated='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testSearchCarrier_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchCarrier(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setCarrierId("1000");
        tracfoneOneCarrier.setSubmarketName("MARKET_NAME");
        tracfoneOneCarrier.setStatus("STATUS");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchCarrier(tracfoneOneCarrier);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchDataConfigMapping() throws TracfoneOneException, SQLException {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");
        tfDataConfigMapping.setPartClassObjId("1000");
        tfDataConfigMapping.setRatePlan("RATE_PLAN");
        tfDataConfigMapping.setDataConfigObjId("1000");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneDataConfigMapping> response = tracfoneCarrierMaintenanceAction.searchDataConfigMapping(tfDataConfigMapping);
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("[TFOneDataConfigMapping{parentId='DUMMY_DATA', partClassObjId='DUMMY_DATA', ratePlan='DUMMY_DATA', dataConfigObjId='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testSearchDataConfigMapping_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchDataConfigMapping(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");
        tfDataConfigMapping.setPartClassObjId("1000");
        tfDataConfigMapping.setRatePlan("RATE_PLAN");
        tfDataConfigMapping.setDataConfigObjId("1000");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchDataConfigMapping(tfDataConfigMapping);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertDataConfigMapping() throws Exception {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");
        tfDataConfigMapping.setPartClassObjId("1000");
        tfDataConfigMapping.setRatePlan("RATE_PLAN");
        tfDataConfigMapping.setDataConfigObjId("1000");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertDataConfigMapping(tfDataConfigMapping, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "1000");
    }

    @Test
    public void testInsertDataConfigMapping_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertDataConfigMapping(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");
        tfDataConfigMapping.setPartClassObjId("1000");
        tfDataConfigMapping.setRatePlan("RATE_PLAN");
        tfDataConfigMapping.setDataConfigObjId("1000");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.insertDataConfigMapping(tfDataConfigMapping, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testValidateDuplicateDataConfigMapping() throws TracfoneOneException, SQLException {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");
        tfDataConfigMapping.setPartClassObjId("1000");
        tfDataConfigMapping.setRatePlan("RATE_PLAN");
        tfDataConfigMapping.setDataConfigObjId("1000");
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn(1).when(resultSet).getInt(1);
        boolean response = tracfoneCarrierMaintenanceAction.validateDuplicateDataConfigMapping(tfDataConfigMapping);
        assertTrue(response);
    }

    @Test
    public void testValidateDuplicateDataConfigMapping_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        boolean dataConfigMappingExists;
        try {
            dataConfigMappingExists = tracfoneCarrierMaintenanceAction.validateDuplicateDataConfigMapping(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");
        tfDataConfigMapping.setPartClassObjId("1000");
        tfDataConfigMapping.setRatePlan("RATE_PLAN");
        tfDataConfigMapping.setDataConfigObjId("1000");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.validateDuplicateDataConfigMapping(tfDataConfigMapping);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteDataConfigMapping() throws Exception {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");
        tfDataConfigMapping.setPartClassObjId("1000");
        tfDataConfigMapping.setRatePlan("RATE_PLAN");
        tfDataConfigMapping.setDataConfigObjId("1000");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteDataConfigMapping(tfDataConfigMapping, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "1000");
    }

    @Test
    public void testDeleteDataConfigMapping_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.deleteDataConfigMapping(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");
        tfDataConfigMapping.setPartClassObjId("1000");
        tfDataConfigMapping.setRatePlan("RATE_PLAN");
        tfDataConfigMapping.setDataConfigObjId("1000");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.deleteDataConfigMapping(tfDataConfigMapping, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testUpdateDataConfigMapping() throws Exception {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");
        tfDataConfigMapping.setPartClassObjId("1000");
        tfDataConfigMapping.setRatePlan("RATE_PLAN");
        tfDataConfigMapping.setDataConfigObjId("1000");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateDataConfigMapping(tfDataConfigMapping, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "1000");
    }

    @Test
    public void testUpdateDataConfigMapping_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateDataConfigMapping(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");
        tfDataConfigMapping.setPartClassObjId("1000");
        tfDataConfigMapping.setRatePlan("RATE_PLAN");
        tfDataConfigMapping.setDataConfigObjId("1000");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.updateDataConfigMapping(tfDataConfigMapping, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateParent() throws Exception {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        tracfoneOneParent.setDbEnv(DBENV);
        tracfoneOneParent.setParentId("1000");
        tracfoneOneParent.setObjId("1000");
        tracfoneOneParent.setParentName("PARENT_NAME");
        tracfoneOneParent.setOtaStartDate(LocalDate.now().toString());
        tracfoneOneParent.setOtaEndDate(LocalDate.now().toString());
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateParent(tracfoneOneParent, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "1000");
    }

    @Test
    public void testUpdateParent_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateParent(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        tracfoneOneParent.setDbEnv(DBENV);
        tracfoneOneParent.setParentId("1000");
        tracfoneOneParent.setParentName("PARENT_NAME");
        tracfoneOneParent.setOtaStartDate(LocalDate.now().toString());
        tracfoneOneParent.setOtaEndDate(LocalDate.now().toString());
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.updateParent(tracfoneOneParent, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierGroup() throws Exception {
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setDbEnv(DBENV);
        tracfoneOneCarrierGroup.setObjId("1000");
        tracfoneOneCarrierGroup.setStatus("STATUS");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateCarrierGroup(tracfoneOneCarrierGroup, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "1000");
    }

    @Test
    public void testUpdateCarrierGroup_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateCarrierGroup(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setDbEnv(DBENV);
        tracfoneOneCarrierGroup.setObjId("1000");
        tracfoneOneCarrierGroup.setStatus("STATUS");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.updateCarrierGroup(tracfoneOneCarrierGroup, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrier() throws Exception {
        List<String> carrier2CarrierGroup = new ArrayList<>();
        carrier2CarrierGroup.add("CARRIER_GROUP_1");
        carrier2CarrierGroup.add("CARRIER_GROUP_2");
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setObjId("100");
        tracfoneOneCarrier.setStatus("STATUS");
        tracfoneOneCarrier.setBillDate("1902-01-02");
        tracfoneOneCarrier.setCarrier2CarrierGroups(carrier2CarrierGroup);
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateCarrier(tracfoneOneCarrier, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "100");
    }

    @Test
    public void testUpdateCarrier_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateCarrier(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs

        List<String> carrierGroups = new ArrayList<>();
        carrierGroups.add("CARRIER_GROUP_1");
        carrierGroups.add("CARRIER_GROUP_2");
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setObjId("100");
        tracfoneOneCarrier.setStatus("STATUS");
        tracfoneOneCarrier.setCarrier2CarrierGroups(carrierGroups);
        tracfoneOneCarrier.setBillDate("1999-01-03");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.updateCarrier(tracfoneOneCarrier, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierRule() throws Exception {
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        tracfoneOneCarrierRule.setDbEnv(DBENV);
        tracfoneOneCarrierRule.setObjId("1000");
        tracfoneOneCarrierRule.setTechnology("CDMA");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateCarrierRule(tracfoneOneCarrierRule, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "1000");
    }

    @Test
    public void testUpdateCarrierRule_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateCarrierRule(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        tracfoneOneCarrierRule.setDbEnv(DBENV);
        tracfoneOneCarrierRule.setObjId("1000");
        tracfoneOneCarrierRule.setTechnology("CDMA");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.updateCarrierRule(tracfoneOneCarrierRule, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateOrderType() throws Exception {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("1000");
        tracfoneOneOrderType.setNpa("NPA");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateOrderType(tracfoneOneOrderType, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "1000");
    }

    @Test
    public void testUpdateOrderType_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateOrderType(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("1000");
        tracfoneOneOrderType.setNpa("NPA");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.updateOrderType(tracfoneOneOrderType, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertParent() throws Exception {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        tracfoneOneParent.setDbEnv(DBENV);
        tracfoneOneParent.setParentId("1000");
        tracfoneOneParent.setParentName("PARENT_NAME");
        tracfoneOneParent.setOtaStartDate(LocalDate.now().toString());
        tracfoneOneParent.setOtaEndDate(LocalDate.now().toString());
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("1000");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertParent(tracfoneOneParent, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "1000");
    }

    @Test
    public void testInsertParent_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertParent(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        tracfoneOneParent.setDbEnv(DBENV);
        tracfoneOneParent.setParentId("1000");
        tracfoneOneParent.setParentName("PARENT_NAME");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.insertParent(tracfoneOneParent, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierGroups() throws Exception {
        List<TracfoneOneCarrierGroup> tracfoneOneCarrierGroups = new ArrayList<>();
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setDbEnv(DBENV);
        tracfoneOneCarrierGroup.setObjId("1000");
        tracfoneOneCarrierGroup.setStatus("STATUS");
        tracfoneOneCarrierGroups.add(tracfoneOneCarrierGroup);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("1000");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertCarrierGroups(tracfoneOneCarrierGroups, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "1000");
    }

    @Test
    public void testInsertCarrierGroups_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertCarrierGroups(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        List<TracfoneOneCarrierGroup> tracfoneOneCarrierGroups = new ArrayList<>();
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setDbEnv(DBENV);
        tracfoneOneCarrierGroup.setObjId("1000");
        tracfoneOneCarrierGroup.setStatus("STATUS");
        tracfoneOneCarrierGroups.add(tracfoneOneCarrierGroup);
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.insertCarrierGroups(tracfoneOneCarrierGroups, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarriers() throws Exception {
        List<String> carrier2CarrierGroup = new ArrayList<>();
        carrier2CarrierGroup.add("CARRIER_GROUP_1");
        carrier2CarrierGroup.add("CARRIER_GROUP_2");
        List<TracfoneOneCarrier> tracfoneOneCarriers = new ArrayList<>();
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setObjId("100");
        tracfoneOneCarrier.setStatus("STATUS");
        tracfoneOneCarrier.setBillDate("1119-01-02");
        tracfoneOneCarrier.setCarrier2CarrierGroups(carrier2CarrierGroup);
        tracfoneOneCarriers.add(tracfoneOneCarrier);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("1000");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertCarriers(tracfoneOneCarriers, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "1000");
    }

    @Test
    public void testInsertCarriers_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertCarriers(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        List<TracfoneOneCarrier> tracfoneOneCarriers = new ArrayList<>();
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setObjId("100");
        tracfoneOneCarrier.setStatus("STATUS");
        tracfoneOneCarriers.add(tracfoneOneCarrier);
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.insertCarriers(tracfoneOneCarriers, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierRule() throws Exception {
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        tracfoneOneCarrierRule.setDbEnv(DBENV);
        tracfoneOneCarrierRule.setObjId("1000");
        tracfoneOneCarrierRule.setTechnology("CDMA");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("1");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertCarrierRule(tracfoneOneCarrierRule, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "1");
    }

    @Test
    public void testInsertCarrierRule_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertCarrierRule(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        tracfoneOneCarrierRule.setDbEnv(DBENV);
        tracfoneOneCarrierRule.setObjId("1000");
        tracfoneOneCarrierRule.setTechnology("CDMA");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.insertCarrierRule(tracfoneOneCarrierRule, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertOrderType() throws Exception {
        List<TracfoneOneOrderType> tracfoneOneOrderTypes = new ArrayList<>();
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("1000");
        tracfoneOneOrderType.setNpa("NPA");
        tracfoneOneOrderTypes.add(tracfoneOneOrderType);

        List<TFOneOrderType> tfOneOrderTypes = new ArrayList<>();
        TFOneOrderType tfOneOrderType = new TFOneOrderType();
        tfOneOrderType.setObjId("1000");
        tfOneOrderType.setNpa("NPA");
        tfOneOrderTypes.add(tfOneOrderType);

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("1000");
        List<TFOneOrderType> response = tracfoneCarrierMaintenanceAction.insertOrderType(tracfoneOneOrderTypes, 100);
        assertEquals("[TracfoneOneOrderType{, objId='1000', orderType='null', npa='NPA', nxx='null', billCycle='null', dealerCode='null', ldAccountNum='null', marketCode='null', orderType2xTransProfile='null', orderType2xCarrier='null'}]", response.toString());
    }

    @Test
    public void testInsertOrderType_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertOrderType(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        List<TracfoneOneOrderType> tracfoneOneOrderTypes = new ArrayList<>();
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("1000");
        tracfoneOneOrderType.setNpa("NPA");
        tracfoneOneOrderTypes.add(tracfoneOneOrderType);
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.insertOrderType(tracfoneOneOrderTypes, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCarrierGroupIds() throws TracfoneOneException, SQLException {
        List<String> carrierGroupIds = new ArrayList<>();
        carrierGroupIds.add("ID_1");
        carrierGroupIds.add("ID_2");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<String> response = tracfoneCarrierMaintenanceAction.getCarrierGroupIds(DBENV, carrierGroupIds);
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("[DUMMY_DATA]", response.toString());
    }

    @Test
    public void testGetCarrierGroupIds_withException() throws TracfoneOneException, SQLException {
        List<String> carrierGroupIds = new ArrayList<>();
        carrierGroupIds.add("ID_1");
        carrierGroupIds.add("ID_2");
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.getCarrierGroupIds(null, carrierGroupIds);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.getCarrierGroupIds(DBENV, carrierGroupIds);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCarrierIds() throws TracfoneOneException, SQLException {
        List<String> carrierGroupIds = new ArrayList<>();
        carrierGroupIds.add("ID_1");
        carrierGroupIds.add("ID_2");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<String> response = tracfoneCarrierMaintenanceAction.getCarrierIds(DBENV, carrierGroupIds);
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("[DUMMY_DATA]", response.toString());
    }

    @Test
    public void testGetCarrierIds_withException() throws TracfoneOneException, SQLException {
        List<String> carrierGroupIds = new ArrayList<>();
        carrierGroupIds.add("ID_1");
        carrierGroupIds.add("ID_2");
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.getCarrierIds(null, carrierGroupIds);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.getCarrierIds(DBENV, carrierGroupIds);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testSearchCarrierRules() throws TracfoneOneException, SQLException {
        TracfoneOneCarrierRule tfOneCarrierRule = new TracfoneOneCarrierRule();
        tfOneCarrierRule.setDbEnv(DBENV);
        tfOneCarrierRule.setObjId("OBJID");
        tfOneCarrierRule.setCoolingPeriod("X_COOLING_PERIOD");
        tfOneCarrierRule.setEsnChangeDays("X_ESN_CHANGE_FLAG");
        tfOneCarrierRule.setLineExpireDays("X_LINE_EXPIRE_DAYS");
        tfOneCarrierRule.setLineReturnDays("X_LINE_RETURN_DAYS");
        tfOneCarrierRule.setCoolingAfterInsert("X_COOLING_AFTER_INSERT");
        tfOneCarrierRule.setNpaNxxFlag("X_NPA_NXX_FLAG");
        tfOneCarrierRule.setUsedLineExpireDays("X_USED_LINE_EXPIRE_DAYS");
        tfOneCarrierRule.setGsmGracePeriod("X_GSM_GRACE_PERIOD");
        tfOneCarrierRule.setTechnology("X_TECHNOLOGY");
        tfOneCarrierRule.setReserveOnSuspend("X_RESERVE_ON_SUSPEND");
        tfOneCarrierRule.setReservePeriod("X_RESERVE_PERIOD");
        tfOneCarrierRule.setDeacAfterGrace("X_DEAC_AFTER_GRACE");
        tfOneCarrierRule.setCancelSuspendDays("X_CANCEL_SUSPEND_DAYS");
        tfOneCarrierRule.setCancelSuspend("X_CANCEL_SUSPEND");
        tfOneCarrierRule.setBlockCreateActItem("X_BLOCK_CREATE_ACT_ITEM");
        tfOneCarrierRule.setAllow2gAct("X_ALLOW_2G_ACT");
        tfOneCarrierRule.setAllow2gReact("X_ALLOW_2G_REACT");
        tfOneCarrierRule.setAllowNonHdActs("ALLOW_NON_HD_ACTS");
        tfOneCarrierRule.setAllowNonHdReacts("ALLOW_NON_HD_REACTS");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneCarrierRule> response = tracfoneCarrierMaintenanceAction.searchCarrierRules(tfOneCarrierRule);
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("[TFOneCarrierRule{objId='DUMMY_DATA', coolingPeriod='DUMMY_DATA', esnChangeDays='DUMMY_DATA', lineExpireDays='DUMMY_DATA', lineReturnDays='DUMMY_DATA', coolingAfterInsert='DUMMY_DATA', npaNxxFlag='DUMMY_DATA', usedLineExpireDays='DUMMY_DATA', gsmGracePeriod='DUMMY_DATA', technology='DUMMY_DATA', reserveOnSuspend='DUMMY_DATA', reservePeriod='DUMMY_DATA', deacAfterGrace='DUMMY_DATA', cancelSuspendDays='DUMMY_DATA', cancelSuspend='DUMMY_DATA', blockCreateActItem='DUMMY_DATA', allow2gAct='DUMMY_DATA', allow2gReact='DUMMY_DATA', allowNonHdActs='DUMMY_DATA', allowNonHdReacts='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testSearchCarrierRules_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchCarrierRules(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneCarrierRule tfOneCarrierRule = new TracfoneOneCarrierRule();
        tfOneCarrierRule.setDbEnv(DBENV);
        tfOneCarrierRule.setObjId("OBJID");
        tfOneCarrierRule.setCoolingPeriod("X_COOLING_PERIOD");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchCarrierRules(tfOneCarrierRule);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchDataConfigs() throws TracfoneOneException, SQLException {
        TracfoneOneDataConfig tracfoneOneDataConfig = new TracfoneOneDataConfig();
        tracfoneOneDataConfig.setDbEnv(DBENV);
        tracfoneOneDataConfig.setApn("APN");
        tracfoneOneDataConfig.setCmd71GatewayHome("GATE_WAY");
        tracfoneOneDataConfig.setCmd71GprsApn("GPRS");
        tracfoneOneDataConfig.setCmd71MmscUpdate("MMSC");
        tracfoneOneDataConfig.setCmd121GatewayIpPortUpdate("GATE_WAY");
        tracfoneOneDataConfig.setCmd121GatewayIpUpdate("GATE_WAY");
        tracfoneOneDataConfig.setCmd121GatewayPortUpdate("GATE_WAY");
        tracfoneOneDataConfig.setCmd148CarrierDataSwitch("CARRIER");
        tracfoneOneDataConfig.setCmd150ClearProxy("CLEAR");
        tracfoneOneDataConfig.setDataSwitch("DATA_SWITCH");
        tracfoneOneDataConfig.setDev("DEV");
        tracfoneOneDataConfig.setHomePage("HOME_PAGE");
        tracfoneOneDataConfig.setIpAddress("IP_ADDRESS");
        tracfoneOneDataConfig.setMmsc("MMSC");
        tracfoneOneDataConfig.setObjId("1000");
        tracfoneOneDataConfig.setParentId("PARENT_ID");
        tracfoneOneDataConfig.setPartClassObjId("1000");
        tracfoneOneDataConfig.setxDefault("DEFAULT");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneDataConfig> response = tracfoneCarrierMaintenanceAction.searchDataConfigs(tracfoneOneDataConfig);
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("[TracfoneOneDataConfig{, objId='DUMMY_DATA', dev='DUMMY_DATA', parentId='DUMMY_DATA', partClassObjId='DUMMY_DATA', xDefault='DUMMY_DATA', ipAddress='DUMMY_DATA', apn='DUMMY_DATA', homePage='DUMMY_DATA', mmsc='DUMMY_DATA', cmd148CarrierDataSwitch='DUMMY_DATA', dataSwitch='DUMMY_DATA', cmd71GprsApn='DUMMY_DATA', cmd150ClearProxy='DUMMY_DATA', cmd121GatewayPortUpdate='DUMMY_DATA', cmd121GatewayIpUpdate='DUMMY_DATA', cmd71MmscUpdate='DUMMY_DATA', cmd71GatewayHome='DUMMY_DATA', cmd121GatewayIpPortUpdate='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testSearchDataConfigs_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchDataConfigs(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneDataConfig tracfoneOneDataConfig = new TracfoneOneDataConfig();
        tracfoneOneDataConfig.setDbEnv(DBENV);
        tracfoneOneDataConfig.setApn("APN");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchDataConfigs(tracfoneOneDataConfig);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllPartClasses() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOnePartClass> response = tracfoneCarrierMaintenanceAction.getAllPartClasses(DBENV);
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("[TracfoneOnePartClass{, objId='DUMMY_DATA', name='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testGetAllPartClasses_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.getAllPartClasses(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.getAllPartClasses(DBENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteOrderType() throws Exception {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("1000");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteOrderType(tracfoneOneOrderType, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "1000");
    }

    @Test
    public void testDeleteOrderType_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.deleteOrderType(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("1000");
        tracfoneOneOrderType.setNpa("NPA");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.deleteOrderType(tracfoneOneOrderType, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertIgOrderTypes() throws Exception {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        tracfoneOneIgOrderType.setProgrammeName("TEST");
        tracfoneOneIgOrderType.setIgOrderType("ORDER");
        tracfoneOneIgOrderType.setPriority("1");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertIgOrderTypes(tracfoneOneIgOrderType, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "TEST");
    }

    @Test
    public void testInsertIgOrderTypes_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertIgOrderTypes(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        tracfoneOneIgOrderType.setProgrammeName("TEST");
        tracfoneOneIgOrderType.setIgOrderType("ORDER");
        tracfoneOneIgOrderType.setPriority("1");
        doThrow(SQLException.class).when(stmt).execute();
        try {
            tracfoneCarrierMaintenanceAction.insertIgOrderTypes(tracfoneOneIgOrderType, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateIgOrderTypes() throws Exception {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        tracfoneOneIgOrderType.setProgrammeName("TEST");
        tracfoneOneIgOrderType.setIgOrderType("ORDER");
        tracfoneOneIgOrderType.setPriority("1");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateIgOrderTypes(tracfoneOneIgOrderType, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "TEST");
    }

    @Test
    public void testUpdateIgOrderTypes_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateIgOrderTypes(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        tracfoneOneIgOrderType.setProgrammeName("TEST");
        tracfoneOneIgOrderType.setIgOrderType("ORDER");
        tracfoneOneIgOrderType.setPriority("1");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.updateIgOrderTypes(tracfoneOneIgOrderType, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchIgOrderTypes() throws TracfoneOneException, SQLException {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        tracfoneOneIgOrderType.setProgrammeName("TEST");
        tracfoneOneIgOrderType.setIgOrderType("ORDER");
        tracfoneOneIgOrderType.setPriority("1");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneIgOrderType> response = tracfoneCarrierMaintenanceAction.searchIgOrderTypes(tracfoneOneIgOrderType, false);
        assertNotNull(response);
        assertEquals("[TFOneIgOrderType{programmeName=\'DUMMY_DATA\', actualOrderType=\'DUMMY_DATA\', igOrderType=\'DUMMY_DATA\', sqlText=\'DUMMY_DATA\', priority=\'DUMMY_DATA\', createSOGencodeFlag=\'DUMMY_DATA\', createMFormIGFlag=\'DUMMY_DATA\', createMFormPortFlag=\'DUMMY_DATA\', skipMinValidationForm=\'DUMMY_DATA\', skipESNValidationFlag=\'DUMMY_DATA\', createIGAPNFlag=\'DUMMY_DATA\', insertILDTransFlag=\'DUMMY_DATA\', bogoConfigFlag=\'DUMMY_DATA\', sUIActionType=\'DUMMY_DATA\', updateMSIDFlag=\'DUMMY_DATA\', addonCashCardFlag=\'DUMMY_DATA\', contactPinUpdateFlag=\'DUMMY_DATA\', brmNotificationFlag=\'DUMMY_DATA\', newerTransFlag=\'DUMMY_DATA\', skipMinUpdateFlag=\'DUMMY_DATA\', safeLinkBatchFlag=\'DUMMY_DATA\', createBucketsFlag=\'DUMMY_DATA\', processIgateIN3Flag=\'DUMMY_DATA\', processIgateIN3LiteFlag=\'DUMMY_DATA\', updateXCase2TaskFlag=\'DUMMY_DATA\', depIGTransFlag=\'DUMMY_DATA\', generateAccountFlag=\'DUMMY_DATA\', createIGACMFlag=\'DUMMY_DATA\'}]", response.toString());
    }

    @Test
    public void testSearchIgOrderTypes_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchIgOrderTypes(null, false);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        tracfoneOneIgOrderType.setProgrammeName("TEST");
        tracfoneOneIgOrderType.setIgOrderType("ORDER");
        tracfoneOneIgOrderType.setPriority("1");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchIgOrderTypes(tracfoneOneIgOrderType, false);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottlePolicy() throws Exception {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        tracfoneOneThrottlePolicy.setDbEnv(DBENV);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        tracfoneOneThrottlePolicy.setObjId("100");
        tracfoneOneThrottlePolicy.setPolicyName("TEST");
        tracfoneOneThrottlePolicy.setPolicyDesc("DESC");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertThrottlePolicy(tracfoneOneThrottlePolicy, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testInsertThrottlePolicy_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertThrottlePolicy(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        tracfoneOneThrottlePolicy.setDbEnv(DBENV);
        tracfoneOneThrottlePolicy.setPolicyName("TEST");
        tracfoneOneThrottlePolicy.setPolicyDesc("DESC");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.insertThrottlePolicy(tracfoneOneThrottlePolicy, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottleRule() throws Exception {
        List<TracfoneOneThrottleRule> rules = new ArrayList();
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        tracfoneOneThrottleRule.setDbEnv(DBENV);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        tracfoneOneThrottleRule.setParentId("123");
        tracfoneOneThrottleRule.setPolicyId("123");
        tracfoneOneThrottleRule.setRuleDesc("DESC");
        rules.add(tracfoneOneThrottleRule);
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertThrottleRules(rules, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testInsertThrottleRule_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertThrottleRules(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        List<TracfoneOneThrottleRule> rules = new ArrayList();
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        tracfoneOneThrottleRule.setDbEnv(DBENV);
        tracfoneOneThrottleRule.setParentId("123");
        tracfoneOneThrottleRule.setPolicyId("123");
        tracfoneOneThrottleRule.setRuleDesc("DESC");
        rules.add(tracfoneOneThrottleRule);
        doThrow(SQLException.class).when(stmt).executeBatch();
        try {
            tracfoneCarrierMaintenanceAction.insertThrottleRules(rules, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottleFeature() throws Exception {
        List<TracfoneOneThrottleFeature> features = new ArrayList();
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        tracfoneOneThrottleFeature.setDbEnv(DBENV);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        tracfoneOneThrottleFeature.setRuleId("123");
        tracfoneOneThrottleFeature.setFeatureFlagValue("TEST");
        tracfoneOneThrottleFeature.setFeatureName("TEST");
        features.add(tracfoneOneThrottleFeature);
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertThrottleFeatures(features, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testInsertThrottleFeature_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertThrottleFeatures(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        List<TracfoneOneThrottleFeature> features = new ArrayList();
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        tracfoneOneThrottleFeature.setDbEnv(DBENV);
        tracfoneOneThrottleFeature.setRuleId("123");
        tracfoneOneThrottleFeature.setFeatureFlagValue("TEST");
        tracfoneOneThrottleFeature.setFeatureName("TEST");
        features.add(tracfoneOneThrottleFeature);
        doThrow(SQLException.class).when(stmt).executeBatch();
        try {
            tracfoneCarrierMaintenanceAction.insertThrottleFeatures(features, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchThrottlePolicy() throws TracfoneOneException, SQLException {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        tracfoneOneThrottlePolicy.setDbEnv(DBENV);
        tracfoneOneThrottlePolicy.setObjId("100");
        tracfoneOneThrottlePolicy.setPolicyName("TEST");
        tracfoneOneThrottlePolicy.setPolicyDesc("DESC");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneThrottlePolicy> response = tracfoneCarrierMaintenanceAction.searchThrottlePolicies(tracfoneOneThrottlePolicy);
        assertNotNull(response);
        assertEquals("[TFOneThrottlePolicy{objId=\'DUMMY_DATA\', policyName=\'DUMMY_DATA\', policyDesc=\'DUMMY_DATA\', bypassTransQueue=\'DUMMY_DATA\', dataSuspendedFlag=\'DUMMY_DATA\'}]", response.toString());
    }

    @Test
    public void testSearchThrottlePolicy_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchThrottlePolicies(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        tracfoneOneThrottlePolicy.setDbEnv(DBENV);
        tracfoneOneThrottlePolicy.setObjId("100");
        tracfoneOneThrottlePolicy.setPolicyName("TEST");
        tracfoneOneThrottlePolicy.setPolicyDesc("DESC");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchThrottlePolicies(tracfoneOneThrottlePolicy);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchThrottleRule() throws TracfoneOneException, SQLException {
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        tracfoneOneThrottleRule.setDbEnv(DBENV);
        tracfoneOneThrottleRule.setParentId("123");
        tracfoneOneThrottleRule.setPolicyId("123");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneThrottleRule> response = tracfoneCarrierMaintenanceAction.searchThrottleRules(tracfoneOneThrottleRule);
        assertNotNull(response);
        assertEquals("[TFOneThrottleRule{objId=\'DUMMY_DATA\', parentId=\'DUMMY_DATA\', policyId=\'DUMMY_DATA\', ruleDesc=\'DUMMY_DATA\', status=\'DUMMY_DATA\'}]", response.toString());
    }

    @Test
    public void testSearchThrottleRule_withException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchThrottleRules(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        tracfoneOneThrottleRule.setDbEnv(DBENV);
        tracfoneOneThrottleRule.setParentId("123");
        tracfoneOneThrottleRule.setPolicyId("123");
        tracfoneOneThrottleRule.setPolicyName("POLICY_NAME");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchThrottleRules(tracfoneOneThrottleRule);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchThrottleFeatures() throws TracfoneOneException, SQLException {
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        tracfoneOneThrottleFeature.setDbEnv(DBENV);
        tracfoneOneThrottleFeature.setRuleId("123");
        tracfoneOneThrottleFeature.setFeatureFlagName("TEST");
        tracfoneOneThrottleFeature.setFeatureName("TEST");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneThrottleFeature> response = tracfoneCarrierMaintenanceAction.searchThrottleFeatures(tracfoneOneThrottleFeature);
        assertNotNull(response);
        assertEquals("[TFOneThrottleFeatures{objId=\'DUMMY_DATA\', ruleId=\'DUMMY_DATA\', featureFlagName=\'DUMMY_DATA\', featureFlagValue=\'DUMMY_DATA\', featureName=\'DUMMY_DATA\', featureValue=\'DUMMY_DATA\', status=\'DUMMY_DATA\'}]", response.toString());
    }

    @Test
    public void testSearchThrottleFeatures_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchThrottleFeatures(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        tracfoneOneThrottleFeature.setDbEnv(DBENV);
        tracfoneOneThrottleFeature.setRuleId("123");
        tracfoneOneThrottleFeature.setFeatureFlagName("TEST");
        tracfoneOneThrottleFeature.setFeatureName("TEST");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchThrottleFeatures(tracfoneOneThrottleFeature);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateThrottlePolicy() throws Exception {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        tracfoneOneThrottlePolicy.setDbEnv(DBENV);
        tracfoneOneThrottlePolicy.setObjId("100");
        tracfoneOneThrottlePolicy.setPolicyName("TEST");
        tracfoneOneThrottlePolicy.setPolicyDesc("DESC");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateThrottlePolicy(tracfoneOneThrottlePolicy, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "100");
    }

    @Test
    public void testUpdateThrottlePolicy_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateThrottlePolicy(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        tracfoneOneThrottlePolicy.setDbEnv(DBENV);
        tracfoneOneThrottlePolicy.setPolicyName("TEST");
        tracfoneOneThrottlePolicy.setPolicyDesc("DESC");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.updateThrottlePolicy(tracfoneOneThrottlePolicy, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateThrottleRule() throws Exception {
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        tracfoneOneThrottleRule.setDbEnv(DBENV);
        tracfoneOneThrottleRule.setObjId("100");
        tracfoneOneThrottleRule.setParentId("123");
        tracfoneOneThrottleRule.setPolicyId("123");
        tracfoneOneThrottleRule.setRuleDesc("DESC");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateThrottleRule(tracfoneOneThrottleRule, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "100");
    }

    @Test
    public void testUpdateThrottleRule_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateThrottleRule(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        tracfoneOneThrottleRule.setDbEnv(DBENV);
        tracfoneOneThrottleRule.setParentId("123");
        tracfoneOneThrottleRule.setPolicyId("123");
        tracfoneOneThrottleRule.setRuleDesc("DESC");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.updateThrottleRule(tracfoneOneThrottleRule, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateThrottleFeature() throws Exception {
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        tracfoneOneThrottleFeature.setDbEnv(DBENV);
        tracfoneOneThrottleFeature.setObjId("100");
        tracfoneOneThrottleFeature.setRuleId("123");
        tracfoneOneThrottleFeature.setFeatureFlagValue("TEST");
        tracfoneOneThrottleFeature.setFeatureFlagValue("Y");
        tracfoneOneThrottleFeature.setFeatureName("TEST");
        tracfoneOneThrottleFeature.setFeatureValue("Y");
        tracfoneOneThrottleFeature.setStatus("A");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateThrottleFeature(tracfoneOneThrottleFeature, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "100");
    }

    @Test
    public void testUpdateThrottleFeature_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateThrottleFeature(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        tracfoneOneThrottleFeature.setDbEnv(DBENV);
        tracfoneOneThrottleFeature.setObjId("100");
        tracfoneOneThrottleFeature.setRuleId("123");
        tracfoneOneThrottleFeature.setFeatureFlagValue("TEST");
        tracfoneOneThrottleFeature.setFeatureFlagValue("Y");
        tracfoneOneThrottleFeature.setFeatureName("TEST");
        tracfoneOneThrottleFeature.setFeatureValue("Y");
        tracfoneOneThrottleFeature.setStatus("A");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.updateThrottleFeature(tracfoneOneThrottleFeature, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testIsDuplicateOrderType() throws TracfoneOneException, SQLException {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        tracfoneOneIgOrderType.setProgrammeName("TEST");
        tracfoneOneIgOrderType.setIgOrderType("ORDER");
        tracfoneOneIgOrderType.setPriority("1");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        Boolean response = tracfoneCarrierMaintenanceAction.isDuplicateOrderType(tracfoneOneIgOrderType);
        assertNotNull(response);
        assertEquals("true", response.toString());
    }

    @Test
    public void testIsDuplicateOrderType_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.isDuplicateOrderType(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        tracfoneOneIgOrderType.setProgrammeName("TEST");
        tracfoneOneIgOrderType.setIgOrderType("ORDER");
        tracfoneOneIgOrderType.setPriority("1");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.isDuplicateOrderType(tracfoneOneIgOrderType);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchVerizonZipNPANXX() throws TracfoneOneException, SQLException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("TEST");
        tracfoneOneVerizonZipNPANXX.setZip("07832");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneVerizonZipNPANXX> response = tracfoneCarrierMaintenanceAction.searchVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX);
        assertNotNull(response);
        assertEquals("[TFOneVerizonZipNPANXX{zip='DUMMY_DATA', NPA='DUMMY_DATA', NXX='DUMMY_DATA', NPANXX='DUMMY_DATA', AccountNum='DUMMY_DATA', template='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testSearchVerizonZipNPANXX_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchVerizonZipNPANXX(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("TEST");
        tracfoneOneVerizonZipNPANXX.setZip("07832");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateVerizonZipNPANXX() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("100");
        tracfoneOneVerizonZipNPANXX.setZip("07832");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "100");
    }

    @Test
    public void testUpdateVerizonZipNPANXX_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateVerizonZipNPANXX(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("TEST");
        tracfoneOneVerizonZipNPANXX.setZip("07832");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.updateVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertVerizonZipNPANXX() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("TEST");
        tracfoneOneVerizonZipNPANXX.setZip("07832");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, 100, "100");
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testInsertVerizonZipNPANXX_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertVerizonZipNPANXX(null, 100, "100");
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("TEST");
        tracfoneOneVerizonZipNPANXX.setZip("07832");
        doThrow(SQLException.class).when(stmt).executeBatch();
        try {
            tracfoneCarrierMaintenanceAction.insertVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, 100, "100");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteVerizonZipNPANXX() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("1000");
        tracfoneOneVerizonZipNPANXX.setZip("07832");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "1000");
    }

    /**
     * Junits for Srint-25
     */

    @Test
    public void testDeleteVerizonZipNPANXX_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.deleteVerizonZipNPANXX(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("TEST");
        tracfoneOneVerizonZipNPANXX.setZip("07832");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.deleteVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchTmoZipNgp_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchTmoZipNgp(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchTmoZipNgp(tracfoneOneTmoZipNgp);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateTmoZipNgp() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateTmoZipNgp(tracfoneOneTmoZipNgp, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testUpdateTmoZipNgp_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateTmoZipNgp(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.updateTmoZipNgp(tracfoneOneTmoZipNgp, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertTmoZipNgp() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertTmoZipNgp(tracfoneOneTmoZipNgp, 100, "100");
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testInsertTmoZipNgp_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertTmoZipNgp(null, 100, "100");
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        doThrow(SQLException.class).when(stmt).executeBatch();
        try {
            tracfoneCarrierMaintenanceAction.insertTmoZipNgp(tracfoneOneTmoZipNgp, 100, "100");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteTmoZipNgp() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteTmoZipNgp(tracfoneOneTmoZipNgp, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testDeleteTmoZipNgp_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.deleteTmoZipNgp(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.deleteTmoZipNgp(tracfoneOneTmoZipNgp, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCingularMrktInfo() throws TracfoneOneException, SQLException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneCingularMrktInfo> response = tracfoneCarrierMaintenanceAction.searchCingularMrktInfo(tracfoneOneCingularMrktInfo);
        assertNotNull(response);
        assertEquals("[TFOneCingularMrktInfo{mkt='DUMMY_DATA', npa='DUMMY_DATA', nxx='DUMMY_DATA', npanxx='DUMMY_DATA', rcNumber='DUMMY_DATA', rcName='DUMMY_DATA', rcState='DUMMY_DATA', zip='DUMMY_DATA', mktType='DUMMY_DATA', accountNum='DUMMY_DATA', marketCode='DUMMY_DATA', dealerCode='DUMMY_DATA', subMarketId='DUMMY_DATA', template='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testSearchCingularMrktInfo_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchCingularMrktInfo(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchCingularMrktInfo(tracfoneOneCingularMrktInfo);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCingularMrktInfo() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateCingularMrktInfo(tracfoneOneCingularMrktInfo, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testUpdateCingularMrktInfo_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateCingularMrktInfo(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.updateCingularMrktInfo(tracfoneOneCingularMrktInfo, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCingularMrktInfo() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        tracfoneOneCingularMrktInfo.setRcName("TEST");
        tracfoneOneCingularMrktInfo.setRcNumber("TEST");
        tracfoneOneCingularMrktInfo.setSubMarketId("TEST");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertCingularMrktInfo(tracfoneOneCingularMrktInfo, 100, "100");
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testInsertCingularMrktInfo_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertCingularMrktInfo(null, 100, "100");
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        doThrow(SQLException.class).when(stmt).executeBatch();
        try {
            tracfoneCarrierMaintenanceAction.insertCingularMrktInfo(tracfoneOneCingularMrktInfo, 100, "100");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCingularMrktInfo() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteCingularMrktInfo(tracfoneOneCingularMrktInfo, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testDeleteCingularMrktInfo_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.deleteCingularMrktInfo(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.deleteCingularMrktInfo(tracfoneOneCingularMrktInfo, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    /**
     * Junits for Srint-26
     */

    @Test
    public void testSearchNotCertifyModel() throws TracfoneOneException, SQLException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneNotCertifyModel> response = tracfoneCarrierMaintenanceAction.searchNotCertifyModel(tracfoneOneNotCertifyModel);
        assertNotNull(response);
        assertEquals("[TFOneNotCertifyModel{objId='DUMMY_DATA', dev='DUMMY_DATA', parentId='DUMMY_DATA', partClassObjId='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testSearchNotCertifyModel_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchCingularMrktInfo(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchNotCertifyModel(tracfoneOneNotCertifyModel);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateNotCertifyModel() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateNotCertifyModel(tracfoneOneNotCertifyModel, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testUpdateNotCertifyModel_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateNotCertifyModel(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.updateNotCertifyModel(tracfoneOneNotCertifyModel, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertNotCertifyModel() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertNotCertifyModel(tracfoneOneNotCertifyModel, 100, "100");
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testInsertNotCertifyModel_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertCingularMrktInfo(null, 100, "100");
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.insertNotCertifyModel(tracfoneOneNotCertifyModel, 100, "100");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteNotCertifyModel() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteNotCertifyModel(tracfoneOneNotCertifyModel, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testDeleteNotCertifyModel_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.deleteNotCertifyModel(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.deleteNotCertifyModel(tracfoneOneNotCertifyModel, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testBulkUpdateNotCertifyModel() throws TracfoneOneException {
        List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModels = new ArrayList<>();
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        tracfoneOneNotCertifyModels.add(tracfoneOneNotCertifyModel);
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.bulkUpdateNotCertifyModel(tracfoneOneNotCertifyModels, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testBulkUpdateNotCertifyModel_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.bulkUpdateNotCertifyModel(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModels = new ArrayList<>();
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        tracfoneOneNotCertifyModels.add(tracfoneOneNotCertifyModel);
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.bulkUpdateNotCertifyModel(tracfoneOneNotCertifyModels, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    /**
     * Junits for Srint-27
     */

    @Test
    public void testBulkUpdateTmoZipNgp() throws TracfoneOneException {
        List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNgps = new ArrayList<>();
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        tracfoneOneTmoZipNgps.add(tracfoneOneTmoZipNgp);
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.bulkUpdateTmoZipNgp(tracfoneOneTmoZipNgps, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testBulkUpdateTmoZipNgp_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.bulkUpdateTmoZipNgp(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNgps = new ArrayList<>();
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        tracfoneOneTmoZipNgps.add(tracfoneOneTmoZipNgp);
        tracfoneOneTmoZipNgps.add(tracfoneOneTmoZipNgp);
        doThrow(SQLException.class).when(stmt).executeBatch();
        try {
            tracfoneCarrierMaintenanceAction.bulkUpdateTmoZipNgp(tracfoneOneTmoZipNgps, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierSimPref() throws TracfoneOneException, SQLException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneCarriersimpref> response = tracfoneCarrierMaintenanceAction.searchCarrierSimPref(tracfoneOneCarriersimpref);
        assertNotNull(response);
        assertEquals("[TFOneCarriersimpref{rank='DUMMY_DATA', minDllExch='DUMMY_DATA', maxDllExch='DUMMY_DATA', carrierName='DUMMY_DATA', simProfile='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testSearchCarrierSimPref_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchCarrierSimPref(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchCarrierSimPref(tracfoneOneCarriersimpref);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierSimPref() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertCarrierSimPref(tracfoneOneCarriersimpref, 100, "100");
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testInsertCarrierSimPref_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertCarrierSimPref(null, 100, "100");
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.insertCarrierSimPref(tracfoneOneCarriersimpref, 100, "100");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierSimPref() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateCarrierSimPref(tracfoneOneCarriersimpref, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testUpdateCarrierSimPref_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateCarrierSimPref(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.updateCarrierSimPref(tracfoneOneCarriersimpref, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierSimPref() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteCarrierSimPref(tracfoneOneCarriersimpref, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testDeleteCarrierSimPref_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.deleteCarrierSimPref(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.deleteCarrierSimPref(tracfoneOneCarriersimpref, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testBulkUpdateCarrierSimPref() throws TracfoneOneException {
        List<TracfoneOneCarrierSimPref> tracfoneOneCarrierSimPrefs = new ArrayList<>();
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        tracfoneOneCarrierSimPrefs.add(tracfoneOneCarriersimpref);
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.bulkUpdateCarrierSimPref(tracfoneOneCarrierSimPrefs, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testBulkUpdateCarrierSimPref_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.bulkUpdateCarrierSimPref(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        List<TracfoneOneCarrierSimPref> tracfoneOneCarrierSimPrefs = new ArrayList<>();
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        tracfoneOneCarrierSimPrefs.add(tracfoneOneCarriersimpref);
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.bulkUpdateCarrierSimPref(tracfoneOneCarrierSimPrefs, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchNpanxx2Carrierzones() throws TracfoneOneException, SQLException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setOldCarrierId("4");
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        tracfoneOneNpanxx2Carrierzones.setState("1");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        TFOneNpaNxx2CarrierZonesSearchResult response = tracfoneCarrierMaintenanceAction.searchNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        assertNotNull(response);
        assertEquals("TFOneNpaNxx2CarrierZonesSearchResult{paginationSearch=TracfoneonePaginationSearch{startIndex=1, endIndex=1000, total=0}, npanxx2Carrierzones=[TFOneNpanxx2Carrierzones{npa='DUMMY_DATA', nxx='DUMMY_DATA', carrierId='DUMMY_DATA', carrierName='DUMMY_DATA', leadTime='DUMMY_DATA', targetLevel='DUMMY_DATA', rateCenter='DUMMY_DATA', state='DUMMY_DATA', carrierIdDescription='DUMMY_DATA', zone='DUMMY_DATA', county='DUMMY_DATA', marketId='DUMMY_DATA', mrktArea='DUMMY_DATA', sid='DUMMY_DATA', technology='DUMMY_DATA', frequency1='DUMMY_DATA', frequency2='DUMMY_DATA', btaMktNumber='DUMMY_DATA', btaMktName='DUMMY_DATA', gsmTech='DUMMY_DATA', cdmaTech='DUMMY_DATA', tdmaTech='DUMMY_DATA', mnc='DUMMY_DATA', dbEnv='null'}]}", response.toString());
    }

    @Test
    public void testSearchNpanxx2Carrierzones_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchNpanxx2Carrierzones(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setOldCarrierId("4");
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        tracfoneOneNpanxx2Carrierzones.setState("1");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertNpanxx2Carrierzones() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setOldCarrierId("4");
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        tracfoneOneNpanxx2Carrierzones.setState("1");
        tracfoneOneNpanxx2Carrierzones.setLeadTime("3");
        tracfoneOneNpanxx2Carrierzones.setTargetLevel("6");
        tracfoneOneNpanxx2Carrierzones.setMarketId("5");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, 100, "100");
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testInsertNpanxx2Carrierzones_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertNpanxx2Carrierzones(null, 100, "100");
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setOldCarrierId("4");
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1.0");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        tracfoneOneNpanxx2Carrierzones.setState("1");
        tracfoneOneNpanxx2Carrierzones.setLeadTime("3");
        tracfoneOneNpanxx2Carrierzones.setTargetLevel("6");
        tracfoneOneNpanxx2Carrierzones.setMarketId("5");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.insertNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, 100, "100");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateNpanxx2Carrierzones() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setOldCarrierId("4");
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        tracfoneOneNpanxx2Carrierzones.setOldCarrierId("5");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testUpdateNpanxx2Carrierzones_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateNpanxx2Carrierzones(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
//         when SQLException occurs
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setOldCarrierId("4");
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.updateNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteNpanxx2Carrierzones() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setOldCarrierId("4");
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testDeleteNpanxx2Carrierzones_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.deleteNpanxx2Carrierzones(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setOldCarrierId("4");
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.deleteNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    /**
     * Sprint - 31
     */

    @Test
    public void testSearchArUsaPostalZips() throws TracfoneOneException, SQLException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        tracfoneOneArUsaPostalZips.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZips.setKeyCode("1");
        tracfoneOneArUsaPostalZips.setPostalCode("2");
        tracfoneOneArUsaPostalZips.setState("SD");
        tracfoneOneArUsaPostalZips.setCity("sd");

        List<Object[]> objects = new ArrayList<>();
        Object[] object = {"1", "null", "null", "null"};
        objects.add(object);

        when(cRtlArUsaPostalZipsFacadeLocal.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(objects);

        List<TFOneArUsaPostalZips> response = tracfoneCarrierMaintenanceAction.getArUsaPostalZips(tracfoneOneArUsaPostalZips);
        assertEquals("[TFOneArUsaPostalZip{postalCode='1', keyCode='null', state='null', city='null'}]", response.toString());
    }

    @Test
    public void testSearchArUsaPostalZips_whenException() {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        when(cRtlArUsaPostalZipsFacadeLocal.getEntityManager()).thenReturn(entityManager);
        doThrow(RuntimeException.class).when(entityManager).createNativeQuery(anyString());
        try {
            tracfoneCarrierMaintenanceAction.getArUsaPostalZips(tracfoneOneArUsaPostalZips);
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testinsertArUsaPostalZips() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        tracfoneOneArUsaPostalZips.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZips.setKeyCode("1");
        tracfoneOneArUsaPostalZips.setPostalCode("2");
        tracfoneOneArUsaPostalZips.setState("SD");
        tracfoneOneArUsaPostalZips.setCity("sd");

        when(cRtlArUsaPostalZipsFacadeLocal.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);

        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertArUsaPostalZips(tracfoneOneArUsaPostalZips, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testinsertArUsaPostalZips_whenException() {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        doThrow(RuntimeException.class).when(cRtlArUsaPostalZipsFacadeLocal).getEntityManager();
        try {
            tracfoneCarrierMaintenanceAction.insertArUsaPostalZips(tracfoneOneArUsaPostalZips, 310);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateArUsaPostalZips() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        tracfoneOneArUsaPostalZips.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZips.setKeyCode("1");
        tracfoneOneArUsaPostalZips.setPostalCode("2");
        tracfoneOneArUsaPostalZips.setState("SD");
        tracfoneOneArUsaPostalZips.setCity("sd");

        when(cRtlArUsaPostalZipsFacadeLocal.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);

        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateArUsaPostalZips(tracfoneOneArUsaPostalZips, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testUpdateArUsaPostalZips_whenException() {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        doThrow(RuntimeException.class).when(cRtlArUsaPostalZipsFacadeLocal).getEntityManager();
        try {
            tracfoneCarrierMaintenanceAction.updateArUsaPostalZips(tracfoneOneArUsaPostalZips, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testdeleteArUsaPostalZips() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        tracfoneOneArUsaPostalZips.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZips.setKeyCode("1");
        tracfoneOneArUsaPostalZips.setPostalCode("2");
        tracfoneOneArUsaPostalZips.setState("SD");
        tracfoneOneArUsaPostalZips.setCity("sd");

        when(cRtlArUsaPostalZipsFacadeLocal.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);

        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteArUsaPostalZips(tracfoneOneArUsaPostalZips, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testdeleteArUsaPostalZips_whenException() {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        doThrow(RuntimeException.class).when(cRtlArUsaPostalZipsFacadeLocal).getEntityManager();
        try {
            tracfoneCarrierMaintenanceAction.deleteArUsaPostalZips(tracfoneOneArUsaPostalZips, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


//    @Test
//    public void testSearchArUsaMarketDetails() throws TracfoneOneException, SQLException {
//        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
//        tracfoneOneArUsaMarket.setDbEnv(DBENV);
//        tracfoneOneArUsaMarket.setKeyCode("8404611100");
//        tracfoneOneArUsaMarket.setCarrierEntity("T-Mobile USA");
//
//        TracfoneonePaginationSearch  tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
//        tracfoneonePaginationSearch.setStartIndex(1);
//        tracfoneonePaginationSearch.setEndIndex(2);
//        tracfoneonePaginationSearch.setTotal(60);
//        tracfoneOneArUsaMarket.setPaginationSearch(tracfoneonePaginationSearch);
//
//        List<Object[]> objects = new ArrayList<>();
//        Object[] object = {"8404611100","null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null","null"};
//        objects.add(object);
//
//
//        List<String> objs = new ArrayList<>();
//        String obj = "1";
//        objs.add(obj);
//
//        when(cRtlArUsaMarketFacadeLocal.getEntityManager()).thenReturn(entityManager);
//        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
//        when(query.getResultList()).thenReturn(objects);
//
//        when(cRtlArUsaMarketFacadeLocal.getEntityManager()).thenReturn(entityManager);
//        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
//        when(query.getResultList().get(0).toString()).thenReturn(objs.toString());
//
//        TFOneArUsaMarketSearchResult response = tracfoneCarrierMaintenanceAction.getArUsaMarketDetails(tracfoneOneArUsaMarket);
//        assertEquals("[TFOneArUsaMarket{keyCode='8404611100', nation='null', state='null', county='null', carrierEntity='null', marketingName='null', mhzTotal='null', spectrumBlocks='null', cmaMktCode='null', cmaMktState='null', cmaMktName='null', cmaMktNameAlternate='null', cmaMktMultiState='null', btaMktCode='null', btaMktState='null', btaMktName='null', btaMktNameAlternate='null', btaMktMultiState='null', beaMktCode='null', beaMktState='null', beaMktName='null', beaMktNameAlternate='null', beaMktMultiState='null', protocol='null', extendedServices='null', bid1='null', bid1Name='null', bid1Bsid1='null', bid1Bsid2='null', bid1Bsid3='null', bid1Mnc='null', bid2='null', bid2Name='null', bid2Bsid1='null', bid2Bsid2='null', bid2Bsid3='null', bid2Mnc='null', bid3='null', bid3Name='null', bid3Bsid1='null', bid3Bsid2='null', bid3Bsid3='null', bid3Mnc='null', bid4='null', bid4Name='null', bid4Bsid1='null', bid4Bsid2='null', bid4Bsid3='null', bid4Mnc='null', oldKeyCode='null', oldCarrierEntity='null'}]", response.toString());
//    }

    @Test
    public void testSearchArUsaMarketDetails_whenException() {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        when(cRtlArUsaMarketFacadeLocal.getEntityManager()).thenReturn(entityManager);
        doThrow(RuntimeException.class).when(entityManager).createNativeQuery(anyString());
        try {
            tracfoneCarrierMaintenanceAction.getArUsaMarketDetails(tracfoneOneArUsaMarket);
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertArUsaMarketDetails() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        tracfoneOneArUsaMarket.setDbEnv(DBENV);
        tracfoneOneArUsaMarket.setKeyCode("8404611100");
        tracfoneOneArUsaMarket.setCarrierEntity("T-Mobile USA");

        when(cRtlArUsaMarketFacadeLocal.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);

        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertArUsaMarketDetails(tracfoneOneArUsaMarket, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testInsertArUsaMarketDetails_whenException() {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        doThrow(RuntimeException.class).when(cRtlArUsaMarketFacadeLocal).getEntityManager();
        try {
            tracfoneCarrierMaintenanceAction.insertArUsaMarketDetails(tracfoneOneArUsaMarket, 316);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateArUsaMarketDetails() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        tracfoneOneArUsaMarket.setDbEnv(DBENV);
        tracfoneOneArUsaMarket.setKeyCode("8404611100");
        tracfoneOneArUsaMarket.setCarrierEntity("T-Mobile USA");
        tracfoneOneArUsaMarket.setOldKeyCode("1");

        when(cRtlArUsaMarketFacadeLocal.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);

        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateArUsaMarketDetails(tracfoneOneArUsaMarket, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testUpdateArUsaMarketDetails_whenException() {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        doThrow(RuntimeException.class).when(cRtlArUsaMarketFacadeLocal).getEntityManager();
        try {
            tracfoneCarrierMaintenanceAction.updateArUsaMarketDetails(tracfoneOneArUsaMarket, 316);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteArUsaMarketDetails() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        tracfoneOneArUsaMarket.setDbEnv(DBENV);
        tracfoneOneArUsaMarket.setKeyCode("8404611100");
        tracfoneOneArUsaMarket.setCarrierEntity("T-Mobile USA");
        tracfoneOneArUsaMarket.setOldKeyCode("1");

        when(cRtlArUsaMarketFacadeLocal.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);

        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteArUsaMarketDetails(tracfoneOneArUsaMarket, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testDeleteArUsaMarketDetails_whenException() {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        doThrow(RuntimeException.class).when(cRtlArUsaMarketFacadeLocal).getEntityManager();
        try {
            tracfoneCarrierMaintenanceAction.deleteArUsaMarketDetails(tracfoneOneArUsaMarket, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertGeoLoc() throws TracfoneOneException {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        tfOneGeoLoc.setOldZip("213");
        tfOneGeoLoc.setZip("213");

        when(cRtlArUsaMarketFacadeLocal.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);

        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertGeoLoc(tfOneGeoLoc, 100);
        assertEquals("Success", tfOneGeneralResponse.getStatus());
    }

    @Test
    public void testInsertGeoLoc_whenException() {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        doThrow(RuntimeException.class).when(cRtlArUsaMarketFacadeLocal).getEntityManager();
        try {
            tracfoneCarrierMaintenanceAction.insertGeoLoc(tfOneGeoLoc, 316);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteGeoLoc() throws TracfoneOneException {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        tfOneGeoLoc.setZip("213");

        when(cRtlArUsaMarketFacadeLocal.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);

        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteGeoLoc(tfOneGeoLoc, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testDeleteGeoLoc_whenException() {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        doThrow(RuntimeException.class).when(cRtlArUsaMarketFacadeLocal).getEntityManager();
        try {
            tracfoneCarrierMaintenanceAction.deleteGeoLoc(tfOneGeoLoc, 318);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testBulkInsertGeoLocs() throws TracfoneOneException {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        tfOneGeoLoc.setCrlatitude("213");
        tfOneGeoLoc.setZip("213");

        when(cRtlArUsaMarketFacadeLocal.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);

        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.bulkInsertGeoLocs(tfOneGeoLoc, 100, "45");
        assertEquals("Success", tfOneGeneralResponse.getStatus());
    }

    @Test
    public void testBulkInsertGeoLocs_whenException() {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        doThrow(RuntimeException.class).when(cRtlArUsaMarketFacadeLocal).getEntityManager();
        try {
            tracfoneCarrierMaintenanceAction.bulkInsertGeoLocs(tfOneGeoLoc, 316, "3245");
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetUsers() throws TracfoneOneException {
        List<String> users = new ArrayList<>();
        users.add("1");

        when(cRtlArUsaMarketFacadeLocal.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(users);

        List<String> userList = tracfoneCarrierMaintenanceAction.getUsers();
        assertEquals("[1]", userList.toString());
    }

    @Test
    public void testGetUsers_whenException() {
        doThrow(RuntimeException.class).when(cRtlArUsaMarketFacadeLocal).getEntityManager();
        try {
            tracfoneCarrierMaintenanceAction.getUsers();
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchGeoLoc() throws TracfoneOneException {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        tfOneGeoLoc.setZip("1231");

        List<Object[]> objects = new ArrayList<>();
        Object[] object = {"1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4", "2", "3", "4"};
        objects.add(object);

        when(cRtlArUsaPostalZipsFacadeLocal.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(objects);

        List<TFOneGeoLoc> geoLocs = tracfoneCarrierMaintenanceAction.searchGeoLoc(tfOneGeoLoc);
        assertEquals("[TFOneGeoLoc{zip='1', state='2', popcy='3', pop05='4', latitude='1', longitude='2', rlatitude='3', rlongitude='4', srlatitude='1', crlatitude='2', rzg2user='3', insertDate='4', updateDate='2'}]", geoLocs.toString());
    }

    @Test
    public void testSearchGeoLoc_whenException() {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        doThrow(RuntimeException.class).when(cRtlArUsaPostalZipsFacadeLocal).getEntityManager();
        try {
            tracfoneCarrierMaintenanceAction.searchGeoLoc(tfOneGeoLoc);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateGeoLoc() throws TracfoneOneException {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        tfOneGeoLoc.setCrlatitude("213");
        tfOneGeoLoc.setZip("213");

        when(cRtlArUsaMarketFacadeLocal.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);

        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateGeoLoc(tfOneGeoLoc, 100);
        assertEquals("Success", tfOneGeneralResponse.getStatus());
    }

    @Test
    public void testUpdateGeoLoc_whenException() {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        doThrow(RuntimeException.class).when(cRtlArUsaMarketFacadeLocal).getEntityManager();
        try {
            tracfoneCarrierMaintenanceAction.updateGeoLoc(tfOneGeoLoc, 316);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testBulkUpdateGeoLoc() throws TracfoneOneException {
        List<TracfoneOneGeoLoc> geoLocs = new ArrayList<>();
        TracfoneOneGeoLoc tfGeoLoc = new TracfoneOneGeoLoc();
        tfGeoLoc.setZip("1231");
        tfGeoLoc.setOldZip("1223");

        geoLocs.add(tfGeoLoc);

        when(cRtlArUsaMarketFacadeLocal.getEntityManager()).thenReturn(entityManager);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);

        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.bulkUpdateGeoLoc(geoLocs, 100);
        assertEquals("Success", tfOneGeneralResponse.getStatus());
    }

    @Test
    public void testBulkUpdateGeoLoc_whenException() {
        List<TracfoneOneGeoLoc> geoLocs = new ArrayList<>();
        TracfoneOneGeoLoc tfGeoLoc = new TracfoneOneGeoLoc();
        tfGeoLoc.setZip("1231");
        tfGeoLoc.setCheckDuplicate(true);
        tfGeoLoc.setOldZip("1223");
        geoLocs.add(tfGeoLoc);
        doThrow(RuntimeException.class).when(cRtlArUsaMarketFacadeLocal).getEntityManager();
        try {
            tracfoneCarrierMaintenanceAction.bulkUpdateGeoLoc(geoLocs, 316);
            fail("Tracfone Exception");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierzones() throws TracfoneOneException, SQLException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneCarrierZones> response = tracfoneCarrierMaintenanceAction.searchCarrierzones(tracfoneOneCarrierZones);
        assertNotNull(response);
        assertEquals("[TFOneCarrierZones{zipCode=DUMMY_DATA, state=DUMMY_DATA, county=DUMMY_DATA, zone=DUMMY_DATA, rateCente=DUMMY_DATA, marketId=DUMMY_DATA, marketArea=DUMMY_DATA, city=DUMMY_DATA, btaMarketNumber=DUMMY_DATA, btaMarketName=DUMMY_DATA, carrierId=DUMMY_DATA, carrierName=DUMMY_DATA, zipStatus=DUMMY_DATA, simProfile=DUMMY_DATA, simProfile2=DUMMY_DATA, planType=DUMMY_DATA}]", response.toString());
    }

    @Test
    public void testSearchCarrierzones_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchCarrierzones(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchCarrierzones(tracfoneOneCarrierZones);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierzones() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertCarrierzones(tracfoneOneCarrierZones, 100, "100");
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testInsertCarrierzones_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertCarrierzones(null, 100, "100");
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        doThrow(SQLException.class).when(stmt).executeBatch();
        try {
            tracfoneCarrierMaintenanceAction.insertCarrierzones(tracfoneOneCarrierZones, 100, "100");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierzones() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteCarrierzones(tracfoneOneCarrierZones, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }
    @Test
    public void testDeleteCarrierzones_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.deleteCarrierzones(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.deleteCarrierzones(tracfoneOneCarrierZones, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
    @Test
    public void testUpdateCarrierzones() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateCarrierzones(tracfoneOneCarrierZones, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }
    @Test
    public void testUpdateCarrierzones_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateCarrierzones(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.updateCarrierzones(tracfoneOneCarrierZones, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierpref() throws TracfoneOneException, SQLException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneCarrierPref> response = tracfoneCarrierMaintenanceAction.searchCarrierpref(tracfoneOneCarrierPref);
        assertNotNull(response);
        assertEquals("[TFOneCarrierPref{state=DUMMY_DATA, county=DUMMY_DATA, carrierId=DUMMY_DATA, carrierName=DUMMY_DATA, carrierRank=DUMMY_DATA, newRank=DUMMY_DATA}]", response.toString());
    }

    @Test
    public void testSearchCarrierpref_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneCarrierMaintenanceAction.searchCarrierpref(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneCarrierMaintenanceAction.searchCarrierpref(tracfoneOneCarrierPref);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierpref() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("HUTCHINSON");
        tracfoneOneCarrierPref.setCarrierId("100555");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        List<TFOneCarrierPref> tfOneCarrierPrefs = new ArrayList<>();
        TFOneCarrierPref tfOneCarrierPref = new TFOneCarrierPref();
        tfOneCarrierPref.setState("SD");
        tfOneCarrierPref.setCounty("TEST");
        tfOneCarrierPref.setCarrierId("1235");
        tfOneCarrierPrefs.add(tfOneCarrierPref);
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertCarrierpref(tracfoneOneCarrierPref, 100, "100");
        assertEquals(tfOneGeneralResponse.getStatus(), "Unable to insert Record");
    }

    @Test
    public void testInsertCarrierpref_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.insertCarrierpref(null, 100, "100");
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.insertCarrierpref(tracfoneOneCarrierPref, 100, "100");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierpref() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteCarrierpref(tracfoneOneCarrierPref, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }

    @Test
    public void testDeleteCarrierpref_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.deleteCarrierpref(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneCarrierMaintenanceAction.deleteCarrierpref(tracfoneOneCarrierPref, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
    @Test
    public void testUpdateCarrierpref() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateCarrierpref(tracfoneOneCarrierPref, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
    }
    @Test
    public void testUpdateCarrierpref_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneCarrierMaintenanceAction.updateCarrierpref(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneCarrierMaintenanceAction.updateCarrierpref(tracfoneOneCarrierPref, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

}