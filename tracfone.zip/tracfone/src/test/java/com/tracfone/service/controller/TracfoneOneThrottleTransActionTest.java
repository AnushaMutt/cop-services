package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneSearchAdditionalModel;
import com.tracfone.service.model.request.TracfoneOneThrottleRework;
import com.tracfone.service.model.request.TracfoneOneThrottleTrans;
import com.tracfone.service.model.request.TracfoneOneThrottleTransaction;
import com.tracfone.service.model.request.TracfoneonePaginationSearch;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneThrottlePolicy;
import com.tracfone.service.model.response.TFOneThrottleTransSearchResult;
import com.tracfone.service.model.response.TFOneThrottleTransaction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneThrottleTransActionTest {

    @InjectMocks
    private TracfoneOneThrottleTransAction action;
    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private CallableStatement callableStatement;
    @Mock
    private ResultSet resultSet;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    private TFOneGeneralResponse tfOneGeneralResponse;
    public final String DBENV = "dbEnv";

    @Before
    public void setUp() throws Exception {
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

    @Test
    public void testViewThrottleTransAction() throws Exception {
        List<String> transNumvalues = new ArrayList<>();
        List<String> ruleIdValue = new ArrayList<>();
        List<String> groupIdValue = new ArrayList<>();
        List<String> statusValue = new ArrayList<>();
        transNumvalues.add("TEST");
        ruleIdValue.add("12345");
        ruleIdValue.add("54332");
        groupIdValue.add("NULL");
        statusValue.add("C");
        TracfoneonePaginationSearch paginationSearch = new TracfoneonePaginationSearch();
        paginationSearch.setEndIndex(200);
        paginationSearch.setStartIndex(0);
        List<TracfoneOneSearchAdditionalModel> searchColumns = new ArrayList<>();
        TracfoneOneSearchAdditionalModel addColumn = new TracfoneOneSearchAdditionalModel();
        addColumn.setSearchColumnName("transactionNum");
        addColumn.setSearchColumnType("string");
        addColumn.setSearchValues(transNumvalues);
        addColumn.setSearchIsColumnNotIn(false);
        addColumn.setSearchIsColumnLike(false);
        TracfoneOneSearchAdditionalModel addColumn1 = new TracfoneOneSearchAdditionalModel();
        addColumn1.setSearchColumnName("ruleId");
        addColumn1.setSearchColumnType("string");
        addColumn1.setSearchValues(ruleIdValue);
        addColumn1.setSearchIsColumnNotIn(false);
        addColumn1.setSearchIsColumnLike(false);
        TracfoneOneSearchAdditionalModel addColumn2 = new TracfoneOneSearchAdditionalModel();
        addColumn2.setSearchColumnName("groupId");
        addColumn2.setSearchColumnType("string");
        addColumn2.setSearchValues(groupIdValue);
        addColumn2.setSearchIsColumnNotIn(false);
        addColumn2.setSearchIsColumnLike(false);
        TracfoneOneSearchAdditionalModel addColumn3 = new TracfoneOneSearchAdditionalModel();
        addColumn3.setSearchColumnName("status");
        addColumn3.setSearchColumnType("string");
        addColumn3.setSearchValues(statusValue);
        addColumn3.setSearchIsColumnNotIn(true);
        addColumn3.setSearchIsColumnLike(false);

        searchColumns.add(addColumn);
        searchColumns.add(addColumn1);
        searchColumns.add(addColumn2);
        searchColumns.add(addColumn3);
        TracfoneOneThrottleTransaction tracfoneThrottleTransaction = new TracfoneOneThrottleTransaction();
        tracfoneThrottleTransaction.setDbEnv(DBENV);
        tracfoneThrottleTransaction.setSearchColumns(searchColumns);
        tracfoneThrottleTransaction.setPaginationSearch(paginationSearch);
        tracfoneThrottleTransaction.setCreationFromDate("12-01-2020");
        tracfoneThrottleTransaction.setCreationToDate("12-30-2020");
        tracfoneThrottleTransaction.setUpdateFromDate("06-01-2020");
        tracfoneThrottleTransaction.setUpdateToDate("06-30-2020");

        TFOneThrottleTransSearchResult tfOneThrottle = new TFOneThrottleTransSearchResult();
        List<TFOneThrottleTransaction> tfOneThrottleTransacion = new ArrayList<>();
        TFOneThrottleTransaction throttleTrans = new TFOneThrottleTransaction();
        throttleTrans.setApiMessage("API");
        throttleTrans.setApiStatus("STATUS");
        throttleTrans.setCos("COS");
        throttleTrans.setEntitlement("ENTITLEMENT");
        throttleTrans.setEsn("ESN");
        throttleTrans.setGroupId("GROUPID");
        throttleTrans.setMin("MIN");
        throttleTrans.setParentName("PARENT NAME");
        throttleTrans.setPolicyName("POLICY NAME");
        throttleTrans.setPriority("PRIO");
        throttleTrans.setPropagateFlagValue("FLAG");
        throttleTrans.setRuleId("RULE");
        throttleTrans.setStatus("STATUS");
        throttleTrans.setSubscriberId("SUB ID");
        throttleTrans.setThreshold("THESH");
        throttleTrans.setThrottleGroupType("GROUP_TYPE");
        throttleTrans.setTransactionNum("THROTTLE NUM");
        throttleTrans.setTransactionType("TYPE");
        throttleTrans.setUsageTierId("USAGE ID");
        throttleTrans.setCreationDate("10-20-2020");
        throttleTrans.setLastUpdateDate("11-20-2020");
        tfOneThrottleTransacion.add(throttleTrans);
        TracfoneonePaginationSearch tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
        tracfoneonePaginationSearch.setStartIndex(0);
        tracfoneonePaginationSearch.setEndIndex(100);
        tracfoneonePaginationSearch.setTotal(123);
        tfOneThrottle.setPaginationSearch(tracfoneonePaginationSearch);
        tfOneThrottle.setThrottleTransactions(tfOneThrottleTransacion);

        when(stmt.executeQuery()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMY_DATA");
        TFOneThrottleTransSearchResult response = action.viewThrottleTransaction(tracfoneThrottleTransaction);
        assertEquals("TFOneThrottleTransSearchResult{paginationSearch=TracfoneonePaginationSearch{startIndex=0, endIndex=200, total=0}, throttleTransactions=[TFOneViewThrottleTransaction{transactionNum=DUMMY_DATA, objId=DUMMY_DATA, creationDate=DUMMY_DATA, lastUpdateDate=DUMMY_DATA, transactionType=DUMMY_DATA, status=DUMMY_DATA, ruleId=DUMMY_DATA, min=DUMMY_DATA, esn=DUMMY_DATA, priority=DUMMY_DATA, threshold=DUMMY_DATA, usageTierId=DUMMY_DATA, throttleGroupType=DUMMY_DATA, subscriberId=DUMMY_DATA, propogateFlagValue=DUMMY_DATA, policyName=DUMMY_DATA, cos=DUMMY_DATA, entitlement=DUMMY_DATA, apiMessage=DUMMY_DATA, apiStatus=DUMMY_DATA, parentName=DUMMY_DATA}groupId=DUMMY_DATA}]}", response.toString());
    }

    @Test
    public void testViewThrottleTransForElseBlocks() throws Exception {
        TracfoneOneThrottleTransaction tracfoneThrottleTransaction = new TracfoneOneThrottleTransaction();
        tracfoneThrottleTransaction.setDbEnv(DBENV);
        tracfoneThrottleTransaction.setCreationFromDate("12-01-2020");
        tracfoneThrottleTransaction.setUpdateFromDate("06-01-2020");

        when(stmt.executeQuery()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMY_DATA");
        TFOneThrottleTransSearchResult response = action.viewThrottleTransaction(tracfoneThrottleTransaction);
        assertEquals("TFOneThrottleTransSearchResult{paginationSearch=TracfoneonePaginationSearch{startIndex=1, endIndex=1000, total=0}, throttleTransactions=[TFOneViewThrottleTransaction{transactionNum=DUMMY_DATA, objId=DUMMY_DATA, creationDate=DUMMY_DATA, lastUpdateDate=DUMMY_DATA, transactionType=DUMMY_DATA, status=DUMMY_DATA, ruleId=DUMMY_DATA, min=DUMMY_DATA, esn=DUMMY_DATA, priority=DUMMY_DATA, threshold=DUMMY_DATA, usageTierId=DUMMY_DATA, throttleGroupType=DUMMY_DATA, subscriberId=DUMMY_DATA, propogateFlagValue=DUMMY_DATA, policyName=DUMMY_DATA, cos=DUMMY_DATA, entitlement=DUMMY_DATA, apiMessage=DUMMY_DATA, apiStatus=DUMMY_DATA, parentName=DUMMY_DATA}groupId=DUMMY_DATA}]}", response.toString());
    }

    @Test
    public void testViewThrottleTrans_withException() throws SQLException {
        List<String> values = new ArrayList<>();
        values.add("TEST");
        TracfoneonePaginationSearch paginationSearch = new TracfoneonePaginationSearch();
        paginationSearch.setEndIndex(200);
        paginationSearch.setStartIndex(0);
        List<TracfoneOneSearchAdditionalModel> searchColumns = new ArrayList<>();
        TracfoneOneSearchAdditionalModel addColumn = new TracfoneOneSearchAdditionalModel();
        addColumn.setSearchColumnName("transactionNum");
        addColumn.setSearchColumnType("string");
        addColumn.setSearchValues(values);
        addColumn.setSearchIsColumnNotIn(false);
        addColumn.setSearchIsColumnLike(false);

        searchColumns.add(addColumn);
        TracfoneOneThrottleTransaction tracfoneThrottleTransaction = new TracfoneOneThrottleTransaction();
        tracfoneThrottleTransaction.setDbEnv(DBENV);
        tracfoneThrottleTransaction.setSearchColumns(searchColumns);
        tracfoneThrottleTransaction.setPaginationSearch(paginationSearch);
        tracfoneThrottleTransaction.setCreationFromDate("12-01-2020");
        tracfoneThrottleTransaction.setCreationToDate("12-30-2020");
        tracfoneThrottleTransaction.setUpdateFromDate("06-01-2020");
        tracfoneThrottleTransaction.setUpdateToDate("06-30-2020");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            action.viewThrottleTransaction(tracfoneThrottleTransaction);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testReworkRequeue() throws Exception {
        List<String> values = new ArrayList<>();
        values.add("3057108887");
        TracfoneOneThrottleTransaction tracfoneThrottleTransaction = new TracfoneOneThrottleTransaction();
        List<TracfoneOneSearchAdditionalModel> tracfoneOneSearch = new ArrayList<>();
        TracfoneOneSearchAdditionalModel tracfoneOneSearchAdditionalModel = new TracfoneOneSearchAdditionalModel();
        tracfoneOneSearchAdditionalModel.setSearchColumnName("min");
        tracfoneOneSearchAdditionalModel.setSearchColumnType("string");
        tracfoneOneSearchAdditionalModel.setSearchIsColumnLike(false);
        tracfoneOneSearchAdditionalModel.setSearchIsColumnNotIn(false);
        tracfoneOneSearchAdditionalModel.setSearchValues(values);
        tracfoneOneSearch.add(tracfoneOneSearchAdditionalModel);
        tracfoneThrottleTransaction.setDbEnv(DBENV);
        TracfoneonePaginationSearch paginationSearch = new TracfoneonePaginationSearch();
        paginationSearch.setEndIndex(200);
        paginationSearch.setStartIndex(0);
        tracfoneThrottleTransaction.setSearchColumns(tracfoneOneSearch);
        tracfoneThrottleTransaction.setPaginationSearch(paginationSearch);
        TracfoneOneThrottleRework tfThrottleTransaction = new TracfoneOneThrottleRework();
        TracfoneOneThrottleTrans throttleTrans = new TracfoneOneThrottleTrans();
        throttleTrans.setApiMessage("TEST API MESSAGE");
        tfThrottleTransaction.setReworkCriteria(throttleTrans);
        tfThrottleTransaction.setSearchCriteria(tracfoneThrottleTransaction);

        tfOneGeneralResponse = action.reworkRequeue(tfThrottleTransaction, "REWORK", 601);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "Transactions reworked successfully");
    }

    @Test
    public void testReworkRequeue_whenException() throws TracfoneOneException, SQLException {
        try {
            action.reworkRequeue(null, "REWORK", 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        List<String> values = new ArrayList<>();
        values.add("test");
        TracfoneOneThrottleTransaction tracfoneThrottleTransaction = new TracfoneOneThrottleTransaction();
        List<TracfoneOneSearchAdditionalModel> tracfoneOneSearch = new ArrayList<>();
        TracfoneOneSearchAdditionalModel tracfoneOneSearchAdditionalModel = new TracfoneOneSearchAdditionalModel();
        tracfoneOneSearchAdditionalModel.setSearchColumnName("transactionNum");
        tracfoneOneSearchAdditionalModel.setSearchColumnType("string");
        tracfoneOneSearchAdditionalModel.setSearchIsColumnLike(false);
        tracfoneOneSearchAdditionalModel.setSearchIsColumnNotIn(false);
        tracfoneOneSearchAdditionalModel.setSearchValues(values);
        tracfoneOneSearch.add(tracfoneOneSearchAdditionalModel);
        tracfoneThrottleTransaction.setDbEnv(DBENV);
        TracfoneonePaginationSearch paginationSearch = new TracfoneonePaginationSearch();
        paginationSearch.setEndIndex(200);
        paginationSearch.setStartIndex(0);
        tracfoneThrottleTransaction.setSearchColumns(tracfoneOneSearch);
        tracfoneThrottleTransaction.setPaginationSearch(paginationSearch);
        TracfoneOneThrottleRework tfThrottleTransaction = new TracfoneOneThrottleRework();
        TracfoneOneThrottleTrans throttleTrans = new TracfoneOneThrottleTrans();
        throttleTrans.setStatus("E");
        throttleTrans.setApiMessage("TEST API MESSAGE");
        tfThrottleTransaction.setReworkCriteria(throttleTrans);
        tfThrottleTransaction.setSearchCriteria(tracfoneThrottleTransaction);

        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            action.reworkRequeue(tfThrottleTransaction, "REWORK", 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottleTransaction() throws Exception {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setTransactionNum("X_TRANSACTION_NUM");
        tfThrottleTrans.setDbEnv(DBENV);
        tfThrottleTrans.setMin("X_MIN");
        tfThrottleTrans.setEsn("X_ESN");
        tfThrottleTrans.setTransactionType("TTON");
        tfThrottleTrans.setParentName("PARENT_NAME");
        tfThrottleTrans.setUsageTierId("USAGE_TIER_ID");
        when(con.prepareCall(anyString())).thenReturn(callableStatement);
        tfOneGeneralResponse = action.insertThrottleTransaction(tfThrottleTrans, 100);
        assertEquals("Success", tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testInsertThrottleTransaction_TTOFF() throws Exception {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setPolicyName("POLICY_NAME");
        tfThrottleTrans.setEntitlement("ENTITLEMENT");
        tfThrottleTrans.setPriority("PRIORITY");
        tfThrottleTrans.setTransactionType("TTOFF");
        tfThrottleTrans.setThreshold("THRESHOLD");
        tfThrottleTrans.setThrottleGroupType("THROTTLE_GROUP_TYPE");
        tfThrottleTrans.setDbEnv(DBENV);
        when(con.prepareCall(anyString())).thenReturn(callableStatement);
        when(callableStatement.getString(3)).thenReturn("Success");
        when(callableStatement.getString(4)).thenReturn("Success");
        tfOneGeneralResponse = action.insertThrottleTransaction(tfThrottleTrans, 100);
        assertEquals("Success", tfOneGeneralResponse.getStatus());
    }

    @Test
    public void testInsertThrottleTransaction_HSBON() throws Exception {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setPolicyName("POLICY_NAME");
        tfThrottleTrans.setEntitlement("ENTITLEMENT");
        tfThrottleTrans.setPriority("PRIORITY");
        tfThrottleTrans.setTransactionType("HSBON");
        tfThrottleTrans.setThreshold("THRESHOLD");
        tfThrottleTrans.setThrottleGroupType("THROTTLE_GROUP_TYPE");
        tfThrottleTrans.setDbEnv(DBENV);
        when(con.prepareCall(anyString())).thenReturn(callableStatement);
        when(callableStatement.getString(6)).thenReturn("Success");
        when(callableStatement.getString(7)).thenReturn("Success");
        tfOneGeneralResponse = action.insertThrottleTransaction(tfThrottleTrans, 100);
        assertEquals("Success", tfOneGeneralResponse.getStatus());
    }

    @Test
    public void testInsertThrottleTransaction_whenException() throws TracfoneOneException, SQLException {
        try {
            action.insertThrottleTransaction(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setTransactionType("HSBON");
        tfThrottleTrans.setDbEnv(DBENV);
        tfThrottleTrans.setThreshold("THROHALD");
        when(con.prepareCall(anyString())).thenReturn(callableStatement);
        doThrow(SQLException.class).when(callableStatement).executeUpdate();
        try {
            action.insertThrottleTransaction(tfThrottleTrans, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetPolicyName() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneThrottlePolicy> res = action.getPolicyName(DBENV);
        assertNotNull(res);
        assertEquals(1, res.size());
        assertEquals("[TFOneThrottlePolicy{objId='DUMMY_DATA', policyName='DUMMY_DATA', policyDesc='DUMMY_DATA', bypassTransQueue='null', dataSuspendedFlag='null'}]", res.toString());
    }

    @Test
    public void testGetPolicyName_whenException() throws SQLException {
        doThrow(SQLException.class).when(resultSet).next();
        try {
            action.getPolicyName(DBENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottleTrans_TTON() throws Exception {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setTransactionType("HSBOF");
        tfThrottleTrans.setThrottleGroupType("HS");
        tfThrottleTrans.setTransactionNum("THRESHOLD");
        tfThrottleTrans.setRuleId("12");
        tfThrottleTrans.setMin("12212112");
        tfThrottleTrans.setEsn("1221312");
        tfThrottleTrans.setStatus("Q");
        tfThrottleTrans.setApiMessage("MESSAGE");
        tfThrottleTrans.setApiStatus("Q");
        tfThrottleTrans.setSubscriberId("232231");
        tfThrottleTrans.setGroupId("2131");
        tfThrottleTrans.setPropagateFlagValue("A");
        tfThrottleTrans.setParentName("TMO");
        tfThrottleTrans.setUsageTierId("2");
        tfThrottleTrans.setCos("COS");
        tfThrottleTrans.setParentName("TMO");
        tfThrottleTrans.setEntitlement("ENT");
        tfThrottleTrans.setPriority("1");
        tfThrottleTrans.setThreshold("11");
        tfThrottleTrans.setDbEnv(DBENV);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("100");
        tfOneGeneralResponse = action.insertTTONThrottleTrans(tfThrottleTrans, 100);
        assertEquals("Success", tfOneGeneralResponse.getStatus());
    }

    @Test
    public void testInsertThrottleTransTTON_whenException() throws SQLException {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setTransactionType("TTON");
        tfThrottleTrans.setThrottleGroupType("TT");
        tfThrottleTrans.setDbEnv(DBENV);

        doThrow(SQLException.class).when(stmt).execute();
        try {
            action.insertTTONThrottleTrans(tfThrottleTrans, 102);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottleTrans_TTOFF() throws Exception {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setTransactionType("TTOFF");
        tfThrottleTrans.setThrottleGroupType("TT");
        tfThrottleTrans.setDbEnv(DBENV);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("100");
        tfOneGeneralResponse = action.insertTTOFFThrottleTrans(tfThrottleTrans, 100);
        assertEquals("Success", tfOneGeneralResponse.getStatus());
    }

    @Test
    public void testInsertThrottleTransTTOFF_whenException() throws SQLException {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setTransactionType("TTOFF");
        tfThrottleTrans.setThrottleGroupType("TT");
        tfThrottleTrans.setDbEnv(DBENV);

        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            action.insertTTOFFThrottleTrans(tfThrottleTrans, 102);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottleTrans_HSBOFF() throws Exception {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setTransactionType("HSBOF");
        tfThrottleTrans.setThrottleGroupType("HS");
        tfThrottleTrans.setDbEnv(DBENV);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("100");
        tfOneGeneralResponse = action.insertHSBOFThrottleTrans(tfThrottleTrans, 100);
        assertEquals("Success", tfOneGeneralResponse.getStatus());
    }

    @Test
    public void testInsertThrottleTransHSBOF_whenException() throws SQLException {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setTransactionType("HSBOF");
        tfThrottleTrans.setThrottleGroupType("HS");
        tfThrottleTrans.setDbEnv(DBENV);

        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            action.insertHSBOFThrottleTrans(tfThrottleTrans, 102);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottleTrans_HSBON() throws Exception {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setTransactionType("HSBOF");
        tfThrottleTrans.setThrottleGroupType("HS");
        tfThrottleTrans.setDbEnv(DBENV);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("100");
        tfOneGeneralResponse = action.insertHSBONThrottleTrans(tfThrottleTrans, 100);
        assertEquals("Success", tfOneGeneralResponse.getStatus());
    }

    @Test
    public void testInsertThrottleTransHSBON_whenException() throws SQLException {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setTransactionType("HSBOF");
        tfThrottleTrans.setThrottleGroupType("HS");
        tfThrottleTrans.setDbEnv(DBENV);

        doThrow(SQLException.class).when(stmt).execute();
        try {
            action.insertHSBONThrottleTrans(tfThrottleTrans, 102);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetUsageTierId() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<String> res = action.getUsageTierId(DBENV);
        assertNotNull(res);
        assertEquals(1, res.size());
        assertEquals("[DUMMY_DATA]", res.toString());
    }

    @Test
    public void testGetUsageTierId_whenException() throws SQLException {
        doThrow(SQLException.class).when(resultSet).next();
        try {
            action.getUsageTierId(DBENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCos() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<String> res = action.getCos(DBENV);
        assertNotNull(res);
        assertEquals(1, res.size());
        assertEquals("[DUMMY_DATA]", res.toString());
    }

    @Test
    public void testGetCos_whenException() throws SQLException {
        doThrow(SQLException.class).when(resultSet).next();
        try {
            action.getCos(DBENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetPriority() throws TracfoneOneException, SQLException {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");
        tfhrottleTrans.setCos("COS");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<String> res = action.getPriority(DBENV, tfhrottleTrans.getCos());
        assertNotNull(res);
        assertEquals(1, res.size());
        assertEquals("[DUMMY_DATA]", res.toString());
    }

    @Test
    public void testGetPriority_whenException() throws SQLException {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");
        tfhrottleTrans.setCos("COS");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            action.getPriority(DBENV, tfhrottleTrans.getCos());
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetThresholdEntitlement() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<String> res = action.getThresholdEntitlement(DBENV, "THRESHOLD");
        assertNotNull(res);
        assertEquals(1, res.size());
        assertEquals("[DUMMY_DATA]", res.toString());
    }

    @Test
    public void testGetThresholdEntitlement_whenException() throws SQLException {
        doThrow(SQLException.class).when(resultSet).next();
        try {
            action.getThresholdEntitlement(DBENV, "THRESHOLD");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetRuleId() throws TracfoneOneException, SQLException {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");
        tfhrottleTrans.setObjId("100");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<String> res = action.getRuleId(DBENV, tfhrottleTrans.getCos());
        assertNotNull(res);
        assertEquals(1, res.size());
        assertEquals("[DUMMY_DATA]", res.toString());
    }

    @Test
    public void testGetRuleId_whenException() throws SQLException {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");
        tfhrottleTrans.setObjId("100");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            action.getRuleId(DBENV, tfhrottleTrans.getCos());
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}