package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.report.TracfoneAdhocReportRequest;
import com.tracfone.service.model.response.TracfoneOneReport;
import com.tracfone.service.util.TracfoneOneConstant;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneControllerReportTest {

    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private ResultSet resultSet;

    @InjectMocks
    private TracfoneControllerReport tracfoneControllerReport;

    @Before
    public void setUp() throws Exception {
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

    @Test
    public void testRunAdhocMonitorReport() throws TracfoneOneException, SQLException {
        TracfoneAdhocReportRequest request = new TracfoneAdhocReportRequest();
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn("IG").when(resultSet).getString(any());
        TracfoneOneReport tracfoneOneReport = tracfoneControllerReport.runAdhocMonitorReport(request);
        tracfoneOneReport.setReportSQL("query");
        tracfoneOneReport.setJsonResponse("response");
        tracfoneOneReport.setCreateDate(null);
        assertEquals("TracfoneOneReport{reportName='monitor', jsonResponse='response', reportSQL='query', createDate=null}", tracfoneOneReport.toString());
    }

    @Test
    public void testRunAdhocMonitorReport_whenException() throws SQLException {
        TracfoneAdhocReportRequest request = new TracfoneAdhocReportRequest();
        doThrow(SQLException.class).when(resultSet).next();
        try {
            request.setToDate("2020/12/1");
            request.setFromDate("2020/12/2");
            tracfoneControllerReport.runAdhocMonitorReport(request);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TracfoneOneConstant.TRACFONE_REPORT_ADHOC_MONITOR_ERROR_CODE, e.getErrorCode());
            assertEquals(TracfoneOneConstant.TRACFONE_REPORT_ADHOC_MONITOR_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testRunAdhocTTMonitorReport() throws TracfoneOneException, SQLException {
        TracfoneAdhocReportRequest request = new TracfoneAdhocReportRequest();
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn("TT").when(resultSet).getString(any());
        TracfoneOneReport tracfoneOneReport = tracfoneControllerReport.runAdhocTTMonitorReport(request);
        tracfoneOneReport.setReportSQL("query");
        tracfoneOneReport.setJsonResponse("response");
        tracfoneOneReport.setCreateDate(null);
        assertEquals("TracfoneOneReport{reportName='ttmonitor', jsonResponse='response', reportSQL='query', createDate=null}", tracfoneOneReport.toString());
    }

    @Test
    public void testRunAdhocTTMonitorReport_whenException() throws SQLException {
        TracfoneAdhocReportRequest request = new TracfoneAdhocReportRequest();
        doThrow(SQLException.class).when(resultSet).next();
        try {
            request.setToDate("2020/12/1");
            request.setFromDate("2020/12/2");
            tracfoneControllerReport.runAdhocTTMonitorReport(request);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TracfoneOneConstant.TRACFONE_REPORT_ADHOC_TT_MONITOR_ERROR_CODE, e.getErrorCode());
            assertEquals(TracfoneOneConstant.TRACFONE_REPORT_ADHOC_TT_MONITOR_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testRunPCRFAdhocMonitorReport() throws TracfoneOneException, SQLException {
        TracfoneAdhocReportRequest request = new TracfoneAdhocReportRequest();
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn("IG").when(resultSet).getString(any());
        TracfoneOneReport tracfoneOneReport = tracfoneControllerReport.runAdhocPCRFMonitorReport(request);
        tracfoneOneReport.setReportSQL("query");
        tracfoneOneReport.setJsonResponse("response");
        tracfoneOneReport.setCreateDate(null);
        assertEquals("TracfoneOneReport{reportName='pcrfmonitor', jsonResponse='response', reportSQL='query', createDate=null}", tracfoneOneReport.toString());
    }

    @Test
    public void testRunPCRFAdhocMonitorReport_whenException() throws SQLException, TracfoneOneException {
        TracfoneAdhocReportRequest request = new TracfoneAdhocReportRequest();
        doThrow(SQLException.class).when(resultSet).next();
        try {
            request.setToDate("2020/12/1");
            request.setFromDate("2020/12/2");
            tracfoneControllerReport.runAdhocPCRFMonitorReport(request);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TracfoneOneConstant.TRACFONE_REPORT_ADHOC_PCRF_MONITOR_ERROR_CODE, e.getErrorCode());
            assertEquals(TracfoneOneConstant.TRACFONE_REPORT_ADHOC_PCRF_MONITOR_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

}