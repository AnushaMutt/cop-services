/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneFeatureRequirement;
import com.tracfone.service.model.request.TracfoneOneLineStatusCode;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionConfig;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneThrottleStatusCode;
import com.tracfone.service.model.request.TracfoneOneUploadProfileFeatures;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneFeatureRequirement;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneLineStatusCode;
import com.tracfone.service.model.response.TFOneRPFeatureNameList;
import com.tracfone.service.model.response.TFOneRatePlanExtensionConfig;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import com.tracfone.service.model.response.TFOneThrottleStatusCode;
import com.tracfone.service.model.response.TFOneUploadProfileFeatures;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantPlanWizard;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * @author Thejaswini
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneFeatureControllerTest implements TracfoneOneConstantPlanWizard, TracfoneOneConstant {
    private static final String DBENV = "DBENV";
    @InjectMocks
    private TracfoneFeatureController tracfoneFeatureController;
    @Mock
    private TracfoneFeatureLocalAction tracfoneFeatureAction;
    @Mock
    private TracfoneProfileAction tracfoneProfileAction;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;
    private TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig;
    private List<String> ids;

    @Before
    public void setUp() {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "100");
        ids = new ArrayList<>();
        ids.add("1000");
        ids.add("1001");
        setRpExtensionConfig();
        tracfoneOneException = new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
    }

    private void setRpExtensionConfig() {
        tfOneRpExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        tfOneRpExtensionConfig.setObjid("100");
        tfOneRpExtensionConfig.setDbEnv("DBENV");
        tfOneRpExtensionConfig.setProfileId("PROFILE_ID");
        tfOneRpExtensionConfig.setFeatureName("F_NAME");
        tfOneRpExtensionConfig.setFeatureValue("F4");
        tfOneRpExtensionConfig.setFeatureRequirement("ADD");
        tfOneRpExtensionConfig.setToggleFlag("Y");
        tfOneRpExtensionConfig.setDisplaySUIFlag("Y");
        tfOneRpExtensionConfig.setRestrictSUIFlag("Y");
    }

    /**
     * Test of getAllMasterFeatures method, of class TracfoneFeatureController.
     */
    @Test
    public void testGetAllMasterFeatures() throws Exception {
        List<TFOneRPFeatureNameList> featureList = new ArrayList<>();
        TFOneRPFeatureNameList tFOneRPFeatureNameList = new TFOneRPFeatureNameList();
        tFOneRPFeatureNameList.setFeatureName("FeatureName");
        featureList.add(tFOneRPFeatureNameList);
        when(tracfoneFeatureAction.getAllMasterFeatures(any())).thenReturn(featureList);
        List<TFOneRPFeatureNameList> masterFeatures = tracfoneFeatureController.getAllMasterFeatures(DBENV);
        assertEquals("[TFOneRPFeatureNameList{featureName=FeatureName}]", masterFeatures.toString());
    }

    @Test
    public void testGetAllMasterFeatures_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).getAllMasterFeatures(null);
        try {
            tracfoneFeatureController.getAllMasterFeatures(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_GET_ALL_MASTER_FEATURE_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_GET_ALL_MASTER_FEATURE_ERROR_MESSAGE);
        }
    }

    /**
     * Test of insertRpExtensionConfig method, of class TracfoneFeatureController.
     */
    @Test
    public void testInsertRpExtensionConfig() throws Exception {
        List<TracfoneOneRatePlanExtensionConfig> tfOneRatePlanExtensionConfigs = new ArrayList<>();
        tfOneRatePlanExtensionConfigs.add(tfOneRpExtensionConfig);
        List<String> featureNames = new ArrayList<>();
        when(tracfoneFeatureAction.findExistingMasterFeatures(any(), any())).thenReturn(featureNames);
        doNothing().when(tracfoneFeatureAction).insertMasterFeature(any(), any(), anyInt());
        when(tracfoneFeatureAction.insertRpExtensionConfig(tfOneRatePlanExtensionConfigs, 100, null)).thenReturn(tFOneGeneralResponse);

        TFOneGeneralResponse response = tracfoneFeatureController.insertRpExtensionConfig(tfOneRatePlanExtensionConfigs, 100);
        assertEquals("Success", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testInsertRpExtensionConfig_whenException() throws Exception {
        // In case a null object is passed
        try {
            tracfoneFeatureController.insertRpExtensionConfig(null, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_MASTER_FEATURE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_MASTER_FEATURE_ERROR_MESSAGE, e.getErrorMessage());
        }

        // Case the action throws a SQLException
        List<TracfoneOneRatePlanExtensionConfig> tfOneRatePlanExtensionConfigs = new ArrayList<>();
        tfOneRatePlanExtensionConfigs.add(tfOneRpExtensionConfig);
        List<String> featureNames = new ArrayList<>();
        when(tracfoneFeatureAction.findExistingMasterFeatures(any(), any())).thenReturn(featureNames);
        try {
            tracfoneFeatureController.insertRpExtensionConfig(tfOneRatePlanExtensionConfigs, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_RP_EXTENSION_CONFIG_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_RP_EXTENSION_CONFIG_ERROR_MESSAGE, e.getErrorMessage());
        }

        //In case the DBENV property was not set on the object
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).findExistingMasterFeatures(any(), any());
        try {
            tracfoneFeatureController.insertRpExtensionConfig(tfOneRatePlanExtensionConfigs, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_MASTER_FEATURE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_MASTER_FEATURE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    /**
     * Test of getAllProfileFeatures method, of class TracfoneFeatureController.
     */
    @Test
    public void testGetAllProfileFeatures() throws Exception {
        TracfoneOneSearchProfileModel selectedRateProfile = new TracfoneOneSearchProfileModel();
        selectedRateProfile.setProfileId("100");
        List<TFOneRatePlanExtensionConfig> rpExtensionConfigs = new ArrayList<>();
        TFOneRatePlanExtensionConfig tfOneRpExtensionConfig = new TFOneRatePlanExtensionConfig();
        tfOneRpExtensionConfig.setDisplaySUIFlag("Y");
        tfOneRpExtensionConfig.setFeatureName("FEATURE_NAME");
        tfOneRpExtensionConfig.setFeatureRequirement("FEATURE_REQUIREMENT");
        tfOneRpExtensionConfig.setFeatureValue("FEATURE_VALUE");
        tfOneRpExtensionConfig.setProfileId("10");
        tfOneRpExtensionConfig.setRestrictSUIFlag("Y");
        tfOneRpExtensionConfig.setToggleFlag("Y");
        rpExtensionConfigs.add(tfOneRpExtensionConfig);
        when(tracfoneFeatureAction.getAllProfileFeatures(any())).thenReturn(rpExtensionConfigs);
        List<TFOneRatePlanProfile> allProfileFeatures = tracfoneFeatureController.getAllProfileFeatures(selectedRateProfile);
        assertEquals("[TFOneRatePlanProfile{profileId=100, profileDescription=null, rpExtensionLinks=null, rpExtensionConfigs=[TFOneRatePlanExtensionConfig{objid=null, profileId=10, profileDescription=null, featureName=FEATURE_NAME, featureValue=FEATURE_VALUE, featureRequirement=FEATURE_REQUIREMENT, toggleFlag=Y, notes=null, displaySUIFlag=Y, restrictSUIFlag=Y, rowNum=null, errorMessages={}, dbEnv=null}], buckets=null, features=null}]", allProfileFeatures.toString());
    }

    @Test
    public void testGetAllProfileFeatures_whenException() throws Exception {
        try {
            tracfoneFeatureController.getAllProfileFeatures(null);
            fail("Throws NPE which gets caught as a TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_GET_PROFILE_FEATURE_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_GET_PROFILE_FEATURE_ERROR_MESSAGE);
        }

        TracfoneOneSearchProfileModel selectedRateProfile = new TracfoneOneSearchProfileModel();
        selectedRateProfile.setProfileId("100");
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).getAllProfileFeatures(any());
        try {
            tracfoneFeatureController.getAllProfileFeatures(selectedRateProfile);
            fail("Throws NPE which gets caught as a TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_GET_PROFILE_FEATURE_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_GET_PROFILE_FEATURE_ERROR_MESSAGE);
        }
    }

    /**
     * Test of updateRpExtensionConfig method, of class TracfoneFeatureController.
     */
    @Test
    public void testUpdateRpExtensionConfig() throws Exception {
        List<String> featureNames = new ArrayList<>();
        when(tracfoneFeatureAction.findExistingMasterFeatures(any(), any())).thenReturn(featureNames);
        doNothing().when(tracfoneFeatureAction).insertMasterFeature(any(), any(), anyInt());
        when(tracfoneFeatureAction.updateRpExtensionConfig(any(TracfoneOneRatePlanExtensionConfig.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneFeatureController.updateRpExtensionConfig(tfOneRpExtensionConfig, 100);
        assertEquals("Success", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testUpdateRpExtensionConfig_whenException() throws Exception {
        // In case a null object is passed
        try {
            tracfoneFeatureController.updateRpExtensionConfig(null, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_MASTER_FEATURE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_MASTER_FEATURE_ERROR_MESSAGE, e.getErrorMessage());
        }

        // Case the action throws a SQLException
        List<String> featureNames = new ArrayList<>();
        when(tracfoneFeatureAction.findExistingMasterFeatures(any(), any())).thenReturn(featureNames);
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).updateRpExtensionConfig(any(), anyInt());
        try {
            tracfoneFeatureController.updateRpExtensionConfig(tfOneRpExtensionConfig, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }

        //In case the DBENV property was not set on the object
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).findExistingMasterFeatures(any(), any());
        try {
            tracfoneFeatureController.updateRpExtensionConfig(tfOneRpExtensionConfig, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_MASTER_FEATURE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_MASTER_FEATURE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    /**
     * Test of deleteRpExtensionConfig method, of class TracfoneFeatureController.
     */
    @Test
    public void testDeleteRpExtensionConfig() throws Exception {
        when(tracfoneFeatureAction.deleteRpExtensionConfigs(any(), anyList(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneFeatureController.deleteRpExtensionConfig(tfOneRpExtensionConfig, 100);
        assertEquals("Success", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testDeleteRpExtensionConfig_whenException() throws Exception {
        try {
            tracfoneFeatureController.deleteRpExtensionConfig(null, 100);
            fail("Throws NPE which gets caught as TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_DELETE_RP_EXTENSION_CONFIG_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_DELETE_RP_EXTENSION_CONFIG_ERROR_MESSAGE);
        }

        doThrow(tracfoneOneException).when(tracfoneFeatureAction).deleteRpExtensionConfigs(any(), anyList(), anyInt());
        try {
            tracfoneFeatureController.deleteRpExtensionConfig(tfOneRpExtensionConfig, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_DELETE_RP_EXTENSION_CONFIG_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_DELETE_RP_EXTENSION_CONFIG_ERROR_MESSAGE);
        }
    }

    @Test
    public void testValidateAndAddProfileFeatures_whenErrorConfigExist() throws Exception {
        List<TracfoneOneRatePlanExtensionConfig> successExtensionConfigs = new ArrayList<>();
        TracfoneOneRatePlanExtensionConfig successExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        successExtensionConfig.setProfileId("1000");
        successExtensionConfig.setFeatureName("FEATURE");
        successExtensionConfig.setRowNum("1");
        successExtensionConfigs.add(successExtensionConfig);
        List<TracfoneOneRatePlanExtensionConfig> errorExtensionConfigs = new ArrayList<>();
        TracfoneOneRatePlanExtensionConfig errorExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        errorExtensionConfig.setProfileId("1000");
        errorExtensionConfig.setFeatureName("FEATURE_NAME");
        errorExtensionConfig.setRowNum("2");
        errorExtensionConfig.setRestrictSUIFlag("Y");
        errorExtensionConfig.setDisplaySUIFlag("Y");
        errorExtensionConfig.setToggleFlag("123");
        errorExtensionConfig.setFeatureRequirement("FEATURE_REQUIREMENT");
        errorExtensionConfig.setFeatureValue("FEATURE_VALUE");
        errorExtensionConfig.setNotes("NOTES");
        errorExtensionConfigs.add(errorExtensionConfig);
        TracfoneOneUploadProfileFeatures profileFeatures = new TracfoneOneUploadProfileFeatures();
        profileFeatures.setInsertFlag("N");
        profileFeatures.setProfileId("1000");
        profileFeatures.setSuccessRpExtensionConfigs(successExtensionConfigs);
        profileFeatures.setErrorRpExtensionConfigs(errorExtensionConfigs);

        TFOneRatePlanProfile profile = new TFOneRatePlanProfile();
        profile.setProfileId("12");

        List<TFOneRatePlanExtensionConfig> existingConfigsForProfiles = new ArrayList<>();
        TFOneRatePlanExtensionConfig existingConfigsForProfile = new TFOneRatePlanExtensionConfig();
        existingConfigsForProfile.setFeatureName("FEATURE_NAME");
        existingConfigsForProfiles.add(existingConfigsForProfile);
        when(tracfoneProfileAction.viewProfile(any())).thenReturn(profile);
        when(tracfoneFeatureAction.viewRpExtensionConfig(any())).thenReturn(existingConfigsForProfiles);
        TFOneUploadProfileFeatures tFOneUploadProfileFeatures = tracfoneFeatureController.validateAndAddProfileFeatures(profileFeatures, 100);
        assertEquals("TFOneUploadProfileFeatures{successRpExtensionConfigs=[TFOneRatePlanExtensionConfig{objid=null, profileId=1000, profileDescription=null, featureName=FEATURE, featureValue=null, featureRequirement=null, toggleFlag=null, notes=null, displaySUIFlag=null, restrictSUIFlag=null, rowNum=1, errorMessages={}, dbEnv=null}], errorRpExtensionConfigs=[TFOneRatePlanExtensionConfig{objid=null, profileId=1000, profileDescription=null, featureName=FEATURE_NAME, featureValue=FEATURE_VALUE, featureRequirement=FEATURE_REQUIREMENT, toggleFlag=123, notes=NOTES, displaySUIFlag=Y, restrictSUIFlag=Y, rowNum=2, errorMessages={featureRequirement=[Feature Requirement cannot be more than 3 character(s)., FEATURE_REQUIREMENT cannot be a value for Feature Requirement.], toggleFlag=[Toggle Flag cannot be more than 1 character(s)., Toggle Flag should only have a value of either Y or N.]}, dbEnv=null}]}", tFOneUploadProfileFeatures.toString());
    }

    @Test
    public void testValidateAndAddProfileFeatures_validateMandatoryFields() throws Exception {
        List<TracfoneOneRatePlanExtensionConfig> errorExtensionConfigs = new ArrayList<>();
        TracfoneOneRatePlanExtensionConfig errorExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        errorExtensionConfigs.add(errorExtensionConfig);
        TracfoneOneUploadProfileFeatures profileFeatures = new TracfoneOneUploadProfileFeatures();
        profileFeatures.setErrorRpExtensionConfigs(errorExtensionConfigs);

        TFOneRatePlanProfile profile = new TFOneRatePlanProfile();
        when(tracfoneProfileAction.viewProfile(any())).thenReturn(profile);
        TFOneUploadProfileFeatures tFOneUploadProfileFeatures = tracfoneFeatureController.validateAndAddProfileFeatures(profileFeatures, 100);
        assertEquals("TFOneUploadProfileFeatures{successRpExtensionConfigs=[], errorRpExtensionConfigs=[TFOneRatePlanExtensionConfig{objid=null, profileId=null, profileDescription=null, featureName=null, featureValue=null, featureRequirement=null, toggleFlag=null, notes=null, displaySUIFlag=null, restrictSUIFlag=null, rowNum=null, errorMessages={featureValue=[Feature Value cannot be blank.], featureName=[Feature Name cannot be blank.], profileId=[Profile Id: null does not exist., Profile Id cannot be blank.], rowNum=[Row Num cannot be blank.], featureRequirement=[Feature Requirement cannot be blank.], restrictSUIFlag=[Restrict SUI Flag cannot be blank.], displaySUIFlag=[Display SUI Flag cannot be blank.], toggleFlag=[Toggle Flag cannot be blank.]}, dbEnv=null}]}", tFOneUploadProfileFeatures.toString());
    }

    @Test
    public void testValidateAndAddProfileFeatures_whenSuccessConfigExist() throws Exception {
        List<TracfoneOneRatePlanExtensionConfig> successExtensionConfigs = new ArrayList<>();
        TracfoneOneRatePlanExtensionConfig successExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        successExtensionConfig.setObjid("1000");
        successExtensionConfig.setProfileId("1000");
        successExtensionConfig.setRowNum("1");
        successExtensionConfig.setFeatureName("FEATURE_NAME");
        successExtensionConfig.setRestrictSUIFlag("Y");
        successExtensionConfig.setDisplaySUIFlag("Y");
        successExtensionConfig.setToggleFlag("Y");
        successExtensionConfig.setFeatureRequirement("ADD");
        successExtensionConfig.setFeatureValue("FEATURE_VALUE");
        successExtensionConfig.setNotes("NOTES");
        successExtensionConfigs.add(successExtensionConfig);

        TracfoneOneUploadProfileFeatures profileFeatures = new TracfoneOneUploadProfileFeatures();
        profileFeatures.setInsertFlag("Y");
        profileFeatures.setProfileId("1000");
        profileFeatures.setSuccessRpExtensionConfigs(successExtensionConfigs);

        when(tracfoneFeatureAction.insertRpExtensionConfig(any(), anyInt(), any())).thenReturn(tFOneGeneralResponse);
        TFOneUploadProfileFeatures tFOneUploadProfileFeatures = tracfoneFeatureController.validateAndAddProfileFeatures(profileFeatures, 100);
        assertEquals("TFOneUploadProfileFeatures{successRpExtensionConfigs=[TFOneRatePlanExtensionConfig{objid=1000, profileId=1000, profileDescription=null, featureName=FEATURE_NAME, featureValue=FEATURE_VALUE, featureRequirement=ADD, toggleFlag=Y, notes=NOTES, displaySUIFlag=Y, restrictSUIFlag=Y, rowNum=1, errorMessages={}, dbEnv=null}], errorRpExtensionConfigs=[]}", tFOneUploadProfileFeatures.toString());
    }

    @Test
    public void validateAndAddProfileFeatures_whenException() throws Exception {
        try {
            tracfoneFeatureController.validateAndAddProfileFeatures(null, 100);
            fail("Throws NPE which gets caught as TracfoneOneException");
        } catch (NullPointerException e) {
            //Excepted
        }
        TracfoneOneUploadProfileFeatures tfUploadProfileFeatures = new TracfoneOneUploadProfileFeatures();
        tfUploadProfileFeatures.setDbEnv(DBENV);
        tfUploadProfileFeatures.setInsertFlag("Y");
        try {
            tracfoneFeatureController.validateAndAddProfileFeatures(tfUploadProfileFeatures, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_FEATURE_FILE_UPLOAD_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_FEATURE_FILE_UPLOAD_ERROR_MESSAGE);
        }
    }

    @Test
    public void testSearchBucketProfile() throws Exception {
        List<TFOneRatePlanProfile> tfOneRatePlanProfiles = new ArrayList<>();
        TFOneRatePlanProfile tFOneRatePlanProfile = new TFOneRatePlanProfile();
        tFOneRatePlanProfile.setProfileId("5401");
        tfOneRatePlanProfiles.add(tFOneRatePlanProfile);
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        searchPlanModel.setDbEnv(DBENV);
        searchPlanModel.setServicePlanId("1501");
        when(tracfoneFeatureAction.searchBucketProfile(any(), any(), anyBoolean())).thenReturn(tfOneRatePlanProfiles);
        List<TFOneRatePlanProfile> filteredProfiles = tracfoneFeatureController.searchBucketProfile(searchPlanModel);
        assertEquals("[TFOneRatePlanProfile{profileId=5401, profileDescription=null, rpExtensionLinks=null, rpExtensionConfigs=null, buckets=null, features=null}]", filteredProfiles.toString());
    }

    @Test
    public void testSearchBucketProfile_whenException() {
        try {
            tracfoneFeatureController.searchBucketProfile(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_SEARCH_PROFILE_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_SEARCH_PROFILE_ERROR_MESSAGE);
        }
    }

    @Test
    public void testSearchChildBucketProfile() throws Exception {
        List<TFOneRatePlanProfile> tfOneRatePlanProfiles = new ArrayList<>();
        TFOneRatePlanProfile tFOneRatePlanProfile = new TFOneRatePlanProfile();
        tFOneRatePlanProfile.setProfileId("5401");
        tfOneRatePlanProfiles.add(tFOneRatePlanProfile);
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        searchPlanModel.setDbEnv(DBENV);
        searchPlanModel.setServicePlanId("1501");
        when(tracfoneFeatureAction.searchBucketProfile(any(), any(), anyBoolean())).thenReturn(tfOneRatePlanProfiles);
        List<TFOneRatePlanProfile> filteredProfiles = tracfoneFeatureController.searchChildBucketProfile(searchPlanModel);
        assertEquals("[TFOneRatePlanProfile{profileId=5401, profileDescription=null, rpExtensionLinks=null, rpExtensionConfigs=null, buckets=null, features=null}]", filteredProfiles.toString());
    }

    @Test
    public void testSearchChildBucketProfile_whenException() {
        try {
            tracfoneFeatureController.searchChildBucketProfile(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_SEARCH_PROFILE_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_SEARCH_PROFILE_ERROR_MESSAGE);
        }
    }

    @Test
    public void testGetChildBucketServicePlansForCopy() throws Exception {
        List<TFOneCarrierServicePlan> bucketServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan bucketServicePlan = new TFOneCarrierServicePlan();
        bucketServicePlan.setMktName("MKT_NAME");
        bucketServicePlan.setDescription("DESCRIPTION");
        bucketServicePlan.setCarrierName("CARRIER_NAME");
        bucketServicePlans.add(bucketServicePlan);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setProfileId("1501");
        when(tracfoneFeatureAction.getBucketServicePlansForCopy(anyString(), anyBoolean())).thenReturn(bucketServicePlans);
        List<TFOneCarrierServicePlan> response = tracfoneFeatureController.getChildBucketServicePlansForCopy(tracfoneOneSearchPlanModel);
        assertEquals("[TFOneCarrierServicePlan{carrierName='CARRIER_NAME', servicePlanId='null', mktName='MKT_NAME', description='DESCRIPTION', servicePlanPurchase='null', parentName='null', servicePlans=null}]", response.toString());
    }

    @Test
    public void testGetChildBucketServicePlansForCopy_whenException() throws Exception {
        String profileId = "1501";
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).getBucketServicePlansForCopy(null, true);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setProfileId(profileId);
        try {
            tracfoneFeatureController.getChildBucketServicePlansForCopy(tracfoneOneSearchPlanModel);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_GET_SERVICE_PLAN_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_GET_SERVICE_PLAN_ERROR_MESSAGE);
        }
    }

    @Test
    public void testGetBucketServicePlansForCopy() throws Exception {
        List<TFOneCarrierServicePlan> bucketServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan bucketServicePlan = new TFOneCarrierServicePlan();
        bucketServicePlan.setMktName("MKT_NAME");
        bucketServicePlan.setDescription("DESCRIPTION");
        bucketServicePlan.setCarrierName("CARRIER_NAME");
        bucketServicePlans.add(bucketServicePlan);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setProfileId("1501");
        tracfoneOneSearchPlanModel.setRatePlanName("RATE_PLAN_NAME");
        when(tracfoneFeatureAction.getBucketServicePlansForCopy(anyString(), anyBoolean())).thenReturn(bucketServicePlans);
        List<TFOneCarrierServicePlan> response = tracfoneFeatureController.getBucketServicePlansForCopy(tracfoneOneSearchPlanModel);
        assertEquals("[TFOneCarrierServicePlan{carrierName='CARRIER_NAME', servicePlanId='null', mktName='MKT_NAME', description='DESCRIPTION', servicePlanPurchase='null', parentName='null', servicePlans=null}]", response.toString());
    }

    @Test
    public void testGetBucketServicePlansForCopy_whenException() throws Exception {
        String profileId = "1501";
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).getBucketServicePlansForCopy(null, false);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setProfileId(profileId);
        try {
            tracfoneFeatureController.getBucketServicePlansForCopy(tracfoneOneSearchPlanModel);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_GET_SERVICE_PLAN_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_GET_SERVICE_PLAN_ERROR_MESSAGE);
        }
    }

    @Test
    public void testGetBucketChildPlans() throws Exception {
        List<TFOneChildPlan> childPlans = new ArrayList<>();
        TFOneChildPlan childPlan = new TFOneChildPlan();
        childPlan.setChildDescription("DESCRIPTION");
        childPlan.setChildPlanId("1000");
        childPlans.add(childPlan);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setProfileId("1501");
        tracfoneOneSearchPlanModel.setRatePlanName("RATE_PLAN_NAME");
        tracfoneOneSearchPlanModel.setServicePlanId("1000");
        when(tracfoneFeatureAction.getBucketChildPlans(anyString(), anyString(), anyString())).thenReturn(childPlans);
        List<TFOneChildPlan> allChildPlans = tracfoneFeatureController.getBucketChildPlans(tracfoneOneSearchPlanModel);
        assertEquals("[TFOneChildPlan{childPlanId=1000, childDescription=DESCRIPTION}]", allChildPlans.toString());
    }

    @Test
    public void testGetBucketChildPlans_whenException() throws Exception {
        String profileId = "1501";
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).getBucketChildPlans(null, profileId, null);

        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setProfileId(profileId);
        try {
            tracfoneFeatureController.getBucketChildPlans(tracfoneOneSearchPlanModel);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_VIEW_ALL_CHILD_PLANS_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_VIEW_ALL_CHILD_PLANS_ERROR_MESSAGE);
        }
    }

    @Test
    public void testGetAllLineStatusCodes() throws Exception {
        List<TFOneLineStatusCode> lineStatusCodes = new ArrayList<>();
        TFOneLineStatusCode lineStatusCode = new TFOneLineStatusCode();
        lineStatusCode.setDescription("DESCRIPTION");
        lineStatusCode.setLineStatusCode("STATUS_CODE");
        lineStatusCodes.add(lineStatusCode);
        when(tracfoneFeatureAction.getAllLineStatusCodes(anyString())).thenReturn(lineStatusCodes);
        List<TFOneLineStatusCode> response = tracfoneFeatureController.getAllLineStatusCodes(DBENV);
        assertEquals("[TFOneLineStatusCode{lineStatusCode='STATUS_CODE', description='DESCRIPTION'}]", response.toString());
    }

    @Test
    public void testGetAllLineStatusCodes_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).getAllLineStatusCodes(null);
        try {
            tracfoneFeatureController.getAllLineStatusCodes(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_VIEW_ALL_LINE_STATUS_CODES_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_VIEW_ALL_LINE_STATUS_CODES_ERROR_MESSAGE);
        }
    }

    @Test
    public void testInsertLineStatusCode() throws Exception {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DBENV);
        tfOneLineStatus.setDescription("DESCRIPTION");
        tfOneLineStatus.setLineStatusCode("100");
        when(tracfoneFeatureAction.insertLineStatusCode(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneFeatureController.insertLineStatusCode(tfOneLineStatus, 100);
        assertEquals("Success", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testInsertLineStatusCode_whenException() throws Exception {
        // In case a null object is passed
        try {
            tracfoneFeatureController.insertLineStatusCode(null, 100);
            fail();
        } catch (TracfoneOneException e) {
        }
        // Case the action throws a SQLException
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DBENV);
        tfOneLineStatus.setDescription("DESCRIPTION");
        tfOneLineStatus.setLineStatusCode("LINE_STATUS_CODE");
        try {
            tracfoneFeatureController.insertLineStatusCode(tfOneLineStatus, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_LINE_STATUS_CODE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_LINE_STATUS_CODE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateLineStatusCode() throws Exception {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DBENV);
        tfOneLineStatus.setDescription("DESCRIPTION");
        tfOneLineStatus.setLineStatusCode("100");
        when(tracfoneFeatureAction.updateLineStatusCode(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneFeatureController.updateLineStatusCode(tfOneLineStatus, 100);
        assertEquals("Success", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testUpdateLineStatusCode_whenException() throws Exception {
        // In case a null object is passed
        try {
            tracfoneFeatureController.updateLineStatusCode(null, 100);
            fail();
        } catch (TracfoneOneException e) {
        }
        // Case the action throws a SQLException
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DBENV);
        tfOneLineStatus.setDescription("DESCRIPTION");
        tfOneLineStatus.setLineStatusCode("LINE_STATUS_CODE");
        try {
            tracfoneFeatureController.updateLineStatusCode(tfOneLineStatus, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_LINE_STATUS_CODE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_LINE_STATUS_CODE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottleStatusCode() throws Exception {
        TracfoneOneThrottleStatusCode tfThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfThrottleStatusCode.setDbEnv(DBENV);
        tfThrottleStatusCode.setDescription("DESCRIPTION");
        when(tracfoneFeatureAction.insertThrottleStatusCode(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneFeatureController.insertThrottleStatusCode(tfThrottleStatusCode, 100);
        assertEquals("Success", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testInsertThrottleStatusCode_whenException() throws Exception {
        // In case a null object is passed
        try {
            tracfoneFeatureController.insertThrottleStatusCode(null, 100);
            fail();
        } catch (TracfoneOneException e) {
        }
        // Case the action throws a SQLException
        TracfoneOneThrottleStatusCode tfThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfThrottleStatusCode.setDbEnv(DBENV);
        tfThrottleStatusCode.setDescription("DESCRIPTION");
        try {
            tracfoneFeatureController.insertThrottleStatusCode(tfThrottleStatusCode, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_THROTTLE_STATUS_CODE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_THROTTLE_STATUS_CODE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testUpdateThrottleStatusCode() throws Exception {
        TracfoneOneThrottleStatusCode tfThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfThrottleStatusCode.setDbEnv(DBENV);
        tfThrottleStatusCode.setDescription("DESCRIPTION");
        when(tracfoneFeatureAction.updateThrottleStatusCode(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneFeatureController.updateThrottleStatusCode(tfThrottleStatusCode, 100);
        assertEquals("Success", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testUpdateThrottleStatusCode_whenException() throws Exception {
        // In case a null object is passed
        try {
            tracfoneFeatureController.updateThrottleStatusCode(null, 100);
            fail();
        } catch (TracfoneOneException e) {
        }
        // Case the action throws a SQLException
        TracfoneOneThrottleStatusCode tfThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfThrottleStatusCode.setDbEnv(DBENV);
        tfThrottleStatusCode.setDescription("DESCRIPTION");
        try {
            tracfoneFeatureController.updateThrottleStatusCode(tfThrottleStatusCode, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_THROTTLE_STATUS_CODE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_THROTTLE_STATUS_CODE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertFeatureRequirement() throws Exception {
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfFeatureRequirement.setDbEnv(DBENV);
        tfFeatureRequirement.setDescription("DESCRIPTION");
        when(tracfoneFeatureAction.insertFeatureRequirement(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneFeatureController.insertFeatureRequirement(tfFeatureRequirement, 100);
        assertEquals("Success", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testInsertFeatureRequirement_whenException() throws Exception {
        // In case a null object is passed
        try {
            tracfoneFeatureController.insertFeatureRequirement(null, 100);
            fail();
        } catch (TracfoneOneException e) {
        }
        // Case the action throws a SQLException
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfFeatureRequirement.setDbEnv(DBENV);
        tfFeatureRequirement.setDescription("DESCRIPTION");
        try {
            tracfoneFeatureController.insertFeatureRequirement(tfFeatureRequirement, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_FEATURE_REQUIREMENT_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_FEATURE_REQUIREMENT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateFeatureRequirement() throws Exception {
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfFeatureRequirement.setDbEnv(DBENV);
        tfFeatureRequirement.setDescription("DESCRIPTION");
        when(tracfoneFeatureAction.updateFeatureRequirement(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneFeatureController.updateFeatureRequirement(tfFeatureRequirement, 100);
        assertEquals("Success", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testUpdateFeatureRequirement_whenException() throws Exception {
        // In case a null object is passed
        try {
            tracfoneFeatureController.updateFeatureRequirement(null, 100);
            fail();
        } catch (TracfoneOneException e) {
        }
        // Case the action throws a SQLException
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfFeatureRequirement.setDbEnv(DBENV);
        tfFeatureRequirement.setDescription("DESCRIPTION");
        try {
            tracfoneFeatureController.updateFeatureRequirement(tfFeatureRequirement, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_FEATURE_REQUIREMENT_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_FEATURE_REQUIREMENT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllFeatureRequirements() throws Exception {
        List<TFOneFeatureRequirement> tfFeatureRequirements = new ArrayList<>();
        TFOneFeatureRequirement tfOneFeatureRequirement = new TFOneFeatureRequirement();
        tfOneFeatureRequirement.setDescription("DESCRIPTION");
        tfOneFeatureRequirement.setFeatureRequirement("FEATURE_REQUIREMENT");
        tfFeatureRequirements.add(tfOneFeatureRequirement);
        when(tracfoneFeatureAction.getAllFeatureRequirements(anyString())).thenReturn(tfFeatureRequirements);
        List<TFOneFeatureRequirement> response = tracfoneFeatureController.getAllFeatureRequirements(DBENV);
        assertEquals("[TFOneFeatureRequirement{featureRequirement='FEATURE_REQUIREMENT', description='DESCRIPTION'}]", response.toString());
    }

    @Test
    public void testGetAllFeatureRequirements_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).getAllFeatureRequirements(any());
        try {
            tracfoneFeatureController.getAllFeatureRequirements(DBENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_VIEW_FEATURE_REQUIREMENT_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_VIEW_FEATURE_REQUIREMENT_ERROR_MESSAGE);
        }
    }


    @Test
    public void testGetAllThrottleStatusCodes() throws Exception {
        List<TFOneThrottleStatusCode> throttleStatusCodes = new ArrayList<>();
        TFOneThrottleStatusCode throttleStatusCode = new TFOneThrottleStatusCode();
        throttleStatusCode.setDescription("DESCRIPTION");
        throttleStatusCodes.add(throttleStatusCode);
        when(tracfoneFeatureAction.getAllThrottleStatusCodes(anyString())).thenReturn(throttleStatusCodes);
        List<TFOneThrottleStatusCode> response = tracfoneFeatureController.getAllThrottleStatusCodes(DBENV);
        assertEquals("[TFOneThrottleStatusCode{throttleStatusCode='null', description='DESCRIPTION'}]", response.toString());
    }

    @Test
    public void testGetAllThrottleStatusCodes_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).getAllThrottleStatusCodes(null);
        try {
            tracfoneFeatureController.getAllThrottleStatusCodes(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_VIEW_ALL_THROTTLE_STATUS_CODES_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_VIEW_ALL_THROTTLE_STATUS_CODES_ERROR_MESSAGE);
        }
    }

    @Test
    public void testGetAllCarrierIds() throws Exception {
        List<TFOneCarrier> tfOneCarriers = new ArrayList<>();
        TFOneCarrier carrier = new TFOneCarrier();
        carrier.setCarrierId("100");
        carrier.setObjId("200");
        carrier.setSubmarketName("T-MOBILE PREPAID");
        tfOneCarriers.add(carrier);
        when(tracfoneFeatureAction.getAllCarrierIds(any(), any(), any())).thenReturn(tfOneCarriers);
        List<TFOneCarrier> response = tracfoneFeatureController.getAllCarrierIds(DBENV, "T-MOBILE", "100");
        assertEquals("[TFOneCarrier{objId='200', carrierId='100', submarketName='T-MOBILE PREPAID', submarketOf='null', city='null', state='null', tapereturnCharge='null', countryCode='null', activelinePercent='null', status='null', ldProvider='null', ldAccount='null', ldPicCode='null', ratePlan='null', dummyEsn='null', billDate='null', voiceMail='null', vmCode='null', vmPackage='null', callerId='null', idCode='null', idPackage='null', callWaiting='null', cwCode='null', cwPackage='null', reactTechnology='null', reactAnalog='null', actTechnology='null', actAnalog='null', digitalRatePlan='null', digitalFeature='null', prlPreLoaded='null', carrier2CarrierGroup='null', tapereturnAddr2Address='null', carrier2Provider='null', carrier2Address='null', carrier2Personality='null', carrier2Rule='null', carrier2CarrScript='null', specialMkt='null', newAnalogPlan='null', newDigitalPlan='null', sms='null', smsCode='null', smsPackage='null', vmSetUpLandLine='null', carrier2RulesCdma='null', carrier2RulesGsm='null', carrier2RulesTdma='null', dataService='null', automated='null'}]", response.toString());
    }

    @Test
    public void testGetAllCarrierIds_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).getAllCarrierIds(any(), any(), any());
        try {
            tracfoneFeatureController.getAllCarrierIds(DBENV, "T-MOBILE", "100");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_GET_CARRIER_IDS_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_GET_CARRIER_IDS_ERROR_MESSAGE);
        }
    }

    @Test
    public void testDeleteFeatureRequirement() throws Exception {
        TracfoneOneFeatureRequirement tfOneFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfOneFeatureRequirement.setDbEnv(DBENV);
        tfOneFeatureRequirement.setFeatureRequirement("SAMPLE");
        when(tracfoneFeatureAction.checkFeatureRequirementDependencies(any())).thenReturn(false);
        when(tracfoneFeatureAction.deleteFeatureRequirement(any(TracfoneOneFeatureRequirement.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneFeatureController.deleteFeatureRequirement(tfOneFeatureRequirement, 1000);
        assertEquals("Success", response.getStatus());
        assertEquals(tFOneGeneralResponse.getMessage(), response.getMessage());
    }

    @Test
    public void testDeleteFeatureRequirement_whenCheckAncillaryCodeDependencyIsTrue() throws Exception {
        TracfoneOneFeatureRequirement tfOneFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfOneFeatureRequirement.setDbEnv(DBENV);
        tfOneFeatureRequirement.setFeatureRequirement("SAMPLE");
        when(tracfoneFeatureAction.checkFeatureRequirementDependencies(any(TracfoneOneFeatureRequirement.class))).thenReturn(true);
        try {
            tracfoneFeatureController.deleteFeatureRequirement(tfOneFeatureRequirement, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_FEATURE_REQUIREMENT_DEPENDENCY_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_FEATURE_REQUIREMENT_DEPENDENCY_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteFeatureRequirement_whenException() throws Exception {
        TracfoneOneFeatureRequirement tfOneFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfOneFeatureRequirement.setDbEnv(DBENV);
        tfOneFeatureRequirement.setFeatureRequirement("SAMPLE");
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).deleteFeatureRequirement(any(TracfoneOneFeatureRequirement.class), anyInt());
        try {
            tracfoneFeatureController.deleteFeatureRequirement(tfOneFeatureRequirement, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_FEATURE_REQUIREMENT_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_FEATURE_REQUIREMENT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchProfileFeatures() throws Exception {
        TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel = new TracfoneOneSearchProfileModel();
        tracfoneOneSearchProfileModel.setDbEnv(DBENV);
        tracfoneOneSearchProfileModel.setFeatureValue("THRWS8");

        List<TFOneRatePlanExtensionConfig> tfOneFeatures = new ArrayList<>();
        TFOneRatePlanExtensionConfig tfOneFeature = new TFOneRatePlanExtensionConfig();
        tfOneFeature.setProfileId("4385");
        tfOneFeature.setFeatureName("Data Throttle");
        tfOneFeature.setFeatureValue("THRWS8");
        tfOneFeature.setFeatureRequirement("ADD");
        tfOneFeature.setToggleFlag("Y");
        tfOneFeature.setRestrictSUIFlag("Y");
        tfOneFeature.setDisplaySUIFlag("Y");
        tfOneFeatures.add(tfOneFeature);

        when(tracfoneFeatureAction.searchProfileFeatures(any())).thenReturn(tfOneFeatures);
        List<TFOneRatePlanExtensionConfig> response = tracfoneFeatureController.searchProfileFeatures(tracfoneOneSearchProfileModel);
        assertEquals("[TFOneRatePlanExtensionConfig{objid=null, profileId=4385, profileDescription=null, featureName=Data Throttle, featureValue=THRWS8, featureRequirement=ADD, toggleFlag=Y, notes=null, displaySUIFlag=Y, restrictSUIFlag=Y, rowNum=null, errorMessages={}, dbEnv=null}]", response.toString());
    }

    @Test
    public void testSearchProfileFeatures_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).searchProfileFeatures(any());
        TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel = new TracfoneOneSearchProfileModel();
        try {
            tracfoneFeatureController.searchProfileFeatures(tracfoneOneSearchProfileModel);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_SEARCH_PROFILE_FEATURES_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_SEARCH_PROFILE_FEATURES_ERROR_MESSAGE);
        }
    }

    @Test
    public void testGetAllFeatureValues() throws Exception {
        List<String> featureValues = new ArrayList<>();
        featureValues.add("BLKBRY,THRWS8");
        when(tracfoneFeatureAction.getAllFeatureValues(any())).thenReturn(featureValues);
        List<String> response = tracfoneFeatureController.getAllFeatureValues(DBENV);
        assertEquals("[BLKBRY,THRWS8]", response.toString());
    }

    @Test
    public void testGetAllFeatureValues_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).getAllFeatureValues(any());
        try {
            tracfoneFeatureController.getAllFeatureValues(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_VIEW_FEATURE_VALUE_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_VIEW_FEATURE_VALUE_ERROR_MESSAGE);
        }
    }

    @Test
    public void testBulkUpdateProfileFeatures() throws Exception {
        List<String> featureNames = new ArrayList<>();
        when(tracfoneFeatureAction.findExistingMasterFeatures(any(), any())).thenReturn(featureNames);
        doNothing().when(tracfoneFeatureAction).insertMasterFeature(any(), any(), anyInt());
        when(tracfoneFeatureAction.bulkUpdateProfileFeatures(any(TracfoneOneRatePlanExtensionConfig.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneFeatureController.bulkUpdateProfileFeatures(tfOneRpExtensionConfig, 100);
        assertEquals("Success", response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testBulkUpdateProfileFeatures_whenException() throws Exception {
        // In case a null object is passed
        try {
            tracfoneFeatureController.bulkUpdateProfileFeatures(null, 100);
            fail();
        } catch (NullPointerException e) {
        }

        // Case the action throws a SQLException
        List<String> featureNames = new ArrayList<>();
        when(tracfoneFeatureAction.findExistingMasterFeatures(any(), any())).thenReturn(featureNames);
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).bulkUpdateProfileFeatures(any(), anyInt());
        TracfoneOneRatePlanExtensionConfig tracfoneOneRatePlanExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        tracfoneOneRatePlanExtensionConfig.setFeatureName("BLKBRY");
        try {
            tracfoneFeatureController.bulkUpdateProfileFeatures(tracfoneOneRatePlanExtensionConfig, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_BULK_UPDATE_PROFILE_FEATURES_CODE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_BULK_UPDATE_PROFILE_FEATURES_ERROR_MESSAGE, e.getErrorMessage());
        }

        //In case the DBENV property was not set on the object
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).findExistingMasterFeatures(any(), any());
        try {
            tracfoneFeatureController.bulkUpdateProfileFeatures(tfOneRpExtensionConfig, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_MASTER_FEATURE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_MASTER_FEATURE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}
