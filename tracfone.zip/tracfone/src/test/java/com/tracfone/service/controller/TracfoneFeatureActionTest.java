package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneFeatureRequirement;
import com.tracfone.service.model.request.TracfoneOneLineStatusCode;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionConfig;
import com.tracfone.service.model.request.TracfoneOneRatePlanProfile;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneThrottleStatusCode;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneFeatureRequirement;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneLineStatusCode;
import com.tracfone.service.model.response.TFOneRPFeatureNameList;
import com.tracfone.service.model.response.TFOneRatePlanExtensionConfig;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import com.tracfone.service.model.response.TFOneThrottleStatusCode;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_RP_EXTENSION_CONFIG_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_RP_EXTENSION_CONFIG_ERROR;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneFeatureActionTest {
    @InjectMocks
    private TracfoneFeatureAction tracfoneFeatureAction;
    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private ResultSet resultSet;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    private TFOneGeneralResponse tfOneGeneralResponse;
    private static final String DB_ENV = "DBENV";

    @Before
    public void setUp() throws Exception {
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

    @Test
    public void testGetAllMasterFeatures() throws TracfoneOneException, SQLException {
        List<TFOneRPFeatureNameList> tfOneFeatureMasters;
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn("FEATURE 1").when(resultSet).getString(any());
        tfOneFeatureMasters = tracfoneFeatureAction.getAllMasterFeatures(DB_ENV);
        assertEquals("[TFOneRPFeatureNameList{featureName=FEATURE 1}]", tfOneFeatureMasters.toString());
    }

    @Test
    public void testGetAllMasterFeatures_whenException() throws SQLException, TracfoneOneException {
        try {
            tracfoneFeatureAction.getAllMasterFeatures(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneFeatureAction.getAllMasterFeatures(DB_ENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertRpExtensionConfig() throws TracfoneOneException, SQLException {
        List<TracfoneOneRatePlanExtensionConfig> tfOneRpExtensionConfigs = new ArrayList<>();
        tfOneRpExtensionConfigs.add(getTracfoneOneRatePlanExtensionConfig());
        doReturn(true).doReturn(true).doReturn(false).doReturn(true).doReturn(false).when(resultSet).next();
        doReturn("1").when(resultSet).getString(anyString());
        int[] count = new int[]{1, 2};
        when(stmt.executeBatch()).thenReturn(count);
        List<String> rpExtensionConfigObjids = new ArrayList<>();
        rpExtensionConfigObjids.add("1");
        tfOneGeneralResponse = tracfoneFeatureAction.insertRpExtensionConfig(tfOneRpExtensionConfigs, 123, "987");
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), rpExtensionConfigObjids.toString());
    }

    @Test
    public void testInsertRpExtensionConfig_whenException() throws TracfoneOneException, SQLException {
        // When NPE
        List<TracfoneOneRatePlanExtensionConfig> tfOneRpExtensionConfigs = null;
        try {
            tracfoneFeatureAction.insertRpExtensionConfig(tfOneRpExtensionConfigs, 123, "987");
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        tfOneRpExtensionConfigs = new ArrayList<>();
        tfOneRpExtensionConfigs.add(getTracfoneOneRatePlanExtensionConfig());
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneFeatureAction.insertRpExtensionConfig(tfOneRpExtensionConfigs, 123, "987");
            fail("Throws TracfoneOneExcepton");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllProfileFeatures() throws TracfoneOneException, SQLException {
        TracfoneOneSearchProfileModel selectedRateProfile = new TracfoneOneSearchProfileModel();
        selectedRateProfile.setDbEnv(DB_ENV);
        selectedRateProfile.setProfileId("100");
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn("1").when(resultSet).getString(anyString());
        List<TFOneRatePlanExtensionConfig> tfOneProfileFeatures = tracfoneFeatureAction.getAllProfileFeatures(selectedRateProfile);
        assertNotNull(tfOneProfileFeatures);
        assertEquals("[TFOneRatePlanExtensionConfig{objid=1, profileId=1, profileDescription=null, featureName=1, featureValue=1, featureRequirement=1, toggleFlag=1, notes=null, displaySUIFlag=1, restrictSUIFlag=1, rowNum=null, errorMessages={}, dbEnv=null}]", tfOneProfileFeatures.toString());
    }

    @Test
    public void testGetAllProfileFeatures_whenException() throws SQLException {
        TracfoneOneSearchProfileModel selectedRateProfile = new TracfoneOneSearchProfileModel();
        selectedRateProfile.setDbEnv(DB_ENV);
        selectedRateProfile.setProfileId("100");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneFeatureAction.getAllProfileFeatures(selectedRateProfile);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteRpExtensionConfigs() throws TracfoneOneException {
        List<String> toBeDeletedIds = new ArrayList<>();
        toBeDeletedIds.add("1");
        toBeDeletedIds.add("2");
        tfOneGeneralResponse = tracfoneFeatureAction.deleteRpExtensionConfigs(DB_ENV, toBeDeletedIds, 1);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), toBeDeletedIds.toString());
    }

    @Test
    public void testDeleteRpExtensionConfigs_whenException() throws SQLException {
        List<String> toBeDeletedIds = new ArrayList<>();
        toBeDeletedIds.add("1");
        toBeDeletedIds.add("2");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneFeatureAction.deleteRpExtensionConfigs(DB_ENV, toBeDeletedIds, 1);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateRpExtensionConfig() throws TracfoneOneException, SQLException {
        TracfoneOneRatePlanExtensionConfig tracfoneOneRatePlanExtensionConfig = getTracfoneOneRatePlanExtensionConfig();
        tracfoneOneRatePlanExtensionConfig.setNotes("");
        doReturn(true).doReturn(false).when(resultSet).next();
        tfOneGeneralResponse = tracfoneFeatureAction.updateRpExtensionConfig(tracfoneOneRatePlanExtensionConfig, 1);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tracfoneOneRatePlanExtensionConfig.getObjid());
    }

    @Test
    public void testUpdateRpExtensionConfig_whenException_ForElse() throws SQLException {
        doReturn(true).doReturn(false).when(resultSet).next();
        when(resultSet.getString(anyString())).thenReturn("dummy");
        TracfoneOneRatePlanExtensionConfig tracfoneOneRatePlanExtensionConfig = getTracfoneOneRatePlanExtensionConfig();
        tracfoneOneRatePlanExtensionConfig.setNotes("TEST NOTES");
        try {
            tracfoneFeatureAction.updateRpExtensionConfig(tracfoneOneRatePlanExtensionConfig, 1);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DUPLICATE_RP_EXTENSION_CONFIG_ERROR, e.getErrorCode());
        }
    }

    @Test
    public void testUpdateRpExtensionConfig_whenException() throws SQLException {
        TracfoneOneRatePlanExtensionConfig tracfoneOneRatePlanExtensionConfig = getTracfoneOneRatePlanExtensionConfig();
        tracfoneOneRatePlanExtensionConfig.setNotes("TEST NOTES");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneFeatureAction.updateRpExtensionConfig(tracfoneOneRatePlanExtensionConfig, 1);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testFindExistingMasterFeatures() throws SQLException, TracfoneOneException {
        TracfoneOneRatePlanExtensionConfig profileFeature = new TracfoneOneRatePlanExtensionConfig();
        profileFeature.setDbEnv(DB_ENV);
        profileFeature.setFeatureName("feature");
        doReturn(true).doReturn(false).when(resultSet).next();
        Set<String> featureNames = new HashSet<>();
        featureNames.add("FEATURE_NAME1");
        featureNames.add("FEATURE_NAME2");
        assertNotNull(tracfoneFeatureAction.findExistingMasterFeatures(DB_ENV, featureNames));
    }

    @Test
    public void testFindExistingMasterFeatures_whenException() throws SQLException, TracfoneOneException {
        try {
            tracfoneFeatureAction.findExistingMasterFeatures(null, null);
            fail();
        } catch (NullPointerException e) {
            // exception
        }

        TracfoneOneRatePlanExtensionConfig profileFeature = new TracfoneOneRatePlanExtensionConfig();
        profileFeature.setDbEnv(DB_ENV);
        // When SQLException is thrown
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            Set<String> featureNames = new HashSet<>();
            tracfoneFeatureAction.findExistingMasterFeatures(DB_ENV, featureNames);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertMasterFeature() throws TracfoneOneException, SQLException {
        TracfoneOneRatePlanExtensionConfig oneRatePlanExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        oneRatePlanExtensionConfig.setDbEnv(DB_ENV);
        oneRatePlanExtensionConfig.setFeatureName("feature");
        Set<String> featureNames = new HashSet<>();
        featureNames.add("FEATURE_NAME1");
        featureNames.add("FEATURE_NAME2");
        tracfoneFeatureAction.insertMasterFeature(DB_ENV, featureNames, 1);
        verify(stmt, times(1)).executeBatch();
    }

    @Test
    public void testInsertMasterFeature_withException() throws SQLException {
        TracfoneOneRatePlanExtensionConfig oneRatePlanExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        oneRatePlanExtensionConfig.setDbEnv(DB_ENV);
        doThrow(SQLException.class).when(stmt).executeBatch();
        try {
            Set<String> featureNames = new HashSet<>();
            tracfoneFeatureAction.insertMasterFeature(DB_ENV, featureNames, 1);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    private TracfoneOneRatePlanExtensionConfig getTracfoneOneRatePlanExtensionConfig() {
        TracfoneOneRatePlanExtensionConfig tracfoneOneRatePlanExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        tracfoneOneRatePlanExtensionConfig.setDbEnv(DB_ENV);
        tracfoneOneRatePlanExtensionConfig.setDisplaySUIFlag("y");
        tracfoneOneRatePlanExtensionConfig.setFeatureName("feature");
        tracfoneOneRatePlanExtensionConfig.setFeatureRequirement("test");
        tracfoneOneRatePlanExtensionConfig.setFeatureValue("123");
        tracfoneOneRatePlanExtensionConfig.setObjid("1");
        tracfoneOneRatePlanExtensionConfig.setProfileId("1");
        tracfoneOneRatePlanExtensionConfig.setRestrictSUIFlag("y");
        tracfoneOneRatePlanExtensionConfig.setToggleFlag("y");
        tracfoneOneRatePlanExtensionConfig.setNotes("notes");
        return tracfoneOneRatePlanExtensionConfig;
    }

    @Test
    public void testViewRpExtensionConfig() throws TracfoneOneException, SQLException {
        TracfoneOneRatePlanExtensionConfig searchConfig = new TracfoneOneRatePlanExtensionConfig();
        searchConfig.setDbEnv(DB_ENV);
        searchConfig.setProfileId("1501");
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn("FEATURE 1").when(resultSet).getString(any());
        List<TFOneRatePlanExtensionConfig> tfOneRpExtensionConfigs = tracfoneFeatureAction.viewRpExtensionConfig(searchConfig);
        assertEquals("[TFOneRatePlanExtensionConfig{objid=FEATURE 1, profileId=null, profileDescription=null, featureName=FEATURE 1, featureValue=FEATURE 1, featureRequirement=null, toggleFlag=null, notes=null, displaySUIFlag=null, restrictSUIFlag=null, rowNum=null, errorMessages={}, dbEnv=null}]", tfOneRpExtensionConfigs.toString());
    }

    @Test
    public void testViewRpExtensionConfig_whenException() throws SQLException, TracfoneOneException {
        try {
            tracfoneFeatureAction.viewRpExtensionConfig(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        TracfoneOneRatePlanExtensionConfig searchConfig = new TracfoneOneRatePlanExtensionConfig();
        searchConfig.setDbEnv(DB_ENV);
        searchConfig.setProfileId("1501");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneFeatureAction.viewRpExtensionConfig(searchConfig);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchBucketProfile() throws TracfoneOneException, SQLException {
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn("PROFILE 1").when(resultSet).getString(any());
        List<TFOneRatePlanProfile> tfFilteredProfiles = tracfoneFeatureAction.searchBucketProfile(DB_ENV, "1501", true);
        assertEquals("[TFOneRatePlanProfile{profileId=PROFILE 1, profileDescription=PROFILE 1, rpExtensionLinks=null, rpExtensionConfigs=null, buckets=null, features=null}]", tfFilteredProfiles.toString());
    }

    @Test
    public void testSearchBucketProfile_whenException() throws SQLException, TracfoneOneException {
        try {
            tracfoneFeatureAction.searchBucketProfile(null, null, true);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneFeatureAction.searchBucketProfile(DB_ENV, "1501", true);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetBucketServicePlansForCopy() throws TracfoneOneException, SQLException {
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn("SERVICE_PLAN 1").when(resultSet).getString(any());
        List<TFOneCarrierServicePlan> tfOneCarrierServicePlans = tracfoneFeatureAction.getBucketServicePlansForCopy(DB_ENV, true);
        assertEquals("[TFOneCarrierServicePlan{carrierName='null', servicePlanId='SERVICE_PLAN 1', mktName='SERVICE_PLAN 1', description='null', servicePlanPurchase='null', parentName='null', servicePlans=null}]", tfOneCarrierServicePlans.toString());
    }

    @Test
    public void testGetBucketServicePlansForCopy_whenException() throws SQLException, TracfoneOneException {
        try {
            tracfoneFeatureAction.getBucketServicePlansForCopy(null, true);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneFeatureAction.getBucketServicePlansForCopy(DB_ENV, true);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetBucketChildPlans() throws TracfoneOneException, SQLException {
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn("CHILD_PLAN 1").when(resultSet).getString(any());
        List<TFOneChildPlan> tfOneChildPlans = tracfoneFeatureAction.getBucketChildPlans(DB_ENV, "1501", "1000");
        assertEquals("[TFOneChildPlan{childPlanId=CHILD_PLAN 1, childDescription=CHILD_PLAN 1}]", tfOneChildPlans.toString());
    }

    @Test
    public void testGetBucketChildPlans_whenException() throws SQLException, TracfoneOneException {
        try {
            tracfoneFeatureAction.getBucketChildPlans(null, null, null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneFeatureAction.getBucketChildPlans(DB_ENV, "1501", "1000");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllLineStatusCodes() throws TracfoneOneException, SQLException {
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn("LINE_STATUS_CODE 1").when(resultSet).getString(any());
        List<TFOneLineStatusCode> lineStatusCodes = tracfoneFeatureAction.getAllLineStatusCodes(DB_ENV);
        assertEquals("[TFOneLineStatusCode{lineStatusCode='LINE_STATUS_CODE 1', description='LINE_STATUS_CODE 1'}]", lineStatusCodes.toString());
    }

    @Test
    public void testGetAllLineStatusCodes_whenException() throws SQLException, TracfoneOneException {
        try {
            tracfoneFeatureAction.getAllLineStatusCodes(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneFeatureAction.getAllLineStatusCodes(DB_ENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertLineStatusCode() throws TracfoneOneException {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DB_ENV);
        tfOneLineStatus.setDescription("DESCRIPTION");
        tfOneLineStatus.setLineStatusCode("100");
        TFOneGeneralResponse response = tracfoneFeatureAction.insertLineStatusCode(tfOneLineStatus, 100);
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testInsertLineStatusCode_withException() throws SQLException {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DB_ENV);
        tfOneLineStatus.setDescription("DESCRIPTION");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneFeatureAction.insertLineStatusCode(tfOneLineStatus, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateLineStatusCode() throws TracfoneOneException {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DB_ENV);
        tfOneLineStatus.setDescription("DESCRIPTION");
        tfOneLineStatus.setLineStatusCode("100");
        TFOneGeneralResponse response = tracfoneFeatureAction.updateLineStatusCode(tfOneLineStatus, 100);
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testUpdateLineStatusCode_withException() throws SQLException {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DB_ENV);
        tfOneLineStatus.setDescription("DESCRIPTION");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneFeatureAction.updateLineStatusCode(tfOneLineStatus, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllThrottleStatusCodes() throws TracfoneOneException, SQLException {
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn("LINE_STATUS_CODE 1").when(resultSet).getString(any());
        List<TFOneThrottleStatusCode> throttleStatusCodes = tracfoneFeatureAction.getAllThrottleStatusCodes(DB_ENV);
        assertEquals("[TFOneThrottleStatusCode{throttleStatusCode='LINE_STATUS_CODE 1', description='LINE_STATUS_CODE 1'}]", throttleStatusCodes.toString());
    }

    @Test
    public void testGetAllThrottleStatusCodes_whenException() throws SQLException, TracfoneOneException {
        try {
            tracfoneFeatureAction.getAllThrottleStatusCodes(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneFeatureAction.getAllThrottleStatusCodes(DB_ENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottleStatusCode() throws TracfoneOneException {
        TracfoneOneThrottleStatusCode tfThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfThrottleStatusCode.setDbEnv(DB_ENV);
        tfThrottleStatusCode.setDescription("DESCRIPTION");
        tfThrottleStatusCode.setThrottleStatusCode("100");
        TFOneGeneralResponse response = tracfoneFeatureAction.insertThrottleStatusCode(tfThrottleStatusCode, 100);
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testInsertThrottleStatusCode_withException() throws SQLException {
        TracfoneOneThrottleStatusCode tfThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfThrottleStatusCode.setDbEnv(DB_ENV);
        tfThrottleStatusCode.setDescription("DESCRIPTION");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneFeatureAction.insertThrottleStatusCode(tfThrottleStatusCode, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateThrottleStatusCode() throws TracfoneOneException {
        TracfoneOneThrottleStatusCode tfThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfThrottleStatusCode.setDbEnv(DB_ENV);
        tfThrottleStatusCode.setDescription("DESCRIPTION");
        tfThrottleStatusCode.setThrottleStatusCode("100");
        TFOneGeneralResponse response = tracfoneFeatureAction.updateThrottleStatusCode(tfThrottleStatusCode, 100);
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testUpdateThrottleStatusCode_withException() throws SQLException {
        TracfoneOneThrottleStatusCode tfThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfThrottleStatusCode.setDbEnv(DB_ENV);
        tfThrottleStatusCode.setDescription("DESCRIPTION");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneFeatureAction.updateThrottleStatusCode(tfThrottleStatusCode, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertFeatureRequirement() throws TracfoneOneException {
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfFeatureRequirement.setDbEnv(DB_ENV);
        tfFeatureRequirement.setDescription("DESCRIPTION");
        tfFeatureRequirement.setFeatureRequirement("100");
        TFOneGeneralResponse response = tracfoneFeatureAction.insertFeatureRequirement(tfFeatureRequirement, 100);
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testInsertFeatureRequirement_withException() throws SQLException {
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfFeatureRequirement.setDbEnv(DB_ENV);
        tfFeatureRequirement.setDescription("DESCRIPTION");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneFeatureAction.insertFeatureRequirement(tfFeatureRequirement, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateFeatureRequirement() throws TracfoneOneException {
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfFeatureRequirement.setDbEnv(DB_ENV);
        tfFeatureRequirement.setDescription("DESCRIPTION");
        tfFeatureRequirement.setFeatureRequirement("100");
        TFOneGeneralResponse response = tracfoneFeatureAction.updateFeatureRequirement(tfFeatureRequirement, 100);
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testUpdateFeatureRequirement_withException() throws SQLException {
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfFeatureRequirement.setDbEnv(DB_ENV);
        tfFeatureRequirement.setDescription("DESCRIPTION");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneFeatureAction.updateFeatureRequirement(tfFeatureRequirement, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllFeatureRequirements() throws TracfoneOneException, SQLException {
        List<TFOneFeatureRequirement> tfFeatureRequirements = new ArrayList<>();
        TFOneFeatureRequirement tfOneFeatureRequirement = new TFOneFeatureRequirement();
        tfOneFeatureRequirement.setDescription("DESCRIPTION");
        tfOneFeatureRequirement.setFeatureRequirement("FEATURE_REQUIREMENT");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        tfFeatureRequirements.add(tfOneFeatureRequirement);
        List<TFOneFeatureRequirement> response = tracfoneFeatureAction.getAllFeatureRequirements(DB_ENV);
        assertEquals("[TFOneFeatureRequirement{featureRequirement='null', description='null'}]", response.toString());
    }

    @Test
    public void testGetAllFeatureRequirements_withException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneFeatureAction.getAllFeatureRequirements(DB_ENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllCarrierIds() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("200").thenReturn("100").thenReturn("T-MOBILE PREPAID");
        List<TFOneCarrier> carrierIds = tracfoneFeatureAction.getAllCarrierIds(DB_ENV, "T-MOBILE", "100");
        assertEquals("[TFOneCarrier{objId='200', carrierId='100', submarketName='T-MOBILE PREPAID', submarketOf='null', city='null', state='null', tapereturnCharge='null', countryCode='null', activelinePercent='null', status='null', ldProvider='null', ldAccount='null', ldPicCode='null', ratePlan='null', dummyEsn='null', billDate='null', voiceMail='null', vmCode='null', vmPackage='null', callerId='null', idCode='null', idPackage='null', callWaiting='null', cwCode='null', cwPackage='null', reactTechnology='null', reactAnalog='null', actTechnology='null', actAnalog='null', digitalRatePlan='null', digitalFeature='null', prlPreLoaded='null', carrier2CarrierGroup='null', tapereturnAddr2Address='null', carrier2Provider='null', carrier2Address='null', carrier2Personality='null', carrier2Rule='null', carrier2CarrScript='null', specialMkt='null', newAnalogPlan='null', newDigitalPlan='null', sms='null', smsCode='null', smsPackage='null', vmSetUpLandLine='null', carrier2RulesCdma='null', carrier2RulesGsm='null', carrier2RulesTdma='null', dataService='null', automated='null'}]", carrierIds.toString());
    }

    @Test
    public void testGetAllCarrierIds_whenException() throws SQLException, TracfoneOneException {
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneFeatureAction.getAllCarrierIds(DB_ENV, "T-MOBILE", "100");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteFeatureRequirement() throws TracfoneOneException {
        TracfoneOneFeatureRequirement tfOneFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfOneFeatureRequirement.setDbEnv(DB_ENV);
        tfOneFeatureRequirement.setFeatureRequirement("FEATURE_REQUIREMENT");
        tfOneGeneralResponse = tracfoneFeatureAction.deleteFeatureRequirement(tfOneFeatureRequirement, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfOneFeatureRequirement.getFeatureRequirement());
    }

    @Test
    public void testDeleteFeatureRequirement_whenException() throws TracfoneOneException, SQLException {
        // When null is passed
        try {
            tracfoneFeatureAction.deleteFeatureRequirement(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        // When SQLException is thrown
        TracfoneOneFeatureRequirement tfOneFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfOneFeatureRequirement.setDbEnv(DB_ENV);
        tfOneFeatureRequirement.setFeatureRequirement("FEATURE_REQUIREMENT");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneFeatureAction.deleteFeatureRequirement(tfOneFeatureRequirement, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void checkFeatureRequirementDependencies() throws TracfoneOneException, SQLException {
        boolean dependencyExists = false;
        int count = 1;
        TracfoneOneFeatureRequirement tfOneFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfOneFeatureRequirement.setDbEnv(DB_ENV);
        tfOneFeatureRequirement.setFeatureRequirement("FEATURE_REQUIREMENT");
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn(count).when(resultSet).getInt(1);
        dependencyExists = tracfoneFeatureAction.checkFeatureRequirementDependencies(tfOneFeatureRequirement);
        assertTrue(dependencyExists);
    }

    @Test
    public void testCheckChildPlanDependencies_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        boolean dependencyExists = false;
        try {
            dependencyExists = tracfoneFeatureAction.checkFeatureRequirementDependencies(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneFeatureRequirement tfOneFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfOneFeatureRequirement.setDbEnv(DB_ENV);
        tfOneFeatureRequirement.setFeatureRequirement("FEATURE_REQUIREMENT");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneFeatureAction.checkFeatureRequirementDependencies(tfOneFeatureRequirement);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllFeatureValuesByProfileId() throws TracfoneOneException, SQLException {
        TracfoneOneRatePlanExtensionConfig tfExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        tfExtensionConfig.setDbEnv(DB_ENV);
        tfExtensionConfig.setProfileId("PROFILE_ID");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("FEATURE_VALUE");
        Set<String> featureValues = tracfoneFeatureAction.getAllFeatureValuesByProfileId(tfExtensionConfig);
        assertEquals("[FEATURE_VALUE]", featureValues.toString());
    }

    @Test
    public void testGetAllFeatureValuesByProfileId_whenException() throws SQLException {
        TracfoneOneRatePlanExtensionConfig tfExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        tfExtensionConfig.setDbEnv(DB_ENV);
        tfExtensionConfig.setProfileId("PROFILE_ID");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneFeatureAction.getAllFeatureValuesByProfileId(tfExtensionConfig);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchProfileFeatures() throws TracfoneOneException, SQLException {
        TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel = new TracfoneOneSearchProfileModel();
        tracfoneOneSearchProfileModel.setDbEnv(DB_ENV);
        tracfoneOneSearchProfileModel.setFeatureValue("BLKBRY,WHAOA");
        tracfoneOneSearchProfileModel.setFeatureName("BLACK BERRY");
        tracfoneOneSearchProfileModel.setRatePlan("WHS");
        tracfoneOneSearchProfileModel.setProfileId("25");
        tracfoneOneSearchProfileModel.setProfileDesc("DESC");
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn("1").when(resultSet).getString(any());
        List<TFOneRatePlanExtensionConfig> tfOneFeatures = tracfoneFeatureAction.searchProfileFeatures(tracfoneOneSearchProfileModel);
        assertEquals("[TFOneRatePlanExtensionConfig{objid=1, profileId=1, profileDescription=1, featureName=1, featureValue=1, featureRequirement=1, toggleFlag=1, notes=1, displaySUIFlag=1, restrictSUIFlag=1, rowNum=null, errorMessages={}, dbEnv=null}]", tfOneFeatures.toString());
    }

    @Test
    public void testSearchProfileFeatures_whenException() throws SQLException, TracfoneOneException {
        try {
            tracfoneFeatureAction.searchProfileFeatures(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        TracfoneOneSearchProfileModel searchConfig = new TracfoneOneSearchProfileModel();
        searchConfig.setDbEnv(DB_ENV);
        searchConfig.setProfileId("1501");
        searchConfig.setFeatureValue("FEATURE");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneFeatureAction.searchProfileFeatures(searchConfig);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllFeatureValues() throws TracfoneOneException, SQLException {
        List<String> featureValues = new ArrayList<>();
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn("BLKBRY").when(resultSet).getString(anyString());
        featureValues = tracfoneFeatureAction.getAllFeatureValues(DB_ENV);
        assertNotNull(featureValues);
        assertEquals("[BLKBRY]", featureValues.toString());
    }

    @Test
    public void testGetAllFeatureValues_whenException() throws SQLException {
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneFeatureAction.getAllFeatureValues(DB_ENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testBulkUpdateProfileFeatures() throws TracfoneOneException, SQLException {
        TracfoneOneRatePlanExtensionConfig tracfoneOneRatePlanExtensionConfig = getTracfoneOneRatePlanExtensionConfig();
        tfOneGeneralResponse = tracfoneFeatureAction.bulkUpdateProfileFeatures(tracfoneOneRatePlanExtensionConfig, 1);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tracfoneOneRatePlanExtensionConfig.getObjid());
    }

    @Test
    public void testBulkUpdateProfileFeatures_whenException() throws SQLException {
        TracfoneOneRatePlanExtensionConfig tracfoneOneRatePlanExtensionConfig = getTracfoneOneRatePlanExtensionConfig();
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneFeatureAction.bulkUpdateProfileFeatures(tracfoneOneRatePlanExtensionConfig, 1);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}