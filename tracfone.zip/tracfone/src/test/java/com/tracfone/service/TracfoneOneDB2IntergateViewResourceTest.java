/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service;

import com.tracfone.service.controller.TracfoneCarrierMaintenanceControllerLocal;
import com.tracfone.service.controller.TracfoneOneDB2IntergateControllerLocal;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneDB2Intergate;
import com.tracfone.service.model.request.TracfoneOneIgOrderType;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneDB2Intergate;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIgOrderType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneDB2IntergateViewResourceTest {

    public final String JSON = "application/json";
    public final String DBENV = "dbEnv";
    private TracfoneOneException tracfoneOneException;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneAuthorizationException tracfoneOneAuthorizationException;

    @InjectMocks
    private TracfoneOneDB2IntergateViewResource viewResource;

    @Mock
    private TracfoneOneDB2IntergateControllerLocal controllerLocal;

    @Mock
    private TracfoneCarrierMaintenanceControllerLocal tracfoneCarrierMaintenanceController;

    @Mock
    private SecurityContext securityContext;
    @Mock
    private TracfoneOnePrincipal principal;
    @Mock
    private TFOneAdminUser user;

    @Before
    public void setUp() {
        initMocks(this);
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
    }

    @Test
    public void testGetOrderTypes() throws TracfoneOneException {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        List<TFOneIgOrderType> orderTypes = new ArrayList<>();
        TFOneIgOrderType igOrderType = new TFOneIgOrderType();
        igOrderType.setIgOrderType("ACM");
        orderTypes.add(igOrderType);
        when(tracfoneCarrierMaintenanceController.searchIgOrderTypes(any(), anyBoolean())).thenReturn(orderTypes);
        Response response = viewResource.getOrderTypes(tracfoneOneIgOrderType);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"programmeName\":null,\"actualOrderType\":null,\"igOrderType\":\"ACM\",\"sqlText\":null,\"priority\":null,\"createSOGencodeFlag\":null,\"createMFormIGFlag\":null,\"createMFormPortFlag\":null,\"skipMinValidationForm\":null,\"skipESNValidationFlag\":null,\"createIGAPNFlag\":null,\"insertILDTransFlag\":null,\"bogoConfigFlag\":null,\"sUIActionType\":null,\"updateMSIDFlag\":null,\"addonCashCardFlag\":null,\"contactPinUpdateFlag\":null,\"brmNotificationFlag\":null,\"newerTransFlag\":null,\"skipMinUpdateFlag\":null,\"safeLinkBatchFlag\":null,\"createBucketsFlag\":null,\"processIgateIN3Flag\":null,\"processIgateIN3LiteFlag\":null,\"updateXCase2TaskFlag\":null,\"depIGTransFlag\":null,\"generateAccountFlag\":null,\"createIGACMFlag\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetOrderTypes_whenException() throws TracfoneOneException {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceController).searchIgOrderTypes(any(), anyBoolean());
        Response response = viewResource.getOrderTypes(tracfoneOneIgOrderType);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testViewDB2Intergate() throws TracfoneOneException {
        TracfoneOneDB2Intergate tracfoneOneDB2Intergate = new TracfoneOneDB2Intergate();
        tracfoneOneDB2Intergate.setDbEnv(DBENV);
        tracfoneOneDB2Intergate.setQueryName("APN");
        tracfoneOneDB2Intergate.setOrderTypes("A");

        List<TFOneDB2Intergate> viewData = new ArrayList<>();
        ;
        TFOneDB2Intergate dB2Intergate = new TFOneDB2Intergate();
        dB2Intergate.setActiveFlag("TRUE");
        dB2Intergate.setAppName("TEST");
        dB2Intergate.setExtraWhereClauseConditions("SONS");
        dB2Intergate.setIntervalTime("2020:02:02");
        dB2Intergate.setNumberOfRecords("2020:02:03");
        dB2Intergate.setOrderTypes("OUTAGE_TYPE");
        dB2Intergate.setQueryId("SERVICE_TYPE");
        dB2Intergate.setQueryName("1,2,3");
        dB2Intergate.setRemarks("CHANNEL");
        dB2Intergate.setSelectQueryClob("BRAND");
        dB2Intergate.setStartingRecord("PARENT_SHORT_NAME");
        dB2Intergate.setTemplates("BRAND");
        dB2Intergate.setUpdateQuery("PARENT_SHORT_NAME");
        dB2Intergate.setUseNewSql("BRAND");
        viewData.add(dB2Intergate);

        when(controllerLocal.viewDB2Intergate(any())).thenReturn(viewData);
        Response response = viewResource.viewDB2Intergate(tracfoneOneDB2Intergate);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"queryId\":\"SERVICE_TYPE\",\"queryName\":\"1,2,3\",\"activeFlag\":\"TRUE\",\"useNewSql\":\"BRAND\",\"intervalTime\":\"2020:02:02\",\"selectQueryClob\":\"BRAND\",\"numberOfRecords\":\"2020:02:03\",\"updateQuery\":\"PARENT_SHORT_NAME\",\"templates\":\"BRAND\",\"orderTypes\":\"OUTAGE_TYPE\",\"extraWhereClauseConditions\":\"SONS\",\"appName\":\"TEST\",\"startingRecord\":\"PARENT_SHORT_NAME\",\"remarks\":\"CHANNEL\"}]", response.getEntity().toString());
    }

    @Test
    public void testViewDB2Intergate_whenException() throws TracfoneOneException {
        TracfoneOneDB2Intergate tracfoneOneDB2Intergate = new TracfoneOneDB2Intergate();
        tracfoneOneDB2Intergate.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(controllerLocal).viewDB2Intergate(any());
        Response response = viewResource.viewDB2Intergate(tracfoneOneDB2Intergate);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }
}
