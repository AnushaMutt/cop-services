/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service;

import com.tracfone.service.controller.TracfoneBucketControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.controller.TracfoneFeatureControllerLocal;
import com.tracfone.service.controller.TracfoneProfileControllerLocal;
import com.tracfone.service.controller.TracfoneRatePlanControllerLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneAncillaryCode;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeConfig;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeDiscount;
import com.tracfone.service.model.request.TracfoneOneApn;
import com.tracfone.service.model.request.TracfoneOneBucket;
import com.tracfone.service.model.request.TracfoneOneBucketList;
import com.tracfone.service.model.request.TracfoneOneCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucketTier;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildTier;
import com.tracfone.service.model.request.TracfoneOneChildPlan;
import com.tracfone.service.model.request.TracfoneOneFeatureRequirement;
import com.tracfone.service.model.request.TracfoneOneLineStatusCode;
import com.tracfone.service.model.request.TracfoneOneMultiRatePlanEsn;
import com.tracfone.service.model.request.TracfoneOneRatePlan;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtension;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionConfig;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionLink;
import com.tracfone.service.model.request.TracfoneOneRatePlanProfile;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.request.TracfoneOneSearchCarrierFeatureModel;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneServicePlanCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneThrottleStatusCode;
import com.tracfone.service.model.request.TracfoneOneUploadProfileFeatures;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneAncillaryCode;
import com.tracfone.service.model.response.TFOneAncillaryCodeConfig;
import com.tracfone.service.model.response.TFOneAncillaryCodeDiscount;
import com.tracfone.service.model.response.TFOneApn;
import com.tracfone.service.model.response.TFOneBucketList;
import com.tracfone.service.model.response.TFOneBulkInsertReport;
import com.tracfone.service.model.response.TFOneBusinessOrganization;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileBucketTier;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildTier;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneFeatureRequirement;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneLineStatusCode;
import com.tracfone.service.model.response.TFOneMultiRatePlanEsn;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOneRPFeatureNameList;
import com.tracfone.service.model.response.TFOneRatePlan;
import com.tracfone.service.model.response.TFOneRatePlanExtension;
import com.tracfone.service.model.response.TFOneRatePlanExtensionConfig;
import com.tracfone.service.model.response.TFOneRatePlanExtensionLink;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import com.tracfone.service.model.response.TFOneThrottleStatusCode;
import com.tracfone.service.model.response.TFOneUploadProfileFeatures;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Testing the services that are associated with Rate Plan Wizard.
 *
 * @author Pritesh Singh
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneServiceRatePlanWizardResourceTest {

    public final String JSON = "application/json";
    public final String DBENV = "dbEnv";
    @InjectMocks
    private TracfoneOneServiceRatePlanWizardResource ratePlanResource;
    @Mock
    private TracfoneRatePlanControllerLocal tracfoneRatePlanController;
    @Mock
    private TracfoneBucketControllerLocal tracfoneBucketController;
    @Mock
    private TracfoneFeatureControllerLocal tracfoneFeatureController;
    @Mock
    private TracfoneProfileControllerLocal tracfoneProfileController;
    @Mock
    private TracfoneControllerLocalAction tracfoneControllerAction;
    @Mock
    private SecurityContext securityContext;
    @Mock
    private TracfoneOnePrincipal principal;
    @Mock
    private TFOneAdminUser user;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;
    private TracfoneOneRatePlan tracfoneOneRatePlan;
    private TracfoneOneApn tracfoneOneApn;
    private TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel;
    private TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel;
    private TracfoneOneRatePlanProfile tracfoneOneRatePlanProfile;
    private TracfoneOneSearchCarrierFeatureModel tracfoneOneSearchCarrierFeatureModel;
    private TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel;
    private TracfoneOneCarrierFeature tracfoneOneCarrierFeature;
    private TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig;
    private TracfoneOneBucket tracfoneOneIgBucket;
    private TracfoneOneAncillaryCode tracfoneOneAncillaryCode;
    private TracfoneOneChildPlan tracfoneOneChildPlan;
    private TracfoneOneRatePlanExtension tracfoneOneRatePlanExtension;
    private TracfoneOneUploadProfileFeatures tracfoneOneUploadProfileFeatures;
    private TracfoneOneAncillaryCodeConfig tracfoneOneAncillaryCodeConfig;

    public TracfoneOneServiceRatePlanWizardResourceTest() {
    }

    @Before
    public void setUp() {
        initMocks(this);
        setRatePlan();
        setAPN();
        setSearchProfileModel();
        setSearchPlanModel();
        setRatePlanProfile();
        setSearchCarrierFeatureModel();
        setSearchBucketModel();
        setCarrierFeature();
        setRpExtensionConfig();
        setIgBucket();
        setAncillaryCode();
        setChildPlan();
        setRatePlanExtension();
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        when(securityContext.getUserPrincipal()).thenReturn(principal);
        when(principal.getTFUser()).thenReturn(user);
    }

    private void setRatePlanExtension() {
        tracfoneOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tracfoneOneRatePlanExtension.setDbEnv(DBENV);
        tracfoneOneRatePlanExtension.setAncillaryCode("AL");
        tracfoneOneRatePlanExtension.setLineStatusCode("AD");
        tracfoneOneRatePlanExtension.setThrottleStatusCode("TH");
    }

    private void setAncillaryCode() {
        tracfoneOneAncillaryCode = new TracfoneOneAncillaryCode();
        tracfoneOneAncillaryCode.setDbEnv(DBENV);
        tracfoneOneAncillaryCode.setAncillaryCode("CD");
        tracfoneOneAncillaryCode.setDescription("ANCILLARY_DESC");
    }

    private void setChildPlan() {
        tracfoneOneChildPlan = new TracfoneOneChildPlan();
        tracfoneOneChildPlan.setDbEnv(DBENV);
        tracfoneOneChildPlan.setChildDescription("CHILD_PLAN");
    }

    private void setSearchCarrierFeatureModel() {
        tracfoneOneSearchCarrierFeatureModel = new TracfoneOneSearchCarrierFeatureModel();
        tracfoneOneSearchCarrierFeatureModel.setCarrierName("CARRIER_NAME");
        tracfoneOneSearchCarrierFeatureModel.setDbEnv(DBENV);
        tracfoneOneSearchCarrierFeatureModel.setServicePlanId("20");
        tracfoneOneSearchCarrierFeatureModel.setTracfoneOneCarrierFeature(tracfoneOneCarrierFeature);
    }

    private void setSearchBucketModel() {
        tracfoneOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tracfoneOneSearchBucketModel.setDbEnv(DBENV);
        tracfoneOneSearchBucketModel.setProfileIds(new ArrayList<>());
        tracfoneOneSearchBucketModel.setRatePlanNames(new ArrayList<>());
        tracfoneOneSearchBucketModel.setServicePlanIds(new ArrayList<>());
    }

    private void setCarrierFeature() {
        tracfoneOneCarrierFeature = new TracfoneOneCarrierFeature();
        tracfoneOneCarrierFeature.setDbEnv(DBENV);
        tracfoneOneCarrierFeature.setxRatePlan("RATE_PLAN");
        tracfoneOneCarrierFeature.setxFeature2xCarrier("CARRIER_NAME");
        TracfoneOneServicePlanCarrierFeature servicePlanCarrierFeature = new TracfoneOneServicePlanCarrierFeature();
        servicePlanCarrierFeature.setServicePlanId("30");
        servicePlanCarrierFeature.setPriority("1");
        tracfoneOneCarrierFeature.setServicePlanCarrierFeature(servicePlanCarrierFeature);
    }

    private void setRpExtensionConfig() {
        tfOneRpExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        tfOneRpExtensionConfig.setDbEnv(DBENV);
        tfOneRpExtensionConfig.setDisplaySUIFlag("Y");
        tfOneRpExtensionConfig.setFeatureName("FEATURE_NAME");
        tfOneRpExtensionConfig.setFeatureRequirement("FEATURE_REQUIREMENT");
        tfOneRpExtensionConfig.setFeatureValue("FEATURE_VALUE");
        tfOneRpExtensionConfig.setProfileId("10");
        tfOneRpExtensionConfig.setRestrictSUIFlag("Y");
        tfOneRpExtensionConfig.setToggleFlag("Y");
    }

    private void setIgBucket() {
        tracfoneOneIgBucket = new TracfoneOneBucket();
        tracfoneOneIgBucket.setDbEnv(DBENV);
        tracfoneOneIgBucket.setActiveFlag("Y");
        tracfoneOneIgBucket.setRatePlan("RATE_PLAN");
        tracfoneOneIgBucket.setBucketId("BUCKET_ID");
    }

    private void setRatePlanProfile() {
        tracfoneOneRatePlanProfile = new TracfoneOneRatePlanProfile();
        tracfoneOneRatePlanProfile.setDbEnv(DBENV);
        tracfoneOneRatePlanProfile.setProfileDescription("PROFILE_DESC");
    }

    private void setSearchPlanModel() {
        tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setCarrierFeatureId("!000");
        tracfoneOneSearchPlanModel.setCarrierName("CARRIER_NAME");
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setProfileId("10");
        tracfoneOneSearchPlanModel.setRatePlanName("RATE_PLAN");
        tracfoneOneSearchPlanModel.setServicePlanId("20");
    }

    private void setSearchProfileModel() {
        tracfoneOneSearchProfileModel = new TracfoneOneSearchProfileModel();
        tracfoneOneSearchProfileModel.setProfileDesc("PROFILE_DESC");
        tracfoneOneSearchProfileModel.setDbEnv(DBENV);
        tracfoneOneSearchProfileModel.setProfileId("10");
        tracfoneOneSearchProfileModel.setFeatureName("FEATURE_NAME");
        tracfoneOneSearchProfileModel.setFeatureValue("FEATURE_VALUE");
        tracfoneOneSearchProfileModel.setRatePlan("RATE_PLAN");
    }

    private void setAPN() {
        tracfoneOneApn = new TracfoneOneApn();
        tracfoneOneApn.setDbEnv(DBENV);
        tracfoneOneApn.setApn("APN");
        tracfoneOneApn.setxParentName("PARENT");
        tracfoneOneApn.setRatePlan("RATE_PLAN");
        tracfoneOneApn.setOrgId("ORG_NAME");
    }

    private void setRatePlan() {
        tracfoneOneRatePlan = new TracfoneOneRatePlan();
        tracfoneOneRatePlan.setDbEnv(DBENV);
        tracfoneOneRatePlan.setRatePlanName("RATE_PLAN");
    }

    /**
     * Test of getAllCarrierNames method, of class TracfoneOneServiceRatePlanWizardResource.
     */
    @Test
    public void testGetAllCarrierNames() throws TracfoneOneException {
        List<String> carrierNames = new ArrayList<>();
        carrierNames.add("First");
        when(tracfoneRatePlanController.getAllCarrierNames(any())).thenReturn(carrierNames);
        Response response = ratePlanResource.getAllCarrierNames(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[\"First\"]", response.getEntity().toString());
    }

    @Test
    public void testGetAllCarrierNames_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getAllCarrierNames(any());
        Response response = ratePlanResource.getAllCarrierNames(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    /**
     * Test of insertRatePlan method, of class TracfoneOneServiceRatePlanWizardResource.
     */
    @Test
    public void testInsertRatePlan() throws TracfoneOneException {
        when(tracfoneRatePlanController.insertRatePlan(any(TracfoneOneRatePlan.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertRatePlan(tracfoneOneRatePlan);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertRatePlan_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).insertRatePlan(any(TracfoneOneRatePlan.class), anyInt());
        Response response = ratePlanResource.insertRatePlan(tracfoneOneRatePlan);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertApn() throws TracfoneOneException {
        when(tracfoneRatePlanController.insertApn(any(TracfoneOneApn.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertApn(tracfoneOneApn);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertApn_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).insertApn(any(TracfoneOneApn.class), anyInt());
        Response response = ratePlanResource.insertApn(tracfoneOneApn);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateRatePlan() throws TracfoneOneException {
        when(tracfoneRatePlanController.updateRatePlan(any(TracfoneOneRatePlan.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateRatePlan(tracfoneOneRatePlan);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateRatePlan_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).updateRatePlan(any(TracfoneOneRatePlan.class), anyInt());
        Response response = ratePlanResource.updateRatePlan(tracfoneOneRatePlan);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateApn() throws TracfoneOneException {
        when(tracfoneRatePlanController.updateApn(any(TracfoneOneApn.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateApn(tracfoneOneApn);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateApn_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).updateApn(any(TracfoneOneApn.class), anyInt());
        Response response = ratePlanResource.updateApn(tracfoneOneApn);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteRatePlan() throws TracfoneOneException {
        when(tracfoneRatePlanController.deleteRatePlan(any(TracfoneOneRatePlan.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteRatePlan(tracfoneOneRatePlan);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteRatePlan_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).deleteRatePlan(any(TracfoneOneRatePlan.class), anyInt());
        Response response = ratePlanResource.deleteRatePlan(tracfoneOneRatePlan);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteApn() throws TracfoneOneException {
        TracfoneOneApn tfOneApn = new TracfoneOneApn();
        tfOneApn.setApn("APN");
        tfOneApn.setxParentName("PARENT");
        tfOneApn.setRatePlan("RATE_PLAN");
        tfOneApn.setOrgId("100");
        when(tracfoneRatePlanController.deleteApn(any(TracfoneOneApn.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteApn(tfOneApn);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }


    @Test
    public void testDeleteApn_whenException() throws TracfoneOneException {
        TracfoneOneApn tfOneApn = new TracfoneOneApn();
        tfOneApn.setApn("APN");
        tfOneApn.setxParentName("PARENT");
        tfOneApn.setRatePlan("RATE_PLAN");
        tfOneApn.setOrgId("100");
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).deleteApn(any(TracfoneOneApn.class), anyInt());
        Response response = ratePlanResource.deleteApn(tfOneApn);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetMasterRatePlans() throws TracfoneOneException {
        List<TFOneRatePlan> allRatePlans = new ArrayList<>();
        TFOneRatePlan tFOneRatePlan = new TFOneRatePlan();
        tFOneRatePlan.setObjId("1000");
        allRatePlans.add(tFOneRatePlan);
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        searchPlanModel.setDbEnv("local");
        when(tracfoneRatePlanController.getMasterRatePlans(any())).thenReturn(allRatePlans);
        Response response = ratePlanResource.getMasterRatePlans(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"ratePlanName\":null,\"privateNetwork\":null,\"espidUpdate\":null,\"espidNum\":null,\"propagateFlagValue\":null,\"allowMformApnRequestFlag\":null,\"calculateDataUnitsFlag\":null,\"thresholdsToTmo\":null,\"hotspotBucketsFlag\":null,\"tmoNextGenFlag\":null,\"ratePlanProfile\":[],\"carrierFeatures\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetMasterRatePlans_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getMasterRatePlans(any());
        Response response = ratePlanResource.getMasterRatePlans(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetServicePlansForCarrier() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        searchPlanModel.setDbEnv("local");
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tFOneCarrierServicePlan = new TFOneCarrierServicePlan();
        tFOneCarrierServicePlan.setServicePlanId("185");
        carrierServicePlans.add(tFOneCarrierServicePlan);
        when(tracfoneRatePlanController.getServicePlansForCarrier(any())).thenReturn(carrierServicePlans);
        Response response = ratePlanResource.getServicePlansForCarrier(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"carrierName\":null,\"servicePlanId\":\"185\",\"mktName\":null,\"description\":null,\"servicePlanPurchase\":null,\"parentName\":null,\"servicePlans\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetServicePlansForCarrier_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getServicePlansForCarrier(any());
        Response response = ratePlanResource.getServicePlansForCarrier(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllBusinessOrgs() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        searchPlanModel.setDbEnv("local");
        List<TFOneBusinessOrganization> allBusOrgs = new ArrayList<>();
        TFOneBusinessOrganization tFOneBusinessOrganization = new TFOneBusinessOrganization();
        tFOneBusinessOrganization.setOrgId("1000");
        allBusOrgs.add(tFOneBusinessOrganization);
        when(tracfoneRatePlanController.getAllBusinessOrgs(any())).thenReturn(allBusOrgs);
        Response response = ratePlanResource.getAllBusinessOrgs(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"orgId\":\"1000\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllBusinessOrgs_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getAllBusinessOrgs(any());
        Response response = ratePlanResource.getAllBusinessOrgs(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllRatePlanApns() throws TracfoneOneException {
        List<TFOneApn> ratePlanApns = new ArrayList<>();
        TFOneApn tFOneApn = new TFOneApn();
        tFOneApn.setOrgId("1000");
        ratePlanApns.add(tFOneApn);
        TracfoneOneApn tfOneApn = new TracfoneOneApn();
        tfOneApn.setApn("APN");
        tfOneApn.setxParentName("PARENT");
        tfOneApn.setRatePlan("RATE_PLAN");
        tfOneApn.setOrgId("100");
        when(tracfoneRatePlanController.getAllRatePlanApns(any(TracfoneOneApn.class))).thenReturn(ratePlanApns);
        Response response = ratePlanResource.getAllRatePlanApns(tfOneApn);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"xParentName\":null,\"ratePlan\":null,\"orgId\":\"1000\",\"apn\":null,\"username\":null,\"password\":null,\"authType\":null,\"proxyAddress\":null,\"proxyPort\":null,\"connectionType\":null,\"mmsApn\":null,\"mmsUsername\":null,\"mmsPassword\":null,\"mmsAuthType\":null,\"mmsc\":null,\"mmsProxyAddress\":null,\"mmsProxyPort\":null,\"mmsApnType\":null,\"rtspProxyAddr\":null,\"rtspProxyPort\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllRatePlanApns_whenException() throws TracfoneOneException {
        TracfoneOneApn tfOneApn = new TracfoneOneApn();
        tfOneApn.setApn("APN");
        tfOneApn.setxParentName("PARENT");
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getAllRatePlanApns(any(TracfoneOneApn.class));
        Response response = ratePlanResource.getAllRatePlanApns(tfOneApn);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchForUnlinkedRatePlans() throws TracfoneOneException {
        List<TFOneRatePlan> unlinkedRatePlans = new ArrayList<>();
        TFOneRatePlan tFOneRatePlan = new TFOneRatePlan();
        tFOneRatePlan.setObjId("1000");
        unlinkedRatePlans.add(tFOneRatePlan);
        TracfoneOneRatePlan tfOneRatePlan = new TracfoneOneRatePlan();
        tfOneRatePlan.setRatePlanName("RATE_PLAN");
        when(tracfoneRatePlanController.searchRatePlansForUpdate(any(TracfoneOneRatePlan.class))).thenReturn(unlinkedRatePlans);
        Response response = ratePlanResource.searchRatePlansForUpdate(tfOneRatePlan);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"ratePlanName\":null,\"privateNetwork\":null,\"espidUpdate\":null,\"espidNum\":null,\"propagateFlagValue\":null,\"allowMformApnRequestFlag\":null,\"calculateDataUnitsFlag\":null,\"thresholdsToTmo\":null,\"hotspotBucketsFlag\":null,\"tmoNextGenFlag\":null,\"ratePlanProfile\":[],\"carrierFeatures\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchForUnlinkedRatePlans_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).searchRatePlansForUpdate(any(TracfoneOneRatePlan.class));
        Response response = ratePlanResource.searchRatePlansForUpdate(tracfoneOneRatePlan);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllParentNames() throws TracfoneOneException {
        List<TFOneParent> allParents = new ArrayList<>();
        TFOneParent tFOneParent = new TFOneParent();
        tFOneParent.setObjId("1000");
        allParents.add(tFOneParent);
        when(tracfoneRatePlanController.getAllParentNames(any(), any())).thenReturn(allParents);
        Response response = ratePlanResource.getAllParentNames(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"xParentName\":null,\"parentId\":null,\"status\":null,\"holdAnalogDeac\":null,\"holdDigitalDeac\":null,\"parent2TempQueue\":null,\"noInventory\":null,\"vmAccessNum\":null,\"autoPortIn\":null,\"autoPortOut\":null,\"noMsid\":null,\"otaCarrier\":null,\"otaEndDate\":null,\"otaPsmsAddress\":null,\"otaStartDate\":null,\"nextAvailable\":null,\"queueName\":null,\"blockPortIn\":null,\"meidCarrier\":null,\"otaReact\":null,\"aggCarrCode\":null,\"suiRuleObjId\":null,\"deactSimExpDays\":null,\"overrideSmsAddress\":null,\"triggerId\":null,\"parentShortName\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllParentNames_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getAllParentNames(any(), any());
        Response response = ratePlanResource.getAllParentNames(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertProfile() throws TracfoneOneException {
        when(tracfoneProfileController.insertProfile(any(TracfoneOneRatePlanProfile.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertProfile(tracfoneOneRatePlanProfile);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertProfile_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).insertProfile(any(TracfoneOneRatePlanProfile.class), anyInt());
        Response response = ratePlanResource.insertProfile(tracfoneOneRatePlanProfile);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchProfile() throws TracfoneOneException {
        List<TFOneRatePlanProfile> tfOneRatePlanProfiles = new ArrayList<>();
        TFOneRatePlanProfile tFOneRatePlanProfile = new TFOneRatePlanProfile();
        tFOneRatePlanProfile.setProfileId("5401");
        tfOneRatePlanProfiles.add(tFOneRatePlanProfile);
        when(tracfoneProfileController.searchProfile(any(TracfoneOneSearchProfileModel.class))).thenReturn(tfOneRatePlanProfiles);
        Response response = ratePlanResource.searchProfile(tracfoneOneSearchProfileModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"profileId\":\"5401\",\"profileDescription\":null,\"rpExtensionLinks\":null,\"rpExtensionConfigs\":null,\"features\":null,\"buckets\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchProfile_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).searchProfile(any(TracfoneOneSearchProfileModel.class));
        Response response = ratePlanResource.searchProfile(tracfoneOneSearchProfileModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateProfile() throws TracfoneOneException {
        when(tracfoneProfileController.updateProfile(any(TracfoneOneRatePlanProfile.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateProfile(tracfoneOneRatePlanProfile);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateProfile_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).updateProfile(any(TracfoneOneRatePlanProfile.class), anyInt());
        Response response = ratePlanResource.updateProfile(tracfoneOneRatePlanProfile);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteProfile() throws TracfoneOneException {
        when(tracfoneProfileController.deleteProfile(any(TracfoneOneRatePlanProfile.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteProfile(tracfoneOneRatePlanProfile);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteProfile_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).deleteProfile(any(TracfoneOneRatePlanProfile.class), anyInt());
        Response response = ratePlanResource.deleteProfile(tracfoneOneRatePlanProfile);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllAncillaryCodes() throws TracfoneOneException {
        List<TFOneAncillaryCode> allAncillaryCodes = new ArrayList<>();
        TFOneAncillaryCode tFOneAncillaryCode = new TFOneAncillaryCode();
        tFOneAncillaryCode.setAncillaryCode("CD");
        tFOneAncillaryCode.setDescription("DESC");
        allAncillaryCodes.add(tFOneAncillaryCode);
        when(tracfoneProfileController.getAllAncillaryCodes(any())).thenReturn(allAncillaryCodes);
        Response response = ratePlanResource.getAllAncillaryCodes(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"ancillaryCode\":\"CD\",\"description\":\"DESC\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllAncillaryCodes_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).getAllAncillaryCodes(any());
        Response response = ratePlanResource.getAllAncillaryCodes(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchAncillaryCodes() throws TracfoneOneException {
        List<TFOneAncillaryCode> allAncillaryCodes = new ArrayList<>();
        TFOneAncillaryCode tFOneAncillaryCode = new TFOneAncillaryCode();
        tFOneAncillaryCode.setAncillaryCode("CD");
        tFOneAncillaryCode.setDescription("DESC");
        allAncillaryCodes.add(tFOneAncillaryCode);
        when(tracfoneProfileController.searchAncillaryCodes(any())).thenReturn(allAncillaryCodes);
        Response response = ratePlanResource.searchAncillaryCodes(tracfoneOneAncillaryCode);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"ancillaryCode\":\"CD\",\"description\":\"DESC\"}]", response.getEntity().toString());
    }

    @Test
    public void testSearchAncillaryCodes_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).searchAncillaryCodes(any());
        Response response = ratePlanResource.searchAncillaryCodes(tracfoneOneAncillaryCode);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertAncillaryCode() throws TracfoneOneException {
        when(tracfoneProfileController.insertAncillaryCode(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertAncillaryCode(tracfoneOneAncillaryCode);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertAncillaryCode_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).insertAncillaryCode(any(), anyInt());
        Response response = ratePlanResource.insertAncillaryCode(tracfoneOneAncillaryCode);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateAncillaryCode() throws TracfoneOneException {
        when(tracfoneProfileController.updateAncillaryCode(any(TracfoneOneAncillaryCode.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateAncillaryCode(tracfoneOneAncillaryCode);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateAncillaryCode_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).updateAncillaryCode(any(TracfoneOneAncillaryCode.class), anyInt());
        Response response = ratePlanResource.updateAncillaryCode(tracfoneOneAncillaryCode);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteAncillaryCodes() throws TracfoneOneException {
        when(tracfoneProfileController.deleteAncillaryCode(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteAncillaryCode(tracfoneOneAncillaryCode);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteAncillaryCodes_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).deleteAncillaryCode(any(), anyInt());
        Response response = ratePlanResource.deleteAncillaryCode(tracfoneOneAncillaryCode);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchForUnlinkedProfiles() throws TracfoneOneException {
        List<TFOneRatePlanProfile> ratePlanProfiles = new ArrayList<>();
        TFOneRatePlanProfile tFOneRatePlanProfile = new TFOneRatePlanProfile();
        tFOneRatePlanProfile.setProfileId("5401");
        ratePlanProfiles.add(tFOneRatePlanProfile);
        when(tracfoneProfileController.searchProfilesForUpdate(any(TracfoneOneSearchProfileModel.class))).thenReturn(ratePlanProfiles);
        Response response = ratePlanResource.searchProfilesForUpdate(tracfoneOneSearchProfileModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"profileId\":\"5401\",\"profileDescription\":null,\"rpExtensionLinks\":null,\"rpExtensionConfigs\":null,\"features\":null,\"buckets\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchForUnlinkedProfiles_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).searchProfilesForUpdate(any(TracfoneOneSearchProfileModel.class));
        Response response = ratePlanResource.searchProfilesForUpdate(tracfoneOneSearchProfileModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierFeature() throws TracfoneOneException {
        when(tracfoneRatePlanController.updateCarrierFeature(any(TracfoneOneCarrierFeature.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateCarrierFeature(tracfoneOneCarrierFeature);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierFeature_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).updateCarrierFeature(any(TracfoneOneCarrierFeature.class), anyInt());
        Response response = ratePlanResource.updateCarrierFeature(tracfoneOneCarrierFeature);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierFeatures() throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        TFOneCarrierFeature tFOneCarrierFeature = new TFOneCarrierFeature();
        tFOneCarrierFeature.setxTechnology("CDMA");
        carrierFeatures.add(tFOneCarrierFeature);
        when(tracfoneRatePlanController.searchCarrierFeatures(any(TracfoneOneSearchCarrierFeatureModel.class))).thenReturn(carrierFeatures);
        Response response = ratePlanResource.searchCarrierFeatures(tracfoneOneSearchCarrierFeatureModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[TFOneCarrierFeature{objId='null', dev='null', xTechnology='CDMA', xRatePlan='null', xVoicemail='null', xVmCode='null', xVmPackage='null', xCallerId='null', xIdCode='null', xIdPackage='null', xSms='null', xSmsCode='null', xSmsPackage='null', xCallWaiting='null', xCwCode='null', xCwPackage='null', xDigitalFeature='null', xDigFeature='null', xFeature2xCarrier='null', xSmscNumber='null', xData='null', xRestrictedUse='null', xSwitchBaseRate='null', xFeatures2BusOrg='null', xIsSwbCarrier='null', xMpn='null', xMpnCode='null', xPoolName='null', createMformIgFlag='null', useCfExtensionFlag='null', dataSaver='null', dataSaverCode='null', useRpExtensionFlag='null', tmoNextGenFlag='null', servicePlanId='null', brand='null', xCarrierId='null', servicePlanCarrierFeature=null, rpExtensionLinks=[]}]", carrierFeatures.toString());
    }

    @Test
    public void testSearchCarrierFeatures_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).searchCarrierFeatures(any(TracfoneOneSearchCarrierFeatureModel.class));
        Response response = ratePlanResource.searchCarrierFeatures(tracfoneOneSearchCarrierFeatureModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllMasterFeatures() throws TracfoneOneException {
        List<TFOneRPFeatureNameList> features = new ArrayList<>();
        TFOneRPFeatureNameList tFOneRPFeatureNameList = new TFOneRPFeatureNameList();
        tFOneRPFeatureNameList.setFeatureName("feature");
        features.add(tFOneRPFeatureNameList);
        when(tracfoneFeatureController.getAllMasterFeatures(any())).thenReturn(features);
        Response response = ratePlanResource.getAllMasterFeatures(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"featureName\":\"feature\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllMasterFeatures_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneFeatureController).getAllMasterFeatures(any());
        Response response = ratePlanResource.getAllMasterFeatures(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertRpExtensionConfig() throws TracfoneOneException {
        List<TracfoneOneRatePlanExtensionConfig> tfOneRpExtensionConfigs = new ArrayList<>();
        when(tracfoneFeatureController.insertRpExtensionConfig(anyList(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertRpExtensionConfig(tfOneRpExtensionConfigs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertRpExtensionConfig_WhenException() throws TracfoneOneException {
        List<TracfoneOneRatePlanExtensionConfig> tfOneRpExtensionConfigs = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).insertRpExtensionConfig(anyList(), anyInt());
        Response response = ratePlanResource.insertRpExtensionConfig(tfOneRpExtensionConfigs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateRpExtensionConfig() throws TracfoneOneException {
        when(tracfoneFeatureController.updateRpExtensionConfig(any(TracfoneOneRatePlanExtensionConfig.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateRpExtensionConfig(tfOneRpExtensionConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateRpExtensionConfig_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneFeatureController).updateRpExtensionConfig(any(TracfoneOneRatePlanExtensionConfig.class), anyInt());
        Response response = ratePlanResource.updateRpExtensionConfig(tfOneRpExtensionConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteRpExtensionConfig() throws TracfoneOneException {
        when(tracfoneFeatureController.deleteRpExtensionConfig(any(TracfoneOneRatePlanExtensionConfig.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteRpExtensionConfig(tfOneRpExtensionConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteRpExtensionConfig_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneFeatureController).deleteRpExtensionConfig(any(TracfoneOneRatePlanExtensionConfig.class), anyInt());
        Response response = ratePlanResource.deleteRpExtensionConfig(tfOneRpExtensionConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertLegacyBucket() throws TracfoneOneException {
        List<TracfoneOneBucket> tfBuckets = new ArrayList<>();
        when(tracfoneBucketController.insertLegacyBucket(anyList(), anyString(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertLegacyBucket(tfBuckets, "PARENT_SHORT_NAME");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertLegacyBucket_whenException() throws TracfoneOneException {
        List<TracfoneOneBucket> tfBuckets = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneBucketController).insertLegacyBucket(anyList(), anyString(), anyInt());
        Response response = ratePlanResource.insertLegacyBucket(tfBuckets, "PARENT_SHORT_NAME");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateIgBucket() throws TracfoneOneException {
        when(tracfoneBucketController.updateIgBucket(any(TracfoneOneBucket.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateIgBucket(tracfoneOneIgBucket);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateIgBucket_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneBucketController).updateIgBucket(any(TracfoneOneBucket.class), anyInt());
        Response response = ratePlanResource.updateIgBucket(tracfoneOneIgBucket);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteIgBucket() throws TracfoneOneException {
        when(tracfoneBucketController.deleteIgBucket(any(TracfoneOneBucket.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteIgBucket(tracfoneOneIgBucket);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteIgBucket_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneBucketController).deleteIgBucket(any(TracfoneOneBucket.class), anyInt());
        Response response = ratePlanResource.deleteIgBucket(tracfoneOneIgBucket);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchIgBuckets() throws TracfoneOneException {
        when(tracfoneBucketController.searchIgBuckets(any(TracfoneOneSearchBucketModel.class))).thenReturn(anyList());
        Response response = ratePlanResource.searchIgBuckets(tracfoneOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
    }

    @Test
    public void testSearchIgBuckets_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneBucketController).searchIgBuckets(any(TracfoneOneSearchBucketModel.class));
        Response response = ratePlanResource.searchIgBuckets(tracfoneOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetIgBucketRatePlans() throws TracfoneOneException {
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setDbEnv(DBENV);
        tfOneSearchBucketModel.setChildPlanId("CHILD_PLAN_ID");
        List<TFOneRatePlan> tfOneRatePlans = new ArrayList<>();
        TFOneRatePlan tfOneRatePlan = new TFOneRatePlan();
        tfOneRatePlan.setRatePlanName("RATE_PLAN_NAME");
        tfOneRatePlan.setObjId("1000");
        tfOneRatePlans.add(tfOneRatePlan);
        when(tracfoneBucketController.getIgBucketRatePlans(any())).thenReturn(tfOneRatePlans);
        Response response = ratePlanResource.getIgBucketRatePlans(tfOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
    }

    @Test
    public void testGetIgBucketRatePlans_whenException() throws TracfoneOneException {
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        doThrow(tracfoneOneException).when(tracfoneBucketController).getIgBucketRatePlans(any());
        Response response = ratePlanResource.getIgBucketRatePlans(tfOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllBucketList() throws TracfoneOneException {
        List<TracfoneOneBucketList> tracfoneOneBucketLists = new ArrayList<>();
        when(tracfoneBucketController.getAllBucketList(any())).thenReturn(tracfoneOneBucketLists);
        Response response = ratePlanResource.getAllBucketList(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
    }

    @Test
    public void testGetAllBucketList_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneBucketController).getAllBucketList(any());
        Response response = ratePlanResource.getAllBucketList(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }


    @Test
    public void testGetAllProfileFeatures() throws TracfoneOneException {
        List<TFOneRatePlanProfile> ratePlanProfiles = new ArrayList<>();
        TFOneRatePlanProfile tfOneRatePlanProfile = new TFOneRatePlanProfile();
        tfOneRatePlanProfile.setProfileDescription("PROFILE_DESRIPTION");
        ratePlanProfiles.add(tfOneRatePlanProfile);
        TracfoneOneSearchProfileModel selectedRateProfile = new TracfoneOneSearchProfileModel();
        selectedRateProfile.setProfileId("100");
        when(tracfoneFeatureController.getAllProfileFeatures(any())).thenReturn(ratePlanProfiles);
        Response response = ratePlanResource.getAllProfileFeatures(selectedRateProfile);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[TFOneRatePlanProfile{profileId=null, profileDescription=PROFILE_DESRIPTION, rpExtensionLinks=null, rpExtensionConfigs=null, buckets=null, features=null}]", ratePlanProfiles.toString());
    }

    @Test
    public void testGetAllProfileFeatures_whenException() throws TracfoneOneException {
        TracfoneOneSearchProfileModel selectedRateProfile = new TracfoneOneSearchProfileModel();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).getAllProfileFeatures(any());
        Response response = ratePlanResource.getAllProfileFeatures(selectedRateProfile);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllChildPlans() throws TracfoneOneException {
        List<TFOneChildPlan> tfOneChildPlans = new ArrayList<>();
        TFOneChildPlan tfOneChildPlan = new TFOneChildPlan();
        tfOneChildPlan.setChildPlanId("CHILD");
        tfOneChildPlan.setChildDescription("DESC");
        tfOneChildPlans.add(tfOneChildPlan);
        when(tracfoneProfileController.getAllChildPlans(any())).thenReturn(tfOneChildPlans);
        Response response = ratePlanResource.getAllChildPlans(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"childPlanId\":\"CHILD\",\"childDescription\":\"DESC\",\"childPlanName\":null,\"ratePlanProfile\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllChildPlans_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).getAllChildPlans(any());
        Response response = ratePlanResource.getAllChildPlans(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateChildPlan() throws TracfoneOneException {
        when(tracfoneProfileController.updateChildPlan(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateChildPlan(tracfoneOneChildPlan);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateChildPlan_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).updateChildPlan(any(), anyInt());
        Response response = ratePlanResource.updateChildPlan(tracfoneOneChildPlan);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertChildPlan() throws TracfoneOneException {
        when(tracfoneProfileController.insertChildPlan(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertChildPlan(tracfoneOneChildPlan);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertChildPlan_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).insertChildPlan(any(), anyInt());
        Response response = ratePlanResource.insertChildPlan(tracfoneOneChildPlan);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteChildPlan() throws TracfoneOneException {
        when(tracfoneProfileController.deleteChildPlan(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteChildPlan(tracfoneOneChildPlan);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteChildPlan_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).deleteChildPlan(any(), anyInt());
        Response response = ratePlanResource.deleteChildPlan(tracfoneOneChildPlan);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierFeatureLinks() throws TracfoneOneException {
        List<TFOneCarrierFeature> tfOneCarrierFeatures = new ArrayList<>();
        TFOneCarrierFeature tfOneCarrierFeature = new TFOneCarrierFeature();
        tfOneCarrierFeature.setObjId("1");
        tfOneCarrierFeature.setxRatePlan("RATE_PLAN");
        List<TFOneRatePlanExtensionLink> tfOneRatePlanExtensionLinks = new ArrayList<>();
        TFOneRatePlanExtensionLink link = new TFOneRatePlanExtensionLink();
        link.setAncillaryCode("AL");
        link.setLineStatusCode("AL");
        link.setThrottleStatusCode("AL");
        link.setRatePlanExtensionId("AL");
        link.setCarrierFeatureId("1");
        link.setObjId("100");
        link.setProfileDescription("PROFILE_DESC");
        link.setProfileId("10");
        tfOneRatePlanExtensionLinks.add(link);
        tfOneCarrierFeature.setRpExtensionLinks(tfOneRatePlanExtensionLinks);
        tfOneCarrierFeatures.add(tfOneCarrierFeature);
        when(tracfoneRatePlanController.getCarrierFeatureLinks(anyList())).thenReturn(tfOneCarrierFeatures);

        List<TracfoneOneCarrierFeature> carrierFeatures = new ArrayList<>();
        carrierFeatures.add(tracfoneOneCarrierFeature);
        Response response = ratePlanResource.getCarrierFeatureLinks(carrierFeatures);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1\",\"dev\":null,\"xTechnology\":null,\"xRatePlan\":\"RATE_PLAN\",\"xVoicemail\":null,\"xVmCode\":null,\"xVmPackage\":null,\"xCallerId\":null,\"xIdCode\":null,\"xIdPackage\":null,\"xSms\":null,\"xSmsCode\":null,\"xSmsPackage\":null,\"xCallWaiting\":null,\"xCwCode\":null,\"xCwPackage\":null,\"xDigitalFeature\":null,\"xDigFeature\":null,\"xFeature2xCarrier\":null,\"xSmscNumber\":null,\"xData\":null,\"xRestrictedUse\":null,\"xSwitchBaseRate\":null,\"xFeatures2BusOrg\":null,\"xIsSwbCarrier\":null,\"xMpn\":null,\"xMpnCode\":null,\"xPoolName\":null,\"createMformIgFlag\":null,\"useCfExtensionFlag\":null,\"dataSaver\":null,\"dataSaverCode\":null,\"useRpExtensionFlag\":null,\"tmoNextGenFlag\":null,\"servicePlanId\":null,\"brand\":null,\"servicePlanCarrierFeature\":null,\"rpExtensionLinks\":[{\"objId\":\"100\",\"carrierFeatureId\":\"1\",\"childPlanId\":null,\"childPlanDescription\":null,\"ratePlanExtensionId\":\"AL\",\"lineStatusCode\":\"AL\",\"throttleStatusCode\":\"AL\",\"ancillaryCode\":\"AL\",\"profileId\":\"10\",\"profileDescription\":\"PROFILE_DESC\"}],\"xCarrierId\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierFeatureLinks_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getCarrierFeatureLinks(anyList());
        List<TracfoneOneCarrierFeature> carrierFeatures = new ArrayList<>();
        carrierFeatures.add(tracfoneOneCarrierFeature);
        Response response = ratePlanResource.getCarrierFeatureLinks(carrierFeatures);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchRpExtensions() throws TracfoneOneException {
        List<TFOneRatePlanExtension> tfOneRatePlanExtensions = new ArrayList<>();
        TFOneRatePlanExtension tfOneRatePlanExtension = new TFOneRatePlanExtension();
        tfOneRatePlanExtension.setObjId("1");
        tfOneRatePlanExtension.setAncillaryCode("AL");
        tfOneRatePlanExtension.setLineStatusCode("AD");
        tfOneRatePlanExtension.setThrottleStatusCode("TH");
        tfOneRatePlanExtensions.add(tfOneRatePlanExtension);
        when(tracfoneProfileController.searchRpExtensions(any())).thenReturn(tfOneRatePlanExtensions);
        Response response = ratePlanResource.searchRpExtensions(tracfoneOneRatePlanExtension);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1\",\"lineStatusCode\":\"AD\",\"throttleStatusCode\":\"TH\",\"ancillaryCode\":\"AL\"}]", response.getEntity().toString());
    }

    @Test
    public void testSearchRpExtensions_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).searchRpExtensions(any());
        Response response = ratePlanResource.searchRpExtensions(tracfoneOneRatePlanExtension);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertRpExtension() throws TracfoneOneException {
        when(tracfoneProfileController.insertRpExtension(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertRpExtension(tracfoneOneRatePlanExtension);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertRpExtension_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).insertRpExtension(any(), anyInt());
        Response response = ratePlanResource.insertRpExtension(tracfoneOneRatePlanExtension);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteRpExtension() throws TracfoneOneException {
        when(tracfoneProfileController.deleteRpExtension(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteRpExtension(tracfoneOneRatePlanExtension);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteRpExtension_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).deleteRpExtension(any(), anyInt());
        Response response = ratePlanResource.deleteRpExtension(tracfoneOneRatePlanExtension);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileBuckets() throws TracfoneOneException {
        List<TFOneCarrierProfileBucket> tfOneCarrierProfileBuckets = new ArrayList<>();
        TFOneCarrierProfileBucket carrierProfileBucket = new TFOneCarrierProfileBucket();
        carrierProfileBucket.setObjid("1");
        carrierProfileBucket.setActiveFlag("Y");
        carrierProfileBucket.setBucketId("BUCKET_ID");
        List<TFOneCarrierProfileBucketTier> tfOneCarrierProfileBucketTiers = new ArrayList<>();
        TFOneCarrierProfileBucketTier carrierProfileBucketTier = new TFOneCarrierProfileBucketTier();
        carrierProfileBucketTier.setObjId("100");
        carrierProfileBucketTier.setUsageTierId("101");
        carrierProfileBucketTier.setTierBehavior("TIER_BEHAVIOR");
        carrierProfileBucketTier.setTierDescription("TIER_DESC");
        tfOneCarrierProfileBucketTiers.add(carrierProfileBucketTier);
        carrierProfileBucket.setTfOneCarrierProfileBucketTiers(tfOneCarrierProfileBucketTiers);
        tfOneCarrierProfileBuckets.add(carrierProfileBucket);
        when(tracfoneBucketController.searchCarrierProfileBuckets(any())).thenReturn(tfOneCarrierProfileBuckets);
        Response response = ratePlanResource.searchCarrierProfileBuckets(tracfoneOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objid\":\"1\",\"profileId\":null,\"bucketId\":\"BUCKET_ID\",\"servicePlanId\":null,\"activeFlag\":\"Y\",\"unitOfMeasure\":null,\"bucketType\":null,\"bucketGroup\":null,\"bucketRequirement\":null,\"autoRenewFlag\":null,\"autoRenewFrequency\":null,\"autoRenewValue\":null,\"autoRenewDay\":null,\"benefitType\":null,\"bucketValue\":null,\"suiDisplayType\":null,\"priority\":null,\"hideUbiFlag\":null,\"tfOneCarrierProfileBucketTiers\":[{\"objId\":\"100\",\"carrierProfileBucketsObjId\":null,\"usageTierId\":\"101\",\"tierDescription\":\"TIER_DESC\",\"tierValue\":null,\"tierBehavior\":\"TIER_BEHAVIOR\"}]}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileBuckets_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneBucketController).searchCarrierProfileBuckets(any());
        Response response = ratePlanResource.searchCarrierProfileBuckets(tracfoneOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets() throws TracfoneOneException {
        List<TFOneCarrierProfileChildBucket> carrierProfileChildBuckets = new ArrayList<>();
        TFOneCarrierProfileChildBucket childBucket = new TFOneCarrierProfileChildBucket();
        childBucket.setObjId("1");
        childBucket.setActiveFlag("Y");
        childBucket.setBucketId("BUCKET_ID");
        List<TFOneCarrierProfileChildTier> carrierProfileChildTiers = new ArrayList<>();
        TFOneCarrierProfileChildTier childTier = new TFOneCarrierProfileChildTier();
        childTier.setObjId("100");
        childTier.setUsageTierId("101");
        childTier.setTierBehavior("TIER_BEHAVIOR");
        childTier.setTierDescription("TIER_DESC");
        carrierProfileChildTiers.add(childTier);
        childBucket.setTfOneCarrierProfileChildTiers(carrierProfileChildTiers);
        carrierProfileChildBuckets.add(childBucket);
        when(tracfoneBucketController.searchCarrierProfileChildBuckets(any())).thenReturn(carrierProfileChildBuckets);
        Response response = ratePlanResource.searchCarrierProfileChildBuckets(tracfoneOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1\",\"profileId\":null,\"servicePlanId\":null,\"childPlanId\":null,\"bucketId\":\"BUCKET_ID\",\"activeFlag\":\"Y\",\"unitOfMeasure\":null,\"bucketType\":null,\"bucketGroup\":null,\"bucketRequirement\":null,\"autoRenewFlag\":null,\"autoRenewFrequency\":null,\"autoRenewValue\":null,\"autoRenewDay\":null,\"benefitType\":null,\"bucketValue\":null,\"priority\":null,\"hideUbiFlag\":null,\"tfOneCarrierProfileChildTiers\":[{\"objId\":\"100\",\"carrierProfileChildObjId\":null,\"usageTierId\":\"101\",\"tierDescription\":\"TIER_DESC\",\"tierValue\":null,\"tierBehavior\":\"TIER_BEHAVIOR\"}]}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneBucketController).searchCarrierProfileChildBuckets(any());
        Response response = ratePlanResource.searchCarrierProfileChildBuckets(tracfoneOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testValidateAndAddProfileFeatures() throws TracfoneOneException {
        List<TracfoneOneRatePlanExtensionConfig> successExtensionConfigs = new ArrayList<>();
        TracfoneOneRatePlanExtensionConfig successExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        successExtensionConfig.setObjid("1000");
        successExtensionConfig.setProfileId("1000");
        successExtensionConfig.setFeatureName("FEATURE");
        successExtensionConfig.setRowNum("1");
        successExtensionConfigs.add(successExtensionConfig);
        TracfoneOneUploadProfileFeatures profileFeatures = new TracfoneOneUploadProfileFeatures();
        profileFeatures.setInsertFlag("Y");
        profileFeatures.setProfileId("1000");
        profileFeatures.setSuccessRpExtensionConfigs(successExtensionConfigs);

        List<TFOneRatePlanExtensionConfig> successRpExtensionConfigs = new ArrayList<>();
        TFOneRatePlanExtensionConfig successRpExtensionConfig = new TFOneRatePlanExtensionConfig();
        successRpExtensionConfig.setObjid("1000");
        successRpExtensionConfig.setProfileId("1000");
        successRpExtensionConfig.setFeatureValue("FEATURE");
        successRpExtensionConfigs.add(successRpExtensionConfig);
        TFOneUploadProfileFeatures tFOneUploadProfileFeatures = new TFOneUploadProfileFeatures();
        tFOneUploadProfileFeatures.setSuccessRpExtensionConfigs(successRpExtensionConfigs);
        when(tracfoneFeatureController.validateAndAddProfileFeatures(any(TracfoneOneUploadProfileFeatures.class), anyInt())).thenReturn(tFOneUploadProfileFeatures);
        Response response = ratePlanResource.validateAndAddProfileFeatures(profileFeatures);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"successRpExtensionConfigs\":[{\"objid\":\"1000\",\"profileId\":\"1000\",\"profileDescription\":null,\"featureName\":null,\"featureValue\":\"FEATURE\",\"featureRequirement\":null,\"toggleFlag\":null,\"notes\":null,\"displaySUIFlag\":null,\"restrictSUIFlag\":null,\"dbEnv\":null,\"rowNum\":null,\"errorMessages\":{}}],\"errorRpExtensionConfigs\":[]}", response.getEntity().toString());
    }

    @Test
    public void testValidateAndAddProfileFeatures_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneFeatureController).validateAndAddProfileFeatures(any(), anyInt());
        Response response = ratePlanResource.validateAndAddProfileFeatures(tracfoneOneUploadProfileFeatures);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertRatePlanAssociation() throws TracfoneOneException {
        List<TracfoneOneRatePlanExtensionLink> ratePlanExtensionLinks = new ArrayList<>();
        TracfoneOneRatePlanExtensionLink ratePlanExtensionLink = new TracfoneOneRatePlanExtensionLink();
        ratePlanExtensionLink.setProfileId("1000");
        ratePlanExtensionLink.setCarrierFeatureId("1000");
        ratePlanExtensionLinks.add(ratePlanExtensionLink);
        TracfoneOneCarrierFeature tracfoneOneCarrierFeature = new TracfoneOneCarrierFeature();
        tracfoneOneCarrierFeature.setObjId("1000");
        tracfoneOneCarrierFeature.setxTechnology("CDMA");
        tracfoneOneCarrierFeature.setRatePlanExtensionLinks(ratePlanExtensionLinks);
        when(tracfoneRatePlanController.insertRatePlanAssociation(any(), anyString(), anyString(), anyString(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertRatePlanAssociation(tracfoneOneCarrierFeature, "CARRIER_NAME", "100", "RATE_PLAN_NAME");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertRatePlanAssociation_whenException() throws TracfoneOneException {
        TracfoneOneCarrierFeature tracfoneOneCarrierFeature = new TracfoneOneCarrierFeature();
        tracfoneOneCarrierFeature.setObjId("1000");
        tracfoneOneCarrierFeature.setxTechnology("CDMA");
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).insertRatePlanAssociation(any(), anyString(), anyString(), anyString(), anyInt());
        Response response = ratePlanResource.insertRatePlanAssociation(tracfoneOneCarrierFeature, "", "", "");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierFeaturesForUpdate() throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        TFOneCarrierFeature tfOneCarrierFeature = new TFOneCarrierFeature();
        tfOneCarrierFeature.setObjId("1000");
        tfOneCarrierFeature.setxTechnology("CDMA");
        carrierFeatures.add(tfOneCarrierFeature);

        TracfoneOneCarrierFeature tracfoneOneCarrierFeature = new TracfoneOneCarrierFeature();
        tracfoneOneCarrierFeature.setxTechnology("CDMA");
        TracfoneOneSearchCarrierFeatureModel searchModel = new TracfoneOneSearchCarrierFeatureModel();
        searchModel.setServicePlanId("185");
        searchModel.setDbEnv(DBENV);
        searchModel.setTracfoneOneCarrierFeature(tracfoneOneCarrierFeature);
        when(tracfoneRatePlanController.searchCarrierFeaturesForUpdate(any())).thenReturn(carrierFeatures);
        Response response = ratePlanResource.searchCarrierFeaturesForUpdate(searchModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"dev\":null,\"xTechnology\":\"CDMA\",\"xRatePlan\":null,\"xVoicemail\":null,\"xVmCode\":null,\"xVmPackage\":null,\"xCallerId\":null,\"xIdCode\":null,\"xIdPackage\":null,\"xSms\":null,\"xSmsCode\":null,\"xSmsPackage\":null,\"xCallWaiting\":null,\"xCwCode\":null,\"xCwPackage\":null,\"xDigitalFeature\":null,\"xDigFeature\":null,\"xFeature2xCarrier\":null,\"xSmscNumber\":null,\"xData\":null,\"xRestrictedUse\":null,\"xSwitchBaseRate\":null,\"xFeatures2BusOrg\":null,\"xIsSwbCarrier\":null,\"xMpn\":null,\"xMpnCode\":null,\"xPoolName\":null,\"createMformIgFlag\":null,\"useCfExtensionFlag\":null,\"dataSaver\":null,\"dataSaverCode\":null,\"useRpExtensionFlag\":null,\"tmoNextGenFlag\":null,\"servicePlanId\":null,\"brand\":null,\"servicePlanCarrierFeature\":null,\"rpExtensionLinks\":[],\"xCarrierId\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierFeaturesForUpdate_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).searchCarrierFeaturesForUpdate(any());
        Response response = ratePlanResource.searchCarrierFeaturesForUpdate(tracfoneOneSearchCarrierFeatureModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertRpExtensionLink() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionLink tfRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfRpExtensionLink.setCarrierFeatureId("100");
        when(tracfoneProfileController.insertRpExtensionLink(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertRpExtensionLink(tfRpExtensionLink);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertRpExtensionLink_WhenException() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionLink tfRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        doThrow(tracfoneOneException).when(tracfoneProfileController).insertRpExtensionLink(any(), anyInt());
        Response response = ratePlanResource.insertRpExtensionLink(tfRpExtensionLink);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteRpExtensionLink() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfOneRpExtensionLink.setObjId("new_id");
        when(tracfoneProfileController.deleteRpExtensionLink(any(TracfoneOneRatePlanExtensionLink.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteRpExtensionLink(tfOneRpExtensionLink);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteRpExtensionLink_whenException() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        doThrow(tracfoneOneException).when(tracfoneProfileController).deleteRpExtensionLink(any(TracfoneOneRatePlanExtensionLink.class), anyInt());
        Response response = ratePlanResource.deleteRpExtensionLink(tfOneRpExtensionLink);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteAllRpExtensionLink() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfOneRpExtensionLink.setObjId("new_id");
        when(tracfoneProfileController.deleteRpExtensionLink(any(TracfoneOneRatePlanExtensionLink.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteAllRpExtensionLink(tfOneRpExtensionLink);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteRpAllExtensionLink_whenException() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        doThrow(tracfoneOneException).when(tracfoneProfileController).deleteRpExtensionLink(any(TracfoneOneRatePlanExtensionLink.class), anyInt());
        Response response = ratePlanResource.deleteAllRpExtensionLink(tfOneRpExtensionLink);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateRpExtensionLink() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfOneRpExtensionLink.setObjId("new_id");
        tfOneRpExtensionLink.setCarrierFeatureId("CARRIER_FEATURE_ID");
        when(tracfoneProfileController.updateRpExtensionLink(any(TracfoneOneRatePlanExtensionLink.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateRpExtensionLink(tfOneRpExtensionLink);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateRpExtensionLink_whenException() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        doThrow(tracfoneOneException).when(tracfoneProfileController).updateRpExtensionLink(any(TracfoneOneRatePlanExtensionLink.class), anyInt());
        Response response = ratePlanResource.updateRpExtensionLink(tfOneRpExtensionLink);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierProfileChildBucket() throws TracfoneOneException {
        TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket = new TracfoneOneCarrierProfileChildBucket();
        tfCarrierProfileChildBucket.setActiveFlag("Y");
        tfCarrierProfileChildBucket.setAutoRenewFlag("Y");
        tfCarrierProfileChildBucket.setObjId("1000");
        when(tracfoneBucketController.updateCarrierProfileChildBucket(any(TracfoneOneCarrierProfileChildBucket.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateCarrierProfileChildBucket(tfCarrierProfileChildBucket);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierProfileChildBucket_whenException() throws TracfoneOneException {
        TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket = new TracfoneOneCarrierProfileChildBucket();
        doThrow(tracfoneOneException).when(tracfoneBucketController).updateCarrierProfileChildBucket(any(TracfoneOneCarrierProfileChildBucket.class), anyInt());
        Response response = ratePlanResource.updateCarrierProfileChildBucket(tfCarrierProfileChildBucket);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testCarrierProfileChildBucketTier() throws TracfoneOneException {
        TracfoneOneCarrierProfileChildTier tfCarrierProfileChildTier = new TracfoneOneCarrierProfileChildTier();
        tfCarrierProfileChildTier.setUsageTierId("Y");
        tfCarrierProfileChildTier.setObjId("1000");
        tfCarrierProfileChildTier.setDbEnv(DBENV);
        when(tracfoneBucketController.updateCarrierProfileChildBucketTier(any(TracfoneOneCarrierProfileChildTier.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateCarrierProfileChildBucketTier(tfCarrierProfileChildTier);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testCarrierProfileChildBucketTier_whenException() throws TracfoneOneException {
        TracfoneOneCarrierProfileChildTier tfCarrierProfileChildTier = new TracfoneOneCarrierProfileChildTier();
        doThrow(tracfoneOneException).when(tracfoneBucketController).updateCarrierProfileChildBucketTier(any(TracfoneOneCarrierProfileChildTier.class), anyInt());
        Response response = ratePlanResource.updateCarrierProfileChildBucketTier(tfCarrierProfileChildTier);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteCarrierProfileChildBucket() throws TracfoneOneException {
        List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket = new TracfoneOneCarrierProfileChildBucket();
        tfCarrierProfileChildBucket.setObjId("1000");
        tfCarrierProfileChildBuckets.add(tfCarrierProfileChildBucket);
        when(tracfoneBucketController.deleteCarrierProfileChildBucket(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteCarrierProfileChildBucket(tfCarrierProfileChildBuckets);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }


    @Test
    public void testDeleteCarrierProfileChildBucket_whenException() throws TracfoneOneException {
        List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneBucketController).deleteCarrierProfileChildBucket(any(), anyInt());
        Response response = ratePlanResource.deleteCarrierProfileChildBucket(tfCarrierProfileChildBuckets);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteCarrierProfileChildBucketTier() throws TracfoneOneException {
        TracfoneOneCarrierProfileChildTier tfCarrierProfileChildTier = new TracfoneOneCarrierProfileChildTier();
        tfCarrierProfileChildTier.setDbEnv(DBENV);
        tfCarrierProfileChildTier.setObjId("1000");
        when(tracfoneBucketController.deleteCarrierProfileChildBucketTier(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteCarrierProfileChildBucketTier(tfCarrierProfileChildTier);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }


    @Test
    public void testDeleteCarrierProfileChildBucketTier_whenException() throws TracfoneOneException {
        TracfoneOneCarrierProfileChildTier tfCarrierProfileChildTier = new TracfoneOneCarrierProfileChildTier();
        doThrow(tracfoneOneException).when(tracfoneBucketController).deleteCarrierProfileChildBucketTier(any(), anyInt());
        Response response = ratePlanResource.deleteCarrierProfileChildBucketTier(tfCarrierProfileChildTier);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierProfileChildBucket() throws TracfoneOneException {
        List<TFOneCarrierProfileChildBucket> tfOneChildBuckets = new ArrayList<>();
        TFOneCarrierProfileChildBucket tfOneCarrierProfileChildBucket = new TFOneCarrierProfileChildBucket();
        tfOneCarrierProfileChildBucket.setActiveFlag("Y");
        tfOneCarrierProfileChildBucket.setAutoRenewFlag("Y");
        tfOneCarrierProfileChildBucket.setObjId("1000");
        tfOneChildBuckets.add(tfOneCarrierProfileChildBucket);
        List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket = new TracfoneOneCarrierProfileChildBucket();
        tfCarrierProfileChildBucket.setActiveFlag("Y");
        tfCarrierProfileChildBucket.setAutoRenewFlag("Y");
        tfCarrierProfileChildBucket.setObjId("1000");
        tfCarrierProfileChildBuckets.add(tfCarrierProfileChildBucket);
        when(tracfoneBucketController.insertCarrierProfileChildBucket(any(), anyString(), anyInt())).thenReturn(tfOneChildBuckets);
        Response response = ratePlanResource.insertCarrierProfileChildBucket(tfCarrierProfileChildBuckets, "PARENT_SHORT_NAME");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"profileId\":null,\"servicePlanId\":null,\"childPlanId\":null,\"bucketId\":null,\"activeFlag\":\"Y\",\"unitOfMeasure\":null,\"bucketType\":null,\"bucketGroup\":null,\"bucketRequirement\":null,\"autoRenewFlag\":\"Y\",\"autoRenewFrequency\":null,\"autoRenewValue\":null,\"autoRenewDay\":null,\"benefitType\":null,\"bucketValue\":null,\"priority\":null,\"hideUbiFlag\":null,\"tfOneCarrierProfileChildTiers\":[]}]", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierProfileChildBucket_whenException() throws TracfoneOneException {
        List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneBucketController).insertCarrierProfileChildBucket(any(), anyString(), anyInt());
        Response response = ratePlanResource.insertCarrierProfileChildBucket(tfCarrierProfileChildBuckets, "PARENT_SHORT_NAME");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierProfileBucket() throws TracfoneOneException {
        List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileBucket tfCarrierProfileBucket = new TracfoneOneCarrierProfileBucket();
        tfCarrierProfileBucket.setActiveFlag("Y");
        tfCarrierProfileBucket.setAutoRenewFlag("Y");
        tfCarrierProfileBucket.setObjectId("1000");
        tfCarrierProfileBucket.setDbEnv(DBENV);

        tfCarrierProfileBuckets.add(tfCarrierProfileBucket);
        List<TFOneCarrierProfileBucket> tfOneBuckets = new ArrayList<>();
        TFOneCarrierProfileBucket tfOneCarrierProfileBucket = new TFOneCarrierProfileBucket();
        tfOneCarrierProfileBucket.setAutoRenewFlag("Y");
        tfOneCarrierProfileBucket.setActiveFlag("Y");
        tfOneCarrierProfileBucket.setObjid("1000");
        tfOneBuckets.add(tfOneCarrierProfileBucket);
        when(tracfoneBucketController.insertCarrierProfileBucket(any(), anyString(), anyInt())).thenReturn(tfOneBuckets);
        Response response = ratePlanResource.insertCarrierProfileBucket(tfCarrierProfileBuckets, "PARENT_SHORT_NAME");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objid\":\"1000\",\"profileId\":null,\"bucketId\":null,\"servicePlanId\":null,\"activeFlag\":\"Y\",\"unitOfMeasure\":null,\"bucketType\":null,\"bucketGroup\":null,\"bucketRequirement\":null,\"autoRenewFlag\":\"Y\",\"autoRenewFrequency\":null,\"autoRenewValue\":null,\"autoRenewDay\":null,\"benefitType\":null,\"bucketValue\":null,\"suiDisplayType\":null,\"priority\":null,\"hideUbiFlag\":null,\"tfOneCarrierProfileBucketTiers\":null}]", response.getEntity().toString());
    }

    @Test
    public void testInsertCarrierProfileBucket_whenException() throws TracfoneOneException {
        List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneBucketController).insertCarrierProfileBucket(any(), anyString(), anyInt());
        Response response = ratePlanResource.insertCarrierProfileBucket(tfCarrierProfileBuckets, "PARENT_SHORT_NAME");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierProfileBucket() throws TracfoneOneException {
        TracfoneOneCarrierProfileBucket tfCarrierProfileBucket = new TracfoneOneCarrierProfileBucket();
        tfCarrierProfileBucket.setActiveFlag("Y");
        tfCarrierProfileBucket.setAutoRenewFlag("Y");
        tfCarrierProfileBucket.setObjectId("new_id");
        when(tracfoneBucketController.updateCarrierProfileBucket(any(TracfoneOneCarrierProfileBucket.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateCarrierProfileBucket(tfCarrierProfileBucket);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierProfileBucket_whenException() throws TracfoneOneException {
        TracfoneOneCarrierProfileBucket tfCarrierProfileBucket = new TracfoneOneCarrierProfileBucket();
        doThrow(tracfoneOneException).when(tracfoneBucketController).updateCarrierProfileBucket(any(TracfoneOneCarrierProfileBucket.class), anyInt());
        Response response = ratePlanResource.updateCarrierProfileBucket(tfCarrierProfileBucket);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierProfileBucketTier() throws TracfoneOneException {
        TracfoneOneCarrierProfileBucketTier tfCarrierProfileBucketTier = new TracfoneOneCarrierProfileBucketTier();
        tfCarrierProfileBucketTier.setDbEnv(DBENV);
        tfCarrierProfileBucketTier.setObjId("1000");
        when(tracfoneBucketController.updateCarrierProfileBucketTier(any(TracfoneOneCarrierProfileBucketTier.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateCarrierProfileBucketTier(tfCarrierProfileBucketTier);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateCarrierProfileBucketTier_whenException() throws TracfoneOneException {
        TracfoneOneCarrierProfileBucketTier tfCarrierProfileBucketTier = new TracfoneOneCarrierProfileBucketTier();
        doThrow(tracfoneOneException).when(tracfoneBucketController).updateCarrierProfileBucketTier(any(TracfoneOneCarrierProfileBucketTier.class), anyInt());
        Response response = ratePlanResource.updateCarrierProfileBucketTier(tfCarrierProfileBucketTier);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteCarrierProfileBucket() throws TracfoneOneException {
        List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileBucket tfCarrierProfileBucket = new TracfoneOneCarrierProfileBucket();
        tfCarrierProfileBucket.setObjectId("1000");
        tfCarrierProfileBucket.setDbEnv(DBENV);
        tfCarrierProfileBuckets.add(tfCarrierProfileBucket);
        when(tracfoneBucketController.deleteCarrierProfileBucket(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteCarrierProfileBucket(tfCarrierProfileBuckets);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteCarrierProfileBucket_whenException() throws TracfoneOneException {
        List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneBucketController).deleteCarrierProfileBucket(anyList(), anyInt());
        Response response = ratePlanResource.deleteCarrierProfileBucket(tfCarrierProfileBuckets);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteCarrierProfileBucketTier() throws TracfoneOneException {
        TracfoneOneCarrierProfileBucketTier tfCarrierProfileBucketTier = new TracfoneOneCarrierProfileBucketTier();
        tfCarrierProfileBucketTier.setDbEnv(DBENV);
        tfCarrierProfileBucketTier.setObjId("1000");
        when(tracfoneBucketController.deleteCarrierProfileBucketTier(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteCarrierProfileBucketTier(tfCarrierProfileBucketTier);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteCarrierProfileBucketTier_whenException() throws TracfoneOneException {
        TracfoneOneCarrierProfileBucketTier tfCarrierProfileBucketTier = new TracfoneOneCarrierProfileBucketTier();
        doThrow(tracfoneOneException).when(tracfoneBucketController).deleteCarrierProfileBucketTier(any(), anyInt());
        Response response = ratePlanResource.deleteCarrierProfileBucketTier(tfCarrierProfileBucketTier);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchBucketProfile() throws TracfoneOneException {
        List<TFOneRatePlanProfile> tfOneRatePlanProfiles = new ArrayList<>();
        TFOneRatePlanProfile tFOneRatePlanProfile = new TFOneRatePlanProfile();
        tFOneRatePlanProfile.setProfileId("5401");
        tfOneRatePlanProfiles.add(tFOneRatePlanProfile);
        when(tracfoneFeatureController.searchBucketProfile(any())).thenReturn(tfOneRatePlanProfiles);
        Response response = ratePlanResource.searchBucketProfile(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"profileId\":\"5401\",\"profileDescription\":null,\"rpExtensionLinks\":null,\"rpExtensionConfigs\":null,\"features\":null,\"buckets\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchBucketProfile_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneFeatureController).searchBucketProfile(any());
        Response response = ratePlanResource.searchBucketProfile(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchChildBucketProfile() throws TracfoneOneException {
        List<TFOneRatePlanProfile> tfOneRatePlanProfiles = new ArrayList<>();
        TFOneRatePlanProfile tFOneRatePlanProfile = new TFOneRatePlanProfile();
        tFOneRatePlanProfile.setProfileId("5401");
        tfOneRatePlanProfiles.add(tFOneRatePlanProfile);
        when(tracfoneFeatureController.searchChildBucketProfile(any())).thenReturn(tfOneRatePlanProfiles);
        Response response = ratePlanResource.searchChildBucketProfile(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"profileId\":\"5401\",\"profileDescription\":null,\"rpExtensionLinks\":null,\"rpExtensionConfigs\":null,\"features\":null,\"buckets\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchChildBucketProfile_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneFeatureController).searchChildBucketProfile(any());
        Response response = ratePlanResource.searchChildBucketProfile(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetBucketServicePlansForCopy() throws TracfoneOneException {
        List<TFOneCarrierServicePlan> bucketServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan bucketServicePlan = new TFOneCarrierServicePlan();
        bucketServicePlan.setMktName("MKT_NAME");
        bucketServicePlan.setDescription("DESCRIPTION");
        bucketServicePlan.setCarrierName("CARRIER_NAME");
        bucketServicePlans.add(bucketServicePlan);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setProfileId("1501");
        tracfoneOneSearchPlanModel.setRatePlanName("RATE_PLAN_NAME");
        when(tracfoneFeatureController.getBucketServicePlansForCopy(any(TracfoneOneSearchPlanModel.class))).thenReturn(bucketServicePlans);
        Response response = ratePlanResource.getBucketServicePlansForCopy(tracfoneOneSearchPlanModel);
        assertEquals("[{\"carrierName\":\"CARRIER_NAME\",\"servicePlanId\":null,\"mktName\":\"MKT_NAME\",\"description\":\"DESCRIPTION\",\"servicePlanPurchase\":null,\"parentName\":null,\"servicePlans\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBucketServicePlansForCopy_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).getBucketServicePlansForCopy(any(TracfoneOneSearchPlanModel.class));
        Response response = ratePlanResource.getBucketServicePlansForCopy(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetChildBucketServicePlansForCopy() throws TracfoneOneException {
        List<TFOneCarrierServicePlan> bucketServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan bucketServicePlan = new TFOneCarrierServicePlan();
        bucketServicePlan.setMktName("MKT_NAME");
        bucketServicePlan.setDescription("DESCRIPTION");
        bucketServicePlan.setCarrierName("CARRIER_NAME");
        bucketServicePlans.add(bucketServicePlan);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setProfileId("1501");
        tracfoneOneSearchPlanModel.setRatePlanName("RATE_PLAN_NAME");
        when(tracfoneFeatureController.getChildBucketServicePlansForCopy(any(TracfoneOneSearchPlanModel.class))).thenReturn(bucketServicePlans);
        Response response = ratePlanResource.getChildBucketServicePlansForCopy(tracfoneOneSearchPlanModel);
        assertEquals("[{\"carrierName\":\"CARRIER_NAME\",\"servicePlanId\":null,\"mktName\":\"MKT_NAME\",\"description\":\"DESCRIPTION\",\"servicePlanPurchase\":null,\"parentName\":null,\"servicePlans\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetChildBucketServicePlansForCopy_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).getChildBucketServicePlansForCopy(any(TracfoneOneSearchPlanModel.class));
        Response response = ratePlanResource.getChildBucketServicePlansForCopy(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetBucketChildPlans() throws TracfoneOneException {
        List<TFOneChildPlan> childPlans = new ArrayList<>();
        TFOneChildPlan childPlan = new TFOneChildPlan();
        childPlan.setChildDescription("DESCRIPTION");
        childPlan.setChildPlanName("CHILD_NAME");
        childPlan.setChildPlanId("1000");
        childPlans.add(childPlan);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setProfileId("1501");
        tracfoneOneSearchPlanModel.setRatePlanName("RATE_PLAN_NAME");
        when(tracfoneFeatureController.getBucketChildPlans(any(TracfoneOneSearchPlanModel.class))).thenReturn(childPlans);
        Response response = ratePlanResource.getBucketChildPlans(tracfoneOneSearchPlanModel);
        assertEquals("[{\"childPlanId\":\"1000\",\"childDescription\":\"DESCRIPTION\",\"childPlanName\":\"CHILD_NAME\",\"ratePlanProfile\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBucketChildPlans_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).getBucketChildPlans(any(TracfoneOneSearchPlanModel.class));
        Response response = ratePlanResource.getBucketChildPlans(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllLineStatusCodes() throws TracfoneOneException {
        List<TFOneLineStatusCode> lineStatusCodes = new ArrayList<>();
        TFOneLineStatusCode lineStatusCode = new TFOneLineStatusCode();
        lineStatusCode.setDescription("DESCRIPTION");
        lineStatusCode.setLineStatusCode("STATUS_CODE");
        lineStatusCodes.add(lineStatusCode);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setProfileId("1501");
        tracfoneOneSearchPlanModel.setRatePlanName("RATE_PLAN_NAME");
        when(tracfoneFeatureController.getAllLineStatusCodes(anyString())).thenReturn(lineStatusCodes);
        Response response = ratePlanResource.getAllLineStatusCodes(tracfoneOneSearchPlanModel);
        assertEquals("[{\"lineStatusCode\":\"STATUS_CODE\",\"description\":\"DESCRIPTION\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllLineStatusCodes_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setProfileId("5401");
        doThrow(tracfoneOneException).when(tracfoneFeatureController).getAllLineStatusCodes(null);
        Response response = ratePlanResource.getAllLineStatusCodes(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertLineStatusCode() throws TracfoneOneException {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DBENV);
        tfOneLineStatus.setDescription("DESCRIPTION");
        tfOneLineStatus.setLineStatusCode("LINE_STATUS_CODE");
        when(tracfoneFeatureController.insertLineStatusCode(any(TracfoneOneLineStatusCode.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertLineStatusCode(tfOneLineStatus);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertLineStatusCode_whenException() throws TracfoneOneException {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).insertLineStatusCode(any(TracfoneOneLineStatusCode.class), anyInt());
        Response response = ratePlanResource.insertLineStatusCode(tfOneLineStatus);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateLineStatusCode() throws TracfoneOneException {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DBENV);
        tfOneLineStatus.setDescription("DESCRIPTION");
        tfOneLineStatus.setLineStatusCode("LINE_STATUS_CODE");
        when(tracfoneFeatureController.updateLineStatusCode(any(TracfoneOneLineStatusCode.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateLineStatusCode(tfOneLineStatus);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateLineStatusCode_whenException() throws TracfoneOneException {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).updateLineStatusCode(any(TracfoneOneLineStatusCode.class), anyInt());
        Response response = ratePlanResource.updateLineStatusCode(tfOneLineStatus);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllThrottleStatusCodes() throws TracfoneOneException {
        List<TFOneThrottleStatusCode> throttleStatusCodes = new ArrayList<>();
        TFOneThrottleStatusCode throttleStatusCode = new TFOneThrottleStatusCode();
        throttleStatusCode.setDescription("DESCRIPTION");
        throttleStatusCodes.add(throttleStatusCode);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setProfileId("1501");
        tracfoneOneSearchPlanModel.setRatePlanName("RATE_PLAN_NAME");
        when(tracfoneFeatureController.getAllThrottleStatusCodes(anyString())).thenReturn(throttleStatusCodes);
        Response response = ratePlanResource.getAllThrottleStatusCodes(tracfoneOneSearchPlanModel);
        assertEquals("[{\"throttleStatusCode\":null,\"description\":\"DESCRIPTION\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllThrottleStatusCodes_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setProfileId("5401");
        doThrow(tracfoneOneException).when(tracfoneFeatureController).getAllThrottleStatusCodes(null);
        Response response = ratePlanResource.getAllThrottleStatusCodes(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertThrottleStatusCode() throws TracfoneOneException {
        TracfoneOneThrottleStatusCode tfThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfThrottleStatusCode.setDbEnv(DBENV);
        tfThrottleStatusCode.setDescription("DESCRIPTION");
        when(tracfoneFeatureController.insertThrottleStatusCode(any(TracfoneOneThrottleStatusCode.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertThrottleStatusCode(tfThrottleStatusCode);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertThrottleStatusCode_whenException() throws TracfoneOneException {
        TracfoneOneThrottleStatusCode tfThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).insertThrottleStatusCode(any(TracfoneOneThrottleStatusCode.class), anyInt());
        Response response = ratePlanResource.insertThrottleStatusCode(tfThrottleStatusCode);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateThrottleStatusCode() throws TracfoneOneException {
        TracfoneOneThrottleStatusCode tfThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfThrottleStatusCode.setDbEnv(DBENV);
        tfThrottleStatusCode.setDescription("DESCRIPTION");
        when(tracfoneFeatureController.updateThrottleStatusCode(any(TracfoneOneThrottleStatusCode.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateThrottleStatusCode(tfThrottleStatusCode);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateThrottleStatusCode_whenException() throws TracfoneOneException {
        TracfoneOneThrottleStatusCode tfThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).updateThrottleStatusCode(any(TracfoneOneThrottleStatusCode.class), anyInt());
        Response response = ratePlanResource.updateThrottleStatusCode(tfThrottleStatusCode);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertFeatureRequirement() throws TracfoneOneException {
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfFeatureRequirement.setDbEnv(DBENV);
        tfFeatureRequirement.setDescription("DESCRIPTION");
        when(tracfoneFeatureController.insertFeatureRequirement(any(TracfoneOneFeatureRequirement.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertFeatureRequirement(tfFeatureRequirement);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertFeatureRequirement_whenException() throws TracfoneOneException {
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).insertFeatureRequirement(any(TracfoneOneFeatureRequirement.class), anyInt());
        Response response = ratePlanResource.insertFeatureRequirement(tfFeatureRequirement);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateFeatureRequirement() throws TracfoneOneException {
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfFeatureRequirement.setDbEnv(DBENV);
        tfFeatureRequirement.setDescription("DESCRIPTION");
        when(tracfoneFeatureController.updateFeatureRequirement(any(TracfoneOneFeatureRequirement.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateFeatureRequirement(tfFeatureRequirement);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateFeatureRequirement_whenException() throws TracfoneOneException {
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).updateFeatureRequirement(any(TracfoneOneFeatureRequirement.class), anyInt());
        Response response = ratePlanResource.updateFeatureRequirement(tfFeatureRequirement);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllFeatureRequirements() throws TracfoneOneException {
        List<TFOneFeatureRequirement> tfFeatureRequirements = new ArrayList<>();
        TFOneFeatureRequirement tfOneFeatureRequirement = new TFOneFeatureRequirement();
        tfOneFeatureRequirement.setDescription("DESCRIPTION");
        tfOneFeatureRequirement.setFeatureRequirement("FEATURE_REQUIREMENT");
        tfFeatureRequirements.add(tfOneFeatureRequirement);
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfFeatureRequirement.setDbEnv(DBENV);
        tfFeatureRequirement.setDescription("DESCRIPTION");
        when(tracfoneFeatureController.getAllFeatureRequirements(anyString())).thenReturn(tfFeatureRequirements);
        Response response = ratePlanResource.getAllFeatureRequirements(tfFeatureRequirement);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"featureRequirement\":\"FEATURE_REQUIREMENT\",\"description\":\"DESCRIPTION\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllFeatureRequirements_whenException() throws TracfoneOneException {
        TracfoneOneFeatureRequirement tfFeatureRequirement = new TracfoneOneFeatureRequirement();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).getAllFeatureRequirements(null);
        Response response = ratePlanResource.getAllFeatureRequirements(tfFeatureRequirement);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testCopyAllBucketsFromProfile() throws TracfoneOneException {
        List<String> profileIds = new ArrayList<>();
        profileIds.add("1000");
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add("1000");
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setDbEnv(DBENV);
        tfOneSearchBucketModel.setChildPlanId("100");
        tfOneSearchBucketModel.setProfileIds(profileIds);
        tfOneSearchBucketModel.setServicePlanIds(servicePlanIds);
        when(tracfoneBucketController.copyAllBucketsFromProfile(any(TracfoneOneSearchBucketModel.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.copyAllBucketsFromProfile(tfOneSearchBucketModel);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testCopyAllBucketsFromProfile_whenException() throws TracfoneOneException {
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        doThrow(tracfoneOneException).when(tracfoneBucketController).copyAllBucketsFromProfile(any(TracfoneOneSearchBucketModel.class), anyInt());
        Response response = ratePlanResource.copyAllBucketsFromProfile(tfOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteAllBucketsAndTiers() throws TracfoneOneException {
        List<String> profileIds = new ArrayList<>();
        profileIds.add("1000");
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add("1000");
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setDbEnv(DBENV);
        tfOneSearchBucketModel.setProfileIds(profileIds);
        tfOneSearchBucketModel.setServicePlanIds(servicePlanIds);
        when(tracfoneBucketController.deleteAllBucketsAndTiers(any(TracfoneOneSearchBucketModel.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteAllBucketsAndTiers(tfOneSearchBucketModel);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteAllBucketsAndTiers_whenException() throws TracfoneOneException {
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        doThrow(tracfoneOneException).when(tracfoneBucketController).deleteAllBucketsAndTiers(any(TracfoneOneSearchBucketModel.class), anyInt());
        Response response = ratePlanResource.deleteAllBucketsAndTiers(tfOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }


    @Test
    public void testUpdateAllBucketsWithProfileId() throws TracfoneOneException {
        List<String> profileIds = new ArrayList<>();
        profileIds.add("1000");
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add("1000");
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setDbEnv(DBENV);
        tfOneSearchBucketModel.setOldProfileId("1001");
        tfOneSearchBucketModel.setProfileIds(profileIds);
        tfOneSearchBucketModel.setServicePlanIds(servicePlanIds);
        when(tracfoneBucketController.updateAllBucketsWithProfileId(any(TracfoneOneSearchBucketModel.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateAllBucketsWithProfileId(tfOneSearchBucketModel);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateAllBucketsWithProfileId_whenException() throws TracfoneOneException {
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        doThrow(tracfoneOneException).when(tracfoneBucketController).updateAllBucketsWithProfileId(any(TracfoneOneSearchBucketModel.class), anyInt());
        Response response = ratePlanResource.updateAllBucketsWithProfileId(tfOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllCarrierIds() throws TracfoneOneException {
        List<TFOneCarrier> carriers = new ArrayList<>();
        TFOneCarrier carrier = new TFOneCarrier();
        carrier.setCarrierId("100");
        carrier.setObjId("200");
        carrier.setSubmarketName("T-MOBILE PREPAID");
        carriers.add(carrier);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setCarrierName("T-MOBILE");
        when(tracfoneFeatureController.getAllCarrierIds(any(), any(), any())).thenReturn(carriers);
        Response response = ratePlanResource.getAllCarrierIds(tracfoneOneSearchPlanModel, "100");
        assertEquals("[{\"objId\":\"200\",\"carrierId\":\"100\",\"submarketName\":\"T-MOBILE PREPAID\",\"submarketOf\":null,\"city\":null,\"state\":null,\"tapeReturnCharge\":null,\"countryCode\":null,\"activeLinePercent\":null,\"status\":null,\"ldProvider\":null,\"ldAccount\":null,\"ldPicCode\":null,\"ratePlan\":null,\"dummyEsn\":null,\"billDate\":null,\"voiceMail\":null,\"vmCode\":null,\"vmPackage\":null,\"callerId\":null,\"idCode\":null,\"idPackage\":null,\"callWaiting\":null,\"cwCode\":null,\"cwPackage\":null,\"reactTechnology\":null,\"reactAnalog\":null,\"actTechnology\":null,\"actAnalog\":null,\"digitalRatePlan\":null,\"digitalFeature\":null,\"prlPreLoaded\":null,\"carrier2CarrierGroup\":null,\"tapeReturnAddr2Address\":null,\"carrier2Provider\":null,\"carrier2Address\":null,\"carrier2Personality\":null,\"carrier2Rule\":null,\"carrier2CarrScript\":null,\"specialMkt\":null,\"newAnalogPlan\":null,\"newDigitalPlan\":null,\"sms\":null,\"smsCode\":null,\"smsPackage\":null,\"vmSetUpLandLine\":null,\"carrier2RulesCdma\":null,\"carrier2RulesGsm\":null,\"carrier2RulesTdma\":null,\"dataService\":null,\"automated\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllCarrierIds_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).getAllCarrierIds(any(), any(), any());
        Response response = ratePlanResource.getAllCarrierIds(tracfoneOneSearchPlanModel, "100");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetProfileServicePlans() throws TracfoneOneException {
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan servicePlan = new TFOneCarrierServicePlan();
        servicePlan.setServicePlanId("500");
        servicePlan.setDescription("SAFELINK");
        carrierServicePlans.add(servicePlan);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        when(tracfoneProfileController.getProfileServicePlans(any(), any())).thenReturn(carrierServicePlans);
        Response response = ratePlanResource.getProfileServicePlans(tracfoneOneSearchPlanModel, "100");
        assertEquals("[{\"carrierName\":null,\"servicePlanId\":\"500\",\"mktName\":null,\"description\":\"SAFELINK\",\"servicePlanPurchase\":null,\"parentName\":null,\"servicePlans\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetProfileServicePlans_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneProfileController).getProfileServicePlans(any(), any());
        Response response = ratePlanResource.getProfileServicePlans(tracfoneOneSearchPlanModel, "100");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetRatePlanServicePlans() throws TracfoneOneException {
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan servicePlan = new TFOneCarrierServicePlan();
        servicePlan.setServicePlanId("500");
        servicePlan.setDescription("SAFELINK");
        carrierServicePlans.add(servicePlan);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        when(tracfoneProfileController.getRatePlanServicePlans(any(), any())).thenReturn(carrierServicePlans);
        Response response = ratePlanResource.getRatePlanServicePlans(tracfoneOneSearchPlanModel, "100");
        assertEquals("[{\"carrierName\":null,\"servicePlanId\":\"500\",\"mktName\":null,\"description\":\"SAFELINK\",\"servicePlanPurchase\":null,\"parentName\":null,\"servicePlans\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetRatePlanServicePlans_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneProfileController).getRatePlanServicePlans(any(), any());
        Response response = ratePlanResource.getRatePlanServicePlans(tracfoneOneSearchPlanModel, "100");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierFeatureRatePlans() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setCarrierName("CARRIER_NAME");
        List<TFOneRatePlan> allRatePlans = new ArrayList<>();
        TFOneRatePlan tFOneRatePlan = new TFOneRatePlan();
        tFOneRatePlan.setObjId("1000");
        allRatePlans.add(tFOneRatePlan);
        when(tracfoneRatePlanController.getCarrierRatePlans(anyString(), anyString())).thenReturn(allRatePlans);
        Response response = ratePlanResource.getCarrierFeatureRatePlans(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"ratePlanName\":null,\"privateNetwork\":null,\"espidUpdate\":null,\"espidNum\":null,\"propagateFlagValue\":null,\"allowMformApnRequestFlag\":null,\"calculateDataUnitsFlag\":null,\"thresholdsToTmo\":null,\"hotspotBucketsFlag\":null,\"tmoNextGenFlag\":null,\"ratePlanProfile\":[],\"carrierFeatures\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierFeatureRatePlans_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getCarrierRatePlans(any(), any());
        Response response = ratePlanResource.getCarrierFeatureRatePlans(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertAncillaryCodeConfig() throws TracfoneOneException {
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        tfAncillaryCodeConfig.setDbEnv(DBENV);
        tfAncillaryCodeConfig.setDisplaySUIFlag("Y");
        tfAncillaryCodeConfig.setProfileId("1000");
        when(tracfoneProfileController.insertAncillaryCodeConfig(any(TracfoneOneAncillaryCodeConfig.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertAncillaryCodeConfig(tfAncillaryCodeConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertAncillaryCodeConfig_whenException() throws TracfoneOneException {
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        doThrow(tracfoneOneException).when(tracfoneProfileController).insertAncillaryCodeConfig(any(TracfoneOneAncillaryCodeConfig.class), anyInt());
        Response response = ratePlanResource.insertAncillaryCodeConfig(tfAncillaryCodeConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateAncillaryCodeConfig() throws TracfoneOneException {
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        tfAncillaryCodeConfig.setDbEnv(DBENV);
        tfAncillaryCodeConfig.setDisplaySUIFlag("Y");
        tfAncillaryCodeConfig.setProfileId("1000");
        tfAncillaryCodeConfig.setExtensionObjId("1000");
        when(tracfoneProfileController.updateAncillaryCodeConfig(any(TracfoneOneAncillaryCodeConfig.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateAncillaryCodeConfig(tfAncillaryCodeConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateAncillaryCodeConfig_whenException() throws TracfoneOneException {
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        doThrow(tracfoneOneException).when(tracfoneProfileController).updateAncillaryCodeConfig(any(TracfoneOneAncillaryCodeConfig.class), anyInt());
        Response response = ratePlanResource.updateAncillaryCodeConfig(tfAncillaryCodeConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteAncillaryCodeConfig() throws TracfoneOneException {
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        tfAncillaryCodeConfig.setDbEnv(DBENV);
        tfAncillaryCodeConfig.setDisplaySUIFlag("Y");
        tfAncillaryCodeConfig.setProfileId("1000");
        tfAncillaryCodeConfig.setExtensionObjId("1000");
        when(tracfoneProfileController.deleteAncillaryCodeConfig(any(TracfoneOneAncillaryCodeConfig.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteAncillaryCodeConfig(tfAncillaryCodeConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteAncillaryCodeConfig_whenException() throws TracfoneOneException {
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        doThrow(tracfoneOneException).when(tracfoneProfileController).deleteAncillaryCodeConfig(any(TracfoneOneAncillaryCodeConfig.class), anyInt());
        Response response = ratePlanResource.deleteAncillaryCodeConfig(tfAncillaryCodeConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAncillaryCodeConfig() throws TracfoneOneException {
        List<TFOneAncillaryCodeConfig> tfAncillaryCodeConfigs = new ArrayList<>();
        TFOneAncillaryCodeConfig tfOneAncillaryCodeConfig = new TFOneAncillaryCodeConfig();
        tfOneAncillaryCodeConfig.setDisplaySUIFlag("Y");
        tfOneAncillaryCodeConfig.setDisplaySUIFlag("Y");
        tfOneAncillaryCodeConfig.setProfileId("1000");
        tfOneAncillaryCodeConfig.setExtensionObjId("1000");
        tfAncillaryCodeConfigs.add(tfOneAncillaryCodeConfig);
        TracfoneOneAncillaryCodeConfig ancillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        ancillaryCodeConfig.setExtensionObjId("1000");
        ancillaryCodeConfig.setProfileId("1000");
        when(tracfoneProfileController.getAncillaryCodeConfig(any())).thenReturn(tfAncillaryCodeConfigs);
        Response response = ratePlanResource.getAncillaryCodeConfig(ancillaryCodeConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"extensionObjId\":\"1000\",\"profileId\":\"1000\",\"featureName\":null,\"featureValue\":null,\"featureRequirement\":null,\"toggleFlag\":null,\"notes\":null,\"restrictSUIFlag\":null,\"displaySUIFlag\":\"Y\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAncillaryCodeConfig_whenException() throws TracfoneOneException {
        TracfoneOneAncillaryCodeConfig ancillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        doThrow(tracfoneOneException).when(tracfoneProfileController).getAncillaryCodeConfig(any());
        Response response = ratePlanResource.getAncillaryCodeConfig(ancillaryCodeConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertAncillaryCodeDiscount() throws TracfoneOneException {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        tfAncillaryCodeDiscount.setNewBrmEquivalent("NEW_BRM_EQUIVALENT");
        when(tracfoneProfileController.insertAncillaryCodeDiscount(any(TracfoneOneAncillaryCodeDiscount.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertAncillaryCodeDiscount(tfAncillaryCodeDiscount);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertAncillaryCodeDiscount_whenException() throws TracfoneOneException {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        doThrow(tracfoneOneException).when(tracfoneProfileController).insertAncillaryCodeDiscount(any(TracfoneOneAncillaryCodeDiscount.class), anyInt());
        Response response = ratePlanResource.insertAncillaryCodeDiscount(tfAncillaryCodeDiscount);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateAncillaryCodeDiscount() throws TracfoneOneException {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        tfAncillaryCodeDiscount.setNewBrmEquivalent("NEW_BRM_EQUIVALENT");
        when(tracfoneProfileController.updateAncillaryCodeDiscount(any(TracfoneOneAncillaryCodeDiscount.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateAncillaryCodeDiscount(tfAncillaryCodeDiscount);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateAncillaryCodeDiscount_whenException() throws TracfoneOneException {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        doThrow(tracfoneOneException).when(tracfoneProfileController).updateAncillaryCodeDiscount(any(TracfoneOneAncillaryCodeDiscount.class), anyInt());
        Response response = ratePlanResource.updateAncillaryCodeDiscount(tfAncillaryCodeDiscount);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteAncillaryCodeDiscount() throws TracfoneOneException {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        when(tracfoneProfileController.deleteAncillaryCodeDiscount(any(TracfoneOneAncillaryCodeDiscount.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteAncillaryCodeDiscount(tfAncillaryCodeDiscount);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteAncillaryCodeDiscount_whenException() throws TracfoneOneException {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        doThrow(tracfoneOneException).when(tracfoneProfileController).deleteAncillaryCodeDiscount(any(TracfoneOneAncillaryCodeDiscount.class), anyInt());
        Response response = ratePlanResource.deleteAncillaryCodeDiscount(tfAncillaryCodeDiscount);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchAncillaryCodeDiscount() throws TracfoneOneException {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        List<TFOneAncillaryCodeDiscount> tfAncillaryCodeDiscounts = new ArrayList<>();
        TFOneAncillaryCodeDiscount tfOneAncillaryCodeDiscount = new TFOneAncillaryCodeDiscount();
        tfOneAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        tfAncillaryCodeDiscounts.add(tfOneAncillaryCodeDiscount);
        when(tracfoneProfileController.searchAncillaryCodeDiscount(any())).thenReturn(tfAncillaryCodeDiscounts);
        Response response = ratePlanResource.searchAncillaryCodeDiscount(tfAncillaryCodeDiscount);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"ancillaryCode\":\"ANCILLARY_CODE\",\"brmEquivalent\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchAncillaryCodeDiscount_whenException() throws TracfoneOneException {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        doThrow(tracfoneOneException).when(tracfoneProfileController).searchAncillaryCodeDiscount(any());
        Response response = ratePlanResource.searchAncillaryCodeDiscount(tfAncillaryCodeDiscount);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteLineStatusCode() throws TracfoneOneException {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DBENV);
        tfOneLineStatus.setLineStatusCode("LINE_STATUS_CODE");
        when(tracfoneProfileController.deleteLineStatusCode(any(TracfoneOneLineStatusCode.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteLineStatusCode(tfOneLineStatus);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteLineStatusCode_whenException() throws TracfoneOneException {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        doThrow(tracfoneOneException).when(tracfoneProfileController).deleteLineStatusCode(any(TracfoneOneLineStatusCode.class), anyInt());
        Response response = ratePlanResource.deleteLineStatusCode(tfOneLineStatus);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteThrottleStatusCode() throws TracfoneOneException {
        TracfoneOneThrottleStatusCode tfOneThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfOneThrottleStatusCode.setDescription("DESCRIPTION");
        tfOneThrottleStatusCode.setDbEnv(DBENV);
        when(tracfoneProfileController.deleteThrottleStatusCode(any(TracfoneOneThrottleStatusCode.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteThrottleStatusCode(tfOneThrottleStatusCode);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteThrottleStatusCode_whenException() throws TracfoneOneException {
        TracfoneOneThrottleStatusCode tfOneThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        doThrow(tracfoneOneException).when(tracfoneProfileController).deleteThrottleStatusCode(any(TracfoneOneThrottleStatusCode.class), anyInt());
        Response response = ratePlanResource.deleteThrottleStatusCode(tfOneThrottleStatusCode);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteFeatureRequirement() throws TracfoneOneException {
        TracfoneOneFeatureRequirement tfOneFeatureRequirement = new TracfoneOneFeatureRequirement();
        tfOneFeatureRequirement.setDbEnv(DBENV);
        tfOneFeatureRequirement.setFeatureRequirement("FEATURE_REQUIREMENT");
        when(tracfoneFeatureController.deleteFeatureRequirement(any(TracfoneOneFeatureRequirement.class), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteFeatureRequirement(tfOneFeatureRequirement);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteFeatureRequirement_whenException() throws TracfoneOneException {
        TracfoneOneFeatureRequirement tfOneFeatureRequirement = new TracfoneOneFeatureRequirement();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).deleteFeatureRequirement(any(TracfoneOneFeatureRequirement.class), anyInt());
        Response response = ratePlanResource.deleteFeatureRequirement(tfOneFeatureRequirement);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertBucketList() throws TracfoneOneException {
        List<TracfoneOneBucketList> tracfoneOneBucketLists = new ArrayList<>();
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDescription("DESCRIPTION");
        tracfoneOneBucketList.setActiveFlag("Y");
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketLists.add(tracfoneOneBucketList);
        when(tracfoneBucketController.insertBucketList(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertBucketList(tracfoneOneBucketLists);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertBucketList_whenException() throws TracfoneOneException {
        List<TracfoneOneBucketList> tracfoneOneBucketLists = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneBucketController).insertBucketList(anyList(), anyInt());
        Response response = ratePlanResource.insertBucketList(tracfoneOneBucketLists);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateBucketList() throws TracfoneOneException {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDescription("DESCRIPTION");
        tracfoneOneBucketList.setActiveFlag("Y");
        tracfoneOneBucketList.setDbEnv(DBENV);
        when(tracfoneBucketController.updateBucketList(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateBucketList(tracfoneOneBucketList);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateBucketList_whenException() throws TracfoneOneException {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        doThrow(tracfoneOneException).when(tracfoneBucketController).updateBucketList(any(), anyInt());
        Response response = ratePlanResource.updateBucketList(tracfoneOneBucketList);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchBucketList() throws TracfoneOneException {
        List<TFOneBucketList> tfOneBucketLists = new ArrayList<>();
        TFOneBucketList tfOneBucketList = new TFOneBucketList();
        tfOneBucketList.setBucketId("1000");
        tfOneBucketList.setDescription("DESCRIPTION");
        tfOneBucketList.setActiveFlag("Y");
        tfOneBucketLists.add(tfOneBucketList);

        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDbEnv(DBENV);

        when(tracfoneBucketController.searchBucketList(any())).thenReturn(tfOneBucketLists);
        Response response = ratePlanResource.searchBucketList(tracfoneOneBucketList);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"bucketId\":\"1000\",\"description\":\"DESCRIPTION\",\"activeFlag\":\"Y\",\"parentShortName\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchBucketList_whenException() throws TracfoneOneException {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        doThrow(tracfoneOneException).when(tracfoneBucketController).searchBucketList(any());
        Response response = ratePlanResource.searchBucketList(tracfoneOneBucketList);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteBucketList() throws TracfoneOneException {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDescription("DESCRIPTION");
        tracfoneOneBucketList.setActiveFlag("Y");
        tracfoneOneBucketList.setDbEnv(DBENV);
        when(tracfoneBucketController.deleteBucketList(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteBucketList(tracfoneOneBucketList);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteBucketList_whenException() throws TracfoneOneException {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        doThrow(tracfoneOneException).when(tracfoneBucketController).deleteBucketList(any(), anyInt());
        Response response = ratePlanResource.deleteBucketList(tracfoneOneBucketList);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertMultiRatePlanEsns() throws TracfoneOneException {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsns.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsns.setDelFlag("ESN");
        tracfoneOneMultiRatePlanEsns.setxServicePlanId("185");
        when(tracfoneProfileController.insertMultiRatePlanEsn(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.insertMultiRatePlanEsns(tracfoneOneMultiRatePlanEsns);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertMultiRatePlanEsns_whenException() throws TracfoneOneException {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns = new TracfoneOneMultiRatePlanEsn();
        doThrow(tracfoneOneException).when(tracfoneProfileController).insertMultiRatePlanEsn(any(), anyInt());
        Response response = ratePlanResource.insertMultiRatePlanEsns(tracfoneOneMultiRatePlanEsns);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateMultiRatePlanEsns() throws TracfoneOneException {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsns.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsns.setDelFlag("ESN");
        tracfoneOneMultiRatePlanEsns.setxServicePlanId("185");
        when(tracfoneProfileController.updateMultiRatePlanEsn(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.updateMultiRatePlanEsns(tracfoneOneMultiRatePlanEsns);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateMultiRatePlanEsns_whenException() throws TracfoneOneException {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns = new TracfoneOneMultiRatePlanEsn();
        doThrow(tracfoneOneException).when(tracfoneProfileController).updateMultiRatePlanEsn(any(), anyInt());
        Response response = ratePlanResource.updateMultiRatePlanEsns(tracfoneOneMultiRatePlanEsns);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteMultiRatePlanEsns() throws TracfoneOneException {
        List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsns = new ArrayList<>();
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsn.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsn.setDelFlag("ESN");
        tracfoneOneMultiRatePlanEsn.setxServicePlanId("185");
        tracfoneOneMultiRatePlanEsns.add(tracfoneOneMultiRatePlanEsn);
        when(tracfoneProfileController.deleteMultiRatePlanEsn(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.deleteMultiRatePlanEsns(tracfoneOneMultiRatePlanEsns);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteMultiRatePlanEsns_whenException() throws TracfoneOneException {
        List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsns = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneProfileController).deleteMultiRatePlanEsn(any(), anyInt());
        Response response = ratePlanResource.deleteMultiRatePlanEsns(tracfoneOneMultiRatePlanEsns);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchMultiRatePlanEsns() throws TracfoneOneException {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsns.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsns.setDelFlag("ESN");
        tracfoneOneMultiRatePlanEsns.setxServicePlanId("185");

        List<TFOneMultiRatePlanEsn> tfOneMultiRatePlanEsnss = new ArrayList<>();
        TFOneMultiRatePlanEsn tfOneMultiRatePlanEsns = new TFOneMultiRatePlanEsn();
        tfOneMultiRatePlanEsns.setxReason("REASON");
        tfOneMultiRatePlanEsns.setxServicePlanId("185");
        tfOneMultiRatePlanEsnss.add(tfOneMultiRatePlanEsns);

        when(tracfoneProfileController.searchMultiRatePlanEsns(any())).thenReturn(tfOneMultiRatePlanEsnss);
        Response response = ratePlanResource.searchMultiRatePlanEsns(tracfoneOneMultiRatePlanEsns);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"xEsn\":null,\"xPriority\":null,\"xServicePlanId\":\"185\",\"xDateAdded\":null,\"xReason\":\"REASON\",\"delFlag\":null,\"xProductId\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchMultiRatePlanEsns_whenException() throws TracfoneOneException {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns = new TracfoneOneMultiRatePlanEsn();
        doThrow(tracfoneOneException).when(tracfoneProfileController).searchMultiRatePlanEsns(any());
        Response response = ratePlanResource.searchMultiRatePlanEsns(tracfoneOneMultiRatePlanEsns);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertProfile() throws TracfoneOneException {
        doNothing().when(tracfoneProfileController).bulkInsertProfiles(anyList(), anyInt());
        List<TracfoneOneRatePlanProfile> profiles = new ArrayList<>();
        profiles.add(tracfoneOneRatePlanProfile);
        Response response = ratePlanResource.bulkInsertProfiles(profiles);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"Success\",\"message\":\"Success\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertProfile_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).bulkInsertProfiles(anyList(), anyInt());
        List<TracfoneOneRatePlanProfile> profiles = new ArrayList<>();
        profiles.add(tracfoneOneRatePlanProfile);
        Response response = ratePlanResource.bulkInsertProfiles(profiles);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchProfileFeatures() throws TracfoneOneException {
        TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel = new TracfoneOneSearchProfileModel();
        tracfoneOneSearchProfileModel.setDbEnv(DBENV);
        tracfoneOneSearchProfileModel.setFeatureValue("THRWS8");

        List<TFOneRatePlanExtensionConfig> tfOneFeatures = new ArrayList<>();
        TFOneRatePlanExtensionConfig tfOneFeature = new TFOneRatePlanExtensionConfig();
        tfOneFeature.setProfileId("4385");
        tfOneFeature.setFeatureName("Data Throttle");
        tfOneFeature.setFeatureValue("THRWS8");
        tfOneFeature.setFeatureRequirement("ADD");
        tfOneFeature.setToggleFlag("Y");
        tfOneFeature.setRestrictSUIFlag("Y");
        tfOneFeature.setDisplaySUIFlag("Y");
        tfOneFeatures.add(tfOneFeature);

        when(tracfoneFeatureController.searchProfileFeatures(any())).thenReturn(tfOneFeatures);
        Response response = ratePlanResource.searchProfileFeatures(tracfoneOneSearchProfileModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objid\":null,\"profileId\":\"4385\",\"profileDescription\":null,\"featureName\":\"Data Throttle\",\"featureValue\":\"THRWS8\",\"featureRequirement\":\"ADD\",\"toggleFlag\":\"Y\",\"notes\":null,\"displaySUIFlag\":\"Y\",\"restrictSUIFlag\":\"Y\",\"dbEnv\":null,\"rowNum\":null,\"errorMessages\":{}}]", response.getEntity().toString());
    }

    @Test
    public void testSearchProfileFeatures_whenException() throws TracfoneOneException {
        TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel = new TracfoneOneSearchProfileModel();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).searchProfileFeatures(any());
        Response response = ratePlanResource.searchProfileFeatures(tracfoneOneSearchProfileModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllFeatureValues() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionConfig tracfoneOneRatePlanExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        tracfoneOneRatePlanExtensionConfig.setDbEnv(DBENV);
        tracfoneOneRatePlanExtensionConfig.setFeatureValue("THRWS8");

        List<String> featureValues = new ArrayList<>();
        featureValues.add("BLKBRY,THRWS8");

        when(tracfoneFeatureController.getAllFeatureValues(any())).thenReturn(featureValues);
        Response response = ratePlanResource.getAllFeatureValues(tracfoneOneRatePlanExtensionConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[\"BLKBRY,THRWS8\"]", response.getEntity().toString());
    }

    @Test
    public void testGetAllFeatureValues_whenException() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionConfig tracfoneOneRatePlanExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).getAllFeatureValues(any());
        Response response = ratePlanResource.getAllFeatureValues(tracfoneOneRatePlanExtensionConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkUpdateProfileFeatures() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        tfOneRpExtensionConfig.setDbEnv(DBENV);
        tfOneRpExtensionConfig.setFeatureRequirement("ADD");

        when(tracfoneFeatureController.bulkUpdateProfileFeatures(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = ratePlanResource.bulkUpdateProfileFeatures(tfOneRpExtensionConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkUpdateProfileFeatures_whenException() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig = new TracfoneOneRatePlanExtensionConfig();
        doThrow(tracfoneOneException).when(tracfoneFeatureController).bulkUpdateProfileFeatures(any(), anyInt());
        Response response = ratePlanResource.bulkUpdateProfileFeatures(tfOneRpExtensionConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertProfileFeatures() throws TracfoneOneException {
        doNothing().when(tracfoneFeatureController).bulkInsertProfileFeatures(anyList(), anyInt());
        List<TracfoneOneRatePlanExtensionConfig> tfOneRpExtensionConfigs = new ArrayList<>();
        tfOneRpExtensionConfigs.add(tfOneRpExtensionConfig);
        Response response = ratePlanResource.bulkInsertProfileFeatures(tfOneRpExtensionConfigs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"Success\",\"message\":\"Success\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertProfileFeatures_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneFeatureController).bulkInsertProfileFeatures(anyList(), anyInt());
        List<TracfoneOneRatePlanExtensionConfig> tfOneRpExtensionConfigs = new ArrayList<>();
        tfOneRpExtensionConfigs.add(tfOneRpExtensionConfig);
        Response response = ratePlanResource.bulkInsertProfileFeatures(tfOneRpExtensionConfigs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertSummary() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv(DBENV);
        List<TFOneBulkInsertReport> tfOneBulkInsertReports = new ArrayList<>();
        TFOneBulkInsertReport tfOneBulkInsertReport = new TFOneBulkInsertReport();
        tfOneBulkInsertReport.setId("100");
        tfOneBulkInsertReport.setStatus("SUCCESS");
        tfOneBulkInsertReports.add(tfOneBulkInsertReport);
        when(tracfoneControllerAction.getBulkInsertSummary(any(), any(), anyInt())).thenReturn(tfOneBulkInsertReports);
        Response response = ratePlanResource.getBulkInsertSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"100\",\"createDate\":null,\"status\":\"SUCCESS\",\"totalRecord\":null,\"successCount\":null,\"errorCount\":null,\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertSummary_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(any(), any(),anyInt());
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        Response response = ratePlanResource.getBulkInsertSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertMultuRpEsn() throws TracfoneOneException {
        doNothing().when(tracfoneProfileController).bulkInsertRatePlanEsn(anyList(), anyInt());
        List<TracfoneOneMultiRatePlanEsn> multiRatePlanEsns = new ArrayList<>();
        TracfoneOneMultiRatePlanEsn ratePlanEsn = new TracfoneOneMultiRatePlanEsn();
        multiRatePlanEsns.add(ratePlanEsn);
        Response response = ratePlanResource.bulkInsertRatePlanEsn(multiRatePlanEsns);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"Success\",\"message\":\"Success\"}", response.getEntity().toString());
    }

    @Test
    public void testBulkInsertMultuRpEsn_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneProfileController).bulkInsertRatePlanEsn(anyList(), anyInt());
        List<TracfoneOneMultiRatePlanEsn> multiRatePlanEsns = new ArrayList<>();
        TracfoneOneMultiRatePlanEsn ratePlanEsn = new TracfoneOneMultiRatePlanEsn();
        multiRatePlanEsns.add(ratePlanEsn);
        Response response = ratePlanResource.bulkInsertRatePlanEsn(multiRatePlanEsns);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertMultiRpEsnSummary() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv(DBENV);
        List<TFOneBulkInsertReport> tfOneBulkInsertReports = new ArrayList<>();
        TFOneBulkInsertReport tfOneBulkInsertReport = new TFOneBulkInsertReport();
        tfOneBulkInsertReport.setId("100");
        tfOneBulkInsertReport.setStatus("SUCCESS");
        tfOneBulkInsertReports.add(tfOneBulkInsertReport);
        when(tracfoneControllerAction.getBulkInsertSummary(any(), any(), anyInt())).thenReturn(tfOneBulkInsertReports);
        Response response = ratePlanResource.getBulkInsertRpEsnSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"100\",\"createDate\":null,\"status\":\"SUCCESS\",\"totalRecord\":null,\"successCount\":null,\"errorCount\":null,\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertMultiRpEsnSummary_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(any(), any(),anyInt());
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        Response response = ratePlanResource.getBulkInsertRpEsnSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    /**
     Junits forSprint 30
     ***/
    @Test
    public void testGetBucketDetails() throws TracfoneOneException {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketList.setBucketId("TEST");
        tracfoneOneBucketList.setParentShortName("TMO");
        tracfoneOneBucketList.setProfileId("100");
        tracfoneOneBucketList.setServicePlanId("100");
        TFOneCarrierProfileBucket tfOneCarrierProfileBucket = new TFOneCarrierProfileBucket();
        tfOneCarrierProfileBucket.setBucketId("TEST");
        tfOneCarrierProfileBucket.setBenefitType("TEST");
        tfOneCarrierProfileBucket.setBucketGroup("TEST");
        tfOneCarrierProfileBucket.setBucketType("TEST");
        when(tracfoneBucketController.getBucketDetails(any())).thenReturn(tfOneCarrierProfileBucket);
        Response response = ratePlanResource.getBucketDetails(tracfoneOneBucketList);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"objid\":null,\"profileId\":null,\"bucketId\":\"TEST\",\"servicePlanId\":null,\"activeFlag\":null,\"unitOfMeasure\":null,\"bucketType\":\"TEST\",\"bucketGroup\":\"TEST\",\"bucketRequirement\":null,\"autoRenewFlag\":null,\"autoRenewFrequency\":null,\"autoRenewValue\":null,\"autoRenewDay\":null,\"benefitType\":\"TEST\",\"bucketValue\":null,\"suiDisplayType\":null,\"priority\":null,\"hideUbiFlag\":null,\"tfOneCarrierProfileBucketTiers\":null}", response.getEntity().toString());
    }

    @Test
    public void testGetBucketDetails_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneBucketController).getBucketDetails(any());
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        Response response = ratePlanResource.getBucketDetails(tracfoneOneBucketList);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }
}
