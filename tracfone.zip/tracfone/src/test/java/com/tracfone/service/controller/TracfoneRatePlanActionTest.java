package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneApn;
import com.tracfone.service.model.request.TracfoneOneCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucketTier;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildTier;
import com.tracfone.service.model.request.TracfoneOneRatePlan;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionLink;
import com.tracfone.service.model.request.TracfoneOneSearchCarrierFeatureModel;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneServicePlanCarrierFeature;
import com.tracfone.service.model.response.TFOneApn;
import com.tracfone.service.model.response.TFOneBusinessOrganization;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOneRatePlan;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneRatePlanActionTest {

    @InjectMocks
    private TracfoneRatePlanAction tracfoneRatePlanAction;
    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private ResultSet resultSet;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    private static final String DB_ENV = "DBENV";
    private static final String TEST = "test";
    private static final String ONE = "1";
    private static final String TWO = "2";
    private static final String RATE_PLAN = "RATE_PLAN";
    private TFOneGeneralResponse tfOneGeneralResponse;

    @Before
    public void setUp() throws Exception {
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

    @Test
    public void testInsertRatePlan() throws TracfoneOneException, SQLException {
        TracfoneOneRatePlan tfRatePlan = new TracfoneOneRatePlan();
        tfRatePlan.setDbEnv(DB_ENV);
        tfRatePlan.setRatePlanName(RATE_PLAN);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getLong(anyString())).thenReturn(1l);
        doNothing().when(stmt).setString(anyInt(), anyString());
        tfOneGeneralResponse = tracfoneRatePlanAction.insertRatePlan(tfRatePlan, 1);
        assertEquals(TFOneGeneralResponse.SUCCESS, tfOneGeneralResponse.getStatus());
        assertEquals(tfRatePlan.getRatePlanId(), tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testInsertRatePlan_withValues() throws TracfoneOneException, SQLException {
        TracfoneOneRatePlan tfRatePlan = getTracfoneOneRatePlan();
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getLong(anyString())).thenReturn(0l);
        doNothing().when(stmt).setString(anyInt(), anyString());
        tfOneGeneralResponse = tracfoneRatePlanAction.insertRatePlan(getTracfoneOneRatePlan(), 1);
        assertEquals(TFOneGeneralResponse.SUCCESS, tfOneGeneralResponse.getStatus());
        assertEquals(tfRatePlan.getRatePlanId(), tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testInsertRatePlan_whenException() throws SQLException {
        TracfoneOneRatePlan tfRatePlan = new TracfoneOneRatePlan();
        tfRatePlan.setDbEnv(DB_ENV);
        tfRatePlan.setRatePlanName(RATE_PLAN);
        try {
            tracfoneRatePlanAction.insertRatePlan(null, 1);
            fail("Throws NullPointerException");
        } catch (NullPointerException | TracfoneOneException e) {
            // expected
        }
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneRatePlanAction.insertRatePlan(tfRatePlan, 1);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierFeatures_withException() throws SQLException {
        TracfoneOneRatePlan tfRatePlan = new TracfoneOneRatePlan();
        tfRatePlan.setDbEnv(DB_ENV);
        doThrow(SQLException.class).when(stmt).executeBatch();
        try {
            tracfoneRatePlanAction.insertCarrierFeatures(tfRatePlan, TEST, 1);
            fail();
        } catch (NullPointerException | TracfoneOneException e) {
            //expected
        }
    }

    @Test
    public void testViewRatePlan() throws TracfoneOneException, SQLException {
        TracfoneOneRatePlan tfRatePlan = new TracfoneOneRatePlan();
        tfRatePlan.setDbEnv(DB_ENV);
        tfRatePlan.setRatePlanId("100");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("100").thenReturn(RATE_PLAN);
        TFOneRatePlan tfOneRatePlan = tracfoneRatePlanAction.viewRatePlan(tfRatePlan, true);
        assertNotNull(tfOneRatePlan);
        assertEquals(RATE_PLAN, tfOneRatePlan.getRatePlanName());
    }

    @Test
    public void testViewRatePlan_whenException() throws SQLException {
        TracfoneOneRatePlan tfRatePlan = new TracfoneOneRatePlan();
        tfRatePlan.setDbEnv(DB_ENV);
        tfRatePlan.setRatePlanId(ONE);
        try {
            tracfoneRatePlanAction.insertRatePlan(null, 1);
            fail("Throws NullPointerException");
        } catch (NullPointerException | TracfoneOneException e) {
            // expected
        }
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneRatePlanAction.viewRatePlan(tfRatePlan, true);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testViewRatePlan_whenArgsFalse() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn(TEST);
        TFOneRatePlan tfOneRatePlan = tracfoneRatePlanAction.viewRatePlan(getTracfoneOneRatePlan(), false);
        assertEquals(TEST, tfOneRatePlan.getObjId());
    }

    @Test
    public void testUpdateRatePlan() throws TracfoneOneException, SQLException {
        TracfoneOneRatePlan tfrRatePlan = getTracfoneOneRatePlan();
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn(ONE);
        tfOneGeneralResponse = tracfoneRatePlanAction.updateRatePlan(getTracfoneOneRatePlan(), 1);
        assertEquals(TFOneGeneralResponse.SUCCESS, tfOneGeneralResponse.getStatus());
        assertEquals(tfrRatePlan.getRatePlanName(), tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testUpdateRatePlan_whenException() throws SQLException {
        TracfoneOneRatePlan tfRatePlan = new TracfoneOneRatePlan();
        tfRatePlan.setDbEnv(DB_ENV);
        tfRatePlan.setRatePlanId(ONE);
        try {
            tracfoneRatePlanAction.updateRatePlan(null, 1);
            fail("Throws NullPointerException");
        } catch (NullPointerException | TracfoneOneException e) {
            // expected
        }
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneRatePlanAction.updateRatePlan(getTracfoneOneRatePlan(), 1);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testDeleteRatePlan() throws TracfoneOneException {
        List<String> idsToBeDeleted = new ArrayList<>();
        idsToBeDeleted.add(ONE);
        idsToBeDeleted.add(TWO);
        tfOneGeneralResponse = tracfoneRatePlanAction.deleteRatePlan(DB_ENV, idsToBeDeleted, 1);
        assertEquals(TFOneGeneralResponse.SUCCESS, tfOneGeneralResponse.getStatus());
        assertEquals(idsToBeDeleted.toString(), tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testDeleteRatePlan_whenException() throws SQLException {
        List<String> idsToBeDeleted = new ArrayList<>();
        idsToBeDeleted.add(ONE);
        idsToBeDeleted.add(TWO);
        try {
            tracfoneRatePlanAction.deleteRatePlan(null, idsToBeDeleted, 1);
            fail("Throws NullPointerException");
        } catch (NullPointerException | TracfoneOneException e) {
            // expected
        }
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneRatePlanAction.deleteRatePlan(DB_ENV, idsToBeDeleted, 1);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetServicePlansForCarrier() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        List<TFOneCarrierServicePlan> tfOneCarrierServicePlans = tracfoneRatePlanAction.getServicePlansForCarrier(TEST, DB_ENV);
        assertNotNull(tfOneCarrierServicePlans);
        assertEquals(1, tfOneCarrierServicePlans.size());
    }

    @Test
    public void testGetServicePlansForCarrier_whenException() throws SQLException {
        try {
            tracfoneRatePlanAction.getServicePlansForCarrier(TEST, null);
            fail("Throws NullPointerException");
        } catch (NullPointerException | TracfoneOneException e) {
            // expected
        }
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneRatePlanAction.getServicePlansForCarrier(TEST, DB_ENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllBusinessOrgs() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        List<TFOneBusinessOrganization> tfAllBusOrgs = tracfoneRatePlanAction.getAllBusinessOrgs(DB_ENV);
        assertNotNull(tfAllBusOrgs);
        assertEquals(1, tfAllBusOrgs.size());
    }

    @Test
    public void testgetAllBusinessOrgs_whenException() throws SQLException {
        try {
            tracfoneRatePlanAction.getAllBusinessOrgs(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException | TracfoneOneException e) {
            // expected
        }
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneRatePlanAction.getAllBusinessOrgs(DB_ENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierFeatures() throws TracfoneOneException {
        List<String> idsToBeDeleted = new ArrayList<>();
        idsToBeDeleted.add(ONE);
        idsToBeDeleted.add(TWO);
        tfOneGeneralResponse = tracfoneRatePlanAction.deleteCarrierFeatures(DB_ENV, ONE, idsToBeDeleted, 1);
        assertEquals(TFOneGeneralResponse.SUCCESS, tfOneGeneralResponse.getStatus());
        assertEquals(idsToBeDeleted.toString(), tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testDeleteCarrierFeatures_withException() throws SQLException {
        List<String> idsToBeDeleted = new ArrayList<>();
        idsToBeDeleted.add(ONE);
        idsToBeDeleted.add(TWO);
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneRatePlanAction.deleteCarrierFeatures(DB_ENV, ONE, idsToBeDeleted, 1);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetMasterRatePlans() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn(ONE);
        List<TFOneRatePlan> tfAllRatePlans = tracfoneRatePlanAction.getMasterRatePlans(DB_ENV);
        assertEquals(2, tfAllRatePlans.size());
    }

    @Test
    public void testGetMasterRatePlans_whenException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneRatePlanAction.getMasterRatePlans(DB_ENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierFeature() throws TracfoneOneException {
        TracfoneOneCarrierFeature tfCarrierFeature = getTracfoneOneCarrierFeature();
        tfOneGeneralResponse = tracfoneRatePlanAction.updateCarrierFeature(getTracfoneOneCarrierFeature(), 1);
        assertEquals(TFOneGeneralResponse.SUCCESS, tfOneGeneralResponse.getStatus());
        assertEquals(tfCarrierFeature.getObjId(), tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testUpdateCarrierFeature_whenException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneRatePlanAction.updateCarrierFeature(getTracfoneOneCarrierFeature(), 1);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierFeatures() throws TracfoneOneException, SQLException {
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add(ONE);
        servicePlanIds.add(TWO);
        TracfoneOneSearchCarrierFeatureModel tfSearchCarrierFeatureModel = new TracfoneOneSearchCarrierFeatureModel();
        tfSearchCarrierFeatureModel.setDbEnv(DB_ENV);
        tfSearchCarrierFeatureModel.setServicePlanId(ONE);
        tfSearchCarrierFeatureModel.setTracfoneOneCarrierFeature(getTracfoneOneCarrierFeature());
        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn(ONE);
        List<TFOneCarrierFeature> carrierFeatures = tracfoneRatePlanAction.searchCarrierFeatures(tfSearchCarrierFeatureModel);
        assertEquals(2, carrierFeatures.size());
    }

    @Test
    public void testSearchCarrierFeatures_withException() throws SQLException {
        TracfoneOneSearchCarrierFeatureModel tfSearchCarrierFeatureModel = new TracfoneOneSearchCarrierFeatureModel();
        tfSearchCarrierFeatureModel.setDbEnv(DB_ENV);
        tfSearchCarrierFeatureModel.setServicePlanId("12");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneRatePlanAction.searchCarrierFeatures(tfSearchCarrierFeatureModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllCarrierNames() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn(ONE);
        List<String> carrierNames = tracfoneRatePlanAction.getAllCarrierNames(DB_ENV);
        assertEquals(1, carrierNames.size());
    }

    @Test
    public void testGetAllCarrierNames_withException() throws SQLException {

        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneRatePlanAction.getAllCarrierNames(DB_ENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertApn() throws TracfoneOneException {
        TracfoneOneApn tfOneApn = new TracfoneOneApn();
        tfOneApn.setDbEnv(DB_ENV);
        tfOneGeneralResponse = tracfoneRatePlanAction.insertApn(tfOneApn, 1);
        assertEquals(TFOneGeneralResponse.SUCCESS, tfOneGeneralResponse.getStatus());
        assertEquals(tfOneApn.getRatePlan(), tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testInsertApn_withException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneRatePlanAction.insertApn(getTracfoneOneApn(), 1);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertApn_withAllValues() throws TracfoneOneException, SQLException {
        TracfoneOneApn tfOneApn = getTracfoneOneApn();
        tfOneGeneralResponse = tracfoneRatePlanAction.insertApn(tfOneApn, 1);
        assertEquals(TFOneGeneralResponse.SUCCESS, tfOneGeneralResponse.getStatus());
        assertEquals(tfOneApn.getRatePlan(), tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testUpdateApn() throws TracfoneOneException {
        TracfoneOneApn tfOneApn = getTracfoneOneApn();
        tfOneGeneralResponse = tracfoneRatePlanAction.updateApn(tfOneApn, 1);
        assertEquals(TFOneGeneralResponse.SUCCESS, tfOneGeneralResponse.getStatus());
        assertEquals(tfOneApn.getRatePlan(), tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testUpdateApn_withException() throws SQLException {
        TracfoneOneApn tfOneApn = getTracfoneOneApn();
        tfOneApn.setDbEnv(DB_ENV);
        tfOneApn.setRatePlan("RATE_PLAN_NAME");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneRatePlanAction.updateApn(tfOneApn, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteApn() throws TracfoneOneException {
        TracfoneOneApn tfOneApn = getTracfoneOneApn();
        tfOneGeneralResponse = tracfoneRatePlanAction.deleteApn(tfOneApn, 1);
        assertEquals(TFOneGeneralResponse.SUCCESS, tfOneGeneralResponse.getStatus());
        assertEquals(tfOneApn.getRatePlan(), tfOneGeneralResponse.getMessage());
    }

    @Test
    public void testDeleteApn_withException() throws SQLException {
        TracfoneOneApn tfOneApn = getTracfoneOneApn();
        tfOneApn.setDbEnv(DB_ENV);
        tfOneApn.setRatePlan("RATE_PLAN_NAME");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneRatePlanAction.deleteApn(tfOneApn, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllParentNames() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn(ONE);
        List<TFOneParent> tfAllParentNames = tracfoneRatePlanAction.getAllParentNames(DB_ENV, TEST);
        assertEquals(1, tfAllParentNames.size());

    }

    @Test
    public void testGetAllParentNames_withException() throws SQLException {
        TracfoneOneApn tfOneApn = getTracfoneOneApn();
        tfOneApn.setDbEnv(DB_ENV);
        tfOneApn.setRatePlan("RATE_PLAN_NAME");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneRatePlanAction.getAllParentNames(DB_ENV, "CARRIER_NAME");
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchForUnlinkedRatePlans() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        List<TFOneRatePlan> tfUnlinkedRatePlans = tracfoneRatePlanAction.searchRatePlansForUpdate(getTracfoneOneRatePlan());
        assertEquals(1, tfUnlinkedRatePlans.size());
    }

    @Test
    public void testSearchForUnlinkedRatePlans_withException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneRatePlanAction.searchRatePlansForUpdate(getTracfoneOneRatePlan());
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllRatePlanApns() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn(ONE);
        List<TFOneApn> ratePlanApns = tracfoneRatePlanAction.getAllRatePlanApns(getTracfoneOneApn());
        assertEquals(1, ratePlanApns.size());
    }

    @Test
    public void testGetAllRatePlanApns_whenException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneRatePlanAction.getAllRatePlanApns(getTracfoneOneApn());
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testIsDuplicateApn() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        boolean flag = tracfoneRatePlanAction.isDuplicateApn(getTracfoneOneApn());
        assertTrue(flag);
    }

    @Test
    public void testIsDuplicateApn_withException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneRatePlanAction.isDuplicateApn(getTracfoneOneApn());
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCarrierFeatureLinks() throws TracfoneOneException, SQLException {
        List<TracfoneOneCarrierFeature> selectedCarrierFeatures = new ArrayList<>();
        selectedCarrierFeatures.add(getTracfoneOneCarrierFeature());
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn(ONE);
        List<TFOneCarrierFeature> carrierFeatures = tracfoneRatePlanAction.getCarrierFeatureLinks(selectedCarrierFeatures);
        assertEquals(1, carrierFeatures.size());
    }

    private TracfoneOneApn getTracfoneOneApn() {
        TracfoneOneApn tfOneApn = new TracfoneOneApn();
        tfOneApn.setDbEnv(DB_ENV);
        tfOneApn.setxParentName(TEST);
        tfOneApn.setRatePlan(TEST);
        tfOneApn.setOrgId(TEST);
        tfOneApn.setApn(TEST);
        tfOneApn.setUsername(TEST);
        tfOneApn.setPassword(TEST);
        tfOneApn.setAuthType(TEST);
        tfOneApn.setProxyAddress(TEST);
        tfOneApn.setProxyPort(TEST);
        tfOneApn.setConnectionType(TEST);
        tfOneApn.setMmsApn(TEST);
        tfOneApn.setMmsUsername(TEST);
        tfOneApn.setMmsPassword(TEST);
        tfOneApn.setMmsAuthType(TEST);
        tfOneApn.setMmsc(TEST);
        tfOneApn.setMmsProxyAddress(TEST);
        tfOneApn.setMmsProxyPort(TEST);
        tfOneApn.setMmsApnType(TEST);
        tfOneApn.setRtspProxyAddr(TEST);
        tfOneApn.setRtspProxyPort(TEST);
        tfOneApn.setOldApn(TEST);
        tfOneApn.setOldOrgId(TEST);
        tfOneApn.setOldParentName(TEST);
        return tfOneApn;
    }

    private TracfoneOneCarrierFeature getTracfoneOneCarrierFeature() {
        TracfoneOneCarrierFeature tracfoneOneCarrierFeature = new TracfoneOneCarrierFeature();
        tracfoneOneCarrierFeature.setDbEnv(DB_ENV);
        tracfoneOneCarrierFeature.setObjId(ONE);
        tracfoneOneCarrierFeature.setxTechnology(TEST);
        tracfoneOneCarrierFeature.setxRatePlan(TEST);
        tracfoneOneCarrierFeature.setxVoicemail(ONE);
        tracfoneOneCarrierFeature.setxVmCode(TEST);
        tracfoneOneCarrierFeature.setxVmPackage(ONE);
        tracfoneOneCarrierFeature.setxCallerId(ONE);
        tracfoneOneCarrierFeature.setxIdCode(TEST);
        tracfoneOneCarrierFeature.setxIdPackage(ONE);
        tracfoneOneCarrierFeature.setxSms(ONE);
        tracfoneOneCarrierFeature.setxSmsCode(TEST);
        tracfoneOneCarrierFeature.setxSmsPackage(ONE);
        tracfoneOneCarrierFeature.setxCallWaiting(ONE);
        tracfoneOneCarrierFeature.setxCwCode(TEST);
        tracfoneOneCarrierFeature.setxCwPackage(ONE);
        tracfoneOneCarrierFeature.setxDigitalFeature(TEST);
        tracfoneOneCarrierFeature.setxDigFeature(ONE);
        tracfoneOneCarrierFeature.setxFeature2xCarrier(ONE);
        tracfoneOneCarrierFeature.setxSmscNumber(TEST);
        tracfoneOneCarrierFeature.setxData(ONE);
        tracfoneOneCarrierFeature.setxRestrictedUse(ONE);
        tracfoneOneCarrierFeature.setxSwitchBaseRate(TEST);
        tracfoneOneCarrierFeature.setxFeatures2BusOrg(ONE);
        tracfoneOneCarrierFeature.setxIsSwbCarrier(ONE);
        tracfoneOneCarrierFeature.setxMpn(ONE);
        tracfoneOneCarrierFeature.setxMpnCode(TEST);
        tracfoneOneCarrierFeature.setxPoolName(TEST);
        tracfoneOneCarrierFeature.setCreateMformIgFlag(TEST);
        tracfoneOneCarrierFeature.setUseCfExtensionFlag(TEST);
        tracfoneOneCarrierFeature.setDataSaver(ONE);
        tracfoneOneCarrierFeature.setDataSaverCode(TEST);
        tracfoneOneCarrierFeature.setUseRpExtensionFlag(TEST);
        tracfoneOneCarrierFeature.setTmoNextGenFlag(TEST);
        tracfoneOneCarrierFeature.getServicePlanCarrierFeature().setServicePlanId(ONE);
        tracfoneOneCarrierFeature.getServicePlanCarrierFeature().setCarrierFeaturesId(ONE);
        tracfoneOneCarrierFeature.getServicePlanCarrierFeature().setPriority(ONE);
        return tracfoneOneCarrierFeature;
    }

    private TracfoneOneRatePlan getTracfoneOneRatePlan() {
        TracfoneOneRatePlan tfRatePlan = new TracfoneOneRatePlan();
        tfRatePlan.setDbEnv(DB_ENV);
        tfRatePlan.setRatePlanId(ONE);
        tfRatePlan.setRatePlanName(TEST);
        tfRatePlan.setPrivateNetwork(TEST);
        tfRatePlan.setEspidUpdate(TEST);
        tfRatePlan.setEspidNum(TEST);
        tfRatePlan.setAllowMformApnRequestFlag(TEST);
        tfRatePlan.setPropagateFlagValue(ONE);
        tfRatePlan.setCalculateDataUnitsFlag(TEST);
        tfRatePlan.setThresholdsToTmo(TEST);
        tfRatePlan.setHotspotBucketsFlag(TEST);
        return tfRatePlan;
    }

    private TracfoneOneSearchPlanModel getTracfoneOneSearchPlanModel() {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DB_ENV);
        tracfoneOneSearchPlanModel.setRatePlanName(TEST);
        tracfoneOneSearchPlanModel.setCarrierName(TEST);
        tracfoneOneSearchPlanModel.setServicePlanId(ONE);
        tracfoneOneSearchPlanModel.setCarrierFeatureId(ONE);
        return tracfoneOneSearchPlanModel;
    }

    @Test
    public void testInsertRatePlanAssociation() throws TracfoneOneException, SQLException {
        List<TracfoneOneCarrierProfileBucketTier> tracfoneOneCarrierProfileBucketTiers = new ArrayList<>();
        TracfoneOneCarrierProfileBucketTier tracfoneOneCarrierProfileBucketTier = new TracfoneOneCarrierProfileBucketTier();
        tracfoneOneCarrierProfileBucketTier.setObjId("10");
        tracfoneOneCarrierProfileBucketTier.setUsageTierId("10");
        tracfoneOneCarrierProfileBucketTiers.add(tracfoneOneCarrierProfileBucketTier);
        List<TracfoneOneCarrierProfileBucket> tracfoneOneCarrierProfileBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileBucket tracfoneOneCarrierProfileBucket = new TracfoneOneCarrierProfileBucket();
        tracfoneOneCarrierProfileBucket.setObjectId("10");
        tracfoneOneCarrierProfileBucket.setBucketId("10");
        tracfoneOneCarrierProfileBucket.setAutoRenewFlag("Y");
        tracfoneOneCarrierProfileBucket.setActiveFlag("Y");
        tracfoneOneCarrierProfileBucket.setTracfoneOneCarrierProfileBucketTiers(tracfoneOneCarrierProfileBucketTiers);
        tracfoneOneCarrierProfileBuckets.add(tracfoneOneCarrierProfileBucket);

        List<TracfoneOneCarrierProfileChildTier> tracfoneOneCarrierProfileChildTiers = new ArrayList<>();
        TracfoneOneCarrierProfileChildTier tracfoneOneCarrierProfileChildTier = new TracfoneOneCarrierProfileChildTier();
        tracfoneOneCarrierProfileChildTier.setCarrierProfileChildObjId("10");
        tracfoneOneCarrierProfileChildTier.setUsageTierId("10");
        tracfoneOneCarrierProfileChildTiers.add(tracfoneOneCarrierProfileChildTier);
        List<TracfoneOneCarrierProfileChildBucket> tracfoneOneCarrierProfileChildBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileChildBucket tracfoneOneCarrierProfileChildBucket = new TracfoneOneCarrierProfileChildBucket();
        tracfoneOneCarrierProfileChildBucket.setActiveFlag("Y");
        tracfoneOneCarrierProfileChildBucket.setTracfoneOneCarrierProfileChildTiers(tracfoneOneCarrierProfileChildTiers);
        tracfoneOneCarrierProfileChildBuckets.add(tracfoneOneCarrierProfileChildBucket);

        List<TracfoneOneRatePlanExtensionLink> ratePlanExtensionLinks = new ArrayList<>();
        TracfoneOneRatePlanExtensionLink ratePlanExtensionLink = new TracfoneOneRatePlanExtensionLink();
        ratePlanExtensionLink.setObjId("10");
        ratePlanExtensionLink.setCarrierFeatureId("10");
        ratePlanExtensionLink.setRatePlanExtensionId("10");
        ratePlanExtensionLink.setProfileId("10");
        ratePlanExtensionLink.setTracfoneOneCarrierProfileBuckets(tracfoneOneCarrierProfileBuckets);
        ratePlanExtensionLink.setTracfoneOneCarrierProfileChildBuckets(tracfoneOneCarrierProfileChildBuckets);
        ratePlanExtensionLinks.add(ratePlanExtensionLink);
        TracfoneOneServicePlanCarrierFeature servicePlanCarrierFeature = new TracfoneOneServicePlanCarrierFeature();
        servicePlanCarrierFeature.setServicePlanId("185");
        servicePlanCarrierFeature.setCarrierFeaturesId("185");
        servicePlanCarrierFeature.setPriority("1");
        TracfoneOneCarrierFeature tfOneCarrierFeature = new TracfoneOneCarrierFeature();
        tfOneCarrierFeature.setxFeature2xCarrier("CARRIER");
        tfOneCarrierFeature.setObjId("10");
        tfOneCarrierFeature.setDbEnv(DB_ENV);
        tfOneCarrierFeature.setServicePlanCarrierFeature(servicePlanCarrierFeature);
        tfOneCarrierFeature.setRatePlanExtensionLinks(ratePlanExtensionLinks);
        when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).
                thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
                .thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("10");
        TFOneGeneralResponse response = tracfoneRatePlanAction.insertRatePlanAssociation(tfOneCarrierFeature, 1);
        assertEquals("Success", response.getStatus());
        assertEquals(response.getMessage(), tfOneCarrierFeature.getObjId());
    }

    @Test
    public void testInsertRatePlanAssociation_whenObjIdNull() throws TracfoneOneException, SQLException {
        List<TracfoneOneCarrierProfileBucketTier> tracfoneOneCarrierProfileBucketTiers = new ArrayList<>();
        TracfoneOneCarrierProfileBucketTier tracfoneOneCarrierProfileBucketTier = new TracfoneOneCarrierProfileBucketTier();
        tracfoneOneCarrierProfileBucketTier.setObjId("10");
        tracfoneOneCarrierProfileBucketTier.setUsageTierId("10");
        tracfoneOneCarrierProfileBucketTiers.add(tracfoneOneCarrierProfileBucketTier);
        List<TracfoneOneCarrierProfileBucket> tracfoneOneCarrierProfileBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileBucket tracfoneOneCarrierProfileBucket = new TracfoneOneCarrierProfileBucket();
        tracfoneOneCarrierProfileBucket.setObjectId("10");
        tracfoneOneCarrierProfileBucket.setBucketId("10");
        tracfoneOneCarrierProfileBucket.setAutoRenewFlag("Y");
        tracfoneOneCarrierProfileBucket.setActiveFlag("Y");
        tracfoneOneCarrierProfileBucket.setTracfoneOneCarrierProfileBucketTiers(tracfoneOneCarrierProfileBucketTiers);
        tracfoneOneCarrierProfileBuckets.add(tracfoneOneCarrierProfileBucket);

        List<TracfoneOneCarrierProfileChildTier> tracfoneOneCarrierProfileChildTiers = new ArrayList<>();
        TracfoneOneCarrierProfileChildTier tracfoneOneCarrierProfileChildTier = new TracfoneOneCarrierProfileChildTier();
        tracfoneOneCarrierProfileChildTier.setCarrierProfileChildObjId("10");
        tracfoneOneCarrierProfileChildTier.setUsageTierId("10");
        tracfoneOneCarrierProfileChildTier.setObjId("10");
        tracfoneOneCarrierProfileChildTiers.add(tracfoneOneCarrierProfileChildTier);
        List<TracfoneOneCarrierProfileChildBucket> tracfoneOneCarrierProfileChildBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileChildBucket tracfoneOneCarrierProfileChildBucket = new TracfoneOneCarrierProfileChildBucket();
        tracfoneOneCarrierProfileChildBucket.setActiveFlag("Y");
        tracfoneOneCarrierProfileChildBucket.setTracfoneOneCarrierProfileChildTiers(tracfoneOneCarrierProfileChildTiers);
        tracfoneOneCarrierProfileChildBuckets.add(tracfoneOneCarrierProfileChildBucket);

        List<TracfoneOneRatePlanExtensionLink> ratePlanExtensionLinks = new ArrayList<>();
        TracfoneOneRatePlanExtensionLink ratePlanExtensionLink = new TracfoneOneRatePlanExtensionLink();
        ratePlanExtensionLink.setObjId("10");
        ratePlanExtensionLink.setCarrierFeatureId("10");
        ratePlanExtensionLink.setRatePlanExtensionId("10");
        ratePlanExtensionLink.setProfileId("10");
        ratePlanExtensionLink.setTracfoneOneCarrierProfileBuckets(tracfoneOneCarrierProfileBuckets);
        ratePlanExtensionLink.setTracfoneOneCarrierProfileChildBuckets(tracfoneOneCarrierProfileChildBuckets);
        ratePlanExtensionLinks.add(ratePlanExtensionLink);
        TracfoneOneServicePlanCarrierFeature servicePlanCarrierFeature = new TracfoneOneServicePlanCarrierFeature();
        servicePlanCarrierFeature.setServicePlanId("185");
        servicePlanCarrierFeature.setCarrierFeaturesId("185");
        servicePlanCarrierFeature.setPriority("1");
        TracfoneOneCarrierFeature tfOneCarrierFeature = new TracfoneOneCarrierFeature();
        tfOneCarrierFeature.setxFeature2xCarrier("100");
        tfOneCarrierFeature.setDbEnv(DB_ENV);
        tfOneCarrierFeature.setServicePlanCarrierFeature(servicePlanCarrierFeature);
        tfOneCarrierFeature.setRatePlanExtensionLinks(ratePlanExtensionLinks);

        when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).
                thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
                .thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("10");
        int[] count = new int[]{1, 2, 3};
        int[] count2 = new int[]{1, 2};
        when(stmt.executeBatch()).thenReturn(count).thenReturn(count2);
        TFOneGeneralResponse response = tracfoneRatePlanAction.insertRatePlanAssociation(tfOneCarrierFeature, 1);
        assertEquals("Success", response.getStatus());
        assertEquals(response.getMessage(), tfOneCarrierFeature.getObjId());
    }

    @Test
    public void testSearchCarrierFeaturesForUpdate_whenException() throws SQLException {
        TracfoneOneSearchCarrierFeatureModel tfSearchCarrierFeatureModel = new TracfoneOneSearchCarrierFeatureModel();
        tfSearchCarrierFeatureModel.setDbEnv(DB_ENV);
        tfSearchCarrierFeatureModel.setTracfoneOneCarrierFeature(getTracfoneOneCarrierFeature());
        try {
            tracfoneRatePlanAction.searchCarrierFeaturesForUpdate(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException | TracfoneOneException e) {
            // expected
        }
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneRatePlanAction.searchCarrierFeaturesForUpdate(tfSearchCarrierFeatureModel);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierFeaturesForUpdate() throws TracfoneOneException, SQLException {
        TracfoneOneSearchCarrierFeatureModel tfSearchCarrierFeatureModel = new TracfoneOneSearchCarrierFeatureModel();
        tfSearchCarrierFeatureModel.setDbEnv(DB_ENV);
        tfSearchCarrierFeatureModel.setServicePlanId(ONE);
        tfSearchCarrierFeatureModel.setProfileId("1000");
        tfSearchCarrierFeatureModel.setBucketId("1000");
        tfSearchCarrierFeatureModel.setProfileDesc("PROFILE_DESCRIPTION");
        tfSearchCarrierFeatureModel.setTracfoneOneCarrierFeature(getTracfoneOneCarrierFeature());
        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn(ONE);
        List<TFOneCarrierFeature> carrierFeatures = tracfoneRatePlanAction.searchCarrierFeaturesForUpdate(tfSearchCarrierFeatureModel);
        assertEquals(2, carrierFeatures.size());
    }

    @Test
    public void testGetCarrierRatePlans() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn(ONE);
        List<TFOneRatePlan> tfAllRatePlans = tracfoneRatePlanAction.getCarrierRatePlans(DB_ENV, "CARRIER_NAME");
        assertEquals(2, tfAllRatePlans.size());
    }

    @Test
    public void testGetCarrierRatePlans_whenException() throws SQLException {
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneRatePlanAction.getCarrierRatePlans(DB_ENV, null);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDuplicateCarrierFeatures() throws TracfoneOneException, SQLException {
        List<String> objIds = new ArrayList<>();
        objIds.add(ONE);
        objIds.add(TWO);
        TracfoneOneCarrierFeature tfCarrierFeature = new TracfoneOneCarrierFeature();
        tfCarrierFeature.setDbEnv(DB_ENV);
        tfCarrierFeature.setxFeature2xCarrier("274892");
        tfCarrierFeature.setxFeatures2BusOrg("340945");
        tfCarrierFeature.setxData("TEST");
        TracfoneOneServicePlanCarrierFeature servicePlanCarrierFeature = new TracfoneOneServicePlanCarrierFeature();
        servicePlanCarrierFeature.setPriority("1");
        servicePlanCarrierFeature.setServicePlanId("100");
        tfCarrierFeature.setServicePlanCarrierFeature(servicePlanCarrierFeature);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn(ONE);
        List<String> carrierFeatures = tracfoneRatePlanAction.duplicateCarrierFeatures(tfCarrierFeature);
        assertEquals(1, carrierFeatures.size());
    }

    @Test
    public void testDuplicateCarrierFeatures_withException() throws SQLException {
        TracfoneOneCarrierFeature tfCarrierFeature = new TracfoneOneCarrierFeature();
        tfCarrierFeature.setDbEnv(DB_ENV);
        tfCarrierFeature.setxFeature2xCarrier("274892");
        tfCarrierFeature.setxFeatures2BusOrg("340945");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneRatePlanAction.duplicateCarrierFeatures(tfCarrierFeature);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

}
