package com.tracfone.service;

import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.controller.TracfoneOneTTransNotesControllerLocal;
import com.tracfone.service.controller.TracfoneOneThrottleTransControllerLocal;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneSearchAdditionalModel;
import com.tracfone.service.model.request.TracfoneOneTTransactionNotes;
import com.tracfone.service.model.request.TracfoneOneThrottlePolicy;
import com.tracfone.service.model.request.TracfoneOneThrottleRework;
import com.tracfone.service.model.request.TracfoneOneThrottleTrans;
import com.tracfone.service.model.request.TracfoneOneThrottleTransaction;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.request.TracfoneOneUserTask;
import com.tracfone.service.model.request.TracfoneOneUserTaskDetail;
import com.tracfone.service.model.request.TracfoneonePaginationSearch;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneThrottlePolicy;
import com.tracfone.service.model.response.TFOneThrottleTransSearchResult;
import com.tracfone.service.model.response.TFOneThrottleTransaction;
import com.tracfone.service.model.response.TFOneUserHistory;
import com.tracfone.service.model.response.TFOneUserHistoryDetail;
import com.tracfone.service.model.response.TFOneUserTask;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

import org.mockito.ArgumentMatchers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneThrottleTransResourceTest {

    public final String JSON = "application/json";
    public final String DBENV = "dbEnv";

    private TracfoneOneException tracfoneOneException;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneAuthorizationException tracfoneOneAuthorizationException;

    @InjectMocks
    TracfoneOneThrottleTransResource tracfoneOneThrottleTransResource;

    @Mock
    private TracfoneControllerLocal tracfoneController;

    @Mock
    private TracfoneControllerLocalAction tracfoneControllerAction;

    @Mock
    private TracfoneOneThrottleTransControllerLocal throttleTransController;

    @Mock
    TracfoneOneTTransNotesControllerLocal tracfoneOneTTransNotesControllerLocal;

    @Mock
    private SecurityContext securityContext;
    @Mock
    private TracfoneOnePrincipal principal;
    @Mock
    private TFOneAdminUser user;

    @Before
    public void setUp() {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        tracfoneOneAuthorizationException = new TracfoneOneAuthorizationException("TFE0", "dummy_auth_error_message");
        when(securityContext.getUserPrincipal()).thenReturn(principal);
        when(principal.getTFUser()).thenReturn(user);
    }

    @Test
    public void testGetUserHistoryByUserId() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        tracfoneOneUserHistory.setType("TYPE");
        tracfoneOneUserHistory.setFromCreationDate("2020:02:02");
        tracfoneOneUserHistory.setToCreationDate("2020:06:07");

        List<TFOneUserHistoryDetail> tfUserHistoryDetails = new ArrayList<>();
        TFOneUserHistoryDetail tfUserHistoryDetail = new TFOneUserHistoryDetail();
        tfUserHistoryDetail.setIdDetail("DETAILS");
        tfUserHistoryDetail.setIdType("TYPE");
        tfUserHistoryDetail.setUserHistoryDetailId("1200");
        tfUserHistoryDetail.setUserHistoryId("1");
        tfUserHistoryDetails.add(tfUserHistoryDetail);

        List<TFOneUserHistory> histories = new ArrayList<>();
        TFOneUserHistory history = new TFOneUserHistory();
        history.setCreationDate("2022:01:01");
        history.setId("1");
        history.setType("TT_INSERT");
        history.setTfUserHistoryDetail(tfUserHistoryDetails);
        histories.add(history);
        when(tracfoneControllerAction.getUserHistoryByUserId(any())).thenReturn(histories);
        Response response = tracfoneOneThrottleTransResource.getUserHistoryByUserId(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":\"1\",\"UserId\":null,\"type\":\"TT_INSERT\",\"creationDate\":\"2022:01:01\",\"tfUserHistoryDetail\":[{\"userHistoryDetailId\":\"1200\",\"userHistoryId\":\"1\",\"idType\":\"TYPE\",\"idDetail\":\"DETAILS\"}]}]", response.getEntity().toString());
    }

    @Test
    public void testGetUserHistoryByUserId_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getUserHistoryByUserId(any());
        Response response = tracfoneOneThrottleTransResource.getUserHistoryByUserId(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetUserTaskByUserId() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setType("TT_TRANSACTION");
        tfOneUserTask.setId("1000");
        tfOneUserTask.setAssignedUserId("1000");

        List<String> status = new ArrayList<>();
        status.add("COMPLETED");
        List<TFOneUserTask> userTasks = new ArrayList<>();
        TFOneUserTask userTask = new TFOneUserTask();
        userTask.setType("TT_TRANSACTION");
        userTask.setAssignedUserId("1200");
        userTask.setUserId("1222");
        userTask.setDescription("DESCRIPTION");
        userTask.setTaskName("TASK_NAME");
        userTask.setStatus(status);
        userTasks.add(userTask);

        when(tracfoneControllerAction.getUserTaskByUserId(any())).thenReturn(userTasks);
        Response response = tracfoneOneThrottleTransResource.getUserTaskByUserId(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":null,\"taskName\":\"TASK_NAME\",\"description\":\"DESCRIPTION\",\"userId\":\"1222\",\"assignedUserId\":\"1200\",\"assignedUserName\":null,\"type\":\"TT_TRANSACTION\",\"status\":[\"COMPLETED\"],\"creationDate\":null,\"tfOneUserTaskDetail\":[]}]", response.getEntity().toString());
    }

    @Test
    public void testGetUserTaskByUserId_whenException() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getUserTaskByUserId(any());
        Response response = tracfoneOneThrottleTransResource.getUserTaskByUserId(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void updateUserTask() throws TracfoneOneException {
        List<String> status = new ArrayList<>();
        status.add("COMPLETED");
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setAssignedUserId("381");
        tfOneUserTask.setDescription("DESC");
        tfOneUserTask.setId("381");
        tfOneUserTask.setStatus(status);
        tfOneUserTask.setTaskName("TASK_NAME");
        tfOneUserTask.setType("TYPE");
        tfOneUserTask.setUserId("381");

        TFOneUserTask tfUserTask = new TFOneUserTask();
        tfUserTask.setAssignedUserId("381");
        tfUserTask.setDescription("DESC");
        tfUserTask.setId("381");
        tfUserTask.setStatus(status);
        tfUserTask.setTaskName("TASK_NAME");
        tfUserTask.setType("TYPE");
        tfUserTask.setUserId("381");
        when(tracfoneControllerAction.updateUserTask(any(), anyInt())).thenReturn(tfUserTask);
        Response response = tracfoneOneThrottleTransResource.updateUserTask(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"id\":\"381\",\"taskName\":\"TASK_NAME\",\"description\":\"DESC\",\"userId\":\"381\",\"assignedUserId\":\"381\",\"assignedUserName\":null,\"type\":\"TYPE\",\"status\":[\"COMPLETED\"],\"creationDate\":null,\"tfOneUserTaskDetail\":[]}", response.getEntity().toString());
    }

    @Test
    public void testUpdateEndTime_whenException() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        doThrow(tracfoneOneException).when(tracfoneControllerAction).updateUserTask(any(), anyInt());
        Response response = tracfoneOneThrottleTransResource.updateUserTask(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testViewThrottleTransaction() throws TracfoneOneException {
        TracfoneOneThrottleTransaction tracfoneThrottleTransaction = new TracfoneOneThrottleTransaction();
        tracfoneThrottleTransaction.setDbEnv(DBENV);
        TFOneThrottleTransSearchResult tfOneThrottle = new TFOneThrottleTransSearchResult();
        List<TFOneThrottleTransaction> tfOneThrottleTransacion = new ArrayList();
        TFOneThrottleTransaction throttleTrans = new TFOneThrottleTransaction();
        throttleTrans.setApiMessage("API");
        throttleTrans.setApiStatus("STATUS");
        throttleTrans.setCos("COS");
        throttleTrans.setEntitlement("ENTITLEMENT");
        throttleTrans.setEsn("ESN");
        throttleTrans.setGroupId("GROUPID");
        throttleTrans.setMin("MIN");
        throttleTrans.setParentName("PARENT NAME");
        throttleTrans.setPolicyName("POLICY NAME");
        throttleTrans.setPriority("PRIO");
        throttleTrans.setPropagateFlagValue("FLAG");
        throttleTrans.setRuleId("RULE");
        throttleTrans.setStatus("STATUS");
        throttleTrans.setSubscriberId("SUB ID");
        throttleTrans.setThreshold("THESH");
        throttleTrans.setThrottleGroupType("GROUP_TYPE");
        throttleTrans.setTransactionNum("THROTTLE NUM");
        throttleTrans.setTransactionType("TYPE");
        throttleTrans.setUsageTierId("USAGE ID");
        tfOneThrottleTransacion.add(throttleTrans);
        TracfoneonePaginationSearch tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
        tracfoneonePaginationSearch.setStartIndex(0);
        tracfoneonePaginationSearch.setEndIndex(100);
        tracfoneonePaginationSearch.setTotal(123);
        tfOneThrottle.setPaginationSearch(tracfoneonePaginationSearch);
        tfOneThrottle.setThrottleTransactions(tfOneThrottleTransacion);

        when(throttleTransController.viewThrottleTransaction(any())).thenReturn(tfOneThrottle);
        Response response = tracfoneOneThrottleTransResource.viewThrottleTransactions(tracfoneThrottleTransaction);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"paginationSearch\":{\"startIndex\":0,\"endIndex\":100,\"total\":123},\"throttleTransactions\":[{\"objId\":null,\"transactionNum\":\"THROTTLE NUM\",\"status\":\"STATUS\",\"min\":\"MIN\",\"esn\":\"ESN\",\"transactionType\":\"TYPE\",\"ruleId\":\"RULE\",\"apiMessage\":\"API\",\"apiStatus\":\"STATUS\",\"cos\":\"COS\",\"entitlement\":\"ENTITLEMENT\",\"parentName\":\"PARENT NAME\",\"policyName\":\"POLICY NAME\",\"priority\":\"PRIO\",\"propagateFlagValue\":\"FLAG\",\"subscriberId\":\"SUB ID\",\"threshold\":\"THESH\",\"throttleGroupType\":\"GROUP_TYPE\",\"usageTierId\":\"USAGE ID\",\"groupId\":\"GROUPID\",\"creationDate\":null,\"lastUpdateDate\":null}]}", response.getEntity().toString());
    }

    @Test
    public void testViewThrottleTrans_whenException() throws TracfoneOneException {
        TracfoneOneThrottleTransaction tracfoneThrottleTransaction = new TracfoneOneThrottleTransaction();
        doThrow(tracfoneOneException).when(throttleTransController).viewThrottleTransaction(any());
        Response response = tracfoneOneThrottleTransResource.viewThrottleTransactions(tracfoneThrottleTransaction);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetAllUsers() throws TracfoneOneException, TracfoneOneAuthorizationException {
        List<TFOneAdminUser> tfOneAdminUsers = new ArrayList<>();
        TFOneAdminUser tfOneAdminUser = new TFOneAdminUser();
        tfOneAdminUser.setUserName("GSHARMA");
        tfOneAdminUser.setUserId(543);
        tfOneAdminUser.setDescription("DESC");
        tfOneAdminUsers.add(tfOneAdminUser);
        when(tracfoneController.getAllUsers(any())).thenReturn(tfOneAdminUsers);
        Response response = tracfoneOneThrottleTransResource.getAllUsers();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"userId\":543,\"userName\":\"GSHARMA\",\"email\":null,\"token\":null,\"description\":\"DESC\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllUsers_whenException() throws TracfoneOneException, TracfoneOneAuthorizationException {
        doThrow(tracfoneOneException).when(tracfoneController).getAllUsers(any());
        Response response = tracfoneOneThrottleTransResource.getAllUsers();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetAllUsers_whenAuthException() throws TracfoneOneException, TracfoneOneAuthorizationException {
        doThrow(tracfoneOneAuthorizationException).when(tracfoneController).getAllUsers(any());
        Response response = tracfoneOneThrottleTransResource.getAllUsers();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_auth_error_message\",\"httpCode\":401}", response.getEntity().toString());
    }

    @Test
    public void testInsertUserTask() throws TracfoneOneException {
        List<TracfoneOneUserTaskDetail> tfOneUserTaskDetails = new ArrayList<>();
        TracfoneOneUserTaskDetail tfOneUserTaskDetail = new TracfoneOneUserTaskDetail();
        tfOneUserTaskDetail.setTaskDetails("DETAILES");
        tfOneUserTaskDetail.setUserComments("COMMENT");
        tfOneUserTaskDetails.add(tfOneUserTaskDetail);
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setType("TT_TYPE");
        tfOneUserTask.setAssignedUserId("234");
        tfOneUserTask.setUserId("435");
        tfOneUserTask.setTaskName("TASK_NAME");
        tfOneUserTask.setDescription("DESC");
        tfOneUserTask.setTfOneUserTaskDetails(tfOneUserTaskDetails);

        when(tracfoneControllerAction.insertUserTask(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneThrottleTransResource.insertUserTask(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertUserTask_whenException() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        doThrow(tracfoneOneException).when(tracfoneControllerAction).insertUserTask(any(), anyInt());
        Response response = tracfoneOneThrottleTransResource.insertUserTask(tfOneUserTask);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testReworkAll() throws TracfoneOneException {
        List<String> values = new ArrayList<>();
        values.add("test");
        TracfoneOneThrottleTransaction tracfoneThrottleTransaction = new TracfoneOneThrottleTransaction();
        List<TracfoneOneSearchAdditionalModel> tracfoneOneSearch = new ArrayList<>();
        TracfoneOneSearchAdditionalModel tracfoneOneSearchAdditionalModel = new TracfoneOneSearchAdditionalModel();
        tracfoneOneSearchAdditionalModel.setSearchColumnName("transactionNum");
        tracfoneOneSearchAdditionalModel.setSearchColumnType("string");
        tracfoneOneSearchAdditionalModel.setSearchIsColumnLike(false);
        tracfoneOneSearchAdditionalModel.setSearchIsColumnNotIn(false);
        tracfoneOneSearchAdditionalModel.setSearchValues(values);
        tracfoneOneSearch.add(tracfoneOneSearchAdditionalModel);
        tracfoneThrottleTransaction.setDbEnv(DBENV);
        tracfoneThrottleTransaction.setSearchColumns(tracfoneOneSearch);
        TracfoneOneThrottleRework tfThrottleTransaction = new TracfoneOneThrottleRework();
        TracfoneOneThrottleTrans throttleTrans = new TracfoneOneThrottleTrans();
        throttleTrans.setStatus("E");
        throttleTrans.setApiMessage("TEST API MESSAGE");
        tfThrottleTransaction.setReworkCriteria(throttleTrans);
        tfThrottleTransaction.setChunkSize("1000");
        tfThrottleTransaction.setSearchCriteria(tracfoneThrottleTransaction);

        when(throttleTransController.reworkRequeue(any(), anyString(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneThrottleTransResource.rework(tfThrottleTransaction);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testReworkAll_whenException() throws TracfoneOneException {
        TracfoneOneThrottleRework tfThrottleTransaction = new TracfoneOneThrottleRework();
        doThrow(tracfoneOneException).when(throttleTransController).reworkRequeue(any(), anyString(), anyInt());
        Response response = tracfoneOneThrottleTransResource.rework(tfThrottleTransaction);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testRequeueAll() throws TracfoneOneException {
        List<String> values = new ArrayList<>();
        values.add("test");
        TracfoneOneThrottleTransaction tracfoneThrottleTransaction = new TracfoneOneThrottleTransaction();
        List<TracfoneOneSearchAdditionalModel> tracfoneOneSearch = new ArrayList<>();
        TracfoneOneSearchAdditionalModel tracfoneOneSearchAdditionalModel = new TracfoneOneSearchAdditionalModel();
        tracfoneOneSearchAdditionalModel.setSearchColumnName("transactionNum");
        tracfoneOneSearchAdditionalModel.setSearchColumnType("string");
        tracfoneOneSearchAdditionalModel.setSearchIsColumnLike(false);
        tracfoneOneSearchAdditionalModel.setSearchIsColumnNotIn(false);
        tracfoneOneSearchAdditionalModel.setSearchValues(values);
        tracfoneOneSearch.add(tracfoneOneSearchAdditionalModel);
        tracfoneThrottleTransaction.setDbEnv(DBENV);
        tracfoneThrottleTransaction.setSearchColumns(tracfoneOneSearch);
        TracfoneOneThrottleRework tfThrottleTransaction = new TracfoneOneThrottleRework();
        TracfoneOneThrottleTrans throttleTrans = new TracfoneOneThrottleTrans();
        throttleTrans.setStatus("E");
        throttleTrans.setApiMessage("TEST API MESSAGE");
        tfThrottleTransaction.setReworkCriteria(throttleTrans);
        tfThrottleTransaction.setChunkSize("1000");
        tfThrottleTransaction.setSearchCriteria(tracfoneThrottleTransaction);

        when(throttleTransController.reworkRequeue(any(), anyString(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneThrottleTransResource.requeue(tfThrottleTransaction);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testRequeueAll_whenException() throws TracfoneOneException {
        TracfoneOneThrottleRework tfThrottleTransaction = new TracfoneOneThrottleRework();
        doThrow(tracfoneOneException).when(throttleTransController).reworkRequeue(any(), anyString(), anyInt());
        Response response = tracfoneOneThrottleTransResource.requeue(tfThrottleTransaction);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetAllFailuresForTT() throws TracfoneOneException {
        String jsonResponse = "[{\"ttObjid\":\"625842364\",\"xCarrier\":\"AT\\u0026T WIRELESS\",\"xTimeSegment\":\"2020:07:17 06:00:00\",\"orderTypeGroup\":\"TTOFF\",\"totalTransCount\":\"1\",\"percentFailure\":\"1\",\"failureCount\":\"1\",\"sumE\":\"1\"}]";
        when(tracfoneController.getAllFailures(anyString(), ArgumentMatchers.anyBoolean())).thenReturn(jsonResponse);
        Response response = tracfoneOneThrottleTransResource.getAllFailuresForTT(true);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals(jsonResponse, response.getEntity().toString());
    }

    @Test
    public void testGetAllFailuresForTT_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneController).getAllFailures(anyString(), ArgumentMatchers.anyBoolean());
        Response response = tracfoneOneThrottleTransResource.getAllFailuresForTT(true);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testInsertThrottleTransaction() throws TracfoneOneException {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setApiMessage("API_MESSAGE");
        tfThrottleTrans.setDbEnv(DBENV);
        tfThrottleTrans.setThreshold("THROHALD");
        tfThrottleTrans.setSitOrTst(true);

        when(throttleTransController.insertThrottleTransaction(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneThrottleTransResource.insertThrottleTransaction(tfThrottleTrans);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertThrottleTransaction_whenException() throws TracfoneOneException {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setApiMessage("API_MESSAGE");
        tfThrottleTrans.setThrottleGroupType("THROHALD");
        tfThrottleTrans.setSitOrTst(true);

        doThrow(tracfoneOneException).when(throttleTransController).insertThrottleTransaction(any(), anyInt());
        Response response = tracfoneOneThrottleTransResource.insertThrottleTransaction(tfThrottleTrans);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testInsertThrottleTrans() throws TracfoneOneException {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setApiMessage("API_MESSAGE");
        tfThrottleTrans.setDbEnv(DBENV);
        tfThrottleTrans.setThreshold("THROHALD");
        tfThrottleTrans.setSitOrTst(true);

        when(throttleTransController.insertThrottle(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneThrottleTransResource.insertThrottleTrans(tfThrottleTrans);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertThrottleTrans_whenException() throws TracfoneOneException {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setApiMessage("API_MESSAGE");
        tfThrottleTrans.setThrottleGroupType("THROHALD");
        tfThrottleTrans.setSitOrTst(true);

        doThrow(tracfoneOneException).when(throttleTransController).insertThrottle(any(), anyInt());
        Response response = tracfoneOneThrottleTransResource.insertThrottleTrans(tfThrottleTrans);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetPolicyName() throws TracfoneOneException {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");

        List<TFOneThrottlePolicy> policyList = new ArrayList<>();
        TFOneThrottlePolicy policy = new TFOneThrottlePolicy();
        policy.setObjId("1");
        policy.setPolicyName("POLICY_NAME");
        policyList.add(policy);

        when(throttleTransController.getPolicyName(any())).thenReturn(policyList);
        Response response = tracfoneOneThrottleTransResource.getPolicyName(tfhrottleTrans);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1\",\"policyName\":\"POLICY_NAME\",\"policyDesc\":null,\"bypassTransQueue\":null,\"dataSuspendedFlag\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetPolicyName_whenException() throws TracfoneOneException {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        doThrow(tracfoneOneException).when(throttleTransController).getPolicyName(any());
        Response response = tracfoneOneThrottleTransResource.getPolicyName(tfhrottleTrans);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetUsageTierId() throws TracfoneOneException {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");

        List<String> usageTierIdList = new ArrayList<>();
        usageTierIdList.add("1");
        usageTierIdList.add("2");

        when(throttleTransController.getUsageTierId(any())).thenReturn(usageTierIdList);
        Response response = tracfoneOneThrottleTransResource.getUsageTierId(tfhrottleTrans);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[\"1\",\"2\"]", response.getEntity().toString());
    }

    @Test
    public void testGetUsageTierId_whenException() throws TracfoneOneException {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        doThrow(tracfoneOneException).when(throttleTransController).getUsageTierId(any());
        Response response = tracfoneOneThrottleTransResource.getUsageTierId(tfhrottleTrans);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetCos() throws TracfoneOneException {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");

        List<String> cosList = new ArrayList<>();
        cosList.add("1");
        cosList.add("2");

        when(throttleTransController.getCos(any())).thenReturn(cosList);
        Response response = tracfoneOneThrottleTransResource.getCos(tfhrottleTrans);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[\"1\",\"2\"]", response.getEntity().toString());
    }

    @Test
    public void testGetCos_whenException() throws TracfoneOneException {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        doThrow(tracfoneOneException).when(throttleTransController).getCos(any());
        Response response = tracfoneOneThrottleTransResource.getCos(tfhrottleTrans);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetPriority() throws TracfoneOneException {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");
        tfhrottleTrans.setCos("COS");
        List<String> priorityList = new ArrayList<>();
        priorityList.add("1");
        priorityList.add("2");
        when(throttleTransController.getPriority(any(), anyString())).thenReturn(priorityList);
        Response response = tracfoneOneThrottleTransResource.getPriority(tfhrottleTrans);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[\"1\",\"2\"]", response.getEntity().toString());
    }

    @Test
    public void testGetPriority_whenException() throws TracfoneOneException {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setCos("COS");
        doThrow(tracfoneOneException).when(throttleTransController).getPriority(any(), anyString());
        Response response = tracfoneOneThrottleTransResource.getPriority(tfhrottleTrans);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetThresholdEntitlement() throws TracfoneOneException {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");
        List<String> list = new ArrayList<>();
        list.add("1");
        list.add("2");
        when(throttleTransController.getThresholdEntitlement(any(), anyString())).thenReturn(list);
        Response response = tracfoneOneThrottleTransResource.getThresholdEntitlement(tfhrottleTrans, "THRESHOLD");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[\"1\",\"2\"]", response.getEntity().toString());
    }

    @Test
    public void testGetThresholdEntitlement_whenException() throws TracfoneOneException {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        doThrow(tracfoneOneException).when(throttleTransController).getThresholdEntitlement(any(), anyString());
        Response response = tracfoneOneThrottleTransResource.getThresholdEntitlement(tfhrottleTrans, "THRESHOLD");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetRuleId() throws TracfoneOneException {
        TracfoneOneThrottlePolicy tfThrottlePolicy = new TracfoneOneThrottlePolicy();
        tfThrottlePolicy.setObjId("100");
        tfThrottlePolicy.setObjId(DBENV);
        List<String> list = new ArrayList<>();
        list.add("1");
        list.add("2");
        when(throttleTransController.getRuleId(any(), anyString())).thenReturn(list);
        Response response = tracfoneOneThrottleTransResource.getRuleId(tfThrottlePolicy);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[\"1\",\"2\"]", response.getEntity().toString());
    }

    @Test
    public void testGetRuleId_whenException() throws TracfoneOneException {
        TracfoneOneThrottlePolicy tfThrottlePolicy = new TracfoneOneThrottlePolicy();
        tfThrottlePolicy.setObjId("100");
        doThrow(tracfoneOneException).when(throttleTransController).getRuleId(any(), anyString());
        Response response = tracfoneOneThrottleTransResource.getRuleId(tfThrottlePolicy);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testInsertThrottleTransNotes() throws TracfoneOneException {
        List<String> objIds = new ArrayList<>(1);
        objIds.add("OBJID1");
        objIds.add("OBJID2");
        objIds.add("OBJID3");
        TracfoneOneTTransactionNotes tfTTransactionNotes = new TracfoneOneTTransactionNotes();
        tfTTransactionNotes.setNotes("NOTE");
        tfTTransactionNotes.setObjIds(objIds);
        tfTTransactionNotes.setDbEnv("DB");
        when(tracfoneOneTTransNotesControllerLocal.insertThrottleTransNotes(any(), any())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneThrottleTransResource.insertThrottleTransNotes(tfTTransactionNotes);
        assertEquals(200, response.getStatus());
        assertEquals(JSON, response.getMediaType().toString());
    }

    @Test
    public void testInsertThrottleTransNotes_whenException() throws TracfoneOneException {
        TracfoneOneTTransactionNotes tfTTransactionNotes = new TracfoneOneTTransactionNotes();
        doThrow(tracfoneOneException).when(tracfoneOneTTransNotesControllerLocal).insertThrottleTransNotes(any(), any());
        Response response = tracfoneOneThrottleTransResource.insertThrottleTransNotes(tfTTransactionNotes);
        assertEquals(200, response.getStatus());
    }
}