package com.tracfone.service;

import com.tracfone.service.controller.TracfoneBucketControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneProfileControllerLocal;
import com.tracfone.service.controller.TracfoneRatePlanControllerLocal;
import com.tracfone.service.controller.TracfoneServicePlanControllerLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtension;
import com.tracfone.service.model.request.TracfoneOneRatePlanProfile;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.request.TracfoneOneSearchCarrierFeatureModel;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneSearchServicePlanModel;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneBusinessOrganization;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileBucketTier;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildTier;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneDatabaseEnvironment;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneRatePlanExtension;
import com.tracfone.service.model.response.TFOneRatePlanExtensionLink;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneMirrorServicePlanResourceTest {
    public final String JSON = "application/json";
    public final String DBENV = "dbEnv";

    @InjectMocks
    private TracfoneOneMirrorServicePlanResource mirrorServicePlanResource;
    @Mock
    private TracfoneControllerLocal tracfoneController;
    @Mock
    private TracfoneRatePlanControllerLocal tracfoneRatePlanController;
    @Mock
    private TracfoneBucketControllerLocal tracfoneBucketController;
    @Mock
    private TracfoneServicePlanControllerLocal tracfoneServicePlanController;
    @Mock
    private TracfoneProfileControllerLocal tracfoneProfileController;
    @Mock
    private SecurityContext securityContext;
    @Mock
    private TracfoneOnePrincipal principal;
    @Mock
    private TFOneAdminUser user;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;
    private TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel;
    private TracfoneOneCarrierFeature tracfoneOneCarrierFeature;
    private TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel;
    private TracfoneOneSearchServicePlanModel tracfoneOneSearchServicePlanModel;
    private TracfoneOneSearchCarrierFeatureModel tracfoneOneSearchCarrierFeatureModel;
    private TracfoneOneRatePlanProfile tracfoneOneRatePlanProfile;
    private TracfoneOneRatePlanExtension tracfoneOneRatePlanExtension;

    public TracfoneOneMirrorServicePlanResourceTest() {
    }

    @Before
    public void setUp() {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        when(securityContext.getUserPrincipal()).thenReturn(principal);
        when(principal.getTFUser()).thenReturn(user);
    }


    @Test
    public void testGetDatabaseEnvironments() throws TracfoneOneException {
        List<TFOneDatabaseEnvironment> tfOneDatabaseEnvironments = new ArrayList<>();
        TFOneDatabaseEnvironment tfOneDatabaseEnvironment = new TFOneDatabaseEnvironment();
        tfOneDatabaseEnvironment.setName("SIT1");
        tfOneDatabaseEnvironments.add(tfOneDatabaseEnvironment);
        when(tracfoneController.getDatabaseEnvironments(user.getUserId())).thenReturn(tfOneDatabaseEnvironments);
        Response response = mirrorServicePlanResource.getDatabaseEnvironments();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":0,\"name\":\"SIT1\",\"description\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetDatabaseEnvironments_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneController).getDatabaseEnvironments(anyInt());
        Response response = mirrorServicePlanResource.getDatabaseEnvironments();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetServicePlansForCarrier() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        searchPlanModel.setDbEnv("local");
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tFOneCarrierServicePlan = new TFOneCarrierServicePlan();
        tFOneCarrierServicePlan.setServicePlanId("185");
        carrierServicePlans.add(tFOneCarrierServicePlan);
        when(tracfoneServicePlanController.getServicePlansForCarrier(any())).thenReturn(carrierServicePlans);
        Response response = mirrorServicePlanResource.getServicePlansForCarrier(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"carrierName\":null,\"servicePlanId\":\"185\",\"mktName\":null,\"description\":null,\"servicePlanPurchase\":null,\"parentName\":null,\"servicePlans\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetServicePlansForCarrier_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneServicePlanController).getServicePlansForCarrier(any());
        Response response = mirrorServicePlanResource.getServicePlansForCarrier(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierFeatureLinks() throws TracfoneOneException {
        List<TFOneCarrierFeature> tfOneCarrierFeatures = new ArrayList<>();
        TFOneCarrierFeature tfOneCarrierFeature = new TFOneCarrierFeature();
        tfOneCarrierFeature.setObjId("1");
        tfOneCarrierFeature.setxRatePlan("RATE_PLAN");
        List<TFOneRatePlanExtensionLink> tfOneRatePlanExtensionLinks = new ArrayList<>();
        TFOneRatePlanExtensionLink link = new TFOneRatePlanExtensionLink();
        link.setAncillaryCode("AL");
        link.setLineStatusCode("AL");
        link.setThrottleStatusCode("AL");
        link.setRatePlanExtensionId("AL");
        link.setCarrierFeatureId("1");
        link.setObjId("100");
        link.setProfileDescription("PROFILE_DESC");
        link.setProfileId("10");
        tfOneRatePlanExtensionLinks.add(link);
        tfOneCarrierFeature.setRpExtensionLinks(tfOneRatePlanExtensionLinks);
        tfOneCarrierFeatures.add(tfOneCarrierFeature);
        when(tracfoneRatePlanController.getCarrierFeatureLinks(anyList())).thenReturn(tfOneCarrierFeatures);

        List<TracfoneOneCarrierFeature> carrierFeatures = new ArrayList<>();
        carrierFeatures.add(tracfoneOneCarrierFeature);
        Response response = mirrorServicePlanResource.getCarrierFeatureLinks(carrierFeatures);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1\",\"dev\":null,\"xTechnology\":null,\"xRatePlan\":\"RATE_PLAN\",\"xVoicemail\":null,\"xVmCode\":null,\"xVmPackage\":null,\"xCallerId\":null,\"xIdCode\":null,\"xIdPackage\":null,\"xSms\":null,\"xSmsCode\":null,\"xSmsPackage\":null,\"xCallWaiting\":null,\"xCwCode\":null,\"xCwPackage\":null,\"xDigitalFeature\":null,\"xDigFeature\":null,\"xFeature2xCarrier\":null,\"xSmscNumber\":null,\"xData\":null,\"xRestrictedUse\":null,\"xSwitchBaseRate\":null,\"xFeatures2BusOrg\":null,\"xIsSwbCarrier\":null,\"xMpn\":null,\"xMpnCode\":null,\"xPoolName\":null,\"createMformIgFlag\":null,\"useCfExtensionFlag\":null,\"dataSaver\":null,\"dataSaverCode\":null,\"useRpExtensionFlag\":null,\"tmoNextGenFlag\":null,\"servicePlanId\":null,\"brand\":null,\"servicePlanCarrierFeature\":null,\"rpExtensionLinks\":[{\"objId\":\"100\",\"carrierFeatureId\":\"1\",\"childPlanId\":null,\"childPlanDescription\":null,\"ratePlanExtensionId\":\"AL\",\"lineStatusCode\":\"AL\",\"throttleStatusCode\":\"AL\",\"ancillaryCode\":\"AL\",\"profileId\":\"10\",\"profileDescription\":\"PROFILE_DESC\"}],\"xCarrierId\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierFeatureLinks_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getCarrierFeatureLinks(anyList());
        List<TracfoneOneCarrierFeature> carrierFeatures = new ArrayList<>();
        carrierFeatures.add(tracfoneOneCarrierFeature);
        Response response = mirrorServicePlanResource.getCarrierFeatureLinks(carrierFeatures);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileBuckets() throws TracfoneOneException {
        List<TFOneCarrierProfileBucket> tfOneCarrierProfileBuckets = new ArrayList<>();
        TFOneCarrierProfileBucket carrierProfileBucket = new TFOneCarrierProfileBucket();
        carrierProfileBucket.setObjid("1");
        carrierProfileBucket.setActiveFlag("Y");
        carrierProfileBucket.setBucketId("BUCKET_ID");
        List<TFOneCarrierProfileBucketTier> tfOneCarrierProfileBucketTiers = new ArrayList<>();
        TFOneCarrierProfileBucketTier carrierProfileBucketTier = new TFOneCarrierProfileBucketTier();
        carrierProfileBucketTier.setObjId("100");
        carrierProfileBucketTier.setUsageTierId("101");
        carrierProfileBucketTier.setTierBehavior("TIER_BEHAVIOR");
        carrierProfileBucketTier.setTierDescription("TIER_DESC");
        tfOneCarrierProfileBucketTiers.add(carrierProfileBucketTier);
        carrierProfileBucket.setTfOneCarrierProfileBucketTiers(tfOneCarrierProfileBucketTiers);
        tfOneCarrierProfileBuckets.add(carrierProfileBucket);
        when(tracfoneBucketController.searchCarrierProfileBuckets(any())).thenReturn(tfOneCarrierProfileBuckets);
        Response response = mirrorServicePlanResource.searchCarrierProfileBuckets(tracfoneOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objid\":\"1\",\"profileId\":null,\"bucketId\":\"BUCKET_ID\",\"servicePlanId\":null,\"activeFlag\":\"Y\",\"unitOfMeasure\":null,\"bucketType\":null,\"bucketGroup\":null,\"bucketRequirement\":null,\"autoRenewFlag\":null,\"autoRenewFrequency\":null,\"autoRenewValue\":null,\"autoRenewDay\":null,\"benefitType\":null,\"bucketValue\":null,\"suiDisplayType\":null,\"priority\":null,\"hideUbiFlag\":null,\"tfOneCarrierProfileBucketTiers\":[{\"objId\":\"100\",\"carrierProfileBucketsObjId\":null,\"usageTierId\":\"101\",\"tierDescription\":\"TIER_DESC\",\"tierValue\":null,\"tierBehavior\":\"TIER_BEHAVIOR\"}]}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileBuckets_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneBucketController).searchCarrierProfileBuckets(any());
        Response response = mirrorServicePlanResource.searchCarrierProfileBuckets(tracfoneOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets() throws TracfoneOneException {
        List<TFOneCarrierProfileChildBucket> carrierProfileChildBuckets = new ArrayList<>();
        TFOneCarrierProfileChildBucket childBucket = new TFOneCarrierProfileChildBucket();
        childBucket.setObjId("1");
        childBucket.setActiveFlag("Y");
        childBucket.setBucketId("BUCKET_ID");
        List<TFOneCarrierProfileChildTier> carrierProfileChildTiers = new ArrayList<>();
        TFOneCarrierProfileChildTier childTier = new TFOneCarrierProfileChildTier();
        childTier.setObjId("100");
        childTier.setUsageTierId("101");
        childTier.setTierBehavior("TIER_BEHAVIOR");
        childTier.setTierDescription("TIER_DESC");
        carrierProfileChildTiers.add(childTier);
        childBucket.setTfOneCarrierProfileChildTiers(carrierProfileChildTiers);
        carrierProfileChildBuckets.add(childBucket);
        when(tracfoneBucketController.searchCarrierProfileChildBuckets(any())).thenReturn(carrierProfileChildBuckets);
        Response response = mirrorServicePlanResource.searchCarrierProfileChildBuckets(tracfoneOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1\",\"profileId\":null,\"servicePlanId\":null,\"childPlanId\":null,\"bucketId\":\"BUCKET_ID\",\"activeFlag\":\"Y\",\"unitOfMeasure\":null,\"bucketType\":null,\"bucketGroup\":null,\"bucketRequirement\":null,\"autoRenewFlag\":null,\"autoRenewFrequency\":null,\"autoRenewValue\":null,\"autoRenewDay\":null,\"benefitType\":null,\"bucketValue\":null,\"priority\":null,\"hideUbiFlag\":null,\"tfOneCarrierProfileChildTiers\":[{\"objId\":\"100\",\"carrierProfileChildObjId\":null,\"usageTierId\":\"101\",\"tierDescription\":\"TIER_DESC\",\"tierValue\":null,\"tierBehavior\":\"TIER_BEHAVIOR\"}]}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneBucketController).searchCarrierProfileChildBuckets(any());
        Response response = mirrorServicePlanResource.searchCarrierProfileChildBuckets(tracfoneOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierFeatures() throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        TFOneCarrierFeature tFOneCarrierFeature = new TFOneCarrierFeature();
        tFOneCarrierFeature.setxTechnology("CDMA");
        carrierFeatures.add(tFOneCarrierFeature);
        when(tracfoneRatePlanController.searchCarrierFeatures(any())).thenReturn(carrierFeatures);
        Response response = mirrorServicePlanResource.searchCarrierFeatures(tracfoneOneSearchCarrierFeatureModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[TFOneCarrierFeature{objId='null', dev='null', xTechnology='CDMA', xRatePlan='null', xVoicemail='null', xVmCode='null', xVmPackage='null', xCallerId='null', xIdCode='null', xIdPackage='null', xSms='null', xSmsCode='null', xSmsPackage='null', xCallWaiting='null', xCwCode='null', xCwPackage='null', xDigitalFeature='null', xDigFeature='null', xFeature2xCarrier='null', xSmscNumber='null', xData='null', xRestrictedUse='null', xSwitchBaseRate='null', xFeatures2BusOrg='null', xIsSwbCarrier='null', xMpn='null', xMpnCode='null', xPoolName='null', createMformIgFlag='null', useCfExtensionFlag='null', dataSaver='null', dataSaverCode='null', useRpExtensionFlag='null', tmoNextGenFlag='null', servicePlanId='null', brand='null', xCarrierId='null', servicePlanCarrierFeature=null, rpExtensionLinks=[]}]", carrierFeatures.toString());
    }

    @Test
    public void testSearchCarrierFeatures_whenException() throws TracfoneOneException {
        TracfoneOneSearchCarrierFeatureModel tracfoneOneSearchCarrierFeatureModel = new TracfoneOneSearchCarrierFeatureModel();
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).searchCarrierFeatures(any(TracfoneOneSearchCarrierFeatureModel.class));
        Response response = mirrorServicePlanResource.searchCarrierFeatures(tracfoneOneSearchCarrierFeatureModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllBusinessOrgs() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        searchPlanModel.setDbEnv("local");
        List<TFOneBusinessOrganization> allBusOrgs = new ArrayList<>();
        TFOneBusinessOrganization tFOneBusinessOrganization = new TFOneBusinessOrganization();
        tFOneBusinessOrganization.setOrgId("1000");
        allBusOrgs.add(tFOneBusinessOrganization);
        when(tracfoneRatePlanController.getAllBusinessOrgs(any())).thenReturn(allBusOrgs);
        Response response = mirrorServicePlanResource.getAllBusinessOrgs(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"orgId\":\"1000\"}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllBusinessOrgs_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getAllBusinessOrgs(any());
        Response response = mirrorServicePlanResource.getAllBusinessOrgs(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllChildPlans() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        searchPlanModel.setDbEnv("local");
        List<TFOneChildPlan> childPlans = new ArrayList<>();
        TFOneChildPlan childPlan = new TFOneChildPlan();
        childPlan.setChildPlanId("1000");
        childPlan.setChildPlanName("CHILD_PLAN_NAME");
        childPlans.add(childPlan);
        when(tracfoneProfileController.getAllChildPlans(any())).thenReturn(childPlans);
        Response response = mirrorServicePlanResource.getAllChildPlans(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"childPlanId\":\"1000\",\"childDescription\":null,\"childPlanName\":\"CHILD_PLAN_NAME\",\"ratePlanProfile\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllChildPlans_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneProfileController).getAllChildPlans(any());
        Response response = mirrorServicePlanResource.getAllChildPlans(searchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchProfile() throws TracfoneOneException {
        List<TFOneRatePlanProfile> tfOneRatePlanProfiles = new ArrayList<>();
        TFOneRatePlanProfile tfOneRatePlanProfile = new TFOneRatePlanProfile();
        tfOneRatePlanProfile.setProfileId("5401");
        tfOneRatePlanProfile.setProfileDescription("PROFILE_DESCRIPTION");
        tfOneRatePlanProfiles.add(tfOneRatePlanProfile);
        when(tracfoneProfileController.searchProfile(any())).thenReturn(tfOneRatePlanProfiles);
        TracfoneOneSearchProfileModel tfRatePlanProfile = new TracfoneOneSearchProfileModel();
        tfRatePlanProfile.setProfileDesc("PROFILE_DESCRIPTION");
        Response response = mirrorServicePlanResource.searchProfile(tfRatePlanProfile);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[TFOneRatePlanProfile{profileId=5401, profileDescription=PROFILE_DESCRIPTION, rpExtensionLinks=null, rpExtensionConfigs=null, buckets=null, features=null}]", tfOneRatePlanProfiles.toString());
    }

    @Test
    public void testSearchProfile_whenException() throws TracfoneOneException {
        TracfoneOneSearchProfileModel tfRatePlanProfile = new TracfoneOneSearchProfileModel();
        doThrow(tracfoneOneException).when(tracfoneProfileController).searchProfile(any(TracfoneOneSearchProfileModel.class));
        Response response = mirrorServicePlanResource.searchProfile(tfRatePlanProfile);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchRpExtensions() throws TracfoneOneException {
        List<TFOneRatePlanExtension> tfRatePlanExtensions = new ArrayList<>();
        TFOneRatePlanExtension tfOneRatePlanExtension = new TFOneRatePlanExtension();
        tfOneRatePlanExtension.setObjId("1000");
        tfOneRatePlanExtension.setAncillaryCode("1001");
        tfOneRatePlanExtension.setLineStatusCode("1000");
        tfRatePlanExtensions.add(tfOneRatePlanExtension);
        when(tracfoneProfileController.searchRpExtensions(any())).thenReturn(tfRatePlanExtensions);
        Response response = mirrorServicePlanResource.searchRpExtensions(tracfoneOneRatePlanExtension);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[TFOneRatePlanExtension{objId=1000, lineStatusCode=1000, throttleStatusCode=null, ancillaryCode=1001}]", tfRatePlanExtensions.toString());
    }

    @Test
    public void testSearchRpExtensions_whenException() throws TracfoneOneException {
        TracfoneOneRatePlanExtension tfRatePlanExtension = new TracfoneOneRatePlanExtension();
        doThrow(tracfoneOneException).when(tracfoneProfileController).searchRpExtensions(any(TracfoneOneRatePlanExtension.class));
        Response response = mirrorServicePlanResource.searchRpExtensions(tfRatePlanExtension);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetAllServicePlanCarrierNames() throws TracfoneOneException {
        List<String> carrierNames = new ArrayList<>();
        carrierNames.add("T-MOBILE");
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setServicePlanId("185");
        when(tracfoneServicePlanController.getAllServicePlanCarrierNames(any())).thenReturn(carrierNames);
        Response response = mirrorServicePlanResource.getAllServicePlanCarrierNames(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[\"T-MOBILE\"]", response.getEntity().toString());
    }

    @Test
    public void testGetAllServicePlanCarrierNames_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setServicePlanId("185");
        doThrow(tracfoneOneException).when(tracfoneServicePlanController).getAllServicePlanCarrierNames(any());
        Response response = mirrorServicePlanResource.getAllServicePlanCarrierNames(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetServicePlansForCopy() throws TracfoneOneException {
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan carrierServicePlan = new TFOneCarrierServicePlan();
        carrierServicePlan.setMktName("MKT_NAME");
        carrierServicePlans.add(carrierServicePlan);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setCarrierName("185");
        when(tracfoneServicePlanController.getServicePlansForCopy(any())).thenReturn(carrierServicePlans);
        Response response = mirrorServicePlanResource.getServicePlansForCopy(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"carrierName\":null,\"servicePlanId\":null,\"mktName\":\"MKT_NAME\",\"description\":null,\"servicePlanPurchase\":null,\"parentName\":null,\"servicePlans\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetServicePlansForCopy_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setCarrierName("185");
        doThrow(tracfoneOneException).when(tracfoneServicePlanController).getServicePlansForCopy(any());
        Response response = mirrorServicePlanResource.getServicePlansForCopy(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testMirrorServicePlan() throws TracfoneOneException {
        Map<String, Integer> copiedObjectMap = new HashMap<>();
        copiedObjectMap.put("BUCKET", 1);
        copiedObjectMap.put("PROFILE", 2);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setServicePlanId("185");
        when(tracfoneServicePlanController.mirrorServicePlan(any(), anyInt())).thenReturn(copiedObjectMap);
        Response response = mirrorServicePlanResource.mirrorServicePlan(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"PROFILE\":2,\"BUCKET\":1}", response.getEntity().toString());
    }

    @Test
    public void testMirrorServicePlan_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setServicePlanId("185");
        doThrow(tracfoneOneException).when(tracfoneServicePlanController).mirrorServicePlan(any(), anyInt());
        Response response = mirrorServicePlanResource.mirrorServicePlan(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

}