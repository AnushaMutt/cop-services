package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneSearchAdditionalModel;
import com.tracfone.service.model.request.TracfoneOneThrottleRework;
import com.tracfone.service.model.request.TracfoneOneThrottleTrans;
import com.tracfone.service.model.request.TracfoneOneThrottleTransaction;
import com.tracfone.service.model.request.TracfoneonePaginationSearch;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneThrottlePolicy;
import com.tracfone.service.model.response.TFOneThrottleTransSearchResult;
import com.tracfone.service.model.response.TFOneThrottleTransaction;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantThrottleTrans;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneThrottleTransControllerTest implements TracfoneOneConstant, TracfoneOneConstantThrottleTrans {

    public final String DBENV = "dbEnv";

    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    @InjectMocks
    TracfoneOneThrottleTransController controllerLocal;

    @Mock
    TracfoneOneThrottleTransActionLocal actionLocal;

    @Before
    public void setUp() {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "100");
        tracfoneOneException = new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
    }

    @Test
    public void testViewThrottleTransController() throws Exception {
        TracfoneOneThrottleTransaction tracfoneThrottleTransaction = new TracfoneOneThrottleTransaction();
        tracfoneThrottleTransaction.setDbEnv(DBENV);

        TFOneThrottleTransSearchResult tfOneThrottle = new TFOneThrottleTransSearchResult();
        List<TFOneThrottleTransaction> tfOneThrottleTransacion = new ArrayList<>();
        TFOneThrottleTransaction throttleTrans = new TFOneThrottleTransaction();
        throttleTrans.setApiMessage("API");
        throttleTrans.setObjId("1234");
        throttleTrans.setCreationDate("020-01-06 16:31:08");
        throttleTrans.setLastUpdateDate("020-01-06 16:31:08");
        throttleTrans.setApiStatus("STATUS");
        throttleTrans.setCos("COS");
        throttleTrans.setEntitlement("ENTITLEMENT");
        throttleTrans.setEsn("ESN");
        throttleTrans.setGroupId("GROUPID");
        throttleTrans.setMin("MIN");
        throttleTrans.setParentName("PARENT NAME");
        throttleTrans.setPolicyName("POLICY NAME");
        throttleTrans.setPriority("PRIO");
        throttleTrans.setPropagateFlagValue("FLAG");
        throttleTrans.setRuleId("RULE");
        throttleTrans.setStatus("STATUS");
        throttleTrans.setSubscriberId("SUB ID");
        throttleTrans.setThreshold("THESH");
        throttleTrans.setThrottleGroupType("GROUP_TYPE");
        throttleTrans.setTransactionNum("THROTTLE NUM");
        throttleTrans.setTransactionType("TYPE");
        throttleTrans.setUsageTierId("USAGE ID");
        tfOneThrottleTransacion.add(throttleTrans);
        TracfoneonePaginationSearch tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
        tracfoneonePaginationSearch.setStartIndex(0);
        tracfoneonePaginationSearch.setEndIndex(100);
        tracfoneonePaginationSearch.setTotal(123);
        tfOneThrottle.setPaginationSearch(tracfoneonePaginationSearch);
        tfOneThrottle.setThrottleTransactions(tfOneThrottleTransacion);

        when(actionLocal.viewThrottleTransaction(any())).thenReturn(tfOneThrottle);
        TFOneThrottleTransSearchResult response = controllerLocal.viewThrottleTransaction(tracfoneThrottleTransaction);
        assertEquals("[TFOneViewThrottleTransaction{transactionNum=THROTTLE NUM, objId=1234, creationDate=020-01-06 16:31:08, lastUpdateDate=020-01-06 16:31:08, transactionType=TYPE, status=STATUS, ruleId=RULE, min=MIN, esn=ESN, priority=PRIO, threshold=THESH, usageTierId=USAGE ID, throttleGroupType=GROUP_TYPE, subscriberId=SUB ID, propogateFlagValue=FLAG, policyName=POLICY NAME, cos=COS, entitlement=ENTITLEMENT, apiMessage=API, apiStatus=STATUS, parentName=PARENT NAME}groupId=GROUPID}]", response.getThrottleTransactions().toString());
    }

    @Test
    public void testViewThrottleTransController_whenException() throws TracfoneOneException {
        doThrow(RuntimeException.class).when(actionLocal).viewThrottleTransaction(any());
        try {
            controllerLocal.viewThrottleTransaction(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_THROTTLE_TRANSACTION_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_THROTTLE_TRANSACTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testReworkRequeueAll() throws Exception {
        List<String> values = new ArrayList<>();
        values.add("test");
        TracfoneOneThrottleTransaction tracfoneThrottleTransaction = new TracfoneOneThrottleTransaction();
        List<TracfoneOneSearchAdditionalModel> tracfoneOneSearch = new ArrayList<>();
        TracfoneOneSearchAdditionalModel tracfoneOneSearchAdditionalModel = new TracfoneOneSearchAdditionalModel();
        tracfoneOneSearchAdditionalModel.setSearchColumnName("transactionNum");
        tracfoneOneSearchAdditionalModel.setSearchColumnType("string");
        tracfoneOneSearchAdditionalModel.setSearchIsColumnLike(false);
        tracfoneOneSearchAdditionalModel.setSearchIsColumnNotIn(false);
        tracfoneOneSearchAdditionalModel.setSearchValues(values);
        tracfoneOneSearch.add(tracfoneOneSearchAdditionalModel);
        tracfoneThrottleTransaction.setDbEnv(DBENV);
        tracfoneThrottleTransaction.setSearchColumns(tracfoneOneSearch);
        TracfoneOneThrottleRework tfThrottleTransaction = new TracfoneOneThrottleRework();
        TracfoneOneThrottleTrans throttleTrans = new TracfoneOneThrottleTrans();
        throttleTrans.setStatus("E");
        throttleTrans.setApiMessage("TEST API MESSAGE");
        tfThrottleTransaction.setReworkCriteria(throttleTrans);
        tfThrottleTransaction.setChunkSize("1000");
        tfThrottleTransaction.setSearchCriteria(tracfoneThrottleTransaction);

        when(actionLocal.reworkRequeue(any(), anyString(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = controllerLocal.reworkRequeue(tfThrottleTransaction, "REWORK", 234);
        assertEquals(response.getStatus(), "200");
        assertEquals(response.getMessage(), "100");
    }

    @Test
    public void testReworkRequeueAll_whenException() throws Exception {
        TracfoneOneThrottleRework tfThrottleTransaction = new TracfoneOneThrottleRework();
        doThrow(tracfoneOneException).when(actionLocal).reworkRequeue(any(), anyString(), anyInt());
        try {
            controllerLocal.reworkRequeue(tfThrottleTransaction, "REWORK", 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_REWORK_THROTTLE_TRANSACTION_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_REWORK_THROTTLE_TRANSACTION_ERROR_MESSAGE, e.getErrorMessage());
        }
        doThrow(tracfoneOneException).when(actionLocal).reworkRequeue(any(), anyString(), anyInt());
        try {
            controllerLocal.reworkRequeue(tfThrottleTransaction, "RE-QUEUE", 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_REQUEUE_THROTTLE_TRANSACTION_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_REQUEUE_THROTTLE_TRANSACTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottleTransaction() throws Exception {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setApiMessage("API_MESSAGE");
        tfThrottleTrans.setDbEnv(DBENV);
        tfThrottleTrans.setThreshold("THROHALD");
        when(actionLocal.insertThrottleTransaction(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = controllerLocal.insertThrottleTransaction(tfThrottleTrans, 100);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testInsertThrottleTransaction_whenException() throws Exception {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setApiMessage("API_MESSAGE");
        tfThrottleTrans.setDbEnv(DBENV);
        tfThrottleTrans.setThreshold("THROHALD");

        doThrow(tracfoneOneException).when(actionLocal).insertThrottleTransaction(any(), anyInt());
        try {
            controllerLocal.insertThrottleTransaction(tfThrottleTrans, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_THROTTLE_TRANSACTION_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_THROTTLE_TRANSACTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetPolicyName() throws Exception {
        List<TFOneThrottlePolicy> policyList = new ArrayList<>();
        TFOneThrottlePolicy policy = new TFOneThrottlePolicy();
        policy.setObjId("1");
        policy.setPolicyName("POLICY_NAME");
        policyList.add(policy);

        when(actionLocal.getPolicyName(anyString())).thenReturn(policyList);
        List<TFOneThrottlePolicy> response = controllerLocal.getPolicyName(DBENV);
        assertEquals("[TFOneThrottlePolicy{objId='1', policyName='POLICY_NAME', policyDesc='null', bypassTransQueue='null', dataSuspendedFlag='null'}]", response.toString());
    }

    @Test
    public void testGetPolicyName_whenException() throws Exception {
        doThrow(tracfoneOneException).when(actionLocal).getPolicyName(anyString());
        try {
            controllerLocal.getPolicyName(DBENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_POLICY_NAME_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_POLICY_NAME_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottle_TTON() throws Exception {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setDbEnv(DBENV);
        tfThrottleTrans.setTransactionType("TTON");
        tfThrottleTrans.setObjId("100");
        when(actionLocal.insertTTONThrottleTrans(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = controllerLocal.insertThrottle(tfThrottleTrans, 100);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testInsertThrottle_TTOFF() throws Exception {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setDbEnv(DBENV);
        tfThrottleTrans.setTransactionType("TTOFF");
        tfThrottleTrans.setObjId("100");
        when(actionLocal.insertTTOFFThrottleTrans(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = controllerLocal.insertThrottle(tfThrottleTrans, 100);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testInsertThrottle_HSBOF() throws Exception {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setDbEnv(DBENV);
        tfThrottleTrans.setTransactionType("HSBOF");
        tfThrottleTrans.setObjId("100");
        when(actionLocal.insertHSBOFThrottleTrans(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = controllerLocal.insertThrottle(tfThrottleTrans, 100);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testInsertThrottle_HSBON() throws Exception {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setDbEnv(DBENV);
        tfThrottleTrans.setTransactionType("HSBON");
        tfThrottleTrans.setObjId("100");
        when(actionLocal.insertHSBONThrottleTrans(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = controllerLocal.insertThrottle(tfThrottleTrans, 100);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals("100", response.getMessage());
    }

    @Test
    public void testInsertThrottle_whenException() throws Exception {
        TracfoneOneThrottleTrans tfThrottleTrans = new TracfoneOneThrottleTrans();
        tfThrottleTrans.setDbEnv(DBENV);
        tfThrottleTrans.setTransactionType("TTON");
        tfThrottleTrans.setObjId("100");

        doThrow(tracfoneOneException).when(actionLocal).insertTTONThrottleTrans(any(), anyInt());
        try {
            controllerLocal.insertThrottle(tfThrottleTrans, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_THROTTLE_TRANSACTION_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_THROTTLE_TRANSACTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetUsageTierId() throws Exception {
        List<String> usageTierIdList = new ArrayList<>();
        usageTierIdList.add("DUMMY_1");
        usageTierIdList.add("DUMMY_2");

        when(actionLocal.getUsageTierId(anyString())).thenReturn(usageTierIdList);
        List<String> response = controllerLocal.getUsageTierId(DBENV);
        assertEquals("[DUMMY_1, DUMMY_2]", response.toString());
    }

    @Test
    public void testGetUsageTierId_whenException() throws Exception {
        doThrow(tracfoneOneException).when(actionLocal).getUsageTierId(anyString());
        try {
            controllerLocal.getUsageTierId(DBENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_USAGE_TIER_ID_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_USAGE_TIER_ID_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCos() throws Exception {
        List<String> cosList = new ArrayList<>();
        cosList.add("DUMMY_1");
        cosList.add("DUMMY_2");

        when(actionLocal.getCos(anyString())).thenReturn(cosList);
        List<String> response = controllerLocal.getCos(DBENV);
        assertEquals("[DUMMY_1, DUMMY_2]", response.toString());
    }

    @Test
    public void testGetCos_whenException() throws Exception {
        doThrow(tracfoneOneException).when(actionLocal).getCos(anyString());
        try {
            controllerLocal.getCos(DBENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_COS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_COS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetPriority() throws Exception {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");
        tfhrottleTrans.setCos("COS");

        List<String> priorityList = new ArrayList<>();
        priorityList.add("DUMMY_1");
        priorityList.add("DUMMY_2");

        when(actionLocal.getPriority(anyString(), anyString())).thenReturn(priorityList);
        List<String> response = controllerLocal.getPriority(DBENV, tfhrottleTrans.getCos());
        assertEquals("[DUMMY_1, DUMMY_2]", response.toString());
    }

    @Test
    public void testGetPriority_whenException() throws Exception {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");
        tfhrottleTrans.setCos("COS");

        doThrow(tracfoneOneException).when(actionLocal).getPriority(anyString(), anyString());
        try {
            controllerLocal.getPriority(DBENV, tfhrottleTrans.getCos());
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_PRIORITY_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_PRIORITY_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetThresholdEntitlement_Threshold() throws Exception {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");

        List<String> list = new ArrayList<>();
        list.add("DUMMY_1");
        list.add("DUMMY_2");

        when(actionLocal.getThresholdEntitlement(anyString(), anyString())).thenReturn(list);
        List<String> response = controllerLocal.getThresholdEntitlement(DBENV, "THRESHOLD");
        assertEquals("[DUMMY_1, DUMMY_2]", response.toString());
    }

    @Test
    public void testGetThresholdEntitlement_whenException() throws Exception {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");
        tfhrottleTrans.setCos("COS");

        doThrow(tracfoneOneException).when(actionLocal).getThresholdEntitlement(anyString(), anyString());
        try {
            controllerLocal.getThresholdEntitlement(DBENV, "THRESHOLD");
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_THRESHOLD_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_THRESHOLD_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetThresholdEntitlement_whenException2() throws Exception {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");
        tfhrottleTrans.setCos("COS");

        doThrow(tracfoneOneException).when(actionLocal).getThresholdEntitlement(anyString(), anyString());
        try {
            controllerLocal.getThresholdEntitlement(DBENV, "ENTITLEMENT");
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ENTITLEMENT_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_ENTITLEMENT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetRuleId() throws Exception {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");
        tfhrottleTrans.setCos("COS");

        List<String> ruleIdList = new ArrayList<>();
        ruleIdList.add("DUMMY_1");
        ruleIdList.add("DUMMY_2");

        when(actionLocal.getRuleId(anyString(), anyString())).thenReturn(ruleIdList);
        List<String> response = controllerLocal.getRuleId(DBENV, tfhrottleTrans.getCos());
        assertEquals("[DUMMY_1, DUMMY_2]", response.toString());
    }

    @Test
    public void testGetRuleId_whenException() throws Exception {
        TracfoneOneThrottleTrans tfhrottleTrans = new TracfoneOneThrottleTrans();
        tfhrottleTrans.setDbEnv("DBENV");
        tfhrottleTrans.setCos("COS");

        doThrow(tracfoneOneException).when(actionLocal).getRuleId(anyString(), anyString());
        try {
            controllerLocal.getRuleId(DBENV, tfhrottleTrans.getCos());
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_RULE_ID_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_RULE_ID_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}
