package com.tracfone.service;

import com.tracfone.service.controller.TracfoneBucketController;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneBulkIdentifier;
import com.tracfone.service.model.request.TracfoneOneBulkTransaction;
import com.tracfone.service.model.request.TracfoneOneColumnDesc;
import com.tracfone.service.model.request.TracfoneOneNewTransaction;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.response.TFOneAdminActionItem;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneBulkInsertReport;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneColumnDesc;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGFailLogs;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneActionResourceTest {
    public final String JSON = "application/json";

    @InjectMocks
    TracfoneOneActionResource tracfoneOneActionResource;

    @Mock
    private TracfoneControllerLocalAction tracfoneControllerAction;

    @Mock
    private SecurityContext securityContext;

    @Mock
    private TracfoneOnePrincipal principal;

    @Mock
    private TFOneAdminUser user;

    @Mock
    private TracfoneBucketController tracfoneBucketController;

    private TracfoneOneException tracfoneOneException;

    private TFOneGeneralResponse tFOneGeneralResponse;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        when(securityContext.getUserPrincipal()).thenReturn(principal);
        when(principal.getTFUser()).thenReturn(user);
    }

    @Test
    public void testGetBulkInsertReport() throws TracfoneOneException {
        List<TFOneBulkInsertReport> bulkInsertReports = new ArrayList<>();
        TFOneBulkInsertReport bulkInsertReport = new TFOneBulkInsertReport();
        bulkInsertReport.setStatus("COMPLETE");
        bulkInsertReport.setSuccessCount("5");
        bulkInsertReport.setErrorCount("0");
        bulkInsertReport.setTotalRecord("5");
        bulkInsertReports.add(bulkInsertReport);
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        when(tracfoneControllerAction.getBulkInsertSummary(anyString(), anyString(), anyInt())).thenReturn(bulkInsertReports);
        Response response = tracfoneOneActionResource.getBulkInsertSummary(tracfoneOneUserHistory);
        assertNotNull(response);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":\"5\",\"successCount\":\"5\",\"errorCount\":\"0\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertReport_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(anyString(), anyString(), anyInt());
        Response response = tracfoneOneActionResource.getBulkInsertSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetErrorRecordDetail() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> errorDeatils = new ArrayList<>();
        TFOneBulkInsertReport errorDetail = new TFOneBulkInsertReport();
        errorDetail.setStatus("COMPLETE");
        errorDetail.setSuccessCount("5");
        errorDetail.setErrorCount("0");
        errorDetail.setTotalRecord("5");
        errorDeatils.add(errorDetail);
        when(tracfoneControllerAction.getErrorRecordDetails(any())).thenReturn(errorDeatils);
        Response response = tracfoneOneActionResource.getErrorRecordDetails(tracfoneOneUserHistory);
        assertNotNull(response);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":\"5\",\"successCount\":\"5\",\"errorCount\":\"0\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetErrorRecordDetails_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getErrorRecordDetails(any());
        Response response = tracfoneOneActionResource.getErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testInsertBulkTransactions() throws TracfoneOneException {
        TracfoneOneBulkTransaction bulkTransaction = new TracfoneOneBulkTransaction();
        TracfoneOneNewTransaction transaction = new TracfoneOneNewTransaction();
        transaction.setRatePlan("TFV3");
        transaction.setZipCode("12345");
        transaction.setOrderType("A");
        transaction.setTemplate("TMOBILE");
        TracfoneOneBulkIdentifier identifier = new TracfoneOneBulkIdentifier();
        identifier.setMin("1234567890");
        List<TracfoneOneBulkIdentifier> identifierList = new ArrayList<>();
        identifierList.add(identifier);
        bulkTransaction.setTracfoneOneNewTransaction(transaction);
        bulkTransaction.setIdentifierList(identifierList);
        Response response = tracfoneOneActionResource.insertBulkTransactions(bulkTransaction);
        assertNotNull(response);
        assertEquals("{\"status\":\"Success\",\"message\":\"Success\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertBulkTransactions_whenException() throws TracfoneOneException {
        TracfoneOneBulkTransaction bulkTransaction = new TracfoneOneBulkTransaction();
        Response response = tracfoneOneActionResource.insertBulkTransactions(bulkTransaction);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"status\":\"Success\",\"message\":\"Success\"}", response.getEntity().toString());
    }

    @Test
    public void testGetIgTransactionsInProgress() throws TracfoneOneException {
        List<TFOneAdminActionItem> tfOneAdminActionItems = new ArrayList<>();
        TFOneAdminActionItem tfOneAdminActionItem = new TFOneAdminActionItem();
        tfOneAdminActionItem.setTransactionId("123");
        tfOneAdminActionItem.setMsid("123");
        tfOneAdminActionItem.setEsn("ESN");
        tfOneAdminActionItem.setIccid("123");
        tfOneAdminActionItems.add(tfOneAdminActionItem);
        TracfoneOneNewTransaction tracfoneOneNewTransaction = new TracfoneOneNewTransaction();
        tracfoneOneNewTransaction.setDbenv("DBENV");
        when(tracfoneControllerAction.getIgTransactionsInProgress(any())).thenReturn(tfOneAdminActionItems);
        Response response = tracfoneOneActionResource.getIgTransactionsInProgress(tracfoneOneNewTransaction);
        assertNotNull(response);
        assertEquals("[{\"buckets\":[],\"hasBuckets\":false,\"env\":null,\"callTransActionType\":null,\"actionItemId\":null,\"carrierId\":null,\"orderType\":null,\"min\":null,\"esn\":\"ESN\",\"esnPartClassModel\":null,\"esnHex\":null,\"oldEsn\":null,\"oldEsnHex\":null,\"pin\":null,\"phoneManf\":null,\"endUser\":null,\"accountNum\":null,\"marketCode\":null,\"ratePlan\":null,\"ldProvider\":null,\"sequenceNum\":null,\"dealerCode\":null,\"transmissionMethod\":null,\"faxNum\":null,\"onlineNum\":null,\"email\":null,\"networkLogin\":null,\"networkPassword\":null,\"systemLogin\":null,\"systemPassword\":null,\"template\":null,\"exeName\":null,\"comPort\":null,\"status\":null,\"statusMessage\":null,\"faxBatchSize\":null,\"faxBatchQtime\":null,\"expidite\":null,\"transProfKey\":null,\"qTransaction\":null,\"onlineNum2\":null,\"faxNum2\":null,\"creationDate\":null,\"updateDate\":null,\"igDbSecsToComp\":null,\"blackoutWait\":null,\"tuxItiServer\":null,\"transactionId\":\"123\",\"technologyFlag\":null,\"voiceMail\":null,\"voiceMailPackage\":null,\"callerId\":null,\"carrierAccountId\":null,\"tmoNextGenFlag\":null,\"callerIdPackage\":null,\"callWaiting\":null,\"callWaitingPackage\":null,\"rtpServer\":null,\"digitalFeatureCode\":null,\"stateField\":null,\"zipCode\":null,\"msid\":\"123\",\"newMsidFlag\":null,\"sms\":null,\"smsPackage\":null,\"iccid\":\"123\",\"oldMin\":null,\"digitalFeature\":null,\"otaType\":null,\"rateCenterNo\":null,\"applicationSystem\":null,\"subscriberUpdate\":null,\"downloadDate\":null,\"prlNumber\":null,\"amount\":null,\"balance\":null,\"language\":null,\"expDate\":null,\"xMpn\":null,\"xMpnCode\":null,\"xPoolName\":null,\"imsi\":null,\"newImsiFlag\":null,\"xMake\":null,\"xModel\":null,\"xMode\":null,\"carrierInitialTransTime\":null,\"carrierEndTransTime\":null,\"igCarrSecsToComp\":null,\"cfExtensionCount\":null,\"dataSaver\":null,\"dataSaverCode\":null,\"xCampaignName\":null,\"carrierFeatureObjid\":null,\"cfProfileId\":null,\"rpExtObjid\":null,\"bucketId\":null,\"rechargeDate\":null,\"bucketBalance\":null,\"bucketValue\":null,\"expirationDate\":null,\"direction\":null,\"benefitType\":null,\"bucketType\":null,\"bucketUsage\":null,\"bucketAction\":null,\"firstName\":null,\"middleInitial\":null,\"lastName\":null,\"suffix\":null,\"prefix\":null,\"ssnLast4\":null,\"address1\":null,\"address2\":null,\"city\":null,\"state\":null,\"zipCode1\":null,\"country\":null,\"ospAccount\":null,\"currAddrHouseNumber\":null,\"currAddrDirection\":null,\"currAddrStreetName\":null,\"currAddrStreetType\":null,\"currAddrUnit\":null,\"servicePlanId\":null,\"igTransInProgress\":null,\"igFailLogs\":null,\"eSimFlag\":null,\"additionalDbColumns\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetIgTransactionsInProgress_whenException() throws TracfoneOneException {
        TracfoneOneNewTransaction tracfoneOneNewTransaction = new TracfoneOneNewTransaction();
        tracfoneOneNewTransaction.setDbenv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getIgTransactionsInProgress(any());
        Response response = tracfoneOneActionResource.getIgTransactionsInProgress(tracfoneOneNewTransaction);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testDeleteIgTransactionInProgress() throws TracfoneOneException {
        TracfoneOneNewTransaction tracfoneOneNewTransaction = new TracfoneOneNewTransaction();
        when(tracfoneControllerAction.deleteIgTransactionInProgress(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneActionResource.deleteIgTransactionInProgress(tracfoneOneNewTransaction);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
    }

    @Test
    public void testDeleteIgTransactionInProgress_whenException() throws TracfoneOneException {
        TracfoneOneNewTransaction tracfoneOneNewTransaction = new TracfoneOneNewTransaction();
        doThrow(tracfoneOneException).when(tracfoneControllerAction).deleteIgTransactionInProgress(any(), anyInt());
        Response response = tracfoneOneActionResource.deleteIgTransactionInProgress(tracfoneOneNewTransaction);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetUserHistoryDetailByIdType() throws TracfoneOneException, TracfoneOneAuthorizationException {
        TracfoneOneUserHistory tfUserHistory = new TracfoneOneUserHistory();
        tfUserHistory.setDbEnv("DBENV");
        when(tracfoneControllerAction.getUserHistoryDetailByIdType(anyString(), anyString(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneActionResource.getUserHistoryDetailByIdType(tfUserHistory, "UNIQUE_KEY");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
    }

    @Test
    public void testGetUserHistoryDetailByIdType_whenException() throws TracfoneOneException, TracfoneOneAuthorizationException {
        TracfoneOneUserHistory tfUserHistory = new TracfoneOneUserHistory();
        tfUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getUserHistoryDetailByIdType(anyString(), anyString(), anyInt());
        Response response = tracfoneOneActionResource.getUserHistoryDetailByIdType(tfUserHistory, "UNIQUE_KEY");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileBuckets() throws TracfoneOneException {
        TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        List<String> profileIds = new ArrayList<>();
        profileIds.add("100");
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add("100");
        tracfoneOneSearchBucketModel.setDbEnv("DBENV");
        tracfoneOneSearchBucketModel.setProfileIds(profileIds);
        tracfoneOneSearchBucketModel.setServicePlanIds(servicePlanIds);

        List<TFOneCarrierProfileBucket> tfOneCarrierProfileBuckets = new ArrayList<>();
        TFOneCarrierProfileBucket tfOneCarrierProfileBucket = new TFOneCarrierProfileBucket();
        tfOneCarrierProfileBucket.setBucketId("TEST");
        tfOneCarrierProfileBuckets.add(tfOneCarrierProfileBucket);
        when(tracfoneBucketController.searchCarrierProfileBuckets(any())).thenReturn(tfOneCarrierProfileBuckets);
        Response response = tracfoneOneActionResource.searchCarrierProfileBuckets(tracfoneOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objid\":null,\"profileId\":null,\"bucketId\":\"TEST\",\"servicePlanId\":null,\"activeFlag\":null,\"unitOfMeasure\":null,\"bucketType\":null,\"bucketGroup\":null,\"bucketRequirement\":null,\"autoRenewFlag\":null,\"autoRenewFrequency\":null,\"autoRenewValue\":null,\"autoRenewDay\":null,\"benefitType\":null,\"bucketValue\":null,\"suiDisplayType\":null,\"priority\":null,\"hideUbiFlag\":null,\"tfOneCarrierProfileBucketTiers\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileBuckets_whenException() throws TracfoneOneException {
        TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        doThrow(tracfoneOneException).when(tracfoneBucketController).searchCarrierProfileBuckets(any());
        Response response = tracfoneOneActionResource.searchCarrierProfileBuckets(tracfoneOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets() throws TracfoneOneException {
        TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        List<String> profileIds = new ArrayList<>();
        profileIds.add("100");
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add("100");
        tracfoneOneSearchBucketModel.setDbEnv("DBENV");
        tracfoneOneSearchBucketModel.setProfileIds(profileIds);
        tracfoneOneSearchBucketModel.setServicePlanIds(servicePlanIds);

        List<TFOneCarrierProfileChildBucket> tfOneCarrierProfileChildBuckets = new ArrayList<>();
        TFOneCarrierProfileChildBucket tfOneCarrierProfileChildBucket = new TFOneCarrierProfileChildBucket();
        tfOneCarrierProfileChildBucket.setBucketId("TEST");
        tfOneCarrierProfileChildBuckets.add(tfOneCarrierProfileChildBucket);
        when(tracfoneBucketController.searchCarrierProfileChildBuckets(any())).thenReturn(tfOneCarrierProfileChildBuckets);
        Response response = tracfoneOneActionResource.searchCarrierProfileChildBuckets(tracfoneOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":null,\"profileId\":null,\"servicePlanId\":null,\"childPlanId\":null,\"bucketId\":\"TEST\",\"activeFlag\":null,\"unitOfMeasure\":null,\"bucketType\":null,\"bucketGroup\":null,\"bucketRequirement\":null,\"autoRenewFlag\":null,\"autoRenewFrequency\":null,\"autoRenewValue\":null,\"autoRenewDay\":null,\"benefitType\":null,\"bucketValue\":null,\"priority\":null,\"hideUbiFlag\":null,\"tfOneCarrierProfileChildTiers\":[]}]", response.getEntity().toString());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets_whenException() throws TracfoneOneException {
        TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        doThrow(tracfoneOneException).when(tracfoneBucketController).searchCarrierProfileChildBuckets(any());
        Response response = tracfoneOneActionResource.searchCarrierProfileChildBuckets(tracfoneOneSearchBucketModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetIgFailLogs() throws TracfoneOneException {
        List<TFOneIGFailLogs> tfOneAdminActionItems = new ArrayList<>();
        TFOneIGFailLogs tfOneAdminActionItem = new TFOneIGFailLogs();
        tfOneAdminActionItem.setTransactionId("123");
        tfOneAdminActionItem.setMsid("123");
        tfOneAdminActionItem.setEsn("ESN");
        tfOneAdminActionItem.setIccid("123");
        tfOneAdminActionItems.add(tfOneAdminActionItem);
        TracfoneOneNewTransaction tracfoneOneNewTransaction = new TracfoneOneNewTransaction();
        tracfoneOneNewTransaction.setDbenv("DBENV");
        tracfoneOneNewTransaction.setActionItemId("GS12345789");
        when(tracfoneControllerAction.getIgFailLogs(any())).thenReturn(tfOneAdminActionItems);
        Response response = tracfoneOneActionResource.getIgFailLogs(tracfoneOneNewTransaction);
        assertNotNull(response);
        assertEquals("[{\"callTransActionType\":null,\"actionItemId\":null,\"carrierId\":null,\"orderType\":null,\"min\":null,\"esn\":\"ESN\",\"esnPartClassModel\":null,\"esnHex\":null,\"oldEsn\":null,\"oldEsnHex\":null,\"pin\":null,\"phoneManf\":null,\"endUser\":null,\"accountNum\":null,\"marketCode\":null,\"ratePlan\":null,\"ldProvider\":null,\"sequenceNum\":null,\"dealerCode\":null,\"transmissionMethod\":null,\"faxNum\":null,\"onlineNum\":null,\"email\":null,\"networkLogin\":null,\"networkPassword\":null,\"systemLogin\":null,\"systemPassword\":null,\"template\":null,\"exeName\":null,\"comPort\":null,\"status\":null,\"statusMessage\":null,\"faxBatchSize\":null,\"faxBatchQtime\":null,\"expidite\":null,\"transProfKey\":null,\"qTransaction\":null,\"onlineNum2\":null,\"faxNum2\":null,\"creationDate\":null,\"updateDate\":null,\"igDbSecsToComp\":null,\"blackoutWait\":null,\"tuxItiServer\":null,\"transactionId\":\"123\",\"technologyFlag\":null,\"voiceMail\":null,\"voiceMailPackage\":null,\"callerId\":null,\"carrierAccountId\":null,\"tmoNextGenFlag\":null,\"callerIdPackage\":null,\"callWaiting\":null,\"callWaitingPackage\":null,\"rtpServer\":null,\"digitalFeatureCode\":null,\"stateField\":null,\"zipCode\":null,\"msid\":\"123\",\"newMsidFlag\":null,\"sms\":null,\"smsPackage\":null,\"iccid\":\"123\",\"oldMin\":null,\"digitalFeature\":null,\"otaType\":null,\"rateCenterNo\":null,\"applicationSystem\":null,\"subscriberUpdate\":null,\"downloadDate\":null,\"amount\":null,\"balance\":null,\"language\":null,\"expDate\":null,\"xMpn\":null,\"xMpnCode\":null,\"xPoolName\":null,\"xMake\":null,\"xModel\":null,\"xMode\":null,\"carrierInitialTransTime\":null,\"carrierEndTransTime\":null,\"loggedDate\":null,\"loggedBy\":null,\"prlNumber\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetIgFailLogs_whenException() throws TracfoneOneException {
        TracfoneOneNewTransaction tracfoneOneNewTransaction = new TracfoneOneNewTransaction();
        tracfoneOneNewTransaction.setDbenv("DBENV");
        tracfoneOneNewTransaction.setActionItemId("GS1234578");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getIgFailLogs(any());
        Response response = tracfoneOneActionResource.getIgFailLogs(tracfoneOneNewTransaction);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetTableDesc() throws TracfoneOneException {
        TracfoneOneColumnDesc tfColumnDesc = new TracfoneOneColumnDesc();
        tfColumnDesc.setDbEnv("DB");
        tfColumnDesc.setTableName("TABLE_NAME");

        List<TFOneColumnDesc> columnDescList = new ArrayList<>();
        TFOneColumnDesc columnDesc = new TFOneColumnDesc();
        columnDesc.setDataType("NUMBER");
        columnDesc.setDataLength("30");
        columnDesc.setColumnName("OBJID");
        columnDescList.add(columnDesc);
        when(tracfoneControllerAction.getTableDesc(any())).thenReturn(columnDescList);
        Response response = tracfoneOneActionResource.getTableDesc(tfColumnDesc);
        assertNotNull(response);
        assertEquals("[{\"columnName\":\"OBJID\",\"dataType\":\"NUMBER\",\"dataLength\":\"30\",\"dataPrecision\":null,\"dataScale\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetTableDesc_whenException() throws TracfoneOneException {
        TracfoneOneColumnDesc tfColumnDesc = new TracfoneOneColumnDesc();
        tfColumnDesc.setDbEnv("DB");
        tfColumnDesc.setTableName("TABLE_NAME");

        doThrow(tracfoneOneException).when(tracfoneControllerAction).getTableDesc(any());
        Response response = tracfoneOneActionResource.getTableDesc(tfColumnDesc);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }
}