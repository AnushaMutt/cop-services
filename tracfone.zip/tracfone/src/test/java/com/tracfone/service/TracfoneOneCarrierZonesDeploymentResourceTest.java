/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service;

import com.tracfone.service.controller.TracfoneCarrierZonesDeploymentControllerLocal;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import com.tracfone.service.model.request.TracfoneOneCarrierZonesDeployment;
import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;
import com.tracfone.service.model.request.TracfoneOneDB2Intergate;
import com.tracfone.service.model.request.TracfoneOneNpaNxx2Carrier;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneCPrefResponse;
import com.tracfone.service.model.response.TFOneCarrierZonesDeployment;
import com.tracfone.service.model.response.TFOneCingularMrktInfo;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneMissingCarrierZones;
import com.tracfone.service.model.response.TFOneMissingCingularMktInfo;
import com.tracfone.service.model.response.TFOneNpaNxx2Carrier;

import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;

import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import org.mockito.junit.MockitoJUnitRunner;

/**
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneCarrierZonesDeploymentResourceTest {

    public final String JSON = "application/json";
    public final String DBENV = "dbEnv";
    private TracfoneOneException tracfoneOneException;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneAuthorizationException tracfoneOneAuthorizationException;

    @InjectMocks
    private TracfoneOneCarrierZonesDeploymentResource carrierZonesDeploymentResource;

    @Mock
    private TracfoneCarrierZonesDeploymentControllerLocal carrierZonesDeploymentControllerLocal;

    @Mock
    private SecurityContext securityContext;
    @Mock
    private TracfoneOnePrincipal principal;
    @Mock
    private TFOneAdminUser user;

    @Before
    public void setUp() {
        initMocks(this);
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
        when(securityContext.getUserPrincipal()).thenReturn(principal);
        when(principal.getTFUser()).thenReturn(user);
    }

    @Test
    public void testValidateCarrierZones() throws TracfoneOneException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        when(carrierZonesDeploymentControllerLocal.validateCarrierZones(any())).thenReturn(zonesDeployment);
        Response response = carrierZonesDeploymentResource.validateCarrierZones(carrierZonesDeployment);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"newZipCodes\":[],\"carrierZones\":[],\"zipNPANXXs\":[],\"arUsaData\":[],\"cingularMrktInfos\":[],\"zipMktSubMkts\":[],\"tmoNextAvailable\":[]}", response.getEntity().toString());
    }

    @Test
    public void testValidateCarrierZones_whenException() throws TracfoneOneException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        doThrow(tracfoneOneException).when(carrierZonesDeploymentControllerLocal).validateCarrierZones(any());
        Response response = carrierZonesDeploymentResource.validateCarrierZones(carrierZonesDeployment);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testValidateNpaNxx() throws TracfoneOneException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        when(carrierZonesDeploymentControllerLocal.validateNpaNxx(any())).thenReturn(zonesDeployment);
        Response response = carrierZonesDeploymentResource.validateNpaNxx(carrierZonesDeployment);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"newZipCodes\":[],\"carrierZones\":[],\"zipNPANXXs\":[],\"arUsaData\":[],\"cingularMrktInfos\":[],\"zipMktSubMkts\":[],\"tmoNextAvailable\":[]}", response.getEntity().toString());
    }

    @Test
    public void testValidateNpaNxx_whenException() throws TracfoneOneException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        doThrow(tracfoneOneException).when(carrierZonesDeploymentControllerLocal).validateNpaNxx(any());
        Response response = carrierZonesDeploymentResource.validateNpaNxx(carrierZonesDeployment);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testValidateArMarket() throws TracfoneOneException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        when(carrierZonesDeploymentControllerLocal.validateARUSA(any())).thenReturn(zonesDeployment);
        Response response = carrierZonesDeploymentResource.validateArMarket(carrierZonesDeployment);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"newZipCodes\":[],\"carrierZones\":[],\"zipNPANXXs\":[],\"arUsaData\":[],\"cingularMrktInfos\":[],\"zipMktSubMkts\":[],\"tmoNextAvailable\":[]}", response.getEntity().toString());
    }

    @Test
    public void testValidateArMarket_whenException() throws TracfoneOneException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        doThrow(tracfoneOneException).when(carrierZonesDeploymentControllerLocal).validateARUSA(any());
        Response response = carrierZonesDeploymentResource.validateArMarket(carrierZonesDeployment);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testAddCarrierZones() throws TracfoneOneException {
        List<TracfoneOneCarrierZones> carrierZoneses = new ArrayList<>();
        TracfoneOneCarrierZones oneCarrierZones = new TracfoneOneCarrierZones();
        oneCarrierZones.setState("TEST");
        oneCarrierZones.setCounty("COUNTY");
        oneCarrierZones.setCarrierId("12345");
        oneCarrierZones.setCarrierName("VZW");
        oneCarrierZones.setDbEnv(DBENV);
        carrierZoneses.add(oneCarrierZones);
        TFOneMissingCarrierZones response = new TFOneMissingCarrierZones();
        response.setFailedRecords(carrierZoneses);
        response.setSuccessRecords(carrierZoneses);
        when(carrierZonesDeploymentControllerLocal.insertMissingCarrierZones(any(), anyInt(), any())).thenReturn(response);
        Response carrierZones = carrierZonesDeploymentResource.addCarrierZones(carrierZoneses, "VERIZON");
        assertEquals(carrierZones.getStatus(), 200);
        assertEquals(carrierZones.getMediaType().toString(), JSON);
        assertEquals("{\"successRecords\":[{\"dbEnv\":\"dbEnv\",\"zipCode\":null,\"state\":\"TEST\",\"county\":\"COUNTY\",\"zone\":null,\"rateCente\":null,\"marketId\":null,\"marketArea\":null,\"city\":null,\"btaMarketNumber\":null,\"btaMarketName\":null,\"carrierId\":\"12345\",\"carrierName\":\"VZW\",\"zipStatus\":null,\"simProfile\":null,\"simProfile2\":null,\"planType\":null,\"carrierRank\":null,\"newRank\":0,\"reasonToFail\":null,\"techReasonToFail\":null,\"oldZipCode\":null,\"oldState\":null,\"oldCounty\":null,\"oldZone\":null,\"oldCarrierName\":null,\"checkDuplicate\":false}],\"failedRecords\":[{\"dbEnv\":\"dbEnv\",\"zipCode\":null,\"state\":\"TEST\",\"county\":\"COUNTY\",\"zone\":null,\"rateCente\":null,\"marketId\":null,\"marketArea\":null,\"city\":null,\"btaMarketNumber\":null,\"btaMarketName\":null,\"carrierId\":\"12345\",\"carrierName\":\"VZW\",\"zipStatus\":null,\"simProfile\":null,\"simProfile2\":null,\"planType\":null,\"carrierRank\":null,\"newRank\":0,\"reasonToFail\":null,\"techReasonToFail\":null,\"oldZipCode\":null,\"oldState\":null,\"oldCounty\":null,\"oldZone\":null,\"oldCarrierName\":null,\"checkDuplicate\":false}]}", carrierZones.getEntity().toString());
    }

    @Test
    public void testAddCarrierZones_whenException() throws TracfoneOneException {
        List<TracfoneOneCarrierZones> carrierZoneses = new ArrayList<>();
        TracfoneOneCarrierZones oneCarrierZones = new TracfoneOneCarrierZones();
        oneCarrierZones.setState("TEST");
        oneCarrierZones.setCounty("COUNTY");
        oneCarrierZones.setCarrierId("12345");
        oneCarrierZones.setCarrierName("VZW");
        oneCarrierZones.setDbEnv(DBENV);
        carrierZoneses.add(oneCarrierZones);
        doThrow(tracfoneOneException).when(carrierZonesDeploymentControllerLocal).insertMissingCarrierZones(any(), anyInt(), any());
        Response response = carrierZonesDeploymentResource.addCarrierZones(carrierZoneses, "VERIZON");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testAddCarrierPref() throws TracfoneOneException {
        List<TracfoneOneCarrierZones> carrierZoneses = new ArrayList<>();
        TracfoneOneCarrierZones oneCarrierZones = new TracfoneOneCarrierZones();
        oneCarrierZones.setState("TEST");
        oneCarrierZones.setCounty("COUNTY");
        oneCarrierZones.setCarrierId("12345");
        oneCarrierZones.setCarrierName("VZW");
        oneCarrierZones.setDbEnv(DBENV);
        carrierZoneses.add(oneCarrierZones);
        TFOneCPrefResponse response = new TFOneCPrefResponse();
        response.setFailedRecords(carrierZoneses);
        response.setSuccessRecords(carrierZoneses);
        when(carrierZonesDeploymentControllerLocal.insertCPref(any(), anyInt())).thenReturn(response);
        Response carrierZones = carrierZonesDeploymentResource.addCarrierPref(carrierZoneses);
        assertEquals(carrierZones.getStatus(), 200);
        assertEquals(carrierZones.getMediaType().toString(), JSON);
        assertEquals("{\"successRecords\":[{\"dbEnv\":\"dbEnv\",\"zipCode\":null,\"state\":\"TEST\",\"county\":\"COUNTY\",\"zone\":null,\"rateCente\":null,\"marketId\":null,\"marketArea\":null,\"city\":null,\"btaMarketNumber\":null,\"btaMarketName\":null,\"carrierId\":\"12345\",\"carrierName\":\"VZW\",\"zipStatus\":null,\"simProfile\":null,\"simProfile2\":null,\"planType\":null,\"carrierRank\":null,\"newRank\":0,\"reasonToFail\":null,\"techReasonToFail\":null,\"oldZipCode\":null,\"oldState\":null,\"oldCounty\":null,\"oldZone\":null,\"oldCarrierName\":null,\"checkDuplicate\":false}],\"failedRecords\":[{\"dbEnv\":\"dbEnv\",\"zipCode\":null,\"state\":\"TEST\",\"county\":\"COUNTY\",\"zone\":null,\"rateCente\":null,\"marketId\":null,\"marketArea\":null,\"city\":null,\"btaMarketNumber\":null,\"btaMarketName\":null,\"carrierId\":\"12345\",\"carrierName\":\"VZW\",\"zipStatus\":null,\"simProfile\":null,\"simProfile2\":null,\"planType\":null,\"carrierRank\":null,\"newRank\":0,\"reasonToFail\":null,\"techReasonToFail\":null,\"oldZipCode\":null,\"oldState\":null,\"oldCounty\":null,\"oldZone\":null,\"oldCarrierName\":null,\"checkDuplicate\":false}]}", carrierZones.getEntity().toString());
    }

    @Test
    public void testAddCarrierPref_whenException() throws TracfoneOneException {
        List<TracfoneOneCarrierZones> carrierZoneses = new ArrayList<>();
        TracfoneOneCarrierZones oneCarrierZones = new TracfoneOneCarrierZones();
        oneCarrierZones.setState("TEST");
        oneCarrierZones.setCounty("COUNTY");
        oneCarrierZones.setCarrierId("12345");
        oneCarrierZones.setCarrierName("VZW");
        oneCarrierZones.setDbEnv(DBENV);
        carrierZoneses.add(oneCarrierZones);
        doThrow(tracfoneOneException).when(carrierZonesDeploymentControllerLocal).insertCPref(any(), anyInt());
        Response response = carrierZonesDeploymentResource.addCarrierPref(carrierZoneses);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testAddNpaNxx() throws TracfoneOneException {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        TFOneNpaNxx2Carrier response = new TFOneNpaNxx2Carrier();
        response.setFailedRecords(nxx2Carriers);
        response.setSuccessRecords(nxx2Carriers);
        when(carrierZonesDeploymentControllerLocal.insertNpaNxx(any(), anyInt())).thenReturn(response);
        Response carrierZones = carrierZonesDeploymentResource.addNpaNxx(nxx2Carriers);
        assertEquals(carrierZones.getStatus(), 200);
        assertEquals(carrierZones.getMediaType().toString(), JSON);
        assertEquals("{\"successRecords\":[{\"dbEnv\":\"dbEnv\",\"npa\":null,\"nxx\":null,\"carrierId\":\"12345\",\"carrierName\":\"VZW\",\"leadTime\":null,\"targetLevel\":null,\"rateCente\":null,\"state\":\"TEST\",\"carrierIdDescription\":null,\"zone\":null,\"county\":\"COUNTY\",\"marketId\":null,\"marketArea\":null,\"sid\":null,\"technology\":null,\"frequency1\":null,\"frequency2\":null,\"btaMarketNumber\":null,\"btaMarketName\":null,\"gsmTech\":null,\"cdmaTech\":null,\"tdmaTech\":null,\"mnc\":null,\"coverageType\":null,\"zipCode\":null,\"reasonToFail\":null,\"techReasonToFail\":null}],\"failedRecords\":[{\"dbEnv\":\"dbEnv\",\"npa\":null,\"nxx\":null,\"carrierId\":\"12345\",\"carrierName\":\"VZW\",\"leadTime\":null,\"targetLevel\":null,\"rateCente\":null,\"state\":\"TEST\",\"carrierIdDescription\":null,\"zone\":null,\"county\":\"COUNTY\",\"marketId\":null,\"marketArea\":null,\"sid\":null,\"technology\":null,\"frequency1\":null,\"frequency2\":null,\"btaMarketNumber\":null,\"btaMarketName\":null,\"gsmTech\":null,\"cdmaTech\":null,\"tdmaTech\":null,\"mnc\":null,\"coverageType\":null,\"zipCode\":null,\"reasonToFail\":null,\"techReasonToFail\":null}]}", carrierZones.getEntity().toString());
    }

    @Test
    public void testAddNpaNxx_whenException() throws TracfoneOneException {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        doThrow(tracfoneOneException).when(carrierZonesDeploymentControllerLocal).insertNpaNxx(any(), anyInt());
        Response response = carrierZonesDeploymentResource.addNpaNxx(nxx2Carriers);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testAddCingularMktInfo() throws TracfoneOneException {
        List<TracfoneOneCingularMrktInfo> mrktInfos = new ArrayList<>();
        TracfoneOneCingularMrktInfo mrktInfo = new TracfoneOneCingularMrktInfo();
        mrktInfo.setDealerCode("DEALER_CODE");
        mrktInfo.setDbEnv("DBENV");
        mrktInfos.add(mrktInfo);
        TFOneMissingCingularMktInfo response = new TFOneMissingCingularMktInfo();
        response.setFailedRecords(mrktInfos);
        response.setSuccessRecords(mrktInfos);
        when(carrierZonesDeploymentControllerLocal.insertCingularMktInfo(any(), anyInt())).thenReturn(response);
        Response carrierZones = carrierZonesDeploymentResource.addCingularMktInfo(mrktInfos);
        assertEquals(carrierZones.getStatus(), 200);
        assertEquals(carrierZones.getMediaType().toString(), JSON);
        assertEquals("{\"successRecords\":[{\"mkt\":null,\"npa\":null,\"nxx\":null,\"npanxx\":null,\"rcNumber\":null,\"rcName\":null,\"rcState\":null,\"zip\":null,\"mktType\":null,\"accountNum\":null,\"marketCode\":null,\"dealerCode\":\"DEALER_CODE\",\"subMarketId\":null,\"template\":null,\"oldZip\":null,\"dbEnv\":\"DBENV\",\"reasonToFail\":null,\"techReasonToFail\":null}],\"failedRecords\":[{\"mkt\":null,\"npa\":null,\"nxx\":null,\"npanxx\":null,\"rcNumber\":null,\"rcName\":null,\"rcState\":null,\"zip\":null,\"mktType\":null,\"accountNum\":null,\"marketCode\":null,\"dealerCode\":\"DEALER_CODE\",\"subMarketId\":null,\"template\":null,\"oldZip\":null,\"dbEnv\":\"DBENV\",\"reasonToFail\":null,\"techReasonToFail\":null}]}", carrierZones.getEntity().toString());
    }

    @Test
    public void testAddCingularMktInfo_whenException() throws TracfoneOneException {
        List<TracfoneOneCingularMrktInfo> mrktInfos = new ArrayList<>();
        TracfoneOneCingularMrktInfo mrktInfo = new TracfoneOneCingularMrktInfo();
        mrktInfo.setDealerCode("DEALER_CODE");
        mrktInfo.setDbEnv("DBENV");
        mrktInfos.add(mrktInfo);
        doThrow(tracfoneOneException).when(carrierZonesDeploymentControllerLocal).insertCingularMktInfo(any(), anyInt());
        Response response = carrierZonesDeploymentResource.addCingularMktInfo(mrktInfos);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testValidateCingularMrktInfo() throws TracfoneOneException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        when(carrierZonesDeploymentControllerLocal.validateCingularMrktInfo(any())).thenReturn(zonesDeployment);
        Response response = carrierZonesDeploymentResource.validateCingularMrktInfo(carrierZonesDeployment);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"newZipCodes\":[],\"carrierZones\":[],\"zipNPANXXs\":[],\"arUsaData\":[],\"cingularMrktInfos\":[],\"zipMktSubMkts\":[],\"tmoNextAvailable\":[]}", response.getEntity().toString());
    }

    @Test
    public void testValidateCingularMrktInfo_whenException() throws TracfoneOneException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        doThrow(tracfoneOneException).when(carrierZonesDeploymentControllerLocal).validateCingularMrktInfo(any());
        Response response = carrierZonesDeploymentResource.validateCingularMrktInfo(carrierZonesDeployment);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testValidateZipMktSubMkt() throws TracfoneOneException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        when(carrierZonesDeploymentControllerLocal.validateZipMktSubMkt(any())).thenReturn(zonesDeployment);
        Response response = carrierZonesDeploymentResource.validateZipMktSubMkt(carrierZonesDeployment);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"newZipCodes\":[],\"carrierZones\":[],\"zipNPANXXs\":[],\"arUsaData\":[],\"cingularMrktInfos\":[],\"zipMktSubMkts\":[],\"tmoNextAvailable\":[]}", response.getEntity().toString());
    }

    @Test
    public void testValidateZipMktSubMkt_whenException() throws TracfoneOneException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        doThrow(tracfoneOneException).when(carrierZonesDeploymentControllerLocal).validateZipMktSubMkt(any());
        Response response = carrierZonesDeploymentResource.validateZipMktSubMkt(carrierZonesDeployment);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testUpdateDealerNan() throws TracfoneOneException {
        List<TracfoneOneCingularMrktInfo> cingularMrktInfos = new ArrayList<>();
        TracfoneOneCingularMrktInfo cingularMrktInfo = new TracfoneOneCingularMrktInfo();
        cingularMrktInfo.setDealerCode("DEALER_CODE");
        cingularMrktInfo.setDbEnv("DBENV");
        cingularMrktInfos.add(cingularMrktInfo);

        List<TFOneCingularMrktInfo> cingularMrktInfoList = new ArrayList<>();
        TFOneCingularMrktInfo cingularMrktInfo1 = new TFOneCingularMrktInfo();
        cingularMrktInfo1.setDealerCode("DEALER_CODE");
        cingularMrktInfoList.add(cingularMrktInfo1);

        when(carrierZonesDeploymentControllerLocal.updateDealerNan(any())).thenReturn(cingularMrktInfoList);
        Response response = carrierZonesDeploymentResource.updateDealerNan(cingularMrktInfos);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"mkt\":null,\"npa\":null,\"nxx\":null,\"npanxx\":null,\"rcNumber\":null,\"rcName\":null,\"rcState\":null,\"zip\":null,\"mktType\":null,\"accountNum\":null,\"marketCode\":null,\"dealerCode\":\"DEALER_CODE\",\"subMarketId\":null,\"template\":null}]", response.getEntity().toString());
    }

    @Test
    public void testUpdateDealerNan_whenException() throws TracfoneOneException {
        List<TracfoneOneCingularMrktInfo> cingularMrktInfos = new ArrayList<>();
        TracfoneOneCingularMrktInfo cingularMrktInfo = new TracfoneOneCingularMrktInfo();
        cingularMrktInfo.setDealerCode("DEALER_CODE");
        cingularMrktInfo.setDbEnv("DBENV");
        cingularMrktInfos.add(cingularMrktInfo);

        doThrow(tracfoneOneException).when(carrierZonesDeploymentControllerLocal).updateDealerNan(any());
        Response response = carrierZonesDeploymentResource.updateDealerNan(cingularMrktInfos);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testValidateNextAvailable() throws TracfoneOneException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        when(carrierZonesDeploymentControllerLocal.validateNextAvailable(any())).thenReturn(zonesDeployment);
        Response response = carrierZonesDeploymentResource.validateNextAvailable(carrierZonesDeployment);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"newZipCodes\":[],\"carrierZones\":[],\"zipNPANXXs\":[],\"arUsaData\":[],\"cingularMrktInfos\":[],\"zipMktSubMkts\":[],\"tmoNextAvailable\":[]}", response.getEntity().toString());
    }

    @Test
    public void testValidateNextAvailable_whenException() throws TracfoneOneException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        doThrow(tracfoneOneException).when(carrierZonesDeploymentControllerLocal).validateNextAvailable(any());
        Response response = carrierZonesDeploymentResource.validateNextAvailable(carrierZonesDeployment);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testAddTmoNpaNxx() throws TracfoneOneException {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        TFOneNpaNxx2Carrier response = new TFOneNpaNxx2Carrier();
        response.setFailedRecords(nxx2Carriers);
        response.setSuccessRecords(nxx2Carriers);
        when(carrierZonesDeploymentControllerLocal.insertTmoNpaNxx(any(), anyInt())).thenReturn(response);
        Response carrierZones = carrierZonesDeploymentResource.addTmoNpaNxx(nxx2Carriers);
        assertEquals(carrierZones.getStatus(), 200);
        assertEquals(carrierZones.getMediaType().toString(), JSON);
        assertEquals("{\"successRecords\":[{\"dbEnv\":\"dbEnv\",\"npa\":null,\"nxx\":null,\"carrierId\":\"12345\",\"carrierName\":\"VZW\",\"leadTime\":null,\"targetLevel\":null,\"rateCente\":null,\"state\":\"TEST\",\"carrierIdDescription\":null,\"zone\":null,\"county\":\"COUNTY\",\"marketId\":null,\"marketArea\":null,\"sid\":null,\"technology\":null,\"frequency1\":null,\"frequency2\":null,\"btaMarketNumber\":null,\"btaMarketName\":null,\"gsmTech\":null,\"cdmaTech\":null,\"tdmaTech\":null,\"mnc\":null,\"coverageType\":null,\"zipCode\":null,\"reasonToFail\":null,\"techReasonToFail\":null}],\"failedRecords\":[{\"dbEnv\":\"dbEnv\",\"npa\":null,\"nxx\":null,\"carrierId\":\"12345\",\"carrierName\":\"VZW\",\"leadTime\":null,\"targetLevel\":null,\"rateCente\":null,\"state\":\"TEST\",\"carrierIdDescription\":null,\"zone\":null,\"county\":\"COUNTY\",\"marketId\":null,\"marketArea\":null,\"sid\":null,\"technology\":null,\"frequency1\":null,\"frequency2\":null,\"btaMarketNumber\":null,\"btaMarketName\":null,\"gsmTech\":null,\"cdmaTech\":null,\"tdmaTech\":null,\"mnc\":null,\"coverageType\":null,\"zipCode\":null,\"reasonToFail\":null,\"techReasonToFail\":null}]}", carrierZones.getEntity().toString());
    }

    @Test
    public void testAddTmoNpaNxx_whenException() throws TracfoneOneException {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        doThrow(tracfoneOneException).when(carrierZonesDeploymentControllerLocal).insertTmoNpaNxx(any(), anyInt());
        Response response = carrierZonesDeploymentResource.addTmoNpaNxx(nxx2Carriers);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testAddNpaNxxAtt() throws TracfoneOneException {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        TFOneNpaNxx2Carrier response = new TFOneNpaNxx2Carrier();
        response.setFailedRecords(nxx2Carriers);
        response.setSuccessRecords(nxx2Carriers);
        when(carrierZonesDeploymentControllerLocal.insertNpaNxxAtt(any(), anyInt())).thenReturn(response);
        Response carrierZones = carrierZonesDeploymentResource.addNpaNxxAtt(nxx2Carriers);
        assertEquals(carrierZones.getStatus(), 200);
        assertEquals(carrierZones.getMediaType().toString(), JSON);
        assertEquals("{\"successRecords\":[{\"dbEnv\":\"dbEnv\",\"npa\":null,\"nxx\":null,\"carrierId\":\"12345\",\"carrierName\":\"VZW\",\"leadTime\":null,\"targetLevel\":null,\"rateCente\":null,\"state\":\"TEST\",\"carrierIdDescription\":null,\"zone\":null,\"county\":\"COUNTY\",\"marketId\":null,\"marketArea\":null,\"sid\":null,\"technology\":null,\"frequency1\":null,\"frequency2\":null,\"btaMarketNumber\":null,\"btaMarketName\":null,\"gsmTech\":null,\"cdmaTech\":null,\"tdmaTech\":null,\"mnc\":null,\"coverageType\":null,\"zipCode\":null,\"reasonToFail\":null,\"techReasonToFail\":null}],\"failedRecords\":[{\"dbEnv\":\"dbEnv\",\"npa\":null,\"nxx\":null,\"carrierId\":\"12345\",\"carrierName\":\"VZW\",\"leadTime\":null,\"targetLevel\":null,\"rateCente\":null,\"state\":\"TEST\",\"carrierIdDescription\":null,\"zone\":null,\"county\":\"COUNTY\",\"marketId\":null,\"marketArea\":null,\"sid\":null,\"technology\":null,\"frequency1\":null,\"frequency2\":null,\"btaMarketNumber\":null,\"btaMarketName\":null,\"gsmTech\":null,\"cdmaTech\":null,\"tdmaTech\":null,\"mnc\":null,\"coverageType\":null,\"zipCode\":null,\"reasonToFail\":null,\"techReasonToFail\":null}]}", carrierZones.getEntity().toString());
    }

    @Test
    public void testAddNpaNxxAtt_whenException() throws TracfoneOneException {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        doThrow(tracfoneOneException).when(carrierZonesDeploymentControllerLocal).insertNpaNxxAtt(any(), anyInt());
        Response response = carrierZonesDeploymentResource.addNpaNxxAtt(nxx2Carriers);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }
}
