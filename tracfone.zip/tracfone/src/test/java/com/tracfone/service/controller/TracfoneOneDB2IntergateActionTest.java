package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneDB2Intergate;
import com.tracfone.service.model.response.TFOneDB2Intergate;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneDB2IntergateActionTest {

    @InjectMocks
    TracfoneOneDB2IntergateAction action;

    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private CallableStatement callableStatement;
    @Mock
    private ResultSet resultSet;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    private TFOneGeneralResponse tfOneGeneralResponse;

    @Before
    public void setUp() throws Exception {
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

    @Test
    public void testViewDB2IntergateTest() throws Exception {
        TracfoneOneDB2Intergate tracfoneOneDB2Intergate = new TracfoneOneDB2Intergate();
        tracfoneOneDB2Intergate.setDbEnv("dnEnv");
        tracfoneOneDB2Intergate.setQueryName("APN");
        tracfoneOneDB2Intergate.setOrderTypes("A");
        tracfoneOneDB2Intergate.setActiveFlag("TRUE");
        tracfoneOneDB2Intergate.setIntervalTime("1500");
        tracfoneOneDB2Intergate.setQueryId("40001");
        tracfoneOneDB2Intergate.setRemarks("TEST");
        tracfoneOneDB2Intergate.setNumberOfRecords("200");
        tracfoneOneDB2Intergate.setStartingRecord("2100");
        tracfoneOneDB2Intergate.setTemplates("TEMP");
        tracfoneOneDB2Intergate.setUseNewSql("FALSE");
        tracfoneOneDB2Intergate.setUpdateQuery("Update Query");

        List<TFOneDB2Intergate> viewData = new ArrayList<>();
        ;
        TFOneDB2Intergate dB2Intergate = new TFOneDB2Intergate();
        dB2Intergate.setActiveFlag("TRUE");
        dB2Intergate.setAppName("TEST");
        dB2Intergate.setExtraWhereClauseConditions("SONS");
        dB2Intergate.setIntervalTime("2020:02:02");
        dB2Intergate.setNumberOfRecords("2020:02:03");
        dB2Intergate.setOrderTypes("OUTAGE_TYPE");
        dB2Intergate.setQueryId("SERVICE_TYPE");
        dB2Intergate.setQueryName("1,2,3");
        dB2Intergate.setRemarks("CHANNEL");
        dB2Intergate.setSelectQueryClob("BRAND");
        dB2Intergate.setStartingRecord("PARENT_SHORT_NAME");
        dB2Intergate.setTemplates("BRAND");
        dB2Intergate.setUpdateQuery("PARENT_SHORT_NAME");
        dB2Intergate.setUseNewSql("BRAND");
        viewData.add(dB2Intergate);

        when(stmt.executeQuery()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMY_DATA");
        List<TFOneDB2Intergate> response = action.viewDB2Intergate(tracfoneOneDB2Intergate);
        assertEquals("[TFOneDB2Intergate{queryId='DUMMY_DATA', queryName='DUMMY_DATA', activeFlag='DUMMY_DATA', useNewSql='DUMMY_DATA', intervalTime='DUMMY_DATA', selectQueryClob='DUMMY_DATA', numberOfRecords='DUMMY_DATA', updateQuery='DUMMY_DATA', templates='DUMMY_DATA', orderTypes='DUMMY_DATA', extraWhereClauseConditions='DUMMY_DATA', appName='DUMMY_DATA', startingRecord='DUMMY_DATA', remarks='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testViewDB2IntergateTest_withException() throws SQLException {
        TracfoneOneDB2Intergate tracfoneOneDB2Intergate = new TracfoneOneDB2Intergate();
        tracfoneOneDB2Intergate.setDbEnv("BRAND");
        tracfoneOneDB2Intergate.setAppName("TEST");
        tracfoneOneDB2Intergate.setOrderTypes("A");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            action.viewDB2Intergate(tracfoneOneDB2Intergate);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateOrderTypes() throws TracfoneOneException {
        TracfoneOneDB2Intergate tracfoneOneDB2Intergate = new TracfoneOneDB2Intergate();
        tracfoneOneDB2Intergate.setDbEnv("DBENV");
        tracfoneOneDB2Intergate.setQueryName("TEST");
        tfOneGeneralResponse = action.updateDB2Intergate(tracfoneOneDB2Intergate, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tracfoneOneDB2Intergate.getQueryId());
    }

    @Test
    public void testUpdateOrderTypes_whenException() throws SQLException, TracfoneOneException {
        // When null is passed
        try {
            action.updateDB2Intergate(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        TracfoneOneDB2Intergate tracfoneOneDB2Intergate = new TracfoneOneDB2Intergate();
        tracfoneOneDB2Intergate.setOrderTypes("ORDER_TYPE");
        tracfoneOneDB2Intergate.setDbEnv("DBENV");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            action.updateDB2Intergate(tracfoneOneDB2Intergate, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}
