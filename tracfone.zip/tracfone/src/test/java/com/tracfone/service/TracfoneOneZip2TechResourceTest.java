package com.tracfone.service;

import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.controller.TracfoneOneZip2TechControllerLocal;
import com.tracfone.service.controller.TracfoneRatePlanControllerLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneBPTech;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.request.TracfoneOneZip2Tech;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneBPTech;
import com.tracfone.service.model.response.TFOneBulkInsertReport;
import com.tracfone.service.model.response.TFOneDatabaseEnvironment;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOneZip2Tech;
import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneZip2TechResourceTest extends TestCase {

    public final String JSON = "application/json";
    public final String DBENV = "dbEnv";
    private TracfoneOneException tracfoneOneException;
    private TFOneGeneralResponse tFOneGeneralResponse;

    @InjectMocks
    TracfoneOneZip2TechResource tracfoneOneZip2TechResource;

    @Mock
    private TracfoneOneZip2TechControllerLocal tracfoneOneZip2TechController;

    @Mock
    private TracfoneControllerLocal tracfoneController;

    @Mock
    private TFOneAdminUser user;

    @Mock
    private TracfoneRatePlanControllerLocal tracfoneRatePlanController;

    @Mock
    private SecurityContext securityContext;
    @Mock
    private TracfoneOnePrincipal principal;

    @Mock
    private TracfoneControllerLocalAction tracfoneControllerAction;

    public TracfoneOneZip2TechResourceTest() {
    }

    @Before
    public void setUp() {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        when(securityContext.getUserPrincipal()).thenReturn(principal);
        when(principal.getTFUser()).thenReturn(user);
    }

    @Test
    public void testGetDatabaseEnvironments() throws TracfoneOneException {
        List<TFOneDatabaseEnvironment> tfOneDatabaseEnvironments = new ArrayList<>();
        TFOneDatabaseEnvironment tfOneDatabaseEnvironment = new TFOneDatabaseEnvironment();
        tfOneDatabaseEnvironment.setName("SIT1");
        tfOneDatabaseEnvironments.add(tfOneDatabaseEnvironment);
        when(tracfoneController.getDatabaseEnvironments(user.getUserId())).thenReturn(tfOneDatabaseEnvironments);
        Response response = tracfoneOneZip2TechResource.getDatabaseEnvironments();
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":0,\"name\":\"SIT1\",\"description\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetDatabaseEnvironments_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneController).getDatabaseEnvironments(anyInt());
        Response response = tracfoneOneZip2TechResource.getDatabaseEnvironments();
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testSearchZip2Tech() throws TracfoneOneException {
        List<TFOneZip2Tech> zip2Teches = new ArrayList<>();
        TFOneZip2Tech zip2Tech = new TFOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setState("STATE");
        zip2Tech.setCounty("COUNTY");
        zip2Tech.setPref1("PREF1");
        zip2Tech.setPref2("PREF2");
        zip2Tech.setService("SERVICE");
        zip2Tech.setLanguage("LANGUAGE");
        zip2Tech.setAction("ACTION");
        zip2Tech.setMarket("MARKET");
        zip2Tech.setZip2("ZIP2");
        zip2Tech.setAid("AID");
        zip2Tech.setVid("VID");
        zip2Tech.setVc("VC");
        zip2Tech.setCom("COM");
        zip2Tech.setLocale("LOCALE");
        zip2Tech.setSiteType("SITETYPE");
        zip2Tech.setGotoPhoneList("GOTOPHONELIST");
        zip2Tech.setTechkey("TECHKEY");
        zip2Tech.setPrefParent("X_PREF_PARENT");
        zip2Teches.add(zip2Tech);

        TracfoneOneZip2Tech tfZip2Tech = new TracfoneOneZip2Tech();
        tfZip2Tech.setZips("12232,23244");
        tfZip2Tech.setDbEnv("DBENV");
        when(tracfoneOneZip2TechController.searchZip2Tech(any())).thenReturn(zip2Teches);
        Response response = tracfoneOneZip2TechResource.searchZip2Tech(tfZip2Tech);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"dbEnv\":null,\"zips\":\"ZIP\",\"state\":\"STATE\",\"county\":\"COUNTY\",\"pref1\":\"PREF1\",\"pref2\":\"PREF2\",\"service\":\"SERVICE\",\"language\":\"LANGUAGE\",\"action\":\"ACTION\",\"market\":\"MARKET\",\"zip2\":\"ZIP2\",\"aid\":\"AID\",\"vid\":\"VID\",\"vc\":\"VC\",\"sahcid\":null,\"com\":\"COM\",\"locale\":\"LOCALE\",\"siteType\":\"SITETYPE\",\"gotoPhoneList\":\"GOTOPHONELIST\",\"tech\":null,\"techZip\":null,\"techkey\":\"TECHKEY\",\"prefParent\":\"X_PREF_PARENT\",\"paginationSearch\":null}]", response.getEntity().toString());
    }

    @Test
    public void testSearchZip2Tech_whenException() throws TracfoneOneException {
        TracfoneOneZip2Tech tfZip2Tech = new TracfoneOneZip2Tech();
        tfZip2Tech.setZips("12232,23244");
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechController).searchZip2Tech(any());
        Response response = tracfoneOneZip2TechResource.searchZip2Tech(tfZip2Tech);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testInsertZip2Techs() throws TracfoneOneException {
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setState("STATE");
        zip2Tech.setCounty("COUNTY");
        zip2Tech.setPref1("PREF1");
        zip2Tech.setPref2("PREF2");
        zip2Tech.setService("SERVICE");
        zip2Tech.setLanguage("LANGUAGE");
        zip2Tech.setAction("ACTION");
        zip2Tech.setMarket("MARKET");
        zip2Tech.setZip2("ZIP2");
        zip2Tech.setAid("AID");
        zip2Tech.setVid("VID");
        zip2Tech.setVc("VC");
        zip2Tech.setCom("COM");
        zip2Tech.setLocale("LOCALE");
        zip2Tech.setSiteType("SITETYPE");
        zip2Tech.setGotoPhoneList("GOTOPHONELIST");
        zip2Tech.setTechkey("TECHKEY");
        zip2Tech.setPrefParent("X_PREF_PARENT");
        when(tracfoneOneZip2TechController.insertZip2Tech(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneZip2TechResource.insertZip2Tech(zip2Tech);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertZip2Techs_whenException() throws TracfoneOneException {
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setDbEnv("DBENV");

        doThrow(tracfoneOneException).when(tracfoneOneZip2TechController).insertZip2Tech(any(), anyInt());
        Response response = tracfoneOneZip2TechResource.insertZip2Tech(zip2Tech);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testUpdateZip2Techs() throws TracfoneOneException {
        List<TracfoneOneZip2Tech> tfZip2Techs = new ArrayList<>();
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setState("STATE");
        zip2Tech.setService("SERVICE");
        zip2Tech.setLanguage("LANGUAGE");
        zip2Tech.setTechkey("TECHKEY");
        zip2Tech.setOldTechKey("OLD_TECHKEY");
        zip2Tech.setOldPrefParent("OLD_PREF_PARENT");
        zip2Tech.setOldService("OLD_SERVICE");
        zip2Tech.setPrefParent("X_PREF_PARENT");
        tfZip2Techs.add(zip2Tech);
        when(tracfoneOneZip2TechController.updateZip2Techs(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneZip2TechResource.updateZip2Techs(tfZip2Techs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateZip2Techs_whenException() throws TracfoneOneException {
        List<TracfoneOneZip2Tech> tfZip2Techs = new ArrayList<>();
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setDbEnv("DBENV");
        tfZip2Techs.add(zip2Tech);
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechController).updateZip2Techs(any(), anyInt());
        Response response = tracfoneOneZip2TechResource.updateZip2Techs(tfZip2Techs);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetColumn() throws TracfoneOneException {
        List<String> service = new ArrayList<>();
        service.add("DUMMY_DATA1");
        service.add("DUMMY_DATA2");

        TracfoneOneZip2Tech tfZip2Tech = new TracfoneOneZip2Tech();
        tfZip2Tech.setDbEnv("DBENV");
        when(tracfoneOneZip2TechController.getZip2TechColumnValues(anyString(), anyString())).thenReturn(service);
        Response response = tracfoneOneZip2TechResource.getColumn(tfZip2Tech, "STATE");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[\"DUMMY_DATA1\",\"DUMMY_DATA2\"]", response.getEntity().toString());
    }

    @Test
    public void testGetColumn_whenException() throws TracfoneOneException {
        TracfoneOneZip2Tech tfZip2Tech = new TracfoneOneZip2Tech();
        tfZip2Tech.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechController).getZip2TechColumnValues(anyString(), anyString());
        Response response = tracfoneOneZip2TechResource.getColumn(tfZip2Tech, "STATE");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetAllParentNames() throws TracfoneOneException {
        List<TFOneParent> allParents = new ArrayList<>();
        TFOneParent tFOneParent = new TFOneParent();
        tFOneParent.setObjId("1000");
        allParents.add(tFOneParent);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv("DBENV");
        when(tracfoneRatePlanController.getAllParentNames(any(), any())).thenReturn(allParents);
        Response response = tracfoneOneZip2TechResource.getAllParentNames(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"objId\":\"1000\",\"xParentName\":null,\"parentId\":null,\"status\":null,\"holdAnalogDeac\":null,\"holdDigitalDeac\":null,\"parent2TempQueue\":null,\"noInventory\":null,\"vmAccessNum\":null,\"autoPortIn\":null,\"autoPortOut\":null,\"noMsid\":null,\"otaCarrier\":null,\"otaEndDate\":null,\"otaPsmsAddress\":null,\"otaStartDate\":null,\"nextAvailable\":null,\"queueName\":null,\"blockPortIn\":null,\"meidCarrier\":null,\"otaReact\":null,\"aggCarrCode\":null,\"suiRuleObjId\":null,\"deactSimExpDays\":null,\"overrideSmsAddress\":null,\"triggerId\":null,\"parentShortName\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetAllParentNames_whenException() throws TracfoneOneException {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneRatePlanController).getAllParentNames(any(), any());
        Response response = tracfoneOneZip2TechResource.getAllParentNames(tracfoneOneSearchPlanModel);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testSearchBPTech() throws TracfoneOneException {
        List<TFOneBPTech> bpTechs = new ArrayList<>();
        TFOneBPTech bpTech = new TFOneBPTech();
        bpTech.setProductKey("PRODUCT_KEY");
        bpTech.setTechkey("TECHKEY");
        bpTech.setBpCode("BPCODE");
        bpTech.setService("SERVICE");
        bpTechs.add(bpTech);

        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setBpCode("BPCODE");
        tfBPTech.setService("SERVICE");
        tfBPTech.setDbEnv("DBENV");
        when(tracfoneOneZip2TechController.searchBPTech(any())).thenReturn(bpTechs);
        Response response = tracfoneOneZip2TechResource.searchBPTech(tfBPTech);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"techkey\":\"TECHKEY\",\"service\":\"SERVICE\",\"bpCode\":\"BPCODE\",\"productKey\":\"PRODUCT_KEY\"}]", response.getEntity().toString());
    }

    @Test
    public void testSearchBPTech_whenException() throws TracfoneOneException {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechController).searchBPTech(any());
        Response response = tracfoneOneZip2TechResource.searchBPTech(tfBPTech);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetBPTechColumn() throws TracfoneOneException {
        List<String> columnValue = new ArrayList<>();
        columnValue.add("DUMMY_DATA1");
        columnValue.add("DUMMY_DATA2");

        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setDbEnv("DBENV");
        when(tracfoneOneZip2TechController.getBPTechColumn(anyString(), anyString())).thenReturn(columnValue);
        Response response = tracfoneOneZip2TechResource.getBPTechColumn(tfBPTech, "BP_TECH_COLUMN");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[\"DUMMY_DATA1\",\"DUMMY_DATA2\"]", response.getEntity().toString());
    }

    @Test
    public void testGetBPTechColumn_whenException() throws TracfoneOneException {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechController).getBPTechColumn(anyString(), anyString());
        Response response = tracfoneOneZip2TechResource.getBPTechColumn(tfBPTech, "BP_TECH_COLUMN");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testUpdateBPTechs() throws TracfoneOneException {
        List<TracfoneOneBPTech> tfBPTechs = new ArrayList<>();
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setBpCode("BPCODE");
        tfBPTech.setService("SERVICE");
        tfBPTech.setDbEnv("DBENV");
        tfBPTechs.add(tfBPTech);
        when(tracfoneOneZip2TechController.updateBPTechs(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneZip2TechResource.updateBPTechs(tfBPTechs);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testUpdateBPTechs_whenException() throws TracfoneOneException {
        List<TracfoneOneBPTech> tfBPTechs = new ArrayList<>();
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setBpCode("BPCODE");
        tfBPTech.setService("SERVICE");
        tfBPTech.setDbEnv("DBENV");
        tfBPTechs.add(tfBPTech);
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechController).updateBPTechs(any(), anyInt());
        Response response = tracfoneOneZip2TechResource.updateBPTechs(tfBPTechs);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testDeleteZip2Techs() throws TracfoneOneException {
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setService("SERVICE");
        zip2Tech.setLanguage("LANGUAGE");
        zip2Tech.setTechkey("TECHKEY");
        when(tracfoneOneZip2TechController.deleteZip2Techs(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneZip2TechResource.deleteZip2Techs(zip2Tech);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteZip2Techs_whenException() throws TracfoneOneException {
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechController).deleteZip2Techs(any(), anyInt());
        Response response = tracfoneOneZip2TechResource.deleteZip2Techs(zip2Tech);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertErrorRecordDetails() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        TFOneBulkInsertReport report = new TFOneBulkInsertReport();
        report.setErrorCount("3");
        report.setSuccessCount("2");
        report.setSuccessCount("5");
        report.setStatus("COMPLETE");
        summary.add(report);

        when(tracfoneControllerAction.getErrorRecordDetails(any())).thenReturn(summary);
        Response response = tracfoneOneZip2TechResource.getBulkInsertErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":null,\"successCount\":\"5\",\"errorCount\":\"3\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertErrorRecordDetails_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getErrorRecordDetails(any());
        Response response = tracfoneOneZip2TechResource.getBulkInsertErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertZip2TechSummary() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        TFOneBulkInsertReport report = new TFOneBulkInsertReport();
        report.setErrorCount("3");
        report.setSuccessCount("2");
        report.setSuccessCount("5");
        report.setStatus("COMPLETE");
        summary.add(report);

        when(tracfoneControllerAction.getBulkInsertSummary(anyString(), anyString(), anyInt())).thenReturn(summary);
        Response response = tracfoneOneZip2TechResource.getBulkInsertZip2TechSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":null,\"successCount\":\"5\",\"errorCount\":\"3\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertZip2TechSummary_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(anyString(), anyString(), anyInt());
        Response response = tracfoneOneZip2TechResource.getBulkInsertZip2TechSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertBpTech() throws TracfoneOneException {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setDbEnv("DB");
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setBpCode("BP_CODE");
        tfBPTech.setService("SERVICE");
        when(tracfoneOneZip2TechController.insertBpTech(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneZip2TechResource.insertBpTech(tfBPTech);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testInsertBpTech_whenException() throws TracfoneOneException {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setDbEnv("DB");
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechController).insertBpTech(any(), anyInt());
        Response response = tracfoneOneZip2TechResource.insertBpTech(tfBPTech);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testDeleteBpTech() throws TracfoneOneException {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setDbEnv("DB");
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setBpCode("BP_CODE");
        tfBPTech.setService("SERVICE");
        when(tracfoneOneZip2TechController.deleteBpTech(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        Response response = tracfoneOneZip2TechResource.deleteBpTech(tfBPTech);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"status\":\"200\",\"message\":\"new_id\"}", response.getEntity().toString());
    }

    @Test
    public void testDeleteBpTech_whenException() throws TracfoneOneException {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setDbEnv("DB");
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechController).deleteBpTech(any(), anyInt());
        Response response = tracfoneOneZip2TechResource.deleteBpTech(tfBPTech);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertBpTechErrorRecordDetails() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        TFOneBulkInsertReport report = new TFOneBulkInsertReport();
        report.setErrorCount("3");
        report.setSuccessCount("2");
        report.setSuccessCount("5");
        report.setStatus("COMPLETE");
        summary.add(report);

        when(tracfoneControllerAction.getErrorRecordDetails(any())).thenReturn(summary);
        Response response = tracfoneOneZip2TechResource.getBulkInsertBpTechErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":null,\"successCount\":\"5\",\"errorCount\":\"3\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertBpTechErrorRecordDetails_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getErrorRecordDetails(any());
        Response response = tracfoneOneZip2TechResource.getBulkInsertBpTechErrorRecordDetails(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertBpTechSummary() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        TFOneBulkInsertReport report = new TFOneBulkInsertReport();
        report.setErrorCount("3");
        report.setSuccessCount("2");
        report.setSuccessCount("5");
        report.setStatus("COMPLETE");
        summary.add(report);

        when(tracfoneControllerAction.getBulkInsertSummary(anyString(), anyString(), anyInt())).thenReturn(summary);
        Response response = tracfoneOneZip2TechResource.getBulkInsertBpTechSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"id\":null,\"createDate\":null,\"status\":\"COMPLETE\",\"totalRecord\":null,\"successCount\":\"5\",\"errorCount\":\"3\",\"details\":null,\"uniqueIdentifier\":null}]", response.getEntity().toString());
    }

    @Test
    public void testGetBulkInsertBpTechSummary_whenException() throws TracfoneOneException {
        TracfoneOneUserHistory tracfoneOneUserHistory = new TracfoneOneUserHistory();
        tracfoneOneUserHistory.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneControllerAction).getBulkInsertSummary(anyString(), anyString(), anyInt());
        Response response = tracfoneOneZip2TechResource.getBulkInsertBpTechSummary(tracfoneOneUserHistory);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"ERR\":\"TFE0-dummy_error_message\"}", response.getEntity().toString());
    }
}