package com.tracfone.service;

import com.tracfone.service.controller.TracfoneOneIGCarrierConfigControllerLocal;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfig;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGCarrierConfig;
import com.tracfone.service.model.response.TFOneIGCarrierConfigDetails;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import org.mockito.junit.MockitoJUnitRunner;

/**
 *
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneIGCarrierConfigViewResourceTest {

    public final String JSON = "application/json";
    public final String DBENV = "dbEnv";
    private TracfoneOneException tracfoneOneException;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneAuthorizationException tracfoneOneAuthorizationException;

    @InjectMocks
    private TracfoneOneIGCarrierConfigViewResource carrierConfigResource;

    @Mock
    private TracfoneOneIGCarrierConfigControllerLocal controllerLocal;

    @Mock
    private SecurityContext securityContext;
    @Mock
    private TracfoneOnePrincipal principal;
    @Mock
    private TFOneAdminUser user;

    @Before
    public void setUp() {
        initMocks(this);
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
    }

    @Test
    public void testGetCarriers() throws TracfoneOneException {
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setDbEnv(DBENV);
        List<String> carrierData = new ArrayList<>();
        carrierData.add("TMOBILE");
        carrierData.add("VERIZON");
        when(controllerLocal.getCarriers(any())).thenReturn(carrierData);
        Response response = carrierConfigResource.getCarriers(carrierConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[\"TMOBILE\",\"VERIZON\"]", response.getEntity().toString());
    }

    @Test
    public void testGetCarriers_whenException() throws TracfoneOneException {
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(controllerLocal).getCarriers(any());
        Response response = carrierConfigResource.getCarriers(carrierConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierConfigs() throws TracfoneOneException {
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setDbEnv(DBENV);
        carrierConfig.setCarrier("TMOBILE");
        List<TFOneIGCarrierConfig> carrierConfigs = new ArrayList<>();
        TFOneIGCarrierConfig config = new TFOneIGCarrierConfig();
        TFOneIGCarrierConfigDetails carrierDetails = new TFOneIGCarrierConfigDetails();
        config.setCarrier("TMOBILE");
        config.setConfigId("21212");
        config.setPropName("TEST");
        config.setPropType("STRING");
        carrierDetails.setConfigId("21212");
        carrierDetails.setPropKey("123");
        carrierDetails.setPropValue("TESTING");
        config.setCarrierDetails(carrierDetails);
        carrierConfigs.add(config);
        when(controllerLocal.getCarrierConfig(any())).thenReturn(carrierConfigs);
        Response response = carrierConfigResource.getCarrierConfig(carrierConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("[{\"configId\":\"21212\",\"carrier\":\"TMOBILE\",\"propName\":\"TEST\",\"propType\":\"STRING\",\"description\":null,\"carrierDetails\":{\"configId\":\"21212\",\"propKey\":\"123\",\"propValueType\":null,\"propValue\":\"TESTING\",\"propValueKey\":null,\"propValueKeyType\":null,\"propValueKeyKey\":null,\"remarks\":null}}]", response.getEntity().toString());
    }

    @Test
    public void testGetCarrierConfigs_whenException() throws TracfoneOneException {
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(controllerLocal).getCarrierConfig(any());
        Response response = carrierConfigResource.getCarrierConfig(carrierConfig);
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }
}
