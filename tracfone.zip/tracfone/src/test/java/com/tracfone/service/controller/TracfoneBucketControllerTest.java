package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneBucket;
import com.tracfone.service.model.request.TracfoneOneBucketList;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucketTier;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildTier;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.response.TFOneBucket;
import com.tracfone.service.model.response.TFOneBucketList;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileBucketTier;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildTier;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneRatePlan;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_BUCKET_LIST_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_BUCKET_LIST_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_CP_BUCKET_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_CP_BUCKET_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_CP_CHILD_BUCKET_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_CP_CHILD_BUCKET_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_IG_BUCKET_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_IG_BUCKET_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_RATE_PLAN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_RATE_PLAN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_COPY_BUCKETS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_COPY_BUCKETS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_ALL_BUCKETS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_ALL_BUCKETS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_BUCKET_LIST_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_BUCKET_LIST_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CP_BUCKET_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CP_BUCKET_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CP_BUCKET_TIER_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CP_BUCKET_TIER_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CP_CHILD_BUCKET_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CP_CHILD_BUCKET_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CP_CHILD_BUCKET_TIER_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CP_CHILD_BUCKET_TIER_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_IG_BUCKET_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_IG_BUCKET_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_BUCKETS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_BUCKETS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_BUCKET_DETAILS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_BUCKET_DETAILS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_BUCKET_LIST_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_BUCKET_LIST_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CP_BUCKETS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CP_BUCKETS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_IG_BUCKETS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_IG_BUCKETS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_BUCKET_LIST_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_BUCKET_LIST_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CP_BUCKET_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CP_BUCKET_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CP_BUCKET_TIER_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CP_BUCKET_TIER_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CP_CHILD_BUCKET_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CP_CHILD_BUCKET_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CP_CHILD_BUCKET_TIER_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CP_CHILD_BUCKET_TIER_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_IG_BUCKET_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_IG_BUCKET_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_PROFILE_ON_BUCKETS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_PROFILE_ON_BUCKETS_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Testing the services that are associated with TracfoneBucketController.
 *
 * @author Pritesh Singh
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneBucketControllerTest {

    private static final String DBENV = "DBENV";
    private static final String ACTIVE_FLAG = "Y";
    private static final String BUCKET_ID = "1000";
    private static final String OLD_BUCKET_ID = "122";
    private static final String SAMPLE = "SAMPLE";
    @InjectMocks
    private TracfoneBucketController tracfoneBucketController;
    @Mock
    private TracfoneBucketLocalAction tracfoneBucketAction;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TFOneGeneralResponse tFOneGeneralResponseForCF;
    private TracfoneOneException tracfoneOneException;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", BUCKET_ID);
        List<String> ids = new ArrayList<>();
        ids.add("1000");
        ids.add("1001");
        tFOneGeneralResponseForCF = new TFOneGeneralResponse("200", ids.toString());
        tracfoneOneException = new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
    }

    @Test
    public void testInsertLegacyBucket() throws Exception {
        List<TracfoneOneBucket> tfBuckets = new ArrayList<>();
        TracfoneOneBucket tracfoneOneBucket = new TracfoneOneBucket();
        tracfoneOneBucket.setDbEnv(DBENV);
        tracfoneOneBucket.setBucketId(BUCKET_ID);
        tracfoneOneBucket.setRatePlan("RATE_PLAN");
        tracfoneOneBucket.setActiveFlag(ACTIVE_FLAG);
        tfBuckets.add(tracfoneOneBucket);
        when(tracfoneBucketAction.insertLegacyBucket(anyList(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.insertLegacyBucket(tfBuckets, "PARENT_SHORT_NAME", 100);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneBucket.getBucketId());
    }

    @Test
    public void testInsertLegacyBucket_whenException() throws Exception {
        List<TracfoneOneBucket> tfBuckets = new ArrayList<>();
        // In case a null object is passed
        try {
            tracfoneBucketController.insertLegacyBucket(tfBuckets, "PARENT_SHORT_NAME", 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_IG_BUCKET_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_IG_BUCKET_ERROR_MESSAGE, e.getErrorMessage());
        }

        //In case the DBENV property was not set on the object
        tfBuckets = new ArrayList<>();
        TracfoneOneBucket tracfoneOneBucket = new TracfoneOneBucket();
        tracfoneOneBucket.setBucketId(BUCKET_ID);
        tfBuckets.add(tracfoneOneBucket);
        doThrow(tracfoneOneException).when(tracfoneBucketAction).insertLegacyBucket(anyList(), anyInt());
        try {
            tracfoneBucketController.insertLegacyBucket(tfBuckets, "PARENT_SHORT_NAME", 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_IG_BUCKET_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_IG_BUCKET_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateIgBucket() throws Exception {
        TracfoneOneBucket tracfoneOneBucket = new TracfoneOneBucket();
        tracfoneOneBucket.setDbEnv(DBENV);
        tracfoneOneBucket.setActiveFlag(ACTIVE_FLAG);
        tracfoneOneBucket.setBucketId(BUCKET_ID);
        when(tracfoneBucketAction.updateIgBucket(any(TracfoneOneBucket.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.updateIgBucket(tracfoneOneBucket, 100);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneBucket.getBucketId());
    }

    @Test
    public void testUpdateIgBucket_whenException() throws Exception {
        TracfoneOneBucket tracfoneOneBucket = new TracfoneOneBucket();
        // Did not set the DBENV property
        tracfoneOneBucket.setActiveFlag(ACTIVE_FLAG);
        tracfoneOneBucket.setBucketId(BUCKET_ID);
        try {
            tracfoneBucketController.updateIgBucket(tracfoneOneBucket, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_IG_BUCKET_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_IG_BUCKET_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllBucketList() throws Exception {
        List<TracfoneOneBucketList> tracfoneOneBucketLists = new ArrayList<>();
        TracfoneOneBucketList tracfoneOneBucket = new TracfoneOneBucketList();
        tracfoneOneBucket.setDbEnv(DBENV);
        tracfoneOneBucket.setActiveFlag(ACTIVE_FLAG);
        tracfoneOneBucket.setBucketId(BUCKET_ID);
        tracfoneOneBucketLists.add(tracfoneOneBucket);
        when(tracfoneBucketAction.getAllBucketList(any(String.class))).thenReturn(tracfoneOneBucketLists);
        List<TracfoneOneBucketList> response = tracfoneBucketController.getAllBucketList(DBENV);
        assertEquals(response.size(), tracfoneOneBucketLists.size());
        assertEquals(response.get(0).getDbEnv(), tracfoneOneBucketLists.get(0).getDbEnv());
    }

    @Test
    public void testGetAllBucketList_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneBucketAction).getAllBucketList(any(String.class));
        try {
            tracfoneBucketController.getAllBucketList(DBENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_BUCKETS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_BUCKETS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierProfileBucket() throws Exception {
        TracfoneOneCarrierProfileBucket carrierProfileBucket = new TracfoneOneCarrierProfileBucket();
        carrierProfileBucket.setBucketId(BUCKET_ID);
        when(tracfoneBucketAction.updateCarrierProfileBucket(any(TracfoneOneCarrierProfileBucket.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.updateCarrierProfileBucket(carrierProfileBucket, 100);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), carrierProfileBucket.getBucketId());
    }

    @Test
    public void testUpdateCarrierProfileBucket_whenException() throws Exception {
        TracfoneOneCarrierProfileBucket carrierProfileBucket = new TracfoneOneCarrierProfileBucket();
        carrierProfileBucket.setBucketId(BUCKET_ID);
        doThrow(tracfoneOneException).when(tracfoneBucketAction).updateCarrierProfileBucket(any(TracfoneOneCarrierProfileBucket.class), anyInt());
        try {
            tracfoneBucketController.updateCarrierProfileBucket(carrierProfileBucket, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CP_BUCKET_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CP_BUCKET_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierProfileBucketTier() throws Exception {
        TracfoneOneCarrierProfileBucketTier carrierProfileBucket = new TracfoneOneCarrierProfileBucketTier();
        carrierProfileBucket.setDbEnv(BUCKET_ID);
        when(tracfoneBucketAction.updateCarrierProfileBucketTier(any(TracfoneOneCarrierProfileBucketTier.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.updateCarrierProfileBucketTier(carrierProfileBucket, 100);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), carrierProfileBucket.getDbEnv());
    }

    @Test
    public void testUpdateCarrierProfileBucketTier_whenException() throws Exception {
        TracfoneOneCarrierProfileBucketTier carrierProfileBucket = new TracfoneOneCarrierProfileBucketTier();
        carrierProfileBucket.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneBucketAction).updateCarrierProfileBucketTier(any(TracfoneOneCarrierProfileBucketTier.class), anyInt());
        try {
            tracfoneBucketController.updateCarrierProfileBucketTier(carrierProfileBucket, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CP_BUCKET_TIER_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CP_BUCKET_TIER_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchIgBuckets() throws Exception {
        List<TFOneBucket> tfOneBucketList = new ArrayList<>();
        TFOneBucket tfOneBucket = new TFOneBucket();
        tfOneBucket.setBucketId(BUCKET_ID);
        tfOneBucket.setActiveFlag(ACTIVE_FLAG);
        tfOneBucketList.add(tfOneBucket);
        TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        when(tracfoneBucketAction.searchIgBuckets(any(TracfoneOneSearchBucketModel.class))).thenReturn(tfOneBucketList);
        List<TFOneBucket> tfOneBucketLists = tracfoneBucketController.searchIgBuckets(tracfoneOneSearchBucketModel);
        assertEquals(tfOneBucketLists.size(), tfOneBucketList.size());
        assertEquals(tfOneBucketLists.get(0).getBucketId(), tfOneBucketList.get(0).getBucketId());
        assertEquals(tfOneBucketLists.get(0).getActiveFlag(), tfOneBucketList.get(0).getActiveFlag());
    }

    @Test
    public void testSearchIgBuckets_whenException() throws Exception {
        TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        doThrow(tracfoneOneException).when(tracfoneBucketAction).searchIgBuckets(any(TracfoneOneSearchBucketModel.class));
        try {
            tracfoneBucketController.searchIgBuckets(tracfoneOneSearchBucketModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_IG_BUCKETS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_IG_BUCKETS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierProfileBuckets() throws Exception {
        List<TFOneCarrierProfileBucket> tfOneCarrierProfileBuckets = new ArrayList<>();
        TFOneCarrierProfileBucket tfOneBucket = new TFOneCarrierProfileBucket();
        tfOneBucket.setBucketId(BUCKET_ID);
        tfOneBucket.setActiveFlag(ACTIVE_FLAG);
        tfOneCarrierProfileBuckets.add(tfOneBucket);
        TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        when(tracfoneBucketAction.searchCarrierProfileBuckets(any(TracfoneOneSearchBucketModel.class))).thenReturn(tfOneCarrierProfileBuckets);
        List<TFOneCarrierProfileBucket> tfOneBucketLists = tracfoneBucketController.searchCarrierProfileBuckets(tracfoneOneSearchBucketModel);
        assertEquals(tfOneBucketLists.size(), tfOneCarrierProfileBuckets.size());
        assertEquals(tfOneBucketLists.get(0).getBucketId(), tfOneBucketLists.get(0).getBucketId());
        assertEquals(tfOneBucketLists.get(0).getActiveFlag(), tfOneBucketLists.get(0).getActiveFlag());
    }

    @Test
    public void testSearchCarrierProfileBuckets_whenException() throws Exception {
        TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        doThrow(tracfoneOneException).when(tracfoneBucketAction).searchCarrierProfileBuckets(any(TracfoneOneSearchBucketModel.class));
        try {
            tracfoneBucketController.searchCarrierProfileBuckets(tracfoneOneSearchBucketModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_CP_BUCKETS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_CP_BUCKETS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteIgBucket() throws TracfoneOneException {
        TracfoneOneBucket oneBucket = new TracfoneOneBucket();
        oneBucket.setDbEnv(DBENV);
        oneBucket.setBucketId(BUCKET_ID);
        oneBucket.setActiveFlag(ACTIVE_FLAG);
        when(tracfoneBucketAction.deleteIgBucket(any(), any(), anyList(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.deleteIgBucket(oneBucket, 1000);
        assertEquals(response.getStatus(), "Success");
        assertEquals(response.getMessage(), BUCKET_ID);
    }

    @Test
    public void testDeleteIgBucket_whenException() throws Exception {
        TracfoneOneBucket oneBucket = new TracfoneOneBucket();
        oneBucket.setBucketId(BUCKET_ID);
        oneBucket.setActiveFlag(ACTIVE_FLAG);
        try {
            tracfoneBucketController.deleteIgBucket(oneBucket, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_IG_BUCKET_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_IG_BUCKET_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierProfileBucket() throws Exception {
        List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileBucket tfCarrierProfileBucket = new TracfoneOneCarrierProfileBucket();
        tfCarrierProfileBucket.setObjectId("1000");
        tfCarrierProfileBucket.setDbEnv(DBENV);
        tfCarrierProfileBuckets.add(tfCarrierProfileBucket);
        when(tracfoneBucketAction.deleteCarrierProfileBuckets(any(), anyList(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.deleteCarrierProfileBucket(tfCarrierProfileBuckets, 1000);
        assertEquals(response.getStatus(), "Success");
        assertEquals(response.getMessage(), BUCKET_ID);
    }

    @Test
    public void testDeleteCarrierProfileBucket_whenException() throws Exception {
        List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets = new ArrayList<>();
        try {
            tracfoneBucketController.deleteCarrierProfileBucket(tfCarrierProfileBuckets, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_CP_BUCKET_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_CP_BUCKET_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierProfileBucketTier() throws Exception {
        TracfoneOneCarrierProfileBucketTier tracfoneOneCarrierProfileBucketTier = new TracfoneOneCarrierProfileBucketTier();
        tracfoneOneCarrierProfileBucketTier.setDbEnv(DBENV);
        tracfoneOneCarrierProfileBucketTier.setTierDescription(SAMPLE);
        when(tracfoneBucketAction.deleteCarrierProfileBucketTier(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.deleteCarrierProfileBucketTier(tracfoneOneCarrierProfileBucketTier, 1000);
        assertEquals(response.getStatus(), "Success");
        assertEquals(response.getMessage(), BUCKET_ID);
    }

    @Test
    public void testDeleteCarrierProfileBucketTier_whenException() throws Exception {
        TracfoneOneCarrierProfileBucketTier tracfoneOneCarrierProfileBucketTier = new TracfoneOneCarrierProfileBucketTier();
        tracfoneOneCarrierProfileBucketTier.setDbEnv(DBENV);
        tracfoneOneCarrierProfileBucketTier.setTierDescription(SAMPLE);
        doThrow(tracfoneOneException).when(tracfoneBucketAction).deleteCarrierProfileBucketTier(any(), anyInt());
        try {
            tracfoneBucketController.deleteCarrierProfileBucketTier(tracfoneOneCarrierProfileBucketTier, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_CP_BUCKET_TIER_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_CP_BUCKET_TIER_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierProfileChildBuckets() throws Exception {
        List<TFOneCarrierProfileChildBucket> tfOneCarrierProfileChildBucketList = new ArrayList<>();
        TFOneCarrierProfileChildBucket tfOneCarrierProfileChildBucket = new TFOneCarrierProfileChildBucket();
        tfOneCarrierProfileChildBucket.setActiveFlag(ACTIVE_FLAG);
        tfOneCarrierProfileChildBucket.setBucketId(BUCKET_ID);
        tfOneCarrierProfileChildBucketList.add(tfOneCarrierProfileChildBucket);
        TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tracfoneOneSearchBucketModel.setDbEnv(DBENV);
        when(tracfoneBucketAction.searchCarrierProfileChildBuckets(any(TracfoneOneSearchBucketModel.class))).thenReturn(tfOneCarrierProfileChildBucketList);
        List<TFOneCarrierProfileChildBucket> response = tracfoneBucketController.searchCarrierProfileChildBuckets(tracfoneOneSearchBucketModel);
        assertEquals(tfOneCarrierProfileChildBucketList.size(), response.size());
        assertEquals(tfOneCarrierProfileChildBucketList.get(0).getBucketId(), response.get(0).getBucketId());
        assertEquals(tfOneCarrierProfileChildBucketList.get(0).getActiveFlag(), response.get(0).getActiveFlag());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets_whenException() throws Exception {
        TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tracfoneOneSearchBucketModel.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneBucketAction).searchCarrierProfileChildBuckets(any(TracfoneOneSearchBucketModel.class));
        try {
            tracfoneBucketController.searchCarrierProfileChildBuckets(tracfoneOneSearchBucketModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierProfileChildBucket() throws Exception {
        TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket = new TracfoneOneCarrierProfileChildBucket();
        tfCarrierProfileChildBucket.setActiveFlag("Y");
        tfCarrierProfileChildBucket.setAutoRenewFlag("Y");
        tfCarrierProfileChildBucket.setObjId("1000");
        tfCarrierProfileChildBucket.setDbEnv(DBENV);
        when(tracfoneBucketAction.updateCarrierProfileChildBucket(any(TracfoneOneCarrierProfileChildBucket.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.updateCarrierProfileChildBucket(tfCarrierProfileChildBucket, 100);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfCarrierProfileChildBucket.getObjId());
    }

    @Test
    public void testUpdateCarrierProfileChildBucket_whenException() throws Exception {
        TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket = new TracfoneOneCarrierProfileChildBucket();
        tfCarrierProfileChildBucket.setActiveFlag("Y");
        tfCarrierProfileChildBucket.setAutoRenewFlag("Y");
        tfCarrierProfileChildBucket.setObjId("new_id");
        try {
            tracfoneBucketController.updateCarrierProfileChildBucket(tfCarrierProfileChildBucket, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CP_CHILD_BUCKET_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CP_CHILD_BUCKET_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierProfileChildBucket() throws Exception {
        List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket = new TracfoneOneCarrierProfileChildBucket();
        tfCarrierProfileChildBucket.setObjId("1000");
        tfCarrierProfileChildBucket.setDbEnv(DBENV);
        tfCarrierProfileChildBuckets.add(tfCarrierProfileChildBucket);
        when(tracfoneBucketAction.deleteCarrierProfileChildBuckets(any(), anyList(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.deleteCarrierProfileChildBucket(tfCarrierProfileChildBuckets, 1000);
        assertEquals(response.getStatus(), "Success");
        assertEquals(response.getMessage(), "1000");
    }

    @Test
    public void testDeleteCarrierProfileChildBucket_whenException() {
        List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets = new ArrayList<>();
        try {
            tracfoneBucketController.deleteCarrierProfileChildBucket(tfCarrierProfileChildBuckets, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_CP_CHILD_BUCKET_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_CP_CHILD_BUCKET_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierProfileChildBucket() throws Exception {
        List<TFOneCarrierProfileChildBucket> tfOneChildBuckets = new ArrayList<>();
        TFOneCarrierProfileChildBucket tfOneCarrierProfileChildBucket = new TFOneCarrierProfileChildBucket();
        tfOneCarrierProfileChildBucket.setActiveFlag("Y");
        tfOneCarrierProfileChildBucket.setAutoRenewFlag("Y");
        tfOneCarrierProfileChildBucket.setObjId("1000");
        tfOneChildBuckets.add(tfOneCarrierProfileChildBucket);
        List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket = new TracfoneOneCarrierProfileChildBucket();
        tfCarrierProfileChildBucket.setActiveFlag("Y");
        tfCarrierProfileChildBucket.setAutoRenewFlag("Y");
        tfCarrierProfileChildBucket.setObjId("1000");
        tfCarrierProfileChildBuckets.add(tfCarrierProfileChildBucket);

        when(tracfoneBucketAction.insertCarrierProfileChildBuckets(any(), anyInt())).thenReturn(tfOneChildBuckets);
        List<TFOneCarrierProfileChildBucket> response = tracfoneBucketController.insertCarrierProfileChildBucket(tfCarrierProfileChildBuckets, "PARENT_SHORT_NAME", 100);
        assertEquals("[TFOneCarrierProfileChildBucket{objId=1000, profileId=null, servicePlanId=null, childPlanId=null, bucketId=null, activeFlag=Y, unitOfMeasure=null, bucketType=null, bucketGroup=null, bucketRequirement=null, autoRenewFlag=Y, autoRenewFrequency=null, autoRenewValue=null, autoRenewDay=null, benefitType=null, bucketValue=null, priority=null, hideUbiFlag=null, tfOneCarrierProfileChildTiers=[]}]", response.toString());
    }

    @Test
    public void testInsertCarrierProfileChildBucket_whenException() throws Exception {
        List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets = new ArrayList<>();
        try {
            tracfoneBucketController.insertCarrierProfileChildBucket(tfCarrierProfileChildBuckets, "PARENT_SHORT_NAME", 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_CP_CHILD_BUCKET_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_CP_CHILD_BUCKET_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierProfileBucket() throws Exception {
        List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileBucket tfCarrierProfileBucket = new TracfoneOneCarrierProfileBucket();
        tfCarrierProfileBucket.setActiveFlag("Y");
        tfCarrierProfileBucket.setAutoRenewFlag("Y");
        tfCarrierProfileBucket.setObjectId("1000");
        tfCarrierProfileBucket.setDbEnv(DBENV);
        tfCarrierProfileBuckets.add(tfCarrierProfileBucket);

        tfCarrierProfileBuckets.add(tfCarrierProfileBucket);
        List<TFOneCarrierProfileBucket> tfOneBuckets = new ArrayList<>();
        TFOneCarrierProfileBucket tfOneCarrierProfileBucket = new TFOneCarrierProfileBucket();
        tfOneCarrierProfileBucket.setAutoRenewFlag("Y");
        tfOneCarrierProfileBucket.setActiveFlag("Y");
        tfOneCarrierProfileBucket.setObjid("1000");
        tfOneBuckets.add(tfOneCarrierProfileBucket);

        when(tracfoneBucketAction.insertCarrierProfileBuckets(any(), anyInt())).thenReturn(tfOneBuckets);
        List<TFOneCarrierProfileBucket> response = tracfoneBucketController.insertCarrierProfileBucket(tfCarrierProfileBuckets, "PARENT_SHORT_NAME", 100);
        assertEquals("[TFOneCarrierProfileBucket{objid=1000, profileId=null, bucketId=null, servicePlanId=null, activeFlag=Y, unitOfMeasure=null, bucketType=null, bucketGroup=null, bucketRequirement=null, autoRenewFlag=Y,autoRenewFrequency=null, autoRenewValue=null, autoRenewDay=null, benefitType=null, bucketValue=null, suiDisplayType=null, priority=null, hideUbiFlag=null, tfOneCarrierProfileBucketTiers=null}]", response.toString());
    }

    @Test
    public void testInsertCarrierProfileBucket_whenException() throws Exception {
        List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets = new ArrayList<>();
        try {
            tracfoneBucketController.insertCarrierProfileBucket(tfCarrierProfileBuckets, null, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_CP_BUCKET_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_CP_BUCKET_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierProfileChildBucketTier() throws Exception {
        TracfoneOneCarrierProfileChildTier tfCarrierProfileChildBucketTier = new TracfoneOneCarrierProfileChildTier();
        tfCarrierProfileChildBucketTier.setDbEnv(DBENV);
        tfCarrierProfileChildBucketTier.setObjId("1000");
        tfCarrierProfileChildBucketTier.setUsageTierId("10");
        when(tracfoneBucketAction.updateCarrierProfileChildBucketTier(any(TracfoneOneCarrierProfileChildTier.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.updateCarrierProfileChildBucketTier(tfCarrierProfileChildBucketTier, 100);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfCarrierProfileChildBucketTier.getObjId());
    }

    @Test
    public void testUpdateCarrierProfileChildBucketTier_whenException() {
        TracfoneOneCarrierProfileChildTier tfCarrierProfileChildBucketTier = new TracfoneOneCarrierProfileChildTier();
        try {
            tracfoneBucketController.updateCarrierProfileChildBucketTier(tfCarrierProfileChildBucketTier, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CP_CHILD_BUCKET_TIER_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CP_CHILD_BUCKET_TIER_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierProfileChildBucketTier() throws Exception {
        TracfoneOneCarrierProfileChildTier tfCarrierProfileChildTier = new TracfoneOneCarrierProfileChildTier();
        tfCarrierProfileChildTier.setDbEnv(DBENV);
        tfCarrierProfileChildTier.setObjId("1000");
        when(tracfoneBucketAction.deleteCarrierProfileChildBucketTier(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.deleteCarrierProfileChildBucketTier(tfCarrierProfileChildTier, 1000);
        assertEquals(response.getStatus(), "Success");
        assertEquals(response.getMessage(), tfCarrierProfileChildTier.getObjId());
    }

    @Test
    public void testDeleteCarrierProfileChildBucketTier_whenException() {
        TracfoneOneCarrierProfileChildTier tfCarrierProfileChildTier = new TracfoneOneCarrierProfileChildTier();
        try {
            tracfoneBucketController.deleteCarrierProfileChildBucketTier(tfCarrierProfileChildTier, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_CP_CHILD_BUCKET_TIER_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_CP_CHILD_BUCKET_TIER_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testCopyAllBucketsFromProfile() throws Exception {
        List<String> profileIds = new ArrayList<>();
        profileIds.add("1000");
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add("1000");
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setDbEnv(DBENV);
        tfOneSearchBucketModel.setChildPlanId("100");
        tfOneSearchBucketModel.setProfileIds(profileIds);
        tfOneSearchBucketModel.setServicePlanIds(servicePlanIds);

        List<TFOneCarrierProfileBucketTier> bucketTiers = new ArrayList<>();
        TFOneCarrierProfileBucketTier tier = new TFOneCarrierProfileBucketTier();
        tier.setTierBehavior("TIER_BEHAVIOR1");
        tier.setUsageTierId("90");
        tier.setTierDescription("TIER_DESCRIPTION1");
        tier.setTierValue("80");
        bucketTiers.add(tier);
        tier = new TFOneCarrierProfileBucketTier();
        tier.setTierBehavior("TIER_BEHAVIOR2");
        tier.setUsageTierId("70");
        tier.setTierDescription("TIER_DESCRIPTION2");
        tier.setTierValue("60");
        bucketTiers.add(tier);

        List<TFOneCarrierProfileBucket> buckets = new ArrayList<>();
        TFOneCarrierProfileBucket tfOneBucket = new TFOneCarrierProfileBucket();
        tfOneBucket.setBucketId(BUCKET_ID);
        tfOneBucket.setActiveFlag(ACTIVE_FLAG);
        tfOneBucket.setObjid("1001");
        tfOneBucket.setAutoRenewFlag("Y");
        tfOneBucket.setTfOneCarrierProfileBucketTiers(bucketTiers);
        buckets.add(tfOneBucket);

        List<TFOneCarrierProfileChildTier> ChildBucketTiers = new ArrayList<>();
        TFOneCarrierProfileChildTier ChildBucketTier = new TFOneCarrierProfileChildTier();
        ChildBucketTier.setTierBehavior("TIER_BEHAVIOR1");
        ChildBucketTier.setUsageTierId("90");
        ChildBucketTier.setTierDescription("TIER_DESCRIPTION1");
        ChildBucketTier.setTierValue("80");
        ChildBucketTiers.add(ChildBucketTier);

        List<TFOneCarrierProfileChildBucket> childBuckets = new ArrayList<>();
        TFOneCarrierProfileChildBucket childBucket = new TFOneCarrierProfileChildBucket();
        childBucket.setBucketId(BUCKET_ID);
        childBucket.setActiveFlag(ACTIVE_FLAG);
        childBucket.setObjId("1000");
        childBucket.setAutoRenewFlag("Y");
        childBucket.setTfOneCarrierProfileChildTiers(ChildBucketTiers);
        childBuckets.add(childBucket);

        when(tracfoneBucketAction.searchCarrierProfileBuckets(any())).thenReturn(buckets);
        when(tracfoneBucketAction.searchCarrierProfileChildBuckets(any())).thenReturn(childBuckets);
        TFOneGeneralResponse response = tracfoneBucketController.copyAllBucketsFromProfile(tfOneSearchBucketModel, 1000);
        assertEquals(response.getStatus(), "Success");
        assertEquals("[TFOneCarrierProfileBucket{objid=1001, profileId=null, bucketId=1000, servicePlanId=null, activeFlag=Y, unitOfMeasure=null, bucketType=null, bucketGroup=null, bucketRequirement=null, autoRenewFlag=Y,autoRenewFrequency=null, autoRenewValue=null, autoRenewDay=null, benefitType=null, bucketValue=null, suiDisplayType=null, priority=null, hideUbiFlag=null, tfOneCarrierProfileBucketTiers=[TFOneCarrierProfileBucketTier{objId=null, carrierProfileBucketsObjId=null, usageTierId=90, tierDescription=TIER_DESCRIPTION1, tierValue=80, tierBehavior=TIER_BEHAVIOR1}, TFOneCarrierProfileBucketTier{objId=null, carrierProfileBucketsObjId=null, usageTierId=70, tierDescription=TIER_DESCRIPTION2, tierValue=60, tierBehavior=TIER_BEHAVIOR2}]}]", buckets.toString());
        assertEquals("[TFOneCarrierProfileChildBucket{objId=1000, profileId=null, servicePlanId=null, childPlanId=null, bucketId=1000, activeFlag=Y, unitOfMeasure=null, bucketType=null, bucketGroup=null, bucketRequirement=null, autoRenewFlag=Y, autoRenewFrequency=null, autoRenewValue=null, autoRenewDay=null, benefitType=null, bucketValue=null, priority=null, hideUbiFlag=null, tfOneCarrierProfileChildTiers=[TFOneCarrierProfileChildTier{objId=null, carrierProfileChildObjId=null, usageTierId=90, tierDescription=TIER_DESCRIPTION1, tierValue=80, tierBehavior=TIER_BEHAVIOR1}]}]", childBuckets.toString());
    }

    @Test
    public void testCopyAllBucketsFromProfile_whenException() {
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        try {
            tracfoneBucketController.copyAllBucketsFromProfile(tfOneSearchBucketModel, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_COPY_BUCKETS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_COPY_BUCKETS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteAllBucketsAndTiers() throws Exception {
        List<String> profileIds = new ArrayList<>();
        profileIds.add("1000");
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add("1000");
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setDbEnv(DBENV);
        tfOneSearchBucketModel.setChildPlanId("100");
        tfOneSearchBucketModel.setProfileIds(profileIds);
        tfOneSearchBucketModel.setServicePlanIds(servicePlanIds);
        when(tracfoneBucketAction.deleteAllBucketsAndTiers(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.deleteAllBucketsAndTiers(tfOneSearchBucketModel, 1000);
        assertEquals(response.getStatus(), "Success");
        assertEquals(response.getMessage(), tfOneSearchBucketModel.getProfileIds().get(0));
    }

    @Test
    public void testDeleteAllBucketsAndTiers_whenException() throws Exception {
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setDbEnv(DBENV);
        try {
            tracfoneBucketController.deleteAllBucketsAndTiers(tfOneSearchBucketModel, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_ALL_BUCKETS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_ALL_BUCKETS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateAllBucketsWithProfileId() throws Exception {
        List<String> profileIds = new ArrayList<>();
        profileIds.add("1000");
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add("1000");
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setDbEnv(DBENV);
        tfOneSearchBucketModel.setChildPlanId("100");
        tfOneSearchBucketModel.setProfileIds(profileIds);
        tfOneSearchBucketModel.setServicePlanIds(servicePlanIds);

        when(tracfoneBucketAction.updateAllBucketsWithProfileId(any(TracfoneOneSearchBucketModel.class), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.updateAllBucketsWithProfileId(tfOneSearchBucketModel, 100);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfOneSearchBucketModel.getProfileIds().get(0));
    }

    @Test
    public void testUpdateAllBucketsWithProfileId_whenException() throws Exception {
        List<String> profileIds = new ArrayList<>();
        profileIds.add("1000");
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add("1000");
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setChildPlanId("100");
        tfOneSearchBucketModel.setProfileIds(profileIds);
        tfOneSearchBucketModel.setServicePlanIds(servicePlanIds);

        doThrow(tracfoneOneException).when(tracfoneBucketAction).updateAllBucketsWithProfileId(any(TracfoneOneSearchBucketModel.class), anyInt());
        try {
            tracfoneBucketController.updateAllBucketsWithProfileId(tfOneSearchBucketModel, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_PROFILE_ON_BUCKETS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_PROFILE_ON_BUCKETS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetIgBucketRatePlans() throws Exception {
        List<TFOneRatePlan> tfOneRatePlans = new ArrayList<>();
        TFOneRatePlan tfOneRatePlan = new TFOneRatePlan();
        tfOneRatePlan.setRatePlanName("RATE_PLAN_NAME");
        tfOneRatePlan.setObjId("1000");
        tfOneRatePlans.add(tfOneRatePlan);
        when(tracfoneBucketAction.getIgBucketRatePlans(any(String.class))).thenReturn(tfOneRatePlans);
        List<TFOneRatePlan> response = tracfoneBucketController.getIgBucketRatePlans(DBENV);
        assertEquals(response.size(), tfOneRatePlans.size());
        assertEquals("[TFOneRatePlan{objId=1000, ratePlanName=RATE_PLAN_NAME, privateNetwork=null, espidUpdate=null, espidNum=null, propagateFlagValue=null, allowMformApnRequestFlag=null, calculateDataUnitsFlag=null, thresholdsToTmo=null, hotspotBucketsFlag=null, tmoNextGenFlag=null, ratePlanProfile=[], carrierFeatures=null}]", tfOneRatePlans.toString());
    }

    @Test
    public void testGetIgBucketRatePlans_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneBucketAction).getIgBucketRatePlans(any(String.class));
        try {
            tracfoneBucketController.getIgBucketRatePlans(DBENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_RATE_PLAN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_RATE_PLAN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testInsertBucketList() throws Exception {
        List<TracfoneOneBucketList> tracfoneOneBucketLists = new ArrayList<>();
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDescription("DESCRIPTION");
        tracfoneOneBucketList.setActiveFlag(ACTIVE_FLAG);
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketLists.add(tracfoneOneBucketList);
        TFOneGeneralResponse response = tracfoneBucketController.insertBucketList(tracfoneOneBucketLists, 100);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
    }

    @Test
    public void testInsertBucketList_whenException() throws Exception {
        List<TracfoneOneBucketList> tracfoneOneBucketLists = new ArrayList<>();
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDescription("DESCRIPTION");
        tracfoneOneBucketList.setActiveFlag(ACTIVE_FLAG);
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketLists.add(tracfoneOneBucketList);
        doThrow(tracfoneOneException).when(tracfoneBucketAction).insertBucketList(anyList(), anyInt());
        try {
            tracfoneBucketController.insertBucketList(tracfoneOneBucketLists, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_BUCKET_LIST_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_BUCKET_LIST_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateBucketList() throws Exception {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDescription("DESCRIPTION");
        tracfoneOneBucketList.setActiveFlag(ACTIVE_FLAG);
        tracfoneOneBucketList.setDbEnv(DBENV);
        when(tracfoneBucketAction.updateBucketList(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.updateBucketList(tracfoneOneBucketList, 100);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneBucketList.getBucketId());
    }

    @Test
    public void testUpdateBucketList_whenException() throws Exception {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDescription("DESCRIPTION");
        tracfoneOneBucketList.setActiveFlag(ACTIVE_FLAG);
        tracfoneOneBucketList.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneBucketAction).updateBucketList(any(), anyInt());
        try {
            tracfoneBucketController.updateBucketList(tracfoneOneBucketList, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_BUCKET_LIST_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_BUCKET_LIST_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchBucketList() throws Exception {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDescription("DESCRIPTION");
        tracfoneOneBucketList.setActiveFlag(ACTIVE_FLAG);
        tracfoneOneBucketList.setDbEnv(DBENV);

        List<TFOneBucketList> tfOneBucketLists = new ArrayList<>();
        TFOneBucketList tfOneBucketList = new TFOneBucketList();
        tfOneBucketList.setBucketId("1000");
        tfOneBucketList.setDescription("DESCRIPTION");
        tfOneBucketList.setActiveFlag("Y");
        tfOneBucketLists.add(tfOneBucketList);

        when(tracfoneBucketAction.searchBucketList(any())).thenReturn(tfOneBucketLists);
        List<TFOneBucketList> response = tracfoneBucketController.searchBucketList(tracfoneOneBucketList);
        assertEquals(response.get(0).getBucketId(), tfOneBucketList.getBucketId());
    }

    @Test
    public void testSearchBucketList_whenException() throws Exception {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDescription("DESCRIPTION");
        tracfoneOneBucketList.setActiveFlag(ACTIVE_FLAG);
        tracfoneOneBucketList.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneBucketAction).searchBucketList(any());
        try {
            tracfoneBucketController.searchBucketList(tracfoneOneBucketList);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_BUCKET_LIST_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_BUCKET_LIST_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void deleteBucketListDeleteTrue() throws Exception {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketList.setDelete(true);
        when(tracfoneBucketAction.deleteBucketList(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneBucketController.deleteBucketList(tracfoneOneBucketList, 1000);
        assertEquals(tFOneGeneralResponse.getStatus(), response.getStatus());
        assertEquals(response.getMessage(), tracfoneOneBucketList.getBucketId());
    }

    @Test
    public void testDeleteAncillaryCodeDiscountDeleteFalse() throws Exception {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketList.setDelete(false);
        long totalAssociatedProfiles = 5;
        when(tracfoneBucketAction.checkBucketListDependencies(any())).thenReturn(totalAssociatedProfiles);
        TFOneGeneralResponse response = tracfoneBucketController.deleteBucketList(tracfoneOneBucketList, 1000);
        assertEquals("Success", response.getStatus());
        assertEquals(String.valueOf(totalAssociatedProfiles), response.getMessage());
    }

    @Test
    public void testDeleteAncillaryCodeDiscount_whenException() throws Exception {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setBucketId("1000");
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketList.setDelete(false);
        doThrow(tracfoneOneException).when(tracfoneBucketAction).deleteBucketList(any(), anyInt());
        try {
            tracfoneBucketController.deleteBucketList(tracfoneOneBucketList, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_BUCKET_LIST_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_BUCKET_LIST_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    /**
     Junits forSprint 30
     ***/

    @Test
    public void testGetBucketDetails() throws Exception {
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        tracfoneOneBucketList.setDbEnv(DBENV);
        tracfoneOneBucketList.setBucketId("TEST");
        tracfoneOneBucketList.setParentShortName("TMO");
        tracfoneOneBucketList.setProfileId("100");
        tracfoneOneBucketList.setServicePlanId("100");
        TFOneCarrierProfileBucket tfOneCarrierProfileBucket = new TFOneCarrierProfileBucket();
        tfOneCarrierProfileBucket.setBucketId("TEST");
        tfOneCarrierProfileBucket.setBenefitType("TEST");
        tfOneCarrierProfileBucket.setBucketGroup("TEST");
        tfOneCarrierProfileBucket.setBucketType("TEST");
        when(tracfoneBucketAction.getBucketDetails(any())).thenReturn(tfOneCarrierProfileBucket);
        TFOneCarrierProfileBucket response = tracfoneBucketController.getBucketDetails(tracfoneOneBucketList);
        assertEquals(response.getBucketId(), tfOneCarrierProfileBucket.getBucketId());
    }

    @Test
    public void testGetBucketDetails_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneBucketAction).getBucketDetails(any());
        TracfoneOneBucketList tracfoneOneBucketList = new TracfoneOneBucketList();
        try {
            tracfoneBucketController.getBucketDetails(tracfoneOneBucketList);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_BUCKET_DETAILS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_BUCKET_DETAILS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}