package com.tracfone.service;

import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerReportLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.report.TracfoneAdhocReportRequest;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TracfoneOneReport;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.ws.rs.core.Response;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneReportingResourceTest {

    public final String JSON = "application/json";
    public final String DBENV = "dbEnv";

    private TracfoneOneException tracfoneOneException;
    private TFOneGeneralResponse tFOneGeneralResponse;

    @InjectMocks
    TracfoneOneReportingResource tracfoneOneReportingResource;

    @Mock
    private TracfoneControllerLocal tracfoneController;
    @Mock
    private TracfoneControllerReportLocal tracfoneControllerReport;

    @Before
    public void setUp() {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
    }

    @Test
    public void testStoreMonitorReportGET_IG() throws TracfoneOneException {
        String jsonResponse = "[{\"template\":\"CSI_TLG\",\"orderType\":\"ACT/REACT\",\"xDate\":\"2020-05-11 16:15:00.0\",\"sumAllQ\":\"0\",\"sumAllL\":\"0\",\"sumAllCp\":\"0\",\"sumAllS\":\"1\",\"sumAllWp\":\" 0\",\"sumAllE\":\"0\",\"sumAllC\":\"0\",\"sumAllW\":\"0\",\"sumAllF\":\"0\",\"transType\":\"SYSTEM_AI\",\"sumAllHw\":\"1\"}]";
        when(tracfoneController.getMonitorReport(anyString(), anyString())).thenReturn(jsonResponse);
        Response response = tracfoneOneReportingResource.storeMonitorReportGET("ig");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals(jsonResponse, response.getEntity().toString());
    }

    @Test
    public void testStoreMonitorReportGET_TT() throws TracfoneOneException {
        String jsonResponse = "[{\"carrier\":\"ATT\",\"transNum\":\"39085\",\"xDate\":\"2020-05-11 16:15:00.0\",\"transType\":\"TTON\",\"sumAllQ\":\"0\",\"sumAllL\":\"0\",\"sumAllCp\":\"0\",\"sumAllS\":\"1\",\"sumAllNt\":\" 0\",\"sumAllE\":\"0\",\"sumAllC\":\"0\",\"sumAllTf\":\"0\",\"sumOther\":\"0\",\"totalTransCount\":\"1\",\"totalTransSegment\":\"1\",\"failureCount\":\"0\",\"comp11Min\":\"0\",\"comp15Min\":\"0\",\"comp30Min\":\"0\",\"compGt30Min\":\"1\"}]";
        when(tracfoneController.getMonitorReport(anyString(), anyString())).thenReturn(jsonResponse);
        Response response = tracfoneOneReportingResource.storeMonitorReportGET("tt");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals(jsonResponse, response.getEntity().toString());
    }

    @Test
    public void testStoreMonitorReportGET_Pcrf() throws TracfoneOneException {
        String jsonResponse = "[{\"'template'\":\"'pcrfParentName'\",\"'orderType'\":\"'orderType'\",\"xDate\":\"2020-05-11 16:15:00.0\",\"'sumQ'\":\"0\",\"'sumL'\":\"0\",\"'sumW'\":\"0\",\"'sumS'\":\"1\",\"'sumC'\":\" 0\",\"'sumF'\":\"0\",\"'sumE'\":\"0\",\"'sumOthers'\":\"0\"}]";
        when(tracfoneController.getMonitorReport(anyString(), anyString())).thenReturn(jsonResponse);
        Response response = tracfoneOneReportingResource.storeMonitorReportGET("pcrf");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals(jsonResponse, response.getEntity().toString());
    }

    @Test
    public void testStoreMonitorReportGET_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneController).getMonitorReport(anyString(), anyString());
        Response response = tracfoneOneReportingResource.storeMonitorReportGET("ig");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }

    @Test
    public void testAdhocMonitorReport_IG() throws TracfoneOneException {
        TracfoneAdhocReportRequest adhocReportRequest = new TracfoneAdhocReportRequest();
        adhocReportRequest.setFromDate("2020/12/1 0:0:0");
        adhocReportRequest.setToDate("2020/12/2 0:0:0");
        adhocReportRequest.setTransactionType("IG");
        TracfoneOneReport tracfoneOneReport = new TracfoneOneReport();
        tracfoneOneReport.setReportName("monitor");
        String jsonResponse = "[{\"carrier\":\"ATT\",\"transNum\":\"39085\",\"xDate\":\"2020-05-11 16:15:00.0\",\"transType\":\"TTON\",\"sumAllQ\":\"0\",\"sumAllL\":\"0\",\"sumAllCp\":\"0\",\"sumAllS\":\"1\",\"sumAllNt\":\" 0\",\"sumAllE\":\"0\",\"sumAllC\":\"0\",\"sumAllTf\":\"0\",\"sumOther\":\"0\",\"totalTransCount\":\"1\",\"totalTransSegment\":\"1\",\"failureCount\":\"0\",\"comp11Min\":\"0\",\"comp15Min\":\"0\",\"comp30Min\":\"0\",\"compGt30Min\":\"1\"}]";
        tracfoneOneReport.setJsonResponse(jsonResponse);
        when(tracfoneControllerReport.runAdhocMonitorReport(any())).thenReturn(tracfoneOneReport);
        Response response = tracfoneOneReportingResource.adhocMonitorReport(adhocReportRequest);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"reportName\":\"monitor\",\"jsonResponse\":\"[{\\\"carrier\\\":\\\"ATT\\\",\\\"transNum\\\":\\\"39085\\\",\\\"xDate\\\":\\\"2020-05-11 16:15:00.0\\\",\\\"transType\\\":\\\"TTON\\\",\\\"sumAllQ\\\":\\\"0\\\",\\\"sumAllL\\\":\\\"0\\\",\\\"sumAllCp\\\":\\\"0\\\",\\\"sumAllS\\\":\\\"1\\\",\\\"sumAllNt\\\":\\\" 0\\\",\\\"sumAllE\\\":\\\"0\\\",\\\"sumAllC\\\":\\\"0\\\",\\\"sumAllTf\\\":\\\"0\\\",\\\"sumOther\\\":\\\"0\\\",\\\"totalTransCount\\\":\\\"1\\\",\\\"totalTransSegment\\\":\\\"1\\\",\\\"failureCount\\\":\\\"0\\\",\\\"comp11Min\\\":\\\"0\\\",\\\"comp15Min\\\":\\\"0\\\",\\\"comp30Min\\\":\\\"0\\\",\\\"compGt30Min\\\":\\\"1\\\"}]\",\"reportSQL\":null,\"createDate\":null}", response.getEntity().toString());
    }

    @Test
    public void testAdhocMonitorReport_TT() throws TracfoneOneException {
        TracfoneAdhocReportRequest adhocReportRequest = new TracfoneAdhocReportRequest();
        adhocReportRequest.setFromDate("2020/12/1 0:0:0");
        adhocReportRequest.setToDate("2020/12/2 0:0:0");
        adhocReportRequest.setTransactionType("TT");
        TracfoneOneReport tracfoneOneReport = new TracfoneOneReport();
        tracfoneOneReport.setReportName("ttmonitor");
        String jsonResponse = "[{\"carrier\":\"ATT\",\"transNum\":\"39085\",\"xDate\":\"2020-05-11 16:15:00.0\",\"transType\":\"TTON\",\"sumAllQ\":\"0\",\"sumAllL\":\"0\",\"sumAllCp\":\"0\",\"sumAllS\":\"1\",\"sumAllNt\":\" 0\",\"sumAllE\":\"0\",\"sumAllC\":\"0\",\"sumAllTf\":\"0\",\"sumOther\":\"0\",\"totalTransCount\":\"1\",\"totalTransSegment\":\"1\",\"failureCount\":\"0\",\"comp11Min\":\"0\",\"comp15Min\":\"0\",\"comp30Min\":\"0\",\"compGt30Min\":\"1\"}]";
        tracfoneOneReport.setJsonResponse(jsonResponse);
        when(tracfoneControllerReport.runAdhocTTMonitorReport(any())).thenReturn(tracfoneOneReport);
        Response response = tracfoneOneReportingResource.adhocMonitorReport(adhocReportRequest);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"reportName\":\"ttmonitor\",\"jsonResponse\":\"[{\\\"carrier\\\":\\\"ATT\\\",\\\"transNum\\\":\\\"39085\\\",\\\"xDate\\\":\\\"2020-05-11 16:15:00.0\\\",\\\"transType\\\":\\\"TTON\\\",\\\"sumAllQ\\\":\\\"0\\\",\\\"sumAllL\\\":\\\"0\\\",\\\"sumAllCp\\\":\\\"0\\\",\\\"sumAllS\\\":\\\"1\\\",\\\"sumAllNt\\\":\\\" 0\\\",\\\"sumAllE\\\":\\\"0\\\",\\\"sumAllC\\\":\\\"0\\\",\\\"sumAllTf\\\":\\\"0\\\",\\\"sumOther\\\":\\\"0\\\",\\\"totalTransCount\\\":\\\"1\\\",\\\"totalTransSegment\\\":\\\"1\\\",\\\"failureCount\\\":\\\"0\\\",\\\"comp11Min\\\":\\\"0\\\",\\\"comp15Min\\\":\\\"0\\\",\\\"comp30Min\\\":\\\"0\\\",\\\"compGt30Min\\\":\\\"1\\\"}]\",\"reportSQL\":null,\"createDate\":null}", response.getEntity().toString());
    }

    @Test
    public void testAdhocMonitorReport_Pcrf() throws TracfoneOneException {
        TracfoneAdhocReportRequest adhocReportRequest = new TracfoneAdhocReportRequest();
        adhocReportRequest.setFromDate("2020/12/1 0:0:0");
        adhocReportRequest.setToDate("2020/12/2 0:0:0");
        adhocReportRequest.setTransactionType("PCRF");
        TracfoneOneReport tracfoneOneReport = new TracfoneOneReport();
        tracfoneOneReport.setReportName("pcrfmonitor");
        String jsonResponse = "[{\"carrier\":\"ATT\",\"transNum\":\"39085\",\"xDate\":\"2020-05-11 16:15:00.0\",\"transType\":\"TTON\",\"sumAllQ\":\"0\",\"sumAllL\":\"0\",\"sumAllCp\":\"0\",\"sumAllS\":\"1\",\"sumAllNt\":\" 0\",\"sumAllE\":\"0\",\"sumAllC\":\"0\",\"sumAllTf\":\"0\",\"sumOther\":\"0\",\"totalTransCount\":\"1\",\"totalTransSegment\":\"1\",\"failureCount\":\"0\",\"comp11Min\":\"0\",\"comp15Min\":\"0\",\"comp30Min\":\"0\",\"compGt30Min\":\"1\"}]";
        tracfoneOneReport.setJsonResponse(jsonResponse);
        when(tracfoneControllerReport.runAdhocPCRFMonitorReport(any())).thenReturn(tracfoneOneReport);
        Response response = tracfoneOneReportingResource.adhocMonitorReport(adhocReportRequest);
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals("{\"reportName\":\"pcrfmonitor\",\"jsonResponse\":\"[{\\\"carrier\\\":\\\"ATT\\\",\\\"transNum\\\":\\\"39085\\\",\\\"xDate\\\":\\\"2020-05-11 16:15:00.0\\\",\\\"transType\\\":\\\"TTON\\\",\\\"sumAllQ\\\":\\\"0\\\",\\\"sumAllL\\\":\\\"0\\\",\\\"sumAllCp\\\":\\\"0\\\",\\\"sumAllS\\\":\\\"1\\\",\\\"sumAllNt\\\":\\\" 0\\\",\\\"sumAllE\\\":\\\"0\\\",\\\"sumAllC\\\":\\\"0\\\",\\\"sumAllTf\\\":\\\"0\\\",\\\"sumOther\\\":\\\"0\\\",\\\"totalTransCount\\\":\\\"1\\\",\\\"totalTransSegment\\\":\\\"1\\\",\\\"failureCount\\\":\\\"0\\\",\\\"comp11Min\\\":\\\"0\\\",\\\"comp15Min\\\":\\\"0\\\",\\\"comp30Min\\\":\\\"0\\\",\\\"compGt30Min\\\":\\\"1\\\"}]\",\"reportSQL\":null,\"createDate\":null}", response.getEntity().toString());
    }

    @Test
    public void testMonitorGraphReport_IG() throws TracfoneOneException {
        String jsonResponse = "[{\"template\":\"CSI_TLG\",\"orderType\":\"ACT/REACT\",\"count\":\"2\",\"status\":\"S\",\"transType\":\"TEST\",}]";
        when(tracfoneController.getMonitorGraphReport(anyString(), anyString())).thenReturn(jsonResponse);
        Response response = tracfoneOneReportingResource.getMonitorGraphReport("ig");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals(jsonResponse, response.getEntity().toString());
    }

    @Test
    public void testMonitorGraphReport_TT() throws TracfoneOneException {
        String jsonResponse = "[{\"carrier\":\"ATT\",\"transNum\":\"39085\",\"transType\":\"TTON\",\"status\":\"S\",\"count\":\"2\",}]";
        when(tracfoneController.getMonitorGraphReport(anyString(), anyString())).thenReturn(jsonResponse);
        Response response = tracfoneOneReportingResource.getMonitorGraphReport("tt");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals(jsonResponse, response.getEntity().toString());
    }

    @Test
    public void testMonitorGraphReport_Pcrf() throws TracfoneOneException {
        String jsonResponse = "[{\"'template'\":\"'pcrfParentName'\",\"'orderType'\":\"'orderType'\",\"'status'\":\"C\",\"'count'\":\"3\"}]";
        when(tracfoneController.getMonitorGraphReport(anyString(), anyString())).thenReturn(jsonResponse);
        Response response = tracfoneOneReportingResource.getMonitorGraphReport("pcrf");
        assertEquals(response.getStatus(), 200);
        assertEquals(response.getMediaType().toString(), JSON);
        assertEquals(jsonResponse, response.getEntity().toString());
    }

    @Test
    public void testeMonitorGraphReport_whenException() throws TracfoneOneException {
        doThrow(tracfoneOneException).when(tracfoneController).getMonitorGraphReport(anyString(), anyString());
        Response response = tracfoneOneReportingResource.getMonitorGraphReport("ig");
        assertEquals(response.getStatus(), 200);
        assertEquals("{\"errorCode\":\"TFE0\",\"errorMessage\":\"dummy_error_message\",\"httpCode\":400}", response.getEntity().toString());
    }
}