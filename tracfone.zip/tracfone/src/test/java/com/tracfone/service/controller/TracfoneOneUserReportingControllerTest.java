package com.tracfone.service.controller;

import com.tracfone.ejb.entity.UserTask;
import com.tracfone.ejb.entity.UserTaskDetail;
import com.tracfone.ejb.entity.session.UserTaskFacadeLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneUserTask;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneUserReporting;
import com.tracfone.service.model.response.TFOneUserTask;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_GET_ALL_USER_TASKS_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_GET_ALL_USER_TASKS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_GET_ASSIGN_REPORT_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_GET_ASSIGN_REPORT_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_GET_TRANSACTION_REPORT_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_GET_TRANSACTION_REPORT_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_REASSIGN_TRANSACTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_REASSIGN_TRANSACTION_ERROR_CODE_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneUserReportingControllerTest {

    @InjectMocks
    private TracfoneOneUserReportingController tracfoneOneUserReportingController;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    @Mock
    private UserTaskFacadeLocal userTaskFacade;
    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private ResultSet resultSet;

    @Mock
    private Query query;

    @Mock
    private EntityManager em;

    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "new_id");
        tracfoneOneException = new TracfoneOneException("TFE0", "dummy_error_message");
    }

    @Test
    public void testGetUserTask() throws TracfoneOneException {
        List<String> status = new ArrayList<>();
        status.add("ASSIGN");
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setFromCreationDate("09/07/2020");
        tfOneUserTask.setToCreationDate("09/07/2020");
        tfOneUserTask.setUserId("381");
        tfOneUserTask.setStatus(status);

        List<Object[]> userTaskLists = new ArrayList<>();
        Object[] object = {"381", "DESC", "381", "TASK_NAME", "TYPE", "381", "DUMMY_DATA", "DUMMY_DATA", "DUMMY_DATA", "DUMMY_DATA", "DUMMY_DATA", "DUMMY_DATA", "DUMMY_DATA"};
        userTaskLists.add(object);

        when(userTaskFacade.getEntityManager()).thenReturn(em);
        when(em.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyInt(), anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(userTaskLists);

        List<TFOneUserTask> response = tracfoneOneUserReportingController.getAllUserTasks(tfOneUserTask);
        assertEquals("[TFOneUserTask{id='381', taskName='DESC', description='381', userId='TASK_NAME', assignedUserId='TYPE', assignedUserName='DUMMY_DATA', type='381', status=[DUMMY_DATA], creationDate='DUMMY_DATA', tfOneUserTaskDetail=[TFOneUserTaskDetail{id='DUMMY_DATA', userTaskId='null', taskDetails='DUMMY_DATA', userComments='DUMMY_DATA'}]}]", response.toString());
    }

    @Test
    public void testGetUserTask_whenException() {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setAssignedUserId("381");
        tfOneUserTask.setId("381");
        try {
            tracfoneOneUserReportingController.getAllUserTasks(tfOneUserTask);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_USER_TASKS_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_USER_TASKS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testReassignTransaction() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setAssignedUserId("381");
        tfOneUserTask.setId("381");

        List<UserTaskDetail> userTaskDetails = new ArrayList<>();
        UserTaskDetail userTaskDetail = new UserTaskDetail();
        userTaskDetail.setUserComments("COMMENT");
        userTaskDetail.setTaskDetails("DETAILS");
        userTaskDetail.setId(324);
        userTaskDetails.add(userTaskDetail);

        UserTask userTask = new UserTask();
        userTask.setDescription("DESC");
        userTask.setTaskName("TASK_NAME");
        userTask.setType("TYPE");
        userTask.setUserId(435);
        userTask.setId(435);
        userTask.setAssignedUserId(435);
        userTask.setUserTaskDetails(userTaskDetails);
        when(userTaskFacade.find(anyInt())).thenReturn(userTask);
        TFOneGeneralResponse response = tracfoneOneUserReportingController.reassignTransaction(tfOneUserTask, 676);
        assertEquals(response.getStatus(), "Success");
        assertEquals("Transaction reassigned Successfully", response.getMessage());
    }

    @Test
    public void testReassignTransaction_whenException() {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setAssignedUserId("381");
        tfOneUserTask.setId("381");
        doThrow(RuntimeException.class).when(userTaskFacade).find(anyInt());
        try {
            tracfoneOneUserReportingController.reassignTransaction(tfOneUserTask, 324);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_REASSIGN_TRANSACTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_REASSIGN_TRANSACTION_ERROR_CODE_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testAssignTransactionReport() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setDbEnv("DB");
        tfOneUserTask.setAssignedUserId("381");
        tfOneUserTask.setToCreationDate("1/9/2020");
        tfOneUserTask.setFromCreationDate("1/10/2020");

        List<TFOneUserReporting> response = tracfoneOneUserReportingController.assignTransactionReport(tfOneUserTask);
        assertEquals("[TFOneUserReporting{status='ASSIGNED', tasks='0', transactions='0'}, TFOneUserReporting{status='CANCELLED', tasks='0', transactions='0'}, TFOneUserReporting{status='COMPLETED', tasks='0', transactions='0'}, TFOneUserReporting{status='IN PROGRESS', tasks='0', transactions='0'}]", response.toString());
    }

    @Test
    public void testAssignTransactionReport_whenException() throws SQLException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setAssignedUserId("381");
        tfOneUserTask.setId("381");
        try {
            tracfoneOneUserReportingController.assignTransactionReport(tfOneUserTask);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ASSIGN_REPORT_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_GET_ASSIGN_REPORT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testTransactionTypeReport() throws TracfoneOneException {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setDbEnv("DB");
        tfOneUserTask.setType("TT_TRANSACTION");
        tfOneUserTask.setAssignedUserId("381");
        tfOneUserTask.setToCreationDate("1/9/2020");
        tfOneUserTask.setFromCreationDate("1/10/2020");

        List<TFOneUserReporting> response = tracfoneOneUserReportingController.transactionTypeReport(tfOneUserTask);
        assertEquals("[TFOneUserReporting{status='RE-QUEUE', tasks='0', transactions='0'}, TFOneUserReporting{status='REWORK', tasks='0', transactions='0'}, TFOneUserReporting{status='INSERT', tasks='0', transactions='0'}]", response.toString());
    }

    @Test
    public void testTransactionTypeReport_whenException() {
        TracfoneOneUserTask tfOneUserTask = new TracfoneOneUserTask();
        tfOneUserTask.setAssignedUserId("381");
        tfOneUserTask.setType("TT_TRANSACTION");
        tfOneUserTask.setToCreationDate("1/9/2020");
        tfOneUserTask.setFromCreationDate("1/10/2020");
        try {
            tracfoneOneUserReportingController.transactionTypeReport(tfOneUserTask);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_TRANSACTION_REPORT_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_GET_TRANSACTION_REPORT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}