package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucketTier;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildTier;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionLink;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchServicePlanModel;
import com.tracfone.service.model.request.TracfoneOneServicePlanCarrierFeature;
import com.tracfone.service.model.response.TFOneAncillaryCodeConfig;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileBucketTier;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildTier;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneRatePlan;
import com.tracfone.service.model.response.TFOneRatePlanExtensionConfig;
import com.tracfone.service.model.response.TFOneRatePlanExtensionLink;
import com.tracfone.service.model.response.TFOneServicePlanCarrierFeature;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ALL_SERVICE_PLAN_CARRIERS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CARRIER_FEATURES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CARRIER_FEATURES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CF_LINKS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CF_LINKS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CF_RATE_PLANS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CF_RATE_PLANS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_PROFILE_FEATURE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_PROFILE_FEATURE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_SERVICE_PLAN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_SERVICE_PLAN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CP_BUCKETS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CP_BUCKETS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_SERVICE_PLANS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_SERVICE_PLANS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ALL_SERVICE_PLAN_CARRIERS_ERROR;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneServicePlanControllerTest {
    @InjectMocks
    private TracfoneServicePlanController tracfoneServicePlanController;
    @Mock
    private TracfoneServicePlanAction tracfoneServicePlanAction;
    @Mock
    private TracfoneRatePlanLocalAction tracfoneRatePlanAction;
    @Mock
    private TracfoneProfileLocalAction tracfoneProfileAction;
    @Mock
    private TracfoneBucketLocalAction tracfoneBucketAction;
    @Mock
    private TracfoneFeatureLocalAction tracfoneFeatureAction;
    private TracfoneOneException tracfoneOneException;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private static final String DBENV = "DBENV";
    private static final String SAMPLE = "SAMPLE";
    private static final String TEST = "test";
    private static final String ONE = "1";

    @Before
    public void setUp() {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", SAMPLE);
        tracfoneOneException = new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
    }

    private TracfoneOneCarrierFeature getTracfoneOneCarrierFeature() {
        TracfoneOneCarrierFeature tracfoneOneCarrierFeature = new TracfoneOneCarrierFeature();
        tracfoneOneCarrierFeature.setDbEnv(DBENV);
        tracfoneOneCarrierFeature.setObjId(ONE);
        tracfoneOneCarrierFeature.setxTechnology(TEST);
        tracfoneOneCarrierFeature.setxRatePlan(TEST);
        tracfoneOneCarrierFeature.setxVoicemail(ONE);
        tracfoneOneCarrierFeature.setxVmCode(TEST);
        tracfoneOneCarrierFeature.setxVmPackage(ONE);
        tracfoneOneCarrierFeature.setxCallerId(ONE);
        tracfoneOneCarrierFeature.setxIdCode(TEST);
        tracfoneOneCarrierFeature.setxIdPackage(ONE);
        tracfoneOneCarrierFeature.setxSms(ONE);
        tracfoneOneCarrierFeature.setxSmsCode(TEST);
        tracfoneOneCarrierFeature.setxSmsPackage(ONE);
        tracfoneOneCarrierFeature.setxCallWaiting(ONE);
        tracfoneOneCarrierFeature.setxCwCode(TEST);
        tracfoneOneCarrierFeature.setxCwPackage(ONE);
        tracfoneOneCarrierFeature.setxDigitalFeature(TEST);
        tracfoneOneCarrierFeature.setxDigFeature(ONE);
        tracfoneOneCarrierFeature.setxFeature2xCarrier(ONE);
        tracfoneOneCarrierFeature.setxSmscNumber(TEST);
        tracfoneOneCarrierFeature.setxData(ONE);
        tracfoneOneCarrierFeature.setxRestrictedUse(ONE);
        tracfoneOneCarrierFeature.setxSwitchBaseRate(TEST);
        tracfoneOneCarrierFeature.setxFeatures2BusOrg(ONE);
        tracfoneOneCarrierFeature.setxIsSwbCarrier(ONE);
        tracfoneOneCarrierFeature.setxMpn(ONE);
        tracfoneOneCarrierFeature.setxMpnCode(TEST);
        tracfoneOneCarrierFeature.setxPoolName(TEST);
        tracfoneOneCarrierFeature.setCreateMformIgFlag(TEST);
        tracfoneOneCarrierFeature.setUseCfExtensionFlag(TEST);
        tracfoneOneCarrierFeature.setDataSaver(ONE);
        tracfoneOneCarrierFeature.setDataSaverCode(TEST);
        tracfoneOneCarrierFeature.setUseRpExtensionFlag(TEST);
        tracfoneOneCarrierFeature.setTmoNextGenFlag(TEST);
        tracfoneOneCarrierFeature.setServicePlanCarrierFeature(getTracfoneOneServicePlanCarrierFeature());
        return tracfoneOneCarrierFeature;
    }

    private TracfoneOneServicePlanCarrierFeature getTracfoneOneServicePlanCarrierFeature() {
        TracfoneOneServicePlanCarrierFeature servicePlanCarrierFeature = new TracfoneOneServicePlanCarrierFeature();
        servicePlanCarrierFeature.setServicePlanId("185");
        servicePlanCarrierFeature.setPriority("1");
        servicePlanCarrierFeature.setCarrierFeaturesId("185");
        return servicePlanCarrierFeature;
    }

    @Test
    public void testSearchServicePlans() throws Exception {
        List<TFOneCarrierServicePlan> servicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneServicePlanView = new TFOneCarrierServicePlan();
        tfOneServicePlanView.setParentName("PARENT_NAME");
        tfOneServicePlanView.setCarrierName("CARRIER_NAME");
        tfOneServicePlanView.setServicePlanId("185");
        servicePlans.add(tfOneServicePlanView);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setServicePlanId("185");
        when(tracfoneServicePlanAction.searchServicePlans(any(TracfoneOneSearchServicePlanModel.class))).thenReturn(servicePlans);
        List<TFOneCarrierServicePlan> response = tracfoneServicePlanController.searchServicePlans(tfServicePlanModel);
        assertEquals("[TFOneCarrierServicePlan{carrierName='CARRIER_NAME', servicePlanId='185', mktName='null', description='null', servicePlanPurchase='null', parentName='PARENT_NAME', servicePlans=null}]", response.toString());
    }

    @Test
    public void testSearchServicePlans_whenException() throws Exception {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        doThrow(tracfoneOneException).when(tracfoneServicePlanAction).searchServicePlans(any(TracfoneOneSearchServicePlanModel.class));
        try {
            tracfoneServicePlanController.searchServicePlans(tfServicePlanModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_SERVICE_PLANS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_SERVICE_PLANS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testViewServicePlanCarrierFeatures() throws Exception {
        TracfoneOneSearchServicePlanModel searchServicePlanModel = new TracfoneOneSearchServicePlanModel();
        searchServicePlanModel.setCarrierName(SAMPLE);
        searchServicePlanModel.setDbEnv(DBENV);
        List<TFOneCarrierFeature> tfOneCarrierFeatures = new ArrayList<>();
        TFOneCarrierFeature tfOneCarrierFeature = new TFOneCarrierFeature();
        tfOneCarrierFeature.setxTechnology(SAMPLE);
        tfOneCarrierFeatures.add(tfOneCarrierFeature);
        when(tracfoneServicePlanAction.viewServicePlanCarrierFeatures(any())).thenReturn(tfOneCarrierFeatures);
        List<TFOneCarrierFeature> response = tracfoneServicePlanController.viewServicePlanCarrierFeatures(searchServicePlanModel);
        assertEquals(response.get(0).getxTechnology(), tfOneCarrierFeature.getxTechnology());
        assertEquals(response.get(0).getObjId(), tfOneCarrierFeature.getObjId());
    }

    @Test
    public void testViewServicePlanCarrierFeatures_whenException() throws Exception {
        TracfoneOneSearchServicePlanModel searchServicePlanModel = new TracfoneOneSearchServicePlanModel();
        doThrow(tracfoneOneException).when(tracfoneServicePlanAction).viewServicePlanCarrierFeatures(any());
        try {
            tracfoneServicePlanController.viewServicePlanCarrierFeatures(searchServicePlanModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_CARRIER_FEATURES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_CARRIER_FEATURES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetServicePlansForCarrier() throws Exception {
        List<TFOneCarrierServicePlan> tfOneCarrierServicePlanList = new ArrayList<>();
        TFOneCarrierServicePlan tfOneCarrierServicePlan = new TFOneCarrierServicePlan();
        tfOneCarrierServicePlan.setCarrierName("CARRIER_NAME");
        tfOneCarrierServicePlan.setDescription(SAMPLE);
        tfOneCarrierServicePlanList.add(tfOneCarrierServicePlan);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setCarrierName("CARRIER_NAME");
        when(tracfoneRatePlanAction.getServicePlansForCarrier(anyString(), anyString())).thenReturn(tfOneCarrierServicePlanList);
        List<TFOneCarrierServicePlan> response = tracfoneServicePlanController.getServicePlansForCarrier(tracfoneOneSearchPlanModel);
        assertEquals(response.get(0).getCarrierName(), tfOneCarrierServicePlan.getCarrierName());
    }

    @Test
    public void testGetServicePlansForCarrier_WhenCarrierNameNotNull() throws Exception {
        List<TFOneCarrierServicePlan> tfOneCarrierServicePlanList = new ArrayList<>();
        TFOneCarrierServicePlan tfOneCarrierServicePlan = new TFOneCarrierServicePlan();
        tfOneCarrierServicePlan.setCarrierName("CARRIER_NAME");
        tfOneCarrierServicePlan.setDescription(SAMPLE);
        tfOneCarrierServicePlanList.add(tfOneCarrierServicePlan);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setLegacy(true);
        tracfoneOneSearchPlanModel.setCarrierName("CARRIER_NAME");
        when(tracfoneServicePlanAction.getAllLegacyPaygoPlans(anyString(), anyString())).thenReturn(tfOneCarrierServicePlanList);
        List<TFOneCarrierServicePlan> response = tracfoneServicePlanController.getServicePlansForCarrier(tracfoneOneSearchPlanModel);
        assertEquals(response.get(0).getCarrierName(), tfOneCarrierServicePlan.getCarrierName());
    }

    @Test
    public void testGetServicePlansForCarrier_WhenCarrierNameNull() throws Exception {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setLegacy(true);
        List<TFOneCarrierServicePlan> response = tracfoneServicePlanController.getServicePlansForCarrier(tracfoneOneSearchPlanModel);
        assertEquals("[]", response.toString());
    }

    @Test
    public void testGetServicePlansForCarrier_whenException() throws Exception {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv("123");
        doThrow(tracfoneOneException).when(tracfoneServicePlanAction).getAllServicePlans(anyString());
        try {
            tracfoneServicePlanController.getServicePlansForCarrier(tracfoneOneSearchPlanModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_SERVICE_PLAN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_SERVICE_PLAN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCarrierRatePlans() throws Exception {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setCarrierName("CARRIER_NAME");
        List<TFOneRatePlan> ratePlans = new ArrayList<>();
        TFOneRatePlan tfOneRatePlan = new TFOneRatePlan();
        tfOneRatePlan.setObjId("1000");
        tfOneRatePlan.setRatePlanName("RATE_PLAN_NAME");
        tfOneRatePlan.setTmoNextGenFlag("Y");
        ratePlans.add(tfOneRatePlan);
        when(tracfoneRatePlanAction.getCarrierRatePlans(any(), any())).thenReturn(ratePlans);
        List<TFOneRatePlan> response = tracfoneServicePlanController.getCarrierRatePlans(tracfoneOneSearchPlanModel);
        assertEquals("[TFOneRatePlan{objId=1000, ratePlanName=RATE_PLAN_NAME, privateNetwork=null, espidUpdate=null, espidNum=null, propagateFlagValue=null, allowMformApnRequestFlag=null, calculateDataUnitsFlag=null, thresholdsToTmo=null, hotspotBucketsFlag=null, tmoNextGenFlag=Y, ratePlanProfile=[], carrierFeatures=null}]", response.toString());
    }

    @Test
    public void testGetCarrierRatePlans_whenException() throws Exception {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneRatePlanAction).getMasterRatePlans(any());
        try {
            tracfoneServicePlanController.getCarrierRatePlans(tracfoneOneSearchPlanModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_CF_RATE_PLANS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_CF_RATE_PLANS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCarrierFeatureLinks() throws Exception {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setProfileDesc("PROFILE_DESCRIPTION");

        List<TFOneCarrierFeature> tfOneCarrierFeatures = new ArrayList<>();
        TFOneCarrierFeature tfOneCarrierFeature = new TFOneCarrierFeature();
        tfOneCarrierFeature.setObjId("1");
        tfOneCarrierFeature.setxRatePlan("RATE_PLAN");
        List<TFOneRatePlanExtensionLink> tfOneRatePlanExtensionLinks = new ArrayList<>();
        TFOneRatePlanExtensionLink link = new TFOneRatePlanExtensionLink();
        link.setAncillaryCode("AL");
        link.setLineStatusCode("AL");
        link.setThrottleStatusCode("AL");
        link.setRatePlanExtensionId("AL");
        link.setCarrierFeatureId("1");
        link.setObjId("100");
        link.setProfileDescription("PROFILE_DESC");
        link.setProfileId("10");
        tfOneRatePlanExtensionLinks.add(link);
        tfOneCarrierFeature.setRpExtensionLinks(tfOneRatePlanExtensionLinks);
        tfOneCarrierFeatures.add(tfOneCarrierFeature);
        when(tracfoneServicePlanAction.getCarrierFeatureLinks(any())).thenReturn(tfOneCarrierFeatures);
        List<TFOneCarrierFeature> response = tracfoneServicePlanController.getCarrierFeatureLinks(tfServicePlanModel);
        assertEquals("[TFOneCarrierFeature{objId='1', dev='null', xTechnology='null', xRatePlan='RATE_PLAN', xVoicemail='null', xVmCode='null', xVmPackage='null', xCallerId='null', xIdCode='null', xIdPackage='null', xSms='null', xSmsCode='null', xSmsPackage='null', xCallWaiting='null', xCwCode='null', xCwPackage='null', xDigitalFeature='null', xDigFeature='null', xFeature2xCarrier='null', xSmscNumber='null', xData='null', xRestrictedUse='null', xSwitchBaseRate='null', xFeatures2BusOrg='null', xIsSwbCarrier='null', xMpn='null', xMpnCode='null', xPoolName='null', createMformIgFlag='null', useCfExtensionFlag='null', dataSaver='null', dataSaverCode='null', useRpExtensionFlag='null', tmoNextGenFlag='null', servicePlanId='null', brand='null', xCarrierId='null', servicePlanCarrierFeature=null, rpExtensionLinks=[TFOneRatePlanExtensionLink{objId=100, childPlanId=null, carrierFeatureId=1, childPlanDescription=null, profileDescription=PROFILE_DESC, lineStatusCode=AL, throttleStatusCode=AL, ancillaryCode=AL, profileId=10, ratePlanExtensionId=AL}]}]", response.toString());
    }

    @Test
    public void testGetCarrierFeatureLinks_IfBlock() throws Exception {
        List<TracfoneOneCarrierFeature> selectedCarrierFeatures = new ArrayList<>();
        TracfoneOneCarrierFeature selectedCarrierFeature = new TracfoneOneCarrierFeature();
        selectedCarrierFeature.setDbEnv(DBENV);
        selectedCarrierFeature.setObjId("100");
        selectedCarrierFeature.setxTechnology("CDMA");
        selectedCarrierFeatures.add(selectedCarrierFeature);

        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setSelectedCarrierFeatures(selectedCarrierFeatures);


        List<TFOneCarrierFeature> tfOneCarrierFeatures = new ArrayList<>();
        TFOneCarrierFeature tfOneCarrierFeature = new TFOneCarrierFeature();
        tfOneCarrierFeature.setObjId("1");
        tfOneCarrierFeature.setxRatePlan("RATE_PLAN");
        List<TFOneRatePlanExtensionLink> tfOneRatePlanExtensionLinks = new ArrayList<>();
        TFOneRatePlanExtensionLink link = new TFOneRatePlanExtensionLink();
        link.setAncillaryCode("AL");
        link.setLineStatusCode("AL");
        link.setThrottleStatusCode("AL");
        link.setRatePlanExtensionId("AL");
        link.setCarrierFeatureId("1");
        link.setObjId("100");
        link.setProfileDescription("PROFILE_DESC");
        link.setProfileId("10");
        tfOneRatePlanExtensionLinks.add(link);
        tfOneCarrierFeature.setRpExtensionLinks(tfOneRatePlanExtensionLinks);
        tfOneCarrierFeatures.add(tfOneCarrierFeature);
        when(tracfoneRatePlanAction.getCarrierFeatureLinks(any())).thenReturn(tfOneCarrierFeatures);
        List<TFOneCarrierFeature> response = tracfoneServicePlanController.getCarrierFeatureLinks(tfServicePlanModel);
        assertEquals("[TFOneCarrierFeature{objId='1', dev='null', xTechnology='null', xRatePlan='RATE_PLAN', xVoicemail='null', xVmCode='null', xVmPackage='null', xCallerId='null', xIdCode='null', xIdPackage='null', xSms='null', xSmsCode='null', xSmsPackage='null', xCallWaiting='null', xCwCode='null', xCwPackage='null', xDigitalFeature='null', xDigFeature='null', xFeature2xCarrier='null', xSmscNumber='null', xData='null', xRestrictedUse='null', xSwitchBaseRate='null', xFeatures2BusOrg='null', xIsSwbCarrier='null', xMpn='null', xMpnCode='null', xPoolName='null', createMformIgFlag='null', useCfExtensionFlag='null', dataSaver='null', dataSaverCode='null', useRpExtensionFlag='null', tmoNextGenFlag='null', servicePlanId='null', brand='null', xCarrierId='null', servicePlanCarrierFeature=null, rpExtensionLinks=[TFOneRatePlanExtensionLink{objId=100, childPlanId=null, carrierFeatureId=1, childPlanDescription=null, profileDescription=PROFILE_DESC, lineStatusCode=AL, throttleStatusCode=AL, ancillaryCode=AL, profileId=10, ratePlanExtensionId=AL}]}]", response.toString());
    }

    @Test
    public void testGetCarrierFeatureLinks_whenException() throws Exception {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        try {
            tracfoneServicePlanController.getCarrierFeatureLinks(tfServicePlanModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_CF_LINKS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_CF_LINKS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllProfileFeatures() throws Exception {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setFeatureName("Feature_NAME");
        tfServicePlanModel.setFeatureRequirement("Feature_REQUIREMENT");
        tfServicePlanModel.setBucketId("1000");
//        List<TFOneRatePlanExtensionConfig> rpExtensionConfigs = new ArrayList<>();
//        TFOneRatePlanExtensionConfig tfOneRpExtensionConfig = new TFOneRatePlanExtensionConfig();
//        tfOneRpExtensionConfig.setDisplaySUIFlag("Y");
//        tfOneRpExtensionConfig.setFeatureName("FEATURE_NAME");
//        tfOneRpExtensionConfig.setFeatureRequirement("FEATURE_REQUIREMENT");
//        tfOneRpExtensionConfig.setFeatureValue("FEATURE_VALUE");
//        tfOneRpExtensionConfig.setProfileId("10");
//        tfOneRpExtensionConfig.setRestrictSUIFlag("Y");
//        tfOneRpExtensionConfig.setToggleFlag("Y");
//        rpExtensionConfigs.add(tfOneRpExtensionConfig);

        List<TFOneAncillaryCodeConfig> ancillaryCodeFeatures = new ArrayList<>();
        TFOneAncillaryCodeConfig ancillaryCodeFeature = new TFOneAncillaryCodeConfig();
        ancillaryCodeFeature.setProfileId("10");
        ancillaryCodeFeature.setDisplaySUIFlag("Y");
        ancillaryCodeFeature.setToggleFlag("Y");
        ancillaryCodeFeature.setFeatureName("FEATURE_NAME");
        ancillaryCodeFeature.setFeatureRequirement("FEATURE_REQUIREMENT");
        ancillaryCodeFeature.setExtensionObjId("100");
        ancillaryCodeFeature.setFeatureValue("FEATURE_VALUE");
        ancillaryCodeFeatures.add(ancillaryCodeFeature);

        when(tracfoneProfileAction.getAncillaryCodeConfig(any())).thenReturn(ancillaryCodeFeatures);
//        when(tracfoneFeatureAction.getAllProfileFeatures(any())).thenReturn(rpExtensionConfigs);
        List<TFOneRatePlanExtensionConfig> allProfileFeatures = tracfoneServicePlanController.getAllProfileFeatures(tfServicePlanModel);
        assertEquals("[TFOneRatePlanExtensionConfig{objid=null, profileId=10, profileDescription=null, featureName=FEATURE_NAME, featureValue=FEATURE_VALUE, featureRequirement=FEATURE_REQUIREMENT, toggleFlag=Y, notes=null, displaySUIFlag=Y, restrictSUIFlag=null, rowNum=null, errorMessages={}, dbEnv=null}]", allProfileFeatures.toString());
    }

    @Test
    public void testGetAllProfileFeatures_filterFeatures_ElseBlock() throws Exception {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setFeatureRequirement("Feature_REQUIREMENT");
        tfServicePlanModel.setBucketId("1000");

        List<TFOneAncillaryCodeConfig> ancillaryCodeFeatures = new ArrayList<>();
        TFOneAncillaryCodeConfig ancillaryCodeFeature = new TFOneAncillaryCodeConfig();
        ancillaryCodeFeature.setProfileId("10");
        ancillaryCodeFeature.setDisplaySUIFlag("Y");
        ancillaryCodeFeature.setToggleFlag("Y");
        ancillaryCodeFeature.setFeatureName("FEATURE_NAME");
        ancillaryCodeFeature.setFeatureRequirement("FEATURE_REQUIREMENT");
        ancillaryCodeFeature.setExtensionObjId("100");
        ancillaryCodeFeature.setFeatureValue("FEATURE_VALUE");
        ancillaryCodeFeatures.add(ancillaryCodeFeature);

        when(tracfoneProfileAction.getAncillaryCodeConfig(any())).thenReturn(ancillaryCodeFeatures);
        List<TFOneRatePlanExtensionConfig> allProfileFeatures = tracfoneServicePlanController.getAllProfileFeatures(tfServicePlanModel);
        assertEquals("[TFOneRatePlanExtensionConfig{objid=null, profileId=10, profileDescription=null, featureName=FEATURE_NAME, featureValue=FEATURE_VALUE, featureRequirement=FEATURE_REQUIREMENT, toggleFlag=Y, notes=null, displaySUIFlag=Y, restrictSUIFlag=null, rowNum=null, errorMessages={}, dbEnv=null}]", allProfileFeatures.toString());
    }

    @Test
    public void testGetAllProfileFeatures_whenFeatureReqNull() throws Exception {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setFeatureName("Feature_NAME");
        tfServicePlanModel.setBucketId("1000");

        List<TFOneAncillaryCodeConfig> ancillaryCodeFeatures = new ArrayList<>();
        TFOneAncillaryCodeConfig ancillaryCodeFeature = new TFOneAncillaryCodeConfig();
        ancillaryCodeFeature.setProfileId("10");
        ancillaryCodeFeature.setDisplaySUIFlag("Y");
        ancillaryCodeFeature.setToggleFlag("Y");
        ancillaryCodeFeature.setFeatureName("FEATURE_NAME");
        ancillaryCodeFeature.setFeatureRequirement("FEATURE_REQUIREMENT");
        ancillaryCodeFeature.setExtensionObjId("100");
        ancillaryCodeFeature.setFeatureValue("FEATURE_VALUE");
        ancillaryCodeFeatures.add(ancillaryCodeFeature);

        when(tracfoneProfileAction.getAncillaryCodeConfig(any())).thenReturn(ancillaryCodeFeatures);
        List<TFOneRatePlanExtensionConfig> allProfileFeatures = tracfoneServicePlanController.getAllProfileFeatures(tfServicePlanModel);
        assertEquals("[TFOneRatePlanExtensionConfig{objid=null, profileId=10, profileDescription=null, featureName=FEATURE_NAME, featureValue=FEATURE_VALUE, featureRequirement=FEATURE_REQUIREMENT, toggleFlag=Y, notes=null, displaySUIFlag=Y, restrictSUIFlag=null, rowNum=null, errorMessages={}, dbEnv=null}]", allProfileFeatures.toString());
    }

    @Test
    public void testGetAllProfileFeatures_ForElse() throws Exception {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setBucketId("1000");

        List<TFOneAncillaryCodeConfig> ancillaryCodeFeatures = new ArrayList<>();
        TFOneAncillaryCodeConfig ancillaryCodeFeature = new TFOneAncillaryCodeConfig();
        ancillaryCodeFeature.setProfileId("10");
        ancillaryCodeFeature.setDisplaySUIFlag("Y");
        ancillaryCodeFeature.setToggleFlag("Y");
        ancillaryCodeFeature.setFeatureName("FEATURE_NAME");
        ancillaryCodeFeature.setFeatureRequirement("FEATURE_REQUIREMENT");
        ancillaryCodeFeature.setExtensionObjId("100");
        ancillaryCodeFeature.setFeatureValue("FEATURE_VALUE");
        ancillaryCodeFeatures.add(ancillaryCodeFeature);

        when(tracfoneProfileAction.getAncillaryCodeConfig(any())).thenReturn(ancillaryCodeFeatures);
        List<TFOneRatePlanExtensionConfig> allProfileFeatures = tracfoneServicePlanController.getAllProfileFeatures(tfServicePlanModel);
        assertEquals("[TFOneRatePlanExtensionConfig{objid=null, profileId=10, profileDescription=null, featureName=FEATURE_NAME, featureValue=FEATURE_VALUE, featureRequirement=FEATURE_REQUIREMENT, toggleFlag=Y, notes=null, displaySUIFlag=Y, restrictSUIFlag=null, rowNum=null, errorMessages={}, dbEnv=null}]", allProfileFeatures.toString());
    }

    @Test
    public void testGetAllProfileFeatures_whenException() throws Exception {
        try {
            tracfoneServicePlanController.getAllProfileFeatures(null);
            fail("Throws NPE which gets caught as a TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_GET_PROFILE_FEATURE_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_GET_PROFILE_FEATURE_ERROR_MESSAGE);
        }

        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setCarrierName("CARRIER_NAME");
        tfServicePlanModel.setBucketId("1000");
        doThrow(tracfoneOneException).when(tracfoneFeatureAction).getAllProfileFeatures(any());
        try {
            tracfoneServicePlanController.getAllProfileFeatures(tfServicePlanModel);
            fail("Throws NPE which gets caught as a TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_GET_PROFILE_FEATURE_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_GET_PROFILE_FEATURE_ERROR_MESSAGE);
        }
    }

    @Test
    public void testSearchCarrierProfileBuckets() throws Exception {
        List<TFOneCarrierProfileBucket> tfOneCarrierProfileBuckets = new ArrayList<>();
        TFOneCarrierProfileBucket tfOneBucket = new TFOneCarrierProfileBucket();
        tfOneBucket.setBucketId("1000");
        tfOneBucket.setActiveFlag("Y");
        tfOneBucket.setBucketRequirement("BUCKET_REQUIREMENT");
        tfOneCarrierProfileBuckets.add(tfOneBucket);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENT");
        tfServicePlanModel.setBucketRequirement("BUCKET_REQUIREMENT");
        tfServicePlanModel.setBucketId("1000");
        when(tracfoneBucketAction.searchCarrierProfileBuckets(any(TracfoneOneSearchBucketModel.class))).thenReturn(tfOneCarrierProfileBuckets);
        List<TFOneCarrierProfileBucket> tfOneBucketLists = tracfoneServicePlanController.searchCarrierProfileBuckets(tfServicePlanModel);
        assertEquals(tfOneBucketLists.size(), tfOneCarrierProfileBuckets.size());
        assertEquals(tfOneBucketLists.get(0).getBucketId(), tfOneBucketLists.get(0).getBucketId());
        assertEquals(tfOneBucketLists.get(0).getActiveFlag(), tfOneBucketLists.get(0).getActiveFlag());
    }

    @Test
    public void testSearchCarrierProfileBuckets_ForElseBlock() throws Exception {
        List<TFOneCarrierProfileBucket> tfOneCarrierProfileBuckets = new ArrayList<>();
        TFOneCarrierProfileBucket tfOneBucket = new TFOneCarrierProfileBucket();
        tfOneBucket.setBucketId("1000");
        tfOneBucket.setActiveFlag("Y");
        tfOneBucket.setBucketRequirement("BUCKET_REQUIREMENT");
        tfOneCarrierProfileBuckets.add(tfOneBucket);

        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENT");

        when(tracfoneBucketAction.searchCarrierProfileBuckets(any(TracfoneOneSearchBucketModel.class))).thenReturn(tfOneCarrierProfileBuckets);
        List<TFOneCarrierProfileBucket> tfOneBucketLists = tracfoneServicePlanController.searchCarrierProfileBuckets(tfServicePlanModel);
        assertEquals(tfOneBucketLists.size(), tfOneCarrierProfileBuckets.size());
        assertEquals(tfOneBucketLists.get(0).getBucketId(), tfOneBucketLists.get(0).getBucketId());
        assertEquals(tfOneBucketLists.get(0).getActiveFlag(), tfOneBucketLists.get(0).getActiveFlag());
    }

    @Test
    public void testSearchCarrierProfileBuckets_BucketRequirementNullElseBlock() throws Exception {
        List<TFOneCarrierProfileBucket> tfOneCarrierProfileBuckets = new ArrayList<>();
        TFOneCarrierProfileBucket tfOneBucket = new TFOneCarrierProfileBucket();
        tfOneBucket.setBucketId("1000");
        tfOneBucket.setActiveFlag("Y");
        tfOneBucket.setBucketRequirement("BUCKET_REQUIREMENT");
        tfOneCarrierProfileBuckets.add(tfOneBucket);

        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENT");
        tfServicePlanModel.setBucketId("1000");

        when(tracfoneBucketAction.searchCarrierProfileBuckets(any(TracfoneOneSearchBucketModel.class))).thenReturn(tfOneCarrierProfileBuckets);
        List<TFOneCarrierProfileBucket> tfOneBucketLists = tracfoneServicePlanController.searchCarrierProfileBuckets(tfServicePlanModel);
        assertEquals(tfOneBucketLists.size(), tfOneCarrierProfileBuckets.size());
        assertEquals(tfOneBucketLists.get(0).getBucketId(), tfOneBucketLists.get(0).getBucketId());
        assertEquals(tfOneBucketLists.get(0).getActiveFlag(), tfOneBucketLists.get(0).getActiveFlag());
    }

    @Test
    public void testSearchCarrierProfileBuckets_filterBucketsElseIfBlock() throws Exception {
        List<TFOneCarrierProfileBucket> tfOneCarrierProfileBuckets = new ArrayList<>();
        TFOneCarrierProfileBucket tfOneBucket = new TFOneCarrierProfileBucket();
        tfOneBucket.setBucketId("1000");
        tfOneBucket.setActiveFlag("Y");
        tfOneBucket.setBucketRequirement("BUCKET_REQUIREMENT");
        tfOneCarrierProfileBuckets.add(tfOneBucket);

        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENT");
        tfServicePlanModel.setBucketRequirement("BUCKET_REQUIREMENT");

        when(tracfoneBucketAction.searchCarrierProfileBuckets(any(TracfoneOneSearchBucketModel.class))).thenReturn(tfOneCarrierProfileBuckets);
        List<TFOneCarrierProfileBucket> tfOneBucketLists = tracfoneServicePlanController.searchCarrierProfileBuckets(tfServicePlanModel);
        assertEquals(tfOneBucketLists.size(), tfOneCarrierProfileBuckets.size());
        assertEquals(tfOneBucketLists.get(0).getBucketId(), tfOneBucketLists.get(0).getBucketId());
        assertEquals(tfOneBucketLists.get(0).getActiveFlag(), tfOneBucketLists.get(0).getActiveFlag());
    }

    @Test
    public void testSearchCarrierProfileBuckets_whenException() throws Exception {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        doThrow(tracfoneOneException).when(tracfoneBucketAction).searchCarrierProfileBuckets(any(TracfoneOneSearchBucketModel.class));
        try {
            tracfoneServicePlanController.searchCarrierProfileBuckets(tfServicePlanModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_CP_BUCKETS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_CP_BUCKETS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierProfileChildBuckets() throws Exception {
        List<TFOneCarrierProfileChildBucket> tfOneCarrierProfileChildBucketList = new ArrayList<>();
        TFOneCarrierProfileChildBucket tfOneCarrierProfileChildBucket = new TFOneCarrierProfileChildBucket();
        tfOneCarrierProfileChildBucket.setBucketId("1000");
        tfOneCarrierProfileChildBucket.setActiveFlag("Y");
        tfOneCarrierProfileChildBucket.setBucketRequirement("BUCKET_REQUIREMENT");
        tfOneCarrierProfileChildBucketList.add(tfOneCarrierProfileChildBucket);

        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENT");
        tfServicePlanModel.setBucketRequirement("BUCKET_REQUIREMENT");
        tfServicePlanModel.setBucketId("1000");

        when(tracfoneBucketAction.searchCarrierProfileChildBuckets(any(TracfoneOneSearchBucketModel.class))).thenReturn(tfOneCarrierProfileChildBucketList);
        List<TFOneCarrierProfileChildBucket> response = tracfoneServicePlanController.searchCarrierProfileChildBuckets(tfServicePlanModel);
        assertEquals(tfOneCarrierProfileChildBucketList.size(), response.size());
        assertEquals(tfOneCarrierProfileChildBucketList.get(0).getBucketId(), response.get(0).getBucketId());
        assertEquals(tfOneCarrierProfileChildBucketList.get(0).getActiveFlag(), response.get(0).getActiveFlag());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets_filterChildBucketsBucketReqNull() throws Exception {
        List<TFOneCarrierProfileChildBucket> tfOneCarrierProfileChildBucketList = new ArrayList<>();
        TFOneCarrierProfileChildBucket tfOneCarrierProfileChildBucket = new TFOneCarrierProfileChildBucket();
        tfOneCarrierProfileChildBucket.setBucketId("1000");
        tfOneCarrierProfileChildBucket.setActiveFlag("Y");
        tfOneCarrierProfileChildBucket.setBucketRequirement("BUCKET_REQUIREMENT");
        tfOneCarrierProfileChildBucketList.add(tfOneCarrierProfileChildBucket);

        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENT");
        tfServicePlanModel.setBucketId("1000");

        when(tracfoneBucketAction.searchCarrierProfileChildBuckets(any(TracfoneOneSearchBucketModel.class))).thenReturn(tfOneCarrierProfileChildBucketList);
        List<TFOneCarrierProfileChildBucket> response = tracfoneServicePlanController.searchCarrierProfileChildBuckets(tfServicePlanModel);
        assertEquals(tfOneCarrierProfileChildBucketList.size(), response.size());
        assertEquals(tfOneCarrierProfileChildBucketList.get(0).getBucketId(), response.get(0).getBucketId());
        assertEquals(tfOneCarrierProfileChildBucketList.get(0).getActiveFlag(), response.get(0).getActiveFlag());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets_filterChildBucketsElseIfBlock() throws Exception {
        List<TFOneCarrierProfileChildBucket> tfOneCarrierProfileChildBucketList = new ArrayList<>();
        TFOneCarrierProfileChildBucket tfOneCarrierProfileChildBucket = new TFOneCarrierProfileChildBucket();
        tfOneCarrierProfileChildBucket.setBucketId("1000");
        tfOneCarrierProfileChildBucket.setActiveFlag("Y");
        tfOneCarrierProfileChildBucket.setBucketRequirement("BUCKET_REQUIREMENT");
        tfOneCarrierProfileChildBucketList.add(tfOneCarrierProfileChildBucket);

        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENT");
        tfServicePlanModel.setBucketRequirement("BUCKET_REQUIREMENT");

        when(tracfoneBucketAction.searchCarrierProfileChildBuckets(any(TracfoneOneSearchBucketModel.class))).thenReturn(tfOneCarrierProfileChildBucketList);
        List<TFOneCarrierProfileChildBucket> response = tracfoneServicePlanController.searchCarrierProfileChildBuckets(tfServicePlanModel);
        assertEquals(tfOneCarrierProfileChildBucketList.size(), response.size());
        assertEquals(tfOneCarrierProfileChildBucketList.get(0).getBucketId(), response.get(0).getBucketId());
        assertEquals(tfOneCarrierProfileChildBucketList.get(0).getActiveFlag(), response.get(0).getActiveFlag());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets_ElseBlock() throws Exception {
        List<TFOneCarrierProfileChildBucket> tfOneCarrierProfileChildBucketList = new ArrayList<>();
        TFOneCarrierProfileChildBucket tfOneCarrierProfileChildBucket = new TFOneCarrierProfileChildBucket();
        tfOneCarrierProfileChildBucket.setBucketId("1000");
        tfOneCarrierProfileChildBucket.setActiveFlag("Y");
        tfOneCarrierProfileChildBucket.setBucketRequirement("BUCKET_REQUIREMENT");
        tfOneCarrierProfileChildBucketList.add(tfOneCarrierProfileChildBucket);

        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setFeatureRequirement("FEATURE_REQUIREMENT");

        when(tracfoneBucketAction.searchCarrierProfileChildBuckets(any(TracfoneOneSearchBucketModel.class))).thenReturn(tfOneCarrierProfileChildBucketList);
        List<TFOneCarrierProfileChildBucket> response = tracfoneServicePlanController.searchCarrierProfileChildBuckets(tfServicePlanModel);
        assertEquals(tfOneCarrierProfileChildBucketList.size(), response.size());
        assertEquals(tfOneCarrierProfileChildBucketList.get(0).getBucketId(), response.get(0).getBucketId());
        assertEquals(tfOneCarrierProfileChildBucketList.get(0).getActiveFlag(), response.get(0).getActiveFlag());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets_ForInnerElse() throws Exception {
        List<TFOneCarrierProfileChildBucket> tfOneCarrierProfileChildBucketList = new ArrayList<>();
        TFOneCarrierProfileChildBucket tfOneCarrierProfileChildBucket = new TFOneCarrierProfileChildBucket();
        tfOneCarrierProfileChildBucket.setActiveFlag("Y");
        tfOneCarrierProfileChildBucket.setBucketId("10");
        tfOneCarrierProfileChildBucket.setBucketRequirement("BUCKET_REQUIREMENT");
        tfOneCarrierProfileChildBucketList.add(tfOneCarrierProfileChildBucket);
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        tfServicePlanModel.setDbEnv(DBENV);
        tfServicePlanModel.setFeatureName("FEATURE_NAME");
        tfServicePlanModel.setBucketRequirement("BUCKET_REQUIREMENT");
        tfServicePlanModel.setBucketId("10");
        when(tracfoneBucketAction.searchCarrierProfileChildBuckets(any(TracfoneOneSearchBucketModel.class))).thenReturn(tfOneCarrierProfileChildBucketList);
        List<TFOneCarrierProfileChildBucket> response = tracfoneServicePlanController.searchCarrierProfileChildBuckets(tfServicePlanModel);
        assertEquals(tfOneCarrierProfileChildBucketList.get(0).getBucketId(), response.get(0).getBucketId());
        assertEquals(tfOneCarrierProfileChildBucketList.get(0).getActiveFlag(), response.get(0).getActiveFlag());
    }

    @Test
    public void testSearchCarrierProfileChildBuckets_whenException() throws Exception {
        TracfoneOneSearchServicePlanModel tfServicePlanModel = new TracfoneOneSearchServicePlanModel();
        doThrow(tracfoneOneException).when(tracfoneBucketAction).searchCarrierProfileChildBuckets(any(TracfoneOneSearchBucketModel.class));
        try {
            tracfoneServicePlanController.searchCarrierProfileChildBuckets(tfServicePlanModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllServicePlanCarrierNames() throws Exception {
        List<String> carrierNames = new ArrayList<>();
        carrierNames.add("T-MOBILE");
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setServicePlanId("81");
        when(tracfoneServicePlanAction.getAllServicePlanCarrierNames(anyString(), anyString(), anyBoolean())).thenReturn(carrierNames);
        List<String> response = tracfoneServicePlanController.getAllServicePlanCarrierNames(tracfoneOneSearchPlanModel);
        assertEquals(response.toString(), carrierNames.toString());
    }

    @Test
    public void testGetAllServicePlanCarrierNames_whenException() {
        try {
            tracfoneServicePlanController.getAllServicePlanCarrierNames(null);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_SERVICE_PLAN_CARRIERS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_SERVICE_PLAN_CARRIERS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetServicePlansForCopy() throws Exception {
        List<TFOneCarrierServicePlan> servicePlans = new ArrayList<>();
        TFOneCarrierServicePlan servicePlan = new TFOneCarrierServicePlan();
        servicePlan.setMktName("MKT_NAME");
        servicePlans.add(servicePlan);

        when(tracfoneServicePlanAction.getServicePlansForCopy(any())).thenReturn(servicePlans);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setCarrierName("185");
        List<TFOneCarrierServicePlan> response = tracfoneServicePlanController.getServicePlansForCopy(tracfoneOneSearchPlanModel);
        assertEquals("[TFOneCarrierServicePlan{carrierName='null', servicePlanId='null', mktName='MKT_NAME', description='null', servicePlanPurchase='null', parentName='null', servicePlans=null}]", response.toString());
    }

    @Test
    public void testGetServicePlansForCopy_whenException() throws Exception {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setCarrierName("185");
        doThrow(tracfoneOneException).when(tracfoneServicePlanAction).getServicePlansForCopy(any());
        try {
            tracfoneServicePlanController.getServicePlansForCopy(tracfoneOneSearchPlanModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_SERVICE_PLAN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_SERVICE_PLAN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}
