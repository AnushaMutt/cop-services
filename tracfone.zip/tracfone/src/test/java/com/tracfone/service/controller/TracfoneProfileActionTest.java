package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneAncillaryCode;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeConfig;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeDiscount;
import com.tracfone.service.model.request.TracfoneOneChildPlan;
import com.tracfone.service.model.request.TracfoneOneLineStatusCode;
import com.tracfone.service.model.request.TracfoneOneMultiRatePlanEsn;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtension;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionLink;
import com.tracfone.service.model.request.TracfoneOneRatePlanProfile;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneThrottleStatusCode;
import com.tracfone.service.model.response.TFOneAncillaryCode;
import com.tracfone.service.model.response.TFOneAncillaryCodeConfig;
import com.tracfone.service.model.response.TFOneAncillaryCodeDiscount;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneMultiRatePlanEsn;
import com.tracfone.service.model.response.TFOneRatePlanExtension;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_ANCILLARY_CODE_CONFIG_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_ANCILLARY_CODE_CONFIG_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneProfileActionTest {
    private static final String DBENV = "DBENV";
    @InjectMocks
    private TracfoneProfileAction tracfoneProfileAction;
    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private ResultSet resultSet;
    @Mock
    private TFOneGeneralResponse tfOneGeneralResponse;
    private List<String> idsToBeDeleted;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        idsToBeDeleted = new ArrayList<>();
        idsToBeDeleted.add("100");
        idsToBeDeleted.add("200");
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

    @Test
    public void testInsertProfile() throws Exception {
        TracfoneOneRatePlanProfile tfRatePlanProfile = new TracfoneOneRatePlanProfile();
        tfRatePlanProfile.setProfileDescription("desc");
        tfRatePlanProfile.setDbEnv(DBENV);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("1");
        tfOneGeneralResponse = tracfoneProfileAction.insertProfile(tfRatePlanProfile, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "1");
    }

    @Test
    public void testInsertProfile_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneProfileAction.insertProfile(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneRatePlanProfile tfRatePlanProfile = new TracfoneOneRatePlanProfile();
        tfRatePlanProfile.setDbEnv(DBENV);
        tfRatePlanProfile.setProfileDescription("desc");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneProfileAction.insertProfile(tfRatePlanProfile, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testViewProfile() throws TracfoneOneException, SQLException {
        TracfoneOneRatePlanProfile tfRatePlanProfile = new TracfoneOneRatePlanProfile();
        tfRatePlanProfile.setProfileId("70");
        tfRatePlanProfile.setProfileDescription("desc");
        tfRatePlanProfile.setDbEnv(DBENV);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("PROFILE_ID").thenReturn("DESCRIPTION");
        TFOneRatePlanProfile tfOneRatePlanProfile = tracfoneProfileAction.viewProfile(tfRatePlanProfile);
        assertNotNull(tfOneRatePlanProfile);
        assertEquals("TFOneRatePlanProfile{profileId=PROFILE_ID, profileDescription=DESCRIPTION, rpExtensionLinks=null, rpExtensionConfigs=null, buckets=null, features=null}", tfOneRatePlanProfile.toString());
    }

    @Test
    public void testViewProfile_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            TFOneRatePlanProfile tfOneRatePlanProfile = tracfoneProfileAction.viewProfile(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneRatePlanProfile tfRatePlanProfile = new TracfoneOneRatePlanProfile();
        tfRatePlanProfile.setProfileId("70");
        tfRatePlanProfile.setProfileDescription("desc");
        tfRatePlanProfile.setDbEnv(DBENV);
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.viewProfile(tfRatePlanProfile);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateProfile() throws TracfoneOneException {
        TracfoneOneRatePlanProfile tfRatePlanProfile = new TracfoneOneRatePlanProfile();
        tfRatePlanProfile.setProfileId("70");
        tfRatePlanProfile.setProfileDescription("desc");
        tfRatePlanProfile.setDbEnv(DBENV);
        tfOneGeneralResponse = tracfoneProfileAction.updateProfile(tfRatePlanProfile, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfRatePlanProfile.getProfileId());
    }

    @Test
    public void testUpdateProfile_whenException() throws SQLException, TracfoneOneException {
        // When null is passed
        try {
            tracfoneProfileAction.updateProfile(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        TracfoneOneRatePlanProfile tfRatePlanProfile = new TracfoneOneRatePlanProfile();
        tfRatePlanProfile.setProfileId("70");
        tfRatePlanProfile.setProfileDescription("desc");
        tfRatePlanProfile.setDbEnv(DBENV);
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.updateProfile(tfRatePlanProfile, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteProfile() throws TracfoneOneException {
        tfOneGeneralResponse = tracfoneProfileAction.deleteProfile(DBENV, idsToBeDeleted, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), idsToBeDeleted.toString());
    }

    @Test
    public void testDeleteProfile_whenException() throws TracfoneOneException, SQLException {
        // When dbEnv is null
        try {
            tracfoneProfileAction.deleteProfile(null, idsToBeDeleted, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.deleteProfile(DBENV, idsToBeDeleted, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllAncillaryCodes() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("ANCILLARY_CODE").thenReturn("DESCRIPTION");
        List<TFOneAncillaryCode> ancillaryCodes = tracfoneProfileAction.getAllAncillaryCodes(DBENV);
        assertNotNull(ancillaryCodes);
        assertEquals(1, ancillaryCodes.size());
        assertEquals("[TFOneAncillaryCode{ancillaryCode=ANCILLARY_CODE, description=DESCRIPTION}]", ancillaryCodes.toString());
    }

    @Test
    public void testGetAllAncillaryCodes_whenException() throws TracfoneOneException, SQLException {
        //When DBENV is null
        try {
            List<TFOneAncillaryCode> tfOneAncillaryCode = tracfoneProfileAction.getAllAncillaryCodes(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.getAllAncillaryCodes(DBENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllChildPlans() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("CHILD_ID").thenReturn("CHILD_DESCRIPTION");
        List<TFOneChildPlan> tfChildPlans = tracfoneProfileAction.getAllChildPlans(DBENV);
        assertNotNull(tfChildPlans);
        assertEquals(1, tfChildPlans.size());
        assertEquals("[TFOneChildPlan{childPlanId=CHILD_ID, childDescription=CHILD_DESCRIPTION}]", tfChildPlans.toString());
    }

    @Test
    public void tsetGetAllChildPlans_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            List<TFOneChildPlan> tfChildPlans = tracfoneProfileAction.getAllChildPlans(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.getAllChildPlans(DBENV);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchProfile() throws TracfoneOneException, SQLException {
        TracfoneOneSearchProfileModel tfRatePlanProfile = new TracfoneOneSearchProfileModel();
        tfRatePlanProfile.setProfileId("70");
        tfRatePlanProfile.setProfileDesc("desc");
        tfRatePlanProfile.setDbEnv(DBENV);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("ANCILLARY_CODE").thenReturn("DESCRIPTION");
        List<TFOneRatePlanProfile> tfOneRatePlanProfile = tracfoneProfileAction.searchProfile(tfRatePlanProfile);
        assertNotNull(tfOneRatePlanProfile);
        assertEquals(1, tfOneRatePlanProfile.size());
        assertEquals("[TFOneRatePlanProfile{profileId=ANCILLARY_CODE, profileDescription=DESCRIPTION, rpExtensionLinks=null, rpExtensionConfigs=null, buckets=null, features=null}]", tfOneRatePlanProfile.toString());
    }

    @Test
    public void testSearchProfile_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.searchProfile(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneSearchProfileModel tfRatePlanProfile = new TracfoneOneSearchProfileModel();
        tfRatePlanProfile.setProfileId("70");
        tfRatePlanProfile.setProfileDesc("desc");
        tfRatePlanProfile.setDbEnv(DBENV);
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.searchProfile(tfRatePlanProfile);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchForUnlinkedProfiles() throws TracfoneOneException, SQLException {
        TracfoneOneSearchProfileModel tfSearchProfileModel = new TracfoneOneSearchProfileModel();
        tfSearchProfileModel.setDbEnv(DBENV);
        tfSearchProfileModel.setFeatureName("name");
        tfSearchProfileModel.setFeatureValue("04");
        tfSearchProfileModel.setProfileDesc("desc");
        tfSearchProfileModel.setProfileId("75");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("PROFILE_ID").thenReturn("PROFILE_DESC");
        List<TFOneRatePlanProfile> tfOneRatePlanProfile = tracfoneProfileAction.searchProfilesForUpdate(tfSearchProfileModel);
        assertNotNull(tfOneRatePlanProfile);
        assertEquals(1, tfOneRatePlanProfile.size());
        assertEquals("[TFOneRatePlanProfile{profileId=PROFILE_ID, profileDescription=PROFILE_DESC, rpExtensionLinks=null, rpExtensionConfigs=null, buckets=null, features=null}]", tfOneRatePlanProfile.toString());
    }

    @Test
    public void testSearchForUnlinkedProfiles_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.searchProfilesForUpdate(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneSearchProfileModel tfSearchProfileModel = new TracfoneOneSearchProfileModel();
        tfSearchProfileModel.setDbEnv(DBENV);
        tfSearchProfileModel.setFeatureName("name");
        tfSearchProfileModel.setFeatureValue("04");
        tfSearchProfileModel.setProfileDesc("desc");
        tfSearchProfileModel.setProfileId("75");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.searchProfilesForUpdate(tfSearchProfileModel);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testUpdateChildPlan() throws TracfoneOneException {
        TracfoneOneChildPlan tfOneChildPlan = new TracfoneOneChildPlan();
        tfOneChildPlan.setDbEnv(DBENV);
        tfOneChildPlan.setChildPlanId("70");
        tfOneChildPlan.setChildDescription("DESC");
        tfOneGeneralResponse = tracfoneProfileAction.updateChildPlan(tfOneChildPlan, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfOneChildPlan.getChildPlanId());
    }

    @Test
    public void testUpdateCarrierProfileBucketTier_withException() throws SQLException, TracfoneOneException {
        // When null is passed
        try {
            tracfoneProfileAction.updateChildPlan(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        TracfoneOneChildPlan tfOneChildPlan = new TracfoneOneChildPlan();
        tfOneChildPlan.setDbEnv(DBENV);
        tfOneChildPlan.setChildPlanId("70");
        tfOneChildPlan.setChildDescription("DESC");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.updateChildPlan(tfOneChildPlan, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testInsertChildPlan() throws TracfoneOneException, SQLException {
        TracfoneOneChildPlan tfOneChildPlan = new TracfoneOneChildPlan();
        tfOneChildPlan.setDbEnv(DBENV);
        tfOneChildPlan.setChildPlanId("25");
        tfOneChildPlan.setChildDescription("desc");
        tfOneGeneralResponse = tracfoneProfileAction.insertChildPlan(tfOneChildPlan, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfOneChildPlan.getChildPlanId());
    }

    @Test
    public void testInsertChildPlan_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.insertChildPlan(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneChildPlan tfOneChildPlan = new TracfoneOneChildPlan();
        tfOneChildPlan.setDbEnv(DBENV);
        tfOneChildPlan.setChildPlanId("25");
        tfOneChildPlan.setChildDescription("desc");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.insertChildPlan(tfOneChildPlan, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteChildPlan() throws TracfoneOneException {
        TracfoneOneChildPlan tfOneChildPlan = new TracfoneOneChildPlan();
        tfOneChildPlan.setDbEnv(DBENV);
        tfOneChildPlan.setChildPlanId("10");
        tfOneChildPlan.setChildDescription("desc");
        tfOneGeneralResponse = tracfoneProfileAction.deleteChildPlan(tfOneChildPlan, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfOneChildPlan.getChildPlanId());
    }

    @Test
    public void testDeleteChildPlan_whenException() throws TracfoneOneException, SQLException {
        // When null is passed
        try {
            tracfoneProfileAction.deleteChildPlan(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        TracfoneOneChildPlan tfOneChildPlan = new TracfoneOneChildPlan();
        tfOneChildPlan.setDbEnv(DBENV);
        tfOneChildPlan.setChildPlanId("10");
        tfOneChildPlan.setChildDescription("desc");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.deleteChildPlan(tfOneChildPlan, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testViewChildPlan() throws TracfoneOneException, SQLException {
        TracfoneOneChildPlan tfOneChildPlan = new TracfoneOneChildPlan();
        tfOneChildPlan.setDbEnv(DBENV);
        tfOneChildPlan.setChildPlanId("70");
        tfOneChildPlan.setChildDescription("DESC");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("PROFILE_ID").thenReturn("PROFILE_DESC");
        TFOneChildPlan tfOneChildPlans = tracfoneProfileAction.viewChildPlan(tfOneChildPlan);
        assertNotNull(tfOneChildPlan);
        assertEquals("TracfoneOneChildIdentifierList{dbEnv=DBENV, childPlanId=70, childDescription=DESC}", tfOneChildPlan.toString());
    }

    @Test
    public void testViewChildPlan_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            TFOneChildPlan tfOneChildPlan = tracfoneProfileAction.viewChildPlan(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneChildPlan tfOneChildPlan = new TracfoneOneChildPlan();
        tfOneChildPlan.setDbEnv(DBENV);
        tfOneChildPlan.setChildPlanId("70");
        tfOneChildPlan.setChildDescription("DESC");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.viewChildPlan(tfOneChildPlan);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testCheckChildPlanDependencies() throws TracfoneOneException, SQLException {
        boolean dependencyExists = false;
        int count = 1;
        TracfoneOneChildPlan tfOneChildPlan = new TracfoneOneChildPlan();
        tfOneChildPlan.setDbEnv(DBENV);
        tfOneChildPlan.setChildPlanId("34");
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn(count).when(resultSet).getInt(1);
        dependencyExists = tracfoneProfileAction.checkChildPlanDependencies(tfOneChildPlan);
        assertTrue(dependencyExists);
    }

    @Test
    public void testCheckChildPlanDependencies_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        boolean dependencyExists = false;
        try {
            dependencyExists = tracfoneProfileAction.checkChildPlanDependencies(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneChildPlan tfOneChildPlan = new TracfoneOneChildPlan();
        tfOneChildPlan.setDbEnv(DBENV);
        tfOneChildPlan.setChildPlanId("34");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.checkChildPlanDependencies(tfOneChildPlan);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteAncillaryCode() throws TracfoneOneException {
        TracfoneOneAncillaryCode tfOneAncillaryCode = new TracfoneOneAncillaryCode();
        tfOneAncillaryCode.setDbEnv(DBENV);
        tfOneAncillaryCode.setAncillaryCode("10");
        tfOneAncillaryCode.setDescription("desc");
        tfOneGeneralResponse = tracfoneProfileAction.deleteAncillaryCode(tfOneAncillaryCode, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfOneAncillaryCode.getAncillaryCode());
    }

    @Test
    public void testDeleteAncillaryCode_whenException() throws TracfoneOneException, SQLException {
        // When null is passed
        try {
            tracfoneProfileAction.deleteAncillaryCode(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        TracfoneOneAncillaryCode tfOneAncillaryCode = new TracfoneOneAncillaryCode();
        tfOneAncillaryCode.setDbEnv(DBENV);
        tfOneAncillaryCode.setAncillaryCode("10");
        tfOneAncillaryCode.setDescription("desc");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneProfileAction.deleteAncillaryCode(tfOneAncillaryCode, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testCheckAncillaryCodeDependencies() throws TracfoneOneException, SQLException {
        boolean dependencyExists = false;
        int count = 1;
        TracfoneOneRatePlanExtension tfOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tfOneRatePlanExtension.setDbEnv(DBENV);
        tfOneRatePlanExtension.setAncillaryCode("ANCILLARY_CODE");
        tfOneRatePlanExtension.setLineStatusCode("LINE_STATUS_CODE");
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn(count).when(resultSet).getInt(1);
        dependencyExists = tracfoneProfileAction.checkRpExtensionCodeDependencies(tfOneRatePlanExtension);
        assertTrue(dependencyExists);
    }

    @Test
    public void testCheckAncillaryCodeDependencies_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        boolean dependencyExists = false;
        try {
            dependencyExists = tracfoneProfileAction.checkRpExtensionCodeDependencies(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneRatePlanExtension tfOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tfOneRatePlanExtension.setDbEnv(DBENV);
        tfOneRatePlanExtension.setAncillaryCode("ANCILLARY_CODE");
        tfOneRatePlanExtension.setLineStatusCode("LINE_STATUS_CODE");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.checkRpExtensionCodeDependencies(tfOneRatePlanExtension);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testSearchAncillaryCodes() throws TracfoneOneException, SQLException {
        TracfoneOneAncillaryCode tfOneAncillaryCode = new TracfoneOneAncillaryCode();
        tfOneAncillaryCode.setAncillaryCode("10");
        tfOneAncillaryCode.setDescription("desc");
        tfOneAncillaryCode.setDbEnv(DBENV);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("ANCILLARY_CODE").thenReturn("DESCRIPTION");
        List<TFOneAncillaryCode> ancillaryCodes = tracfoneProfileAction.searchAncillaryCodes(tfOneAncillaryCode);
        assertNotNull(ancillaryCodes);
        assertEquals(1, ancillaryCodes.size());
        assertEquals("[TFOneAncillaryCode{ancillaryCode=ANCILLARY_CODE, description=DESCRIPTION}]", ancillaryCodes.toString());
    }

    @Test
    public void testSearchAncillaryCodes_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.searchAncillaryCodes(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneAncillaryCode tfOneAncillaryCode = new TracfoneOneAncillaryCode();
        tfOneAncillaryCode.setAncillaryCode("10");
        tfOneAncillaryCode.setDescription("desc");
        tfOneAncillaryCode.setDbEnv(DBENV);
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.searchAncillaryCodes(tfOneAncillaryCode);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateAncillaryCode() throws TracfoneOneException {
        TracfoneOneAncillaryCode ancillaryCode = new TracfoneOneAncillaryCode();
        ancillaryCode.setDbEnv(DBENV);
        ancillaryCode.setAncillaryCode("SAMPLE");
        ancillaryCode.setDescription("DESCRIPTION");
        tfOneGeneralResponse = tracfoneProfileAction.updateAncillaryCode(ancillaryCode, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), ancillaryCode.getAncillaryCode());
    }

    @Test
    public void testUpdateAncillaryCode_whenException() throws SQLException, TracfoneOneException {
        // When null is passed
        try {
            tracfoneProfileAction.updateAncillaryCode(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        TracfoneOneAncillaryCode ancillaryCode = new TracfoneOneAncillaryCode();
        ancillaryCode.setDbEnv(DBENV);
        ancillaryCode.setAncillaryCode("SAMPLE");
        ancillaryCode.setDescription("DESCRIPTION");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.updateAncillaryCode(ancillaryCode, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertAncillaryCode() throws TracfoneOneException, SQLException {
        TracfoneOneAncillaryCode tfOneAncillaryCode = new TracfoneOneAncillaryCode();
        tfOneAncillaryCode.setDbEnv(DBENV);
        tfOneAncillaryCode.setDescription("desc");
        tfOneAncillaryCode.setAncillaryCode("25");
        tfOneGeneralResponse = tracfoneProfileAction.insertAncillaryCode(tfOneAncillaryCode, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfOneAncillaryCode.getAncillaryCode());
    }

    @Test
    public void testInsertAncillaryCode_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.insertAncillaryCode(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneAncillaryCode tfOneAncillaryCode = new TracfoneOneAncillaryCode();
        tfOneAncillaryCode.setDbEnv(DBENV);
        tfOneAncillaryCode.setDescription("desc");
        tfOneAncillaryCode.setAncillaryCode("25");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneProfileAction.insertAncillaryCode(tfOneAncillaryCode, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchRpExtensions() throws TracfoneOneException, SQLException {
        TracfoneOneRatePlanExtension tfOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tfOneRatePlanExtension.setAncillaryCode("10");
        tfOneRatePlanExtension.setDbEnv(DBENV);
        tfOneRatePlanExtension.setLineStatusCode("25");
        tfOneRatePlanExtension.setThrottleStatusCode("70");
        tfOneRatePlanExtension.setObjId("obj");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("ANCILLARY_CODE").thenReturn("OBJID").thenReturn("THROTTLE_STATUS_CODE").thenReturn("LINE_STATUS_CODE");
        List<TFOneRatePlanExtension> ratePlanExtension = tracfoneProfileAction.searchRpExtensions(tfOneRatePlanExtension);
        assertNotNull(ratePlanExtension);
        assertEquals(1, ratePlanExtension.size());
        assertEquals("[TFOneRatePlanExtension{objId=OBJID, lineStatusCode=LINE_STATUS_CODE, throttleStatusCode=THROTTLE_STATUS_CODE, ancillaryCode=ANCILLARY_CODE}]", ratePlanExtension.toString());
    }

    @Test
    public void testSearchRpExtensions_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.searchRpExtensions(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneRatePlanExtension tfRatePlanExtension = new TracfoneOneRatePlanExtension();
        tfRatePlanExtension.setObjId("25");
        tfRatePlanExtension.setThrottleStatusCode("15");
        tfRatePlanExtension.setLineStatusCode("50");
        tfRatePlanExtension.setDbEnv(DBENV);
        tfRatePlanExtension.setAncillaryCode("70");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.searchRpExtensions(tfRatePlanExtension);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testCheckRpExtensionDependencies() throws TracfoneOneException, SQLException {
        boolean dependencyExists = false;
        int count = 1;
        TracfoneOneRatePlanExtension tfOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tfOneRatePlanExtension.setDbEnv(DBENV);
        tfOneRatePlanExtension.setLineStatusCode("10");
        tfOneRatePlanExtension.setThrottleStatusCode("70");
        tfOneRatePlanExtension.setAncillaryCode("25");
        tfOneRatePlanExtension.setObjId("50");
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn(count).when(resultSet).getInt(1);
        dependencyExists = tracfoneProfileAction.checkRpExtensionDependencies(tfOneRatePlanExtension);
        assertTrue(dependencyExists);
    }

    @Test
    public void testCheckRpExtensionDependencies_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        boolean dependencyExists = false;
        try {
            dependencyExists = tracfoneProfileAction.checkRpExtensionDependencies(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneRatePlanExtension tfOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tfOneRatePlanExtension.setDbEnv(DBENV);
        tfOneRatePlanExtension.setLineStatusCode("10");
        tfOneRatePlanExtension.setThrottleStatusCode("70");
        tfOneRatePlanExtension.setAncillaryCode("25");
        tfOneRatePlanExtension.setObjId("15");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.checkRpExtensionDependencies(tfOneRatePlanExtension);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteRpExtension() throws TracfoneOneException {
        TracfoneOneRatePlanExtension tfOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tfOneRatePlanExtension.setObjId("10");
        tfOneRatePlanExtension.setDbEnv(DBENV);
        tfOneRatePlanExtension.setThrottleStatusCode("07");
        tfOneRatePlanExtension.setLineStatusCode("25");
        tfOneRatePlanExtension.setAncillaryCode("70");
        tfOneGeneralResponse = tracfoneProfileAction.deleteRpExtension(tfOneRatePlanExtension, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfOneRatePlanExtension.getObjId());
    }

    @Test
    public void testDeleteRpExtension_whenException() throws TracfoneOneException, SQLException {
        // When null is passed
        try {
            tracfoneProfileAction.deleteRpExtension(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }

        // When SQLException is thrown
        TracfoneOneRatePlanExtension tfOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tfOneRatePlanExtension.setObjId("10");
        tfOneRatePlanExtension.setDbEnv(DBENV);
        tfOneRatePlanExtension.setThrottleStatusCode("07");
        tfOneRatePlanExtension.setLineStatusCode("25");
        tfOneRatePlanExtension.setAncillaryCode("70");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.deleteRpExtension(tfOneRatePlanExtension, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertRpExtension() throws TracfoneOneException, SQLException {
        TracfoneOneRatePlanExtension tfOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tfOneRatePlanExtension.setDbEnv(DBENV);
        tfOneRatePlanExtension.setObjId("10");
        tfOneRatePlanExtension.setAncillaryCode("25");
        tfOneRatePlanExtension.setLineStatusCode("50");
        tfOneRatePlanExtension.setThrottleStatusCode("70");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString("EXTENSION_ID_SEQ")).thenReturn("100");
        tfOneGeneralResponse = tracfoneProfileAction.insertRpExtension(tfOneRatePlanExtension, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "100");
    }

    @Test
    public void testInsertRpExtension_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.insertRpExtension(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneRatePlanExtension tfOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tfOneRatePlanExtension.setDbEnv(DBENV);
        tfOneRatePlanExtension.setObjId("10");
        tfOneRatePlanExtension.setAncillaryCode("25");
        tfOneRatePlanExtension.setLineStatusCode("50");
        tfOneRatePlanExtension.setThrottleStatusCode("70");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneProfileAction.insertRpExtension(tfOneRatePlanExtension, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertRpExtensionLink() throws TracfoneOneException, SQLException {
        TracfoneOneRatePlanExtensionLink tfRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfRpExtensionLink.setCarrierFeatureId("100");
        tfRpExtensionLink.setProfileId("100");
        tfRpExtensionLink.setRatePlanExtensionId("100");
        tfRpExtensionLink.setDbEnv(DBENV);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString("EXTENSION_LINKID_SEQ")).thenReturn("100");
        tfOneGeneralResponse = tracfoneProfileAction.insertRpExtensionLink(tfRpExtensionLink, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfRpExtensionLink.getObjId());
    }

    @Test
    public void testInsertRpExtensionLink_whenException() throws TracfoneOneException, SQLException {
        try {
            tracfoneProfileAction.insertRpExtensionLink(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        TracfoneOneRatePlanExtensionLink tfRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfRpExtensionLink.setCarrierFeatureId("100");
        tfRpExtensionLink.setProfileId("100");
        tfRpExtensionLink.setRatePlanExtensionId("100");
        tfRpExtensionLink.setDbEnv(DBENV);
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneProfileAction.insertRpExtensionLink(tfRpExtensionLink, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteRpExtensionLink() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionLink tfRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfRpExtensionLink.setCarrierFeatureId("100");
        tfRpExtensionLink.setProfileId("100");
        tfRpExtensionLink.setRatePlanExtensionId("100");
        tfRpExtensionLink.setDbEnv(DBENV);
        tfRpExtensionLink.setObjId("100");
        tfOneGeneralResponse = tracfoneProfileAction.deleteRpExtensionLink(tfRpExtensionLink, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfRpExtensionLink.getObjId());
    }

    @Test
    public void testDeleteRpExtensionLink_whenException() throws TracfoneOneException, SQLException {
        // When null is passed
        try {
            tracfoneProfileAction.deleteRpExtensionLink(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        TracfoneOneRatePlanExtensionLink tfRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfRpExtensionLink.setDbEnv(DBENV);
        tfRpExtensionLink.setProfileId("100");
        tfRpExtensionLink.setRatePlanExtensionId("100");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.deleteRpExtensionLink(tfRpExtensionLink, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateRpExtensionLink() throws TracfoneOneException {
        TracfoneOneRatePlanExtensionLink tfRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfRpExtensionLink.setCarrierFeatureId("100");
        tfRpExtensionLink.setObjId("100");
        tfRpExtensionLink.setRatePlanExtensionId("100");
        tfRpExtensionLink.setDbEnv(DBENV);
        tfOneGeneralResponse = tracfoneProfileAction.updateRpExtensionLink(tfRpExtensionLink, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfRpExtensionLink.getObjId());
    }

    @Test
    public void testUpdateRpExtensionLink_whenException() throws SQLException, TracfoneOneException {
        // When null is passed
        try {
            tracfoneProfileAction.updateRpExtensionLink(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        TracfoneOneRatePlanExtensionLink tfRpExtensionLink = new TracfoneOneRatePlanExtensionLink();
        tfRpExtensionLink.setCarrierFeatureId("100");
        tfRpExtensionLink.setRatePlanExtensionId("100");
        tfRpExtensionLink.setDbEnv(DBENV);
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.updateRpExtensionLink(tfRpExtensionLink, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetProfileServicePlans() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("500").thenReturn("SAFELINK");
        List<TFOneCarrierServicePlan> servicePlans = tracfoneProfileAction.getProfileServicePlans(DBENV, "100");
        assertEquals("[TFOneCarrierServicePlan{carrierName='null', servicePlanId='500', mktName='null', description='SAFELINK', servicePlanPurchase='null', parentName='null', servicePlans=null}]", servicePlans.toString());
    }

    @Test
    public void testGetProfileServicePlans_whenException() throws SQLException, TracfoneOneException {
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.getProfileServicePlans(DBENV, "100");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetRatePlanServicePlans() throws TracfoneOneException, SQLException {
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("500").thenReturn("SAFELINK");
        List<TFOneCarrierServicePlan> servicePlans = tracfoneProfileAction.getRatePlanServicePlans(DBENV, "RATE_PLAN_NAME");
        assertEquals("[TFOneCarrierServicePlan{carrierName='null', servicePlanId='500', mktName='null', description='SAFELINK', servicePlanPurchase='null', parentName='null', servicePlans=null}]", servicePlans.toString());
    }

    @Test
    public void testGetRatePlanServicePlans_whenException() throws SQLException, TracfoneOneException {
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.getRatePlanServicePlans(DBENV, "100");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertAncillaryCodeConfig() throws TracfoneOneException, SQLException {
        TracfoneOneAncillaryCodeConfig ancillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        ancillaryCodeConfig.setExtensionObjId("1000");
        ancillaryCodeConfig.setProfileId("1000");
        ancillaryCodeConfig.setDbEnv(DBENV);
        tfOneGeneralResponse = tracfoneProfileAction.insertAncillaryCodeConfig(ancillaryCodeConfig, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), ancillaryCodeConfig.getExtensionObjId());
    }

    @Test
    public void testInsertAncillaryCodeConfig_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.insertAncillaryCodeConfig(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneAncillaryCodeConfig ancillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        ancillaryCodeConfig.setExtensionObjId("100");
        ancillaryCodeConfig.setProfileId("1000");
        ancillaryCodeConfig.setDbEnv(DBENV);
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.insertAncillaryCodeConfig(ancillaryCodeConfig, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_ANCILLARY_CODE_CONFIG_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateAncillaryCodeConfig() throws TracfoneOneException, SQLException {
        TracfoneOneAncillaryCodeConfig ancillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        ancillaryCodeConfig.setExtensionObjId("1000");
        ancillaryCodeConfig.setProfileId("1000");
        ancillaryCodeConfig.setDbEnv(DBENV);
        tfOneGeneralResponse = tracfoneProfileAction.updateAncillaryCodeConfig(ancillaryCodeConfig, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), ancillaryCodeConfig.getExtensionObjId());
    }

    @Test
    public void testUpdateAncillaryCodeConfig_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.updateAncillaryCodeConfig(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneAncillaryCodeConfig ancillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        ancillaryCodeConfig.setExtensionObjId("100");
        ancillaryCodeConfig.setProfileId("1000");
        ancillaryCodeConfig.setDbEnv(DBENV);
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.updateAncillaryCodeConfig(ancillaryCodeConfig, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_ANCILLARY_CODE_CONFIG_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteAncillaryCodeConfig() throws TracfoneOneException, SQLException {
        TracfoneOneAncillaryCodeConfig ancillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        ancillaryCodeConfig.setExtensionObjId("1000");
        ancillaryCodeConfig.setProfileId("1000");
        ancillaryCodeConfig.setDbEnv(DBENV);
        tfOneGeneralResponse = tracfoneProfileAction.deleteAncillaryCodeConfig(ancillaryCodeConfig, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), ancillaryCodeConfig.getExtensionObjId());
    }

    @Test
    public void testDeleteAncillaryCodeConfig_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.deleteAncillaryCodeConfig(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneAncillaryCodeConfig ancillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        ancillaryCodeConfig.setExtensionObjId("100");
        ancillaryCodeConfig.setProfileId("1000");
        ancillaryCodeConfig.setDbEnv(DBENV);
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.deleteAncillaryCodeConfig(ancillaryCodeConfig, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAncillaryCodeConfig() throws TracfoneOneException, SQLException {
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        tfAncillaryCodeConfig.setDbEnv(DBENV);
        tfAncillaryCodeConfig.setProfileId("1000");
        tfAncillaryCodeConfig.setExtensionObjId("1000");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMY_VALUE");
        List<TFOneAncillaryCodeConfig> ancillaryCodes = tracfoneProfileAction.getAncillaryCodeConfig(tfAncillaryCodeConfig);
        assertNotNull(ancillaryCodes);
        assertEquals(1, ancillaryCodes.size());
        assertEquals("[TFOneAncillaryCodeConfig{extensionObjId='DUMMY_VALUE', profileId='DUMMY_VALUE', featureName='DUMMY_VALUE', featureValue='DUMMY_VALUE', featureRequirement='DUMMY_VALUE', toggleFlag='DUMMY_VALUE', notes='DUMMY_VALUE', restrictSUIFlag='DUMMY_VALUE', displaySUIFlag='DUMMY_VALUE'}]", ancillaryCodes.toString());
    }

    @Test
    public void testGetAncillaryCodeConfig_whenException() throws TracfoneOneException, SQLException {
        //When DBENV is null
        try {
            List<TFOneAncillaryCodeConfig> tfOneAncillaryCode = tracfoneProfileAction.getAncillaryCodeConfig(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig = new TracfoneOneAncillaryCodeConfig();
        tfAncillaryCodeConfig.setDbEnv(DBENV);
        tfAncillaryCodeConfig.setProfileId("1000");
        tfAncillaryCodeConfig.setExtensionObjId("1000");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.getAncillaryCodeConfig(tfAncillaryCodeConfig);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertAncillaryCodeDiscount() throws TracfoneOneException, SQLException {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        tfOneGeneralResponse = tracfoneProfileAction.insertAncillaryCodeDiscount(tfAncillaryCodeDiscount, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfAncillaryCodeDiscount.getAncillaryCode());
    }

    @Test
    public void testInsertAncillaryCodeDiscount_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.insertAncillaryCodeDiscount(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.insertAncillaryCodeDiscount(tfAncillaryCodeDiscount, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateAncillaryCodeDiscount() throws TracfoneOneException, SQLException {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        tfOneGeneralResponse = tracfoneProfileAction.updateAncillaryCodeDiscount(tfAncillaryCodeDiscount, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfAncillaryCodeDiscount.getAncillaryCode());
    }

    @Test
    public void testUpdateAncillaryCodeDiscount_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.updateAncillaryCodeDiscount(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.updateAncillaryCodeDiscount(tfAncillaryCodeDiscount, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteAncillaryCodeDiscount() throws TracfoneOneException, SQLException {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        tfOneGeneralResponse = tracfoneProfileAction.deleteAncillaryCodeDiscount(tfAncillaryCodeDiscount, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfAncillaryCodeDiscount.getAncillaryCode());
    }

    @Test
    public void testDeleteAncillaryCodeDiscount_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.deleteAncillaryCodeDiscount(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        // when SQLException occurs
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.deleteAncillaryCodeDiscount(tfAncillaryCodeDiscount, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchAncillaryCodeDiscount() throws TracfoneOneException, SQLException {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        tfAncillaryCodeDiscount.setNewBrmEquivalent("NEW_BRM_EQUIVALENT");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("DUMMY_VALUE");
        List<TFOneAncillaryCodeDiscount> ancillaryCodes = tracfoneProfileAction.searchAncillaryCodeDiscount(tfAncillaryCodeDiscount);
        assertNotNull(ancillaryCodes);
        assertEquals(1, ancillaryCodes.size());
        assertEquals("[TFOneAncillaryCodeDiscount{ancillaryCode='DUMMY_VALUE', brmEquivalent='DUMMY_VALUE'}]", ancillaryCodes.toString());
    }

    @Test
    public void testSearchAncillaryCodeDiscount_whenException() throws TracfoneOneException, SQLException {
        //When DBENV is null
        try {
            List<TFOneAncillaryCodeDiscount> tfOneAncillaryCode = tracfoneProfileAction.searchAncillaryCodeDiscount(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        // when SQLException occurs
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.searchAncillaryCodeDiscount(tfAncillaryCodeDiscount);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteLineStatusCode() throws TracfoneOneException {
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DBENV);
        tfOneLineStatus.setLineStatusCode("LINE_STATUS_CODE");
        tfOneGeneralResponse = tracfoneProfileAction.deleteLineStatusCode(tfOneLineStatus, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfOneLineStatus.getLineStatusCode());
    }

    @Test
    public void testDeleteLineStatusCode_whenException() throws TracfoneOneException, SQLException {
        // When null is passed
        try {
            tracfoneProfileAction.deleteLineStatusCode(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        // When SQLException is thrown
        TracfoneOneLineStatusCode tfOneLineStatus = new TracfoneOneLineStatusCode();
        tfOneLineStatus.setDbEnv(DBENV);
        tfOneLineStatus.setLineStatusCode("LINE_STATUS_CODE");
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneProfileAction.deleteLineStatusCode(tfOneLineStatus, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteThrottleStatusCode() throws TracfoneOneException {
        TracfoneOneThrottleStatusCode tfOneThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfOneThrottleStatusCode.setThrottleStatusCode("THROTTLE_STATUS_CODE");
        tfOneThrottleStatusCode.setDbEnv(DBENV);
        tfOneGeneralResponse = tracfoneProfileAction.deleteThrottleStatusCode(tfOneThrottleStatusCode, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), tfOneThrottleStatusCode.getThrottleStatusCode());
    }

    @Test
    public void testDeleteThrottleStatusCode_whenException() throws TracfoneOneException, SQLException {
        // When null is passed
        try {
            tracfoneProfileAction.deleteThrottleStatusCode(null, 100);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // exception
        }
        // When SQLException is thrown
        TracfoneOneThrottleStatusCode tfOneThrottleStatusCode = new TracfoneOneThrottleStatusCode();
        tfOneThrottleStatusCode.setThrottleStatusCode("THROTTLE_STATUS_CODE");
        tfOneThrottleStatusCode.setDbEnv(DBENV);
        doThrow(SQLException.class).when(stmt).executeQuery();
        try {
            tracfoneProfileAction.deleteThrottleStatusCode(tfOneThrottleStatusCode, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testCheckAncillaryCodeProfiles() throws TracfoneOneException, SQLException {
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        doReturn(true).doReturn(false).when(resultSet).next();
        doReturn(1L).when(resultSet).getLong(1);
        Long response = tracfoneProfileAction.checkAncillaryCodeDiscountDependencies(tfAncillaryCodeDiscount);
        assertEquals("1", response.toString());
    }

    @Test
    public void testCheckAncillaryCodeProfiles_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        long count = 1l;
        try {
            count = tracfoneProfileAction.checkAncillaryCodeDiscountDependencies(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount = new TracfoneOneAncillaryCodeDiscount();
        tfAncillaryCodeDiscount.setDbEnv(DBENV);
        tfAncillaryCodeDiscount.setAncillaryCode("ANCILLARY_CODE");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.checkAncillaryCodeDiscountDependencies(tfAncillaryCodeDiscount);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertMultiRatePlanEsns() throws Exception {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsn.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsn.setxEsn("ESN");
        tracfoneOneMultiRatePlanEsn.setxServicePlanId("185");
        tracfoneOneMultiRatePlanEsn.setDelFlag("Y");
        tracfoneOneMultiRatePlanEsn.setxProductId("185");
        tracfoneOneMultiRatePlanEsn.setxPriority("1");
        tracfoneOneMultiRatePlanEsn.setxReason("REASON");
        tfOneGeneralResponse = tracfoneProfileAction.insertMultiRatePlanEsn(tracfoneOneMultiRatePlanEsn, 100, "1235");
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "185");
    }

    @Test
    public void testInsertMultiRatePlanEsns_ForElse() throws Exception {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsn.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsn.setxServicePlanId("185");

        tfOneGeneralResponse = tracfoneProfileAction.insertMultiRatePlanEsn(tracfoneOneMultiRatePlanEsn, 100, "1235");
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "185");
    }

    @Test
    public void testInsertMultiRatePlanEsns_whenException() throws SQLException {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsn.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsn.setxEsn("ESN");
        tracfoneOneMultiRatePlanEsn.setxServicePlanId("185");
        tracfoneOneMultiRatePlanEsn.setDelFlag("Y");
        tracfoneOneMultiRatePlanEsn.setxProductId("185");
        tracfoneOneMultiRatePlanEsn.setxPriority("1");
        tracfoneOneMultiRatePlanEsn.setxReason("REASON");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.insertMultiRatePlanEsn(tracfoneOneMultiRatePlanEsn, 100, "1235");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateMultiRatePlanEsns() throws Exception {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsns.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsns.setxEsn("ESN");
        tracfoneOneMultiRatePlanEsns.setxServicePlanId("185");
        tracfoneOneMultiRatePlanEsns.setDelFlag("Y");
        tracfoneOneMultiRatePlanEsns.setxProductId("185");
        tracfoneOneMultiRatePlanEsns.setxPriority("1");
        tracfoneOneMultiRatePlanEsns.setxReason("REASON");
        tfOneGeneralResponse = tracfoneProfileAction.updateMultiRatePlanEsn(tracfoneOneMultiRatePlanEsns, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "185");
    }

    @Test
    public void testUpdateMultiRatePlanEsns_whenException() throws SQLException {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsn.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsn.setxEsn("ESN");
        tracfoneOneMultiRatePlanEsn.setxServicePlanId("185");
        tracfoneOneMultiRatePlanEsn.setDelFlag("Y");
        tracfoneOneMultiRatePlanEsn.setxProductId("185");
        tracfoneOneMultiRatePlanEsn.setxPriority("1");
        tracfoneOneMultiRatePlanEsn.setxReason("REASON");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneProfileAction.updateMultiRatePlanEsn(tracfoneOneMultiRatePlanEsn, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteMultiRatePlanEsns() throws Exception {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsn.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsn.setxEsn("ESN");
        tracfoneOneMultiRatePlanEsn.setxServicePlanId("185");
        tracfoneOneMultiRatePlanEsn.setDelFlag("Y");
        tracfoneOneMultiRatePlanEsn.setxProductId("185");
        tracfoneOneMultiRatePlanEsn.setxPriority("1");
        tracfoneOneMultiRatePlanEsn.setxReason("REASON");
        List<TracfoneOneMultiRatePlanEsn> multiRatePlanEsnList = new ArrayList<>();
        multiRatePlanEsnList.add(tracfoneOneMultiRatePlanEsn);
        tfOneGeneralResponse = tracfoneProfileAction.deleteMultiRatePlanEsn(multiRatePlanEsnList, 100);
        assertEquals(tfOneGeneralResponse.getStatus(), "Success");
        assertEquals(tfOneGeneralResponse.getMessage(), "185");
    }

    @Test
    public void testDeleteMultiRatePlanEsns_whenException() throws SQLException {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsn.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsn.setxEsn("ESN");
        tracfoneOneMultiRatePlanEsn.setxServicePlanId("185");
        tracfoneOneMultiRatePlanEsn.setDelFlag("Y");
        tracfoneOneMultiRatePlanEsn.setxProductId("185");
        tracfoneOneMultiRatePlanEsn.setxPriority("1");
        tracfoneOneMultiRatePlanEsn.setxReason("REASON");
        List<TracfoneOneMultiRatePlanEsn> multiRatePlanEsnList = new ArrayList<>();
        multiRatePlanEsnList.add(tracfoneOneMultiRatePlanEsn);
        doThrow(SQLException.class).when(stmt).executeBatch();
        try {
            tracfoneProfileAction.deleteMultiRatePlanEsn(multiRatePlanEsnList, 100);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchMultiRatePlanEsns() throws TracfoneOneException, SQLException {
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsn.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsn.setxEsn("ESN");
        tracfoneOneMultiRatePlanEsn.setxServicePlanId("185");
        tracfoneOneMultiRatePlanEsn.setDelFlag("Y");
        tracfoneOneMultiRatePlanEsn.setxProductId("185");
        tracfoneOneMultiRatePlanEsn.setxPriority("1");
        tracfoneOneMultiRatePlanEsn.setxReason("REASON");
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneMultiRatePlanEsn> response = tracfoneProfileAction.searchMultiRatePlanEsns(tracfoneOneMultiRatePlanEsn);
        assertNotNull(response);
        assertEquals(1, response.size());
        assertEquals("[TFOneMultiRatePlanEsns{xEsn='DUMMY_DATA', xPrority='DUMMY_DATA', xServicePlanId='DUMMY_DATA', xDateAdded='null', xReason='DUMMY_DATA', delFlag='DUMMY_DATA', xProductId='DUMMY_DATA'}]", response.toString());
    }

    @Test
    public void testSearchMultiRatePlanEsns_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.searchMultiRatePlanEsns(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn = new TracfoneOneMultiRatePlanEsn();
        tracfoneOneMultiRatePlanEsn.setDbEnv(DBENV);
        tracfoneOneMultiRatePlanEsn.setxEsn("ESN");
        tracfoneOneMultiRatePlanEsn.setxServicePlanId("185");
        tracfoneOneMultiRatePlanEsn.setDelFlag("Y");
        tracfoneOneMultiRatePlanEsn.setxProductId("185");
        tracfoneOneMultiRatePlanEsn.setxPriority("1");
        tracfoneOneMultiRatePlanEsn.setxReason("REASON");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.searchMultiRatePlanEsns(tracfoneOneMultiRatePlanEsn);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchProfileByDesc() throws TracfoneOneException, SQLException {
        List<TracfoneOneRatePlanProfile> profiles = new ArrayList<>();
        TracfoneOneRatePlanProfile tfRatePlanProfile = new TracfoneOneRatePlanProfile();
        tfRatePlanProfile.setProfileDescription("desc");
        tfRatePlanProfile.setDbEnv(DBENV);
        profiles.add(tfRatePlanProfile);
        tfRatePlanProfile = new TracfoneOneRatePlanProfile();
        tfRatePlanProfile.setProfileDescription("desc1");
        tfRatePlanProfile.setDbEnv(DBENV);
        profiles.add(tfRatePlanProfile);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("desc");
        List<String> duplicates = tracfoneProfileAction.searchProfilesByDesc(profiles);
        assertNotNull(duplicates);
        assertEquals("[desc]", duplicates.toString());
    }

    @Test
    public void testSearchProfileByDesc_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneProfileAction.searchProfilesByDesc(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        List<TracfoneOneRatePlanProfile> profiles = new ArrayList<>();
        TracfoneOneRatePlanProfile tfRatePlanProfile = new TracfoneOneRatePlanProfile();
        tfRatePlanProfile.setProfileDescription("desc");
        tfRatePlanProfile.setDbEnv(DBENV);
        profiles.add(tfRatePlanProfile);
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneProfileAction.searchProfilesByDesc(profiles);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}