package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOnePCRFTransaction;
import com.tracfone.service.model.request.TracfoneonePaginationSearch;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOnePCRFTransSearchResult;
import com.tracfone.service.model.response.TFOnePCRFTransaction;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantPCRFTrans;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * @author Gaurav.Sharma
 */
public class TracfoneOnePCRFTransControllerTest implements TracfoneOneConstant, TracfoneOneConstantPCRFTrans {

    public final String DBENV = "dbEnv";
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    @InjectMocks
    TracfoneOnePCRFTransController cRFTransControllerLocal;

    @Mock
    TracfoneOnePCRFTransActionLocal cRFTransActionLocal;

    @Before
    public void setUp() {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "100");
        tracfoneOneException = new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
    }

    @Test
    public void testViewPCRFTransController() throws Exception {
        TracfoneOnePCRFTransaction cRFTransaction = new TracfoneOnePCRFTransaction();
        cRFTransaction.setDbEnv(DBENV);

        TFOnePCRFTransSearchResult cRFTransSearchResult = new TFOnePCRFTransSearchResult();
        List<TFOnePCRFTransaction> cRFTransactions = new ArrayList();
        TFOnePCRFTransaction cRFTransaction1 = new TFOnePCRFTransaction();
        cRFTransaction1.setActionType("ACTIion");
        cRFTransaction1.setAddonsFlag("flag");
        cRFTransaction1.setBlackoutWaitDate("2020/12/12");
        cRFTransaction1.setBrand("brand");
        cRFTransaction1.setEsn("ESN");
        cRFTransaction1.setGroupId("GROUPID");
        cRFTransaction1.setMin("MIN");
        cRFTransaction1.setCaseId("12");
        cRFTransaction1.setCharField1("12");
        cRFTransaction1.setCharField2("42");
        cRFTransaction1.setCharField3("41");
        cRFTransaction1.setContactObjId("21441");
        cRFTransaction1.setSubscriberId("15251");
        cRFTransaction1.setContentDeliveryFormat("THESH");
        cRFTransaction1.setConversionFactor("FACTOR");
        cRFTransaction1.setDataUsage("1234");
        cRFTransaction1.setDateField1("2020/12/12");
        cRFTransaction1.setDealerId("1414");
        cRFTransaction1.setDenomination("API");
        cRFTransaction1.setFutureTtl("2020/12/12");
        cRFTransaction1.setHiSpeedDataUsage("COS");
        cRFTransaction1.setImsi("ENTITLEMENT");
        cRFTransaction1.setMdn("ESN");
        cRFTransaction1.setOrderType("GROUPID");
        cRFTransaction1.setObjId("MIN");
        cRFTransaction1.setPartInstStatus("PARENT NAME");
        cRFTransaction1.setPcrfCos("POLICY NAME");
        cRFTransaction1.setPhoneManufacturer("PRIO");
        cRFTransaction1.setPhoneModel("FLAG");
        cRFTransaction1.setPosaFlag("RULE");
        cRFTransaction1.setProgramParameterId("STATUS");
        cRFTransaction1.setPropagateFlag("SUB ID");
        cRFTransaction1.setRatePlan("THESH");
        cRFTransaction1.setRcsEnableFlag("GROUP_TYPE");
        cRFTransaction1.setRedemptionDate("NUM");
        cRFTransaction1.setRetryCount("TYPE");
        cRFTransaction1.setServicePlanType("USAGE ID");
        cRFTransaction1.setSim("STATUS");
        cRFTransaction1.setSourceSystem("SUB ID");
        cRFTransaction1.setTtl("THESH");
        cRFTransaction1.setZipCode("GROUP_TYPE");
        cRFTransaction1.setInsertTimestamp("2020/12/12");
        cRFTransaction1.setUpdateTimestamp("2020/12/12");
        cRFTransaction1.setWebObjId("12456");
        cRFTransactions.add(cRFTransaction1);
        TracfoneonePaginationSearch tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
        tracfoneonePaginationSearch.setStartIndex(0);
        tracfoneonePaginationSearch.setEndIndex(100);
        tracfoneonePaginationSearch.setTotal(123);
        cRFTransSearchResult.setPaginationSearch(tracfoneonePaginationSearch);
        cRFTransSearchResult.setPcrfTransactions(cRFTransactions);

        when(cRFTransActionLocal.viewPcrfTransaction(any())).thenReturn(cRFTransSearchResult);
        TFOnePCRFTransSearchResult response = cRFTransControllerLocal.viewPcrfTransaction(cRFTransaction);
        assertEquals("[TFOnePCRFTransaction{objId='MIN', min='MIN', esn='ESN', subscriberId='15251', groupId='GROUPID', orderType='GROUPID', phoneManufacturer='PRIO', actionType='ACTIion', sim='STATUS', zipCode='GROUP_TYPE', servicePlanId='null', caseId='12', pcrfStatusCode='null', statusMessage='null', webObjId='12456', brand='brand', sourceSystem='SUB ID', template='null', ratePlan='THESH', blackoutWaitDate='2020/12/12', retryCount='TYPE', dataUsage='1234', hiSpeedDataUsage='COS', conversionFactor='FACTOR', dealerId='1414', denomination='API', pcrfParentName='null', propagateFlag='SUB ID', servicePlanType='USAGE ID', partInstStatus='PARENT NAME', phoneModel='FLAG', contentDeliveryFormat='THESH', language='null', wfMacId='null', insertTimestamp='2020/12/12', updateTimestamp='2020/12/12', mdn='ESN', pcrfCos='POLICY NAME', ttl='THESH', futureTtl='2020/12/12', redemptionDate='NUM', contactObjId='21441', imsi='ENTITLEMENT', lifeLineId='null', installDate='null', programParameterId='STATUS', vmbcCertificationFlag='null', charField1='12', charField2='42', charField3='41', dateField1='2020/12/12', addonsFlag='flag', rcsEnableFlag='GROUP_TYPE', posaFlag='RULE', unlockStatus='null'}]", response.getPcrfTransactions().toString());
    }

    @Test
    public void testViewPCRFTransController_whenException() throws TracfoneOneException {
        doThrow(RuntimeException.class).when(cRFTransActionLocal).viewPcrfTransaction(any());
        try {
            cRFTransControllerLocal.viewPcrfTransaction(null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_PCRF_TRANSACTION_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_PCRF_TRANSACTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}
