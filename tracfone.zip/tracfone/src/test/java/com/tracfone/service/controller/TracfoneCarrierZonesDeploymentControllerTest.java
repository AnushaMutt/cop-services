package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import com.tracfone.service.model.request.TracfoneOneCarrierZonesDeployment;
import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;
import com.tracfone.service.model.request.TracfoneOneNpaNxx2Carrier;
import com.tracfone.service.model.response.TFOneCPrefResponse;
import com.tracfone.service.model.response.TFOneCarrierZonesDeployment;
import com.tracfone.service.model.response.TFOneCingularMrktInfo;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneMissingCarrierZones;
import com.tracfone.service.model.response.TFOneMissingCingularMktInfo;
import com.tracfone.service.model.response.TFOneNpaNxx2Carrier;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantCarrierZonesDeployment;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;

import static org.mockito.ArgumentMatchers.any;

import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import org.mockito.junit.MockitoJUnitRunner;

/**
 * @author Gaurav.Sharma
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneCarrierZonesDeploymentControllerTest implements TracfoneOneConstant, TracfoneOneConstantCarrierZonesDeployment {

    private static final String DBENV = "DBENV";

    @InjectMocks
    TracfoneCarrierZonesDeploymentController deploymentController;

    @Mock
    TracfoneCarrierZonesDeploymentAction deploymentAction;

    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", "100");
        tracfoneOneException = new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
    }

    @Test
    public void testValidateCarrierZones() throws Exception {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        zonesDeployment.setNewZipCodes(zipCodes);
        when(deploymentAction.validateCarrierZones(any())).thenReturn(zonesDeployment);
        TFOneCarrierZonesDeployment deployment = deploymentController.validateCarrierZones(carrierZonesDeployment);
        assertEquals("TFOneCarrierZonesDeployment{newZipCodes=[12345, 33178], carrierZones=[], zipNPANXXs=[], arUsaData=[], cingularMrktInfos=[], zipMktSubMkts=[], tmoNextAvailable=[]}", deployment.toString());
    }

    @Test
    public void testValidateCarrierZones_whenException() throws Exception {
        doThrow(tracfoneOneException).when(deploymentAction).validateCarrierZones(any());
        try {
            deploymentController.validateCarrierZones(null);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_VALIDATE_CARRIER_ZONES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_VALIDATE_CARRIER_ZONES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testValidateNpaNxx() throws Exception {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();

        when(deploymentAction.validateNpaNxx(any())).thenReturn(zonesDeployment);
        TFOneCarrierZonesDeployment deployment = deploymentController.validateNpaNxx(carrierZonesDeployment);
        assertEquals("TFOneCarrierZonesDeployment{newZipCodes=[], carrierZones=[], zipNPANXXs=[], arUsaData=[], cingularMrktInfos=[], zipMktSubMkts=[], tmoNextAvailable=[]}", deployment.toString());
    }

    @Test
    public void testValidateNpaNxx_whenException() throws Exception {
        doThrow(tracfoneOneException).when(deploymentAction).validateNpaNxx(any());
        try {
            deploymentController.validateNpaNxx(null);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_VALIDATE_NPANAXX_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_VALIDATE_NPANAXX_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testValidateArMarket() throws Exception {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        zonesDeployment.setNewZipCodes(zipCodes);
        when(deploymentAction.validateARUSA(any())).thenReturn(zonesDeployment);
        TFOneCarrierZonesDeployment deployment = deploymentController.validateARUSA(carrierZonesDeployment);
        assertEquals("TFOneCarrierZonesDeployment{newZipCodes=[12345, 33178], carrierZones=[], zipNPANXXs=[], arUsaData=[], cingularMrktInfos=[], zipMktSubMkts=[], tmoNextAvailable=[]}", deployment.toString());
    }

    @Test
    public void testValidateArMarket_whenException() throws Exception {
        doThrow(tracfoneOneException).when(deploymentAction).validateARUSA(any());
        try {
            deploymentController.validateARUSA(null);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_VALIDATE_AR_USA_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_VALIDATE_AR_USA_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierZones() throws Exception {
        List<TracfoneOneCarrierZones> carrierZoneses = new ArrayList<>();
        TracfoneOneCarrierZones oneCarrierZones = new TracfoneOneCarrierZones();
        oneCarrierZones.setState("TEST");
        oneCarrierZones.setCounty("COUNTY");
        oneCarrierZones.setCarrierId("12345");
        oneCarrierZones.setCarrierName("VZW");
        oneCarrierZones.setDbEnv(DBENV);
        carrierZoneses.add(oneCarrierZones);
        TFOneMissingCarrierZones response = new TFOneMissingCarrierZones();
        response.setFailedRecords(carrierZoneses);
        response.setSuccessRecords(carrierZoneses);
        when(deploymentAction.insertMissingCarrierZones(any(), ArgumentMatchers.anyInt(), any())).thenReturn(response);
        TFOneMissingCarrierZones carrierZones = deploymentController.insertMissingCarrierZones(carrierZoneses, 1000, "VERIZON");
        assertEquals(carrierZones, carrierZones);
    }

    @Test
    public void testInsertCarrierZones_whenException() throws Exception {
        List<TracfoneOneCarrierZones> carrierZoneses = new ArrayList<>();
        TracfoneOneCarrierZones oneCarrierZones = new TracfoneOneCarrierZones();
        oneCarrierZones.setState("TEST");
        oneCarrierZones.setCounty("COUNTY");
        oneCarrierZones.setCarrierId("12345");
        oneCarrierZones.setCarrierName("VZW");
        oneCarrierZones.setDbEnv(DBENV);
        carrierZoneses.add(oneCarrierZones);
        doThrow(tracfoneOneException).when(deploymentAction).insertMissingCarrierZones(any(), ArgumentMatchers.anyInt(), any());
        try {
            deploymentController.insertMissingCarrierZones(carrierZoneses, 1000, "VERIZON");
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_MISSING_CZ_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_MISSING_CZ_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertNpanxx() throws Exception {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        TFOneNpaNxx2Carrier response = new TFOneNpaNxx2Carrier();
        response.setFailedRecords(nxx2Carriers);
        response.setSuccessRecords(nxx2Carriers);
        when(deploymentAction.insertNpaNxx(any(), ArgumentMatchers.anyInt())).thenReturn(response);
        TFOneNpaNxx2Carrier carrierZones = deploymentController.insertNpaNxx(nxx2Carriers, 1000);
        assertEquals(carrierZones, carrierZones);
    }

    @Test
    public void testInsertNpanxx_whenException() throws Exception {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        doThrow(tracfoneOneException).when(deploymentAction).insertNpaNxx(any(), ArgumentMatchers.anyInt());
        try {
            deploymentController.insertNpaNxx(nxx2Carriers, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CARRIER_ID_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CARRIER_ID_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCPref() throws Exception {
        List<TracfoneOneCarrierZones> carrierZoneses = new ArrayList<>();
        TracfoneOneCarrierZones oneCarrierZones = new TracfoneOneCarrierZones();
        oneCarrierZones.setState("TEST");
        oneCarrierZones.setCounty("COUNTY");
        oneCarrierZones.setCarrierId("12345");
        oneCarrierZones.setCarrierName("VZW");
        oneCarrierZones.setDbEnv(DBENV);
        carrierZoneses.add(oneCarrierZones);
        TFOneCPrefResponse response = new TFOneCPrefResponse();
        response.setFailedRecords(carrierZoneses);
        response.setSuccessRecords(carrierZoneses);
        when(deploymentAction.insertCPref(any(), ArgumentMatchers.anyInt())).thenReturn(response);
        TFOneCPrefResponse carrierZones = deploymentController.insertCPref(carrierZoneses, 1000);
        assertEquals(carrierZones, carrierZones);
    }

    @Test
    public void testInsertCPref_whenException() throws Exception {
        List<TracfoneOneCarrierZones> carrierZoneses = new ArrayList<>();
        TracfoneOneCarrierZones oneCarrierZones = new TracfoneOneCarrierZones();
        oneCarrierZones.setState("TEST");
        oneCarrierZones.setCounty("COUNTY");
        oneCarrierZones.setCarrierId("12345");
        oneCarrierZones.setCarrierName("VZW");
        oneCarrierZones.setDbEnv(DBENV);
        carrierZoneses.add(oneCarrierZones);
        doThrow(tracfoneOneException).when(deploymentAction).insertCPref(any(), ArgumentMatchers.anyInt());
        try {
            deploymentController.insertCPref(carrierZoneses, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CARRIER_ID_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CARRIER_ID_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testValidateCingularMrktInfo() throws Exception {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        zonesDeployment.setNewZipCodes(zipCodes);
        when(deploymentAction.validateCingularMrktInfo(any())).thenReturn(zonesDeployment);
        TFOneCarrierZonesDeployment deployment = deploymentController.validateCingularMrktInfo(carrierZonesDeployment);
        assertEquals("TFOneCarrierZonesDeployment{newZipCodes=[12345, 33178], carrierZones=[], zipNPANXXs=[], arUsaData=[], cingularMrktInfos=[], zipMktSubMkts=[], tmoNextAvailable=[]}", deployment.toString());
    }

    @Test
    public void testValidateCingularMrktInfo_whenException() throws Exception {
        doThrow(tracfoneOneException).when(deploymentAction).validateCingularMrktInfo(any());
        try {
            deploymentController.validateCingularMrktInfo(null);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_VALIDATE_CINGULAR_MRKT_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_VALIDATE_CINGULAR_MRKT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testValidateZipMktSubMkt() throws Exception {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        zonesDeployment.setNewZipCodes(zipCodes);
        when(deploymentAction.validateZipMktSubMkt(any())).thenReturn(zonesDeployment);
        TFOneCarrierZonesDeployment deployment = deploymentController.validateZipMktSubMkt(carrierZonesDeployment);
        assertEquals("TFOneCarrierZonesDeployment{newZipCodes=[12345, 33178], carrierZones=[], zipNPANXXs=[], arUsaData=[], cingularMrktInfos=[], zipMktSubMkts=[], tmoNextAvailable=[]}", deployment.toString());
    }

    @Test
    public void testValidateZipMktSubMkt_whenException() throws Exception {
        doThrow(tracfoneOneException).when(deploymentAction).validateZipMktSubMkt(any());
        try {
            deploymentController.validateZipMktSubMkt(null);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_VALIDATE_ZIP_MKT_SUB_MKT_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_VALIDATE_ZIP_MKT_SUB_MKT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateDealerNan() throws Exception {
        List<TracfoneOneCingularMrktInfo> cingularMrktInfos = new ArrayList<>();
        TracfoneOneCingularMrktInfo cingularMrktInfo = new TracfoneOneCingularMrktInfo();
        cingularMrktInfo.setDealerCode("DEALER_CODE");
        cingularMrktInfo.setDbEnv("DBENV");
        cingularMrktInfos.add(cingularMrktInfo);

        List<TFOneCingularMrktInfo> cingularMrktInfoList = new ArrayList<>();
        TFOneCingularMrktInfo cingularMrktInfo1 = new TFOneCingularMrktInfo();
        cingularMrktInfo1.setDealerCode("DEALER_CODE");
        cingularMrktInfoList.add(cingularMrktInfo1);

        when(deploymentAction.updateDealerNan(any())).thenReturn(cingularMrktInfoList);
        List<TFOneCingularMrktInfo> res = deploymentController.updateDealerNan(cingularMrktInfos);
        assertEquals("[TFOneCingularMrktInfo{mkt='null', npa='null', nxx='null', npanxx='null', rcNumber='null', rcName='null', rcState='null', zip='null', mktType='null', accountNum='null', marketCode='null', dealerCode='DEALER_CODE', subMarketId='null', template='null'}]", res.toString());
    }

    @Test
    public void testUpdateDealerNan_whenException() throws Exception {
        doThrow(tracfoneOneException).when(deploymentAction).updateDealerNan(any());
        try {
            deploymentController.updateDealerNan(null);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_DEALER_NAN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_DEALER_NAN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCingularMktInfo() throws Exception {
        List<TracfoneOneCingularMrktInfo> mrktInfos = new ArrayList<>();
        TracfoneOneCingularMrktInfo mrktInfo = new TracfoneOneCingularMrktInfo();
        mrktInfo.setDealerCode("DEALER_CODE");
        mrktInfo.setMkt("MKT");
        mrktInfo.setMarketCode("MARKET_CODE");
        mrktInfo.setAccountNum("ACCOUNT_NUM");
        mrktInfo.setZip("ZIP");
        mrktInfo.setTemplate("TEMPLATE");
        mrktInfo.setSubMarketId("SUB_MARKET_ID");
        mrktInfo.setRcState("STATE");
        mrktInfo.setRcNumber("NUMBER");
        mrktInfo.setRcName("NAME");
        mrktInfo.setDbEnv("DBENV");
        mrktInfos.add(mrktInfo);
        TFOneMissingCingularMktInfo response = new TFOneMissingCingularMktInfo();
        response.setFailedRecords(mrktInfos);
        response.setSuccessRecords(mrktInfos);
        when(deploymentAction.insertCingularMktInfo(any(), ArgumentMatchers.anyInt())).thenReturn(response);
        TFOneMissingCingularMktInfo carrierZones = deploymentController.insertCingularMktInfo(mrktInfos, 1000);
        assertEquals(carrierZones, carrierZones);
    }

    @Test
    public void testInsertCingularMktInfo_whenException() throws Exception {
        List<TracfoneOneCingularMrktInfo> mrktInfos = new ArrayList<>();
        TracfoneOneCingularMrktInfo mrktInfo = new TracfoneOneCingularMrktInfo();
        mrktInfo.setDealerCode("DEALER_CODE");
        mrktInfo.setMkt("MKT");
        mrktInfo.setMarketCode("MARKET_CODE");
        mrktInfo.setAccountNum("ACCOUNT_NUM");
        mrktInfo.setZip("ZIP");
        mrktInfo.setTemplate("TEMPLATE");
        mrktInfo.setSubMarketId("SUB_MARKET_ID");
        mrktInfo.setRcState("STATE");
        mrktInfo.setRcNumber("NUMBER");
        mrktInfo.setRcName("NAME");
        mrktInfo.setDbEnv("DBENV");
        mrktInfos.add(mrktInfo);
        TFOneMissingCingularMktInfo response = new TFOneMissingCingularMktInfo();
        response.setFailedRecords(mrktInfos);
        response.setSuccessRecords(mrktInfos);
        doThrow(tracfoneOneException).when(deploymentAction).insertCingularMktInfo(any(), ArgumentMatchers.anyInt());
        try {
            deploymentController.insertCingularMktInfo(mrktInfos, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_MISSING_CINGULAR_MKT_INFO_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_MISSING_CINGULAR_MKT_INFO_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testValidateNextAvailable() throws Exception {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("12345");
        zipCodes.add("33178");
        TracfoneOneCarrierZonesDeployment carrierZonesDeployment = new TracfoneOneCarrierZonesDeployment();
        carrierZonesDeployment.setDbEnv(DBENV);
        carrierZonesDeployment.setZipcodes(zipCodes);
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();

        when(deploymentAction.validateNextAvailable(any())).thenReturn(zonesDeployment);
        TFOneCarrierZonesDeployment deployment = deploymentController.validateNextAvailable(carrierZonesDeployment);
        assertEquals("TFOneCarrierZonesDeployment{newZipCodes=[], carrierZones=[], zipNPANXXs=[], arUsaData=[], cingularMrktInfos=[], zipMktSubMkts=[], tmoNextAvailable=[]}", deployment.toString());
    }

    @Test
    public void testValidateNextAvailable_whenException() throws Exception {
        doThrow(tracfoneOneException).when(deploymentAction).validateNextAvailable(any());
        try {
            deploymentController.validateNextAvailable(null);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_VALIDATE_TMO_NEXT_AVAILABLE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_VALIDATE_TMO_NEXT_AVAILABLE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertTmoNpaNxx() throws Exception {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        TFOneNpaNxx2Carrier response = new TFOneNpaNxx2Carrier();
        response.setFailedRecords(nxx2Carriers);
        response.setSuccessRecords(nxx2Carriers);
        when(deploymentAction.insertTmoNpaNxx(any(), ArgumentMatchers.anyInt())).thenReturn(response);
        TFOneNpaNxx2Carrier carrierZones = deploymentController.insertTmoNpaNxx(nxx2Carriers, 1000);
        assertEquals(carrierZones, carrierZones);
    }

    @Test
    public void testInsertTmoNpaNxx_whenException() throws Exception {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        doThrow(tracfoneOneException).when(deploymentAction).insertTmoNpaNxx(any(), ArgumentMatchers.anyInt());
        try {
            deploymentController.insertTmoNpaNxx(nxx2Carriers, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_TMO_NPANXX_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_TMO_NPANXX_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertNpanxxAtt() throws Exception {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        TFOneNpaNxx2Carrier response = new TFOneNpaNxx2Carrier();
        response.setFailedRecords(nxx2Carriers);
        response.setSuccessRecords(nxx2Carriers);
        when(deploymentAction.insertNpaNxxAtt(any(), ArgumentMatchers.anyInt())).thenReturn(response);
        TFOneNpaNxx2Carrier carrierZones = deploymentController.insertNpaNxxAtt(nxx2Carriers, 1000);
        assertEquals(carrierZones, carrierZones);
    }

    @Test
    public void testInsertNpanxxAtt_whenException() throws Exception {
        List<TracfoneOneNpaNxx2Carrier> nxx2Carriers = new ArrayList<>();
        TracfoneOneNpaNxx2Carrier npaNxx2Carrier = new TracfoneOneNpaNxx2Carrier();
        npaNxx2Carrier.setState("TEST");
        npaNxx2Carrier.setCounty("COUNTY");
        npaNxx2Carrier.setCarrierId("12345");
        npaNxx2Carrier.setCarrierName("VZW");
        npaNxx2Carrier.setDbEnv(DBENV);
        nxx2Carriers.add(npaNxx2Carrier);
        doThrow(tracfoneOneException).when(deploymentAction).insertNpaNxxAtt(any(), ArgumentMatchers.anyInt());
        try {
            deploymentController.insertNpaNxxAtt(nxx2Carriers, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_NPAXX_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_NPAXX_ERROR_MESSAGE, e.getErrorMessage());
        }
    }
}
