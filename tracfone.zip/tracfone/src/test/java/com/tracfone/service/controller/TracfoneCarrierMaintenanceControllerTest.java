package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneArUsaMarket;
import com.tracfone.service.model.request.TracfoneOneArUsaPostalZips;
import com.tracfone.service.model.request.TracfoneOneCarrier;
import com.tracfone.service.model.request.TracfoneOneCarrierGroup;
import com.tracfone.service.model.request.TracfoneOneCarrierPref;
import com.tracfone.service.model.request.TracfoneOneCarrierRule;
import com.tracfone.service.model.request.TracfoneOneCarrierSimPref;
import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;
import com.tracfone.service.model.request.TracfoneOneDataConfig;
import com.tracfone.service.model.request.TracfoneOneDataConfigMapping;
import com.tracfone.service.model.request.TracfoneOneGeoLoc;
import com.tracfone.service.model.request.TracfoneOneIgOrderType;
import com.tracfone.service.model.request.TracfoneOneNotCertifyModel;
import com.tracfone.service.model.request.TracfoneOneNpanxx2Carrierzones;
import com.tracfone.service.model.request.TracfoneOneOrderType;
import com.tracfone.service.model.request.TracfoneOneParent;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneThrottleFeature;
import com.tracfone.service.model.request.TracfoneOneThrottlePolicy;
import com.tracfone.service.model.request.TracfoneOneThrottleRule;
import com.tracfone.service.model.request.TracfoneOneTmoZipNgp;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.request.TracfoneOneVerizonZipNPANXX;
import com.tracfone.service.model.response.TFOneArUsaMarket;
import com.tracfone.service.model.response.TFOneArUsaMarketSearchResult;
import com.tracfone.service.model.response.TFOneArUsaPostalZips;
import com.tracfone.service.model.response.TFOneBulkInsertReport;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierGroup;
import com.tracfone.service.model.response.TFOneCarrierPref;
import com.tracfone.service.model.response.TFOneCarrierRule;
import com.tracfone.service.model.response.TFOneCarrierZones;
import com.tracfone.service.model.response.TFOneCarriersimpref;
import com.tracfone.service.model.response.TFOneCingularMrktInfo;
import com.tracfone.service.model.response.TFOneDataConfig;
import com.tracfone.service.model.response.TFOneDataConfigMapping;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneGeoLoc;
import com.tracfone.service.model.response.TFOneIgOrderType;
import com.tracfone.service.model.response.TFOneNotCertifyModel;
import com.tracfone.service.model.response.TFOneNpaNxx2CarrierZonesSearchResult;
import com.tracfone.service.model.response.TFOneNpanxx2Carrierzones;
import com.tracfone.service.model.response.TFOneOrderType;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOnePartClass;
import com.tracfone.service.model.response.TFOneThrottleFeature;
import com.tracfone.service.model.response.TFOneThrottlePolicy;
import com.tracfone.service.model.response.TFOneThrottleRule;
import com.tracfone.service.model.response.TFOneTmoZipNgp;
import com.tracfone.service.model.response.TFOneVerizonZipNPANXX;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;

import com.tracfone.service.util.TracfoneOneConstantPlanWizard;

import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_CARRIERPREF_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_CARRIERPREF_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_CARRIERSIMPREF_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_CARRIERSIMPREF_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_CARRIERZONES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_CARRIERZONES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_CINGULAR_MRKT_INFO_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_CINGULAR_MRKT_INFO_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_DATA_CONFIG_MAPPING_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_DATA_CONFIG_MAPPING_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_NOT_CERTIFY_MODEL_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_NOT_CERTIFY_MODEL_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_TMO_ZIP_NGP_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_TMO_ZIP_NGP_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_VERIZON_ZIP_NPANXX_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_VERIZON_ZIP_NPANXX_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_CARRIERPREF_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_CARRIERPREF_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_CARRIERZONES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_CARRIERZONES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CARRIERPREF_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CARRIERPREF_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CARRIERSIMPREF_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CARRIERSIMPREF_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CARRIERZONES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CARRIERZONES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CINGULAR_MRKT_INFO_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_CINGULAR_MRKT_INFO_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_DATA_CONFIG_MAPPING_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_DATA_CONFIG_MAPPING_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_NOT_CERTIFY_MODEL_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_NOT_CERTIFY_MODEL_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_ORDER_TYPE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_ORDER_TYPE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_TMO_ZIP_NGP_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_TMO_ZIP_NGP_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_VERIZON_ZIP_NPANXX_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_VERIZON_ZIP_NPANXX_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_CARRIER_GROUP_ID_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_CARRIER_ID_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_DATA_CONFIG_MAPPING_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_DATA_CONFIG_MAPPING_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_IG_ORDER_TYPES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_IG_ORDER_TYPES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ALL_PART_CLASS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ALL_PART_CLASS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CARRIER_GROUP_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CARRIER_GROUP_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ORDER_TYPES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ORDER_TYPES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_CARRIER_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_CARRIER_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_CARRIER_GROUP_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_CARRIER_GROUP_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_CARRIER_RULE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_CARRIER_RULE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_IG_ORDER_TYPES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_IG_ORDER_TYPES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_ORDER_TYPE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_ORDER_TYPE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_PARENT_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_PARENT_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_THROTTLE_FEATURE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_THROTTLE_FEATURE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_THROTTLE_POLICY_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_THROTTLE_POLICY_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_THROTTLE_RULE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_THROTTLE_RULE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CARRIERSIMPREF_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CARRIERSIMPREF_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CARRIER_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CARRIER_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CARRIER_RULE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CARRIER_RULE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CINGULAR_MRKT_INFO_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CINGULAR_MRKT_INFO_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_DATA_CONFIG_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_DATA_CONFIG_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_DATA_CONFIG_MAPPING_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_DATA_CONFIG_MAPPING_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_IG_ORDER_TYPES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_IG_ORDER_TYPES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_NOT_CERTIFY_MODEL_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_NOT_CERTIFY_MODEL_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_PARENT_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_PARENT_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_THROTTLE_FEATURES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_THROTTLE_FEATURES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_THROTTLE_POLICY_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_THROTTLE_POLICY_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_THROTTLE_RULE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_THROTTLE_RULE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_TMO_ZIP_NGP_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_TMO_ZIP_NGP_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_VERIZON_ZIP_NPANXX_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_VERIZON_ZIP_NPANXX_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CARRIERPREF_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CARRIERPREF_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CARRIERSIMPREF_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CARRIERSIMPREF_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CARRIERZONES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CARRIERZONES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CARRIER_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CARRIER_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CARRIER_GROUP_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CARRIER_GROUP_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CARRIER_RULE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CARRIER_RULE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CINGULAR_MRKT_INFO_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CINGULAR_MRKT_INFO_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_DATA_CONFIG_MAPPING_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_DATA_CONFIG_MAPPING_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_IG_ORDER_TYPES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_IG_ORDER_TYPES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_ORDER_TYPE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_ORDER_TYPE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_PARENT_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_PARENT_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_THROTTLE_FEATURES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_THROTTLE_FEATURES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_THROTTLE_POLICY_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_THROTTLE_POLICY_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_THROTTLE_RULE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_THROTTLE_RULE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_VERIZON_ZIP_NPANXX_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_VERIZON_ZIP_NPANXX_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_GEO_LOC_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_GEO_LOC_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_GEO_LOC_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_GEO_LOC_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_GEO_LOC_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_GEO_LOC_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_GEO_LOC_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_GEO_LOC_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_USER_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_USER_ERROR;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Testing the services that are associated with TracfoneCarrierMaintenanceController.
 *
 * @author Pritesh Singh
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneCarrierMaintenanceControllerTest {
    private static final String DBENV = "DBENV";
    private static final String SAMPLE = "SAMPLE";

    @InjectMocks
    private TracfoneCarrierMaintenanceController tracfoneCarrierMaintenanceController;

    @Mock
    TracfoneCarrierMaintenanceLocalAction tracfoneCarrierMaintenanceAction;

    private TFOneGeneralResponse tFOneGeneralResponse;
    private TracfoneOneException tracfoneOneException;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("Success", SAMPLE);
        tracfoneOneException = new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
    }

    @Test
    public void testSearchCarrierGroups() throws Exception {
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setCarrierName("CARRIER_NAME");
        tracfoneOneCarrierGroup.setDbEnv(DBENV);

        List<TFOneCarrierGroup> carrierGroups = new ArrayList<>();
        TFOneCarrierGroup carrierGroup = new TFOneCarrierGroup();
        carrierGroup.setObjId("1000");
        carrierGroup.setCarrierName("CARRIER_NAME");
        carrierGroups.add(carrierGroup);
        when(tracfoneCarrierMaintenanceAction.searchCarrierGroups(any())).thenReturn(carrierGroups);
        List<TFOneCarrierGroup> response = tracfoneCarrierMaintenanceController.searchCarrierGroups(tracfoneOneCarrierGroup);
        assertEquals("[TFOneCarrierGroup{objId='1000', carrierGroupId='null', carrierName='CARRIER_NAME', group2Address='null', status='null', carrierGroup2Parent='null', noAutoPart='null'}]", response.toString());
    }

    @Test
    public void testSearchCarrierGroups_whenException() throws Exception {
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchCarrierGroups(any());
        try {
            tracfoneCarrierMaintenanceController.searchCarrierGroups(tracfoneOneCarrierGroup);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_CARRIER_GROUP_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_CARRIER_GROUP_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetOrderTypes() throws Exception {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setOrderType2xCarrier("CARRIER");

        List<TFOneOrderType> orderTypes = new ArrayList<>();
        TFOneOrderType orderType = new TFOneOrderType();
        orderType.setObjId("1000");
        orderType.setNpa("NPA");
        orderTypes.add(orderType);
        when(tracfoneCarrierMaintenanceAction.searchOrderTypes(any())).thenReturn(orderTypes);
        List<TFOneOrderType> response = tracfoneCarrierMaintenanceController.searchOrderTypes(tracfoneOneOrderType);
        assertEquals("[TracfoneOneOrderType{, objId='1000', orderType='null', npa='NPA', nxx='null', billCycle='null', dealerCode='null', ldAccountNum='null', marketCode='null', orderType2xTransProfile='null', orderType2xCarrier='null'}]", response.toString());
    }

    @Test
    public void testGetOrderTypes_whenException() throws Exception {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchOrderTypes(any());
        try {
            tracfoneCarrierMaintenanceController.searchOrderTypes(tracfoneOneOrderType);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ORDER_TYPES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_ORDER_TYPES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchParent() throws Exception {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        tracfoneOneParent.setDbEnv(DBENV);
        tracfoneOneParent.setParentId("1000");

        List<TFOneParent> tfOneParents = new ArrayList<>();
        TFOneParent tfOneParent = new TFOneParent();
        tfOneParent.setParentId("1000");
        tfOneParent.setxParentName("PARENT_NAME");
        tfOneParents.add(tfOneParent);
        when(tracfoneCarrierMaintenanceAction.searchParent(any())).thenReturn(tfOneParents);
        List<TFOneParent> response = tracfoneCarrierMaintenanceController.searchParent(tracfoneOneParent);
        assertEquals("[TFOneParent{objId='null', xParentName='PARENT_NAME', parentId='1000', status='null', holdAnalogDeac='null', holdDigitalDeac='null', parent2TempQueue='null', noInventory='null', vmAccessNum='null', autoPortIn='null', autoPortOut='null', noMsid='null', otaCarrier='null', otaEndDate='null', otaPsmsAddress='null', otaStartDate='null', nextAvailable='null', queueName='null', blockPortIn='null', meidCarrier='null', otaReact='null', aggCarrCode='null', suiRuleObjId='null', deactSimExpDays='null', overrideSmsAddress='null', triggerId='null', parentShortName='null'}]", response.toString());
    }

    @Test
    public void testSearchParent_whenException() throws Exception {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchParent(any());
        try {
            tracfoneCarrierMaintenanceController.searchParent(tracfoneOneParent);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_PARENT_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_PARENT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrier() throws Exception {
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setCarrierId("1000");

        List<TFOneCarrier> tfOneCarriers = new ArrayList<>();
        TFOneCarrier tfOneCarrier = new TFOneCarrier();
        tfOneCarrier.setObjId("1000");
        tfOneCarrier.setActTechnology("CDMA");
        tfOneCarriers.add(tfOneCarrier);
        when(tracfoneCarrierMaintenanceAction.searchCarrier(any())).thenReturn(tfOneCarriers);
        List<TFOneCarrier> response = tracfoneCarrierMaintenanceController.searchCarrier(tracfoneOneCarrier);
        assertEquals("[TFOneCarrier{objId='1000', carrierId='null', submarketName='null', submarketOf='null', city='null', state='null', tapereturnCharge='null', countryCode='null', activelinePercent='null', status='null', ldProvider='null', ldAccount='null', ldPicCode='null', ratePlan='null', dummyEsn='null', billDate='null', voiceMail='null', vmCode='null', vmPackage='null', callerId='null', idCode='null', idPackage='null', callWaiting='null', cwCode='null', cwPackage='null', reactTechnology='null', reactAnalog='null', actTechnology='CDMA', actAnalog='null', digitalRatePlan='null', digitalFeature='null', prlPreLoaded='null', carrier2CarrierGroup='null', tapereturnAddr2Address='null', carrier2Provider='null', carrier2Address='null', carrier2Personality='null', carrier2Rule='null', carrier2CarrScript='null', specialMkt='null', newAnalogPlan='null', newDigitalPlan='null', sms='null', smsCode='null', smsPackage='null', vmSetUpLandLine='null', carrier2RulesCdma='null', carrier2RulesGsm='null', carrier2RulesTdma='null', dataService='null', automated='null'}]", response.toString());
    }

    @Test
    public void testSearchCarrier_whenException() throws Exception {
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchCarrier(any());
        try {
            tracfoneCarrierMaintenanceController.searchCarrier(tracfoneOneCarrier);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_CARRIER_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_CARRIER_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchDataConfigMapping() throws Exception {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("1000");

        List<TFOneDataConfigMapping> tfOneDataConfigMappings = new ArrayList<>();
        TFOneDataConfigMapping tfOneDataConfigMapping = new TFOneDataConfigMapping();
        tfOneDataConfigMapping.setRatePlan("RATE_PLAN");
        tfOneDataConfigMappings.add(tfOneDataConfigMapping);

        when(tracfoneCarrierMaintenanceAction.searchDataConfigMapping(any())).thenReturn(tfOneDataConfigMappings);
        List<TFOneDataConfigMapping> response = tracfoneCarrierMaintenanceController.searchDataConfigMapping(tfDataConfigMapping);
        assertEquals("[TFOneDataConfigMapping{parentId='null', partClassObjId='null', ratePlan='RATE_PLAN', dataConfigObjId='null'}]", response.toString());
    }

    @Test
    public void testSearchDataConfigMapping_whenException() throws Exception {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchDataConfigMapping(any());
        try {
            tracfoneCarrierMaintenanceController.searchDataConfigMapping(tfDataConfigMapping);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_DATA_CONFIG_MAPPING_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_DATA_CONFIG_MAPPING_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertDataConfigMapping() throws Exception {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("SAMPLE");
        when(tracfoneCarrierMaintenanceAction.insertDataConfigMapping(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertDataConfigMapping(tfDataConfigMapping, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfDataConfigMapping.getParentId());
    }

    @Test
    public void testInsertDataConfigMapping_whenException() throws Exception {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("SAMPLE");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertDataConfigMapping(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.insertDataConfigMapping(tfDataConfigMapping, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_DATA_CONFIG_MAPPING_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_DATA_CONFIG_MAPPING_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteDataConfigMapping() throws Exception {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("SAMPLE");
        when(tracfoneCarrierMaintenanceAction.deleteDataConfigMapping(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.deleteDataConfigMapping(tfDataConfigMapping, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfDataConfigMapping.getParentId());
    }

    @Test
    public void testDeleteDataConfigMapping_whenException() throws Exception {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("SAMPLE");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).deleteDataConfigMapping(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.deleteDataConfigMapping(tfDataConfigMapping, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_DATA_CONFIG_MAPPING_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_DATA_CONFIG_MAPPING_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateDataConfigMapping() throws Exception {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("SAMPLE");
        when(tracfoneCarrierMaintenanceAction.updateDataConfigMapping(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateDataConfigMapping(tfDataConfigMapping, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tfDataConfigMapping.getParentId());
    }

    @Test
    public void testUpdateDataConfigMapping_whenException() throws Exception {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("SAMPLE");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateDataConfigMapping(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateDataConfigMapping(tfDataConfigMapping, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_DATA_CONFIG_MAPPING_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_DATA_CONFIG_MAPPING_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateDataConfigMapping_whenException_ForDuplicate() throws Exception {
        TracfoneOneDataConfigMapping tfDataConfigMapping = new TracfoneOneDataConfigMapping();
        tfDataConfigMapping.setDbEnv(DBENV);
        tfDataConfigMapping.setParentId("SAMPLE");
        when(tracfoneCarrierMaintenanceAction.validateDuplicateDataConfigMapping(any())).thenReturn(true);
        try {
            tracfoneCarrierMaintenanceController.updateDataConfigMapping(tfDataConfigMapping, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DUPLICATE_DATA_CONFIG_MAPPING_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DUPLICATE_DATA_CONFIG_MAPPING_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateParent() throws Exception {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        tracfoneOneParent.setDbEnv(DBENV);
        tracfoneOneParent.setParentId("SAMPLE");
        tracfoneOneParent.setParentName("PARENT_NAME");
        when(tracfoneCarrierMaintenanceAction.updateParent(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateParent(tracfoneOneParent, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneParent.getParentId());
    }

    @Test
    public void testUpdateParent_whenException() throws Exception {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        tracfoneOneParent.setDbEnv(DBENV);
        tracfoneOneParent.setParentId("1000");
        tracfoneOneParent.setParentName("PARENT_NAME");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateParent(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateParent(tracfoneOneParent, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_PARENT_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_PARENT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierGroup() throws Exception {
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setDbEnv(DBENV);
        tracfoneOneCarrierGroup.setObjId("SAMPLE");
        tracfoneOneCarrierGroup.setStatus("STATUS");
        when(tracfoneCarrierMaintenanceAction.updateCarrierGroup(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateCarrierGroup(tracfoneOneCarrierGroup, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneCarrierGroup.getObjId());
    }

    @Test
    public void testUpdateCarrierGroup_whenException() throws Exception {
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setDbEnv(DBENV);
        tracfoneOneCarrierGroup.setObjId("1000");
        tracfoneOneCarrierGroup.setStatus("STATUS");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateCarrierGroup(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateCarrierGroup(tracfoneOneCarrierGroup, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CARRIER_GROUP_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CARRIER_GROUP_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrier() throws Exception {
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setObjId("SAMPLE");
        tracfoneOneCarrier.setStatus("STATUS");
        when(tracfoneCarrierMaintenanceAction.updateCarrier(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateCarrier(tracfoneOneCarrier, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneCarrier.getObjId());
    }

    @Test
    public void testUpdateCarrier_whenException() throws Exception {
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setObjId("100");
        tracfoneOneCarrier.setStatus("STATUS");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateCarrier(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateCarrier(tracfoneOneCarrier, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CARRIER_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CARRIER_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierRule() throws Exception {
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        tracfoneOneCarrierRule.setDbEnv(DBENV);
        tracfoneOneCarrierRule.setObjId("SAMPLE");
        tracfoneOneCarrierRule.setTechnology("CDMA");
        when(tracfoneCarrierMaintenanceAction.updateCarrierRule(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateCarrierRule(tracfoneOneCarrierRule, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneCarrierRule.getObjId());
    }

    @Test
    public void testUpdateCarrierRule_whenException() throws Exception {
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        tracfoneOneCarrierRule.setDbEnv(DBENV);
        tracfoneOneCarrierRule.setObjId("1000");
        tracfoneOneCarrierRule.setTechnology("CDMA");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateCarrierRule(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateCarrierRule(tracfoneOneCarrierRule, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CARRIER_RULE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CARRIER_RULE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateOrderType() throws Exception {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("SAMPLE");
        tracfoneOneOrderType.setNpa("NPA");
        when(tracfoneCarrierMaintenanceAction.updateOrderType(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateOrderType(tracfoneOneOrderType, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneOrderType.getObjId());
    }

    @Test
    public void testUpdateOrderType_whenException() throws Exception {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("1000");
        tracfoneOneOrderType.setNpa("NPA");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateOrderType(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateOrderType(tracfoneOneOrderType, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_ORDER_TYPE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_ORDER_TYPE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertParent() throws Exception {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        tracfoneOneParent.setDbEnv(DBENV);
        tracfoneOneParent.setParentId("SAMPLE");
        tracfoneOneParent.setParentName("PARENT_NAME");
        when(tracfoneCarrierMaintenanceAction.insertParent(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertParent(tracfoneOneParent, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneParent.getParentId());
    }

    @Test
    public void testInsertParent_whenException() throws Exception {
        TracfoneOneParent tracfoneOneParent = new TracfoneOneParent();
        tracfoneOneParent.setDbEnv(DBENV);
        tracfoneOneParent.setParentId("1000");
        tracfoneOneParent.setParentName("PARENT_NAME");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertParent(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.insertParent(tracfoneOneParent, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_PARENT_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_PARENT_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierGroups() throws Exception {
        List<TracfoneOneCarrierGroup> tracfoneOneCarrierGroups = new ArrayList<>();
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setDbEnv(DBENV);
        tracfoneOneCarrierGroup.setObjId("SAMPLE");
        tracfoneOneCarrierGroup.setStatus("STATUS");
        tracfoneOneCarrierGroups.add(tracfoneOneCarrierGroup);
        when(tracfoneCarrierMaintenanceAction.insertCarrierGroups(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertCarrierGroups(tracfoneOneCarrierGroups, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneCarrierGroup.getObjId());
    }

    @Test
    public void testInsertCarrierGroups_whenException_For_Duplicate() throws Exception {
        List<TracfoneOneCarrierGroup> tracfoneOneCarrierGroups = new ArrayList<>();
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setDbEnv(DBENV);
        tracfoneOneCarrierGroup.setObjId("1000");
        tracfoneOneCarrierGroup.setStatus("STATUS");
        tracfoneOneCarrierGroups.add(tracfoneOneCarrierGroup);

        List<String> duplicateIds = new ArrayList<>();
        duplicateIds.add("ID_1");
        duplicateIds.add("ID_2");

        when(tracfoneCarrierMaintenanceAction.getCarrierGroupIds(any(), any())).thenReturn(duplicateIds);
        try {
            tracfoneCarrierMaintenanceController.insertCarrierGroups(tracfoneOneCarrierGroups, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DUPLICATE_CARRIER_GROUP_ID_ERROR, e.getErrorCode());
        }
    }

    @Test
    public void testInsertCarrierGroups_whenException() throws Exception {
        List<TracfoneOneCarrierGroup> tracfoneOneCarrierGroups = new ArrayList<>();
        TracfoneOneCarrierGroup tracfoneOneCarrierGroup = new TracfoneOneCarrierGroup();
        tracfoneOneCarrierGroup.setDbEnv(DBENV);
        tracfoneOneCarrierGroup.setObjId("1000");
        tracfoneOneCarrierGroup.setStatus("STATUS");
        tracfoneOneCarrierGroups.add(tracfoneOneCarrierGroup);
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertCarrierGroups(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.insertCarrierGroups(tracfoneOneCarrierGroups, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_CARRIER_GROUP_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_CARRIER_GROUP_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarriers() throws Exception {
        List<TracfoneOneCarrier> tracfoneOneCarriers = new ArrayList<>();
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setObjId("SAMPLE");
        tracfoneOneCarrier.setStatus("STATUS");
        tracfoneOneCarriers.add(tracfoneOneCarrier);
        when(tracfoneCarrierMaintenanceAction.insertCarriers(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertCarriers(tracfoneOneCarriers, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneCarriers.get(0).getObjId());
    }

    @Test
    public void testInsertCarriers_whenException() throws Exception {
        List<TracfoneOneCarrier> tracfoneOneCarriers = new ArrayList<>();
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setObjId("100");
        tracfoneOneCarrier.setStatus("STATUS");
        tracfoneOneCarriers.add(tracfoneOneCarrier);
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertCarriers(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.insertCarriers(tracfoneOneCarriers, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_CARRIER_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_CARRIER_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarriers_whenException_ForDuplicate() throws Exception {
        List<TracfoneOneCarrier> tracfoneOneCarriers = new ArrayList<>();
        TracfoneOneCarrier tracfoneOneCarrier = new TracfoneOneCarrier();
        tracfoneOneCarrier.setDbEnv(DBENV);
        tracfoneOneCarrier.setObjId("100");
        tracfoneOneCarrier.setStatus("STATUS");
        tracfoneOneCarriers.add(tracfoneOneCarrier);
        List<String> duplicateIds = new ArrayList<>();
        duplicateIds.add("ID_1");
        duplicateIds.add("ID_2");

        when(tracfoneCarrierMaintenanceAction.getCarrierIds(any(), any())).thenReturn(duplicateIds);
        try {
            tracfoneCarrierMaintenanceController.insertCarriers(tracfoneOneCarriers, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DUPLICATE_CARRIER_ID_ERROR, e.getErrorCode());
        }
    }

    @Test
    public void testInsertCarrierRule() throws Exception {
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        tracfoneOneCarrierRule.setDbEnv(DBENV);
        tracfoneOneCarrierRule.setObjId("SAMPLE");
        tracfoneOneCarrierRule.setTechnology("CDMA");
        when(tracfoneCarrierMaintenanceAction.insertCarrierRule(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertCarrierRule(tracfoneOneCarrierRule, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneCarrierRule.getObjId());
    }

    @Test
    public void testInsertCarrierRule_whenException() throws Exception {
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        tracfoneOneCarrierRule.setDbEnv(DBENV);
        tracfoneOneCarrierRule.setObjId("1000");
        tracfoneOneCarrierRule.setTechnology("CDMA");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertCarrierRule(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.insertCarrierRule(tracfoneOneCarrierRule, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_CARRIER_RULE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_CARRIER_RULE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertOrderType() throws Exception {
        List<TracfoneOneOrderType> tracfoneOneOrderTypes = new ArrayList<>();
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("SAMPLE");
        tracfoneOneOrderType.setNpa("NPA");
        tracfoneOneOrderTypes.add(tracfoneOneOrderType);

        List<TFOneOrderType> tfOneOrderTypes = new ArrayList<>();
        TFOneOrderType tfOneOrderType = new TFOneOrderType();
        tfOneOrderType.setObjId("1000");
        tfOneOrderType.setNpa("NPA");
        tfOneOrderTypes.add(tfOneOrderType);

        when(tracfoneCarrierMaintenanceAction.insertOrderType(any(), anyInt())).thenReturn(tfOneOrderTypes);
        List<TFOneOrderType> response = tracfoneCarrierMaintenanceController.insertOrderType(tracfoneOneOrderTypes, 1000);
        assertEquals("[TracfoneOneOrderType{, objId='1000', orderType='null', npa='NPA', nxx='null', billCycle='null', dealerCode='null', ldAccountNum='null', marketCode='null', orderType2xTransProfile='null', orderType2xCarrier='null'}]", response.toString());
    }

    @Test
    public void testInsertOrderType_whenException() throws Exception {
        List<TracfoneOneOrderType> tracfoneOneOrderTypes = new ArrayList<>();
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("1000");
        tracfoneOneOrderType.setNpa("NPA");
        tracfoneOneOrderTypes.add(tracfoneOneOrderType);
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertOrderType(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.insertOrderType(tracfoneOneOrderTypes, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_ORDER_TYPE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_ORDER_TYPE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierRules() throws Exception {
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        tracfoneOneCarrierRule.setDbEnv(DBENV);
        tracfoneOneCarrierRule.setObjId("1000");

        List<TFOneCarrierRule> tfOneCarrierRules = new ArrayList<>();
        TFOneCarrierRule tfOneCarrierRule = new TFOneCarrierRule();
        tfOneCarrierRule.setCoolingPeriod("COOLING_PERIOD");
        tfOneCarrierRules.add(tfOneCarrierRule);
        when(tracfoneCarrierMaintenanceAction.searchCarrierRules(any())).thenReturn(tfOneCarrierRules);
        List<TFOneCarrierRule> response = tracfoneCarrierMaintenanceController.searchCarrierRules(tracfoneOneCarrierRule);
        assertEquals("[TFOneCarrierRule{objId='null', coolingPeriod='COOLING_PERIOD', esnChangeDays='null', lineExpireDays='null', lineReturnDays='null', coolingAfterInsert='null', npaNxxFlag='null', usedLineExpireDays='null', gsmGracePeriod='null', technology='null', reserveOnSuspend='null', reservePeriod='null', deacAfterGrace='null', cancelSuspendDays='null', cancelSuspend='null', blockCreateActItem='null', allow2gAct='null', allow2gReact='null', allowNonHdActs='null', allowNonHdReacts='null'}]", response.toString());
    }

    @Test
    public void testSearchCarrierRules_whenException() throws Exception {
        TracfoneOneCarrierRule tracfoneOneCarrierRule = new TracfoneOneCarrierRule();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchCarrierRules(any());
        try {
            tracfoneCarrierMaintenanceController.searchCarrierRules(tracfoneOneCarrierRule);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_CARRIER_RULE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_CARRIER_RULE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchDataConfigs() throws Exception {
        TracfoneOneDataConfig tracfoneOneDataConfig = new TracfoneOneDataConfig();
        tracfoneOneDataConfig.setDbEnv(DBENV);
        tracfoneOneDataConfig.setApn("APN");

        List<TFOneDataConfig> dataConfigs = new ArrayList<>();
        TFOneDataConfig dataConfig = new TFOneDataConfig();
        dataConfig.setApn("APN");
        dataConfigs.add(dataConfig);
        when(tracfoneCarrierMaintenanceAction.searchDataConfigs(any())).thenReturn(dataConfigs);
        List<TFOneDataConfig> response = tracfoneCarrierMaintenanceController.searchDataConfigs(tracfoneOneDataConfig);
        assertEquals("[TracfoneOneDataConfig{, objId='null', dev='null', parentId='null', partClassObjId='null', xDefault='null', ipAddress='null', apn='APN', homePage='null', mmsc='null', cmd148CarrierDataSwitch='null', dataSwitch='null', cmd71GprsApn='null', cmd150ClearProxy='null', cmd121GatewayPortUpdate='null', cmd121GatewayIpUpdate='null', cmd71MmscUpdate='null', cmd71GatewayHome='null', cmd121GatewayIpPortUpdate='null'}]", response.toString());
    }

    @Test
    public void testSearchDataConfigs_whenException() throws Exception {
        TracfoneOneDataConfig tracfoneOneDataConfig = new TracfoneOneDataConfig();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchDataConfigs(any());
        try {
            tracfoneCarrierMaintenanceController.searchDataConfigs(tracfoneOneDataConfig);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_DATA_CONFIG_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_DATA_CONFIG_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllPartClasses() throws Exception {
        List<TFOnePartClass> allPartClasses = new ArrayList<>();
        TFOnePartClass allPartClass = new TFOnePartClass();
        allPartClass.setName("NAME");
        allPartClass.setObjId("100");
        allPartClasses.add(allPartClass);
        when(tracfoneCarrierMaintenanceAction.getAllPartClasses(any())).thenReturn(allPartClasses);
        List<TFOnePartClass> response = tracfoneCarrierMaintenanceController.getAllPartClasses(DBENV);
        assertEquals("[TracfoneOnePartClass{, objId='100', name='NAME'}]", response.toString());
    }

    @Test
    public void testGetAllPartClasses_whenException() throws Exception {
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).getAllPartClasses(any());
        try {
            tracfoneCarrierMaintenanceController.getAllPartClasses(DBENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_PART_CLASS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_PART_CLASS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteOrderType() throws Exception {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("SAMPLE");
        when(tracfoneCarrierMaintenanceAction.deleteOrderType(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.deleteOrderType(tracfoneOneOrderType, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneOrderType.getObjId());
    }

    @Test
    public void testDeleteOrderType_whenException() throws Exception {
        TracfoneOneOrderType tracfoneOneOrderType = new TracfoneOneOrderType();
        tracfoneOneOrderType.setDbEnv(DBENV);
        tracfoneOneOrderType.setObjId("1000");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).deleteOrderType(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.deleteOrderType(tracfoneOneOrderType, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_ORDER_TYPE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_ORDER_TYPE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertIgOrderTypes() throws Exception {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        tracfoneOneIgOrderType.setProgrammeName("INSERT");
        tracfoneOneIgOrderType.setIgOrderType("IG_ORDER");
        tracfoneOneIgOrderType.setActualOrderType("ACTUAL_IG");
        tracfoneOneIgOrderType.setPriority("1");
        tracfoneOneIgOrderType.setProcessIgateIN3Flag("Y");
        tracfoneOneIgOrderType.setProcessIgateIN3LiteFlag("Y");
        tracfoneOneIgOrderType.setUpdateXCase2TaskFlag("Y");
        tracfoneOneIgOrderType.setNewerTransFlag("Y");


        when(tracfoneCarrierMaintenanceAction.isDuplicateOrderType(any())).thenReturn(false);
        when(tracfoneCarrierMaintenanceAction.insertIgOrderTypes(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertIgOrderTypes(tracfoneOneIgOrderType, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testInsertIgOrderTypes_whenException() throws Exception {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertIgOrderTypes(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.insertIgOrderTypes(tracfoneOneIgOrderType, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_IG_ORDER_TYPES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_IG_ORDER_TYPES_ERROR_MESSAGE, e.getErrorMessage());
        }

        // duplicate
        when(tracfoneCarrierMaintenanceAction.isDuplicateOrderType(any())).thenReturn(true);
        try {
            tracfoneCarrierMaintenanceController.insertIgOrderTypes(tracfoneOneIgOrderType, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DUPLICATE_IG_ORDER_TYPES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DUPLICATE_IG_ORDER_TYPES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchIgOrderTypes() throws Exception {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        tracfoneOneIgOrderType.setProgrammeName("SAMPLE");
        tracfoneOneIgOrderType.setIgOrderType("ORDER");
        tracfoneOneIgOrderType.setPriority("1");

        List<TFOneIgOrderType> tfOneIgOrderTypes = new ArrayList<>();
        TFOneIgOrderType tfOneIGOrderType = new TFOneIgOrderType();
        tfOneIGOrderType.setProgrammeName("SAMPLE");
        tfOneIGOrderType.setIgOrderType("ORDER");
        tfOneIGOrderType.setPriority("1");
        tfOneIgOrderTypes.add(tfOneIGOrderType);
        when(tracfoneCarrierMaintenanceAction.searchIgOrderTypes(any(), anyBoolean())).thenReturn(tfOneIgOrderTypes);
        List<TFOneIgOrderType> response = tracfoneCarrierMaintenanceController.searchIgOrderTypes(tracfoneOneIgOrderType, false);
        assertEquals("[TFOneIgOrderType{programmeName=\'SAMPLE\', actualOrderType=\'null\', igOrderType=\'ORDER\', sqlText=\'null\', priority=\'1\', createSOGencodeFlag=\'null\', createMFormIGFlag=\'null\', createMFormPortFlag=\'null\', skipMinValidationForm=\'null\', skipESNValidationFlag=\'null\', createIGAPNFlag=\'null\', insertILDTransFlag=\'null\', bogoConfigFlag=\'null\', sUIActionType=\'null\', updateMSIDFlag=\'null\', addonCashCardFlag=\'null\', contactPinUpdateFlag=\'null\', brmNotificationFlag=\'null\', newerTransFlag=\'null\', skipMinUpdateFlag=\'null\', safeLinkBatchFlag=\'null\', createBucketsFlag=\'null\', processIgateIN3Flag=\'null\', processIgateIN3LiteFlag=\'null\', updateXCase2TaskFlag=\'null\', depIGTransFlag=\'null\', generateAccountFlag=\'null\', createIGACMFlag=\'null\'}]", response.toString());
    }

    @Test
    public void testSearchIgOrderTypes_whenException() throws Exception {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchIgOrderTypes(any(), anyBoolean());
        try {
            tracfoneCarrierMaintenanceController.searchIgOrderTypes(tracfoneOneIgOrderType, false);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_IG_ORDER_TYPES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_IG_ORDER_TYPES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateIgOrderTypes() throws Exception {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        tracfoneOneIgOrderType.setDbEnv(DBENV);
        tracfoneOneIgOrderType.setProgrammeName("SAMPLE");
        tracfoneOneIgOrderType.setIgOrderType("ORDER");
        tracfoneOneIgOrderType.setPriority("1");
        when(tracfoneCarrierMaintenanceAction.updateIgOrderTypes(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateIgOrderTypes(tracfoneOneIgOrderType, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneIgOrderType.getProgrammeName());
    }

    @Test
    public void testUpdateIgOrderTypes_whenException() throws Exception {
        TracfoneOneIgOrderType tracfoneOneIgOrderType = new TracfoneOneIgOrderType();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateIgOrderTypes(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateIgOrderTypes(tracfoneOneIgOrderType, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_IG_ORDER_TYPES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_IG_ORDER_TYPES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottlePolicy() throws Exception {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        tracfoneOneThrottlePolicy.setDbEnv(DBENV);
        tracfoneOneThrottlePolicy.setPolicyName("TEST");
        tracfoneOneThrottlePolicy.setPolicyDesc("DESC");

        when(tracfoneCarrierMaintenanceAction.insertThrottlePolicy(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertThrottlePolicy(tracfoneOneThrottlePolicy, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testInsertThrottlePolicy_whenException() throws Exception {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertThrottlePolicy(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.insertThrottlePolicy(tracfoneOneThrottlePolicy, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_THROTTLE_POLICY_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_THROTTLE_POLICY_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottleRule() throws Exception {
        List<TracfoneOneThrottleRule> rules = new ArrayList<>();
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        tracfoneOneThrottleRule.setDbEnv(DBENV);
        tracfoneOneThrottleRule.setParentId("123");
        tracfoneOneThrottleRule.setPolicyId("123");
        tracfoneOneThrottleRule.setRuleDesc("DESC");
        rules.add(tracfoneOneThrottleRule);

        List<TFOneThrottleRule> tfOneThrottleRules = new ArrayList<>();
        when(tracfoneCarrierMaintenanceAction.insertThrottleRules(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertThrottleRules(rules, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testInsertThrottleRule_whenException() throws Exception {
        List<TracfoneOneThrottleRule> rules = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertThrottleRules(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.insertThrottleRules(rules, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_THROTTLE_RULE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_THROTTLE_RULE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertThrottleFeature() throws Exception {
        List<TracfoneOneThrottleFeature> features = new ArrayList<>();
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        tracfoneOneThrottleFeature.setDbEnv(DBENV);
        tracfoneOneThrottleFeature.setRuleId("123");
        tracfoneOneThrottleFeature.setFeatureFlagValue("TEST");
        tracfoneOneThrottleFeature.setFeatureName("TEST");
        features.add(tracfoneOneThrottleFeature);
        List<TFOneThrottleFeature> tfOneThrottleFeatures = new ArrayList<>();
        when(tracfoneCarrierMaintenanceAction.insertThrottleFeatures(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertThrottleFeatures(features, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testInsertThrottleFeature_whenException() throws Exception {
        List<TracfoneOneThrottleFeature> features = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertThrottleFeatures(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.insertThrottleFeatures(features, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_THROTTLE_FEATURE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_THROTTLE_FEATURE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchThrottlePolicy() throws Exception {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        tracfoneOneThrottlePolicy.setDbEnv(DBENV);
        tracfoneOneThrottlePolicy.setPolicyName("TEST");
        tracfoneOneThrottlePolicy.setPolicyDesc("DESC");


        List<TFOneThrottlePolicy> tfOneThrottlePolicies = new ArrayList<>();
        TFOneThrottlePolicy tfOneThrottlePolicy = new TFOneThrottlePolicy();
        tfOneThrottlePolicy.setPolicyName("TEST");
        tfOneThrottlePolicy.setPolicyDesc("DESC");
        tfOneThrottlePolicies.add(tfOneThrottlePolicy);
        when(tracfoneCarrierMaintenanceAction.searchThrottlePolicies(any())).thenReturn(tfOneThrottlePolicies);
        List<TFOneThrottlePolicy> response = tracfoneCarrierMaintenanceController.searchThrottlePolicies(tracfoneOneThrottlePolicy);
        assertEquals("[TFOneThrottlePolicy{objId=\'null\', policyName=\'TEST\', policyDesc=\'DESC\', bypassTransQueue=\'null\', dataSuspendedFlag=\'null\'}]", response.toString());
    }

    @Test
    public void testSearchThrottlePolicy_whenException() throws Exception {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchThrottlePolicies(any());
        try {
            tracfoneCarrierMaintenanceController.searchThrottlePolicies(tracfoneOneThrottlePolicy);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_THROTTLE_POLICY_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_THROTTLE_POLICY_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchThrottleRule() throws Exception {
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        tracfoneOneThrottleRule.setDbEnv(DBENV);
        tracfoneOneThrottleRule.setParentId("123");
        tracfoneOneThrottleRule.setPolicyId("123");
        tracfoneOneThrottleRule.setRuleDesc("DESC");

        List<TFOneThrottleRule> tfOneThrottleRules = new ArrayList<>();
        TFOneThrottleRule tfOneThrottleRule = new TFOneThrottleRule();
        tfOneThrottleRule.setParentId("123");
        tfOneThrottleRule.setPolicyId("123");
        tfOneThrottleRule.setRuleDesc("DESC");
        tfOneThrottleRules.add(tfOneThrottleRule);
        when(tracfoneCarrierMaintenanceAction.searchThrottleRules(any())).thenReturn(tfOneThrottleRules);
        List<TFOneThrottleRule> response = tracfoneCarrierMaintenanceController.searchThrottleRules(tracfoneOneThrottleRule);
        assertEquals("[TFOneThrottleRule{objId=\'null\', parentId=\'123\', policyId=\'123\', ruleDesc=\'DESC\', status=\'null\'}]", response.toString());
    }

    @Test
    public void testSearchThrottleRule_whenException() throws Exception {
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchThrottleRules(any());
        try {
            tracfoneCarrierMaintenanceController.searchThrottleRules(tracfoneOneThrottleRule);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_THROTTLE_RULE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_THROTTLE_RULE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchThrottleFeatures() throws Exception {
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        tracfoneOneThrottleFeature.setDbEnv(DBENV);
        tracfoneOneThrottleFeature.setRuleId("123");
        tracfoneOneThrottleFeature.setFeatureFlagValue("TEST");
        tracfoneOneThrottleFeature.setFeatureName("TEST");

        List<TFOneThrottleFeature> tfOneThrottleFeatures = new ArrayList<>();
        TFOneThrottleFeature tfOneThrottleFeature = new TFOneThrottleFeature();
        tfOneThrottleFeature.setRuleId("123");
        tfOneThrottleFeature.setFeatureFlagName("TEST");
        tfOneThrottleFeature.setFeatureName("TEST");
        tfOneThrottleFeatures.add(tfOneThrottleFeature);
        when(tracfoneCarrierMaintenanceAction.searchThrottleFeatures(any())).thenReturn(tfOneThrottleFeatures);
        List<TFOneThrottleFeature> response = tracfoneCarrierMaintenanceController.searchThrottleFeatures(tracfoneOneThrottleFeature);
        assertEquals("[TFOneThrottleFeatures{objId=\'null\', ruleId=\'123\', featureFlagName=\'TEST\', featureFlagValue=\'null\', featureName=\'TEST\', featureValue=\'null\', status=\'null\'}]", response.toString());
    }

    @Test
    public void testSearchThrottleFeatures_whenException() throws Exception {
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchThrottleFeatures(any());
        try {
            tracfoneCarrierMaintenanceController.searchThrottleFeatures(tracfoneOneThrottleFeature);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_THROTTLE_FEATURES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_THROTTLE_FEATURES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateThrottlePolicy() throws Exception {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        tracfoneOneThrottlePolicy.setDbEnv(DBENV);
        tracfoneOneThrottlePolicy.setObjId("SAMPLE");
        tracfoneOneThrottlePolicy.setPolicyName("TEST");
        tracfoneOneThrottlePolicy.setPolicyDesc("DESC");
        when(tracfoneCarrierMaintenanceAction.updateThrottlePolicy(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateThrottlePolicy(tracfoneOneThrottlePolicy, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneThrottlePolicy.getObjId());
    }

    @Test
    public void testUpdateThrottlePolicy_whenException() throws Exception {
        TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy = new TracfoneOneThrottlePolicy();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateThrottlePolicy(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateThrottlePolicy(tracfoneOneThrottlePolicy, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_THROTTLE_POLICY_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_THROTTLE_POLICY_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateThrottleRule() throws Exception {
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        tracfoneOneThrottleRule.setDbEnv(DBENV);
        tracfoneOneThrottleRule.setObjId("SAMPLE");
        tracfoneOneThrottleRule.setParentId("123");
        tracfoneOneThrottleRule.setPolicyId("123");
        tracfoneOneThrottleRule.setRuleDesc("DESC");
        when(tracfoneCarrierMaintenanceAction.updateThrottleRule(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateThrottleRule(tracfoneOneThrottleRule, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneThrottleRule.getObjId());
    }

    @Test
    public void testUpdateThrottleRule_whenException() throws Exception {
        TracfoneOneThrottleRule tracfoneOneThrottleRule = new TracfoneOneThrottleRule();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateThrottleRule(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateThrottleRule(tracfoneOneThrottleRule, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_THROTTLE_RULE_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_THROTTLE_RULE_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateThrottleFeature() throws Exception {
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        tracfoneOneThrottleFeature.setDbEnv(DBENV);
        tracfoneOneThrottleFeature.setObjId("SAMPLE");
        tracfoneOneThrottleFeature.setRuleId("123");
        tracfoneOneThrottleFeature.setFeatureFlagValue("TEST");
        tracfoneOneThrottleFeature.setFeatureName("TEST");
        when(tracfoneCarrierMaintenanceAction.updateThrottleFeature(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateThrottleFeature(tracfoneOneThrottleFeature, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneThrottleFeature.getObjId());
    }

    @Test
    public void testUpdateThrottleFeature_whenException() throws Exception {
        TracfoneOneThrottleFeature tracfoneOneThrottleFeature = new TracfoneOneThrottleFeature();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateThrottleFeature(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateThrottleFeature(tracfoneOneThrottleFeature, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_THROTTLE_FEATURES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_THROTTLE_FEATURES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchVerizonZipNPANXX() throws Exception {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("TEST");
        tracfoneOneVerizonZipNPANXX.setZip("07832");

        List<TFOneVerizonZipNPANXX> tfOneVerizonZipNPANXXs = new ArrayList<>();
        TFOneVerizonZipNPANXX tfOneVerizonZipNPANXX = new TFOneVerizonZipNPANXX();
        tfOneVerizonZipNPANXX.setAccountNum("123");
        tfOneVerizonZipNPANXX.setnPANXX("TEST");
        tfOneVerizonZipNPANXX.setZip("07832");
        tfOneVerizonZipNPANXXs.add(tfOneVerizonZipNPANXX);
        when(tracfoneCarrierMaintenanceAction.searchVerizonZipNPANXX(any())).thenReturn(tfOneVerizonZipNPANXXs);
        List<TFOneVerizonZipNPANXX> response = tracfoneCarrierMaintenanceController.searchVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX);
        assertEquals("[TFOneVerizonZipNPANXX{zip='07832', NPA='null', NXX='null', NPANXX='TEST', AccountNum='123', template='null'}]", response.toString());
    }

    @Test
    public void testSearchVerizonZipNPANXX_whenException() throws Exception {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchVerizonZipNPANXX(any());
        try {
            tracfoneCarrierMaintenanceController.searchVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_VERIZON_ZIP_NPANXX_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_VERIZON_ZIP_NPANXX_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertVerizonZipNPANXX() throws TracfoneOneException {
        List<TracfoneOneVerizonZipNPANXX> tracfoneOneVerizonZipNPANXXs = new ArrayList<>();
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("TEST");
        tracfoneOneVerizonZipNPANXX.setZip("07832");
        tracfoneOneVerizonZipNPANXXs.add(tracfoneOneVerizonZipNPANXX);
        when(tracfoneCarrierMaintenanceAction.insertVerizonZipNPANXX(any(), anyInt(), any())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testInsertVerizonZipNPANXX_whenException() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertVerizonZipNPANXX(any(), anyInt(), any());
        try {
            tracfoneCarrierMaintenanceController.insertVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_VERIZON_ZIP_NPANXX_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_VERIZON_ZIP_NPANXX_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateVerizonZipNPANXX() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("SAMPLE");
        tracfoneOneVerizonZipNPANXX.setZip("07832");
        tracfoneOneVerizonZipNPANXX.setCheckDuplicate(true);
        when(tracfoneCarrierMaintenanceAction.updateVerizonZipNPANXX(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneVerizonZipNPANXX.getnPANXX());
    }

    @Test
    public void testUpdateVerizonZipNPANXX_whenException() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateVerizonZipNPANXX(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_VERIZON_ZIP_NPANXX_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_VERIZON_ZIP_NPANXX_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteVerizonZipNPANXX() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        tracfoneOneVerizonZipNPANXX.setDbEnv(DBENV);
        tracfoneOneVerizonZipNPANXX.setAccountNum("123");
        tracfoneOneVerizonZipNPANXX.setnPANXX("SAMPLE");
        tracfoneOneVerizonZipNPANXX.setZip("07832");
        when(tracfoneCarrierMaintenanceAction.deleteVerizonZipNPANXX(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.deleteVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneVerizonZipNPANXX.getnPANXX());
    }

    @Test
    public void testDeleteVerizonZipNPANXX_whenException() throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX = new TracfoneOneVerizonZipNPANXX();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).deleteVerizonZipNPANXX(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.deleteVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_VERIZON_ZIP_NPANXX_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_VERIZON_ZIP_NPANXX_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    /**
     * Junits for Srint-25
     */

    @Test
    public void testSearchTmoZipNgp() throws Exception {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");

        List<TFOneTmoZipNgp> tfOneTmoZipNgps = new ArrayList<>();
        TFOneTmoZipNgp tfOneTmoZipNgp = new TFOneTmoZipNgp();
        tfOneTmoZipNgp.setNgp("TEST");
        tfOneTmoZipNgp.setPriority("1");
        tfOneTmoZipNgp.setZip("07832");
        tfOneTmoZipNgps.add(tfOneTmoZipNgp);
        when(tracfoneCarrierMaintenanceAction.searchTmoZipNgp(any())).thenReturn(tfOneTmoZipNgps);
        List<TFOneTmoZipNgp> response = tracfoneCarrierMaintenanceController.searchTmoZipNgp(tracfoneOneTmoZipNgp);
        assertEquals("[TFOneTmoZipNgp{zip='07832', ngp='TEST', ngpName='null', priority='1'}]", response.toString());
    }

    @Test
    public void testSearchTmoZipNgp_whenException() throws Exception {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchTmoZipNgp(any());
        try {
            tracfoneCarrierMaintenanceController.searchTmoZipNgp(tracfoneOneTmoZipNgp);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_TMO_ZIP_NGP_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_TMO_ZIP_NGP_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertTmoZipNgp() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        when(tracfoneCarrierMaintenanceAction.insertTmoZipNgp(any(), anyInt(), any())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertTmoZipNgp(tracfoneOneTmoZipNgp, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testInsertTmoZipNgp_whenException() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertTmoZipNgp(any(), anyInt(), any());
        try {
            tracfoneCarrierMaintenanceController.insertTmoZipNgp(tracfoneOneTmoZipNgp, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_TMO_ZIP_NGP_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_TMO_ZIP_NGP_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateTmoZipNgp() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        tracfoneOneTmoZipNgp.setNgp("SAMPLE");
        tracfoneOneTmoZipNgp.setCheckDuplicate(true);
        when(tracfoneCarrierMaintenanceAction.updateTmoZipNgp(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateTmoZipNgp(tracfoneOneTmoZipNgp, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneTmoZipNgp.getNgp());
    }

    @Test
    public void testUpdateTmoZipNgp_whenException() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateTmoZipNgp(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateTmoZipNgp(tracfoneOneTmoZipNgp, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteTmoZipNgp() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        tracfoneOneTmoZipNgp.setNgp("SAMPLE");
        when(tracfoneCarrierMaintenanceAction.deleteTmoZipNgp(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.deleteTmoZipNgp(tracfoneOneTmoZipNgp, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), tracfoneOneTmoZipNgp.getNgp());
    }

    @Test
    public void testDeleteTmoZipNgp_whenException() throws TracfoneOneException {
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).deleteTmoZipNgp(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.deleteTmoZipNgp(tracfoneOneTmoZipNgp, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_TMO_ZIP_NGP_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_TMO_ZIP_NGP_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCingularMrktInfo() throws Exception {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");

        List<TFOneCingularMrktInfo> tfOneTmoZipNgps = new ArrayList<>();
        TFOneCingularMrktInfo tfOneCingularMrktInfo = new TFOneCingularMrktInfo();
        tfOneCingularMrktInfo.setMkt("TEST");
        tfOneCingularMrktInfo.setNpanxx("1");
        tfOneCingularMrktInfo.setZip("07832");
        tfOneCingularMrktInfo.setRcState("TEST");
        tfOneCingularMrktInfo.setRcName("TEST");
        tfOneCingularMrktInfo.setRcNumber("TEST");
        tfOneCingularMrktInfo.setTemplate("TEST");
        tfOneTmoZipNgps.add(tfOneCingularMrktInfo);
        when(tracfoneCarrierMaintenanceAction.searchCingularMrktInfo(any())).thenReturn(tfOneTmoZipNgps);
        List<TFOneCingularMrktInfo> response = tracfoneCarrierMaintenanceController.searchCingularMrktInfo(tracfoneOneCingularMrktInfo);
        assertEquals("[TFOneCingularMrktInfo{mkt='TEST', npa='null', nxx='null', npanxx='1', rcNumber='TEST', rcName='TEST', rcState='TEST', zip='07832', mktType='null', accountNum='null', marketCode='null', dealerCode='null', subMarketId='null', template='TEST'}]", response.toString());
    }

    @Test
    public void testSearchCingularMrktInfo_whenException() throws Exception {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchCingularMrktInfo(any());
        try {
            tracfoneCarrierMaintenanceController.searchCingularMrktInfo(tracfoneOneCingularMrktInfo);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_CINGULAR_MRKT_INFO_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_CINGULAR_MRKT_INFO_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCingularMrktInfo() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        when(tracfoneCarrierMaintenanceAction.insertCingularMrktInfo(any(), anyInt(), any())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertCingularMrktInfo(tracfoneOneCingularMrktInfo, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testInsertCingularMrktInfo_whenException() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertCingularMrktInfo(any(), anyInt(), any());
        try {
            tracfoneCarrierMaintenanceController.insertCingularMrktInfo(tracfoneOneCingularMrktInfo, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_CINGULAR_MRKT_INFO_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_CINGULAR_MRKT_INFO_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCingularMrktInfo() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        when(tracfoneCarrierMaintenanceAction.updateCingularMrktInfo(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateCingularMrktInfo(tracfoneOneCingularMrktInfo, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testUpdateCingularMrktInfo_whenException() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateCingularMrktInfo(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateCingularMrktInfo(tracfoneOneCingularMrktInfo, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CINGULAR_MRKT_INFO_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CINGULAR_MRKT_INFO_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCingularMrktInfo() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        tracfoneOneCingularMrktInfo.setDbEnv(DBENV);
        tracfoneOneCingularMrktInfo.setZip("123");
        when(tracfoneCarrierMaintenanceAction.deleteCingularMrktInfo(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.deleteCingularMrktInfo(tracfoneOneCingularMrktInfo, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testDeleteCingularMrktInfo_whenException() throws TracfoneOneException {
        TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).deleteCingularMrktInfo(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.deleteCingularMrktInfo(tracfoneOneCingularMrktInfo, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_CINGULAR_MRKT_INFO_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_CINGULAR_MRKT_INFO_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    /**
     * Junits for Srint-26
     */

    @Test
    public void testSearchNotCertifyModel() throws Exception {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");

        List<TFOneNotCertifyModel> tfOneNotCertifyModels = new ArrayList<>();
        TFOneNotCertifyModel tfOneNotCertifyModel = new TFOneNotCertifyModel();
        tfOneNotCertifyModel.setParentId("100");
        tfOneNotCertifyModel.setDev("1");
        tfOneNotCertifyModel.setPartClassObjId("07832");
        tfOneNotCertifyModels.add(tfOneNotCertifyModel);
        when(tracfoneCarrierMaintenanceAction.searchNotCertifyModel(any())).thenReturn(tfOneNotCertifyModels);
        List<TFOneNotCertifyModel> response = tracfoneCarrierMaintenanceController.searchNotCertifyModel(tracfoneOneNotCertifyModel);
        assertEquals("[TFOneNotCertifyModel{objId='null', dev='1', parentId='100', partClassObjId='07832'}]", response.toString());
    }

    @Test
    public void testSearchNotCertifyModel_whenException() throws Exception {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchNotCertifyModel(any());
        try {
            tracfoneCarrierMaintenanceController.searchNotCertifyModel(tracfoneOneNotCertifyModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_NOT_CERTIFY_MODEL_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_NOT_CERTIFY_MODEL_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertNotCertifyModel() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        when(tracfoneCarrierMaintenanceAction.insertNotCertifyModel(any(), anyInt(), any())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertNotCertifyModel(tracfoneOneNotCertifyModel, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testInsertNotCertifyModel_whenException() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertNotCertifyModel(any(), anyInt(), any());
        try {
            tracfoneCarrierMaintenanceController.insertNotCertifyModel(tracfoneOneNotCertifyModel, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_NOT_CERTIFY_MODEL_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_NOT_CERTIFY_MODEL_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateNotCertifyModel() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        when(tracfoneCarrierMaintenanceAction.updateNotCertifyModel(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateNotCertifyModel(tracfoneOneNotCertifyModel, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testUpdateNotCertifyModel_whenException() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateNotCertifyModel(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateNotCertifyModel(tracfoneOneNotCertifyModel, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteNotCertifyModel() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        when(tracfoneCarrierMaintenanceAction.deleteNotCertifyModel(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.deleteNotCertifyModel(tracfoneOneNotCertifyModel, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testDeleteNotCertifyModel_whenException() throws TracfoneOneException {
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).deleteNotCertifyModel(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.deleteNotCertifyModel(tracfoneOneNotCertifyModel, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_NOT_CERTIFY_MODEL_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_NOT_CERTIFY_MODEL_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testBulkUpdateNotCertifyModel() throws TracfoneOneException {
        List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModels = new ArrayList<>();
        TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel = new TracfoneOneNotCertifyModel();
        tracfoneOneNotCertifyModel.setDbEnv(DBENV);
        tracfoneOneNotCertifyModel.setParentId("123");
        tracfoneOneNotCertifyModel.setPartClassObjId("100");
        tracfoneOneNotCertifyModels.add(tracfoneOneNotCertifyModel);
        when(tracfoneCarrierMaintenanceAction.bulkUpdateNotCertifyModel(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.bulkUpdateNotCertifyModel(tracfoneOneNotCertifyModels, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testBulkUpdateNotCertifyModel_whenException() throws TracfoneOneException {
        List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModels = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).bulkUpdateNotCertifyModel(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.bulkUpdateNotCertifyModel(tracfoneOneNotCertifyModels, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    /**
     * Junits for Srint-27
     */

    @Test
    public void testBulkUpdateTmoZipNgp() throws TracfoneOneException {
        List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNgps = new ArrayList<>();
        TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp = new TracfoneOneTmoZipNgp();
        tracfoneOneTmoZipNgp.setDbEnv(DBENV);
        tracfoneOneTmoZipNgp.setZip("123");
        tracfoneOneTmoZipNgp.setPriority("07832");
        tracfoneOneTmoZipNgps.add(tracfoneOneTmoZipNgp);
        when(tracfoneCarrierMaintenanceAction.bulkUpdateTmoZipNgp(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.bulkUpdateTmoZipNgp(tracfoneOneTmoZipNgps, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testBulkUpdateTmoZipNgp_whenException() throws TracfoneOneException {
        List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNgps = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).bulkUpdateTmoZipNgp(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.bulkUpdateTmoZipNgp(tracfoneOneTmoZipNgps, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierSimPref() throws Exception {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");

        List<TFOneCarriersimpref> tfOneCarriersimprefs = new ArrayList<>();
        TFOneCarriersimpref tfOneCarriersimpref = new TFOneCarriersimpref();
        tfOneCarriersimpref.setCarrierName("TEST");
        tfOneCarriersimpref.setRank("1");
        tfOneCarriersimpref.setSimProfile("TEST");
        tfOneCarriersimpref.setMinDllExch("1");
        tfOneCarriersimpref.setMaxDllExch("1");
        tfOneCarriersimprefs.add(tfOneCarriersimpref);
        when(tracfoneCarrierMaintenanceAction.searchCarrierSimPref(any())).thenReturn(tfOneCarriersimprefs);
        List<TFOneCarriersimpref> response = tracfoneCarrierMaintenanceController.searchCarrierSimPref(tracfoneOneCarriersimpref);
        assertEquals("[TFOneCarriersimpref{rank='1', minDllExch='1', maxDllExch='1', carrierName='TEST', simProfile='TEST'}]", response.toString());
    }

    @Test
    public void testSearchCarrierSimPref_whenException() throws Exception {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchCarrierSimPref(any());
        try {
            tracfoneCarrierMaintenanceController.searchCarrierSimPref(tracfoneOneCarriersimpref);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_CARRIERSIMPREF_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_CARRIERSIMPREF_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierSimPref() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        when(tracfoneCarrierMaintenanceAction.insertCarrierSimPref(any(), anyInt(), any())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertCarrierSimPref(tracfoneOneCarriersimpref, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testInsertCarrierSimPref_whenException() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertCarrierSimPref(any(), anyInt(), any());
        try {
            tracfoneCarrierMaintenanceController.insertCarrierSimPref(tracfoneOneCarriersimpref, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_CARRIERSIMPREF_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_CARRIERSIMPREF_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierSimPref() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        when(tracfoneCarrierMaintenanceAction.updateCarrierSimPref(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateCarrierSimPref(tracfoneOneCarriersimpref, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testUpdateCarrierSimPref_whenException() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateCarrierSimPref(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateCarrierSimPref(tracfoneOneCarriersimpref, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CARRIERSIMPREF_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CARRIERSIMPREF_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierSimPref() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        when(tracfoneCarrierMaintenanceAction.deleteCarrierSimPref(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.deleteCarrierSimPref(tracfoneOneCarriersimpref, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testDeleteCarrierSimPref_whenException() throws TracfoneOneException {
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).deleteCarrierSimPref(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.deleteCarrierSimPref(tracfoneOneCarriersimpref, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_CARRIERSIMPREF_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_CARRIERSIMPREF_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testBulkUpdateCarrierSimPref() throws TracfoneOneException {
        List<TracfoneOneCarrierSimPref> tracfoneOneCarrierSimPrefs = new ArrayList<>();
        TracfoneOneCarrierSimPref tracfoneOneCarriersimpref = new TracfoneOneCarrierSimPref();
        tracfoneOneCarriersimpref.setDbEnv(DBENV);
        tracfoneOneCarriersimpref.setCarrierName("TEST");
        tracfoneOneCarriersimpref.setRank("1");
        tracfoneOneCarriersimpref.setSimProfile("TEST");
        tracfoneOneCarriersimpref.setMinDllExch("1");
        tracfoneOneCarriersimpref.setMaxDllExch("1");
        tracfoneOneCarrierSimPrefs.add(tracfoneOneCarriersimpref);
        when(tracfoneCarrierMaintenanceAction.bulkUpdateCarrierSimPref(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.bulkUpdateCarrierSimPref(tracfoneOneCarrierSimPrefs, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testBulkUpdateCarrierSimPref_whenException() throws TracfoneOneException {
        List<TracfoneOneCarrierSimPref> tracfoneOneCarrierSimPrefs = new ArrayList<>();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).bulkUpdateCarrierSimPref(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.bulkUpdateCarrierSimPref(tracfoneOneCarrierSimPrefs, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CARRIERSIMPREF_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CARRIERSIMPREF_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchNpanxx2Carrierzones() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        tracfoneOneNpanxx2Carrierzones.setState("1");

        TFOneNpaNxx2CarrierZonesSearchResult tfOneNpanxx2Carrierzones = new TFOneNpaNxx2CarrierZonesSearchResult();
        TFOneNpanxx2Carrierzones tfOneNpanxx2Carrierzone = new TFOneNpanxx2Carrierzones();
        tfOneNpanxx2Carrierzone.setNpa("1");
        tfOneNpanxx2Carrierzone.setNxx("2");
        tfOneNpanxx2Carrierzone.setCarrierId("1");
        tfOneNpanxx2Carrierzone.setZone("1");
        tfOneNpanxx2Carrierzone.setSid("1");
        tfOneNpanxx2Carrierzone.setRateCenter("1");
        tfOneNpanxx2Carrierzone.setState("1");
        tfOneNpanxx2Carrierzones.getNpanxx2Carrierzones().add(tfOneNpanxx2Carrierzone);
        when(tracfoneCarrierMaintenanceAction.searchNpanxx2Carrierzones(any())).thenReturn(tfOneNpanxx2Carrierzones);
        TFOneNpaNxx2CarrierZonesSearchResult response = tracfoneCarrierMaintenanceController.searchNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        assertEquals("TFOneNpaNxx2CarrierZonesSearchResult{paginationSearch=null, npanxx2Carrierzones=[TFOneNpanxx2Carrierzones{npa='1', nxx='2', carrierId='1', carrierName='null', leadTime='null', targetLevel='null', rateCenter='1', state='1', carrierIdDescription='null', zone='1', county='null', marketId='null', mrktArea='null', sid='1', technology='null', frequency1='null', frequency2='null', btaMktNumber='null', btaMktName='null', gsmTech='null', cdmaTech='null', tdmaTech='null', mnc='null', dbEnv='null'}]}", response.toString());
    }

    @Test
    public void testSearchNpanxx2Carrierzones_whenException() throws Exception {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchNpanxx2Carrierzones(any());
        try {
            tracfoneCarrierMaintenanceController.searchNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_NPANXX_2_CARRIERZONES_ERROR, e.getErrorCode());
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_NPANXX_2_CARRIERZONES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertNpanxx2Carrierzones() throws TracfoneOneException {
        TFOneNpaNxx2CarrierZonesSearchResult tfOneNpanxx2Carrierzones = new TFOneNpaNxx2CarrierZonesSearchResult();
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setOldCarrierId("4");
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        tracfoneOneNpanxx2Carrierzones.setState("1");
        when(tracfoneCarrierMaintenanceAction.searchNpanxx2Carrierzones(any())).thenReturn(tfOneNpanxx2Carrierzones);
        when(tracfoneCarrierMaintenanceAction.insertNpanxx2Carrierzones(any(), anyInt(), any())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals("SAMPLE", response.getMessage());
    }

    @Test
    public void testInsertNpanxx2Carrierzones_whenException() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchNpanxx2Carrierzones(any());
        try {
            tracfoneCarrierMaintenanceController.insertNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals("TFE200", e.getErrorCode());
            assertEquals("Unable to get response from DB.", e.getErrorMessage());
        }
    }


    @Test
    public void testUpdateNpanxx2Carrierzones() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setOldCarrierId("4");
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        tracfoneOneNpanxx2Carrierzones.setState("1");
        tracfoneOneNpanxx2Carrierzones.setOldCarrierId("2");
        when(tracfoneCarrierMaintenanceAction.updateNpanxx2Carrierzones(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, 1000);
        assertEquals("Success", TFOneGeneralResponse.SUCCESS);
        assertEquals("SAMPLE", response.getMessage());
    }

    @Test
    public void testUpdateNpanxx2Carrierzones_whenException() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateNpanxx2Carrierzones(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_NPANXX2CARRIERZONES_ERROR, e.getErrorCode());
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_NPANXX2CARRIERZONES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteNpanxx2Carrierzones() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        tracfoneOneNpanxx2Carrierzones.setDbEnv(DBENV);
        tracfoneOneNpanxx2Carrierzones.setOldCarrierId("4");
        tracfoneOneNpanxx2Carrierzones.setNpa("1");
        tracfoneOneNpanxx2Carrierzones.setNxx("2");
        tracfoneOneNpanxx2Carrierzones.setCarrierId("1");
        tracfoneOneNpanxx2Carrierzones.setZone("1");
        tracfoneOneNpanxx2Carrierzones.setSid("1");
        tracfoneOneNpanxx2Carrierzones.setRateCenter("1");
        tracfoneOneNpanxx2Carrierzones.setState("1");
        when(tracfoneCarrierMaintenanceAction.deleteNpanxx2Carrierzones(any(), anyInt())).thenReturn(tFOneGeneralResponse);
//        doNothing().when(tracfoneRatePlanController).validateDeleteNpanxx2Carrierzones(any());
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.deleteNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, 1000);

        assertEquals("Success", TFOneGeneralResponse.SUCCESS);
        assertEquals("SAMPLE", response.getMessage());
    }

    @Test
    public void testDeleteNpanxx2Carrierzones_whenException() throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones = new TracfoneOneNpanxx2Carrierzones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).deleteNpanxx2Carrierzones(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.deleteNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_DELETE_NPANXX_2_CARRIERZONES_ERROR, e.getErrorCode());
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_DELETE_NPANXX_2_CARRIERZONES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    /**
     * Sprint - 31
     */

    @Test
    public void testSearchArUsaPostalZips() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        tracfoneOneArUsaPostalZips.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZips.setKeyCode("1");
        tracfoneOneArUsaPostalZips.setPostalCode("2");
        tracfoneOneArUsaPostalZips.setState("SD");
        tracfoneOneArUsaPostalZips.setCity("sd");


        List<TFOneArUsaPostalZips> tfOneArUsaPostalZips = new ArrayList<>();
        TFOneArUsaPostalZips tfOneArUsaPostalZip = new TFOneArUsaPostalZips();
        tfOneArUsaPostalZip.setKeyCode("1");
        tfOneArUsaPostalZip.setPostalCode("2");
        tfOneArUsaPostalZip.setState("SD");
        tfOneArUsaPostalZip.setCity("sd");
        tfOneArUsaPostalZips.add(tfOneArUsaPostalZip);
        when(tracfoneCarrierMaintenanceAction.getArUsaPostalZips(any())).thenReturn(tfOneArUsaPostalZips);
        List<TFOneArUsaPostalZips> response = tracfoneCarrierMaintenanceController.getArUsaPostalZips(tracfoneOneArUsaPostalZips);
        assertEquals("[TFOneArUsaPostalZip{postalCode='2', keyCode='1', state='SD', city='sd'}]", response.toString());
    }

    @Test
    public void testSearchArUsaPostalZips_whenException() throws Exception {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).getArUsaPostalZips(any());
        try {
            tracfoneCarrierMaintenanceController.getArUsaPostalZips(tracfoneOneArUsaPostalZips);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_GET_AR_USA_POSTAL_ZIPS_ERROR, e.getErrorCode());
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_GET_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testinsertArUsaPostalZips() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        tracfoneOneArUsaPostalZips.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZips.setKeyCode("1");
        tracfoneOneArUsaPostalZips.setPostalCode("2");
        tracfoneOneArUsaPostalZips.setState("SD");
        tracfoneOneArUsaPostalZips.setCity("sd");
        when(tracfoneCarrierMaintenanceAction.insertArUsaPostalZips(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertArUsaPostalZips(tracfoneOneArUsaPostalZips, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals("SAMPLE", response.getMessage());
    }

    @Test
    public void testinsertArUsaPostalZips_whenException() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertArUsaPostalZips(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.insertArUsaPostalZips(tracfoneOneArUsaPostalZips, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_ADD_AR_USA_POSTAL_ZIPS_ERROR, e.getErrorCode());
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_ADD_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateArUsaPostalZips() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        tracfoneOneArUsaPostalZips.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZips.setKeyCode("1");
        tracfoneOneArUsaPostalZips.setPostalCode("2");
        tracfoneOneArUsaPostalZips.setState("SD");
        tracfoneOneArUsaPostalZips.setCity("sd");
        when(tracfoneCarrierMaintenanceAction.updateArUsaPostalZips(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateArUsaPostalZips(tracfoneOneArUsaPostalZips, 1000);
        assertEquals("Success", TFOneGeneralResponse.SUCCESS);
        assertEquals("SAMPLE", response.getMessage());
    }

    @Test
    public void testUpdateArUsaPostalZips_whenException() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateArUsaPostalZips(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateArUsaPostalZips(tracfoneOneArUsaPostalZips, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_AR_USA_POSTAL_ZIPS_ERROR, e.getErrorCode());
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testdeleteArUsaPostalZips() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        tracfoneOneArUsaPostalZips.setDbEnv(DBENV);
        tracfoneOneArUsaPostalZips.setKeyCode("1");
        tracfoneOneArUsaPostalZips.setPostalCode("2");
        tracfoneOneArUsaPostalZips.setState("SD");
        tracfoneOneArUsaPostalZips.setCity("sd");
        when(tracfoneCarrierMaintenanceAction.deleteArUsaPostalZips(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.deleteArUsaPostalZips(tracfoneOneArUsaPostalZips, 1000);

        assertEquals("Success", TFOneGeneralResponse.SUCCESS);
        assertEquals("SAMPLE", response.getMessage());
    }

    @Test
    public void testdeleteArUsaPostalZips_whenException() throws TracfoneOneException {
        TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).deleteArUsaPostalZips(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.deleteArUsaPostalZips(tracfoneOneArUsaPostalZips, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_DELETE_AR_USA_POSTAL_ZIPS_ERROR, e.getErrorCode());
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_DELETE_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchArUsaMarketDetails() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        tracfoneOneArUsaMarket.setDbEnv(DBENV);
        tracfoneOneArUsaMarket.setKeyCode("8404611100");
        tracfoneOneArUsaMarket.setCarrierEntity("T-Mobile USA");


        TFOneArUsaMarketSearchResult arUsaMarketSearch = new TFOneArUsaMarketSearchResult();
        TFOneArUsaMarket tfOneArUsaMarket = new TFOneArUsaMarket();
        tfOneArUsaMarket.setKeyCode("8404611100");
        tfOneArUsaMarket.setCarrierEntity("T-Mobile USA");
        arUsaMarketSearch.getArUsaMarkets().add(tfOneArUsaMarket);
        when(tracfoneCarrierMaintenanceAction.getArUsaMarketDetails(any())).thenReturn(arUsaMarketSearch);
        TFOneArUsaMarketSearchResult response = tracfoneCarrierMaintenanceController.getArUsaMarketDetails(tracfoneOneArUsaMarket);
        assertEquals("TFArUsaMarketSearchResult{paginationSearch=null, arUsaMarkets=[TFOneArUsaMarket{keyCode='8404611100', nation='null', state='null', county='null', carrierEntity='T-Mobile USA', marketingName='null', mhzTotal='null', spectrumBlocks='null', cmaMktCode='null', cmaMktState='null', cmaMktName='null', cmaMktNameAlternate='null', cmaMktMultiState='null', btaMktCode='null', btaMktState='null', btaMktName='null', btaMktNameAlternate='null', btaMktMultiState='null', beaMktCode='null', beaMktState='null', beaMktName='null', beaMktNameAlternate='null', beaMktMultiState='null', protocol='null', extendedServices='null', bid1='null', bid1Name='null', bid1Bsid1='null', bid1Bsid2='null', bid1Bsid3='null', bid1Mnc='null', bid2='null', bid2Name='null', bid2Bsid1='null', bid2Bsid2='null', bid2Bsid3='null', bid2Mnc='null', bid3='null', bid3Name='null', bid3Bsid1='null', bid3Bsid2='null', bid3Bsid3='null', bid3Mnc='null', bid4='null', bid4Name='null', bid4Bsid1='null', bid4Bsid2='null', bid4Bsid3='null', bid4Mnc='null', oldKeyCode='null', oldCarrierEntity='null'}]}", response.toString());
    }

    @Test
    public void testSearchArUsaMarketDetails_whenException() throws Exception {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).getArUsaMarketDetails(any());
        try {
            tracfoneCarrierMaintenanceController.getArUsaMarketDetails(tracfoneOneArUsaMarket);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_GET_AR_USA_MARKET_DETAILS_ERROR, e.getErrorCode());
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_GET_AR_USA_MARKET_DETAILS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertArUsaMarketDetails() throws TracfoneOneException {
        TFOneArUsaMarketSearchResult tfOneNpanxx2Carrierzones = new TFOneArUsaMarketSearchResult();
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        tracfoneOneArUsaMarket.setDbEnv(DBENV);
        tracfoneOneArUsaMarket.setKeyCode("8404611100");
        tracfoneOneArUsaMarket.setCarrierEntity("T-Mobile USA");
        when(tracfoneCarrierMaintenanceAction.getArUsaMarketDetails(any())).thenReturn(tfOneNpanxx2Carrierzones);
        when(tracfoneCarrierMaintenanceAction.insertArUsaMarketDetails(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertArUsaMarketDetails(tracfoneOneArUsaMarket, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals("SAMPLE", response.getMessage());
    }

    @Test
    public void testInsertArUsaMarketDetails_whenException() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).getArUsaMarketDetails(any());
        try {
            tracfoneCarrierMaintenanceController.insertArUsaMarketDetails(tracfoneOneArUsaMarket, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals("TFE200", e.getErrorCode());
            assertEquals("Unable to get response from DB.", e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateArUsaMarketDetails() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        tracfoneOneArUsaMarket.setDbEnv(DBENV);
        tracfoneOneArUsaMarket.setKeyCode("8404611100");
        tracfoneOneArUsaMarket.setCarrierEntity("T-Mobile USA");
        tracfoneOneArUsaMarket.setOldKeyCode("8404611101");
        tracfoneOneArUsaMarket.setOldCarrierEntity("T-Mobile USA");
        when(tracfoneCarrierMaintenanceAction.updateArUsaMarketDetails(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateArUsaMarketDetails(tracfoneOneArUsaMarket, 1000);
        assertEquals("Success", TFOneGeneralResponse.SUCCESS);
        assertEquals("SAMPLE", response.getMessage());
    }

    @Test
    public void testUpdateArUsaMarketDetails_whenException() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateArUsaMarketDetails(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateArUsaMarketDetails(tracfoneOneArUsaMarket, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_AR_USA_MARKET_DETAILS_ERROR, e.getErrorCode());
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_AR_USA_MARKET_DETAILS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteArUsaMarketDetails() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        tracfoneOneArUsaMarket.setDbEnv(DBENV);
        tracfoneOneArUsaMarket.setKeyCode("8404611100");
        tracfoneOneArUsaMarket.setCarrierEntity("T-Mobile USA");
        when(tracfoneCarrierMaintenanceAction.deleteArUsaMarketDetails(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.deleteArUsaMarketDetails(tracfoneOneArUsaMarket, 1000);

        assertEquals("Success", TFOneGeneralResponse.SUCCESS);
        assertEquals("SAMPLE", response.getMessage());
    }

    @Test
    public void testDeleteArUsaMarketDetails_whenException() throws TracfoneOneException {
        TracfoneOneArUsaMarket tracfoneOneArUsaMarket = new TracfoneOneArUsaMarket();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).deleteArUsaMarketDetails(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.deleteArUsaMarketDetails(tracfoneOneArUsaMarket, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_DELETE_AR_USA_MARKET_DETAILS_ERROR, e.getErrorCode());
            assertEquals(TracfoneOneConstantPlanWizard.TRACFONE_DELETE_AR_USA_MARKET_DETAILS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertGeoLoc() throws Exception {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        tfOneGeoLoc.setZip("11122");
        tfOneGeoLoc.setRzg2user("1");
        tfOneGeoLoc.setCrlatitude("11122");
        tfOneGeoLoc.setLongitude("11122");
        when(tracfoneCarrierMaintenanceAction.insertGeoLoc(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertGeoLoc(tfOneGeoLoc, 1000);
        assertEquals("Success", TFOneGeneralResponse.SUCCESS);
        assertEquals("SAMPLE", response.getMessage());
    }

    @Test
    public void testInsertGeoLoc_whenException() throws Exception {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        tfOneGeoLoc.setZip("11122");
        tfOneGeoLoc.setRzg2user("1");
        tfOneGeoLoc.setCrlatitude("11122");
        tfOneGeoLoc.setLongitude("11122");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertGeoLoc(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.insertGeoLoc(tfOneGeoLoc, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_GEO_LOC_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_GEO_LOC_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteGeoLoc() throws Exception {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        tfOneGeoLoc.setZip("11122");
        tfOneGeoLoc.setRzg2user("1");
        tfOneGeoLoc.setCrlatitude("11122");
        tfOneGeoLoc.setLongitude("11122");
        when(tracfoneCarrierMaintenanceAction.deleteGeoLoc(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.deleteGeoLoc(tfOneGeoLoc, 1000);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals("SAMPLE", response.getMessage());
    }

    @Test
    public void testDeleteGeoLoc_whenException() throws Exception {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        tfOneGeoLoc.setZip("11122");
        tfOneGeoLoc.setRzg2user("1");
        tfOneGeoLoc.setCrlatitude("11122");
        tfOneGeoLoc.setLongitude("11122");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).deleteGeoLoc(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.deleteGeoLoc(tfOneGeoLoc, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_GEO_LOC_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_GEO_LOC_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetUsers() throws Exception {
        List<String> userData = new ArrayList<>();
        userData.add("1");
        userData.add("2");
        when(tracfoneCarrierMaintenanceAction.getUsers()).thenReturn(userData);
        List<String> response = tracfoneCarrierMaintenanceController.getUsers();
        assertEquals("[1, 2]", response.toString());
    }

    @Test
    public void testGetUsers_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).getUsers();
        try {
            tracfoneCarrierMaintenanceController.getUsers();
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_USER_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_USER_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchGeoLoc() throws Exception {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        tfOneGeoLoc.setZip("1231");

        List<TFOneGeoLoc> tfOneGeoLocs = new ArrayList<>(1);
        TFOneGeoLoc tfGeoLoc = new TFOneGeoLoc();
        tfGeoLoc.setRzg2user("121");
        tfOneGeoLocs.add(tfGeoLoc);

        when(tracfoneCarrierMaintenanceAction.searchGeoLoc(tfOneGeoLoc)).thenReturn(tfOneGeoLocs);
        List<TFOneGeoLoc> response = tracfoneCarrierMaintenanceController.searchGeoLoc(tfOneGeoLoc);
        assertEquals("[TFOneGeoLoc{zip='null', state='null', popcy='null', pop05='null', latitude='null', longitude='null', rlatitude='null', rlongitude='null', srlatitude='null', crlatitude='null', rzg2user='121', insertDate='null', updateDate='null'}]", response.toString());
    }

    @Test
    public void testSearchGeoLoc_whenException() throws Exception {
        TracfoneOneGeoLoc tfOneGeoLoc = new TracfoneOneGeoLoc();
        tfOneGeoLoc.setZip("1231");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchGeoLoc(tfOneGeoLoc);
        try {
            tracfoneCarrierMaintenanceController.searchGeoLoc(tfOneGeoLoc);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_GEO_LOC_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_GEO_LOC_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateGeoLoc() throws Exception {
        TracfoneOneGeoLoc tfGeoLoc = new TracfoneOneGeoLoc();
        tfGeoLoc.setZip("1231");
        tfGeoLoc.setOldZip("1223");
        when(tracfoneCarrierMaintenanceAction.updateGeoLoc(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateGeoLoc(tfGeoLoc, 1000);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals("SAMPLE", response.getMessage());

    }

    @Test
    public void testUpdateGeoLoc_whenException() throws Exception {
        TracfoneOneGeoLoc tfGeoLoc = new TracfoneOneGeoLoc();
        tfGeoLoc.setZip("1231");
        tfGeoLoc.setOldZip("1223");
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateGeoLoc(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateGeoLoc(tfGeoLoc, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_GEO_LOC_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_GEO_LOC_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testBulkUpdateGeoLoc() throws Exception {
        List<TracfoneOneGeoLoc> geoLocs = new ArrayList<>();
        TracfoneOneGeoLoc tfGeoLoc = new TracfoneOneGeoLoc();
        tfGeoLoc.setZip("1231");
        tfGeoLoc.setOldZip("1223");
        geoLocs.add(tfGeoLoc);

        when(tracfoneCarrierMaintenanceAction.bulkUpdateGeoLoc(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.bulkUpdateGeoLoc(geoLocs, 1000);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals("SAMPLE", response.getMessage());
    }

    @Test
    public void testBulkUpdateGeoLoc_whenException() throws Exception {
        List<TracfoneOneGeoLoc> geoLocs = new ArrayList<>();
        TracfoneOneGeoLoc tfGeoLoc = new TracfoneOneGeoLoc();
        tfGeoLoc.setZip("1231");
        tfGeoLoc.setOldZip("1223");
        geoLocs.add(tfGeoLoc);

        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).bulkUpdateGeoLoc(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.bulkUpdateGeoLoc(geoLocs, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_GEO_LOC_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_GEO_LOC_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearch2Carrierzones() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");

        List<TFOneCarrierZones> tfOneCarrierzones = new ArrayList<>();
        TFOneCarrierZones tfOneCarrierzone = new TFOneCarrierZones();
        tfOneCarrierzone.setZipCode("4");
        tfOneCarrierzone.setState("1");
        tfOneCarrierzone.setZone("2");
        tfOneCarrierzone.setCounty("1");
        tfOneCarrierzone.setCarrierName("1");
        tfOneCarrierzones.add(tfOneCarrierzone);
        when(tracfoneCarrierMaintenanceAction.searchCarrierzones(any())).thenReturn(tfOneCarrierzones);
        List<TFOneCarrierZones> response = tracfoneCarrierMaintenanceController.searchCarrierzones(tracfoneOneCarrierZones);
        assertEquals("[TFOneCarrierZones{zipCode=4, state=1, county=1, zone=2, rateCente=null, marketId=null, marketArea=null, city=null, btaMarketNumber=null, btaMarketName=null, carrierId=null, carrierName=1, zipStatus=null, simProfile=null, simProfile2=null, planType=null}]", response.toString());
    }

    @Test
    public void testSearchCarrierzones_whenException() throws Exception {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchCarrierzones(any());
        try {
            tracfoneCarrierMaintenanceController.searchCarrierzones(tracfoneOneCarrierZones);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_CARRIERZONES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_CARRIERZONES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierzones() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        when(tracfoneCarrierMaintenanceAction.insertCarrierzones(any(), anyInt(), any())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertCarrierzones(tracfoneOneCarrierZones, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testInsertCarrierzones_whenException() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertCarrierzones(any(), anyInt(),any());
        try {
            tracfoneCarrierMaintenanceController.insertCarrierzones(tracfoneOneCarrierZones, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_CARRIERZONES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_CARRIERZONES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierzones() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        when(tracfoneCarrierMaintenanceAction.deleteCarrierzones(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.deleteCarrierzones(tracfoneOneCarrierZones, 1000);
        assertEquals("Success", TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testDeleteCarrierzones_whenException() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).deleteCarrierzones(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.deleteCarrierzones(tracfoneOneCarrierZones, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_CARRIERZONES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_CARRIERZONES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierzones() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        tracfoneOneCarrierZones.setDbEnv(DBENV);
        tracfoneOneCarrierZones.setZipCode("4");
        tracfoneOneCarrierZones.setState("1");
        tracfoneOneCarrierZones.setZone("2");
        tracfoneOneCarrierZones.setCounty("1");
        tracfoneOneCarrierZones.setCarrierName("1");
        when(tracfoneCarrierMaintenanceAction.updateCarrierzones(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateCarrierzones(tracfoneOneCarrierZones, 1000);
        assertEquals("Success", TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testUpdateCarrierzones_whenException() throws TracfoneOneException {
        TracfoneOneCarrierZones tracfoneOneCarrierZones = new TracfoneOneCarrierZones();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateCarrierzones(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateCarrierzones(tracfoneOneCarrierZones, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CARRIERZONES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CARRIERZONES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierpref() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");

        List<TFOneCarrierPref> tfOneCarrierPrefs = new ArrayList<>();
        TFOneCarrierPref tfOneCarrierPref = new TFOneCarrierPref();
        tfOneCarrierPref.setState("SD");
        tfOneCarrierPref.setCounty("TEST");
        tfOneCarrierPref.setCarrierId("1235");
        tfOneCarrierPref.setCarrierName("test");
        tfOneCarrierPref.setCarrierRank("test");
        tfOneCarrierPref.setNewRank("123");
        tfOneCarrierPrefs.add(tfOneCarrierPref);
        when(tracfoneCarrierMaintenanceAction.searchCarrierpref(any())).thenReturn(tfOneCarrierPrefs);
        List<TFOneCarrierPref> response = tracfoneCarrierMaintenanceController.searchCarrierpref(tracfoneOneCarrierPref);
        assertEquals("[TFOneCarrierPref{state=SD, county=TEST, carrierId=1235, carrierName=test, carrierRank=test, newRank=123}]", response.toString());
    }

    @Test
    public void testSearchCarrierpref_whenException() throws Exception {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).searchCarrierpref(any());
        try {
            tracfoneCarrierMaintenanceController.searchCarrierpref(tracfoneOneCarrierPref);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_CARRIERPREF_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_CARRIERPREF_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertCarrierpref() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        when(tracfoneCarrierMaintenanceAction.insertCarrierpref(any(), anyInt(), any())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.insertCarrierpref(tracfoneOneCarrierPref, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testInsertCarrierpref_whenException() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).insertCarrierpref(any(), anyInt(),any());
        try {
            tracfoneCarrierMaintenanceController.insertCarrierpref(tracfoneOneCarrierPref, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_CARRIERPREF_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_CARRIERPREF_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteCarrierpref() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        when(tracfoneCarrierMaintenanceAction.deleteCarrierpref(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.deleteCarrierpref(tracfoneOneCarrierPref, 1000);
        assertEquals("Success", TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testDeleteCarrierpref_whenException() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).deleteCarrierpref(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.deleteCarrierpref(tracfoneOneCarrierPref, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_CARRIERPREF_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_CARRIERPREF_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierpref() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        tracfoneOneCarrierPref.setDbEnv(DBENV);
        tracfoneOneCarrierPref.setState("SD");
        tracfoneOneCarrierPref.setCounty("TEST");
        tracfoneOneCarrierPref.setCarrierId("1235");
        tracfoneOneCarrierPref.setCarrierName("test");
        tracfoneOneCarrierPref.setCarrierRank("test");
        tracfoneOneCarrierPref.setNewRank("123");
        when(tracfoneCarrierMaintenanceAction.updateCarrierpref(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneCarrierMaintenanceController.updateCarrierpref(tracfoneOneCarrierPref, 1000);
        assertEquals("Success", TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "SAMPLE");
    }

    @Test
    public void testUpdateCarrierpref_whenException() throws TracfoneOneException {
        TracfoneOneCarrierPref tracfoneOneCarrierPref = new TracfoneOneCarrierPref();
        doThrow(tracfoneOneException).when(tracfoneCarrierMaintenanceAction).updateCarrierpref(any(), anyInt());
        try {
            tracfoneCarrierMaintenanceController.updateCarrierpref(tracfoneOneCarrierPref, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CARRIERPREF_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CARRIERPREF_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

}