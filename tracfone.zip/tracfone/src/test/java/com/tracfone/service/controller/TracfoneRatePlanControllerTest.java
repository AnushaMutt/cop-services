package com.tracfone.service.controller;


import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneApn;
import com.tracfone.service.model.request.TracfoneOneCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucketTier;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildTier;
import com.tracfone.service.model.request.TracfoneOneRatePlan;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionLink;
import com.tracfone.service.model.request.TracfoneOneSearchCarrierFeatureModel;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.response.TFOneApn;
import com.tracfone.service.model.response.TFOneBusinessOrganization;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOneRatePlan;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_APN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_APN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_RATE_PLAN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_ADD_RATE_PLAN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_APN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_APN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_RATE_PLAN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DELETE_RATE_PLAN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_APN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_APN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_RATE_PLAN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_DUPLICATE_RATE_PLAN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ALL_BUS_ORGS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ALL_BUS_ORGS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ALL_CARRIERS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ALL_CARRIERS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ALL_PARENT_NAMES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ALL_PARENT_NAMES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CF_LINKS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CF_LINKS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_MASTER_RATE_PLANS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_MASTER_RATE_PLANS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_RATEPLAN_APNS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_RATEPLAN_APNS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_SERVICE_PLAN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_SERVICE_PLAN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_RP_ASSOCIATION_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_INSERT_RP_ASSOCIATION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CARRIER_FEATURES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CARRIER_FEATURES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_UNLINKED_RP_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_UNLINKED_RP_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_APN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_APN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CF_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_CF_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_RATE_PLAN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_UPDATE_RATE_PLAN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_VIEW_RATE_PLAN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_VIEW_RATE_PLAN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CF_RATE_PLANS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CF_RATE_PLANS_ERROR;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class TracfoneRatePlanControllerTest {
    private static final String RATE_PLAN_NAME = "RATE_PLAN_NAME";
    private static final String DBENV = "DBENV";
    private static final String RATE_PLAN_ID = "1000";
    private static final String ACTIVE_FLAG = "Y";
    private static final String SAMPLE = "SAMPLE";
    @Mock
    private TracfoneRatePlanLocalAction tracfoneRatePlanLocalAction;
    @Mock
    private TracfoneBucketLocalAction tracfoneBucketLocalAction;
    @InjectMocks
    private TracfoneRatePlanController tracfoneRatePlanController;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private TFOneGeneralResponse tFOneGeneralResponseForCF;
    private static final String MESSAGE = "SAMPLE";

    private TracfoneOneException tracfoneOneException;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", MESSAGE);
        List<String> ids = new ArrayList<>();
        ids.add("1000");
        ids.add("1001");
        tFOneGeneralResponseForCF = new TFOneGeneralResponse("200", ids.toString());
        tracfoneOneException = new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
    }

    @Test
    public void testInsertRatePlan() throws Exception {
        TracfoneOneRatePlan tracfoneOneRatePlan = new TracfoneOneRatePlan();
        tracfoneOneRatePlan.setRatePlanId(RATE_PLAN_ID);
        tracfoneOneRatePlan.setRatePlanName(RATE_PLAN_NAME);
        tracfoneOneRatePlan.setDbEnv(DBENV);
        when(tracfoneRatePlanLocalAction.viewRatePlan(any(), anyBoolean())).thenReturn(null);
        when(tracfoneRatePlanLocalAction.insertRatePlan(any(TracfoneOneRatePlan.class), anyInt())).thenReturn(tFOneGeneralResponseForCF);
        TFOneGeneralResponse response = tracfoneRatePlanController.insertRatePlan(tracfoneOneRatePlan, 100);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "[1000, 1001]");
    }

    @Test
    public void testInsertRatePlan_whenException() throws Exception {
        TracfoneOneRatePlan tracfoneOneRatePlan = new TracfoneOneRatePlan();
        tracfoneOneRatePlan.setRatePlanId(RATE_PLAN_ID);
        tracfoneOneRatePlan.setRatePlanName(RATE_PLAN_NAME);
        tracfoneOneRatePlan.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).insertRatePlan(any(TracfoneOneRatePlan.class), anyInt());
        try {
            tracfoneRatePlanController.insertRatePlan(tracfoneOneRatePlan, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_RATE_PLAN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_RATE_PLAN_ERROR_MESSAGE, e.getErrorMessage());
        }

        // duplicate
        TFOneRatePlan duplicate = new TFOneRatePlan();
        duplicate.setRatePlanName(RATE_PLAN_NAME);
        when(tracfoneRatePlanLocalAction.viewRatePlan(any(), anyBoolean())).thenReturn(duplicate);
        try {
            tracfoneRatePlanController.insertRatePlan(tracfoneOneRatePlan, 100);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DUPLICATE_RATE_PLAN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DUPLICATE_RATE_PLAN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testViewRatePlan() throws Exception {
        TracfoneOneRatePlan tracfoneOneRatePlan = new TracfoneOneRatePlan();
        tracfoneOneRatePlan.setDbEnv(DBENV);
        tracfoneOneRatePlan.setRatePlanName(RATE_PLAN_NAME);
        tracfoneOneRatePlan.setRatePlanId(RATE_PLAN_ID);
        TFOneRatePlan tfOneRatePlan = new TFOneRatePlan();
        tfOneRatePlan.setRatePlanName(RATE_PLAN_NAME);
        tfOneRatePlan.setEspidNum(SAMPLE);
        when(tracfoneRatePlanLocalAction.viewRatePlan(any(TracfoneOneRatePlan.class), anyBoolean())).thenReturn(tfOneRatePlan);
        TFOneRatePlan response = tracfoneRatePlanController.viewRatePlan(tracfoneOneRatePlan);
        assertEquals(response.getRatePlanName(), tfOneRatePlan.getRatePlanName());
        assertEquals(response.getEspidNum(), tfOneRatePlan.getEspidNum());
    }

    @Test
    public void testViewRatePlan_whenException() throws Exception {
        TracfoneOneRatePlan tracfoneOneRatePlan = new TracfoneOneRatePlan();
        tracfoneOneRatePlan.setRatePlanId(RATE_PLAN_ID);
        tracfoneOneRatePlan.setRatePlanName(RATE_PLAN_NAME);
        tracfoneOneRatePlan.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).viewRatePlan(any(TracfoneOneRatePlan.class), anyBoolean());
        try {
            tracfoneRatePlanController.viewRatePlan(tracfoneOneRatePlan);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_VIEW_RATE_PLAN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_VIEW_RATE_PLAN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateRatePlan() throws Exception {
        TracfoneOneRatePlan tracfoneOneRatePlan = new TracfoneOneRatePlan();
        tracfoneOneRatePlan.setDbEnv(DBENV);
        tracfoneOneRatePlan.setRatePlanName(RATE_PLAN_NAME);
        tracfoneOneRatePlan.setRatePlanId(RATE_PLAN_ID);
        when(tracfoneRatePlanLocalAction.updateRatePlan(any(TracfoneOneRatePlan.class), anyInt())).thenReturn(tFOneGeneralResponseForCF);
        TFOneGeneralResponse response = tracfoneRatePlanController.updateRatePlan(tracfoneOneRatePlan, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "[1000, 1001]");
    }

    @Test
    public void testUpdateRatePlan_whenException() throws Exception {
        TracfoneOneRatePlan tracfoneOneRatePlan = new TracfoneOneRatePlan();
        tracfoneOneRatePlan.setRatePlanId(RATE_PLAN_ID);
        tracfoneOneRatePlan.setRatePlanName(RATE_PLAN_NAME);
        tracfoneOneRatePlan.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).updateRatePlan(any(TracfoneOneRatePlan.class), anyInt());
        try {
            tracfoneRatePlanController.updateRatePlan(tracfoneOneRatePlan, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_RATE_PLAN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_RATE_PLAN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteRatePlan() throws Exception {
        TracfoneOneRatePlan tracfoneOneRatePlan = new TracfoneOneRatePlan();
        tracfoneOneRatePlan.setDbEnv(DBENV);
        tracfoneOneRatePlan.setRatePlanName(RATE_PLAN_NAME);
        tracfoneOneRatePlan.setRatePlanId(RATE_PLAN_ID);
        when(tracfoneRatePlanLocalAction.deleteRatePlan(anyString(), anyList(), anyInt())).thenReturn(tFOneGeneralResponseForCF);
        TFOneGeneralResponse response = tracfoneRatePlanController.deleteRatePlan(tracfoneOneRatePlan, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "[1000, 1001]");
    }

    @Test
    public void testDeleteRatePlan_whenException() throws Exception {
        TracfoneOneRatePlan tracfoneOneRatePlan = new TracfoneOneRatePlan();
        tracfoneOneRatePlan.setRatePlanId(RATE_PLAN_ID);
        tracfoneOneRatePlan.setRatePlanName(RATE_PLAN_NAME);
        tracfoneOneRatePlan.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).deleteRatePlan(anyString(), anyList(), anyInt());
        try {
            tracfoneRatePlanController.deleteRatePlan(tracfoneOneRatePlan, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_RATE_PLAN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_RATE_PLAN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetServicePlansForCarrier() throws Exception {
        List<TFOneCarrierServicePlan> tfOneCarrierServicePlanList = new ArrayList<>();
        TFOneCarrierServicePlan tfOneCarrierServicePlan = new TFOneCarrierServicePlan();
        tfOneCarrierServicePlan.setCarrierName("CLARO");
        tfOneCarrierServicePlan.setDescription(SAMPLE);
        tfOneCarrierServicePlanList.add(tfOneCarrierServicePlan);
        when(tracfoneRatePlanLocalAction.getServicePlansForCarrier(anyString(), anyString())).thenReturn(tfOneCarrierServicePlanList);
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        searchPlanModel.setCarrierName("CLARO");
        searchPlanModel.setDbEnv(DBENV);
        List<TFOneCarrierServicePlan> response = tracfoneRatePlanController.getServicePlansForCarrier(searchPlanModel);
        assertEquals(response.get(0).getCarrierName(), tfOneCarrierServicePlan.getCarrierName());
        assertEquals(response.get(0).getDescription(), tfOneCarrierServicePlan.getDescription());
    }

    @Test
    public void testGetServicePlansForCarrier_whenException() throws Exception {
        TracfoneOneSearchPlanModel searchPlanModel = new TracfoneOneSearchPlanModel();
        searchPlanModel.setCarrierName("CLARO");
        searchPlanModel.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).getServicePlansForCarrier(anyString(), anyString());
        try {
            tracfoneRatePlanController.getServicePlansForCarrier(searchPlanModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_SERVICE_PLAN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_SERVICE_PLAN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllBusinessOrgs() throws Exception {
        List<TFOneBusinessOrganization> tfOneBusinessOrganizationArrayList = new ArrayList<>();
        TFOneBusinessOrganization tfOneBusinessOrganization = new TFOneBusinessOrganization();
        tfOneBusinessOrganization.setOrgId(SAMPLE);
        tfOneBusinessOrganizationArrayList.add(tfOneBusinessOrganization);
        TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel = new TracfoneOneSearchPlanModel();
        tracfoneOneSearchPlanModel.setDbEnv(DBENV);
        tracfoneOneSearchPlanModel.setRatePlanName(RATE_PLAN_NAME);
        when(tracfoneRatePlanLocalAction.getAllBusinessOrgs(anyString())).thenReturn(tfOneBusinessOrganizationArrayList);
        List<TFOneBusinessOrganization> response = tracfoneRatePlanController.getAllBusinessOrgs(DBENV);
        assertEquals(response.get(0).getOrgId(), tfOneBusinessOrganization.getOrgId());
    }

    @Test
    public void testGetAllBusinessOrgs_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).getAllBusinessOrgs(DBENV);
        try {
            tracfoneRatePlanController.getAllBusinessOrgs(DBENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_BUS_ORGS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_BUS_ORGS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetMasterRatePlans() throws Exception {
        List<TFOneRatePlan> tfOneRatePlanList = new ArrayList<>();
        TFOneRatePlan tfOneRatePlan = new TFOneRatePlan();
        tfOneRatePlan.setRatePlanName(RATE_PLAN_NAME);
        tfOneRatePlan.setEspidNum(SAMPLE);
        tfOneRatePlanList.add(tfOneRatePlan);
        when(tracfoneRatePlanLocalAction.getMasterRatePlans(anyString())).thenReturn(tfOneRatePlanList);
        List<TFOneRatePlan> response = tracfoneRatePlanController.getMasterRatePlans(DBENV);
        assertEquals(response.get(0).getRatePlanName(), tfOneRatePlan.getRatePlanName());
        assertEquals(response.get(0).getEspidNum(), tfOneRatePlan.getEspidNum());
    }

    @Test
    public void testGetMasterRatePlans_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).getMasterRatePlans(anyString());
        try {
            tracfoneRatePlanController.getMasterRatePlans(DBENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_MASTER_RATE_PLANS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_MASTER_RATE_PLANS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateCarrierFeature() throws Exception {
        TracfoneOneCarrierFeature tracfoneOneCarrierFeature = new TracfoneOneCarrierFeature();
        tracfoneOneCarrierFeature.setDbEnv(DBENV);
        tracfoneOneCarrierFeature.setxRatePlan(RATE_PLAN_NAME);
        when(tracfoneRatePlanLocalAction.updateCarrierFeature(any(TracfoneOneCarrierFeature.class), anyInt())).thenReturn(tFOneGeneralResponseForCF);
        TFOneGeneralResponse response = tracfoneRatePlanController.updateCarrierFeature(tracfoneOneCarrierFeature, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "[1000, 1001]");
    }

    @Test
    public void testUpdateCarrierFeature_whenException() throws Exception {
        TracfoneOneCarrierFeature tracfoneOneCarrierFeature = new TracfoneOneCarrierFeature();
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).updateCarrierFeature(any(TracfoneOneCarrierFeature.class), anyInt());
        try {
            tracfoneRatePlanController.updateCarrierFeature(tracfoneOneCarrierFeature, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_CF_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_CF_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllParentNames() throws TracfoneOneException {
        List<TFOneParent> tfOneParents = new ArrayList<>();
        TFOneParent tfOneParent = new TFOneParent();
        tfOneParent.setObjId(SAMPLE);
        tfOneParents.add(tfOneParent);
        when(tracfoneRatePlanLocalAction.getAllParentNames(anyString(), anyString())).thenReturn(tfOneParents);
        List<TFOneParent> response = tracfoneRatePlanController.getAllParentNames(DBENV, "carrierName");
        assertEquals(response.size(), tfOneParents.size());
        assertEquals(response.get(0).getObjId(), tfOneParents.get(0).getObjId());
    }

    @Test
    public void testGetAllParentNames_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).getAllParentNames(anyString(), anyString());
        try {
            tracfoneRatePlanController.getAllParentNames(anyString(), anyString());
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_PARENT_NAMES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_PARENT_NAMES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }


    @Test
    public void testSearchForUnlinkedRatePlans() throws TracfoneOneException {
        List<TFOneRatePlan> tfOneRatePlans = new ArrayList<>();
        TFOneRatePlan tfOneRatePlan = new TFOneRatePlan();
        tfOneRatePlan.setRatePlanName(RATE_PLAN_NAME);
        tfOneRatePlans.add(tfOneRatePlan);
        TracfoneOneRatePlan tracfoneOneRatePlan = new TracfoneOneRatePlan();
        tracfoneOneRatePlan.setDbEnv(DBENV);
        tracfoneOneRatePlan.setRatePlanId(SAMPLE);
        when(tracfoneRatePlanLocalAction.searchRatePlansForUpdate(any(TracfoneOneRatePlan.class))).thenReturn(tfOneRatePlans);
        List<TFOneRatePlan> response = tracfoneRatePlanController.searchRatePlansForUpdate(tracfoneOneRatePlan);
        assertEquals(response.size(), tfOneRatePlans.size());
        assertEquals(response.get(0).getRatePlanName(), tfOneRatePlans.get(0).getRatePlanName());
    }

    @Test
    public void testSearchForUnlinkedRatePlans_whenException() throws Exception {
        TracfoneOneRatePlan tracfoneOneRatePlan = new TracfoneOneRatePlan();
        tracfoneOneRatePlan.setDbEnv(DBENV);
        tracfoneOneRatePlan.setRatePlanId(SAMPLE);
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).searchRatePlansForUpdate(any(TracfoneOneRatePlan.class));
        try {
            tracfoneRatePlanController.searchRatePlansForUpdate(tracfoneOneRatePlan);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_UNLINKED_RP_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_UNLINKED_RP_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllRatePlanApns() throws TracfoneOneException {
        TracfoneOneApn tracfoneOneApn = new TracfoneOneApn();
        List<TFOneApn> ratePlanApns = new ArrayList<>();
        TFOneApn tfOneApn = new TFOneApn();
        tfOneApn.setOrgId(SAMPLE);
        ratePlanApns.add(tfOneApn);
        when(tracfoneRatePlanLocalAction.getAllRatePlanApns(any(TracfoneOneApn.class))).thenReturn(ratePlanApns);
        List<TFOneApn> response = tracfoneRatePlanController.getAllRatePlanApns(tracfoneOneApn);
        assertEquals(response.size(), ratePlanApns.size());
        assertEquals(response.get(0).getOrgId(), ratePlanApns.get(0).getOrgId());
    }

    @Test
    public void testGetAllRatePlanApns_whenException() throws Exception {
        TracfoneOneApn tracfoneOneApn = new TracfoneOneApn();
        tracfoneOneApn.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).getAllRatePlanApns(any(TracfoneOneApn.class));
        try {
            tracfoneRatePlanController.getAllRatePlanApns(tracfoneOneApn);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_RATEPLAN_APNS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_RATEPLAN_APNS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCarrierFeatureLinks() throws TracfoneOneException {
        List<TracfoneOneCarrierFeature> selectedCarrierFeatures = new ArrayList<>();
        TracfoneOneCarrierFeature tracfoneOneCarrierFeature = new TracfoneOneCarrierFeature();
        tracfoneOneCarrierFeature.setObjId(SAMPLE);
        selectedCarrierFeatures.add(tracfoneOneCarrierFeature);
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        TFOneCarrierFeature carrierFeature = new TFOneCarrierFeature();
        carrierFeature.setObjId(SAMPLE);
        carrierFeatures.add(carrierFeature);
        when(tracfoneRatePlanLocalAction.getCarrierFeatureLinks(anyList())).thenReturn(carrierFeatures);
        carrierFeatures = tracfoneRatePlanController.getCarrierFeatureLinks(selectedCarrierFeatures);
        assertEquals(carrierFeatures.get(0).getObjId(), SAMPLE);
    }

    @Test
    public void testGetCarrierFeatureLinks_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).getCarrierFeatureLinks(anyList());
        try {
            tracfoneRatePlanController.getCarrierFeatureLinks(anyList());
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_CF_LINKS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_CF_LINKS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierFeatures() throws Exception {
        TracfoneOneSearchCarrierFeatureModel tracfoneOneSearchCarrierFeatureModel = new TracfoneOneSearchCarrierFeatureModel();
        tracfoneOneSearchCarrierFeatureModel.setCarrierName(SAMPLE);
        tracfoneOneSearchCarrierFeatureModel.setDbEnv(DBENV);
        List<TFOneCarrierFeature> tfOneCarrierFeatures = new ArrayList<>();
        TFOneCarrierFeature tfOneCarrierFeature = new TFOneCarrierFeature();
        tfOneCarrierFeature.setxRatePlan(RATE_PLAN_NAME);
        tfOneCarrierFeature.setxTechnology(SAMPLE);
        tfOneCarrierFeatures.add(tfOneCarrierFeature);
        when(tracfoneRatePlanLocalAction.searchCarrierFeatures(any(TracfoneOneSearchCarrierFeatureModel.class))).thenReturn(tfOneCarrierFeatures);
        List<TFOneCarrierFeature> response = tracfoneRatePlanController.searchCarrierFeatures(tracfoneOneSearchCarrierFeatureModel);
        assertEquals(response.get(0).getxRatePlan(), tfOneCarrierFeature.getxRatePlan());
        assertEquals(response.get(0).getObjId(), tfOneCarrierFeature.getObjId());
    }

    @Test
    public void testSearchCarrierFeatures_whenException() throws Exception {
        TracfoneOneSearchCarrierFeatureModel tracfoneOneSearchCarrierFeatureModel = new TracfoneOneSearchCarrierFeatureModel();
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).searchCarrierFeatures(any(TracfoneOneSearchCarrierFeatureModel.class));
        try {
            tracfoneRatePlanController.searchCarrierFeatures(tracfoneOneSearchCarrierFeatureModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_CARRIER_FEATURES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_CARRIER_FEATURES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetAllCarrierNames() throws Exception {
        List<String> strings = new ArrayList<>();
        strings.add(SAMPLE);
        when(tracfoneRatePlanLocalAction.getAllCarrierNames(anyString())).thenReturn(strings);
        List<String> response = tracfoneRatePlanController.getAllCarrierNames(DBENV);
        assertEquals(response.get(0), strings.get(0));
    }

    @Test
    public void testGetAllCarrierNames_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).getAllCarrierNames(anyString());
        try {
            tracfoneRatePlanController.getAllCarrierNames(DBENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ALL_CARRIERS_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_GET_ALL_CARRIERS_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertApn() throws Exception {
        TracfoneOneApn tracfoneOneApn = new TracfoneOneApn();
        tracfoneOneApn.setRatePlan(RATE_PLAN_NAME);
        tracfoneOneApn.setOrgId(RATE_PLAN_ID);
        when(tracfoneRatePlanLocalAction.isDuplicateApn(any())).thenReturn(false);
        when(tracfoneRatePlanLocalAction.insertApn(any(TracfoneOneApn.class), anyInt())).thenReturn(tFOneGeneralResponseForCF);
        TFOneGeneralResponse response = tracfoneRatePlanController.insertApn(tracfoneOneApn, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "[1000, 1001]");
    }

    @Test
    public void testInsertApn_whenException() throws Exception {
        TracfoneOneApn tracfoneOneApn = new TracfoneOneApn();
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).insertApn(any(TracfoneOneApn.class), anyInt());
        try {
            tracfoneRatePlanController.insertApn(tracfoneOneApn, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_APN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_APN_ERROR_MESSAGE, e.getErrorMessage());
        }

        // duplicate
        when(tracfoneRatePlanLocalAction.isDuplicateApn(any())).thenReturn(true);
        try {
            tracfoneRatePlanController.insertApn(tracfoneOneApn, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DUPLICATE_APN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DUPLICATE_APN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateApn() throws Exception {
        TracfoneOneApn tracfoneOneApn = new TracfoneOneApn();
        tracfoneOneApn.setRatePlan(RATE_PLAN_NAME);
        tracfoneOneApn.setOrgId(RATE_PLAN_ID);
        tracfoneOneApn.setApn(SAMPLE);
        tracfoneOneApn.setOldApn(SAMPLE);
        tracfoneOneApn.setDbEnv(DBENV);
        tracfoneOneApn.setOldOrgId(RATE_PLAN_ID);
        tracfoneOneApn.setRatePlan(SAMPLE);
        tracfoneOneApn.setOldParentName(SAMPLE);
        when(tracfoneRatePlanLocalAction.updateApn(any(TracfoneOneApn.class), anyInt())).thenReturn(tFOneGeneralResponseForCF);
        TFOneGeneralResponse response = tracfoneRatePlanController.updateApn(tracfoneOneApn, 1000);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "[1000, 1001]");
    }

    @Test
    public void testUpdateApn_whenException() throws Exception {
        TracfoneOneApn tracfoneOneApn = new TracfoneOneApn();
        tracfoneOneApn.setOrgId(SAMPLE);
        tracfoneOneApn.setRatePlan(RATE_PLAN_NAME);
        tracfoneOneApn.setApn(SAMPLE);
        tracfoneOneApn.setOldApn(SAMPLE);
        tracfoneOneApn.setDbEnv(DBENV);
        tracfoneOneApn.setOldOrgId(RATE_PLAN_ID);
        tracfoneOneApn.setRatePlan(SAMPLE);
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).updateApn(any(TracfoneOneApn.class), anyInt());
        try {
            tracfoneRatePlanController.updateApn(tracfoneOneApn, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_APN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_APN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteApn() throws TracfoneOneException {
        TracfoneOneApn tfOneApn = new TracfoneOneApn();
        tfOneApn.setDbEnv(DBENV);
        when(tracfoneRatePlanLocalAction.deleteApn(any(TracfoneOneApn.class), anyInt())).thenReturn(tFOneGeneralResponseForCF);
        TFOneGeneralResponse response = tracfoneRatePlanController.deleteApn(tfOneApn, 1);
        assertEquals(response.getStatus(), TFOneGeneralResponse.SUCCESS);
        assertEquals(response.getMessage(), "[1000, 1001]");
    }

    @Test
    public void testDeleteApn_whenException() throws TracfoneOneException {
        TracfoneOneApn tfOneApn = new TracfoneOneApn();
        tfOneApn.setDbEnv(DBENV);
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).deleteApn(any(TracfoneOneApn.class), anyInt());
        try {
            tracfoneRatePlanController.deleteApn(tfOneApn, 1);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_APN_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_APN_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertRatePlanAssociation() throws Exception {
        List<TFOneCarrierProfileBucket> profileBuckets = new ArrayList<>();
        TFOneCarrierProfileBucket tfOneCarrierProfileBucket = new TFOneCarrierProfileBucket();
        tfOneCarrierProfileBucket.setObjid("100");
        tfOneCarrierProfileBucket.setProfileId("100");
        tfOneCarrierProfileBucket.setActiveFlag("Y");
        tfOneCarrierProfileBucket.setAutoRenewFlag("Y");
        profileBuckets.add(tfOneCarrierProfileBucket);
        TFOneGeneralResponse generalResponse = new TFOneGeneralResponse("Success", "10");

        List<TracfoneOneCarrierProfileBucketTier> tracfoneOneCarrierProfileBucketTiers = new ArrayList<>();
        TracfoneOneCarrierProfileBucketTier tracfoneOneCarrierProfileBucketTier = new TracfoneOneCarrierProfileBucketTier();
        tracfoneOneCarrierProfileBucketTier.setObjId("10");
        tracfoneOneCarrierProfileBucketTier.setUsageTierId("10");
        tracfoneOneCarrierProfileBucketTiers.add(tracfoneOneCarrierProfileBucketTier);
        List<TracfoneOneCarrierProfileBucket> tracfoneOneCarrierProfileBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileBucket tracfoneOneCarrierProfileBucket = new TracfoneOneCarrierProfileBucket();
        tracfoneOneCarrierProfileBucket.setObjectId("10");
        tracfoneOneCarrierProfileBucket.setBucketId("10");
        tracfoneOneCarrierProfileBucket.setAutoRenewFlag("Y");
        tracfoneOneCarrierProfileBucket.setActiveFlag("Y");
        tracfoneOneCarrierProfileBucket.setTracfoneOneCarrierProfileBucketTiers(tracfoneOneCarrierProfileBucketTiers);
        tracfoneOneCarrierProfileBuckets.add(tracfoneOneCarrierProfileBucket);

        List<TracfoneOneCarrierProfileChildTier> tracfoneOneCarrierProfileChildTiers = new ArrayList<>();
        TracfoneOneCarrierProfileChildTier tracfoneOneCarrierProfileChildTier = new TracfoneOneCarrierProfileChildTier();
        tracfoneOneCarrierProfileChildTier.setCarrierProfileChildObjId("10");
        tracfoneOneCarrierProfileChildTier.setUsageTierId("10");
        tracfoneOneCarrierProfileChildTiers.add(tracfoneOneCarrierProfileChildTier);
        List<TracfoneOneCarrierProfileChildBucket> tracfoneOneCarrierProfileChildBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileChildBucket tracfoneOneCarrierProfileChildBucket = new TracfoneOneCarrierProfileChildBucket();
        tracfoneOneCarrierProfileChildBucket.setActiveFlag("Y");
        tracfoneOneCarrierProfileChildBucket.setTracfoneOneCarrierProfileChildTiers(tracfoneOneCarrierProfileChildTiers);
        tracfoneOneCarrierProfileChildBuckets.add(tracfoneOneCarrierProfileChildBucket);
        List<TracfoneOneRatePlanExtensionLink> ratePlanExtensionLinks = new ArrayList<>();
        TracfoneOneRatePlanExtensionLink ratePlanExtensionLink = new TracfoneOneRatePlanExtensionLink();
        ratePlanExtensionLink.setObjId("10");
        ratePlanExtensionLink.setCarrierFeatureId("10");
        ratePlanExtensionLink.setRatePlanExtensionId("10");
        ratePlanExtensionLink.setProfileId("10");
        ratePlanExtensionLink.setTracfoneOneCarrierProfileBuckets(tracfoneOneCarrierProfileBuckets);
        ratePlanExtensionLink.setTracfoneOneCarrierProfileChildBuckets(tracfoneOneCarrierProfileChildBuckets);
        ratePlanExtensionLinks.add(ratePlanExtensionLink);

        TracfoneOneCarrierFeature tfOneCarrierFeature = new TracfoneOneCarrierFeature();
        tfOneCarrierFeature.setObjId("10");
        tfOneCarrierFeature.setxTechnology("CDMA");
        tfOneCarrierFeature.setRatePlanExtensionLinks(ratePlanExtensionLinks);
        when(tracfoneRatePlanLocalAction.insertRatePlanAssociation(any(), anyInt())).thenReturn(generalResponse);
        when(tracfoneBucketLocalAction.searchCarrierProfileBuckets(any())).thenReturn(profileBuckets);
        TFOneGeneralResponse response = tracfoneRatePlanController.insertRatePlanAssociation(tfOneCarrierFeature, "CARRIER_NAME", "185", "RATE_PLAN_NAME", 1000);
        assertEquals("Success", response.getStatus());
        assertEquals(response.getMessage(), tfOneCarrierFeature.getObjId());
    }

    @Test
    public void testInsertRatePlanAssociation_whenExcepFtion() throws Exception {
        TracfoneOneCarrierFeature tfOneCarrierFeature = new TracfoneOneCarrierFeature();
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).insertRatePlanAssociation(any(), anyInt());
        try {
            tracfoneRatePlanController.insertRatePlanAssociation(tfOneCarrierFeature, "", "", "", 1);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_INSERT_RP_ASSOCIATION_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_INSERT_RP_ASSOCIATION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchCarrierFeaturesForUpdate() throws Exception {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        TFOneCarrierFeature tfOneCarrierFeature = new TFOneCarrierFeature();
        tfOneCarrierFeature.setObjId("1000");
        tfOneCarrierFeature.setxTechnology("CDMA");
        carrierFeatures.add(tfOneCarrierFeature);

        TracfoneOneCarrierFeature tracfoneOneCarrierFeature = new TracfoneOneCarrierFeature();
        tracfoneOneCarrierFeature.setxTechnology("CDMA");
        TracfoneOneSearchCarrierFeatureModel searchModel = new TracfoneOneSearchCarrierFeatureModel();
        searchModel.setServicePlanId("185");
        searchModel.setDbEnv(DBENV);
        searchModel.setTracfoneOneCarrierFeature(tracfoneOneCarrierFeature);

        when(tracfoneRatePlanLocalAction.searchCarrierFeaturesForUpdate(any(TracfoneOneSearchCarrierFeatureModel.class))).thenReturn(carrierFeatures);
        List<TFOneCarrierFeature> response = tracfoneRatePlanController.searchCarrierFeaturesForUpdate(searchModel);
        assertEquals(response.toString(), carrierFeatures.toString());
    }

    @Test
    public void testSearchCarrierFeaturesForUpdate_whenException() throws Exception {
        TracfoneOneSearchCarrierFeatureModel searchModel = new TracfoneOneSearchCarrierFeatureModel();
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).searchCarrierFeaturesForUpdate(searchModel);
        try {
            tracfoneRatePlanController.searchCarrierFeaturesForUpdate(searchModel);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_CARRIER_FEATURES_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_CARRIER_FEATURES_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetCarrierRatePlans() throws Exception {
        List<TFOneRatePlan> ratePlans = new ArrayList<>();
        TFOneRatePlan tfOneRatePlan = new TFOneRatePlan();
        tfOneRatePlan.setObjId("1000");
        tfOneRatePlan.setRatePlanName("RATE_PLAN_NAME");
        tfOneRatePlan.setTmoNextGenFlag("Y");
        ratePlans.add(tfOneRatePlan);
        when(tracfoneRatePlanLocalAction.getCarrierRatePlans(any(), any())).thenReturn(ratePlans);
        List<TFOneRatePlan> response = tracfoneRatePlanController.getCarrierRatePlans(DBENV, "CARRIER_NAME");
        assertEquals("[TFOneRatePlan{objId=1000, ratePlanName=RATE_PLAN_NAME, privateNetwork=null, espidUpdate=null, espidNum=null, propagateFlagValue=null, allowMformApnRequestFlag=null, calculateDataUnitsFlag=null, thresholdsToTmo=null, hotspotBucketsFlag=null, tmoNextGenFlag=Y, ratePlanProfile=[], carrierFeatures=null}]", response.toString());
    }

    @Test
    public void testGetCarrierRatePlans_whenException() throws Exception {
        doThrow(tracfoneOneException).when(tracfoneRatePlanLocalAction).getCarrierRatePlans(any(), any());
        try {
            tracfoneRatePlanController.getCarrierRatePlans(DBENV, "CARRIER_NAME");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(e.getErrorCode(), TRACFONE_GET_CF_RATE_PLANS_ERROR);
            assertEquals(e.getErrorMessage(), TRACFONE_GET_CF_RATE_PLANS_ERROR_MESSAGE);
        }
    }
}