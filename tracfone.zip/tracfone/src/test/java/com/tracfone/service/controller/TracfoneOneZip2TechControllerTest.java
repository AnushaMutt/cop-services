package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneBPTech;
import com.tracfone.service.model.request.TracfoneOneZip2Tech;
import com.tracfone.service.model.response.TFOneBPTech;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneZip2Tech;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_ADD_ZIP2TECH_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_ADD_ZIP2TECH_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_GET_ZIP2TECH_COLUMN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_SEARCH_ZIP2TECH_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_SEARCH_ZIP2TECH_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_UPDATE_ZIP2TECH_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_UPDATE_ZIP2TECH_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_SEARCH_BPTECH_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_SEARCH_BPTECH_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_GET_BPTECH_COLUMN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_UPDATE_BPTECH_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_UPDATE_BPTECH_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_DELETE_ZIP2TECH_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_DELETE_ZIP2TECH_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_DELETE_BPTECH_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_DELETE_BPTECH_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_ADD_BPTECH_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantZip2Tech.TRACFONE_ADD_BPTECH_ERROR;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneZip2TechControllerTest {

    @InjectMocks
    TracfoneOneZip2TechController tracfoneOneZip2TechController;

    @Mock
    private TracfoneOneZip2TechActionLocal tracfoneOneZip2TechAction;

    private TracfoneOneException tracfoneOneException;
    private TFOneGeneralResponse tFOneGeneralResponse;
    private static final String SAMPLE = "SAMPLE";
    private static final String DBENV = "DBENV";


    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tFOneGeneralResponse = new TFOneGeneralResponse("200", SAMPLE);
        tracfoneOneException = new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
    }

    @Test
    public void testSearchZip2Tech() throws Exception {
        List<TFOneZip2Tech> zip2Teches = new ArrayList<>();
        TFOneZip2Tech zip2Tech = new TFOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setState("STATE");
        zip2Tech.setCounty("COUNTY");
        zip2Tech.setPref1("PREF1");
        zip2Tech.setPref2("PREF2");
        zip2Tech.setService("SERVICE");
        zip2Tech.setLanguage("LANGUAGE");
        zip2Tech.setAction("ACTION");
        zip2Tech.setMarket("MARKET");
        zip2Tech.setZip2("ZIP2");
        zip2Tech.setAid("AID");
        zip2Tech.setVid("VID");
        zip2Tech.setVc("VC");
        zip2Tech.setCom("COM");
        zip2Tech.setLocale("LOCALE");
        zip2Tech.setSiteType("SITETYPE");
        zip2Tech.setGotoPhoneList("GOTOPHONELIST");
        zip2Tech.setTechkey("TECHKEY");
        zip2Tech.setPrefParent("X_PREF_PARENT");
        zip2Teches.add(zip2Tech);

        TracfoneOneZip2Tech tfZip2Tech = new TracfoneOneZip2Tech();
        tfZip2Tech.setZips("12232,23244");
        tfZip2Tech.setDbEnv("DBENV");

        when(tracfoneOneZip2TechAction.searchZip2Tech(any())).thenReturn(zip2Teches);
        List<TFOneZip2Tech> response = tracfoneOneZip2TechController.searchZip2Tech(tfZip2Tech);
        assertEquals("[TFOneZip2Tech{dbEnv='null', zips='ZIP', state='STATE', county='COUNTY', pref1='PREF1', pref2='PREF2', service='SERVICE', language='LANGUAGE', action='ACTION', market='MARKET', zip2='ZIP2', aid='AID', vid='VID', vc='VC', sahcid='null', com='COM', locale='LOCALE', siteType='SITETYPE', gotoPhoneList='GOTOPHONELIST', tech='null', techZip='null', techkey='TECHKEY', prefParent='X_PREF_PARENT', paginationSearch=null}]", response.toString());
    }

    @Test
    public void testSearchZip2Tech_whenException() throws Exception {
        List<TFOneZip2Tech> zip2Teches = new ArrayList<>();
        TFOneZip2Tech zip2Tech = new TFOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setState("STATE");
        zip2Teches.add(zip2Tech);

        TracfoneOneZip2Tech tfZip2Tech = new TracfoneOneZip2Tech();
        tfZip2Tech.setZips("12232,23244");
        tfZip2Tech.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechAction).searchZip2Tech(any());
        try {
            tracfoneOneZip2TechController.searchZip2Tech(tfZip2Tech);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_ZIP2TECH_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_ZIP2TECH_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetZip2TechColumnValues() throws Exception {
        List<String> columnValues = new ArrayList<>();
        columnValues.add("DUMMY_DATA1");
        columnValues.add("DUMMY_DATA2");

        TracfoneOneZip2Tech tfZip2Tech = new TracfoneOneZip2Tech();
        tfZip2Tech.setDbEnv("DBENV");

        when(tracfoneOneZip2TechAction.getZip2TechColumnValues(anyString(), anyString())).thenReturn(columnValues);
        List<String> response = tracfoneOneZip2TechController.getZip2TechColumnValues("TECHKEY", DBENV);
        assertEquals("[DUMMY_DATA1, DUMMY_DATA2]", response.toString());
    }

    @Test
    public void testGetZip2TechColumnValues_whenException() throws Exception {
        List<String> columnValues = new ArrayList<>();
        columnValues.add("DUMMY_DATA1");
        columnValues.add("DUMMY_DATA2");

        TracfoneOneZip2Tech tfZip2Tech = new TracfoneOneZip2Tech();
        tfZip2Tech.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechAction).getZip2TechColumnValues(anyString(), anyString());
        try {
            tracfoneOneZip2TechController.getZip2TechColumnValues("STATE", DBENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_ZIP2TECH_COLUMN_ERROR, e.getErrorCode());
            assertEquals("Unable to get state", e.getErrorMessage());
        }
    }

    @Test
    public void testInsertZip2Techs() throws Exception {
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setState("STATE");
        zip2Tech.setCounty("COUNTY");
        zip2Tech.setPref1("PREF1");
        zip2Tech.setPref2("PREF2");
        zip2Tech.setService("SERVICE");
        zip2Tech.setLanguage("LANGUAGE");
        zip2Tech.setAction("ACTION");
        zip2Tech.setMarket("MARKET");
        zip2Tech.setZip2("ZIP2");
        zip2Tech.setAid("AID");
        zip2Tech.setVid("VID");
        zip2Tech.setVc("VC");
        zip2Tech.setCom("COM");
        zip2Tech.setLocale("LOCALE");
        zip2Tech.setSiteType("SITETYPE");
        zip2Tech.setGotoPhoneList("GOTOPHONELIST");
        zip2Tech.setTechkey("TECHKEY");
        zip2Tech.setPrefParent("X_PREF_PARENT");
        when(tracfoneOneZip2TechAction.insertZip2Tech(any(), anyInt(), any())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneOneZip2TechController.insertZip2Tech(zip2Tech, 100);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals(SAMPLE, response.getMessage());
    }

    @Test
    public void testInsertZip2Techs_whenException() throws Exception {
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setDbEnv("DBENV");

        doThrow(tracfoneOneException).when(tracfoneOneZip2TechAction).insertZip2Tech(any(), anyInt(), any());
        try {
            tracfoneOneZip2TechController.insertZip2Tech(zip2Tech, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_ZIP2TECH_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_ZIP2TECH_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateZip2Techs() throws Exception {
        List<TracfoneOneZip2Tech> tfZip2Techs = new ArrayList<>();
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setState("STATE");
        zip2Tech.setService("SERVICE");
        zip2Tech.setLanguage("LANGUAGE");
        zip2Tech.setTechkey("TECHKEY");
        zip2Tech.setOldTechKey("OLD_TECHKEY");
        zip2Tech.setOldPrefParent("OLD_PREF_PARENT");
        zip2Tech.setOldService("OLD_SERVICE");
        zip2Tech.setPrefParent("X_PREF_PARENT");
        tfZip2Techs.add(zip2Tech);
        when(tracfoneOneZip2TechAction.updateZip2Techs(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneOneZip2TechController.updateZip2Techs(tfZip2Techs, 100);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals(SAMPLE, response.getMessage());
    }

    @Test
    public void testUpdateZip2Techs_whenException() throws Exception {
        List<TracfoneOneZip2Tech> tfZip2Techs = new ArrayList<>();
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setDbEnv("DBENV");

        tfZip2Techs.add(zip2Tech);
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechAction).updateZip2Techs(any(), anyInt());
        try {
            tracfoneOneZip2TechController.updateZip2Techs(tfZip2Techs, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_ZIP2TECH_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_ZIP2TECH_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchBPTech() throws Exception {
        List<TFOneBPTech> bpTechs = new ArrayList<>();
        TFOneBPTech bpTech = new TFOneBPTech();
        bpTech.setProductKey("PRODUCT_KEY");
        bpTech.setTechkey("TECHKEY");
        bpTech.setBpCode("BPCODE");
        bpTech.setService("SERVICE");
        bpTechs.add(bpTech);

        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setBpCode("BPCODE");
        tfBPTech.setService("SERVICE");
        tfBPTech.setDbEnv("DBENV");

        when(tracfoneOneZip2TechAction.searchBPTech(any())).thenReturn(bpTechs);
        List<TFOneBPTech> response = tracfoneOneZip2TechController.searchBPTech(tfBPTech);
        assertEquals("[TFOneBPTech{techkey='TECHKEY', service='SERVICE', bpCode='BPCODE', productKey='PRODUCT_KEY'}]", response.toString());
    }

    @Test
    public void testSearchBPTech_whenException() throws Exception {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechAction).searchBPTech(any());
        try {
            tracfoneOneZip2TechController.searchBPTech(tfBPTech);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_SEARCH_BPTECH_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_SEARCH_BPTECH_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetBPTechColumn() throws Exception {
        List<String> columnValues = new ArrayList<>();
        columnValues.add("DUMMY_DATA1");
        columnValues.add("DUMMY_DATA2");

        TracfoneOneZip2Tech tfZip2Tech = new TracfoneOneZip2Tech();
        tfZip2Tech.setDbEnv("DBENV");

        when(tracfoneOneZip2TechAction.getBPTechColumn(anyString(), anyString())).thenReturn(columnValues);
        List<String> response = tracfoneOneZip2TechController.getBPTechColumn("COLUMN", DBENV);
        assertEquals("[DUMMY_DATA1, DUMMY_DATA2]", response.toString());
    }

    @Test
    public void testGetBPTechColumn_whenException() throws Exception {
        List<String> columnValues = new ArrayList<>();
        columnValues.add("DUMMY_DATA1");
        columnValues.add("DUMMY_DATA2");

        TracfoneOneZip2Tech tfZip2Tech = new TracfoneOneZip2Tech();
        tfZip2Tech.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechAction).getBPTechColumn(anyString(), anyString());
        try {
            tracfoneOneZip2TechController.getBPTechColumn("COLUMN", DBENV);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_GET_BPTECH_COLUMN_ERROR, e.getErrorCode());
            assertEquals("Unable to get column", e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateBPTechs() throws Exception {
        List<TracfoneOneBPTech> tfBPTechs = new ArrayList<>();
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setBpCode("BPCODE");
        tfBPTech.setService("SERVICE");
        tfBPTech.setDbEnv("DBENV");
        tfBPTechs.add(tfBPTech);
        when(tracfoneOneZip2TechAction.updateBPTechs(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneOneZip2TechController.updateBPTechs(tfBPTechs, 100);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals(SAMPLE, response.getMessage());
    }

    @Test
    public void testUpdateBPTechs_whenException() throws Exception {
        List<TracfoneOneBPTech> tfBPTechs = new ArrayList<>();
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setBpCode("BPCODE");
        tfBPTech.setService("SERVICE");
        tfBPTech.setDbEnv("DBENV");
        tfBPTechs.add(tfBPTech);
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechAction).updateBPTechs(any(), anyInt());
        try {
            tracfoneOneZip2TechController.updateBPTechs(tfBPTechs, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_UPDATE_BPTECH_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_UPDATE_BPTECH_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteZip2Techs() throws Exception {
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setService("SERVICE");
        zip2Tech.setLanguage("LANGUAGE");
        zip2Tech.setTechkey("TECHKEY");
        when(tracfoneOneZip2TechAction.deleteZip2Techs(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneOneZip2TechController.deleteZip2Techs(zip2Tech, 100);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals(SAMPLE, response.getMessage());
    }

    @Test
    public void testDeleteZip2Techs_whenException() throws Exception {
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setDbEnv("DBENV");
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechAction).deleteZip2Techs(any(), anyInt());
        try {
            tracfoneOneZip2TechController.deleteZip2Techs(zip2Tech, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_ZIP2TECH_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_ZIP2TECH_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertBpTech() throws Exception {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setDbEnv("DB");
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setBpCode("BP_CODE");
        tfBPTech.setService("SERVICE");
        when(tracfoneOneZip2TechAction.insertBpTech(any(), anyInt(), any())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneOneZip2TechController.insertBpTech(tfBPTech, 100);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals(SAMPLE, response.getMessage());
    }

    @Test
    public void testInsertBpTech_whenException() throws Exception {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setDbEnv("DB");
        tfBPTech.setProductKey("PRODUCT_KEY");

        doThrow(tracfoneOneException).when(tracfoneOneZip2TechAction).insertBpTech(any(), anyInt(), any());
        try {
            tracfoneOneZip2TechController.insertBpTech(tfBPTech, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_ADD_BPTECH_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_ADD_BPTECH_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteBpTech() throws Exception {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setDbEnv("DB");
        tfBPTech.setBpCode("BP_CODE");
        tfBPTech.setService("SERVICE");
        when(tracfoneOneZip2TechAction.deleteBpTech(any(), anyInt())).thenReturn(tFOneGeneralResponse);
        TFOneGeneralResponse response = tracfoneOneZip2TechController.deleteBpTech(tfBPTech, 100);
        assertEquals(TFOneGeneralResponse.SUCCESS, response.getStatus());
        assertEquals(SAMPLE, response.getMessage());
    }

    @Test
    public void testDeleteBpTech_whenException() throws Exception {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setDbEnv("DB");
        tfBPTech.setService("SERVICE");
        doThrow(tracfoneOneException).when(tracfoneOneZip2TechAction).deleteBpTech(any(), anyInt());
        try {
            tracfoneOneZip2TechController.deleteBpTech(tfBPTech, 1000);
            fail();
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DELETE_BPTECH_ERROR, e.getErrorCode());
            assertEquals(TRACFONE_DELETE_BPTECH_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

}