package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneBPTech;
import com.tracfone.service.model.request.TracfoneOneZip2Tech;
import com.tracfone.service.model.request.TracfoneonePaginationSearch;
import com.tracfone.service.model.response.TFOneBPTech;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneZip2Tech;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneZip2TechActionTest {
    private static final String DBENV = "DBENV";
    @InjectMocks
    TracfoneOneZip2TechAction tracfoneOneZip2TechAction;
    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private ResultSet resultSet;
    @Mock
    private TFOneGeneralResponse tfOneGeneralResponse;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(resultSet);
    }

    @Test
    public void searchZip2Tech() throws TracfoneOneException, SQLException {
        TracfoneonePaginationSearch paginationSearch = new TracfoneonePaginationSearch();
        paginationSearch.setEndIndex(200);
        paginationSearch.setStartIndex(100);
        paginationSearch.setTotal(1000);
        TracfoneOneZip2Tech tfZip2Tech = new TracfoneOneZip2Tech();
        tfZip2Tech.setZips("12232,23244");
        tfZip2Tech.setDbEnv("DBENV");
        tfZip2Tech.setService("SERVICE");
        tfZip2Tech.setCounty("COUNTRY");
        tfZip2Tech.setState("STATE");
        tfZip2Tech.setLanguage("LANGUAGE");
        tfZip2Tech.setPrefParent("PARENT");
        tfZip2Tech.setTechkey("TECHKEY");
        tfZip2Tech.setPaginationSearch(paginationSearch);

        when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
        when(resultSet.getInt(1)).thenReturn(1000);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneZip2Tech> res = tracfoneOneZip2TechAction.searchZip2Tech(tfZip2Tech);
        assertNotNull(res);
        assertEquals(1, res.size());
        assertEquals("[TFOneZip2Tech{dbEnv='null', zips='DUMMY_DATA', state='DUMMY_DATA', county='DUMMY_DATA', pref1='DUMMY_DATA', pref2='DUMMY_DATA', service='DUMMY_DATA', language='DUMMY_DATA', action='DUMMY_DATA', market='DUMMY_DATA', zip2='DUMMY_DATA', aid='DUMMY_DATA', vid='DUMMY_DATA', vc='DUMMY_DATA', sahcid='DUMMY_DATA', com='DUMMY_DATA', locale='DUMMY_DATA', siteType='DUMMY_DATA', gotoPhoneList='DUMMY_DATA', tech='DUMMY_DATA', techZip='DUMMY_DATA', techkey='DUMMY_DATA', prefParent='DUMMY_DATA', paginationSearch=TracfoneonePaginationSearch{startIndex=100, endIndex=200, total=1000}}]", res.toString());
    }

    @Test
    public void testSearchZip2Tech_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneOneZip2TechAction.searchZip2Tech(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneZip2Tech tfZip2Tech = new TracfoneOneZip2Tech();
        tfZip2Tech.setZips("12232,23244");
        tfZip2Tech.setDbEnv("DBENV");
        TracfoneonePaginationSearch paginationSearch = new TracfoneonePaginationSearch();
        paginationSearch.setEndIndex(200);
        paginationSearch.setStartIndex(100);
        paginationSearch.setTotal(1000);
        tfZip2Tech.setPaginationSearch(paginationSearch);
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneOneZip2TechAction.searchZip2Tech(tfZip2Tech);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateZip2Techs() throws TracfoneOneException, SQLException {
        List<TracfoneOneZip2Tech> tfZip2Techs = new ArrayList<>();
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setState("STATE");
        zip2Tech.setDbEnv("DBENV");
        zip2Tech.setService("SERVICE");
        zip2Tech.setLanguage("LANGUAGE");
        zip2Tech.setTechkey("TECHKEY");
        zip2Tech.setOldTechKey("OLD_TECHKEY");
        zip2Tech.setOldPrefParent("OLD_PREF_PARENT");
        zip2Tech.setOldService("OLD_SERVICE");
        zip2Tech.setPrefParent("X_PREF_PARENT");
        tfZip2Techs.add(zip2Tech);
        TFOneGeneralResponse res = tracfoneOneZip2TechAction.updateZip2Techs(tfZip2Techs, 12312);
        assertNotNull(res);
        assertEquals(TFOneGeneralResponse.SUCCESS, res.getStatus());
    }

    @Test
    public void testUpdateZip2Techs_whenException() throws SQLException {
        List<TracfoneOneZip2Tech> tfZip2Techs = new ArrayList<>();
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setOldPrefParent("OLD_PREF_PARENT");
        zip2Tech.setOldService("OLD_SERVICE");
        zip2Tech.setPrefParent("X_PREF_PARENT");
        zip2Tech.setDbEnv("DBENV");
        tfZip2Techs.add(zip2Tech);
        ;
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneOneZip2TechAction.updateZip2Techs(tfZip2Techs, 102);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetZip2TechColumnValues() throws TracfoneOneException, SQLException {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setBpCode("BPCODE");
        tfBPTech.setService("SERVICE");
        tfBPTech.setDbEnv("DBENV");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<String> res = tracfoneOneZip2TechAction.getZip2TechColumnValues("COLUMN", "DBENV");
        assertNotNull(res);
        assertEquals(1, res.size());
        assertEquals("[DUMMY_DATA]", res.toString());
    }

    @Test
    public void testGetZip2TechColumnValues_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneOneZip2TechAction.getZip2TechColumnValues(null, "DBENV");
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneOneZip2TechAction.getZip2TechColumnValues("COLUMN", "DBENV");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchBPTech() throws TracfoneOneException, SQLException {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setBpCode("BPCODE");
        tfBPTech.setService("SERVICE");
        tfBPTech.setDbEnv("DBENV");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<TFOneBPTech> res = tracfoneOneZip2TechAction.searchBPTech(tfBPTech);
        assertNotNull(res);
        assertEquals(1, res.size());
        assertEquals("[TFOneBPTech{techkey='DUMMY_DATA', service='DUMMY_DATA', bpCode='DUMMY_DATA', productKey='DUMMY_DATA'}]", res.toString());
    }

    @Test
    public void testSearchBPTech_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneOneZip2TechAction.searchBPTech(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setBpCode("BPCODE");
        tfBPTech.setService("SERVICE");
        tfBPTech.setDbEnv("DBENV");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneOneZip2TechAction.searchBPTech(tfBPTech);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testGetBPTechColumn() throws TracfoneOneException, SQLException {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setBpCode("BPCODE");
        tfBPTech.setService("SERVICE");
        tfBPTech.setDbEnv("DBENV");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(any())).thenReturn("DUMMY_DATA");
        List<String> res = tracfoneOneZip2TechAction.getBPTechColumn("COLUMN", "DBENV");
        assertNotNull(res);
        assertEquals(1, res.size());
        assertEquals("[DUMMY_DATA]", res.toString());
    }

    @Test
    public void testGetBPTechColumn_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneOneZip2TechAction.getBPTechColumn(null, "DBENV");
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneOneZip2TechAction.getBPTechColumn("COLUMN", "DBENV");
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testUpdateBPTechs() throws TracfoneOneException, SQLException {
        List<TracfoneOneBPTech> tfBPTechs = new ArrayList<>();
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setBpCode("BPCODE");
        tfBPTech.setService("SERVICE");
        tfBPTech.setDbEnv("DBENV");
        tfBPTechs.add(tfBPTech);
        TFOneGeneralResponse res = tracfoneOneZip2TechAction.updateBPTechs(tfBPTechs, 12312);
        assertNotNull(res);
        assertEquals(TFOneGeneralResponse.SUCCESS, res.getStatus());
    }

    @Test
    public void testUpdateBPTechs_whenException() throws SQLException {
        List<TracfoneOneBPTech> tfBPTechs = new ArrayList<>();
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setBpCode("BPCODE");
        tfBPTech.setService("SERVICE");
        tfBPTech.setDbEnv("DBENV");
        tfBPTechs.add(tfBPTech);
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneOneZip2TechAction.updateBPTechs(tfBPTechs, 102);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertZip2Techs() throws TracfoneOneException, SQLException {
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setState("STATE");
        zip2Tech.setDbEnv("DBENV");
        zip2Tech.setService("SERVICE");
        zip2Tech.setLanguage("LANGUAGE");
        zip2Tech.setTechkey("TECHKEY");
        zip2Tech.setPrefParent("X_PREF_PARENT");
        TFOneGeneralResponse res = tracfoneOneZip2TechAction.insertZip2Tech(zip2Tech, 12312, "UNIQUE");
        assertNotNull(res);
        assertEquals(TFOneGeneralResponse.SUCCESS, res.getStatus());
    }

    @Test
    public void testInsertZip2Techs_whenException() throws SQLException {
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setOldPrefParent("OLD_PREF_PARENT");
        zip2Tech.setOldService("OLD_SERVICE");
        zip2Tech.setPrefParent("X_PREF_PARENT");
        zip2Tech.setDbEnv("DBENV");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneOneZip2TechAction.insertZip2Tech(zip2Tech, 102, null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteZip2Techs() throws TracfoneOneException, SQLException {
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setState("STATE");
        zip2Tech.setDbEnv("DBENV");
        zip2Tech.setService("SERVICE");
        zip2Tech.setLanguage("LANGUAGE");
        zip2Tech.setTechkey("TECHKEY");
        zip2Tech.setPrefParent("X_PREF_PARENT");
        TFOneGeneralResponse res = tracfoneOneZip2TechAction.deleteZip2Techs(zip2Tech, 12312);
        assertNotNull(res);
        assertEquals(TFOneGeneralResponse.SUCCESS, res.getStatus());
        assertEquals("ZIP", res.getMessage());
    }

    @Test
    public void testDeleteZip2Techs_whenException() throws SQLException {
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setZips("ZIP");
        zip2Tech.setOldPrefParent("OLD_PREF_PARENT");
        zip2Tech.setOldService("OLD_SERVICE");
        zip2Tech.setPrefParent("X_PREF_PARENT");
        zip2Tech.setDbEnv("DBENV");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneOneZip2TechAction.deleteZip2Techs(zip2Tech, 102);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testInsertBpTech() throws TracfoneOneException, SQLException {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setDbEnv("DB");
        tfBPTech.setProductKey("PRODUCT_KEY");
        tfBPTech.setBpCode("BP_CODE");
        tfBPTech.setService("SERVICE");
        TFOneGeneralResponse res = tracfoneOneZip2TechAction.insertBpTech(tfBPTech, 12312, "UNIQUE");
        assertNotNull(res);
        assertEquals(TFOneGeneralResponse.SUCCESS, res.getStatus());
    }

    @Test
    public void testInsertBpTech_If() throws SQLException {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setDbEnv("DB");
        tfBPTech.setService("SERVICE");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneOneZip2TechAction.insertBpTech(tfBPTech, 102, null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testDeleteBpTech() throws TracfoneOneException, SQLException {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setDbEnv("DB");
        tfBPTech.setBpCode("BP_CODE");
        tfBPTech.setService("SERVICE");
        TFOneGeneralResponse res = tracfoneOneZip2TechAction.deleteBpTech(tfBPTech, 12312);
        assertNotNull(res);
        assertEquals(TFOneGeneralResponse.SUCCESS, res.getStatus());
        assertEquals("TECHKEY", res.getMessage());
    }

    @Test
    public void testDeleteBpTech_whenException() throws SQLException {
        TracfoneOneBPTech tfBPTech = new TracfoneOneBPTech();
        tfBPTech.setTechkey("TECHKEY");
        tfBPTech.setDbEnv("DB");
        tfBPTech.setBpCode("BP_CODE");
        tfBPTech.setService("SERVICE");
        doThrow(SQLException.class).when(stmt).executeUpdate();
        try {
            tracfoneOneZip2TechAction.deleteBpTech(tfBPTech, 102);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

    @Test
    public void testSearchTechKey() throws TracfoneOneException, SQLException {
        TracfoneOneZip2Tech tfZip2Tech = new TracfoneOneZip2Tech();
        tfZip2Tech.setDbEnv("DBENV");
        tfZip2Tech.setTechkey("TECHKEY");

        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString(anyString())).thenReturn("2");
        boolean res = tracfoneOneZip2TechAction.searchTechKey(tfZip2Tech);
        assertNotNull(res);
    }

    @Test
    public void testSearchTechKey_whenException() throws TracfoneOneException, SQLException {
        //When null is passed
        try {
            tracfoneOneZip2TechAction.searchTechKey(null);
            fail("Throws NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }

        // when SQLException occurs
        TracfoneOneZip2Tech tfZip2Tech = new TracfoneOneZip2Tech();
        tfZip2Tech.setTechkey("TECHKEY");
        tfZip2Tech.setDbEnv("DBENV");
        doThrow(SQLException.class).when(resultSet).next();
        try {
            tracfoneOneZip2TechAction.searchTechKey(tfZip2Tech);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e.getErrorMessage());
        }
    }

}