package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneTTransactionNotes;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.enterprise.event.Event;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.tracfone.service.util.TracfoneOneConstantThrottleTransNotes.TRACFONE_POSTGRES_DATASOURCE_CONNECTION_ERROR_CODE_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantThrottleTransNotes.TRACFONE_POSTGRES_DATASOURCE_CONNECTION_ERROR_CODE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * @author Pritesh.Singh
 */
@RunWith(MockitoJUnitRunner.class)
public class TracfoneOneTTransNotesActionTest {

    private static final String DBENV = "DBENV";

    @InjectMocks
    private TracfoneOneTTransNotesAction tracfoneOneTTransNotesAction;

    @Mock
    private DataBaseController dbControllerEJB;
    @Mock
    private Event<TracfoneAudit> tracfoneAuditEvent;
    @Mock
    private DataSource dataSource;
    @Mock
    private Connection con;
    @Mock
    private PreparedStatement stmt;
    @Mock
    private ResultSet resultSet;
    @Mock
    private TFOneGeneralResponse tfOneGeneralResponse;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        when(dbControllerEJB.getDataSource(anyString())).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(con);
        when(con.prepareStatement(anyString())).thenReturn(stmt);
    }

    @Test
    public void testInsertThrottleTransNotes() throws SQLException {
        List<String> objIds = new ArrayList<>(1);
        objIds.add("OBJID1");
        objIds.add("OBJID2");
        objIds.add("OBJID3");
        TracfoneOneTTransactionNotes tfTTransactionNotes = new TracfoneOneTTransactionNotes();
        tfTTransactionNotes.setNotes("NOTE");
        tfTTransactionNotes.setObjIds(objIds);
        tfTTransactionNotes.setDbEnv(DBENV);
        verify(stmt, times(0)).addBatch();
    }

    @Test
    public void testInsertThrottleTransNotes_whenException() throws SQLException {
        List<String> objIds = new ArrayList<>(1);
        objIds.add("1");
        objIds.add("2");
        objIds.add("3");
        TracfoneOneTTransactionNotes tfTTransactionNotes = new TracfoneOneTTransactionNotes();
        tfTTransactionNotes.setNotes("NOTE");
        tfTTransactionNotes.setObjIds(objIds);
        tfTTransactionNotes.setDbEnv(DBENV);

        doThrow(SQLException.class).when(stmt).executeBatch();
        try {
            tracfoneOneTTransNotesAction.insertThrottleTransNotes(tfTTransactionNotes, null);
            fail("Throws TracfoneOneException");
        } catch (TracfoneOneException e) {
            assertEquals(TRACFONE_POSTGRES_DATASOURCE_CONNECTION_ERROR_CODE, e.getErrorCode());
            assertEquals(TRACFONE_POSTGRES_DATASOURCE_CONNECTION_ERROR_CODE_MESSAGE, e.getErrorMessage());
        }
    }
}