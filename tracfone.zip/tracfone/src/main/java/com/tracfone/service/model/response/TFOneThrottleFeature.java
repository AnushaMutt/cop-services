package com.tracfone.service.model.response;

/**
 * @author Thejaswini
 */
public class TFOneThrottleFeature {
    private String objId;
    private String ruleId;
    private String featureFlagName;
    private String featureFlagValue;
    private String featureName;
    private String featureValue;
    private String status;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getRuleId() {
        return ruleId;
    }

    public void setRuleId(String ruleId) {
        this.ruleId = ruleId;
    }

    public String getFeatureFlagName() {
        return featureFlagName;
    }

    public void setFeatureFlagName(String featureFlagName) {
        this.featureFlagName = featureFlagName;
    }

    public String getFeatureFlagValue() {
        return featureFlagValue;
    }

    public void setFeatureFlagValue(String featureFlagValue) {
        this.featureFlagValue = featureFlagValue;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public String getFeatureValue() {
        return featureValue;
    }

    public void setFeatureValue(String featureValue) {
        this.featureValue = featureValue;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "TFOneThrottleFeatures{" +
                "objId='" + objId + '\'' +
                ", ruleId='" + ruleId + '\'' +
                ", featureFlagName='" + featureFlagName + '\'' +
                ", featureFlagValue='" + featureFlagValue + '\'' +
                ", featureName='" + featureName + '\'' +
                ", featureValue='" + featureValue + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
