package com.tracfone.service.util;

public interface TracfoneOneConstantCarrierOutage {

    String SERVICE_TYPE = "SERVICE_TYPE";

    String TRACFONE_SEARCH_CARRIER_OUTAGES_ERROR = "TFE2000";
    String TRACFONE_SEARCH_CARRIER_OUTAGES_ERROR_MESSAGE = "Unable to search for Carrier Outage";

    String TRACFONE_UPDATE_CARRIER_OUTAGE_ERROR = "TFE2001";
    String TRACFONE_UPDATE_CARRIER_OUTAGE_ERROR_MESSAGE = "Unable to update Carrier Outage";

    String TRACFONE_INSERT_CARRIER_OUTAGE_ERROR = "TFE2002";
    String TRACFONE_INSERT_CARRIER_OUTAGE_ERROR_MESSAGE = "Unable to insert Carrier Outage";

    String TRACFONE_BULK_UPDATE_ERROR = "TFE2003";
    String TRACFONE_BULK_UPDATE_ERROR_MESSAGE = "Unable to bulk edit Carrier Outages";

    String TRACFONE_GET_ALL_SERVICE_TYPES_ERROR = "TFE2003";
    String TRACFONE_GET_ALL_SERVICE_TYPES_ERROR_MESSAGE = "Unable to get all Service Types";

    String TRACFONE_INSERT_SERVICE_TYPES_ERROR = "TFE2004";
    String TRACFONE_INSERT_SERVICE_TYPES_ERROR_MESSAGE = "Unable to insert Service Type";

    String TRACFONE_UPDATE_SERVICE_TYPES_ERROR = "TFE2005";
    String TRACFONE_UPDATE_SERVICE_TYPES_ERROR_MESSAGE = "Unable to update Service Type";

    String TRACFONE_DELETE_SERVICE_TYPES_ERROR = "TFE2006";
    String TRACFONE_DELETE_SERVICE_TYPES_ERROR_MESSAGE = "Unable to delete Service Type";

    String TRACFONE_DUPLICATE_SERVICE_TYPES_ERROR = "TFE2007";
    String TRACFONE_DUPLICATE_SERVICE_TYPES_ERROR_MESSAGE = "Duplicate Service Type found";

    String TRACFONE_SERVICE_TYPE_DEPENDENCY_ERROR = "TFE2008";
    String TRACFONE_SERVICE_TYPE_DEPENDENCY_ERROR_MESSAGE = "This Service Type cannot be deleted since it has dependencies";

    String TRACFONE_SEARCH_CARRIER_OUTAGE = "select OBJID, PARENT_SHORT_NAME, BRAND, CHANNEL, ZIPCODE, SERVICE_TYPE, OUTAGE_TYPE, " +
            "START_TIME, END_TIME, CREATED_BY, SCRIPT_ID, X_SCRIPT_TEXT, OUTAGE_DESCRIPTION from SA.table_carrier_outage where ";

    String TRACFONE_SEARCH_CARRIER_OUTAGE_ARCHIVE = "select OBJID, PARENT_SHORT_NAME, BRAND, CHANNEL, ZIPCODE, " +
            "SERVICE_TYPE, OUTAGE_TYPE, START_TIME, END_TIME, CREATED_BY, SCRIPT_ID, X_SCRIPT_TEXT, OUTAGE_DESCRIPTION from " +
            "SA.table_carrier_outage_archive where ";

    String TRACFONE_INSERT_CARRIER_OUTAGE = "insert into sa.table_carrier_outage (OBJID, PARENT_SHORT_NAME, BRAND, CHANNEL, " +
            "ZIPCODE, SERVICE_TYPE, OUTAGE_TYPE, START_TIME, END_TIME, CREATED_BY, SCRIPT_ID, X_SCRIPT_TEXT, " +
            "OUTAGE_DESCRIPTION, INSERT_TIMESTAMP, UPDATE_TIMESTAMP) VALUES " +
            "(sa.TABLE_CARRIER_OUTAGE_SEQ.nextval, ?, ?, ?, ?, ?, ?, TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS'), " +
            "TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS'), ?, ?, ?, ?, sysdate, sysdate)";

    String TRACFONE_UPDATE_CARRIER_OUTAGE = "update sa.table_carrier_outage set UPDATE_TIMESTAMP = sysdate, " +
            "END_TIME = TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS'), SERVICE_TYPE = ?, OUTAGE_TYPE = ?, BRAND = ?, CHANNEL = ?, " +
            "OUTAGE_DESCRIPTION = ? where OBJID = ? ";

    String TRACFONE_GET_DUPLICATE_CARRIER_OUTAGE = "SELECT ZIPCODE from sa.table_carrier_outage where " +
            "PARENT_SHORT_NAME = ? and  BRAND like ? and  CHANNEL like ? and OUTAGE_TYPE = ? "
            + " and SERVICE_TYPE like ? and START_TIME = to_date(? ,'yyyy/mm/dd hh24:mi:ss')";

    String TRACFONE_BULK_UPDATE_END_TIME = "update sa.table_carrier_outage set UPDATE_TIMESTAMP = sysdate, " +
            "END_TIME = TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') where OBJID in (?";

    String TRACFONE_GET_ALL_SERVICE_TYPES = "select OBJID, SERVICE_TYPE, SERVICE_TYPE_CATEGORY, REMARKS from sa.TABLE_OUTAGE_SERVICE_TYPE";

    String TRACFONE_INSERT_SERVICE_TYPE = "insert into sa.TABLE_OUTAGE_SERVICE_TYPE "
            + "(OBJID, SERVICE_TYPE, SERVICE_TYPE_CATEGORY, CREATION_DATE, REMARKS) values (?, ?, ?, sysdate, ?)";

    String TRACFONE_MAX_SERVICE_TYPE_OBJID = "select max(objid) as objid from sa.TABLE_OUTAGE_SERVICE_TYPE";

    String TRACFONE_UPDATE_SERVICE_TYPE = "update sa.TABLE_OUTAGE_SERVICE_TYPE set SERVICE_TYPE = ?,"
            + "SERVICE_TYPE_CATEGORY = ?,REMARKS = ? where objid = ?";

    String TRACFONE_DELETE_SERVICE_TYPE = "delete from sa.TABLE_OUTAGE_SERVICE_TYPE where OBJID = ?";

    String TRACFONE_CHECK_SERVICE_PLANS_OUTAGE = "select distinct SERVICE_TYPE from sa.table_carrier_outage WHERE " +
            "LOWER(SERVICE_TYPE) like ?";
}
