package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneIgFailLogs;
import com.tracfone.service.model.response.TFOneIGFailLogs;
import com.tracfone.service.model.response.TFOneIgFailLogSearchModel;
import com.tracfone.service.util.TracfoneOneConstantIgFailLags;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Thejaswini
 */
@Stateless
public class TracfoneOneIgFailLogsController implements TracfoneOneIgFailLogsControllerLocal, TracfoneOneConstantIgFailLags {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneIgFailLogsController.class);

    @EJB
    TracfoneOneIgFailLogsActionLocal tracfoneIgFailLogsAction;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @Override
    public TFOneIgFailLogSearchModel getIgFailLogs(TracfoneOneIgFailLogs tracfoneOneIgFailLogs) throws TracfoneOneException {
        TFOneIgFailLogSearchModel failLogs;
        try {
            failLogs = tracfoneIgFailLogsAction.getIgFailLogs(tracfoneOneIgFailLogs);
        }catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_IG_FAIL_LOGS_ERROR, TRACFONE_GET_IG_FAIL_LOGS_ERROR_MESSAGE, ex);
        }
        return failLogs;
    }


}

