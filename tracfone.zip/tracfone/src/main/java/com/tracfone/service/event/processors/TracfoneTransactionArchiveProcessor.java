/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.event.processors;

import com.tracfone.ejb.entity.session.TFTransactionArchiveFacadeLocal;
import com.tracfone.service.model.event.TFTransactionArchive;
import java.util.Calendar;
import javax.ejb.Asynchronous;
import javax.ejb.EJB;
import javax.ejb.Singleton;

import javax.enterprise.event.Observes;
import javax.inject.Named;

/**
 *
 * @author Srinivas Murthy Pulavarthy
 */
@Named
@Singleton
public class TracfoneTransactionArchiveProcessor {
    
    @EJB
    TFTransactionArchiveFacadeLocal transactionArchiveFacadeLocalEJB;    
    
    @Asynchronous 
    public void observeItemEvent(@Observes TFTransactionArchive transactionArchive) {
        com.tracfone.ejb.entity.TFTransactionArchive tfTransactionArchive = new com.tracfone.ejb.entity.TFTransactionArchive();
        tfTransactionArchive.setTransactionId("-1");//Srinivas : We need to modify the Insert Transaction block to retrieve both Transaction ID and Action Item Id;
        tfTransactionArchive.setActionItemId(transactionArchive.getActionItemId());
        tfTransactionArchive.setDbEnv(transactionArchive.getDbEnv());
        tfTransactionArchive.setUserId(Long.valueOf(transactionArchive.getUserId()));
        tfTransactionArchive.setStatus(transactionArchive.getStatus());
        tfTransactionArchive.setCreateddate(Calendar.getInstance().getTime());
        tfTransactionArchive.setModifieddate(Calendar.getInstance().getTime());
        Calendar deactivationDateCalendar = Calendar.getInstance(); 
        deactivationDateCalendar.add(Calendar.DATE, 7);
        tfTransactionArchive.setDeactivationDate(deactivationDateCalendar.getTime());
        transactionArchiveFacadeLocalEJB.create(tfTransactionArchive);
    }
}
