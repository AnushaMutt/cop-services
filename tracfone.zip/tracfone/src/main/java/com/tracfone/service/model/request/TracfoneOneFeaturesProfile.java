/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
//import javax.xml.bind.annotation.XmlElement;

/**
 * Table sa.x_rp_extension_config
 * @author Nidhi Mantri
 */
public class TracfoneOneFeaturesProfile {

    private long objid;
    @NotNull(message = "Profile Id cannot be null")
    @NotBlank(message = "Profile Id cannot be blank")
    private long profileId;
    @NotNull(message = "Feature  Name cannot be null")
    @NotBlank(message = "Feature Name cannot be blank")
    private String featureName;
    @NotNull(message = "Feature Value cannot be null")
    @NotBlank(message = "FeatureVlaue cannot be blank")
    private String featureValue;
    @NotNull(message = "Feature Requirement cannot be null")
    @NotBlank(message = "Feature Requirement cannot be blank")
    private String featureRequirement;
    @NotNull(message = "Toggle Flag  cannot be null")
    @NotBlank(message = "Feature Requirement cannot be blank")
    @Size(max=1, message = "Toggle Flag cannot have more than 1 character")
    private String toggleFlag;
    @NotNull(message = "Notes  cannot be null")
    @NotBlank(message = "Notes  cannot be blank")
    private String notes;
    @NotNull(message = "Display Sui Flag cannot be null")
    @NotBlank(message = "Display Sui Flag cannot be blank")
    @Size(max=1, message = "Display Sui Flag cannot have more than 1 character")
    private String displaySUIFlag;
    @NotNull(message = "Restricted Sui Flag  cannot be null")
    @NotBlank(message = "Restricted Sui Flag cannot be blank")
     @Size(max=1, message = "Restricted Sui Flag cannot have more than 1 character")
    private String restrictSUIFlag;
    
    private String dbEnv;
    
    public String getDbEnv() {
        return dbEnv;
    }
    
    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }
    
    public long getObjid() {
        return objid;
    }

    public void setObjid(long objid) {
        this.objid = objid;
    }

    public long getProfileId() {
        return profileId;
    }

    public void setProfileId(long profileId) {
        this.profileId = profileId;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public String getFeatureValue() {
        return featureValue;
    }

    public void setFeatureValue(String featureValue) {
        this.featureValue = featureValue;
    }

    public String getFeatureRequirement() {
        return featureRequirement;
    }

    public void setFeatureRequirement(String featureRequirement) {
        this.featureRequirement = featureRequirement;
    }

    public String getToggleFlag() {
        return toggleFlag;
    }

    public void setToggleFlag(String toggleFlag) {
        this.toggleFlag = toggleFlag;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getDisplaySUIFlag() {
        return displaySUIFlag;
    }

    public void setDisplaySUIFlag(String displaySUIFlag) {
        this.displaySUIFlag = displaySUIFlag;
    }

    public String getRestrictSUIFlag() {
        return restrictSUIFlag;
    }

    public void setRestrictSUIFlag(String restrictSUIFlag) {
        this.restrictSUIFlag = restrictSUIFlag;
    }

    @Override
    public String toString() {
        return "TFOneFeaturesProfile{" + "objid=" + objid + ", profileId=" + profileId + ", featureName=" + featureName + ", featureValue=" + featureValue + ", featureRequirement=" + featureRequirement + ", toggleFlag=" + toggleFlag + ", notes=" + notes + ", displaySUIFlag=" + displaySUIFlag + ", restrictSUIFlag=" + restrictSUIFlag + ", dbEnv=" + dbEnv + '}';
    }
    
   
    
}


