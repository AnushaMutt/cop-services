

package com.tracfone.service.model.request;

import javax.validation.constraints.NotNull;
/**
 * @author druiz
 */
public class TracfoneOneRole {
    @NotNull(message = "Role cannot be empty")
    private Integer roleId;
    private String roleName;
    private Integer rolePriority;

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public Integer getRolePriority() {
        return rolePriority;
    }

    public void setRolePriority(Integer rolePriority) {
        this.rolePriority = rolePriority;
    }
}