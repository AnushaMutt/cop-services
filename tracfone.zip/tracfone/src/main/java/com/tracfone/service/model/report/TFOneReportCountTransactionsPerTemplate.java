
package com.tracfone.service.model.report;

/**
 *
 * @author druiz
 */
public class TFOneReportCountTransactionsPerTemplate {
      
    private String timeRan;
    private String xTimeSegment;
    private String template;
    private String orderTypeGroup;
    private String sumAllQ;
    private String sumAllL;
    private String sumAllCp;
    private String sumAllWp;
    private String sumAllW;
    private String sumAllS;
    private String sumAllE;
    private String sumAllF;
    private String sumAllTf;
    private String sumAllHw;
    private String csumAllQ;
    private String csumAllL;
    private String csumAllCp;
    private String csumAllWp;
    private String csumAllW;
    private String csumAllS;
    private String csumAllE;
    private String csumAllF;
    private String csumAllTf;
    private String csumAllHw;
    private String totalTransCount;

    public String getTimeRan() {
        return timeRan;
    }

    public void setTimeRan(String timeRan) {
        this.timeRan = timeRan;
    }

    public String getxTimeSegment() {
        return xTimeSegment;
    }

    public void setxTimeSegment(String xTimeSegment) {
        this.xTimeSegment = xTimeSegment;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getOrderTypeGroup() {
        return orderTypeGroup;
    }

    public void setOrderTypeGroup(String orderTypeGroup) {
        this.orderTypeGroup = orderTypeGroup;
    }

    public String getSumAllQ() {
        return sumAllQ;
    }

    public void setSumAllQ(String sumAllQ) {
        this.sumAllQ = sumAllQ;
    }

    public String getSumAllL() {
        return sumAllL;
    }

    public void setSumAllL(String sumAllL) {
        this.sumAllL = sumAllL;
    }

    public String getSumAllCP() {
        return sumAllCp;
    }

    public void setSumAllCP(String sumAllCP) {
        this.sumAllCp = sumAllCP;
    }

    public String getSumAllWP() {
        return sumAllWp;
    }

    public void setSumAllWP(String sumAllWP) {
        this.sumAllWp = sumAllWP;
    }

    public String getSumAllW() {
        return sumAllW;
    }

    public void setSumAllW(String sumAllW) {
        this.sumAllW = sumAllW;
    }

    public String getSumAllS() {
        return sumAllS;
    }

    public void setSumAllS(String sumAllS) {
        this.sumAllS = sumAllS;
    }

    public String getSumAllE() {
        return sumAllE;
    }

    public void setSumAllE(String sumAllE) {
        this.sumAllE = sumAllE;
    }

    public String getSumAllF() {
        return sumAllF;
    }

    public void setSumAllF(String sumAllF) {
        this.sumAllF = sumAllF;
    }

    public String getSumAllTF() {
        return sumAllTf;
    }

    public void setSumAllTF(String sumAllTF) {
        this.sumAllTf = sumAllTF;
    }

    public String getSumAllHW() {
        return sumAllHw;
    }

    public void setSumAllHW(String sumAllHW) {
        this.sumAllHw = sumAllHW;
    }

    public String getCsumAllQ() {
        return csumAllQ;
    }

    public void setCsumAllQ(String csumAllQ) {
        this.csumAllQ = csumAllQ;
    }

    public String getCsumAllL() {
        return csumAllL;
    }

    public void setCsumAllL(String csumAllL) {
        this.csumAllL = csumAllL;
    }

    public String getCsumAllCP() {
        return csumAllCp;
    }

    public void setCsumAllCP(String csumAllCP) {
        this.csumAllCp = csumAllCP;
    }

    public String getCsumAllWP() {
        return csumAllWp;
    }

    public void setCsumAllWP(String csumAllWP) {
        this.csumAllWp = csumAllWP;
    }

    public String getCsumAllW() {
        return csumAllW;
    }

    public void setCsumAllW(String csumAllW) {
        this.csumAllW = csumAllW;
    }

    public String getCsumAllS() {
        return csumAllS;
    }

    public void setCsumAllS(String csumAllS) {
        this.csumAllS = csumAllS;
    }

    public String getCsumAllE() {
        return csumAllE;
    }

    public void setCsumAllE(String csumAllE) {
        this.csumAllE = csumAllE;
    }

    public String getCsumAllF() {
        return csumAllF;
    }

    public void setCsumAllF(String csumAllF) {
        this.csumAllF = csumAllF;
    }

    public String getCsumAllTF() {
        return csumAllTf;
    }

    public void setCsumAllTF(String csumAllTF) {
        this.csumAllTf = csumAllTF;
    }

    public String getCsumAllHW() {
        return csumAllHw;
    }

    public void setCsumAllHW(String csumAllHW) {
        this.csumAllHw = csumAllHW;
    }

    public String getTotalTransCount() {
        return totalTransCount;
    }

    public void setTotalTransCount(String totalTransCount) {
        this.totalTransCount = totalTransCount;
    }

    
}
