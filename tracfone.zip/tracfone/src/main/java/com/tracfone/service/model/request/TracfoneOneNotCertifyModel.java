package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * @author Thejaswini
 */
public class TracfoneOneNotCertifyModel {
    @Size(min = 1, message = "Obj Id cannot be null")
    @Digits(integer = 38, fraction = 0, message = "Obj Id must be a number")
    @Size(max = 38, message = "Obj Id cannot have more than 38 digits")
    private String objId;
    @Digits(integer = 38, fraction = 0, message = "Dev must be a number")
    @Size(max = 38, message = "Dev cannot have more than 38 digits")
    private String dev;
    @Size(min = 1, message = "Parent Id cannot be null")
    @Size(max = 30, message = "Parent Id cannot have more than 30 characters")
    private String parentId;
    @Size(min = 1, message = "Part Class Obj Id cannot be null")
    @Digits(integer = 38, fraction = 0, message = "Part Class Obj Id must be a number")
    @Size(max = 38, message = "Part Class Obj Id cannot have more than 38 digits")
    private String partClassObjId;
    private String dbEnv;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getDev() {
        return dev;
    }

    public void setDev(String dev) {
        this.dev = dev;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getPartClassObjId() {
        return partClassObjId;
    }

    public void setPartClassObjId(String partClassObjId) {
        this.partClassObjId = partClassObjId;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    @Override
    public String toString() {
        return "TracfoneOneNotCertifyModel{" +
                "objId='" + objId + '\'' +
                ", dev='" + dev + '\'' +
                ", parentId='" + parentId + '\'' +
                ", partClassObjId='" + partClassObjId + '\'' +
                '}';
    }
}
