package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * TABLE: TABLE_X_DATA_CONFIG
 *
 * @author Pritesh Singh
 */
public class TracfoneOneDataConfig {
    private String dbEnv;
    @Digits(integer = 38, fraction = 0, message = "ObjId must be a number")
    private String objId;
    @Digits(integer = 38, fraction = 0, message = "Dev must be a number")
    private String dev;
    @Size(max = 30, message = "Parent Id cannot have more than 30 characters")
    private String parentId;
    @Digits(integer = 38, fraction = 0, message = "Part Class ObjId must be a number")
    private String partClassObjId;
    @Digits(integer = 38, fraction = 0, message = "Default must be a number")
    private String xDefault;
    @Size(max = 30, message = "Ip Address cannot have more than 30 characters")
    private String ipAddress;
    @Size(max = 30, message = "Apn cannot have more than 30 characters")
    private String apn;
    @Size(max = 150, message = "Home Page cannot have more than 150 characters")
    private String homePage;
    @Size(max = 150, message = "Mmsc cannot have more than 150 characters")
    private String mmsc;
    @Size(max = 1, message = "Cmd148CarrierDataSwitch cannot have more than 1 characters")
    private String cmd148CarrierDataSwitch;
    @Digits(integer = 38, fraction = 0, message = "Data Switch must be a number")
    private String dataSwitch;
    @Size(max = 1, message = "Cmd71GprsApn cannot have more than 1 characters")
    private String cmd71GprsApn;
    @Size(max = 1, message = "Cmd150ClearProxy cannot have more than 1 characters")
    private String cmd150ClearProxy;
    @Size(max = 1, message = "Cmd121GatewayPortUpdate cannot have more than 1 characters")
    private String cmd121GatewayPortUpdate;
    @Size(max = 1, message = "Cmd121GatewayIpUpdate cannot have more than 1 characters")
    private String cmd121GatewayIpUpdate;
    @Size(max = 1, message = "Cmd71MmscUpdate cannot have more than 1 characters")
    private String cmd71MmscUpdate;
    @Size(max = 1, message = "Cmd71GatewayHome cannot have more than 1 characters")
    private String cmd71GatewayHome;
    @Digits(integer = 22, fraction = 0, message = "Cmd121GatewayIpPortUpdate must be a number")
    private String cmd121GatewayIpPortUpdate;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getDev() {
        return dev;
    }

    public void setDev(String dev) {
        this.dev = dev;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getPartClassObjId() {
        return partClassObjId;
    }

    public void setPartClassObjId(String partClassObjId) {
        this.partClassObjId = partClassObjId;
    }

    public String getxDefault() {
        return xDefault;
    }

    public void setxDefault(String xDefault) {
        this.xDefault = xDefault;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getApn() {
        return apn;
    }

    public void setApn(String apn) {
        this.apn = apn;
    }

    public String getHomePage() {
        return homePage;
    }

    public void setHomePage(String homePage) {
        this.homePage = homePage;
    }

    public String getMmsc() {
        return mmsc;
    }

    public void setMmsc(String mmsc) {
        this.mmsc = mmsc;
    }

    public String getCmd148CarrierDataSwitch() {
        return cmd148CarrierDataSwitch;
    }

    public void setCmd148CarrierDataSwitch(String cmd148CarrierDataSwitch) {
        this.cmd148CarrierDataSwitch = cmd148CarrierDataSwitch;
    }

    public String getDataSwitch() {
        return dataSwitch;
    }

    public void setDataSwitch(String dataSwitch) {
        this.dataSwitch = dataSwitch;
    }

    public String getCmd71GprsApn() {
        return cmd71GprsApn;
    }

    public void setCmd71GprsApn(String cmd71GprsApn) {
        this.cmd71GprsApn = cmd71GprsApn;
    }

    public String getCmd150ClearProxy() {
        return cmd150ClearProxy;
    }

    public void setCmd150ClearProxy(String cmd150ClearProxy) {
        this.cmd150ClearProxy = cmd150ClearProxy;
    }

    public String getCmd121GatewayPortUpdate() {
        return cmd121GatewayPortUpdate;
    }

    public void setCmd121GatewayPortUpdate(String cmd121GatewayPortUpdate) {
        this.cmd121GatewayPortUpdate = cmd121GatewayPortUpdate;
    }

    public String getCmd121GatewayIpUpdate() {
        return cmd121GatewayIpUpdate;
    }

    public void setCmd121GatewayIpUpdate(String cmd121GatewayIpUpdate) {
        this.cmd121GatewayIpUpdate = cmd121GatewayIpUpdate;
    }

    public String getCmd71MmscUpdate() {
        return cmd71MmscUpdate;
    }

    public void setCmd71MmscUpdate(String cmd71MmscUpdate) {
        this.cmd71MmscUpdate = cmd71MmscUpdate;
    }

    public String getCmd71GatewayHome() {
        return cmd71GatewayHome;
    }

    public void setCmd71GatewayHome(String cmd71GatewayHome) {
        this.cmd71GatewayHome = cmd71GatewayHome;
    }

    public String getCmd121GatewayIpPortUpdate() {
        return cmd121GatewayIpPortUpdate;
    }

    public void setCmd121GatewayIpPortUpdate(String cmd121GatewayIpPortUpdate) {
        this.cmd121GatewayIpPortUpdate = cmd121GatewayIpPortUpdate;
    }

    @Override
    public String toString() {
        return "TracfoneOneDataConfig{" +
                "dbEnv='" + dbEnv + '\'' +
                ", objId='" + objId + '\'' +
                ", dev='" + dev + '\'' +
                ", parentId='" + parentId + '\'' +
                ", partClassObjId='" + partClassObjId + '\'' +
                ", xDefault='" + xDefault + '\'' +
                ", ipAddress='" + ipAddress + '\'' +
                ", apn='" + apn + '\'' +
                ", homePage='" + homePage + '\'' +
                ", mmsc='" + mmsc + '\'' +
                ", cmd148CarrierDataSwitch='" + cmd148CarrierDataSwitch + '\'' +
                ", dataSwitch='" + dataSwitch + '\'' +
                ", cmd71GprsApn='" + cmd71GprsApn + '\'' +
                ", cmd150ClearProxy='" + cmd150ClearProxy + '\'' +
                ", cmd121GatewayPortUpdate='" + cmd121GatewayPortUpdate + '\'' +
                ", cmd121GatewayIpUpdate='" + cmd121GatewayIpUpdate + '\'' +
                ", cmd71MmscUpdate='" + cmd71MmscUpdate + '\'' +
                ", cmd71GatewayHome='" + cmd71GatewayHome + '\'' +
                ", cmd121GatewayIpPortUpdate='" + cmd121GatewayIpPortUpdate + '\'' +
                '}';
    }
}