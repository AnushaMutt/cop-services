package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneGeoCoderAddress;
import com.tracfone.service.model.request.TracfoneOneGeoCoderToken;
import com.tracfone.service.model.response.TFOneGeoCodeAddress;
import com.tracfone.service.model.response.TFOneGeoCoder;

import javax.ejb.Local;

/**
 *
 * @author Thejaswini
 */
@Local
public interface TracfoneOneGeoCoderControllerLocal {

    TFOneGeoCoder generateToken(int userId, TracfoneOneGeoCoderToken tracfoneOneGeoCoderToken) throws TracfoneOneException;

    TFOneGeoCodeAddress findGeoAddressLocation (int use, final TracfoneOneGeoCoderAddress tracfoneOneGeoCoderAddress) throws TracfoneOneException;

}
