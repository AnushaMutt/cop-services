package com.tracfone.service.model.response;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author druiz
 */
public class TFOneCarrierSubscriber {

    public static final String LINE_PLATFORM_PREPAID = "PREPAID";
    public static final String LINE_PLATFORM_POSTPAID = "POSTPAID";

    public static final String MIN = "MIN";
    public static final String SIM = "SIM";
    public static final String LINE_STATUS_ACTIVE = "ACTIVE";
    public static final String LINE_STATUS_SUSPENDED = "SUSPENDED";
    public static final String LINE_STATUS_CANCELED = "CANCELED";
    public static final String LINE_STATUS_RESERVED = "RESERVED";

    private String min;
    private String esn;
    private String sim;
    private String make;
    private String model;
    private String lineStatus;
    private String lineFoundBy;
    private String linePlatform;
    private TFOneRatePlan rateplanProfile;
    private List<TFOneActionItemBucket> buckets;
    private List<Map<String, String>> additionalFields;
    private String carrierErrorMessage;
    private String status;

    public TFOneCarrierSubscriber() {
        min = "";
        esn = "";
        lineStatus = "";
        lineFoundBy = "";
        rateplanProfile = null;
        buckets = new ArrayList<>();
    }

    public String getLinePlatform() {
        return linePlatform;
    }

    public void setLinePlatform(String linePlatform) {
        this.linePlatform = linePlatform;
    }

    public boolean lineFoundByMin() {
        return MIN.equalsIgnoreCase(lineFoundBy);
    }

    public boolean lineFoundBySim() {
        return SIM.equalsIgnoreCase(lineFoundBy);
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getEsn() {
        return esn;
    }

    public void setEsn(String esn) {
        this.esn = esn;
    }

    public String getSim() {
        return sim;
    }

    public void setSim(String sim) {
        this.sim = sim;
    }

    public String getLineStatus() {
        return lineStatus;
    }

    public void setLineStatus(String lineStatus) {
        this.lineStatus = lineStatus;
    }

    public String getLineFoundBy() {
        return lineFoundBy;
    }

    public void setLineFoundBy(String lineFoundBy) {
        this.lineFoundBy = lineFoundBy;
    }

    public TFOneRatePlan getRateplanProfile() {
        return rateplanProfile;
    }

    public void setRateplanProfile(TFOneRatePlan rateplanProfile) {
        this.rateplanProfile = rateplanProfile;
    }

    public List<TFOneActionItemBucket> getBuckets() {
        return buckets;
    }

    public void setBuckets(List<TFOneActionItemBucket> buckets) {
        this.buckets = buckets;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public List<Map<String, String>> getAdditionalFields() {
        return additionalFields;
    }

    public void setAdditionalFields(List<Map<String, String>> additionalFields) {
        this.additionalFields = additionalFields;
    }

    public String getCarrierErrorMessage() {
        return carrierErrorMessage;
    }

    public void setCarrierErrorMessage(String carrierErrorMessage) {
        this.carrierErrorMessage = carrierErrorMessage;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "TFOneCarrierSubscriber{" +
                "min='" + min + '\'' +
                ", esn='" + esn + '\'' +
                ", sim='" + sim + '\'' +
                ", make='" + make + '\'' +
                ", model='" + model + '\'' +
                ", lineStatus='" + lineStatus + '\'' +
                ", lineFoundBy='" + lineFoundBy + '\'' +
                ", linePlatform='" + linePlatform + '\'' +
                ", rateplanProfile=" + rateplanProfile +
                ", buckets=" + buckets +
                ", additionalFields=" + additionalFields +
                ", carrierErrorMessage='" + carrierErrorMessage + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}