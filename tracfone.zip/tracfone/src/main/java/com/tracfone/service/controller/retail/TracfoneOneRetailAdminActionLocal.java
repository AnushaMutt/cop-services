package com.tracfone.service.controller.retail;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneJobTask;
import com.tracfone.service.model.retail.request.TracfoneOneRetailBrand;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrier;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierDetail;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierPrefDetail;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierPrefGroup;
import com.tracfone.service.model.retail.request.TracfoneOneRetailLocation;
import com.tracfone.service.model.retail.request.TracfoneOneRetailMaster;
import com.tracfone.service.model.retail.request.TracfoneOneRetailParent;
import com.tracfone.service.model.retail.request.TracfoneOneRetailParentRule;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTech;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTpAdminSearchModel;
import com.tracfone.service.model.retail.request.TracfoneOneTraitLogicRule;
import com.tracfone.service.model.retail.response.TFOneRetailBrand;
import com.tracfone.service.model.retail.response.TFOneRetailCarrier;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierDetail;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierPrefDetail;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierPrefGroup;
import com.tracfone.service.model.retail.response.TFOneRetailMaster;
import com.tracfone.service.model.retail.response.TFOneRetailParent;
import com.tracfone.service.model.retail.response.TFOneRetailParentRule;
import com.tracfone.service.model.retail.response.TFOneRetailTech;
import com.tracfone.service.model.retail.response.TFOneRetailTpAdminSearchResults;
import com.tracfone.service.model.retail.response.TFOneTraitLogicRule;

import javax.ejb.Local;
import java.util.List;

@Local
public interface TracfoneOneRetailAdminActionLocal {

    List<TFOneRetailCarrier> getCarriers() throws TracfoneOneException;

    TFOneGeneralResponse insertCarrier(TracfoneOneRetailCarrier tfCRtlCarrier, int userId) throws TracfoneOneException;

    List<TFOneRetailBrand> getBrands() throws TracfoneOneException;

    TFOneGeneralResponse insertBrand(TracfoneOneRetailBrand tfOneCRtlBrand, int userId) throws TracfoneOneException;

    List<TFOneRetailTech> getTechs() throws TracfoneOneException;

    TFOneGeneralResponse insertTech(TracfoneOneRetailTech tfOneCRtlTech, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertCarrierDetail(TracfoneOneRetailCarrierDetail tfOneCrtlCarrierDtl, int userId) throws TracfoneOneException;

    List<TFOneRetailCarrierDetail> getCarrierDetails() throws TracfoneOneException;

    List<TFOneTraitLogicRule> getTraitLogicRules() throws TracfoneOneException;

    List<TFOneRetailCarrierPrefGroup> getCarrierPrefGroups() throws TracfoneOneException;

    List<TFOneRetailCarrierPrefDetail> getCarrierPrefDetails(String carrierPrefGroupId) throws TracfoneOneException;

    TFOneGeneralResponse insertCarrierPrefGroup(TracfoneOneRetailCarrierPrefGroup tracfoneOneRetailCarrierPrefGroup, int userId) throws TracfoneOneException;

    List<TFOneRetailCarrierDetail> getCarrierDetailsByBrand(String brandId) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrier(TracfoneOneRetailCarrier tracfoneOneRetailCarrier, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateBrand(TracfoneOneRetailBrand tracfoneOneRetailBrand, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateTech(TracfoneOneRetailTech tracfoneOneRetailTech, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrierDetail(TracfoneOneRetailCarrierDetail tracfoneOneRetailCarrierDetail, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrierPrefGroup(TracfoneOneRetailCarrierPrefGroup tracfoneOneRetailCarrierPrefGroup, int userId) throws TracfoneOneException;

    List<TFOneRetailParent> getParents() throws TracfoneOneException;

    List<TFOneRetailMaster> getMasters(String parentId) throws TracfoneOneException;

    TFOneGeneralResponse insertParent(TracfoneOneRetailParent tracfoneOneRetailParent, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateParent(TracfoneOneRetailParent tracfoneOneRetailParent, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertMaster(TracfoneOneRetailMaster tracfoneOneRetailMaster, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateMaster(TracfoneOneRetailMaster tracfoneOneRetailMaster, int userId) throws TracfoneOneException;

    List<TFOneRetailParentRule> getParentRules(String parentId) throws TracfoneOneException;

    TFOneGeneralResponse insertParentRule(TracfoneOneRetailParentRule tracfoneOneRetailParentRule, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateParentRule(TracfoneOneRetailParentRule tracfoneOneRetailParentRule, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertCarrierPrefDetail(TracfoneOneRetailCarrierPrefDetail tracfoneOneRetailCarrierPrefDetail, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteCarrierPrefDetail(String carrierPrefDetailId, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertTraitLogicRule(TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateTraitLogicRule(TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule, int userId) throws TracfoneOneException;

    TFOneRetailTpAdminSearchResults searchTpNorm(TracfoneOneRetailTpAdminSearchModel tpAdminSearchModel) throws TracfoneOneException;

    List<String> getStates() throws TracfoneOneException;

    TFOneGeneralResponse runTraits(String parentId, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateTpNorms(TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel, int userId) throws TracfoneOneException;

    List<TFOneRetailCarrierDetail> getAllCarrierDetails() throws TracfoneOneException;

    void insertTpNorm(TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel, int userId);

    TFOneGeneralResponse runTpNormTraits(int userId) throws TracfoneOneException;

    TFOneRetailTpAdminSearchResults getTpNormStats() throws TracfoneOneException;

    String getLastTraitRunDate(String parentId) throws TracfoneOneException;

    TFOneGeneralResponse runStoreTraits(TracfoneOneRetailLocation tracfoneOneRetailLocation, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateRank(String objId, String rank, int userId) throws TracfoneOneException;

    List<TFOneJobTask> runTraitsSummary() throws TracfoneOneException;

    TFOneGeneralResponse updateNewRank(List<TracfoneOneRetailCarrierPrefDetail> carrierPrefDetail, int userId) throws TracfoneOneException;
}