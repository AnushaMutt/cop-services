package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneDB2Intergate;
import com.tracfone.service.model.response.TFOneDB2Intergate;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.util.TracfoneOneConstantDB2Intergate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Gaurav.Sharma
 */
@Stateless
public class TracfoneOneDB2IntergateController implements TracfoneOneDB2IntergateControllerLocal, TracfoneOneConstantDB2Intergate {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneDB2IntergateController.class);

    @EJB
    private TracfoneOneDB2IntergateActionLocal actionLocal;

    @Override
    public List<TFOneDB2Intergate> viewDB2Intergate(TracfoneOneDB2Intergate searchCriteria) throws TracfoneOneException {
        List<TFOneDB2Intergate> viewData = new ArrayList<>();
        try {
            viewData = actionLocal.viewDB2Intergate(searchCriteria);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_DB2_INTERGATE_ERROR, TRACFONE_GET_DB2_INTERGATE_ERROR_MESSAGE, ex);
        }
        return viewData;
    }

    @Override
    public TFOneGeneralResponse updateDB2Intergate(TracfoneOneDB2Intergate tracfoneOneDB2Intergate, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = actionLocal.updateDB2Intergate(tracfoneOneDB2Intergate, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_DB2_INTERGATE_ERROR, TRACFONE_UPDATE_DB2_INTERGATE_ERROR_MESSAGE, ex);
        }
        return response;
    }
}
