/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.controller;

import com.tracfone.ejb.entity.Group;
import com.tracfone.ejb.entity.GroupActions;
import com.tracfone.ejb.entity.Tracfoneoneuser;
import com.tracfone.ejb.entity.Usergroups;
import com.tracfone.service.model.request.TracfoneOneAction;
import com.tracfone.service.model.request.TracfoneOneGroup;
import com.tracfone.service.model.request.TracfoneOneUserProfile;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author druiz
 */
@Local
public interface TracfoneEJBAdminUtilLocal {
    
    Tracfoneoneuser buildUserEntity(TracfoneOneUserProfile userProfileRequestModel, Tracfoneoneuser tracfoneUser);
    
    Group buildGroupEntity(TracfoneOneGroup groupRequestModel, Group tracfoneGroup);
    
    Group buildNewGroupEntity(TracfoneOneGroup groupRequestModel);
    
    List<Usergroups> getUserGroupsToAdd(Integer userId, List<Usergroups> existingGroups, List<TracfoneOneGroup> groupsInRequest);
    
    List<Usergroups> getUserGroupsToDelete(List<Usergroups> existingGroups, List<TracfoneOneGroup> groupsInRequest);
    
    List<GroupActions> getGroupActionsIdToAdd(Integer groupId, List<GroupActions> existingActions, List<TracfoneOneAction> actionsInRequest);
    
    List<GroupActions> getGroupActionsIdToDelete(List<GroupActions> existingActionIDs, List<TracfoneOneAction> actionsInRequest);
}
