/**
 * 
 */
package com.tracfone.service.util;

import java.util.Properties;



/**
 * @author user
 *
 */
public class TracfoneOneProperties {
	

	  private static TracfoneOneProperties instance = null; 
	  private Properties properties = null;
	  private static int counter;
	  
	private TracfoneOneProperties() { 
	}

    static {
        if(instance == null) {
            synchronized(TracfoneOneProperties.class) {
                if(instance == null) {
                    instance = new TracfoneOneProperties();
 
                }
            }
        }
    }
    
   public static TracfoneOneProperties initilizeTracfoneOneProperties() {
          return instance;
    }
    
    public void setProperties(Properties properties) {
    	this.properties = properties;
    }
    
    public Properties getProperties() {
    	return properties;
    }
    
    
    
	  

}
