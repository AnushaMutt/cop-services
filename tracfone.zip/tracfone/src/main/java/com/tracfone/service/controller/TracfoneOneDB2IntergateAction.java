package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneDB2Intergate;
import com.tracfone.service.model.response.TFOneDB2Intergate;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantDB2Intergate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Gaurav.Sharma
 */
@Stateless
public class TracfoneOneDB2IntergateAction implements TracfoneOneDB2IntergateActionLocal, TracfoneOneConstant, TracfoneOneConstantDB2Intergate {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneDB2IntergateAction.class);

    @EJB
    private DataBaseController dbControllerEJB;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    private static final String AND = " AND ";
    private static final String COMMA = ",";

    @Override
    public List<TFOneDB2Intergate> viewDB2Intergate(TracfoneOneDB2Intergate searchCriteria) throws TracfoneOneException {
        List<TFOneDB2Intergate> viewData = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(searchCriteria.getDbEnv()).getConnection();
                PreparedStatement stmt = con.prepareStatement(viewDB2IntergateStatement(TRACFONE_SEARCH_DB2_INTERGATE, searchCriteria));) {
            setDB2IntergateStatement(stmt, searchCriteria);

            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    viewData.add(setDB2Intergate(resultSet));
                }
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return viewData;
    }

    private TFOneDB2Intergate setDB2Intergate(ResultSet resultSet) throws SQLException {
        TFOneDB2Intergate viewData = new TFOneDB2Intergate();
        viewData.setActiveFlag(resultSet.getString("ACTIVE_FLAG"));
        viewData.setAppName(resultSet.getString("APP_NAME"));
        viewData.setExtraWhereClauseConditions(resultSet.getString("EXTRA_WHERE_CLAUSE_CONDITIONS"));
        viewData.setNumberOfRecords(resultSet.getString("NUMBER_OF_RECORDS"));
        viewData.setIntervalTime(resultSet.getString("INTERVAL_TIME"));
        viewData.setOrderTypes(resultSet.getString("ORDER_TYPES"));
        viewData.setQueryId(resultSet.getString("QUERY_ID"));
        viewData.setQueryName(resultSet.getString("QUERY_NAME"));
        viewData.setRemarks(resultSet.getString("REMARKS"));
        viewData.setSelectQueryClob(resultSet.getString("SELECT_QUERY_CLOB"));
        viewData.setStartingRecord(resultSet.getString("STARTING_RECORD"));
        viewData.setTemplates(resultSet.getString("TEMPLATES"));
        viewData.setUpdateQuery(resultSet.getString("UPDATE_QUERY"));
        viewData.setUseNewSql(resultSet.getString("USE_NEW_SQL"));
        LOGGER.info("TFOneDB2Intergate - " + viewData);
        return viewData;
    }

    @Override
    public TFOneGeneralResponse updateDB2Intergate(TracfoneOneDB2Intergate tracfoneOneDB2Intergate, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneDB2Intergate.getDbEnv()).getConnection();
                PreparedStatement stmt = con.prepareStatement(updateDB2IntergateStatement(TRACFONE_UPDATE_DB2_INTERGATE, tracfoneOneDB2Intergate));) {
            setUpdateDB2IntergateStatement(stmt, tracfoneOneDB2Intergate);
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update DB2 Intergate", "Updated DB2 Intergate " + tracfoneOneDB2Intergate, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneDB2Intergate.getQueryId());
    }

    private String viewDB2IntergateStatement(String query, TracfoneOneDB2Intergate tracfoneOneDB2Intergate) {
        StringBuilder builder = new StringBuilder(query);
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getActiveFlag())) {
            builder.append("ACTIVE_FLAG = ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getOrderTypes())) {
            for (String orderTypes : tracfoneOneDB2Intergate.getOrderTypes().split(",")) {
                builder.append("ORDER_TYPES LIKE ? ").append(AND);
            }
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getQueryName())) {
            builder.append("UPPER(QUERY_NAME) LIKE ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getIntervalTime())) {
            builder.append("INTERVAL_TIME = ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getNumberOfRecords())) {
            builder.append("NUMBER_OF_RECORDS = ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getStartingRecord())) {
            builder.append("STARTING_RECORD = ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getTemplates())) {
            builder.append("UPPER(TEMPLATES) LIKE ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getUpdateQuery())) {
            builder.append("UPDATE_QUERY = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getUseNewSql())) {
            builder.append("USE_NEW_SQL = ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getAppName())) {
            builder.append("UPPER(APP_NAME) = ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getQueryId())) {
            builder.append("QUERY_ID = ?").append(AND);
        }
        LOGGER.info("Search Query for DB2INTERGATE " + builder);
        return builder.substring(0, builder.lastIndexOf(AND));
    }

    private String updateDB2IntergateStatement(String query, TracfoneOneDB2Intergate tracfoneOneDB2Intergate) {
        StringBuilder builder = new StringBuilder(query);
        if (null != tracfoneOneDB2Intergate.getActiveFlag()) {
            builder.append("ACTIVE_FLAG = ?").append(COMMA);
        }
        if (null != tracfoneOneDB2Intergate.getOrderTypes()) {
            builder.append("ORDER_TYPES = ? ").append(COMMA);
        }
        if (null != tracfoneOneDB2Intergate.getQueryName()) {
            builder.append("QUERY_NAME = ?").append(COMMA);
        }
        if (null != tracfoneOneDB2Intergate.getIntervalTime()) {
            builder.append("INTERVAL_TIME = ? ").append(COMMA);
        }
        if (null != tracfoneOneDB2Intergate.getNumberOfRecords()) {
            builder.append("NUMBER_OF_RECORDS = ? ").append(COMMA);
        }
        if (null != tracfoneOneDB2Intergate.getStartingRecord()) {
            builder.append("STARTING_RECORD = ? ").append(COMMA);
        }
        if (null != tracfoneOneDB2Intergate.getTemplates()) {
            builder.append("TEMPLATES = ? ").append(COMMA);
        }
        if (null != tracfoneOneDB2Intergate.getUpdateQuery()) {
            builder.append("UPDATE_QUERY = ?").append(COMMA);
        }
        if (null != tracfoneOneDB2Intergate.getUseNewSql()) {
            builder.append("USE_NEW_SQL = ? ").append(COMMA);
        }
        if (null != tracfoneOneDB2Intergate.getAppName()) {
            builder.append("APP_NAME = ? ").append(COMMA);
        }
        if (null != tracfoneOneDB2Intergate.getRemarks()) {
            builder.append("REMARKS = ? ").append(COMMA);
        }
        if (null != tracfoneOneDB2Intergate.getExtraWhereClauseConditions()) {
            builder.append("EXTRA_WHERE_CLAUSE_CONDITIONS = ? ").append(COMMA);
        }
        if (null != tracfoneOneDB2Intergate.getSelectQueryClob()) {
            builder.append("SELECT_QUERY_CLOB = ? ").append(COMMA);
        }
        builder = new StringBuilder(builder.substring(0, builder.lastIndexOf(COMMA)));
        builder.append("WHERE QUERY_ID = ? ");
        LOGGER.info("Update Query for DB2INTERGATE " + builder);
        return builder.toString();
    }

    private int setDB2IntergateStatement(PreparedStatement stmt, TracfoneOneDB2Intergate tracfoneOneDB2Intergate) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getActiveFlag())) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getActiveFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getOrderTypes())) {
            for (String orderType : tracfoneOneDB2Intergate.getOrderTypes().split(",")) {
                stmt.setString(index++, "%" + orderType + "%");
            }
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getQueryName())) {
            stmt.setString(index++, "%" + tracfoneOneDB2Intergate.getQueryName().toUpperCase() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getIntervalTime())) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getIntervalTime());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getNumberOfRecords())) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getNumberOfRecords());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getStartingRecord())) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getStartingRecord());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getTemplates())) {
            stmt.setString(index++, "%" + tracfoneOneDB2Intergate.getTemplates().toUpperCase() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getUpdateQuery())) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getUpdateQuery());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getUseNewSql())) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getUseNewSql());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getAppName())) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getAppName().toUpperCase());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDB2Intergate.getQueryId())) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getQueryId());
        }
        return index;
    }

    private int setUpdateDB2IntergateStatement(PreparedStatement stmt, TracfoneOneDB2Intergate tracfoneOneDB2Intergate) throws SQLException {
        int index = 1;
        if (null != tracfoneOneDB2Intergate.getActiveFlag()) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getActiveFlag());
        }
        if (null != tracfoneOneDB2Intergate.getOrderTypes()) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getOrderTypes());
        }
        if (null != tracfoneOneDB2Intergate.getQueryName()) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getQueryName());
        }
        if (null != tracfoneOneDB2Intergate.getIntervalTime()) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getIntervalTime());
        }
        if (null != tracfoneOneDB2Intergate.getNumberOfRecords()) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getNumberOfRecords());
        }
        if (null != tracfoneOneDB2Intergate.getStartingRecord()) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getStartingRecord());
        }
        if (null != tracfoneOneDB2Intergate.getTemplates()) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getTemplates());
        }
        if (null != tracfoneOneDB2Intergate.getUpdateQuery()) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getUpdateQuery());
        }
        if (null != tracfoneOneDB2Intergate.getUseNewSql()) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getUseNewSql());
        }
        if (null != tracfoneOneDB2Intergate.getAppName()) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getAppName().toUpperCase());
        }
        if (null != tracfoneOneDB2Intergate.getRemarks()) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getRemarks());
        }
        if (null != tracfoneOneDB2Intergate.getExtraWhereClauseConditions()) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getExtraWhereClauseConditions());
        }
        if (null != tracfoneOneDB2Intergate.getSelectQueryClob()) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getSelectQueryClob());
        }
        if (null != tracfoneOneDB2Intergate.getQueryId()) {
            stmt.setString(index++, tracfoneOneDB2Intergate.getQueryId());
        }
        return index;
    }
}
