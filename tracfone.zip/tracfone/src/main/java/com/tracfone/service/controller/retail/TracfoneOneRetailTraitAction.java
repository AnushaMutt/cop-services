package com.tracfone.service.controller.retail;

import com.google.gson.Gson;
import com.mysql.jdbc.StringUtils;
import com.tracfone.ejb.entity.retail.session.CRtlTpNormFacadeLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.retail.request.TracfoneOneRetailLocation;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTraitSearchModel;
import com.tracfone.service.model.retail.response.TFOneRetailLocation;
import com.tracfone.service.model.retail.response.TFOneTraitDetail;
import com.tracfone.service.model.retail.response.TracfoneOneRetailAvailability;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantRetailStore;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.persistence.ParameterMode;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Stateless
public class TracfoneOneRetailTraitAction implements TracfoneOneRetailTraitActionLocal, TracfoneOneConstantRetailStore, TracfoneOneConstant {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneRetailTraitAction.class);
    private static final String AND = " AND ";
    private static final String OBJID = "OBJID";
    private static final String PENV = "p_env";
    private static final String RADIUS = "p_radius";
    private static final String USER = "p_user";
    private static final String TRAIT2LOCATION = "trait2location";


    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @EJB
    CRtlTpNormFacadeLocal cRtlTpNormFacade;

    @Override
    public List<TracfoneOneRetailAvailability> viewAvailability(TracfoneOneRetailTraitSearchModel tracfoneOneRetailLocation) throws TracfoneOneException {
        List<TracfoneOneRetailAvailability> availabilities = new ArrayList<>();
        LOGGER.info("Information sent to view availability " + tracfoneOneRetailLocation);
        try {
            Map<String, String> carrierTechDetailMap = getCarrierTechDetailMap(tracfoneOneRetailLocation);
            LOGGER.info("carrierTechDetailMap " + carrierTechDetailMap);

            List<BigDecimal> brands = getBrands(tracfoneOneRetailLocation);

            // Building the query for view availability
            StringBuilder builder = new StringBuilder(TRACFONE_VIEW_AVAILABILITY_PART1);
            for (String carrierTech : carrierTechDetailMap.values()) {
                builder.append(", (select carr_trait from c_rtl_trait_dtl where 1=1 and tdtl2trait = rt.objid and tdtl2carrier_dtl = ? and rownum = 1) ")
                        .append(carrierTech);
            }
            builder.append(TRACFONE_VIEW_AVAILABILITY_PART2)
                    .append(inClause("rtd.tdtl2brand", brands.size()));
            if (!StringUtils.isNullOrEmpty(tracfoneOneRetailLocation.getObjIds())) {
                builder.append(AND)
                        .append(inClause("rl.objid", tracfoneOneRetailLocation.getObjIds().split(",").length));
            }
            LOGGER.info("Query for get availability is " + builder.toString());
            Query query = cRtlTpNormFacade.getEntityManager().createNativeQuery(builder.toString());

            // Setting all the params
            int index = 1;
            for (String carrierDetailId : carrierTechDetailMap.keySet()) {
                query.setParameter(index++, carrierDetailId);
            }
            LOGGER.info("Added all the carrier detail ids from Brand Map " + carrierTechDetailMap);
            query.setParameter(index++, tracfoneOneRetailLocation.getParentId());
            for (BigDecimal brandId : brands) {
                LOGGER.info("bigDecimal " + brandId);
                query.setParameter(index++, brandId);
            }
            LOGGER.info("Added all the brand ids " + brands);
            if (!StringUtils.isNullOrEmpty(tracfoneOneRetailLocation.getObjIds())) {
                for (String locationId : tracfoneOneRetailLocation.getObjIds().split(",")) {
                    query.setParameter(index++, locationId);
                }
                LOGGER.info("Added all the location objids " + tracfoneOneRetailLocation.getObjIds());
            }

            // Making the call
            List<Object[]> retails = query.getResultList();
            LOGGER.info("Total number of availabilities identified - " + retails.size());
            for (Object[] retail : retails) {
                TracfoneOneRetailAvailability availability = new TracfoneOneRetailAvailability();
                availability.setRetailer(String.valueOf(retail[0]));
                availability.setStoreName(String.valueOf(retail[1]));
                availability.setStoreNum(String.valueOf(retail[2]));
                availability.setZip(String.valueOf(retail[3]));
                availability.setState(String.valueOf(retail[4]));
                availability.setBrand(String.valueOf(retail[5]));
                availability.setRadius(String.valueOf(retail[6]));
                index = 7;
                for (String carrierTech : carrierTechDetailMap.values()) {
                    String carrierTechAvailability = retail[index] != null ? String.valueOf(retail[index]) : null;
                    LOGGER.info("What is the carrierTech " + carrierTech + " and the availability is " + carrierTechAvailability);
                    if (availability.getCarrierTechs().containsKey(carrierTech)) {
                        if ("1".equalsIgnoreCase(carrierTechAvailability)) {
                            availability.getCarrierTechs().put(carrierTech, carrierTechAvailability);
                        }
                    } else {
                        availability.getCarrierTechs().put(carrierTech, carrierTechAvailability);
                    }
                    index++;
                }

                LOGGER.info("TracfoneOneRetailAvailability - " + availability);
                availabilities.add(availability);
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        LOGGER.info("View Availabilities - " + availabilities);
        return availabilities;
    }

    @Override
    public List<TFOneTraitDetail> getTraitDetails(String objId) throws TracfoneOneException {
        List<TFOneTraitDetail> traitDetails = new ArrayList<>();
        try {
            List<Object[]> traitDetailsList = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_GET_TRAIT_DETAIL).setParameter(1, objId)
                    .getResultList();

            for (Object[] traitDetail : traitDetailsList) {
                TFOneTraitDetail tfOneTraitDetail = new TFOneTraitDetail();
                tfOneTraitDetail.setRadius(String.valueOf(traitDetail[0]));
                tfOneTraitDetail.setTraits(String.valueOf(traitDetail[1]));
                tfOneTraitDetail.setDplyd(String.valueOf(traitDetail[2]));
                tfOneTraitDetail.setBufferZips(String.valueOf(traitDetail[3]));
                tfOneTraitDetail.setPop(String.valueOf(traitDetail[4]));
                tfOneTraitDetail.setZipsDplyd(String.valueOf(traitDetail[5]));
                tfOneTraitDetail.setPercZipDplyd(String.valueOf(traitDetail[6]));
                tfOneTraitDetail.setPopDplyd(String.valueOf(traitDetail[7]));
                tfOneTraitDetail.setPercPopDplyd(String.valueOf(traitDetail[8]));
                tfOneTraitDetail.setExtZipDplyd(tfOneTraitDetail.getExtZipDplyd() != null ? String.valueOf(traitDetail[9]) : null);
                tfOneTraitDetail.setExtPercPopDplyd(tfOneTraitDetail.getExtPercPopDplyd() != null ? String.valueOf(traitDetail[10]) : null);
                tfOneTraitDetail.setExtPopDplyd(tfOneTraitDetail.getExtPopDplyd() != null ? String.valueOf(traitDetail[11]) : null);
                tfOneTraitDetail.setExtPercPopDplyd(tfOneTraitDetail.getExtPercPopDplyd() != null ? String.valueOf(traitDetail[12]) : null);
                tfOneTraitDetail.setCarrier(String.valueOf(traitDetail[13]));
                tfOneTraitDetail.setBrand(String.valueOf(traitDetail[14]));
                tfOneTraitDetail.setTech(String.valueOf(traitDetail[15]));
                traitDetails.add(tfOneTraitDetail);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_TRAIT_DETAILS, TRACFONE_GET_TRAIT_DETAILS_MESSAGE, ex);
        }
        return traitDetails;
    }

    @Override
    public TFOneGeneralResponse closeStores(String objIds, String parentId, int userId) throws TracfoneOneException {
        try {
            updateBasedOnObjIds(objIds, TRACFONE_CLOSE_STORES, OBJID, false);

            Query query = cRtlTpNormFacade.getEntityManager().
                    createNativeQuery(TRACFONE_COUNT_LOCATIONS);

            List<Object[]> totalCount = query.setParameter(1, parentId).getResultList();
            if ("0".equalsIgnoreCase(String.valueOf(totalCount.get(0)))) {
                LOGGER.info("No Open Stores found , Going to inactive Parent " + parentId);
                cRtlTpNormFacade.getEntityManager().createNativeQuery(TRACFONE_INACTIVE_PARENT).
                        setParameter(1, parentId).executeUpdate();
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Close Retail Stores ", objIds, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_CLOSE_STORE_SUCCESS);
    }

    @Override
    public List<TFOneRetailLocation> searchRetailLocations(TracfoneOneRetailTraitSearchModel retailTraitSearchModel) throws TracfoneOneException {
        List<TFOneRetailLocation> locations = new ArrayList<>();
        try {
            Query query = cRtlTpNormFacade.getEntityManager().
                    createNativeQuery(getSearchLocationQuery(TRACFONE_SEARCH_LOCATIONS, retailTraitSearchModel));
            int index = 1;
            query.setParameter(index++, retailTraitSearchModel.getParentId());
            setSearchParams(retailTraitSearchModel, query, index);

            List<Object[]> retails = query.getResultList();
            for (Object[] retail : retails) {
                TFOneRetailLocation location = getTfOneRetailLocation(retail);
                location.setLastUpdateDate(String.valueOf(retail[8]));
                LOGGER.info("TFOneRetailLocation - " + location);
                locations.add(location);
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return locations;
    }

    private void setSearchParams(TracfoneOneRetailTraitSearchModel retailTraitSearchModel, Query query, int index) {
        if (!StringUtils.isNullOrEmpty(retailTraitSearchModel.getBrand())) {
            query.setParameter(index++, retailTraitSearchModel.getBrand());
        }
        if (!StringUtils.isNullOrEmpty(retailTraitSearchModel.getCarrier())) {
            for (String carrierId : retailTraitSearchModel.getCarrier().split(",")) {
                query.setParameter(index++, carrierId);
            }
        }
        LOGGER.info("Searching based on list of zip " + retailTraitSearchModel.getZips());
        if (!StringUtils.isNullOrEmpty(retailTraitSearchModel.getZips())) {
            for (String zipCode : retailTraitSearchModel.getZips().split(",")) {
                query.setParameter(index++, zipCode);
            }
        }
    }

    @Override
    public TFOneGeneralResponse approveTraits(String objId, int userId) {
        try {
            LOGGER.info("Approving Traits" + objId);
            cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_UPDATE_TRAIT_STATUS_CLOSED)
                    .setParameter(1, objId)
                    .setParameter(2, objId)
                    .executeUpdate();
            LOGGER.info("Set the status of active trait to closed" + objId);
            cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_UPDATE_TRAIT_STATUS_ACTIVE)
                    .setParameter(1, objId)
                    .executeUpdate();
            LOGGER.info("Set the status of pending trait to active" + objId);
            Object count = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_ACTIVE_TRAIT_COUNT)
                    .setParameter(1, objId)
                    .getSingleResult();
            LOGGER.info("Count of active traits for the location - " + count);
            if (Integer.valueOf(String.valueOf(count)) < 1) {
                cRtlTpNormFacade.getEntityManager()
                        .createNativeQuery(TRACFONE_RESET_TRAIT_STATUS)
                        .setParameter(1, objId)
                        .executeUpdate();
                LOGGER.info("Set the status back to active" + objId);
            }
        } catch (Exception e) {
            LOGGER.error("Error approving trait for " + objId, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Approved Traits for Locations ObjIds ", objId, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_APPROVE_TRAIT_SUCCESS);
    }

    @Override
    public List<String> getRadius() throws TracfoneOneException {
        List<String> radius = new ArrayList<>();
        try {
            radius = cRtlTpNormFacade.getEntityManager().createNativeQuery(TRACFONE_GET_RADIUS).getResultList();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return radius;
    }

    @Override
    public Map<String, String> analyseTraits(TracfoneOneRetailTraitSearchModel retailTraitSearchModel, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        Map<String, String> analysis = new HashMap<>();
        LOGGER.info("Calling analyseTraits for " + retailTraitSearchModel);
        try {
            for (String objId : retailTraitSearchModel.getObjIds().split(",")) {
                LOGGER.info("Calling SP C_RTL_TRAIT_SP_N" + objId);
                analyseTraitsStoredProcedure(objId, retailTraitSearchModel);
                LOGGER.info("Done with SP C_RTL_TRAIT_SP_N  for Trait Analysis " + objId);
                Query query = cRtlTpNormFacade.getEntityManager().createNativeQuery(TRACFONE_TRAIT_ANALYSIS);
                query.setParameter(1, retailTraitSearchModel.getBrand());
                query.setParameter(2, objId);
                List<String> rslts = query.getResultList();
                StringBuilder prefs = new StringBuilder();
                for (String rslt : rslts) {
                    prefs.append("[" + rslt + "] ");
                }
                analysis.put(objId, String.valueOf(prefs));
                LOGGER.info(" Analyse Traits " + analysis);
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Trait Analysis ", gson.toJson(retailTraitSearchModel), null);
            tracfoneAuditEvent.fire(audit);
        }
        LOGGER.info("Trait Analysis " + analysis);
        return analysis;
    }

    @Override
    public int getTraitCountForLocation(String objId) {
        int traitCount = 0;
        try {
            Object count = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_TRAIT_COUNT)
                    .setParameter(1, objId)
                    .getSingleResult();
            LOGGER.info("Count of traits for the location - " + count);
            traitCount = Integer.valueOf(String.valueOf(count));
        } catch (Exception e) {
            LOGGER.error("Error when getting the trait count for objid " + objId, e);
        }
        return traitCount;
    }

    @Override
    public List<TFOneRetailLocation> searchClosedStores(TracfoneOneRetailTraitSearchModel retailTraitSearchModel) throws TracfoneOneException {
        List<TFOneRetailLocation> locations = new ArrayList<>();
        try {
            Query query = cRtlTpNormFacade.getEntityManager().
                    createNativeQuery(getSearchLocationQuery(TRACFONE_SEARCH_CLOSED_LOCATIONS, retailTraitSearchModel));
            int index = 1;
            query.setParameter(index++, retailTraitSearchModel.getParentId());
            query.setParameter(index++, retailTraitSearchModel.getFromDate());
            query.setParameter(index++, retailTraitSearchModel.getToDate());
            setSearchParams(retailTraitSearchModel, query, index);
            List<Object[]> retails = query.getResultList();
            for (Object[] retail : retails) {
                TFOneRetailLocation location = getTfOneRetailLocation(retail);
                location.setLastUpdateDate(String.valueOf(retail[8]));
                LOGGER.info("TFOneRetailLocation - " + location);
                locations.add(location);
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return locations;
    }

    private TFOneRetailLocation getTfOneRetailLocation(Object[] retail) {
        TFOneRetailLocation location = new TFOneRetailLocation();
        location.setObjId(String.valueOf(retail[0]));
        location.setMasterId(String.valueOf(retail[1]));
        location.setParentId(String.valueOf(retail[2]));
        location.setStoreName(String.valueOf(retail[3]));
        location.setStoreNum(String.valueOf(retail[4]));
        location.setState(String.valueOf(retail[5]));
        location.setZip(String.valueOf(retail[6]));
        location.setRadius(String.valueOf(retail[7]));
        return location;
    }

    private void analyseTraitsStoredProcedure(String objId, TracfoneOneRetailTraitSearchModel retailTraitSearchModel) {
        try {
            cRtlTpNormFacade.getEntityManager()
                    .createStoredProcedureQuery("C_RTL_TRAIT_SP_N")
                    .registerStoredProcedureParameter(PENV, String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter("p_brand", String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter("p_loc_id", String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter(RADIUS, String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter(USER, String.class, ParameterMode.IN)
                    .setParameter(PENV, "ANALYSIS")
                    .setParameter("p_brand", retailTraitSearchModel.getBrand())
                    .setParameter("p_loc_id", objId)
                    .setParameter(RADIUS, retailTraitSearchModel.getRadius())
                    //TODO need to re-look into
                    .setParameter(USER, "1")
                    .execute();
        } catch (Exception e) {
            LOGGER.error("Error when running Trait Analysis for objid " + objId, e);
        }
    }

    @Override
    public TFOneGeneralResponse reopenStores(String objIds, String parentId, int userId) throws TracfoneOneException {
        try {
            cRtlTpNormFacade.getEntityManager().createNativeQuery(TRACFONE_ACTIVE_PARENT).
                    setParameter(1, parentId).executeUpdate();

            updateBasedOnObjIds(objIds, TRACFONE_REOPEN_STORES, OBJID, false);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Reopen Retail Stores ", objIds, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_REOPEN_STORE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse deleteStores(String objIds, int userId) throws TracfoneOneException {
        try {
            // Delete all dependencies in c_rtl_trait_pref table
            updateBasedOnObjIds(objIds, TRACFONE_DELETE_TRAIT_PREFS, TRAIT2LOCATION, true);
            // Delete all dependencies in c_rtl_trait_pref_tst table
            updateBasedOnObjIds(objIds, TRACFONE_DELETE_TRAIT_PREFS_TST, TRAIT2LOCATION, true);
            // Delete all dependencies in c_rtl_trait_dtl table
            updateBasedOnObjIds(objIds, TRACFONE_DELETE_TRAIT_DETAILS, TRAIT2LOCATION, true);
            // Delete all dependencies in c_rtl_trait_dtl_tst table
            updateBasedOnObjIds(objIds, TRACFONE_DELETE_TRAIT_DETAILS_TST, TRAIT2LOCATION, true);
            // Delete all dependencies in c_rtl_trait table
            updateBasedOnObjIds(objIds, TRACFONE_DELETE_TRAITS, TRAIT2LOCATION, false);
            // Delete all dependencies in c_rtl_trait_tst table
            updateBasedOnObjIds(objIds, TRACFONE_DELETE_TRAITS_TST, TRAIT2LOCATION, false);
            // Delete all c_rtl_location table
            updateBasedOnObjIds(objIds, TRACFONE_DELETE_LOCATIONS, OBJID, false);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Deleted Retail Stores ", objIds, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_DELETE_STORE_SUCCESS);
    }

    private void updateBasedOnObjIds(String objIds, String tracfoneDeleteTraitPrefs, String fieldName, boolean needsAdditionalBracket) {
        StringBuilder builder = new StringBuilder(tracfoneDeleteTraitPrefs);
        builder.append(inClause(fieldName, objIds.split(",").length));
        if (needsAdditionalBracket) {
            builder.append(")");
        }

        int index = 1;
        LOGGER.info("Query to be executed is :" + builder);
        Query query = cRtlTpNormFacade.getEntityManager().createNativeQuery(builder.toString());
        for (String objId : objIds.split(",")) {
            query.setParameter(index++, objId);
        }

        query.executeUpdate();
    }

    private String getSearchLocationQuery(String query, TracfoneOneRetailTraitSearchModel retailTraitSearchModel) {
        StringBuilder builder = new StringBuilder(query);
        if (!StringUtils.isNullOrEmpty(retailTraitSearchModel.getBrand())) {
            builder.append("rt.objid in (select tdtl2trait from c_rtl_trait_dtl where tdtl2brand = ?) ")
                    .append(AND);
        }
        if (!StringUtils.isNullOrEmpty(retailTraitSearchModel.getCarrier())) {
            builder.append("rt.objid in (select tdtl2trait from c_rtl_trait_dtl where tdtl2carrier_dtl in " +
                    "(select objid from c_rtl_carrier_dtl where ").append(inClause("cdtl2carrier", retailTraitSearchModel.getCarrier().split(",").length))
                    .append("))").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(retailTraitSearchModel.getZips())) {
            builder.append(inClause("rl.zip", retailTraitSearchModel.getZips().split(",").length))
                    .append(AND);
        }
        String sql = builder.substring(0, builder.lastIndexOf(AND)).concat(" order by rl.store_num");
        LOGGER.info("Query for search Master Retail is : " + sql);
        return sql;
    }

    @Override
    public boolean addUpdateRetailStore(TracfoneOneRetailLocation tracfoneOneRetailLocation, int userId) {
        Gson gson = new Gson();
        boolean isSuccess = false;
        try {
            cRtlTpNormFacade.getEntityManager()
                    .createStoredProcedureQuery("C_RTL_STORE_SP_N")
                    .registerStoredProcedureParameter(PENV, String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter("p_parent", String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter("p_store_name", String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter("p_store_num", String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter("p_zip", String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter(RADIUS, String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter(USER, String.class, ParameterMode.IN)
                    .setParameter(PENV, "PROD")
                    .setParameter("p_parent", String.valueOf(tracfoneOneRetailLocation.getParentId()))
                    .setParameter("p_store_name", tracfoneOneRetailLocation.getStoreName())
                    .setParameter("p_store_num", tracfoneOneRetailLocation.getStoreNum())
                    .setParameter("p_zip", tracfoneOneRetailLocation.getZip())
                    .setParameter(RADIUS, tracfoneOneRetailLocation.getRadius())
                    //TODO need to re-look into
                    .setParameter(USER, "1")
                    .execute();
            isSuccess = true;
        } catch (Exception e) {
            LOGGER.error("Error when running SP for retail store location " + tracfoneOneRetailLocation, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Added or updated a Retail Store ", gson.toJson(tracfoneOneRetailLocation), null);
            tracfoneAuditEvent.fire(audit);
        }
        return isSuccess;
    }

    private String inClause(String fieldName, int total) {
        StringBuilder builder = new StringBuilder(fieldName);
        builder.append(" IN (");
        int count = 1;
        while (count <= total) {
            builder.append("?,");
            count++;
        }
        builder.deleteCharAt(builder.length() - 1);
        builder.append(") ");
        return builder.toString();
    }

    private List<BigDecimal> getBrands(TracfoneOneRetailTraitSearchModel tracfoneOneRetailLocation) {
        List<BigDecimal> brands;
        if (!StringUtils.isNullOrEmpty(tracfoneOneRetailLocation.getBrand())) {
            brands = new ArrayList<>();
            brands.add(BigDecimal.valueOf(Long.valueOf(tracfoneOneRetailLocation.getBrand())));
        } else {
            brands = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_GET_BRAND_FOR_PARENT)
                    .setParameter(1, tracfoneOneRetailLocation.getParentId())
                    .getResultList();
        }
        return brands;
    }

    private Map<String, String> getCarrierTechDetailMap(TracfoneOneRetailTraitSearchModel tracfoneOneRetailLocation) {
        List<Object[]> brandMappings;
        if (!StringUtils.isNullOrEmpty(tracfoneOneRetailLocation.getBrand())) {
            brandMappings = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_GET_BRAND_MAPPINGS_FOR_PARENT)
                    .setParameter(1, tracfoneOneRetailLocation.getBrand())
                    .getResultList();
        } else {
            brandMappings = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_GET_ALL_BRAND_MAPPINGS_FOR_PARENT)
                    .setParameter(1, tracfoneOneRetailLocation.getParentId())
                    .getResultList();
        }

        Map<String, String> carrierTechDetailsMap = new LinkedHashMap<>();
        // To get keys as carrier detail id and value as the techs to show like ATT_WIRELESS_2G which is carrier_tech
        for (Object[] brandMapping : brandMappings) {
            String carrierTech = brandMapping[1] + "_" + brandMapping[2];
            // SQL does not work unless I remove the spaces and the hyphens in the carrier names
            carrierTechDetailsMap.put(String.valueOf(brandMapping[0]),
                    carrierTech.replace(" ", "_").replace("T-MOBILE", "TMOBILE"));
        }
        return carrierTechDetailsMap;
    }


    @Override
    public TFOneGeneralResponse countStores(String parentId, int userId) throws TracfoneOneException {
        List<Object[]> totalCount = new ArrayList<>(1);
        try {

            totalCount = cRtlTpNormFacade.getEntityManager().
                    createNativeQuery(TRACFONE_COUNT_LOCATIONS).
                    setParameter(1, parentId).getResultList();

        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Count Stores ", parentId, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, String.valueOf(totalCount.get(0)));
    }

}
