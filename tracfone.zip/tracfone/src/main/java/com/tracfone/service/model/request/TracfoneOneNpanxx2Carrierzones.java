package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

public class TracfoneOneNpanxx2Carrierzones {
    @Size(min=1, message = "NPA Codes cannot be null")
    @Size(max = 5, message = "NPA cannot have more than 5 characters")
    private String npa;
    @Size(min=1, message = "NXX Codes cannot be null")
    @Size(max = 5, message = "NXX cannot have more than 5 characters")
    private String nxx;
    @Size(min=1, message = "CARRIERID Codes cannot be null")
    @Digits(integer = 126, fraction = 100, message = "CARRIERID must be a number with Integer not more than 126 Digits")
    private String carrierId;
    @Size(max = 255, message = "CARRIER_NAME cannot have more than 255 characters")
    private String carrierName;
    @Digits(integer = 126, fraction = 100, message = "LEAD_TIME must be a number with Integer not more than 126 Digits")
    private String leadTime;
    @Digits(integer = 126, fraction = 100, message = "LEAD_TIME must be a number with Integer not more than 126 Digits")
    private String targetLevel;
    @Size(min=1, message = "RATECENTER Codes cannot be null")
    @Size(max = 15, message = "RATECENTER cannot have more than 15 characters")
    private String rateCenter;
    @Size(min=1, message = "STATE Codes cannot be null")
    @Size(max = 4, message = "STATE cannot have more than 4 characters")
    private String state;
    @Size(max = 255, message = "CARRIER_ID_DESCRIPTION cannot have more than 255 characters")
    private String carrierIdDescription;
    @Size(min=1, message = "ZONE Codes cannot be null")
    @Size(max = 100, message = "ZONE cannot have more than 100 characters")
    private String zone;
    @Size(max = 50, message = "COUNTY cannot have more than 50 characters")
    private String county;
    @Digits(integer = 126, fraction = 100, message = "Market Id must be a number with Integer not more than 126 Digits")
    private String marketId;
    @Size(max = 33, message = "MRKT_AREA cannot have more than 33 characters")
    private String mrktArea;
    @Size(min=1, message = "SID Codes cannot be null")
    @Size(max = 10, message = "SID cannot have more than 10 characters")
    private String sid;
    @Size(max = 20, message = "TECHNOLOGY cannot have more than 20 characters")
    private String technology;
    @Digits(integer = 38, fraction = 0, message = "Frequency1 must be a number")
    private String frequency1;
    @Digits(integer = 38, fraction = 0, message = "Frequency2 must be a number")
    private String frequency2;
    @Size(max = 4, message = "BTA_MKT_NUMBER cannot have more than 4 characters")
    private String btaMktNumber;
    @Size(max = 100, message = "BTA_MKT_NAME cannot have more than 100 characters")
    private String btaMktName;
    @Size(max = 20, message = "GSM_TECH cannot have more than 20 characters")
    private String gsmTech;
    @Size(max = 20, message = "CDMA_TECH cannot have more than 20 characters")
    private String cdmaTech;
    @Size(max = 20, message = "TDMA_TECH cannot have more than 20 characters")
    private String tdmaTech;
    @Size(max = 5, message = "MNC cannot have more than 5 characters")
    private String mnc;
    private String dbEnv;
    @Size(max = 5, message = "NPA cannot have more than 5 characters")
    private String oldNpa;
    @Size(max = 5, message = "NXX cannot have more than 5 characters")
    private String oldNxx;
    @Size(max = 126, message = "CARRIERID cannot have more than 126 characters")
    private String oldCarrierId;
    @Size(max = 4, message = "STATE cannot have more than 4 characters")
    private String oldState;
    @Size(max = 10, message = "SID cannot have more than 10 characters")
    private String oldSid;
    @Size(max = 100, message = "ZONE cannot have more than 100 characters")
    private String oldZone;
    @Size(max = 15, message = "RATECENTER cannot have more than 15 characters")
    private  String oldRateCenter;
    private boolean checkDuplicate;
    private TracfoneonePaginationSearch paginationSearch;

    public String getNpa() {
        return npa;
    }

    public void setNpa(String npa) {
        this.npa = npa;
    }

    public String getNxx() {
        return nxx;
    }

    public void setNxx(String nxx) {
        this.nxx = nxx;
    }

    public String getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(String carrierId) {
        this.carrierId = carrierId;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getLeadTime() {
        return leadTime;
    }

    public void setLeadTime(String leadTime) {
        this.leadTime = leadTime;
    }

    public String getTargetLevel() {
        return targetLevel;
    }

    public void setTargetLevel(String targetLevel) {
        this.targetLevel = targetLevel;
    }

    public String getRateCenter() {
        return rateCenter;
    }

    public void setRateCenter(String rateCenter) {
        this.rateCenter = rateCenter;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCarrierIdDescription() {
        return carrierIdDescription;
    }

    public void setCarrierIdDescription(String carrierIdDescription) {
        this.carrierIdDescription = carrierIdDescription;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getMarketId() {
        return marketId;
    }

    public void setMarketId(String marketId) {
        this.marketId = marketId;
    }

    public String getMrktArea() {
        return mrktArea;
    }

    public void setMrktArea(String mrktArea) {
        this.mrktArea = mrktArea;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getTechnology() {
        return technology;
    }

    public void setTechnology(String technology) {
        this.technology = technology;
    }

    public String getFrequency1() {
        return frequency1;
    }

    public void setFrequency1(String frequency1) {
        this.frequency1 = frequency1;
    }

    public String getFrequency2() {
        return frequency2;
    }

    public void setFrequency2(String frequency2) {
        this.frequency2 = frequency2;
    }

    public String getBtaMktNumber() {
        return btaMktNumber;
    }

    public void setBtaMktNumber(String btaMktNumber) {
        this.btaMktNumber = btaMktNumber;
    }

    public String getBtaMktName() {
        return btaMktName;
    }

    public void setBtaMktName(String btaMktName) {
        this.btaMktName = btaMktName;
    }

    public String getGsmTech() {
        return gsmTech;
    }

    public void setGsmTech(String gsmTech) {
        this.gsmTech = gsmTech;
    }

    public String getCdmaTech() {
        return cdmaTech;
    }

    public void setCdmaTech(String cdmaTech) {
        this.cdmaTech = cdmaTech;
    }

    public String getTdmaTech() {
        return tdmaTech;
    }

    public void setTdmaTech(String tdmaTech) {
        this.tdmaTech = tdmaTech;
    }

    public String getMnc() {
        return mnc;
    }

    public void setMnc(String mnc) {
        this.mnc = mnc;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getOldNpa() {
        return oldNpa;
    }

    public void setOldNpa(String oldNpa) {
        this.oldNpa = oldNpa;
    }

    public String getOldNxx() {
        return oldNxx;
    }

    public void setOldNxx(String oldNxx) {
        this.oldNxx = oldNxx;
    }

    public String getOldCarrierId() {
        return oldCarrierId;
    }

    public void setOldCarrierId(String oldCarrierId) {
        this.oldCarrierId = oldCarrierId;
    }

    public String getOldState() {
        return oldState;
    }

    public void setOldState(String oldState) {
        this.oldState = oldState;
    }

    public String getOldSid() {
        return oldSid;
    }

    public void setOldSid(String oldSid) {
        this.oldSid = oldSid;
    }

    public String getOldZone() {
        return oldZone;
    }

    public void setOldZone(String oldZone) {
        this.oldZone = oldZone;
    }

    public String getOldRateCenter() {
        return oldRateCenter;
    }

    public void setOldRateCenter(String oldRateCenter) {
        this.oldRateCenter = oldRateCenter;
    }

    public boolean isCheckDuplicate() {
        return checkDuplicate;
    }

    public void setCheckDuplicate(boolean checkDuplicate) {
        this.checkDuplicate = checkDuplicate;
    }

    public TracfoneonePaginationSearch getPaginationSearch() {
        return paginationSearch;
    }

    public void setPaginationSearch(TracfoneonePaginationSearch paginationSearch) {
        this.paginationSearch = paginationSearch;
    }

    @Override
    public String toString() {
        return "TracfoneOneNpanxx2Carrierzones{" +
                "npa='" + npa + '\'' +
                ", nxx='" + nxx + '\'' +
                ", carrierId='" + carrierId + '\'' +
                ", carrierName='" + carrierName + '\'' +
                ", leadTime='" + leadTime + '\'' +
                ", targetLevel='" + targetLevel + '\'' +
                ", rateCenter='" + rateCenter + '\'' +
                ", state='" + state + '\'' +
                ", carrierIdDescription='" + carrierIdDescription + '\'' +
                ", zone='" + zone + '\'' +
                ", county='" + county + '\'' +
                ", marketId='" + marketId + '\'' +
                ", mrktArea='" + mrktArea + '\'' +
                ", sid='" + sid + '\'' +
                ", technology='" + technology + '\'' +
                ", frequency1='" + frequency1 + '\'' +
                ", frequency2='" + frequency2 + '\'' +
                ", btaMktNumber='" + btaMktNumber + '\'' +
                ", btaMktName='" + btaMktName + '\'' +
                ", gsmTech='" + gsmTech + '\'' +
                ", cdmaTech='" + cdmaTech + '\'' +
                ", tdmaTech='" + tdmaTech + '\'' +
                ", mnc='" + mnc + '\'' +
                ", dbEnv='" + dbEnv + '\'' +
                ", oldNpa='" + oldNpa + '\'' +
                ", oldNxx='" + oldNxx + '\'' +
                ", oldCarrierId='" + oldCarrierId + '\'' +
                ", oldState='" + oldState + '\'' +
                ", oldSid='" + oldSid + '\'' +
                ", oldZone='" + oldZone + '\'' +
                ", oldRateCenter='" + oldRateCenter + '\'' +
                ", checkDuplicate=" + checkDuplicate +
                '}';
    }
}
