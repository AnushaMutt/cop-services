package com.tracfone.service.model.retail.response;

public class TFOneRetailParent {
    private String objId;
    private String status;
    private String retailer;
    private String secUserId;
    private String insertDate;
    private String updateDate;
    private String lastTraitRunDate;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRetailer() {
        return retailer;
    }

    public void setRetailer(String retailer) {
        this.retailer = retailer;
    }

    public String getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(String secUserId) {
        this.secUserId = secUserId;
    }

    public String getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(String insertDate) {
        this.insertDate = insertDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getLastTraitRunDate() {
        return lastTraitRunDate;
    }

    public void setLastTraitRunDate(String lastTraitRunDate) {
        this.lastTraitRunDate = lastTraitRunDate;
    }

    @Override
    public String toString() {
        return "TFOneRetailParent{" +
                "objId='" + objId + '\'' +
                ", status='" + status + '\'' +
                ", retailer='" + retailer + '\'' +
                ", secUserId='" + secUserId + '\'' +
                ", insertDate='" + insertDate + '\'' +
                ", updateDate='" + updateDate + '\'' +
                ", lastTraitRunDate='" + lastTraitRunDate + '\'' +
                '}';
    }
}
