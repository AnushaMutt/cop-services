package com.tracfone.service.model.retail.response;

public class TFOneRetailLocation {
    private String objId;
    private String masterId;
    private String parentId;
    private String storeName;
    private String storeNum;
    private String zip;
    private String brand;
    private String radius;
    private String state;
    private String lastUpdateDate;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getMasterId() {
        return masterId;
    }

    public void setMasterId(String masterId) {
        this.masterId = masterId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getStoreNum() {
        return storeNum;
    }

    public void setStoreNum(String storeNum) {
        this.storeNum = storeNum;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getRadius() {
        return radius;
    }

    public void setRadius(String radius) {
        this.radius = radius;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    @Override
    public String toString() {
        return "TFOneRetailLocation{" +
                "objId='" + objId + '\'' +
                ", masterId='" + masterId + '\'' +
                ", parentId='" + parentId + '\'' +
                ", storeName='" + storeName + '\'' +
                ", storeNum='" + storeNum + '\'' +
                ", zip='" + zip + '\'' +
                ", brand='" + brand + '\'' +
                ", radius='" + radius + '\'' +
                ", state='" + state + '\'' +
                ", lastUpdateDate='" + lastUpdateDate + '\'' +
                '}';
    }
}
