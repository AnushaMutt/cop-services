package com.tracfone.service.schedulers;

import com.google.gson.Gson;
import com.tracfone.service.model.event.TracfoneOneReportRequest;
import com.tracfone.service.model.report.TFOneReportMonitor;
import com.tracfone.service.report.workers.MonitorCarrierWorkerBean;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Singleton
public class MonitorReportJob {
    @EJB
    MonitorCarrierWorkerBean monitorCarrierWorkerBean;

    @Inject
    private Event<TracfoneOneReportRequest> tracfoneOneConstantReportEvent;

    private static final Logger LOGGER = LogManager.getLogger(MonitorReportJob.class);

//    @Schedule(second = "*/50", minute = "*", hour = "*", persistent = false)
    public void runMonitorReport() {
        try {
            List<TFOneReportMonitor> carrierMonitorReport = new ArrayList<>();
//            List<TFOneReportMonitor> carrierMonitorReport = monitorCarrierWorkerBean.runMonitorReport();
            if (!carrierMonitorReport.isEmpty()) {
                Gson gson = new Gson();
                TracfoneOneReportRequest reportRequest = new TracfoneOneReportRequest();
                reportRequest.setJsonResponse(gson.toJson(carrierMonitorReport));
                reportRequest.setReportName(TracfoneOneConstantReport.TRACFONE_REPORTNAME_MONITOR);
                tracfoneOneConstantReportEvent.fire(reportRequest);
            } else {
                LOGGER.info("MonitorCarrierWorkerBean returned an empty response.");
            }

        } catch (Exception ex) {
            LOGGER.error("Monitor report storing error. EX: " + ex.getMessage());
        }
    }
}
