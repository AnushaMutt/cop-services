/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author Shireen Fathima
 */
public class TracfoneOneSearchBucketModel {
    
    private String dbEnv;
    private List<String> profileIds;
    private List<String> ratePlanNames;
    private List<String> servicePlanIds;
    private String childPlanId;
    private String oldProfileId;

    public TracfoneOneSearchBucketModel() {
        profileIds = new ArrayList<>();
        ratePlanNames = new ArrayList<>();
        servicePlanIds = new ArrayList<>();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public List<String> getRatePlanNames() {
        return ratePlanNames;
    }

    public void setRatePlanNames(List<String> ratePlanNames) {
        this.ratePlanNames = ratePlanNames;
    }

    public List<String> getServicePlanIds() {
        return servicePlanIds;
    }

    public void setServicePlanIds(List<String> servicePlanIds) {
        this.servicePlanIds = servicePlanIds;
    }

    public List<String> getProfileIds() {
        return profileIds;
    }

    public void setProfileIds(List<String> profileIds) {
        this.profileIds = profileIds;
    }

    public String getChildPlanId() {
        return childPlanId;
    }

    public void setChildPlanId(String childPlanId) {
        this.childPlanId = childPlanId;
    }

    public String getOldProfileId() {
        return oldProfileId;
    }

    public void setOldProfileId(String oldProfileId) {
        this.oldProfileId = oldProfileId;
    }

    @Override
    public String toString() {
        return "TracfoneOneSearchBucketModel{" +
                "dbEnv='" + dbEnv + '\'' +
                ", profileIds=" + profileIds +
                ", ratePlanNames=" + ratePlanNames +
                ", servicePlanIds=" + servicePlanIds +
                ", childPlanId='" + childPlanId + '\'' +
                ", oldProfileId='" + oldProfileId + '\'' +
                '}';
    }
}
