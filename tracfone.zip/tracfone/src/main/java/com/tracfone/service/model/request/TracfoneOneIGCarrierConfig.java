package com.tracfone.service.model.request;

import javax.validation.constraints.Size;
import java.util.List;

/**
 *
 * @author Gaurav.Sharma
 */
public class TracfoneOneIGCarrierConfig {

    private String dbEnv;
    private String configId;
    @Size(max = 20, message = "Carrier cannot have more than 20 characters")
    private String carrier;
    @Size(max = 100, message = "Prop Name cannot have more than 100 characters")
    private String propName;
    @Size(max = 10, message = "Prop Type cannot have more than 10 characters")
    private String propType;
    private TracfoneOneIGCarrierConfigDetails igCarrierDetails;
    private String description;
    private List<TracfoneOneIGCarrierConfigDetails> igCarrierDetailsArray;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getConfigId() {
        return configId;
    }

    public void setConfigId(String configId) {
        this.configId = configId;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getPropName() {
        return propName;
    }

    public void setPropName(String propName) {
        this.propName = propName;
    }

    public String getPropType() {
        return propType;
    }

    public void setPropType(String propType) {
        this.propType = propType;
    }

    public TracfoneOneIGCarrierConfigDetails getIgCarrierDetails() {
        return igCarrierDetails;
    }

    public void setIgCarrierDetails(TracfoneOneIGCarrierConfigDetails igCarrierDetails) {
        this.igCarrierDetails = igCarrierDetails;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<TracfoneOneIGCarrierConfigDetails> getIgCarrierDetailsArray() {
        return igCarrierDetailsArray;
    }

    public void setIgCarrierDetailsArray(List<TracfoneOneIGCarrierConfigDetails> igCarrierDetailsArray) {
        this.igCarrierDetailsArray = igCarrierDetailsArray;
    }
}
