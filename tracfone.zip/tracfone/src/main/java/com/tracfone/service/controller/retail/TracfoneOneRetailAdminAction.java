package com.tracfone.service.controller.retail;

import com.google.gson.Gson;
import com.mysql.jdbc.StringUtils;
import com.tracfone.ejb.entity.retail.CRtlBrand;
import com.tracfone.ejb.entity.retail.CRtlCarrier;
import com.tracfone.ejb.entity.retail.CRtlCarrierDtl;
import com.tracfone.ejb.entity.retail.CRtlCarrierPref;
import com.tracfone.ejb.entity.retail.CRtlCarrierPrefGrp;
import com.tracfone.ejb.entity.retail.CRtlMaster;
import com.tracfone.ejb.entity.retail.CRtlParent;
import com.tracfone.ejb.entity.retail.CRtlParentRule;
import com.tracfone.ejb.entity.retail.CRtlTech;
import com.tracfone.ejb.entity.retail.CRtlTpNorm;
import com.tracfone.ejb.entity.retail.CRtlTraitLogicRule;
import com.tracfone.ejb.entity.retail.session.CRtlBrandFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlCarrierDtlFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlCarrierFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlCarrierPrefFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlCarrierPrefGrpFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlMasterFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlParentFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlParentRuleFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlTechFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlTpNormFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlTraitLogicRuleFacadeLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneJobTask;
import com.tracfone.service.model.retail.request.TracfoneOneRetailBrand;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrier;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierDetail;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierPrefDetail;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierPrefGroup;
import com.tracfone.service.model.retail.request.TracfoneOneRetailLocation;
import com.tracfone.service.model.retail.request.TracfoneOneRetailMaster;
import com.tracfone.service.model.retail.request.TracfoneOneRetailParent;
import com.tracfone.service.model.retail.request.TracfoneOneRetailParentRule;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTech;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTpAdminSearchModel;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTraitRunner;
import com.tracfone.service.model.retail.request.TracfoneOneTraitLogicRule;
import com.tracfone.service.model.retail.response.TFOneRetailBrand;
import com.tracfone.service.model.retail.response.TFOneRetailCarrier;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierDetail;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierPrefDetail;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierPrefGroup;
import com.tracfone.service.model.retail.response.TFOneRetailMaster;
import com.tracfone.service.model.retail.response.TFOneRetailParent;
import com.tracfone.service.model.retail.response.TFOneRetailParentRule;
import com.tracfone.service.model.retail.response.TFOneRetailTech;
import com.tracfone.service.model.retail.response.TFOneRetailTpAdminSearchResults;
import com.tracfone.service.model.retail.response.TFOneRetailTpNorm;
import com.tracfone.service.model.retail.response.TFOneTraitLogicRule;
import com.tracfone.service.util.TracfoneOneConstantRetailStore;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;

@Stateless
public class TracfoneOneRetailAdminAction implements TracfoneOneRetailAdminActionLocal, TracfoneOneConstantRetailStore {

    private static final String PARENT_UPDATE = "_PARENT_UPDATE";
    private static final String C_RTL_STORE_SP_N = "C_RTL_STORE_SP_N";
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneRetailAdminAction.class);

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @EJB
    CRtlCarrierFacadeLocal cRtlCarrierFacade;

    @EJB
    CRtlBrandFacadeLocal cRtlBrandFacade;

    @EJB
    CRtlTechFacadeLocal cRtlTechFacade;

    @EJB
    CRtlCarrierDtlFacadeLocal cRtlCarrierDtlFacade;

    @EJB
    CRtlTraitLogicRuleFacadeLocal cRtlTraitLogicRuleFacade;

    @EJB
    CRtlCarrierPrefGrpFacadeLocal cRtlCarrierPrefGrpFacade;

    @EJB
    CRtlCarrierPrefFacadeLocal cRtlCarrierPrefFacade;

    @EJB
    CRtlParentFacadeLocal cRtlParentFacade;

    @EJB
    CRtlMasterFacadeLocal cRtlMasterFacade;

    @EJB
    CRtlParentRuleFacadeLocal cRtlParentRuleFacade;

    @EJB
    CRtlTpNormFacadeLocal cRtlTpNormFacade;

    @Override
    public List<TFOneRetailCarrier> getCarriers() throws TracfoneOneException {
        List<TFOneRetailCarrier> tfCRtlCarriers = new ArrayList<>();
        try {
            List<CRtlCarrier> cRtlCarriers = cRtlCarrierFacade.findAll();
            for (CRtlCarrier cRtlCarrier : cRtlCarriers) {
                TFOneRetailCarrier tfOneCRtlCarrier = new TFOneRetailCarrier();
                tfOneCRtlCarrier.setCarrier(cRtlCarrier.getCarrier());
                tfOneCRtlCarrier.setCarrierLong(cRtlCarrier.getCarrierLong());
                tfOneCRtlCarrier.setInsertDate(formatDate(cRtlCarrier.getInsertDate()));
                tfOneCRtlCarrier.setObjId(String.valueOf(cRtlCarrier.getObjid()));
                tfOneCRtlCarrier.setSecUserId(cRtlCarrier.getSecUserId());
                tfOneCRtlCarrier.setStatus(cRtlCarrier.getStatus());
                tfOneCRtlCarrier.setUpdateDate(formatDate(cRtlCarrier.getUpdateDate()));
                tfCRtlCarriers.add(tfOneCRtlCarrier);
            }
            Collections.sort(tfCRtlCarriers, (c1, c2) -> c1.getCarrier().compareToIgnoreCase(c2.getCarrier()));
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ALL_CARRIERS, TRACFONE_GET_ALL_CARRIERS_MESSAGE, ex);
        }
        return tfCRtlCarriers;
    }

    @Override
    public TFOneGeneralResponse insertCarrier(TracfoneOneRetailCarrier tfCRtlCarrier, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        CRtlCarrier cRtlCarrier = new CRtlCarrier();
        cRtlCarrier.setCarrier(tfCRtlCarrier.getCarrier());
        cRtlCarrier.setCarrierLong(tfCRtlCarrier.getCarrierLong());
        cRtlCarrier.setInsertDate(new Date());
        // TODO - Look into this when we integrate with COP Users
        cRtlCarrier.setSecUserId("1");
        cRtlCarrier.setStatus(tfCRtlCarrier.getStatus());

        try {
            cRtlCarrierFacade.create(cRtlCarrier);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Retail Carrier", gson.toJson(tfCRtlCarrier), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_CARRIER_CREATE_SUCCESS);
    }


    @Override
    public List<TFOneRetailBrand> getBrands() throws TracfoneOneException {
        List<TFOneRetailBrand> tfOneCRtlBrands = new ArrayList<>();
        try {
            List<CRtlBrand> cRtlBrands = cRtlBrandFacade.findAll();
            for (CRtlBrand cRtlBrand : cRtlBrands) {
                TFOneRetailBrand tfCRtlBrand = new TFOneRetailBrand();
                tfCRtlBrand.setBrand(cRtlBrand.getBrand());
                tfCRtlBrand.setBrandLong(cRtlBrand.getBrandLong());
                tfCRtlBrand.setcRtlTraitLogicRuleId(cRtlBrand.getcRtlTraitLogicRuleId());
                tfCRtlBrand.setInsertDate(formatDate(cRtlBrand.getInsertDate()));
                tfCRtlBrand.setObjId(String.valueOf(cRtlBrand.getObjid()));
                tfCRtlBrand.setOneSecUserId(cRtlBrand.getSecUserId());
                tfCRtlBrand.setStatus(cRtlBrand.getStatus());
                tfCRtlBrand.setUpdateDate(formatDate(cRtlBrand.getUpdateDate()));
                tfOneCRtlBrands.add(tfCRtlBrand);
            }
            Collections.sort(tfOneCRtlBrands, (c1, c2) -> c1.getBrand().compareToIgnoreCase(c2.getBrand()));
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ALL_BRANDS, TRACFONE_GET_ALL_BRANDS_MESSAGE, ex);
        }
        return tfOneCRtlBrands;
    }

    @Override
    public TFOneGeneralResponse insertBrand(TracfoneOneRetailBrand tfOneCRtlBrand, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        CRtlBrand cRtlBrand = new CRtlBrand();
        cRtlBrand.setBrand(tfOneCRtlBrand.getBrand());
        cRtlBrand.setBrandLong(tfOneCRtlBrand.getBrandLong());
        cRtlBrand.setcRtlTraitLogicRuleId(tfOneCRtlBrand.getTraitLogicRuleId());
        cRtlBrand.setInsertDate(new Date());
        // TODO - Look into this when we integrate with COP Users
        cRtlBrand.setSecUserId("1");
        cRtlBrand.setStatus(tfOneCRtlBrand.getStatus());

        try {
            cRtlBrandFacade.create(cRtlBrand);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Retail Brand", gson.toJson(tfOneCRtlBrand), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_BRAND_CREATE_SUCCESS);
    }

    @Override
    public List<TFOneRetailTech> getTechs() throws TracfoneOneException {
        List<TFOneRetailTech> tfOneCRtlTechs = new ArrayList<>();
        try {
            List<CRtlTech> cRtlTeches = cRtlTechFacade.findAll();
            for (CRtlTech cRtlTeche : cRtlTeches) {
                TFOneRetailTech tfCRtlTech = new TFOneRetailTech();
                tfCRtlTech.setInsertDate(formatDate(cRtlTeche.getInsertDate()));
                tfCRtlTech.setObjId(cRtlTeche.getObjid().toString());
                tfCRtlTech.setSecUserId(cRtlTeche.getSecUserId());
                tfCRtlTech.setStatus(cRtlTeche.getStatus());
                tfCRtlTech.setTech(cRtlTeche.getTech());
                tfCRtlTech.setTechLong(cRtlTeche.getTechLong());
                tfCRtlTech.setUpdateDate(formatDate(cRtlTeche.getUpdateDate()));
                tfOneCRtlTechs.add(tfCRtlTech);
            }
            Collections.sort(tfOneCRtlTechs, (c1, c2) -> c1.getTech().compareToIgnoreCase(c2.getTech()));
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ALL_TECHS, TRACFONE_GET_ALL_TECHS_MESSAGE, ex);
        }
        return tfOneCRtlTechs;
    }

    @Override
    public TFOneGeneralResponse insertTech(TracfoneOneRetailTech tfOneCRtlTech, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        CRtlTech cRtlTech = new CRtlTech();
        cRtlTech.setInsertDate(new Date());
        // TODO - Look into this when we integrate with COP Users
        cRtlTech.setSecUserId("1");
        cRtlTech.setStatus(tfOneCRtlTech.getStatus());
        cRtlTech.setTech(tfOneCRtlTech.getTech());
        cRtlTech.setTechLong(tfOneCRtlTech.getTechLong());

        try {
            cRtlTechFacade.create(cRtlTech);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Retail Tech", gson.toJson(tfOneCRtlTech), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_TECH_CREATE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse insertCarrierDetail(TracfoneOneRetailCarrierDetail tfOneCrtlCarrierDtl, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        CRtlCarrierDtl cRtlCarrierDtl = new CRtlCarrierDtl();
        cRtlCarrierDtl.setcRtlBrandId(tfOneCrtlCarrierDtl.getCdtl2Brand());
        cRtlCarrierDtl.setcRtlCarrierId(tfOneCrtlCarrierDtl.getCdtl2Carrier());
        cRtlCarrierDtl.setcRtlTechId(tfOneCrtlCarrierDtl.getCdtl2Tech());
        cRtlCarrierDtl.setInsertDate(new Date());
        // TODO - Look into this when we integrate with COP Users
        cRtlCarrierDtl.setSecUserId("1");
        cRtlCarrierDtl.setStatus(tfOneCrtlCarrierDtl.getStatus());

        try {
            cRtlCarrierDtlFacade.create(cRtlCarrierDtl);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Retail Carrier Detail", gson.toJson(tfOneCrtlCarrierDtl), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_CARRIER_DETAIL_CREATE_SUCCESS);
    }

    @Override
    public List<TFOneRetailCarrierDetail> getCarrierDetails() throws TracfoneOneException {
        List<TFOneRetailCarrierDetail> carrierDtls = new ArrayList<>();
        try {
            List<CRtlCarrierDtl> cRtlCarrierDtls = cRtlCarrierDtlFacade.findAll();
            for (CRtlCarrierDtl cRtlCarrierDtl : cRtlCarrierDtls) {
                TFOneRetailCarrierDetail carrierDtl = new TFOneRetailCarrierDetail();
                carrierDtl.setObjId(String.valueOf(cRtlCarrierDtl.getObjid()));
                carrierDtl.setStatus(cRtlCarrierDtl.getStatus());
                carrierDtl.setInsertDate(formatDate(cRtlCarrierDtl.getInsertDate()));
                carrierDtl.setUpdateDate(formatDate(cRtlCarrierDtl.getUpdateDate()));
                carrierDtl.setCdtl2Carrier(cRtlCarrierDtl.getcRtlCarrierId());
                carrierDtl.setCdtl2Brand(cRtlCarrierDtl.getcRtlBrandId());
                carrierDtl.setCdtl2Tech(cRtlCarrierDtl.getcRtlTechId());
                carrierDtls.add(carrierDtl);
            }
            Collections.sort(carrierDtls, (c1, c2) -> c1.getCdtl2Brand().compareToIgnoreCase(c2.getCdtl2Brand()));
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ALL_CARRIER_DETAILS, TRACFONE_GET_ALL_CARRIER_DETAILS_MESSAGE, ex);
        }
        return carrierDtls;
    }

    @Override
    public List<TFOneRetailCarrierDetail> getAllCarrierDetails() throws TracfoneOneException {
        List<TFOneRetailCarrierDetail> carrierDtls = new ArrayList<>();
        try {
            List<Object[]> cRtlCarrierDtls = cRtlCarrierDtlFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_GET_CARRIER_DETAILS)
                    .getResultList();
            for (Object[] cRtlCarrierDtl : cRtlCarrierDtls) {
                carrierDtls.add(getTfOneRetailCarrierDetail(cRtlCarrierDtl));
            }
            Collections.sort(carrierDtls, (c1, c2) -> c1.getCdtl2Brand().compareToIgnoreCase(c2.getCdtl2Brand()));
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ALL_CARRIER_DETAILS, TRACFONE_GET_ALL_CARRIER_DETAILS_MESSAGE, ex);
        }
        return carrierDtls;
    }

    @Override
    public void insertTpNorm(TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel, int userId) {
        Gson gson = new Gson();
        String zip = retailTpAdminSearchModel.getZipCodes();
        String carrierDetailId = retailTpAdminSearchModel.getCarrierDetails();
        try {
            // check if this combination already exists

            List<CRtlTpNorm> duplicate = cRtlTpNormFacade.findByZipAndCarrierDetail(zip, getBigDecimalValue(carrierDetailId));
            LOGGER.info("duplicate found? " + duplicate + " size " + duplicate.size());
            if (duplicate.isEmpty()) {
                CRtlTpNorm cRtlTpNorm = new CRtlTpNorm();
                cRtlTpNorm.setCoverage(retailTpAdminSearchModel.getCoverage());
                cRtlTpNorm.setTp2Zip(zip);
                cRtlTpNorm.setTp2CarrierDtl(getBigDecimalValue(carrierDetailId));
                cRtlTpNorm.setRank(BigDecimal.valueOf(0));
                cRtlTpNorm.setState(BigDecimal.valueOf(0));
                if (retailTpAdminSearchModel.getCoverageNotes() != null) {
                    cRtlTpNorm.setCoverageNotes(getStringValue(retailTpAdminSearchModel.getCoverageNotes()));
                }
                cRtlTpNorm.setInsertDate(new Date());
                cRtlTpNorm.setEnv("PROD");
                // TODO - Look into this when we integrate with COP Users
                cRtlTpNorm.setSecUserId("1");
                LOGGER.info("Going to create a TP Norm for carrier detail id " + carrierDetailId + " zip code " + zip);
                cRtlTpNormFacade.create(cRtlTpNorm);
            }
        } catch (Exception e) {
            LOGGER.error("Error inserting TP NORM with carrier detail id " + carrierDetailId + " zip code " + zip, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Retail TP Norms ", gson.toJson(retailTpAdminSearchModel), null);
            tracfoneAuditEvent.fire(audit);
        }
    }

    @Override
    public TFOneGeneralResponse runTpNormTraits(int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            // update c_rtl_job_task START DATE
            cRtlTpNormFacade.getEntityManager().createNativeQuery(TRACFONE_UPDATE_RUN_START_DATE).executeUpdate();

            // Get zips to run traits on
            List<Object[]> zips = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_RUN_TRAITS_FOR_TP_NORM)
                    .getResultList();
            if (zips.isEmpty()) {
                return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_RUN_TP_NORM_TRAITS_SUCCESS);
            }

            LOGGER.info("Number of zip records retrieved from DB " + zips.size());
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                int count = 0;
                for (Object[] zip : zips) {
                    LOGGER.info("ZIP " + zip[0]);
                    LOGGER.info("ZIP DATE " + zip[1]);
                    // for each zip identify the location to run traits on
                    List<Object[]> traitRunners = cRtlTpNormFacade.getEntityManager().getEntityManagerFactory().createEntityManager()
                            .createNativeQuery(TRACFONE_GET_LOCATIONS_FROM_ZIP)
                            .setParameter(1, zip[1])
                            .setParameter(2, zip[0])
                            .getResultList();
                    if (traitRunners != null) {
                        LOGGER.info("Number of records retrieved from DB " + traitRunners.size());
                    }
                    //run traits
                    for (Object[] objects : traitRunners) {
                        TracfoneOneRetailTraitRunner traitRunner = new TracfoneOneRetailTraitRunner();
                        traitRunner.setParentId(String.valueOf(objects[0]));
                        traitRunner.setStoreName(String.valueOf(objects[1]));
                        traitRunner.setStoreNum(String.valueOf(objects[2]));
                        traitRunner.setZip(String.valueOf(objects[3]));
                        traitRunner.setRadius(String.valueOf(objects[4]));
                        LOGGER.info("Trait Runner retrieved for TP Norms" + traitRunner);
                        LOGGER.info(C_RTL_STORE_SP_CALL);

                        callStoredProcedure(C_RTL_STORE_SP_N, traitRunner);
                        LOGGER.info(C_RTL_STORE_SP_N_DONE + traitRunner + " and count " + count++);
                    }
                }
            });
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            // update c_rtl_job_task END DATE
            cRtlTpNormFacade.getEntityManager().createNativeQuery(TRACFONE_UPDATE_RUN_END_DATE).executeUpdate();
            TracfoneAudit audit = new TracfoneAudit(userId, "Ran Traits from TP Admin for date", gson.toJson(new Date()), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_RUN_TP_NORM_TRAITS_SUCCESS);
    }

    @Override
    public TFOneRetailTpAdminSearchResults getTpNormStats() throws TracfoneOneException {
        TFOneRetailTpAdminSearchResults tfOneRetailTpAdminSearchResults = new TFOneRetailTpAdminSearchResults();
        try {
            // Getting the last run date for Tp Norm Trait run
            Object date = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_GET_LAST_RUN_DATE)
                    .getSingleResult();
            LOGGER.info("Update Date - " + date);
            tfOneRetailTpAdminSearchResults.setLastUpdateDate(String.valueOf(date));

            // Getting the total number of records found in search
            Object count = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_GET_ZIPS_UPDATED_COUNT)
                    .getSingleResult();
            LOGGER.info("Zip Count - " + count);
            tfOneRetailTpAdminSearchResults.setUpdatedZipCount(String.valueOf(count));

            // Getting the total number of records found in search
            count = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_GET_STORES_UPDATED_COUNT)
                    .getSingleResult();
            LOGGER.info("Store Count - " + count);
            tfOneRetailTpAdminSearchResults.setUpdatedStoreCount(String.valueOf(count));
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        LOGGER.info("TP Norm Stats " + tfOneRetailTpAdminSearchResults);
        return tfOneRetailTpAdminSearchResults;
    }

    @Override
    public String getLastTraitRunDate(String parentId) throws TracfoneOneException {
        List<Object> lastTraitRunDate = new ArrayList<>();
        try {
            lastTraitRunDate = cRtlCarrierDtlFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_GET_LAST_TRAIT_RUN_DATE)
                    .setParameter(1, parentId + PARENT_UPDATE)
                    .getResultList();
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_LAST_TRAIT_RUN_DATE, TRACFONE_LAST_TRAIT_RUN_DATE_MESSAGE, ex);
        }
        return (lastTraitRunDate.isEmpty()) ? lastTraitRunDate.toString() : lastTraitRunDate.get(0).toString();
    }

    private TFOneRetailCarrierDetail getTfOneRetailCarrierDetail(Object[] cRtlCarrierDtl) {
        TFOneRetailCarrierDetail carrierDtl = new TFOneRetailCarrierDetail();
        carrierDtl.setObjId(String.valueOf(cRtlCarrierDtl[0]));
        carrierDtl.setStatus(String.valueOf(cRtlCarrierDtl[1]));
        carrierDtl.setInsertDate(formatDate((Date) cRtlCarrierDtl[2]));
        carrierDtl.setUpdateDate(formatDate((Date) cRtlCarrierDtl[3]));
        carrierDtl.setCdtl2Carrier(String.valueOf(cRtlCarrierDtl[4]));
        carrierDtl.setCdtl2Brand(String.valueOf(cRtlCarrierDtl[5]));
        carrierDtl.setCdtl2Tech(String.valueOf(cRtlCarrierDtl[6]));
        return carrierDtl;
    }

    @Override
    public List<TFOneTraitLogicRule> getTraitLogicRules() throws TracfoneOneException {
        List<TFOneTraitLogicRule> tfOneTraitLogicRules = new ArrayList<>();
        try {
            List<CRtlTraitLogicRule> cRtlTraitLogicRules = cRtlTraitLogicRuleFacade.findAll();
            for (CRtlTraitLogicRule cRtlTraitLogicRule : cRtlTraitLogicRules) {
                TFOneTraitLogicRule tfOneTraitLogicRule = new TFOneTraitLogicRule();
                tfOneTraitLogicRule.setObjId(String.valueOf(cRtlTraitLogicRule.getObjid()));
                tfOneTraitLogicRule.setRuleName(cRtlTraitLogicRule.getRuleName());
                tfOneTraitLogicRule.setInnerGeo(cRtlTraitLogicRule.getInnerGeo() != null ? String.valueOf(cRtlTraitLogicRule.getInnerGeo()) : null);
                tfOneTraitLogicRule.setInnerPop(cRtlTraitLogicRule.getInnerPop() != null ? String.valueOf(cRtlTraitLogicRule.getInnerPop()) : null);
                tfOneTraitLogicRule.setInnerRadius(cRtlTraitLogicRule.getInnerRadius() != null ? String.valueOf(cRtlTraitLogicRule.getInnerRadius()) : null);
                tfOneTraitLogicRule.setOuterGeo(cRtlTraitLogicRule.getOuterGeo() != null ? String.valueOf(cRtlTraitLogicRule.getOuterGeo()) : null);
                tfOneTraitLogicRule.setOuterPop(cRtlTraitLogicRule.getOuterPop() != null ? String.valueOf(cRtlTraitLogicRule.getOuterPop()) : null);
                tfOneTraitLogicRule.setOuterRadius(cRtlTraitLogicRule.getOuterRadius() != null ? String.valueOf(cRtlTraitLogicRule.getOuterRadius()) : null);
                tfOneTraitLogicRule.setUseOuterPop(cRtlTraitLogicRule.getUseOuterPop() != null ? String.valueOf(cRtlTraitLogicRule.getUseOuterPop()) : null);
                tfOneTraitLogicRule.setPrefAllCarr(cRtlTraitLogicRule.getPrefAllCarr() != null ? String.valueOf(cRtlTraitLogicRule.getPrefAllCarr()) : null);
                tfOneTraitLogicRule.setRule2Logic(cRtlTraitLogicRule.getRule2Logic() != null ? String.valueOf(cRtlTraitLogicRule.getRule2Logic()) : null);
                tfOneTraitLogicRule.setRule2User(cRtlTraitLogicRule.getSecUserId() != null ? String.valueOf(cRtlTraitLogicRule.getSecUserId()) : null);
                tfOneTraitLogicRules.add(tfOneTraitLogicRule);
            }
            Collections.sort(tfOneTraitLogicRules, (c1, c2) -> c1.getRuleName().compareToIgnoreCase(c2.getRuleName()));
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ALL_TRAIT_LOGIC_RULES, TRACFONE_GET_ALL_TRAIT_LOGIC_RULES_MESSAGE, ex);
        }
        return tfOneTraitLogicRules;
    }

    @Override
    public List<TFOneRetailCarrierPrefGroup> getCarrierPrefGroups() throws TracfoneOneException {
        List<TFOneRetailCarrierPrefGroup> carrierPrefGroups = new ArrayList<>();
        try {
            List<CRtlCarrierPrefGrp> cRtlCarrierPrefGrps = cRtlCarrierPrefGrpFacade.findAll();
            for (CRtlCarrierPrefGrp cRtlCarrierPrefGrp : cRtlCarrierPrefGrps) {
                TFOneRetailCarrierPrefGroup carrierPrefGroup = new TFOneRetailCarrierPrefGroup();
                carrierPrefGroup.setSecUserId(String.valueOf(cRtlCarrierPrefGrp.getSecUserId()));
                carrierPrefGroup.setDescription(cRtlCarrierPrefGrp.getDescription());
                carrierPrefGroup.setBrand(String.valueOf(cRtlCarrierPrefGrp.getcPrefGrp2Brand()));
                carrierPrefGroup.setObjId(String.valueOf(cRtlCarrierPrefGrp.getObjid()));
                carrierPrefGroup.setStatus(cRtlCarrierPrefGrp.getStatus());
                carrierPrefGroup.setInsertDate(formatDate(cRtlCarrierPrefGrp.getInsertDate()));
                carrierPrefGroup.setUpdateDate(formatDate(cRtlCarrierPrefGrp.getUpdateDate()));
                carrierPrefGroups.add(carrierPrefGroup);
            }
            Collections.sort(carrierPrefGroups, (c1, c2) -> c1.getBrand().compareToIgnoreCase(c2.getBrand()));
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ALL_CARRIER_PREF_GROUPS, TRACFONE_GET_ALL_CARRIER_PREF_GROUPS_MESSAGE, ex);
        }
        return carrierPrefGroups;
    }

    @Override
    public List<TFOneRetailCarrierPrefDetail> getCarrierPrefDetails(String carrierPrefGroupId) throws TracfoneOneException {
        List<TFOneRetailCarrierPrefDetail> carrierPrefDetails = new ArrayList<>();
        try {
            List<Object[]> cRtlCarrierPrefs = cRtlCarrierPrefFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_GET_CARRIER_PREFS)
                    .setParameter(1, carrierPrefGroupId)
                    .getResultList();
            for (Object[] cRtlCarrierPref : cRtlCarrierPrefs) {
                TFOneRetailCarrierPrefDetail carrierPrefDetail = new TFOneRetailCarrierPrefDetail();
                carrierPrefDetail.setObjId(String.valueOf(cRtlCarrierPref[0]));
                carrierPrefDetail.setCarrierPrefGroupId(String.valueOf(cRtlCarrierPref[1]));
                carrierPrefDetail.setCarrierDetailId(String.valueOf(cRtlCarrierPref[2]));
                carrierPrefDetail.setRank(String.valueOf(cRtlCarrierPref[3]));
                carrierPrefDetail.setCarrier(String.valueOf(cRtlCarrierPref[4]));
                carrierPrefDetail.setBrand(String.valueOf(cRtlCarrierPref[5]));
                carrierPrefDetail.setTech(String.valueOf(cRtlCarrierPref[6]));
                carrierPrefDetails.add(carrierPrefDetail);
            }
            Collections.sort(carrierPrefDetails, (c1, c2) -> c1.getBrand().compareToIgnoreCase(c2.getBrand()));
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ALL_CARRIER_PREFS, TRACFONE_GET_ALL_CARRIER_PREFS_MESSAGE, ex);
        }
        return carrierPrefDetails;
    }

    @Override
    public TFOneGeneralResponse insertCarrierPrefGroup(TracfoneOneRetailCarrierPrefGroup tracfoneOneRetailCarrierPrefGroup, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        CRtlCarrierPrefGrp cRtlCarrierPrefGrp = new CRtlCarrierPrefGrp();
        cRtlCarrierPrefGrp.setDescription(tracfoneOneRetailCarrierPrefGroup.getDescription());
        cRtlCarrierPrefGrp.setcPrefGrp2Brand(BigDecimal.valueOf(Integer.valueOf(tracfoneOneRetailCarrierPrefGroup.getBrand())));
        cRtlCarrierPrefGrp.setInsertDate(new Date());
        // TODO - Look into this when we integrate with COP Users
        cRtlCarrierPrefGrp.setSecUserId(BigDecimal.valueOf(1));
        cRtlCarrierPrefGrp.setStatus(tracfoneOneRetailCarrierPrefGroup.getStatus());

        try {
            cRtlCarrierPrefGrpFacade.create(cRtlCarrierPrefGrp);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Retail Carrier Pref Group",
                    gson.toJson(tracfoneOneRetailCarrierPrefGroup), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_CARRIER_PREF_GROUP_CREATE_SUCCESS);
    }

    @Override
    public List<TFOneRetailCarrierDetail> getCarrierDetailsByBrand(String brandId) throws TracfoneOneException {
        List<TFOneRetailCarrierDetail> carrierDtls = new ArrayList<>();
        try {
            List<Object[]> cRtlCarrierDtls = cRtlCarrierDtlFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_GET_CARRIER_DETAILS_BY_BRAND)
                    .setParameter(1, brandId)
                    .getResultList();
            for (Object[] cRtlCarrierDtl : cRtlCarrierDtls) {
                carrierDtls.add(getTfOneRetailCarrierDetail(cRtlCarrierDtl));
            }
            Collections.sort(carrierDtls, (c1, c2) -> c1.getCdtl2Brand().compareToIgnoreCase(c2.getCdtl2Brand()));
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ALL_CARRIER_DETAILS, TRACFONE_GET_ALL_CARRIER_DETAILS_MESSAGE, ex);
        }
        return carrierDtls;
    }

    @Override
    public TFOneGeneralResponse updateCarrier(TracfoneOneRetailCarrier tracfoneOneRetailCarrier, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        try {
            for (String objId : tracfoneOneRetailCarrier.getObjId().split(",")) {
                CRtlCarrier carrier = cRtlCarrierFacade.find(BigDecimal.valueOf(Integer.valueOf(objId)));
                if (tracfoneOneRetailCarrier.getCarrierLong() != null) {
                    carrier.setCarrierLong(getStringValue(tracfoneOneRetailCarrier.getCarrierLong()));
                }
                if (!StringUtils.isNullOrEmpty(tracfoneOneRetailCarrier.getCarrier())) {
                    carrier.setCarrier(tracfoneOneRetailCarrier.getCarrier());
                }
                if (!StringUtils.isNullOrEmpty(tracfoneOneRetailCarrier.getStatus())) {
                    carrier.setStatus(tracfoneOneRetailCarrier.getStatus());
                }
                carrier.setUpdateDate(new Date());
                cRtlCarrierFacade.edit(carrier);
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Retail Carrier", gson.toJson(tracfoneOneRetailCarrier), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_CARRIER_UPDATE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse updateBrand(TracfoneOneRetailBrand tracfoneOneRetailBrand, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        try {
            for (String objId : tracfoneOneRetailBrand.getObjId().split(",")) {
                CRtlBrand brand = cRtlBrandFacade.find(BigDecimal.valueOf(Integer.valueOf(objId)));
                if (tracfoneOneRetailBrand.getBrandLong() != null) {
                    brand.setBrandLong(getStringValue(tracfoneOneRetailBrand.getBrandLong()));
                }
                if (tracfoneOneRetailBrand.getTraitLogicRuleId() != null) {
                    brand.setcRtlTraitLogicRuleId(getStringValue(tracfoneOneRetailBrand.getTraitLogicRuleId()));
                }
                if (!StringUtils.isNullOrEmpty(tracfoneOneRetailBrand.getStatus())) {
                    brand.setStatus(tracfoneOneRetailBrand.getStatus());
                }
                if (!StringUtils.isNullOrEmpty(tracfoneOneRetailBrand.getBrand())) {
                    brand.setBrand(tracfoneOneRetailBrand.getBrand());
                }
                brand.setUpdateDate(new Date());
                cRtlBrandFacade.edit(brand);
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Retail Brand", gson.toJson(tracfoneOneRetailBrand), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_BRAND_UPDATE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse updateTech(TracfoneOneRetailTech tracfoneOneRetailTech, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        try {
            for (String objId : tracfoneOneRetailTech.getObjId().split(",")) {
                CRtlTech tech = cRtlTechFacade.find(BigDecimal.valueOf(Integer.valueOf(objId)));
                if (tracfoneOneRetailTech.getTechLong() != null) {
                    tech.setTechLong(getStringValue(tracfoneOneRetailTech.getTechLong()));
                }
                if (!StringUtils.isNullOrEmpty(tracfoneOneRetailTech.getTech())) {
                    tech.setTech(tracfoneOneRetailTech.getTech());
                }
                if (!StringUtils.isNullOrEmpty(tracfoneOneRetailTech.getStatus())) {
                    tech.setStatus(tracfoneOneRetailTech.getStatus());
                }
                tech.setUpdateDate(new Date());
                cRtlTechFacade.edit(tech);
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Retail Tech", gson.toJson(tracfoneOneRetailTech), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_TECH_UPDATE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse updateCarrierDetail(TracfoneOneRetailCarrierDetail tracfoneOneRetailCarrierDetail, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        try {
            for (String objId : tracfoneOneRetailCarrierDetail.getObjId().split(",")) {
                CRtlCarrierDtl carrierDtl = cRtlCarrierDtlFacade.find(BigDecimal.valueOf(Integer.valueOf(objId)));
                if (!StringUtils.isNullOrEmpty(tracfoneOneRetailCarrierDetail.getCdtl2Tech())) {
                    carrierDtl.setcRtlTechId(tracfoneOneRetailCarrierDetail.getCdtl2Tech());
                }
                if (!StringUtils.isNullOrEmpty(tracfoneOneRetailCarrierDetail.getCdtl2Brand())) {
                    carrierDtl.setcRtlBrandId(tracfoneOneRetailCarrierDetail.getCdtl2Brand());
                }
                if (!StringUtils.isNullOrEmpty(tracfoneOneRetailCarrierDetail.getCdtl2Carrier())) {
                    carrierDtl.setcRtlCarrierId(tracfoneOneRetailCarrierDetail.getCdtl2Carrier());
                }
                if (!StringUtils.isNullOrEmpty(tracfoneOneRetailCarrierDetail.getStatus())) {
                    carrierDtl.setStatus(tracfoneOneRetailCarrierDetail.getStatus());
                }
                carrierDtl.setUpdateDate(new Date());
                cRtlCarrierDtlFacade.edit(carrierDtl);
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Retail Carrier Detail", gson.toJson(tracfoneOneRetailCarrierDetail), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_CARRIER_DETAIL_UPDATE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse updateCarrierPrefGroup(TracfoneOneRetailCarrierPrefGroup tracfoneOneRetailCarrierPrefGroup, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        try {
            CRtlCarrierPrefGrp carrierPrefGrp = cRtlCarrierPrefGrpFacade.find(BigDecimal.valueOf(Integer.valueOf(tracfoneOneRetailCarrierPrefGroup.getObjId())));
            if (tracfoneOneRetailCarrierPrefGroup.getBrand() != null) {
                carrierPrefGrp.setcPrefGrp2Brand(getBigDecimalValue(tracfoneOneRetailCarrierPrefGroup.getBrand()));
            }
            if (tracfoneOneRetailCarrierPrefGroup.getDescription() != null) {
                carrierPrefGrp.setDescription(getStringValue(tracfoneOneRetailCarrierPrefGroup.getDescription()));
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneRetailCarrierPrefGroup.getStatus())) {
                carrierPrefGrp.setStatus(tracfoneOneRetailCarrierPrefGroup.getStatus());
            }
            carrierPrefGrp.setUpdateDate(new Date());
            cRtlCarrierPrefGrpFacade.edit(carrierPrefGrp);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Retail Carrier Pref Group", gson.toJson(tracfoneOneRetailCarrierPrefGroup), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_CARRIER_PREF_GROUP_UPDATE_SUCCESS);
    }

    @Override
    public List<TFOneRetailParent> getParents() throws TracfoneOneException {
        List<TFOneRetailParent> tfOneRetailParents = new ArrayList<>();
        Map<String, TFOneRetailParent> parents = new HashMap<>();
        try {
            List<Object[]> parentDetails = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_GET_ALL_PARENT)
                    .getResultList();

            for (Object[] parentDetail : parentDetails) {
                TFOneRetailParent tfOneCRtlCarrier = new TFOneRetailParent();
                tfOneCRtlCarrier.setObjId(String.valueOf(parentDetail[0]));
                tfOneCRtlCarrier.setStatus(String.valueOf(parentDetail[1]));
                tfOneCRtlCarrier.setRetailer(String.valueOf(parentDetail[2]));
                tfOneCRtlCarrier.setInsertDate(String.valueOf(parentDetail[3]));
                if (parentDetail[4] != null) {
                    tfOneCRtlCarrier.setUpdateDate(String.valueOf(parentDetail[4]));
                }
                tfOneCRtlCarrier.setSecUserId(String.valueOf(parentDetail[5]));
                parents.put(tfOneCRtlCarrier.getObjId(), tfOneCRtlCarrier);
            }

            List<Object[]> runTraits = cRtlTpNormFacade.getEntityManager().
                    createNativeQuery(TRACFONE_GET_LAST_TRAIT_RUN_DATE_PARENT_ADMIN)
                    .getResultList();
            runTraits.forEach(e -> {
                TFOneRetailParent retailParent = parents.get(String.valueOf(e[0]).split("_")[0]);
                retailParent.setLastTraitRunDate(String.valueOf(e[1]));
            });
            tfOneRetailParents = parents.values().stream().collect(Collectors.toList());

            Collections.sort(tfOneRetailParents, (c1, c2) -> c1.getRetailer().compareToIgnoreCase(c2.getRetailer()));
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ALL_PARENTS, TRACFONE_GET_ALL_PARENTS_MESSAGE, ex);
        }
        return tfOneRetailParents;
    }

    @Override
    public List<TFOneRetailMaster> getMasters(String parentId) throws TracfoneOneException {
        List<TFOneRetailMaster> tfOneRetailMasters = new ArrayList<>();
        try {
            List<CRtlMaster> cRtlMasters = cRtlMasterFacade.findAllByParent(BigDecimal.valueOf(Integer.valueOf(parentId)));
            for (CRtlMaster cRtlMaster : cRtlMasters) {
                TFOneRetailMaster tfOneRetailMaster = new TFOneRetailMaster();
                tfOneRetailMaster.setStoreName(cRtlMaster.getStoreName());
                tfOneRetailMaster.setMaster2Parent(String.valueOf(cRtlMaster.getMaster2Parent()));
                tfOneRetailMaster.setObjId(String.valueOf(cRtlMaster.getObjid()));
                tfOneRetailMaster.setSecUserId(String.valueOf(cRtlMaster.getSecUserId()));
                tfOneRetailMaster.setStatus(cRtlMaster.getStatus());
                tfOneRetailMaster.setInsertDate(formatDate(cRtlMaster.getInsertDate()));
                tfOneRetailMaster.setUpdateDate(formatDate(cRtlMaster.getUpdateDate()));
                tfOneRetailMasters.add(tfOneRetailMaster);
            }
            Collections.sort(tfOneRetailMasters, (c1, c2) -> c1.getStoreName().compareToIgnoreCase(c2.getStoreName()));
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ALL_MASTERS, TRACFONE_GET_ALL_MASTERS_MESSAGE, ex);
        }
        return tfOneRetailMasters;
    }

    @Override
    public TFOneGeneralResponse insertParent(TracfoneOneRetailParent tracfoneOneRetailParent, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        CRtlParent cRtlParent = new CRtlParent();
        cRtlParent.setRetailer(tracfoneOneRetailParent.getRetailer());
        cRtlParent.setInsertDate(new Date());
        // TODO - Look into this when we integrate with COP Users
        cRtlParent.setSecUserId(BigDecimal.valueOf(1));
        cRtlParent.setStatus(tracfoneOneRetailParent.getStatus());

        try {
            cRtlParentFacade.create(cRtlParent);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Retail Parent", gson.toJson(tracfoneOneRetailParent), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_PARENT_CREATE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse updateParent(TracfoneOneRetailParent tracfoneOneRetailParent, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        try {
            CRtlParent cRtlParent = cRtlParentFacade.find(BigDecimal.valueOf(Integer.valueOf(tracfoneOneRetailParent.getObjId())));
            if (!StringUtils.isNullOrEmpty(tracfoneOneRetailParent.getRetailer())) {
                cRtlParent.setRetailer(tracfoneOneRetailParent.getRetailer());
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneRetailParent.getStatus())) {
                cRtlParent.setStatus(tracfoneOneRetailParent.getStatus());
            }
            cRtlParent.setUpdateDate(new Date());
            cRtlParentFacade.edit(cRtlParent);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Retail Parent", gson.toJson(tracfoneOneRetailParent), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_PARENT_UPDATE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse insertMaster(TracfoneOneRetailMaster tracfoneOneRetailMaster, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        CRtlMaster cRtlMaster = new CRtlMaster();
        cRtlMaster.setStoreName(tracfoneOneRetailMaster.getStoreName());
        cRtlMaster.setMaster2Parent(BigDecimal.valueOf(Integer.valueOf(tracfoneOneRetailMaster.getMaster2Parent())));
        cRtlMaster.setInsertDate(new Date());
        // TODO - Look into this when we integrate with COP Users
        cRtlMaster.setSecUserId(BigDecimal.valueOf(1));
        cRtlMaster.setStatus(tracfoneOneRetailMaster.getStatus());

        try {
            cRtlMasterFacade.create(cRtlMaster);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Retail Master", gson.toJson(tracfoneOneRetailMaster), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_MASTER_CREATE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse updateMaster(TracfoneOneRetailMaster tracfoneOneRetailMaster, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        try {
            CRtlMaster cRtlMaster = cRtlMasterFacade.find(BigDecimal.valueOf(Integer.valueOf(tracfoneOneRetailMaster.getObjId())));
            if (!StringUtils.isNullOrEmpty(tracfoneOneRetailMaster.getStoreName())) {
                cRtlMaster.setStoreName(tracfoneOneRetailMaster.getStoreName());
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneRetailMaster.getStatus())) {
                cRtlMaster.setStatus(tracfoneOneRetailMaster.getStatus());
            }
            cRtlMaster.setUpdateDate(new Date());
            cRtlMasterFacade.edit(cRtlMaster);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Retail Master", gson.toJson(tracfoneOneRetailMaster), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_MASTER_UPDATE_SUCCESS);
    }

    @Override
    public List<TFOneRetailParentRule> getParentRules(String parentId) throws TracfoneOneException {
        List<TFOneRetailParentRule> tfOneRetailParentRules = new ArrayList<>();
        try {
            List<CRtlParentRule> cRtlParentRules = cRtlParentRuleFacade.findAllByParent(BigDecimal.valueOf(Integer.valueOf(parentId)));
            for (CRtlParentRule cRtlParentRule : cRtlParentRules) {
                TFOneRetailParentRule tfOneRetailParentRule = new TFOneRetailParentRule();
                tfOneRetailParentRule.setObjId(String.valueOf(cRtlParentRule.getObjid()));
                tfOneRetailParentRule.setRule2cPrefGrpTrait(String.valueOf(cRtlParentRule.getRule2cPrefGrpTrait()));
                tfOneRetailParentRule.setRule2Parent(String.valueOf(cRtlParentRule.getRule2Parent()));
                tfOneRetailParentRule.setRule2cPrefGrpRank(cRtlParentRule.getRule2cPrefGrpRank() != null ? String.valueOf(cRtlParentRule.getRule2cPrefGrpRank()) : null);
                tfOneRetailParentRule.setRule2TraitRule(cRtlParentRule.getRule2TraitRule() != null ? String.valueOf(cRtlParentRule.getRule2TraitRule()) : null);
                tfOneRetailParentRules.add(tfOneRetailParentRule);
            }
            Collections.sort(tfOneRetailParentRules, (c1, c2) -> c1.getRule2cPrefGrpTrait().compareToIgnoreCase(c2.getRule2cPrefGrpTrait()));
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ALL_PARENT_RULES, TRACFONE_GET_ALL_PARENT_RULES_MESSAGE, ex);
        }
        return tfOneRetailParentRules;
    }

    @Override
    public TFOneGeneralResponse insertParentRule(TracfoneOneRetailParentRule tracfoneOneRetailParentRule, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        CRtlParentRule cRtlParentRule = new CRtlParentRule();
        cRtlParentRule.setRule2cPrefGrpTrait(BigDecimal.valueOf(Integer.valueOf(tracfoneOneRetailParentRule.getRule2cPrefGrpTrait())));
        cRtlParentRule.setRule2Parent(BigDecimal.valueOf(Integer.valueOf(tracfoneOneRetailParentRule.getRule2Parent())));
        if (tracfoneOneRetailParentRule.getRule2cPrefGrpRank() != null) {
            cRtlParentRule.setRule2cPrefGrpRank(getBigDecimalValue(tracfoneOneRetailParentRule.getRule2cPrefGrpRank()));
        }
        if (tracfoneOneRetailParentRule.getRule2TraitRule() != null) {
            cRtlParentRule.setRule2TraitRule(getBigDecimalValue(tracfoneOneRetailParentRule.getRule2TraitRule()));
        }

        try {
            cRtlParentRuleFacade.create(cRtlParentRule);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Retail Parent Rule", gson.toJson(tracfoneOneRetailParentRule), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_PARENT_RULE_CREATE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse updateParentRule(TracfoneOneRetailParentRule tracfoneOneRetailParentRule, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        try {
            CRtlParentRule cRtlParentRule = cRtlParentRuleFacade.find(BigDecimal.valueOf(Integer.valueOf(tracfoneOneRetailParentRule.getObjId())));
            if (tracfoneOneRetailParentRule.getRule2cPrefGrpRank() != null) {
                cRtlParentRule.setRule2cPrefGrpRank(getBigDecimalValue(tracfoneOneRetailParentRule.getRule2cPrefGrpRank()));
            }
            if (tracfoneOneRetailParentRule.getRule2TraitRule() != null) {
                cRtlParentRule.setRule2TraitRule(getBigDecimalValue(tracfoneOneRetailParentRule.getRule2TraitRule()));
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneRetailParentRule.getRule2cPrefGrpTrait())) {
                cRtlParentRule.setRule2cPrefGrpTrait(BigDecimal.valueOf(Integer.valueOf(tracfoneOneRetailParentRule.getRule2cPrefGrpTrait())));
            }
            cRtlParentRuleFacade.edit(cRtlParentRule);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Retail Parent Rule", gson.toJson(tracfoneOneRetailParentRule), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_PARENT_RULE_UPDATE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse insertCarrierPrefDetail(TracfoneOneRetailCarrierPrefDetail tracfoneOneRetailCarrierPrefDetail, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        CRtlCarrierPref cRtlCarrierPref = new CRtlCarrierPref();
        cRtlCarrierPref.setcPref2CarrierPrefGrp(BigDecimal.valueOf(Integer.valueOf(tracfoneOneRetailCarrierPrefDetail.getCarrierPrefGroupId())));
        cRtlCarrierPref.setcPref2CarrierDtl(BigDecimal.valueOf(Integer.valueOf(tracfoneOneRetailCarrierPrefDetail.getCarrierDetailId())));
        cRtlCarrierPref.setRank(BigDecimal.valueOf(Integer.valueOf(tracfoneOneRetailCarrierPrefDetail.getRank())));

        try {
            cRtlCarrierPrefFacade.create(cRtlCarrierPref);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Retail Parent Rule", gson.toJson(tracfoneOneRetailCarrierPrefDetail), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_CARRIER_PREF_CREATE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse deleteCarrierPrefDetail(String carrierPrefDetailId, int userId) throws TracfoneOneException {
        try {
            cRtlCarrierPrefFacade.getEntityManager().createNativeQuery(TRACFONE_DELETE_CARRIER_PREF_LOG)
                    .setParameter(1, carrierPrefDetailId).executeUpdate();

            CRtlCarrierPref cRtlCarrierPref = cRtlCarrierPrefFacade.find(BigDecimal.valueOf(Integer.valueOf(carrierPrefDetailId)));
            cRtlCarrierPrefFacade.remove(cRtlCarrierPref);

            TracfoneOneRetailCarrierDetail tfRetailCarrierDetail = new TracfoneOneRetailCarrierDetail();
            tfRetailCarrierDetail.setStatus("C");
            tfRetailCarrierDetail.setObjId(cRtlCarrierPref.getcPref2CarrierDtl().toString());
            updateCarrierDetail(tfRetailCarrierDetail, userId);

        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Retail Carrier Pref", carrierPrefDetailId, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_CARRIER_PREF_DELETE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse insertTraitLogicRule(TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        CRtlTraitLogicRule cRtlTraitLogicRule = new CRtlTraitLogicRule();
        cRtlTraitLogicRule.setSecUserId(tracfoneOneTraitLogicRule.getRule2User());
        cRtlTraitLogicRule.setRuleName(tracfoneOneTraitLogicRule.getRuleName());
        cRtlTraitLogicRule.setRule2Logic(tracfoneOneTraitLogicRule.getRule2Logic());
        if (!StringUtils.isNullOrEmpty(tracfoneOneTraitLogicRule.getUseOuterPop())) {
            cRtlTraitLogicRule.setUseOuterPop(BigDecimal.valueOf(Integer.valueOf(tracfoneOneTraitLogicRule.getUseOuterPop())));
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneTraitLogicRule.getPrefAllCarr())) {
            cRtlTraitLogicRule.setPrefAllCarr(BigDecimal.valueOf(Integer.valueOf(tracfoneOneTraitLogicRule.getPrefAllCarr())));
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneTraitLogicRule.getOuterRadius())) {
            cRtlTraitLogicRule.setOuterRadius(BigDecimal.valueOf(Integer.valueOf(tracfoneOneTraitLogicRule.getOuterRadius())));
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneTraitLogicRule.getOuterPop())) {
            cRtlTraitLogicRule.setOuterPop(BigDecimal.valueOf(Integer.valueOf(tracfoneOneTraitLogicRule.getOuterPop())));
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneTraitLogicRule.getOuterGeo())) {
            cRtlTraitLogicRule.setOuterGeo(BigDecimal.valueOf(Integer.valueOf(tracfoneOneTraitLogicRule.getOuterGeo())));
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneTraitLogicRule.getInnerRadius())) {
            cRtlTraitLogicRule.setInnerRadius(BigDecimal.valueOf(Integer.valueOf(tracfoneOneTraitLogicRule.getInnerRadius())));
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneTraitLogicRule.getInnerPop())) {
            cRtlTraitLogicRule.setInnerPop(BigDecimal.valueOf(Integer.valueOf(tracfoneOneTraitLogicRule.getInnerPop())));
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneTraitLogicRule.getInnerGeo())) {
            cRtlTraitLogicRule.setInnerGeo(BigDecimal.valueOf(Integer.valueOf(tracfoneOneTraitLogicRule.getInnerGeo())));
        }

        try {
            cRtlTraitLogicRuleFacade.create(cRtlTraitLogicRule);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Retail Trait Logic Rule", gson.toJson(cRtlTraitLogicRule), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_TRAIT_LOGIC_RULE_CREATE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse updateTraitLogicRule(TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule, int userId) throws TracfoneOneException {
        Gson gson = new Gson();

        try {
            CRtlTraitLogicRule traitLogicRule = cRtlTraitLogicRuleFacade.find(BigDecimal.valueOf(Integer.valueOf(tracfoneOneTraitLogicRule.getObjId())));
            setTraitLogicRule(traitLogicRule, tracfoneOneTraitLogicRule);

            cRtlTraitLogicRuleFacade.edit(traitLogicRule);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Retail Trait Logic Rule", gson.toJson(tracfoneOneTraitLogicRule), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_TRAIT_LOGIC_RULE_UPDATE_SUCCESS);
    }

    @Override
    public TFOneRetailTpAdminSearchResults searchTpNorm(TracfoneOneRetailTpAdminSearchModel tpAdminSearchModel) throws TracfoneOneException {
        TFOneRetailTpAdminSearchResults tfOneRetailTpAdminSearchResults = new TFOneRetailTpAdminSearchResults();
        tfOneRetailTpAdminSearchResults.setStartIndex(tpAdminSearchModel.getStartIndex());
        tfOneRetailTpAdminSearchResults.setEndIndex(tpAdminSearchModel.getEndIndex());
        try {
            // Getting the total number of records found in search
            Query query = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(buildTpNormSearchQuery(tpAdminSearchModel, true));
            System.out.print("111111111 "+query.toString());
            setTpNormParams(query, tpAdminSearchModel, true);
            Object count = query.getSingleResult();
            LOGGER.info("Count - " + count);
            tfOneRetailTpAdminSearchResults.setCount(String.valueOf(count));

            // Retrieving the list based on start and end index specified from UI
            List<TFOneRetailTpNorm> tfOneRetailTpNorms = new ArrayList<>();
            query = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(buildTpNormSearchQuery(tpAdminSearchModel, false));
            setTpNormParams(query, tpAdminSearchModel, false);
            List<Object[]> tpNorms = query.getResultList();
            for (Object[] tfOneTpNorm : tpNorms) {
                TFOneRetailTpNorm tfOneRetailTpNorm = new TFOneRetailTpNorm();
                tfOneRetailTpNorm.setObjId(String.valueOf(tfOneTpNorm[0]));
                tfOneRetailTpNorm.setTp2Zip(String.valueOf(tfOneTpNorm[1]));
                tfOneRetailTpNorm.setCarrier(String.valueOf(tfOneTpNorm[2]));
                tfOneRetailTpNorm.setCarrierStatus(String.valueOf(tfOneTpNorm[3]));
                tfOneRetailTpNorm.setBrand(String.valueOf(tfOneTpNorm[4]));
                tfOneRetailTpNorm.setBrandStatus(String.valueOf(tfOneTpNorm[5]));
                tfOneRetailTpNorm.setTech(String.valueOf(tfOneTpNorm[6]));
                tfOneRetailTpNorm.setTechStatus(String.valueOf(tfOneTpNorm[7]));
                tfOneRetailTpNorm.setCoverage(String.valueOf(tfOneTpNorm[8]));
                if (tfOneTpNorm[9] != null) {
                    tfOneRetailTpNorm.setCoverageNotes(String.valueOf(tfOneTpNorm[9]));
                }
                tfOneRetailTpNorms.add(tfOneRetailTpNorm);
            }
            Collections.sort(tfOneRetailTpNorms, (c1, c2) -> c1.getTp2Zip().compareToIgnoreCase(c2.getTp2Zip()));
            tfOneRetailTpAdminSearchResults.setTfOneRetailTpNorms(tfOneRetailTpNorms);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        LOGGER.info("Search TP Norm " + tfOneRetailTpAdminSearchResults);
        return tfOneRetailTpAdminSearchResults;
    }

    @Override
    public List<String> getStates() throws TracfoneOneException {
        List<String> states = new ArrayList<>();
        try {
            states = cRtlTpNormFacade.getEntityManager().createNativeQuery(TRACFONE_GET_STATES).getResultList();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return states;
    }

    @Override
    public TFOneGeneralResponse updateTpNorms(TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel, int userId) throws TracfoneOneException {
        if (retailTpAdminSearchModel.isUpdateAll()) {
            return updateAllTpNorms(retailTpAdminSearchModel, userId);
        } else {
            return updateSelectedTpNorms(retailTpAdminSearchModel, userId);
        }
    }

    private TFOneGeneralResponse updateAllTpNorms(TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            // using the search criteria get all the objids and just update them with inner query
            Query query = cRtlTpNormFacade.getEntityManager().createNativeQuery(buildUpdateAllTpNormQuery(retailTpAdminSearchModel));
            setUpdateAllQueryParams(query, retailTpAdminSearchModel);
            query.executeUpdate();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Updated All TP Norms", gson.toJson(retailTpAdminSearchModel), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_TP_NORM_UPDATE_SUCCESS);
    }

    private void setUpdateAllQueryParams(Query query, TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel) {
        int index = 1;
        if (retailTpAdminSearchModel.getCoverage() != null) {
            query.setParameter(index++, retailTpAdminSearchModel.getCoverage());
        }
        if (retailTpAdminSearchModel.getCoverageNotes() != null) {
            query.setParameter(index++, retailTpAdminSearchModel.getCoverageNotes());
        }
        if (!StringUtils.isNullOrEmpty(retailTpAdminSearchModel.getZipCodes())) {
            for (String fieldValue : retailTpAdminSearchModel.getZipCodes().split(",")) {
                query.setParameter(index++, fieldValue);
            }
        }
        if (!StringUtils.isNullOrEmpty(retailTpAdminSearchModel.getCarrierDetails())) {
            for (String fieldValue : retailTpAdminSearchModel.getCarrierDetails().split(",")) {
                query.setParameter(index++, fieldValue);
            }
        }
        if (!StringUtils.isNullOrEmpty(retailTpAdminSearchModel.getStates())) {
            for (String fieldValue : retailTpAdminSearchModel.getStates().split(",")) {
                query.setParameter(index++, fieldValue);
            }
        }
    }

    private String buildUpdateAllTpNormQuery(TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel) {
        StringBuilder builder = new StringBuilder("UPDATE C_RTL_TP_NORM SET UPDATE_DATE = SYSDATE, ");
        if (retailTpAdminSearchModel.getCoverage() != null) {
            builder.append("COVERAGE = ? ");
            if (retailTpAdminSearchModel.getCoverageNotes() != null) {
                builder.append(", COVERAGE_NOTES = ? ");
            }
        } else {
            builder.append("COVERAGE_NOTES = ? ");
        }
        builder.append("WHERE OBJID IN (SELECT N.OBJID");
        if (retailTpAdminSearchModel.getStates() != null) {
            builder.append(TRACFONE_GET_TP_NORMS_BY_STATES);
        } else {
            builder.append(TRACFONE_GET_TP_NORMS);
        }
        if (!StringUtils.isNullOrEmpty(retailTpAdminSearchModel.getZipCodes())) {
            builder.append(inClause("N.TP2ZIP", retailTpAdminSearchModel.getZipCodes()))
                    .append("AND ");
        }
        if (!StringUtils.isNullOrEmpty(retailTpAdminSearchModel.getCarrierDetails())) {
            builder.append(inClause("N.TP2CARRIER_DTL", retailTpAdminSearchModel.getCarrierDetails()))
                    .append("AND ");
        }
        if (!StringUtils.isNullOrEmpty(retailTpAdminSearchModel.getStates())) {
            builder.append(inClause("G.STATE", retailTpAdminSearchModel.getStates()))
                    .append("AND ");
        }
        String query = null;
        if (builder.lastIndexOf("AND ") != -1) {
            query = builder.substring(0, builder.lastIndexOf("AND "));
        }
        query = query + ")";
        LOGGER.info("The Update ALL Query is " + query);

        return query;
    }

    private TFOneGeneralResponse updateSelectedTpNorms(TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            for (String fieldValue : retailTpAdminSearchModel.getObjIds().split(",")) {
                CRtlTpNorm tpNorm = cRtlTpNormFacade.find(BigDecimal.valueOf(Integer.valueOf(fieldValue)));
                if (retailTpAdminSearchModel.getCoverage() != null) {
                    tpNorm.setCoverage(getStringValue(retailTpAdminSearchModel.getCoverage()));
                }
                if (retailTpAdminSearchModel.getCoverageNotes() != null) {
                    tpNorm.setCoverageNotes(getStringValue(retailTpAdminSearchModel.getCoverageNotes()));
                }
                tpNorm.setUpdateDate(new Date());
                cRtlTpNormFacade.edit(tpNorm);
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Updated TP Norms", gson.toJson(retailTpAdminSearchModel), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_TP_NORM_UPDATE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse runTraits(String parentId, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            String name = parentId.concat(PARENT_UPDATE);
            Object parentUpdateCount = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_COUNT_PARENT_UPDATE_JOB_TASK)
                    .setParameter(1, name)
                    .getSingleResult();
            String query = null;
            if ("0".equals(String.valueOf(parentUpdateCount))) {
                LOGGER.info("No Job Task found, Inserting a new Job Task");
                query = TRACFONE_INSERT_PARENT_UPDATE_JOB_TASK;
            } else {
                LOGGER.info("Job Task found, updating Job Task");
                query = TRACFONE_UPDATE_START_RUN_JOB_TASK;
            }
            cRtlTpNormFacade.getEntityManager().createNativeQuery(query).setParameter(1, name).executeUpdate();

            List<Object[]> traitRunners = cRtlTpNormFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_RUN_TRAITS_FOR_PARENT)
                    .setParameter(1, parentId)
                    .getResultList();
            if (traitRunners != null) {
                LOGGER.info("Number of records retrieved from DB " + traitRunners.size());
            }

            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                int count = 0;
                for (Object[] objects : traitRunners) {
                    TracfoneOneRetailTraitRunner traitRunner = new TracfoneOneRetailTraitRunner();
                    traitRunner.setParentId(String.valueOf(objects[0]));
                    traitRunner.setStoreName(String.valueOf(objects[1]));
                    traitRunner.setStoreNum(String.valueOf(objects[2]));
                    traitRunner.setZip(String.valueOf(objects[3]));
                    traitRunner.setRadius(String.valueOf(objects[4]));
                    LOGGER.info("Trait Runner retrieved " + traitRunner);
                    LOGGER.info(C_RTL_STORE_SP_CALL);

                    callStoredProcedure(C_RTL_STORE_SP_N, traitRunner);
                    LOGGER.info(C_RTL_STORE_SP_N_DONE + traitRunner + " and count " + count++);
                }
            });
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            cRtlTpNormFacade.getEntityManager().createNativeQuery(TRACFONE_UPDATE_END_RUN_JOB_TASK)
                    .setParameter(1, parentId.concat(PARENT_UPDATE)).executeUpdate();
            TracfoneAudit audit = new TracfoneAudit(userId, "Ran Traits from Parent Admin", gson.toJson(parentId), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_RUN_TRAITS_SUCCESS);
    }

    private void callStoredProcedure(String procedureName, TracfoneOneRetailTraitRunner traitRunner) {
        EntityManager entityManager = null;
        try {
            entityManager = cRtlTpNormFacade.getEntityManager().getEntityManagerFactory().createEntityManager();
            entityManager.createStoredProcedureQuery(procedureName)
                    .registerStoredProcedureParameter("p_env", String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter("p_parent", String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter("p_store_name", String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter("p_store_num", String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter("p_zip", String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter("p_radius", String.class, ParameterMode.IN)
                    .registerStoredProcedureParameter("p_user", String.class, ParameterMode.IN)
                    .setParameter("p_env", "PROD")
                    .setParameter("p_parent", traitRunner.getParentId())
                    .setParameter("p_store_name", traitRunner.getStoreName())
                    .setParameter("p_store_num", traitRunner.getStoreNum())
                    .setParameter("p_zip", traitRunner.getZip())
                    .setParameter("p_radius", traitRunner.getRadius())
                    //TODO need to re-look into
                    .setParameter("p_user", "1")
                    .execute();
        } catch (Exception e) {
            LOGGER.error(e);
        } finally {
            if (entityManager != null) {
                entityManager.close();
            }
        }
    }

    private void setTpNormParams(Query query, TracfoneOneRetailTpAdminSearchModel tfOneRetailTpNorms, boolean isCountQuery) {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tfOneRetailTpNorms.getZipCodes())) {
            for (String fieldValue : tfOneRetailTpNorms.getZipCodes().split(",")) {
                query.setParameter(index++, fieldValue);
            }
        }
        if (!StringUtils.isNullOrEmpty(tfOneRetailTpNorms.getCarrierDetails())) {
            for (String fieldValue : tfOneRetailTpNorms.getCarrierDetails().split(",")) {
                query.setParameter(index++, fieldValue);
            }
        }
        if (!StringUtils.isNullOrEmpty(tfOneRetailTpNorms.getStates())) {
            for (String fieldValue : tfOneRetailTpNorms.getStates().split(",")) {
                query.setParameter(index++, fieldValue);
            }
        }
        if (!isCountQuery) {
            query.setParameter(index++, tfOneRetailTpNorms.getStartIndex());
            query.setParameter(index, tfOneRetailTpNorms.getEndIndex());
        }
    }

    private String buildTpNormSearchQuery(TracfoneOneRetailTpAdminSearchModel tpAdminSearchModel, boolean isCountStatement) {
        StringBuilder builder = new StringBuilder();
        if (isCountStatement) {
            builder.append(TRACFONE_TP_NORMS_COUNT);
        } else {
            builder.append(TRACFONE_TP_NORMS_START);
        }
        builder.append(TRACFONE_TP_NORMS_SELECT);

        if (StringUtils.isNullOrEmpty(tpAdminSearchModel.getStates())) {
            builder.append(TRACFONE_GET_TP_NORMS);
        } else {
            builder.append(TRACFONE_GET_TP_NORMS_BY_STATES);
        }

        if (!StringUtils.isNullOrEmpty(tpAdminSearchModel.getZipCodes())) {
            builder.append(inClause("N.TP2ZIP", tpAdminSearchModel.getZipCodes()))
                    .append("AND ");
        }
        if (!StringUtils.isNullOrEmpty(tpAdminSearchModel.getCarrierDetails())) {
            builder.append(inClause("N.TP2CARRIER_DTL", tpAdminSearchModel.getCarrierDetails()))
                    .append("AND ");
        }
        if (!StringUtils.isNullOrEmpty(tpAdminSearchModel.getStates())) {
            builder.append(inClause("G.STATE", tpAdminSearchModel.getStates()))
                    .append("AND ");
        }
        String query = null;
        if (builder.lastIndexOf("AND ") != -1) {
            query = builder.substring(0, builder.lastIndexOf("AND "));
            query = query + " ORDER BY N.TP2ZIP " + TRACFONE_TP_NORMS_END +
                    (!isCountStatement ? " ) where rnum >=? and rnum <= ?" : " ");
        }
        LOGGER.info("Search query for TP Norms " + query);
        return query;
    }

    private String inClause(String fieldName, String fieldValues) {
        StringBuilder builder = new StringBuilder(fieldName);
        builder.append(" IN (");
        int total = fieldValues.split(",").length;
        int count = 1;
        while (count <= total) {
            builder.append("?,");
            count++;
        }
        builder.deleteCharAt(builder.length() - 1);
        builder.append(") ");
        return builder.toString();
    }

    private void setTraitLogicRule(CRtlTraitLogicRule traitLogicRule, TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule) {
        if (tracfoneOneTraitLogicRule.getInnerGeo() != null) {
            traitLogicRule.setInnerGeo(getBigDecimalValue(tracfoneOneTraitLogicRule.getInnerGeo()));
        }
        if (tracfoneOneTraitLogicRule.getInnerPop() != null) {
            traitLogicRule.setInnerPop(getBigDecimalValue(tracfoneOneTraitLogicRule.getInnerPop()));
        }
        if (tracfoneOneTraitLogicRule.getInnerRadius() != null) {
            traitLogicRule.setInnerRadius(getBigDecimalValue(tracfoneOneTraitLogicRule.getInnerRadius()));
        }
        if (tracfoneOneTraitLogicRule.getOuterGeo() != null) {
            traitLogicRule.setOuterGeo(getBigDecimalValue(tracfoneOneTraitLogicRule.getOuterGeo()));
        }
        if (tracfoneOneTraitLogicRule.getOuterPop() != null) {
            traitLogicRule.setOuterPop(getBigDecimalValue(tracfoneOneTraitLogicRule.getOuterPop()));
        }
        if (tracfoneOneTraitLogicRule.getOuterRadius() != null) {
            traitLogicRule.setOuterRadius(getBigDecimalValue(tracfoneOneTraitLogicRule.getOuterRadius()));
        }
        if (tracfoneOneTraitLogicRule.getPrefAllCarr() != null) {
            traitLogicRule.setPrefAllCarr(getBigDecimalValue(tracfoneOneTraitLogicRule.getPrefAllCarr()));
        }
        if (tracfoneOneTraitLogicRule.getRule2Logic() != null) {
            traitLogicRule.setRule2Logic(getStringValue(tracfoneOneTraitLogicRule.getRule2Logic()));
        }
        if (tracfoneOneTraitLogicRule.getRule2User() != null) {
            traitLogicRule.setSecUserId(getStringValue(tracfoneOneTraitLogicRule.getRule2User()));
        }
        if (tracfoneOneTraitLogicRule.getRuleName() != null) {
            traitLogicRule.setRuleName(getStringValue(tracfoneOneTraitLogicRule.getRuleName()));
        }
        if (tracfoneOneTraitLogicRule.getUseOuterPop() != null) {
            traitLogicRule.setUseOuterPop(getBigDecimalValue(tracfoneOneTraitLogicRule.getUseOuterPop()));
        }
    }

    private String getStringValue(String fieldValue) {
        return fieldValue.trim().length() == 0 ? null : fieldValue.trim();
    }

    private BigDecimal getBigDecimalValue(String fieldValue) {
        return fieldValue.trim().length() == 0 ? null : BigDecimal.valueOf(Integer.valueOf(fieldValue));
    }

    private String formatDate(Date date) {
        if (date == null) {
            return null;
        }

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss");
        return formatter.format(date);
    }

    @Override
    public TFOneGeneralResponse runStoreTraits(TracfoneOneRetailLocation tracfoneOneRetailLocation, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            updateJobTask(tracfoneOneRetailLocation.getStoreNum());

            TracfoneOneRetailTraitRunner traitRunner = new TracfoneOneRetailTraitRunner();
            traitRunner.setParentId(String.valueOf(tracfoneOneRetailLocation.getParentId()));
            traitRunner.setStoreName(String.valueOf(tracfoneOneRetailLocation.getStoreName()));
            traitRunner.setStoreNum(String.valueOf(tracfoneOneRetailLocation.getStoreNum()));
            traitRunner.setZip(String.valueOf(tracfoneOneRetailLocation.getZip()));
            traitRunner.setRadius(String.valueOf(tracfoneOneRetailLocation.getRadius()));
            LOGGER.info("Trait Runner retrieved " + traitRunner);
            LOGGER.info(C_RTL_STORE_SP_CALL);

            callStoredProcedure(C_RTL_STORE_SP_N, traitRunner);
            LOGGER.info(C_RTL_STORE_SP_N_DONE + traitRunner);

            cRtlTpNormFacade.getEntityManager().createNativeQuery(TRACFONE_UPDATE_END_RUN_JOB_TASK)
                    .setParameter(1, tracfoneOneRetailLocation.getStoreNum().concat("_STORE_UPDATE"))
                    .executeUpdate();

            cRtlTpNormFacade.getEntityManager().createNativeQuery(TRACFONE_UPDATE_LAST_TRAIT_RUN_DATE)
                    .setParameter(1, tracfoneOneRetailLocation.getObjIds())
                    .executeUpdate();

        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Run Traits from View Retail Traits", gson.toJson(tracfoneOneRetailLocation.getStoreNum()), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_RUN_STORE_TRAITS_SUCCESS);
    }

    private void updateJobTask(String storeNum) {
        String name = storeNum.concat("_STORE_UPDATE");
        Object storeUpdateCount = cRtlTpNormFacade.getEntityManager()
                .createNativeQuery(TRACFONE_COUNT_PARENT_UPDATE_JOB_TASK)
                .setParameter(1, name)
                .getSingleResult();
        String query = null;
        if ("0".equals(String.valueOf(storeUpdateCount))) {
            LOGGER.info("No Job Task found, Inserting a new Job Task");
            query = TRACFONE_INSERT_STORE_UPDATE_JOB_TASK;
        } else {
            LOGGER.info("Job Task found, updating Job Task");
            query = TRACFONE_UPDATE_START_RUN_JOB_TASK;
        }
        cRtlTpNormFacade.getEntityManager().createNativeQuery(query).setParameter(1, name).executeUpdate();
    }

    @Override
    public TFOneGeneralResponse updateRank(String objId, String rank, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            cRtlCarrierDtlFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_UPDATE_CARRIER_PREF_RANK)
                    .setParameter(1, rank)
                    .setParameter(2, objId).executeUpdate();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Rank", gson.toJson(objId), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_RANK_UPDATE_SUCCESS);
    }

    @Override
    public List<TFOneJobTask> runTraitsSummary() throws TracfoneOneException {
        List<TFOneJobTask> jobTasks = new ArrayList<>();
        try {
            List<Object[]> runTraitsSummary = cRtlTpNormFacade.getEntityManager().
                    createNativeQuery(TRACFONE_GET_LAST_TRAIT_RUN_DATE_SUMMARY)
                    .getResultList();
            runTraitsSummary.forEach(e ->
                    jobTasks.add(new TFOneJobTask(String.valueOf(e[0]), String.valueOf(e[1]), String.valueOf(e[2]),
                            String.valueOf(e[3]), String.valueOf(e[4]), e[5] == null ? null : String.valueOf(e[5])))
            );
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_RUN_TRAITS_SUMMARY, TRACFONE_RUN_TRAITS_SUMMARY_MESSAGE, ex);
        }
        return jobTasks;
    }

    @Override
    public TFOneGeneralResponse updateNewRank(List<TracfoneOneRetailCarrierPrefDetail> carrierPrefDetail, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            Query query = cRtlCarrierDtlFacade.getEntityManager()
                    .createNativeQuery(TRACFONE_UPDATE_CARRIER_PREF_RANK);
            carrierPrefDetail.forEach(prefDetails ->
                    query.setParameter(1, prefDetails.getRank())
                            .setParameter(2, prefDetails.getObjId()).executeUpdate()
            );
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Updating Rank for ", gson.toJson(carrierPrefDetail), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_RANK_UPDATE_SUCCESS);
    }
}