package com.tracfone.service.model.retail.response;

public class TFOneTraitDetail {
    private String radius;
    private String traits;
    private String brand;
    private String carrier;
    private String tech;
    private String dplyd;
    private String bufferZips;
    private String pop;
    private String zipsDplyd;
    private String percZipDplyd;
    private String popDplyd;
    private String percPopDplyd;
    private String extZipDplyd;
    private String extPercDplyd;
    private String extPopDplyd;
    private String extPercPopDplyd;

    public String getRadius() {
        return radius;
    }

    public void setRadius(String radius) {
        this.radius = radius;
    }

    public String getTraits() {
        return traits;
    }

    public void setTraits(String traits) {
        this.traits = traits;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getTech() {
        return tech;
    }

    public void setTech(String tech) {
        this.tech = tech;
    }

    public String getDplyd() {
        return dplyd;
    }

    public void setDplyd(String dplyd) {
        this.dplyd = dplyd;
    }

    public String getBufferZips() {
        return bufferZips;
    }

    public void setBufferZips(String bufferZips) {
        this.bufferZips = bufferZips;
    }

    public String getPop() {
        return pop;
    }

    public void setPop(String pop) {
        this.pop = pop;
    }

    public String getZipsDplyd() {
        return zipsDplyd;
    }

    public void setZipsDplyd(String zipsDplyd) {
        this.zipsDplyd = zipsDplyd;
    }

    public String getPercZipDplyd() {
        return percZipDplyd;
    }

    public void setPercZipDplyd(String percZipDplyd) {
        this.percZipDplyd = percZipDplyd;
    }

    public String getPopDplyd() {
        return popDplyd;
    }

    public void setPopDplyd(String popDplyd) {
        this.popDplyd = popDplyd;
    }

    public String getPercPopDplyd() {
        return percPopDplyd;
    }

    public void setPercPopDplyd(String percPopDplyd) {
        this.percPopDplyd = percPopDplyd;
    }

    public String getExtZipDplyd() {
        return extZipDplyd;
    }

    public void setExtZipDplyd(String extZipDplyd) {
        this.extZipDplyd = extZipDplyd;
    }

    public String getExtPercDplyd() {
        return extPercDplyd;
    }

    public void setExtPercDplyd(String extPercDplyd) {
        this.extPercDplyd = extPercDplyd;
    }

    public String getExtPopDplyd() {
        return extPopDplyd;
    }

    public void setExtPopDplyd(String extPopDplyd) {
        this.extPopDplyd = extPopDplyd;
    }

    public String getExtPercPopDplyd() {
        return extPercPopDplyd;
    }

    public void setExtPercPopDplyd(String extPercPopDplyd) {
        this.extPercPopDplyd = extPercPopDplyd;
    }

    @Override
    public String toString() {
        return "TFOneTraitDetail{" +
                "radius='" + radius + '\'' +
                ", traits='" + traits + '\'' +
                ", brand='" + brand + '\'' +
                ", carrier='" + carrier + '\'' +
                ", tech='" + tech + '\'' +
                ", dplyd='" + dplyd + '\'' +
                ", bufferZips='" + bufferZips + '\'' +
                ", pop='" + pop + '\'' +
                ", zipsDplyd='" + zipsDplyd + '\'' +
                ", percZipDplyd='" + percZipDplyd + '\'' +
                ", popDplyd='" + popDplyd + '\'' +
                ", percPopDplyd='" + percPopDplyd + '\'' +
                ", extZipDplyd='" + extZipDplyd + '\'' +
                ", extPercDplyd='" + extPercDplyd + '\'' +
                ", extPopDplyd='" + extPopDplyd + '\'' +
                ", extPercPopDplyd='" + extPercPopDplyd + '\'' +
                '}';
    }
}
