package com.tracfone.service.model.response;

import com.tracfone.service.model.request.TracfoneOneNpaNxx2Carrier;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Gaurav.Sharma
 */
public class TFOneNpaNxx2Carrier {

    private List<TracfoneOneNpaNxx2Carrier> successRecords;
    private List<TracfoneOneNpaNxx2Carrier> failedRecords;
        
    public TFOneNpaNxx2Carrier(){
        successRecords = new ArrayList<>();
        failedRecords = new ArrayList<>();
    }
    
    public List<TracfoneOneNpaNxx2Carrier> getSuccessRecords() {
        return successRecords;
    }

    public void setSuccessRecords(List<TracfoneOneNpaNxx2Carrier> successRecords) {
        this.successRecords = successRecords;
    }

    public List<TracfoneOneNpaNxx2Carrier> getFailedRecords() {
        return failedRecords;
    }

    public void setFailedRecords(List<TracfoneOneNpaNxx2Carrier> failedRecords) {
        this.failedRecords = failedRecords;
    }

    @Override
    public String toString() {
        return "TFOneNpaNxx2Carrier{" + "successRecords=" + successRecords + ", failedRecords=" + failedRecords + '}';
    }
}
