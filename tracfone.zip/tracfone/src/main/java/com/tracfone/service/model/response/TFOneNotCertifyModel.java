package com.tracfone.service.model.response;
/**
 * @author Thejaswini
 */
public class TFOneNotCertifyModel {
    private String objId;
    private String dev;
    private String parentId;
    private String partClassObjId;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getDev() {
        return dev;
    }

    public void setDev(String dev) {
        this.dev = dev;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getPartClassObjId() {
        return partClassObjId;
    }

    public void setPartClassObjId(String partClassObjId) {
        this.partClassObjId = partClassObjId;
    }

    @Override
    public String toString() {
        return "TFOneNotCertifyModel{" +
                "objId='" + objId + '\'' +
                ", dev='" + dev + '\'' +
                ", parentId='" + parentId + '\'' +
                ", partClassObjId='" + partClassObjId + '\'' +
                '}';
    }
}
