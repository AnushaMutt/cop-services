/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.controller;

import javax.ejb.Singleton;
import javax.naming.NamingException;

/**
 *
 * @author user
 */
@Singleton
public class COPConfiguration {
     public String getCOPProperty(String propertyName) throws NamingException {  
     String propertyValue = "";
     return propertyValue;
}
}
