package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneCarrierControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.controller.TracfoneTransactionWizardControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TFRatePlan;
import com.tracfone.service.model.request.TracfoneOneActionItemId;
import com.tracfone.service.model.request.TracfoneOneCarrierSubscriber;
import com.tracfone.service.model.request.TracfoneOneNewTransaction;
import com.tracfone.service.model.request.TracfoneOneSearchServicePlanModel;
import com.tracfone.service.model.request.TracfoneOneWizardArchive;
import com.tracfone.service.model.response.TFOneActionItemBucket;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneCarrierChildPlan;
import com.tracfone.service.model.response.TFOneCarrierRatePlan;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneCarrierSubscriber;
import com.tracfone.service.model.response.TFOneDatabaseEnvironment;
import com.tracfone.service.model.response.TFOneFeatures;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneRPFeatureNameList;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import com.tracfone.service.model.response.TFOneServicePlan;
import com.tracfone.service.model.response.TFOneTransactionArchive;
import com.tracfone.service.model.response.TFTransactionCarrier;
import com.tracfone.service.model.response.TracfoneOneViewActionItems;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/**
 * @author Srinivas Murthy Pulavarthy
 */
@Path("transactions")
public class TracfoneOneTransactionWizardResource {

    @Context
    private SecurityContext securityContext;

    private static Logger LOGGER = LogManager.getLogger(TracfoneOneTransactionWizardResource.class);
    
    private static Gson gson = new GsonBuilder().serializeNulls().create();
    
    @EJB
    private TracfoneTransactionWizardControllerLocal tracfoneOneTransactionWizardController;
    
    @EJB
    private TracfoneControllerLocalAction tracfoneControllerAction;
        
    @EJB
    private TracfoneCarrierControllerLocal tracfoneOneCarrierController;
    
    @POST
    @Path("carriers/inquire")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response inquireSubscriberProfile(final TracfoneOneCarrierSubscriber subscriberInfo) {
       TFOneCarrierSubscriber carrierInfoResponse  = null;
        try {
            carrierInfoResponse = tracfoneOneCarrierController.inquireSubscriber(getUserFromPrincipal().getUserId(), subscriberInfo);
        } 
        catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);            
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(carrierInfoResponse), MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("carriers")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarriers() { 
        List<TFTransactionCarrier> carriers = null;
        
        try {
            carriers = tracfoneOneTransactionWizardController.getCarriers(getUserFromPrincipal().getUserId(), true);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);            
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();

        }
        return Response.ok(gson.toJson(carriers), MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("carriers/{carrier}/rateplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getRatePlan(@PathParam("carrier") String carrier) {
        TFOneCarrierRatePlan tfOneCarrierRatePlan = null;
        try {
            tfOneCarrierRatePlan = tracfoneOneTransactionWizardController.getCarrierRatePlan(getUserFromPrincipal().getUserId(), carrier);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);            
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();

        }
        return Response.ok(gson.toJson(tfOneCarrierRatePlan), MediaType.APPLICATION_JSON).build();
    }

    @GET
    @Path("carriers/rateplans/{rateplan}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getRatePlanDefaultProfile(@PathParam("rateplan") String ratePlanName) {
        TFOneCarrierRatePlan tfOneCarrierRatePlan = null;
        try {
            tfOneCarrierRatePlan = tracfoneOneTransactionWizardController.getCarrierRatePlanDefaultProfile(getUserFromPrincipal().getUserId(), ratePlanName);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneCarrierRatePlan), MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("carriers/profile/{profileId}/serviceplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getServicePlansForProfileId(@PathParam("profileId") String profileId) {
        List<TFOneServicePlan> tfOneServicePlans = null;
        try {
            tfOneServicePlans = tracfoneOneTransactionWizardController.getServicePlansForProfileId(getUserFromPrincipal().getUserId(), profileId);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);            
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();

        }
        return Response.ok(gson.toJson(tfOneServicePlans), MediaType.APPLICATION_JSON).build();
    }
     
    @GET
    @Path("carriers/profile/{profileId}/serviceplan/{servicePlanId}/buckets")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBucketsForProfileIdAndServicePlan(@PathParam("profileId") String profileId,  @PathParam("servicePlanId") String servicePlanId) {
        List<TFOneActionItemBucket> tfOneActionItemBuckets  = null;
        try {
            tfOneActionItemBuckets = 
                    tracfoneOneTransactionWizardController.getBucketsForProfileIdAndServicePlan(getUserFromPrincipal().getUserId(), profileId, servicePlanId);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);            
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();

        }
        return Response.ok(gson.toJson(tfOneActionItemBuckets), MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("carriers/{carrier}/serviceplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getServicePlans(@PathParam("carrier") String carrier) {
        TFOneCarrierServicePlan tfOneCarrierServicePlan = null;
        try {
            tfOneCarrierServicePlan = tracfoneOneTransactionWizardController.getCarrierServicePlans(getUserFromPrincipal().getUserId(), carrier);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);            
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();

        }
        return Response.ok(gson.toJson(tfOneCarrierServicePlan), MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("carriers/{carrier}/childplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierChildPlans(@PathParam("carrier") String carrier) {
        
        TFOneCarrierChildPlan tfOneCarrierChildPlan = new TFOneCarrierChildPlan();
        try {
            tfOneCarrierChildPlan = tracfoneOneTransactionWizardController.getCarrierChildPlans(getUserFromPrincipal().getUserId(), carrier);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);            
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();

        }
        return Response.ok(gson.toJson(tfOneCarrierChildPlan), MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("carriers/{carrier}/features/{profileId}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getFeatures(@PathParam("carrier") String carrier, @PathParam("profileId") final String profileId) { 
        TFOneRatePlanProfile tfOneRatePlanProfile = null;
        try {
            tfOneRatePlanProfile = tracfoneOneTransactionWizardController.getFeatures(getUserFromPrincipal().getUserId(), profileId);
        } catch (TracfoneOneException tfoEx) {
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        
        return Response.ok(gson.toJson(tfOneRatePlanProfile), MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("carriers/{carrier}/buckets")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getRatePlanBuckets(final TFRatePlan tfRatePlan) {
        List<TFOneActionItemBucket> tfOneActionItemBuckets  = null;
        try {
            tfOneActionItemBuckets = tracfoneOneTransactionWizardController.getBuckets(getUserFromPrincipal().getUserId(),tfRatePlan);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);            
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();

        }
        return Response.ok(gson.toJson(tfOneActionItemBuckets), MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("carriers/{carrier}/transaction")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertTransactionWizard(final TracfoneOneNewTransaction tfOneNewTransaction) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneOneTransactionWizardController.insertTransaction(tfOneNewTransaction, getUserFromPrincipal().getUserId() , getUserFromPrincipal().getDescription());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
           int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("carriers/{carrier}/transaction/{aid}/status")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getTransactionStatus(@PathParam("aid") final String actionItemId) {
        TracfoneOneViewActionItems aidResponse = null;
        try {
            if(actionItemId!= null && !actionItemId.isEmpty()){
              TracfoneOneActionItemId tracfoneOneActionItemId = new TracfoneOneActionItemId();
              List<String> actionItemIds = new ArrayList();
              actionItemIds.add(actionItemId);
              tracfoneOneActionItemId.setActionItemId(actionItemIds);
              aidResponse = tracfoneControllerAction.viewActionitemId(tracfoneOneActionItemId, getUserFromPrincipal().getUserId());
            }
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
             int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            LOGGER.error(tfoAuthEx.getMessage(), tfoAuthEx);
             int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(aidResponse), MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("carriers/history")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getTransactionsInsertedByUser(final TFOneDatabaseEnvironment dbEnv) { 
        List<TFOneTransactionArchive> tfOneTransactionArchive = null;
        try {
            tfOneTransactionArchive = tracfoneOneTransactionWizardController.getTransactionsInsertedByUser(getUserFromPrincipal().getUserId(), getUserFromPrincipal().getUserId(), dbEnv.getDescription());
        } catch (TracfoneOneException tfoEx) {
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneTransactionArchive), MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("histories")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllTransactionsInserted(final TFOneDatabaseEnvironment dbEnv) {
        
      
        List<TFOneTransactionArchive> tfOneTransactionArchive = null;
        try {
            tfOneTransactionArchive = tracfoneOneTransactionWizardController.getAllTransactionsInserted(getUserFromPrincipal().getUserId(), dbEnv.getDescription());
        } catch (TracfoneOneException tfoEx) {
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneTransactionArchive), MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("histories/extenddeactdate")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response extendDeactDate(List<TracfoneOneWizardArchive> request) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneOneTransactionWizardController.extendDeactDateManual(request);
        } catch (TracfoneOneException tfoEx) {
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("carriers/extenddeactdefault")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response extendDeactDateDefault(TracfoneOneWizardArchive request) {
        TFOneGeneralResponse tfOneResponse = null;
       
        try {
            tfOneResponse = tracfoneOneTransactionWizardController.extendDeactDateDefault(request);
        } catch (TracfoneOneException tfoEx) {
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriers/profilesforcarrier")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getProfilesForFeature(TracfoneOneSearchServicePlanModel tracfoneOneSearchServicePlanModel) {
        List<TFOneRatePlanProfile> tfOneRatePlanProfiles = null;
        try {
            tfOneRatePlanProfiles = tracfoneOneTransactionWizardController.getProfilesForFeature(getUserFromPrincipal().getUserId(), tracfoneOneSearchServicePlanModel);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();

        }
        return Response.ok(gson.toJson(tfOneRatePlanProfiles), MediaType.APPLICATION_JSON).build();
    }

    @GET
    @Path("carriers/{profileid}/rateplanforprofile")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getRatePlanByProfile(@PathParam("profileid") String profileid) {
        List<TFOneFeatures> tfOneFeatures = null;
        try {
            tfOneFeatures = tracfoneOneTransactionWizardController.getRatePlanByProfile(getUserFromPrincipal().getUserId(), profileid);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();

        }
        return Response.ok(gson.toJson(tfOneFeatures), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieve the list of feature from master
     *
     * @return
     */
    @GET
    @Path("carriers/viewallmasterfeatures")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllMasterFeatures() {
        List<TFOneRPFeatureNameList> features = null;

        try {
            features = tracfoneOneTransactionWizardController.getAllMasterFeatures();
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(features), MediaType.APPLICATION_JSON).build();
    }

    
    /**
     * Retrieves the user object making request from the principal.
     *
     * @return
     */
    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }
}