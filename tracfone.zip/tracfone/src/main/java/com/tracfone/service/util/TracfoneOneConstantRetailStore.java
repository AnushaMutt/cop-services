package com.tracfone.service.util;

public interface TracfoneOneConstantRetailStore {
    String C_RTL_STORE_SP_CALL = "Calling SP C_RTL_STORE_SP_N";
    String C_RTL_STORE_SP_N_DONE = "Done with SP C_RTL_STORE_SP_N for trait ";

    String TRACFONE_GET_ALL_CARRIERS = "TFE1400";
    String TRACFONE_GET_ALL_CARRIERS_MESSAGE = "Unable to get all Carrier";

    String TRACFONE_GET_ALL_BRANDS = "TFE1401";
    String TRACFONE_GET_ALL_BRANDS_MESSAGE = "Unable to get all Brand";

    String TRACFONE_GET_ALL_TECHS = "TFE1402";
    String TRACFONE_GET_ALL_TECHS_MESSAGE = "Unable to get all Techs";

    String TRACFONE_GET_ALL_CARRIER_DETAILS = "TFE1403";
    String TRACFONE_GET_ALL_CARRIER_DETAILS_MESSAGE = "Unable to get all Carrier Detail";

    String TRACFONE_GET_ALL_TRAIT_LOGIC_RULES = "TFE1404";
    String TRACFONE_GET_ALL_TRAIT_LOGIC_RULES_MESSAGE = "Unable to get all Trait Logic Rules";

    String TRACFONE_GET_ALL_CARRIER_PREF_GROUPS = "TFE1405";
    String TRACFONE_GET_ALL_CARRIER_PREF_GROUPS_MESSAGE = "Unable to get all Carrier Pref Groups";

    String TRACFONE_GET_ALL_CARRIER_PREFS = "TFE1406";
    String TRACFONE_GET_ALL_CARRIER_PREFS_MESSAGE = "Unable to get all Carrier Pref Details";

    String TRACFONE_GET_ALL_PARENTS = "TFE1407";
    String TRACFONE_GET_ALL_PARENTS_MESSAGE = "Unable to get all Parents";

    String TRACFONE_GET_ALL_MASTERS = "TFE1408";
    String TRACFONE_GET_ALL_MASTERS_MESSAGE = "Unable to get all Masters";

    String TRACFONE_GET_ALL_PARENT_RULES = "TFE1409";
    String TRACFONE_GET_ALL_PARENT_RULES_MESSAGE = "Unable to get all Parent Rules";

    String TRACFONE_ADD_CARRIER = "TFE1410";
    String TRACFONE_ADD_CARRIER_MESSAGE = "Unable to add a Carrier";

    String TRACFONE_ADD_BRAND = "TFE1411";
    String TRACFONE_ADD_BRAND_MESSAGE = "Unable to add a Brand";

    String TRACFONE_ADD_TECH = "TFE1412";
    String TRACFONE_ADD_TECH_MESSAGE = "Unable to add a Tech";

    String TRACFONE_ADD_CARRIER_DETAIL = "TFE1413";
    String TRACFONE_ADD_CARRIER_DETAIL_MESSAGE = "Unable to add a Carrier Detail";

    String TRACFONE_DELETE_CARRIER_PREF = "TFE1416";
    String TRACFONE_DELETE_CARRIER_PREF_MESSAGE = "Unable to delete a Carrier Pref Detail";

    String TRACFONE_ADD_CARRIER_PREF_GROUP = "TFE1415";
    String TRACFONE_ADD_CARRIER_PREF_GROUP_MESSAGE = "Unable to add a Carrier Pref Group";

    String TRACFONE_ADD_CARRIER_PREF = "TFE1416";
    String TRACFONE_ADD_CARRIER_PREF_MESSAGE = "Unable to add a Carrier Pref Detail";

    String TRACFONE_ADD_PARENT = "TFE1417";
    String TRACFONE_ADD_PARENT_MESSAGE = "Unable to add a Parent";

    String TRACFONE_ADD_MASTER = "TFE1418";
    String TRACFONE_ADD_MASTER_MESSAGE = "Unable to add a Master";

    String TRACFONE_ADD_PARENT_RULE = "TFE1419";
    String TRACFONE_ADD_PARENT_RULE_MESSAGE = "Unable to add a Parent Rule";

    String TRACFONE_UPDATE_CARRIER = "TFE1410";
    String TRACFONE_UPDATE_CARRIER_MESSAGE = "Unable to update a Carrier";

    String TRACFONE_UPDATE_BRAND = "TFE1411";
    String TRACFONE_UPDATE_BRAND_MESSAGE = "Unable to update a Brand";

    String TRACFONE_UPDATE_TECH = "TFE1412";
    String TRACFONE_UPDATE_TECH_MESSAGE = "Unable to update a Tech";

    String TRACFONE_UPDATE_CARRIER_DETAIL = "TFE1413";
    String TRACFONE_UPDATE_CARRIER_DETAIL_MESSAGE = "Unable to update a Carrier Detail";

    String TRACFONE_UPDATE_CARRIER_PREF_GROUP = "TFE1415";
    String TRACFONE_UPDATE_CARRIER_PREF_GROUP_MESSAGE = "Unable to update a Carrier Pref Group";

    String TRACFONE_UPDATE_PARENT = "TFE1417";
    String TRACFONE_UPDATE_PARENT_MESSAGE = "Unable to update a Parent";

    String TRACFONE_UPDATE_MASTER = "TFE1418";
    String TRACFONE_UPDATE_MASTER_MESSAGE = "Unable to update a Master";

    String TRACFONE_UPDATE_PARENT_RULE = "TFE1419";
    String TRACFONE_UPDATE_PARENT_RULE_MESSAGE = "Unable to update a Parent Rule";

    String TRACFONE_ADD_TRAIT_LOGIC_RULE = "TFE1420";
    String TRACFONE_ADD_TRAIT_LOGIC_RULE_MESSAGE = "Unable to add a Trait Logic Rule";

    String TRACFONE_UPDATE_TRAIT_LOGIC_RULE = "TFE1421";
    String TRACFONE_UPDATE_TRAIT_LOGIC_RULE_MESSAGE = "Unable to update a Trait Logic Rule";

    String TRACFONE_SEARCH_TP_NORMS = "TFE1422";
    String TRACFONE_SEARCH_TP_NORMS_MESSAGE = "Unable to search for TP Norms";

    String TRACFONE_GET_ALL_STATES = "TFE1423";
    String TRACFONE_GET_ALL_STATES_MESSAGE = "Unable to get all States";

    String TRACFONE_UPDATE_TP_NORM = "TFE1424";
    String TRACFONE_UPDATE_TP_NORM_MESSAGE = "Unable to update TP Norms";

    String TRACFONE_RUN_TRAITS = "TFE1425";
    String TRACFONE_RUN_TRAITS_MESSAGE = "Unable to Run Traits";

    String TRACFONE_INSERT_TP_NORM = "TFE1426";
    String TRACFONE_INSERT_TP_NORM_MESSAGE = "Unable to insert TP Norms";

    String TRACFONE_VIEW_AVAILABILITY = "TFE1427";
    String TRACFONE_VIEW_AVAILABILITY_MESSAGE = "Unable to view Availability";

    String TRACFONE_CLOSE_STORE = "TFE1428";
    String TRACFONE_CLOSE_STORE_MESSAGE = "Unable to close Stores";

    String TRACFONE_ADD_STORE = "TFE1429";
    String TRACFONE_ADD_STORE_MESSAGE = "Unable to open Stores";

    String TRACFONE_SEARCH_RETAIL_LOCATIONS = "TFE1430";
    String TRACFONE_SEARCH_RETAIL_LOCATIONS_MESSAGE = "Unable to search for Retail Locations";

    String TRACFONE_UPDATE_RETAIL_LOCATIONS = "TFE1431";
    String TRACFONE_UPDATE_RETAIL_LOCATIONS_MESSAGE = "Unable to update radius for Retail Locations";

    String TRACFONE_RUN_TP_NORM_TRAITS = "TFE1432";
    String TRACFONE_RUN_TP_NORM_TRAITS_MESSAGE = "Unable to Run TP Norm Traits";

    String TRACFONE_GET_TP_NORM_STATS = "TFE1433";
    String TRACFONE_GET_TP_NORM_STATS_MESSAGE = "Unable to get TP Norm Stats";

    String TRACFONE_REOPEN_STORE = "TFE1434";
    String TRACFONE_REOPEN_STORE_MESSAGE = "Unable to reopen Stores";

    String TRACFONE_GET_TRAIT_DETAILS = "TFE1435";
    String TRACFONE_GET_TRAIT_DETAILS_MESSAGE = "Unable to get Trait Details for the Location";

    String TRACFONE_DELETE_STORES = "TFE1436";
    String TRACFONE_DELETE_STORES_MESSAGE = "Unable to delete Stores";

    String TRACFONE_APPROVE_REJECT_TRAITS = "TFE1437";
    String TRACFONE_APPROVE_REJECT_TRAITS_MESSAGE = "Unable to approve or reject the update to radius for Retail Locations";

    String TRACFONE_GET_ALL_RADIUS = "TFE1438";
    String TRACFONE_GET_ALL_RADIUS_MESSAGE = "Unable to get all Radius";

    String TRACFONE_ANALYSE_TRAITS = "TFE1439";
    String TRACFONE_ANALYSE_TRAITS_MESSAGE = "Unable to analyse Traits";

    String TRACFONE_SEARCH_CLOSED_STORES = "TFE1440";
    String TRACFONE_SEARCH_CLOSED_STORES_MESSAGE = "Unable to search for Closed Stores";

    String TRACFONE_LAST_TRAIT_RUN_DATE = "TFE1441";
    String TRACFONE_LAST_TRAIT_RUN_DATE_MESSAGE = "Unable to get last Trait run Date";

    String TRACFONE_RUN_STORE_TRAITS = "TFE1442";
    String TRACFONE_RUN_STORE_TRAITS_MESSAGE = "Unable to Run Store Trait";

    String TRACFONE_UPDATE_RANK = "TFE1443";
    String TRACFONE_UPDATE_RANK_MESSAGE = "Unable to update a Rank";

    String TRACFONE_RUN_TRAITS_SUMMARY = "TFE1444";
    String TRACFONE_RUN_TRAITS_SUMMARY_MESSAGE = "Unable to get run Traits Summary";

    String TRACFONE_COUNT_STORE = "TFE1445";
    String TRACFONE_COUNT_STORE_MESSAGE = "Unable to count Stores";

    String TRACFONE_CARRIER_CREATE_SUCCESS = "Carrier created successfully.";
    String TRACFONE_BRAND_CREATE_SUCCESS = "Brand created successfully.";
    String TRACFONE_TECH_CREATE_SUCCESS = "Tech created successfully.";
    String TRACFONE_CARRIER_DETAIL_CREATE_SUCCESS = "Carrier Detail created successfully.";
    String TRACFONE_CARRIER_PREF_GROUP_CREATE_SUCCESS = "Carrier Pref Group created successfully.";
    String TRACFONE_CARRIER_PREF_CREATE_SUCCESS = "Carrier Pref created successfully.";
    String TRACFONE_PARENT_CREATE_SUCCESS = "Parent created successfully.";
    String TRACFONE_MASTER_CREATE_SUCCESS = "Master created successfully.";
    String TRACFONE_PARENT_RULE_CREATE_SUCCESS = "Parent Rule created successfully.";
    String TRACFONE_TRAIT_LOGIC_RULE_CREATE_SUCCESS = "Trait Logic Rule created successfully.";
    String TRACFONE_TP_NORMS_CREATE_SUCCESS = "TP Norms created successfully.";
    String TRACFONE_STORE_OPEN_SUCCESS = "Stores opened successfully.";
    String TRACFONE_CLOSE_STORE_SUCCESS = "Stores closed successfully.";
    String TRACFONE_REOPEN_STORE_SUCCESS = "Stores reopened successfully.";
    String TRACFONE_DELETE_STORE_SUCCESS = "Stores deleted successfully.";

    String TRACFONE_CARRIER_UPDATE_SUCCESS = "Carrier updated successfully.";
    String TRACFONE_BRAND_UPDATE_SUCCESS = "Brand updated successfully.";
    String TRACFONE_TECH_UPDATE_SUCCESS = "Tech updated successfully.";
    String TRACFONE_CARRIER_DETAIL_UPDATE_SUCCESS = "Carrier Detail updated successfully.";
    String TRACFONE_CARRIER_PREF_GROUP_UPDATE_SUCCESS = "Carrier Pref Group updated successfully.";
    String TRACFONE_PARENT_UPDATE_SUCCESS = "Parent updated successfully.";
    String TRACFONE_MASTER_UPDATE_SUCCESS = "Master updated successfully.";
    String TRACFONE_PARENT_RULE_UPDATE_SUCCESS = "Parent Rule update successfully.";
    String TRACFONE_TRAIT_LOGIC_RULE_UPDATE_SUCCESS = "Trait Logic Rule updated successfully.";
    String TRACFONE_TP_NORM_UPDATE_SUCCESS = "TP Norms updated successfully.";
    String TRACFONE_UPDATE_RETAIL_LOCATION_SUCCESS = "Radius updated for Retail Locations successfully.";
    String TRACFONE_APPROVE_TRAIT_SUCCESS = "Approved Traits for radius updates successfully.";
    String TRACFONE_REJECT_TRAIT_SUCCESS = "Rejected Traits for radius updates successfully.";

    String TRACFONE_RUN_TRAITS_SUCCESS = "Traits were run successfully.";
    String TRACFONE_RUN_TP_NORM_TRAITS_SUCCESS = "TP Norm Traits were run successfully.";

    String TRACFONE_RUN_STORE_TRAITS_SUCCESS = "Store Trait run successfully.";

    String TRACFONE_CARRIER_PREF_DELETE_SUCCESS = "Carrier Pref removed successfully.";
    String TRACFONE_RANK_UPDATE_SUCCESS = "Rank updated successfully.";

    String TRACFONE_GET_CARRIER_DETAILS = "SELECT CD.OBJID, CD.STATUS, CD.INSERT_DATE, CD.UPDATE_DATE, " +
            "(select C.carrier from C_RTL_CARRIER C where C.objid = CD.CDTL2CARRIER) CARRIER, " +
            "(select B.BRAND from C_RTL_BRAND B where B.objid = CD.CDTL2BRAND) BRAND, " +
            "(select T.TECH from C_RTL_TECH T where T.objid = CD.CDTL2TECH) TECH FROM C_RTL_CARRIER_DTL CD " +
            "where CD.STATUS = 'A'";

    String TRACFONE_GET_CARRIER_DETAILS_BY_BRAND = TRACFONE_GET_CARRIER_DETAILS + " AND CD.CDTL2BRAND = ?";

    String TRACFONE_GET_CARRIER_PREFS = "select P.OBJID, P.CPREF2CARRIER_PREF_GRP, P.CPREF2CARRIER_DTL, P.RANK, " +
            "(SELECT C.CARRIER FROM C_RTL_CARRIER C WHERE OBJID IN (SELECT CD.CDTL2CARRIER FROM C_RTL_CARRIER_DTL CD WHERE CD.OBJID = P.CPREF2CARRIER_DTL)) CARRIER, " +
            "(SELECT C.BRAND FROM C_RTL_BRAND C WHERE OBJID IN (SELECT CD.CDTL2BRAND FROM C_RTL_CARRIER_DTL CD WHERE CD.OBJID = P.CPREF2CARRIER_DTL)) BRAND, " +
            "(SELECT C.TECH FROM C_RTL_TECH C WHERE OBJID IN (SELECT CD.CDTL2TECH FROM C_RTL_CARRIER_DTL CD WHERE CD.OBJID = P.CPREF2CARRIER_DTL)) TECH " +
            "from C_RTL_CARRIER_PREF P where P.CPREF2CARRIER_PREF_GRP = ?";

    String TRACFONE_TP_NORMS_START = "select * from (select a.*, rownum as rnum from (";

    String TRACFONE_TP_NORMS_COUNT = "select count(1) from (";

    String TRACFONE_TP_NORMS_SELECT = "SELECT N.OBJID, N.TP2ZIP,\n" +
            "(SELECT C.CARRIER FROM C_RTL_CARRIER C WHERE   OBJID IN (SELECT CD.CDTL2CARRIER FROM C_RTL_CARRIER_DTL CD WHERE CD.OBJID = N.TP2CARRIER_DTL )) CARRIER,\n" +
            "(SELECT C.status FROM C_RTL_CARRIER C WHERE   OBJID IN (SELECT CD.CDTL2CARRIER FROM C_RTL_CARRIER_DTL CD WHERE CD.OBJID = N.TP2CARRIER_DTL )) CARRIER_status,\n" +
            "(SELECT C.BRAND FROM C_RTL_BRAND C WHERE OBJID IN (SELECT CD.CDTL2BRAND FROM C_RTL_CARRIER_DTL CD WHERE CD.OBJID = N.TP2CARRIER_DTL ) ) BRAND,\n" +
            "(SELECT C.status FROM C_RTL_BRAND C WHERE  OBJID IN (SELECT CD.CDTL2BRAND FROM C_RTL_CARRIER_DTL CD WHERE CD.OBJID = N.TP2CARRIER_DTL ) ) BRAND_status,\n" +
            "(SELECT C.TECH FROM C_RTL_TECH C WHERE   OBJID IN (SELECT CD.CDTL2TECH FROM C_RTL_CARRIER_DTL CD WHERE CD.OBJID = N.TP2CARRIER_DTL )) TECH,\n" +
            "(SELECT C.status FROM C_RTL_TECH C WHERE  OBJID IN (SELECT CD.CDTL2TECH FROM C_RTL_CARRIER_DTL CD WHERE CD.OBJID = N.TP2CARRIER_DTL )) TECH_status,\n" +
            "N.COVERAGE, N.COVERAGE_NOTES  ";

    String TRACFONE_GET_TP_NORMS_BY_STATES = " FROM C_RTL_TP_NORM N, C_RTL_ZIP_GEOLOC G WHERE N.TP2ZIP = G.ZIP AND ";

    String TRACFONE_GET_TP_NORMS = " FROM C_RTL_TP_NORM N WHERE ";

    String TRACFONE_TP_NORMS_END = ")a where carrier_status = 'A' and brand_status = 'A' and tech_status = 'A'";

    String TRACFONE_GET_STATES = "select distinct state from C_RTL_ZIP_GEOLOC where state is not null order by state";

    String TRACFONE_RUN_TRAITS_FOR_PARENT = "select distinct rp.objid parent_id, rm.store_name, " +
            "rl.store_num, rl.zip, GET_LOC_RADIUS_BY_TRAIT(rt.objid) radius " +
            "from c_rtl_parent rp left outer join c_rtl_master rm on rm.master2parent = rp.objid " +
            "left outer join c_rtl_location rl on rl.location2master = rm.objid left outer join c_rtl_trait rt on rt.trait2location = rl.objid " +
            "where 1=1 and rt.status = 'A' and rl.status = 'A' and rm.status = 'A' and rp.status = 'A' and rp.objid = ? order by rl.store_num";

    String TRACFONE_UPDATE_RUN_START_DATE = "update c_rtl_job_task set x_start_run = sysdate where 1=1 and x_name = 'TP_NORM_UPDATE'";

    String TRACFONE_UPDATE_RUN_END_DATE = "update c_rtl_job_task set x_end_run = sysdate where 1=1 and x_name = 'TP_NORM_UPDATE'";

    String TRACFONE_GET_LAST_RUN_DATE = "select ijt.x_end_run from c_rtl_job_task ijt where 1=1 and ijt.x_name = 'TP_NORM_UPDATE'";

    String TRACFONE_GET_ZIPS_UPDATED_COUNT = "select count(distinct rtp.tp2zip) total_zips from c_rtl_tp_norm rtp " +
            "where 1=1 and rtp.update_date >= (select ijt.x_end_run from c_rtl_job_task ijt where 1=1 and ijt.x_name = 'TP_NORM_UPDATE')";

    String TRACFONE_GET_STORES_UPDATED_COUNT = "select count(1) from c_rtl_location rl " +
            "join c_rtl_trait rt on rt.trait2location = rl.objid where 1=1 and rt.insert_date < (select ijt.x_end_run from c_rtl_job_task ijt where 1=1 and ijt.x_name = 'TP_NORM_UPDATE') " +
            "and rt.status = 'A' and rl.status = 'A' and rl.zip in (select distinct rtp.tp2zip from c_rtl_tp_norm rtp where 1=1 " +
            "and rtp.update_date >= (select ijt.x_end_run from c_rtl_job_task ijt where 1=1 and ijt.x_name = 'TP_NORM_UPDATE'))";

    String TRACFONE_RUN_TRAITS_FOR_TP_NORM = "select distinct rtp.tp2zip, TO_CHAR(rtp.update_date, 'yyyy-MM-DD') update_date " +
            "from c_rtl_tp_norm rtp where 1=1 and " +
            "rtp.update_date >= (select ijt.x_end_run from c_rtl_job_task ijt where 1=1 and ijt.x_name = 'TP_NORM_UPDATE')";

    String TRACFONE_GET_LOCATIONS_FROM_ZIP = "select rp.objid parent_id, rm.store_name, rl.store_num, rl.zip, get_loc_radius_by_trait(rt.objid) radius " +
            "from c_rtl_parent rp " +
            "join c_rtl_master rm on rm.master2parent = rp.objid " +
            "join c_rtl_location rl on rl.location2master = rm.objid " +
            "join c_rtl_trait rt on rt.trait2location = rl.objid " +
            "where 1=1 and rt.insert_date < TO_DATE(?, 'yyyy-MM-DD') and rt.status = 'A' " +
            "and rl.zip = ? and rl.status = 'A'";

    String TRACFONE_CLOSE_STORES = "update c_rtl_location set update_date = sysdate, status = 'C' where ";

    String TRACFONE_SEARCH_LOCATIONS = "select distinct rl.objid, rm.objid master_id, rp.objid parent_id, rm.store_name, " +
            "rl.store_num, rz.state, rl.zip, GET_LOC_RADIUS_BY_TRAIT(rt.objid) radius, rl.UPDATE_DATE from c_rtl_parent rp " +
            "left outer join c_rtl_master rm on rm.master2parent = rp.objid " +
            "left outer join c_rtl_location rl on rl.location2master = rm.objid " +
            "left outer join c_rtl_trait rt on rt.trait2location = rl.objid " +
            "left outer join c_rtl_zip_geoloc rz on rz.zip = rl.zip " +
            "where 1=1 and rt.status = 'A' and rl.status = 'A' and rm.status = 'A' and rp.status = 'A' and rp.objid = ? AND ";

    String TRACFONE_COUNT_LOCATIONS = "select count(distinct rl.objid) as count from c_rtl_parent rp\n" +
            "            left outer join c_rtl_master rm on rm.master2parent = rp.objid\n" +
            "            left outer join c_rtl_location rl on rl.location2master = rm.objid\n" +
            "            left outer join c_rtl_trait rt on rt.trait2location = rl.objid\n" +
            "            left outer join c_rtl_zip_geoloc rz on rz.zip = rl.zip\n" +
            "            where 1=1 and rt.status = 'A' and rl.status = 'A' and rm.status = 'A' and rp.status = 'A' and rp.objid = ?";

    String TRACFONE_INACTIVE_PARENT = "update c_rtl_parent set status = 'C' where objid = ?";

    String TRACFONE_SEARCH_CLOSED_LOCATIONS = "select distinct rl.objid, rm.objid master_id, rp.objid parent_id, rm.store_name, " +
            "rl.store_num, rz.state, rl.zip, GET_LOC_RADIUS_BY_TRAIT(rt.objid) radius, rl.update_date from c_rtl_parent rp " +
            "left outer join c_rtl_master rm on rm.master2parent = rp.objid " +
            "left outer join c_rtl_location rl on rl.location2master = rm.objid " +
            "left outer join c_rtl_trait rt on rt.trait2location = rl.objid " +
            "left outer join c_rtl_zip_geoloc rz on rz.zip = rl.zip " +
            "where 1=1 and rt.status = 'A' and rl.status = 'C' and rm.status = 'A' and rp.status = 'A' and rp.objid = ? " +
            "AND TRUNC(rl.update_date) between to_date(? ,'yyyy-mm-dd') and to_date(? ,'yyyy-mm-dd') AND ";

    String TRACFONE_GET_BRAND_FOR_PARENT = "select rb.objid from c_rtl_parent rp " +
            "join c_rtl_parent_rule rpr on rpr.rule2parent = rp.objid " +
            "join c_rtl_carrier_pref_grp rcpg on rpr.rule2cpref_grp_trait = rcpg.objid " +
            "join c_rtl_brand rb on rcpg.cprefgrp2brand = rb.objid where 1=1 and rp.objid = ?";

    String TRACFONE_GET_ALL_BRAND_MAPPINGS_FOR_PARENT = "select rcd.objid, rc.carrier, crt.tech from c_rtl_carrier_dtl rcd " +
            "join c_rtl_carrier rc on rcd.cdtl2carrier = rc.objid join c_rtl_tech crt on rcd.cdtl2tech = crt.objid " +
            "where 1=1 and rcd.status = 'A' and rcd.cdtl2brand in (" + TRACFONE_GET_BRAND_FOR_PARENT + ") " +
            "order by rc.carrier, crt.tech";

    String TRACFONE_GET_BRAND_MAPPINGS_FOR_PARENT = "select rcd.objid, rc.carrier, crt.tech from c_rtl_carrier_dtl rcd " +
            "join c_rtl_carrier rc on rcd.cdtl2carrier = rc.objid " +
            "join c_rtl_tech crt on rcd.cdtl2tech = crt.objid " +
            "where 1=1 and rcd.status = 'A' and " +
            "rcd.cdtl2brand = ? " +
            "order by rc.carrier, crt.tech";

    String TRACFONE_VIEW_AVAILABILITY_PART1 = "select distinct rp.retailer, rm.store_name, rl.store_num, rz.zip, " +
            "rz.state, rb.brand, GET_LOC_RADIUS_BY_TRAIT(rt.objid) radius";

    String TRACFONE_VIEW_AVAILABILITY_PART2 = " from c_rtl_parent rp " +
            "join c_rtl_master rm on rm.master2parent = rp.objid " +
            "join c_rtl_location rl on rl.location2master = rm.objid " +
            "join c_rtl_trait rt on rt.trait2location = rl.objid " +
            "join c_rtl_trait_dtl rtd on rtd.tdtl2trait = rt.objid " +
            "join c_rtl_zip_geoloc rz on rl.zip = rz.zip " +
            "join c_rtl_brand rb on rtd.tdtl2brand = rb.objid " +
            "where 1=1 and rt.status = 'A' and rl.status = 'A' and rm.status = 'A' and rp.status = 'A' " +
            "and rp.objid = ? AND ";

    String TRACFONE_REOPEN_STORES = "update c_rtl_location set update_date = sysdate, status = 'A' where ";

    String TRACFONE_GET_TRAIT_DETAIL = "SELECT tdtl.radius, tdtl.CARR_TRAIT, tdtl.CARR_DPLYD, tdtl.TOTAL_BUFFER_ZIP, " +
            "tdtl.TOTAL_POP, tdtl.ZIP_DPLYD, tdtl.PER_ZIP_DPLYD, tdtl.POP_DPLYD, tdtl.PER_POP_DPLYD, tdtl.FIN_ZIP_DPLYD, " +
            "tdtl.FIN_PER_ZIP_DPLYD, tdtl.FIN_POP_DPLYD, tdtl.FIN_PER_POP_DPLYD, c.carrier, b.brand, tec.tech " +
            "FROM c_rtl_carrier_dtl cdtl , c_rtl_trait_dtl tdtl, c_rtl_location l, c_rtl_trait t, " +
            "c_rtl_carrier c, c_rtl_brand b, c_rtl_tech tec " +
            "where l.objid = t.trait2location and " +
            "t.objid = tdtl.tdtl2trait and t.status = 'A' and " +
            "tdtl.TDTL2CARRIER_DTL = cdtl.objid and cdtl.status ='A' and " +
            "cdtl.CDTL2CARRIER = c.objid and " +
            "cdtl.CDTL2BRAND = b.objid and " +
            "cdtl.CDTL2TECH = tec.objid and l.objid = ?";

    String TRACFONE_DELETE_TRAIT_PREFS = "delete from c_rtl_trait_pref where tpref2trait IN (SELECT OBJID FROM c_rtl_trait WHERE ";
    String TRACFONE_DELETE_TRAIT_PREFS_TST = "delete from c_rtl_trait_pref_tst where tpref2trait IN (SELECT OBJID FROM c_rtl_trait_tst WHERE ";
    String TRACFONE_DELETE_TRAIT_DETAILS = "delete from c_rtl_trait_dtl where tdtl2trait IN (SELECT OBJID FROM c_rtl_trait WHERE ";
    String TRACFONE_DELETE_TRAIT_DETAILS_TST = "delete from c_rtl_trait_dtl_tst where tdtl2trait IN (SELECT OBJID FROM c_rtl_trait_tst WHERE ";
    String TRACFONE_DELETE_TRAITS = "delete from c_rtl_trait where ";
    String TRACFONE_DELETE_TRAITS_TST = "delete from c_rtl_trait_tst where ";
    String TRACFONE_DELETE_LOCATIONS = "delete from c_rtl_location where ";

    String TRACFONE_UPDATE_TRAIT_STATUS_CLOSED = "UPDATE C_RTL_TRAIT SET STATUS = 'C' WHERE 1=1 AND STATUS = 'A' AND TRAIT2LOCATION = ? " +
            "AND EXISTS (SELECT 1 FROM C_RTL_TRAIT WHERE 1=1 AND STATUS = 'P' AND TRAIT2LOCATION = ?)";

    String TRACFONE_UPDATE_TRAIT_STATUS_ACTIVE = "UPDATE C_RTL_TRAIT SET STATUS = 'A' WHERE 1=1 AND STATUS = 'P' AND TRAIT2LOCATION = ?";

    String TRACFONE_ACTIVE_TRAIT_COUNT = "select count(1) total from c_rtl_trait where 1=1 and status = 'A' and trait2location = ?";

    String TRACFONE_TRAIT_COUNT = "select count(1) total from c_rtl_trait where 1=1 and trait2location = ?";

    String TRACFONE_RESET_TRAIT_STATUS = "update c_rtl_trait set status = 'A' where 1=1 and " +
            "objid = (select max(objid) from c_rtl_trait where 1=1 and status = 'C' and trait2location = ?)";

    String TRACFONE_REJECT_TRAITS = "update C_RTL_TRAIT set status = 'D' where status = 'P' AND ";

    String TRACFONE_GET_RADIUS = "select distinct radius from c_rtl_trait_dtl where radius is not null and " +
            "tdtl2trait in (select objid from c_rtl_trait where status = 'A') order by radius";

    String TRACFONE_TRAIT_ANALYSIS = "select rc.carrier || ' - ' || rtc.tech as prefs from c_rtl_location rl " +
            "join c_rtl_trait_tst rt on rt.trait2location = rl.objid " +
            "join c_rtl_trait_pref_tst rtp on rtp.tpref2trait = rt.objid " +
            "join c_rtl_carrier_dtl rcd on rtp.tpref2carrier_dtl = rcd.objid " +
            "join c_rtl_carrier rc on rcd.cdtl2carrier = rc.objid " +
            "join c_rtl_tech rtc on rcd.cdtl2tech = rtc.objid " +
            "join c_rtl_brand rb on rcd.cdtl2brand = rb.objid " +
            "where 1=1 " +
            "and rb.brand = ? and rl.objid = ? and rt.status = 'A'";

    String TRACFONE_COUNT_PARENT_UPDATE_JOB_TASK = "SELECT count(1) from c_rtl_job_task where X_NAME = ?";

    String TRACFONE_INSERT_PARENT_UPDATE_JOB_TASK = "insert into c_rtl_job_task(OBJID, X_STATUS, X_NAME, X_DESCRIPTION, X_START_RUN) " +
            "values(C_RTL_JOB_TASK_SEQ.nextval, 'A', ?, 'Running Traits on this parent', SYSDATE)";

    String TRACFONE_UPDATE_START_RUN_JOB_TASK = "update c_rtl_job_task set X_START_RUN = sysdate where x_name = ?";

    String TRACFONE_GET_LAST_TRAIT_RUN_DATE = "SELECT X_END_RUN from c_rtl_job_task where X_NAME = ?";

    String TRACFONE_UPDATE_END_RUN_JOB_TASK = "update c_rtl_job_task set X_END_RUN = sysdate where x_name = ?";

    String TRACFONE_UPDATE_LAST_TRAIT_RUN_DATE = "update c_rtl_location set update_date = sysdate where OBJID = ?";

    String TRACFONE_INSERT_STORE_UPDATE_JOB_TASK = "insert into c_rtl_job_task(OBJID, X_STATUS, X_NAME, X_DESCRIPTION, X_START_RUN) " +
            "values(C_RTL_JOB_TASK_SEQ.nextval, 'A', ?, 'Running Traits on this Store', SYSDATE)";

    String TRACFONE_DELETE_CARRIER_PREF_LOG = "delete from C_RTL_CARRIER_PREF_LOG where OBJID_PREF = ?";

    String TRACFONE_UPDATE_CARRIER_PREF_RANK = "update C_RTL_CARRIER_PREF set rank = ? where objid = ?";

    String TRACFONE_GET_LAST_TRAIT_RUN_DATE_PARENT_ADMIN = "SELECT x_name, to_char(x_end_run, 'YYYY-MM-DD HH24:MI:SS') as " +
            "x_end_run FROM c_rtl_job_task where x_description = 'Running Traits on this parent' and x_name like '%PARENT_UPDATE'";

    String TRACFONE_GET_LAST_TRAIT_RUN_DATE_SUMMARY = "SELECT OBJID, X_STATUS, X_NAME, X_DESCRIPTION, X_START_RUN, X_END_RUN " +
            "from c_rtl_job_task where x_description = 'Running Traits on this parent' and " +
            "x_name like '%_PARENT_UPDATE' and X_START_RUN > sysdate - 2 order by X_END_RUN desc";

    String TRACFONE_GET_ALL_PARENT = "SELECT OBJID, STATUS, RETAILER, to_char(INSERT_DATE, 'yyyy:MM:dd HH:mm:ss'), " +
            "to_char(UPDATE_DATE, 'yyyy:MM:dd HH:mm:ss'), PARENT2USER FROM cop.C_RTL_PARENT";

    String TRACFONE_ACTIVE_PARENT = "update c_rtl_parent set status = 'A' where objid = ?";
}
