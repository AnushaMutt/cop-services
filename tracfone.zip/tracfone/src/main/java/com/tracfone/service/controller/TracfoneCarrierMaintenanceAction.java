package com.tracfone.service.controller;

import com.google.gson.Gson;
import com.mysql.jdbc.StringUtils;
import com.tracfone.ejb.entity.retail.session.CRtlArUsaMarketFacadeLocal;
import com.tracfone.ejb.entity.retail.session.CRtlArUsaPostalZipsFacadeLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneArUsaMarket;
import com.tracfone.service.model.request.TracfoneOneArUsaPostalZips;
import com.tracfone.service.model.request.TracfoneOneCarrier;
import com.tracfone.service.model.request.TracfoneOneCarrierGroup;
import com.tracfone.service.model.request.TracfoneOneCarrierPref;
import com.tracfone.service.model.request.TracfoneOneCarrierRule;
import com.tracfone.service.model.request.TracfoneOneCarrierSimPref;
import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;
import com.tracfone.service.model.request.TracfoneOneDataConfig;
import com.tracfone.service.model.request.TracfoneOneDataConfigMapping;
import com.tracfone.service.model.request.TracfoneOneGeoLoc;
import com.tracfone.service.model.request.TracfoneOneIgOrderType;
import com.tracfone.service.model.request.TracfoneOneNotCertifyModel;
import com.tracfone.service.model.request.TracfoneOneNpanxx2Carrierzones;
import com.tracfone.service.model.request.TracfoneOneOrderType;
import com.tracfone.service.model.request.TracfoneOneParent;
import com.tracfone.service.model.request.TracfoneOneThrottleFeature;
import com.tracfone.service.model.request.TracfoneOneThrottlePolicy;
import com.tracfone.service.model.request.TracfoneOneThrottleRule;
import com.tracfone.service.model.request.TracfoneOneTmoZipNgp;
import com.tracfone.service.model.request.TracfoneOneVerizonZipNPANXX;
import com.tracfone.service.model.request.TracfoneonePaginationSearch;
import com.tracfone.service.model.response.TFOneArUsaMarket;
import com.tracfone.service.model.response.TFOneArUsaMarketSearchResult;
import com.tracfone.service.model.response.TFOneArUsaPostalZips;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierGroup;
import com.tracfone.service.model.response.TFOneCarrierPref;
import com.tracfone.service.model.response.TFOneCarrierRule;
import com.tracfone.service.model.response.TFOneCarrierZones;
import com.tracfone.service.model.response.TFOneCarriersimpref;
import com.tracfone.service.model.response.TFOneCingularMrktInfo;
import com.tracfone.service.model.response.TFOneDataConfig;
import com.tracfone.service.model.response.TFOneDataConfigMapping;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneGeoLoc;
import com.tracfone.service.model.response.TFOneIgOrderType;
import com.tracfone.service.model.response.TFOneNotCertifyModel;
import com.tracfone.service.model.response.TFOneNpaNxx2CarrierZonesSearchResult;
import com.tracfone.service.model.response.TFOneNpanxx2Carrierzones;
import com.tracfone.service.model.response.TFOneOrderType;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOnePartClass;
import com.tracfone.service.model.response.TFOneThrottleFeature;
import com.tracfone.service.model.response.TFOneThrottlePolicy;
import com.tracfone.service.model.response.TFOneThrottleRule;
import com.tracfone.service.model.response.TFOneTmoZipNgp;
import com.tracfone.service.model.response.TFOneVerizonZipNPANXX;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantPlanWizard;
import jersey.repackaged.com.google.common.collect.Lists;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import javax.persistence.Query;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author Pritesh Singh
 */
@Stateless
public class TracfoneCarrierMaintenanceAction implements TracfoneCarrierMaintenanceLocalAction, TracfoneOneConstantPlanWizard, TracfoneOneConstant {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneCarrierMaintenanceAction.class);
    private static final String OBJID = "OBJID";
    private static final String X_STATUS = "X_STATUS";
    private static final String X_PARENT_ID = "X_PARENT_ID";
    private static final String X_PART_CLASS_OBJID = "X_PART_CLASS_OBJID";
    private static final String CARRIER_GROUPS_LISTS_ADDED = "Carrier Groups lists added ";
    public static final String NPA = "NPA = ?";
    public static final String STATE = "STATE = ?";

    @EJB
    private DataBaseController dbControllerEJB;

    @EJB
    CRtlArUsaPostalZipsFacadeLocal cRtlArUsaPostalZipsFacadeLocal;

    @EJB
    CRtlArUsaMarketFacadeLocal cRtlArUsaMarketFacadeLocal;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    private static final String AND = " AND ";

    @Override
    public List<TFOneCarrierGroup> searchCarrierGroups(TracfoneOneCarrierGroup tracfoneOneCarrierGroup) throws TracfoneOneException {
        List<TFOneCarrierGroup> carrierGroups = new ArrayList<>(1);
        TFOneCarrierGroup carrierGroup;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierGroup.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchCarrierGroupStatement(tracfoneOneCarrierGroup));) {

            int index = 1;

            if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierGroup.getCarrierGroup2Parent())) {
                stmt.setString(index++, tracfoneOneCarrierGroup.getCarrierGroup2Parent());
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierGroup.getCarrierGroupId())) {
                stmt.setString(index++, tracfoneOneCarrierGroup.getCarrierGroupId());
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierGroup.getCarrierName())) {
                stmt.setString(index++, "%" + tracfoneOneCarrierGroup.getCarrierName().toUpperCase() + "%");
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierGroup.getStatus())) {
                stmt.setString(index++, tracfoneOneCarrierGroup.getStatus().toUpperCase());
            }

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    carrierGroup = new TFOneCarrierGroup();
                    carrierGroup.setObjId(resultSet.getString(OBJID));
                    carrierGroup.setCarrierGroupId(resultSet.getString("X_CARRIER_GROUP_ID"));
                    carrierGroup.setCarrierName(resultSet.getString("X_CARRIER_NAME"));
                    carrierGroup.setGroup2Address(resultSet.getString("X_GROUP2ADDRESS"));
                    carrierGroup.setStatus(resultSet.getString(X_STATUS));
                    carrierGroup.setCarrierGroup2Parent(resultSet.getString("X_CARRIER_GROUP2X_PARENT"));
                    carrierGroup.setNoAutoPart(resultSet.getString("X_NO_AUTO_PORT"));
                    carrierGroups.add(carrierGroup);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return carrierGroups;
    }

    private String getSearchCarrierGroupStatement(TracfoneOneCarrierGroup tracfoneOneCarrierGroup) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_CARRIER_GROUPS);
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierGroup.getCarrierGroup2Parent())) {
            builder.append("X_CARRIER_GROUP2X_PARENT =  ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierGroup.getCarrierGroupId())) {
            builder.append("X_CARRIER_GROUP_ID = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierGroup.getCarrierName())) {
            builder.append("UPPER(X_CARRIER_NAME) LIKE ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierGroup.getStatus())) {
            builder.append(UPPER_STATUS);
            builder.append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query for Carrier Group is : " + searchQuery);
        return searchQuery;
    }

    @Override
    public List<TFOneOrderType> searchOrderTypes(TracfoneOneOrderType tracfoneOneOrderType) throws TracfoneOneException {
        List<TFOneOrderType> orderTypes = new ArrayList<>(1);
        TFOneOrderType orderType;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneOrderType.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchOrderTypeStatement(tracfoneOneOrderType));) {
            int index = 1;
            if (!StringUtils.isNullOrEmpty(tracfoneOneOrderType.getOrderType2xCarrier())) {
                stmt.setString(index++, tracfoneOneOrderType.getOrderType2xCarrier());
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneOrderType.getOrderType())) {
                stmt.setString(index++, tracfoneOneOrderType.getOrderType());
            }

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    orderType = new TFOneOrderType();
                    orderType.setObjId(resultSet.getString(OBJID));
                    orderType.setOrderType(resultSet.getString("X_ORDER_TYPE"));
                    orderType.setNpa(resultSet.getString("X_NPA"));
                    orderType.setNxx(resultSet.getString("X_NXX"));
                    orderType.setBillCycle(resultSet.getString("X_BILL_CYCLE"));
                    orderType.setDealerCode(resultSet.getString("X_DEALER_CODE"));
                    orderType.setLdAccountNum(resultSet.getString("X_LD_ACCOUNT_NUM"));
                    orderType.setMarketCode(resultSet.getString("X_MARKET_CODE"));
                    orderType.setOrderType2xTransProfile(resultSet.getString("X_ORDER_TYPE2X_TRANS_PROFILE"));
                    orderType.setOrderType2xCarrier(resultSet.getString("X_ORDER_TYPE2X_CARRIER"));
                    orderTypes.add(orderType);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return orderTypes;
    }

    private String getSearchOrderTypeStatement(TracfoneOneOrderType tracfoneOneOrderType) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_ORDER_TYPES);
        if (!StringUtils.isNullOrEmpty(tracfoneOneOrderType.getOrderType2xCarrier())) {
            builder.append("X_ORDER_TYPE2X_CARRIER =  ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneOrderType.getOrderType())) {
            builder.append("X_ORDER_TYPE = ?");
            builder.append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query for Order Type is : " + searchQuery);
        return searchQuery;
    }

    @Override
    public List<TFOneParent> searchParent(TracfoneOneParent tracfoneOneParent) throws TracfoneOneException {
        List<TFOneParent> tfOneParents = new ArrayList<>(1);
        TFOneParent tfOneParent;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneParent.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchParentStatement(tracfoneOneParent));) {
            int index = 1;

            if (!StringUtils.isNullOrEmpty(tracfoneOneParent.getParentName())) {
                stmt.setString(index++, "%" + tracfoneOneParent.getParentName().toUpperCase() + "%");
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneParent.getParentId())) {
                stmt.setString(index++, tracfoneOneParent.getParentId());
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneParent.getStatus())) {
                stmt.setString(index++, tracfoneOneParent.getStatus().toUpperCase());
            }
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneParent = new TFOneParent();
                    tfOneParent.setParentShortName(resultSet.getString("PARENT_SHORT_NAME"));
                    tfOneParent.setTriggerId(resultSet.getString("TRIGGER_ID"));
                    tfOneParent.setOverrideSmsAddress(resultSet.getString("OVERRIDE_SMS_ADDRESS"));
                    tfOneParent.setDeactSimExpDays(resultSet.getString("DEACT_SIM_EXP_DAYS"));
                    tfOneParent.setSuiRuleObjId(resultSet.getString("SUI_RULE_OBJID"));
                    tfOneParent.setAggCarrCode(resultSet.getString("X_AGG_CARR_CODE"));
                    tfOneParent.setOtaReact(resultSet.getString("X_OTA_REACT"));
                    tfOneParent.setMeidCarrier(resultSet.getString("X_MEID_CARRIER"));
                    tfOneParent.setBlockPortIn(resultSet.getString("X_BLOCK_PORT_IN"));
                    tfOneParent.setQueueName(resultSet.getString("X_QUEUE_NAME"));
                    tfOneParent.setNextAvailable(resultSet.getString("X_NEXT_AVAILABLE"));
                    tfOneParent.setOtaStartDate(resultSet.getString("X_OTA_START_DATE"));
                    tfOneParent.setOtaPsmsAddress(resultSet.getString("X_OTA_PSMS_ADDRESS"));
                    tfOneParent.setOtaEndDate(resultSet.getString("X_OTA_END_DATE"));
                    tfOneParent.setOtaCarrier(resultSet.getString("X_OTA_CARRIER"));
                    tfOneParent.setNoMsid(resultSet.getString("X_NO_MSID"));
                    tfOneParent.setAutoPortOut(resultSet.getString("X_AUTO_PORT_OUT"));
                    tfOneParent.setAutoPortIn(resultSet.getString("X_AUTO_PORT_IN"));
                    tfOneParent.setVmAccessNum(resultSet.getString("X_VM_ACCESS_NUM"));
                    tfOneParent.setNoInventory(resultSet.getString("X_NO_INVENTORY"));
                    tfOneParent.setParent2TempQueue(resultSet.getString("X_PARENT2TEMP_QUEUE"));
                    tfOneParent.setHoldDigitalDeac(resultSet.getString("X_HOLD_DIGITAL_DEAC"));
                    tfOneParent.setHoldAnalogDeac(resultSet.getString("X_HOLD_ANALOG_DEAC"));
                    tfOneParent.setStatus(resultSet.getString(X_STATUS));
                    tfOneParent.setParentId(resultSet.getString(X_PARENT_ID));
                    tfOneParent.setxParentName(resultSet.getString("X_PARENT_NAME"));
                    tfOneParent.setObjId(resultSet.getString(OBJID));
                    tfOneParents.add(tfOneParent);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneParents;
    }


    private String getSearchParentStatement(TracfoneOneParent tracfoneOneParent) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_PARENT);
        if (!StringUtils.isNullOrEmpty(tracfoneOneParent.getParentName())) {
            builder.append("UPPER(X_PARENT_NAME) LIKE ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneParent.getParentId())) {
            builder.append(PARENT_ID_VALUE);
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneParent.getStatus())) {
            builder.append(UPPER_STATUS);
            builder.append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query for Parent is : " + searchQuery);
        return searchQuery;
    }

    @Override
    public List<TFOneCarrier> searchCarrier(TracfoneOneCarrier tracfoneOneCarrier) throws TracfoneOneException {
        List<TFOneCarrier> tfOneCarriers = new ArrayList<>(1);
        TFOneCarrier tfOneCarrier;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrier.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchCarrierStatement(tracfoneOneCarrier));) {
            int index = 1;
            if (!StringUtils.isNullOrEmpty(tracfoneOneCarrier.getCarrierId())) {
                stmt.setString(index++, tracfoneOneCarrier.getCarrierId());
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneCarrier.getSubmarketName())) {
                stmt.setString(index++, "%" + tracfoneOneCarrier.getSubmarketName().toUpperCase() + "%");
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneCarrier.getStatus())) {
                stmt.setString(index++, tracfoneOneCarrier.getStatus().toUpperCase());
            }
            if (!tracfoneOneCarrier.getCarrier2CarrierGroups().isEmpty()) {
                for (int i = 0; i < tracfoneOneCarrier.getCarrier2CarrierGroups().size(); i++) {
                    stmt.setString(index++, tracfoneOneCarrier.getCarrier2CarrierGroups().get(i));
                }
            }
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneCarrier = new TFOneCarrier();
                    tfOneCarrier.setObjId(resultSet.getString(OBJID));
                    tfOneCarrier.setCarrierId(resultSet.getString("X_CARRIER_ID"));
                    tfOneCarrier.setSubmarketName(resultSet.getString("X_MKT_SUBMKT_NAME"));
                    tfOneCarrier.setSubmarketOf(resultSet.getString("X_SUBMKT_OF"));
                    tfOneCarrier.setCity(resultSet.getString("X_CITY"));
                    tfOneCarrier.setState(resultSet.getString("X_STATE"));
                    tfOneCarrier.setTapeReturnCharge(resultSet.getString("X_TAPERETURN_CHARGE"));
                    tfOneCarrier.setCountryCode(resultSet.getString("X_COUNTRY_CODE"));
                    tfOneCarrier.setActiveLinePercent(resultSet.getString("X_ACTIVELINE_PERCENT"));
                    tfOneCarrier.setStatus(resultSet.getString(X_STATUS));
                    tfOneCarrier.setLdProvider(resultSet.getString("X_LD_PROVIDER"));
                    tfOneCarrier.setLdAccount(resultSet.getString("X_LD_ACCOUNT"));
                    tfOneCarrier.setLdPicCode(resultSet.getString("X_LD_PIC_CODE"));
                    tfOneCarrier.setRatePlan(resultSet.getString("X_RATE_PLAN"));
                    tfOneCarrier.setDummyEsn(resultSet.getString("X_DUMMY_ESN"));
                    tfOneCarrier.setBillDate(resultSet.getString("X_BILL_DATE"));
                    tfOneCarrier.setVoiceMail(resultSet.getString("X_VOICEMAIL"));
                    tfOneCarrier.setVmCode(resultSet.getString("X_VM_CODE"));
                    tfOneCarrier.setVmPackage(resultSet.getString("X_VM_PACKAGE"));
                    tfOneCarrier.setCallerId(resultSet.getString("X_CALLER_ID"));
                    tfOneCarrier.setIdCode(resultSet.getString("X_ID_CODE"));
                    tfOneCarrier.setIdPackage(resultSet.getString("X_ID_PACKAGE"));
                    tfOneCarrier.setCallWaiting(resultSet.getString("X_CALL_WAITING"));
                    tfOneCarrier.setCwCode(resultSet.getString("X_CW_CODE"));
                    tfOneCarrier.setCwPackage(resultSet.getString("X_CW_PACKAGE"));
                    tfOneCarrier.setReactTechnology(resultSet.getString("X_REACT_TECHNOLOGY"));
                    tfOneCarrier.setReactAnalog(resultSet.getString("X_REACT_ANALOG"));
                    tfOneCarrier.setActTechnology(resultSet.getString("X_ACT_TECHNOLOGY"));
                    tfOneCarrier.setActAnalog(resultSet.getString("X_ACT_ANALOG"));
                    tfOneCarrier.setDigitalRatePlan(resultSet.getString("X_DIGITAL_RATE_PLAN"));
                    tfOneCarrier.setDigitalFeature(resultSet.getString("X_DIGITAL_FEATURE"));
                    tfOneCarrier.setPrlPreLoaded(resultSet.getString("X_PRL_PRELOADED"));
                    tfOneCarrier.setCarrier2CarrierGroup(resultSet.getString("CARRIER2CARRIER_GROUP"));
                    tfOneCarrier.setTapeReturnAddr2Address(resultSet.getString("TAPERETURN_ADDR2ADDRESS"));
                    tfOneCarrier.setCarrier2Provider(resultSet.getString("CARRIER2PROVIDER"));
                    tfOneCarrier.setCarrier2Address(resultSet.getString("X_CARRIER2ADDRESS"));
                    tfOneCarrier.setCarrier2Personality(resultSet.getString("CARRIER2PERSONALITY"));
                    tfOneCarrier.setCarrier2Rule(resultSet.getString("CARRIER2RULES"));
                    tfOneCarrier.setCarrier2CarrScript(resultSet.getString("CARRIER2X_CARR_SCRIPT"));
                    tfOneCarrier.setSpecialMkt(resultSet.getString("X_SPECIAL_MKT"));
                    tfOneCarrier.setNewAnalogPlan(resultSet.getString("X_NEW_ANALOG_PLAN"));
                    tfOneCarrier.setNewDigitalPlan(resultSet.getString("X_NEW_DIGITAL_PLAN"));
                    tfOneCarrier.setSms(resultSet.getString("X_SMS"));
                    tfOneCarrier.setSmsCode(resultSet.getString("X_SMS_CODE"));
                    tfOneCarrier.setSmsPackage(resultSet.getString("X_SMS_PACKAGE"));
                    tfOneCarrier.setVmSetUpLandLine(resultSet.getString("X_VM_SETUP_LAND_LINE"));
                    tfOneCarrier.setCarrier2RulesCdma(resultSet.getString("CARRIER2RULES_CDMA"));
                    tfOneCarrier.setCarrier2RulesGsm(resultSet.getString("CARRIER2RULES_GSM"));
                    tfOneCarrier.setCarrier2RulesTdma(resultSet.getString("CARRIER2RULES_TDMA"));
                    tfOneCarrier.setDataService(resultSet.getString("X_DATA_SERVICE"));
                    tfOneCarrier.setAutomated(resultSet.getString("X_AUTOMATED"));
                    tfOneCarriers.add(tfOneCarrier);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneCarriers;
    }

    private String getSearchCarrierStatement(TracfoneOneCarrier tracfoneOneCarrier) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_CARRIER);
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrier.getCarrierId())) {
            builder.append("X_CARRIER_ID = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrier.getSubmarketName())) {
            builder.append("UPPER(X_MKT_SUBMKT_NAME) LIKE ?");
            builder.append(AND);
        }

        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrier.getStatus())) {
            builder.append(UPPER_STATUS);
            builder.append(AND);
        }
        if (!tracfoneOneCarrier.getCarrier2CarrierGroups().isEmpty()) {
            builder.append(buildInClause(tracfoneOneCarrier.getCarrier2CarrierGroups().size()));
            builder.append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query for Carrier is : " + searchQuery);
        return searchQuery;
    }

    private String buildInClause(int size) {
        LOGGER.info("Total number of CARRIER2CARRIER_GROUP to search is : " + size);
        StringBuilder query = new StringBuilder("CARRIER2CARRIER_GROUP in (?");
        if (size != 1) {
            int index = 1;
            while (index < size) {
                query.append(", ?");
                index++;
            }
        }
        query.append(")");
        return query.toString();
    }

    @Override
    public List<TFOneDataConfigMapping> searchDataConfigMapping(TracfoneOneDataConfigMapping tfDataConfigMapping) throws TracfoneOneException {
        List<TFOneDataConfigMapping> tfOneDataConfigMappings = new ArrayList<>(1);
        TFOneDataConfigMapping tfOneDataConfigMapping;
        try (Connection con = dbControllerEJB.getDataSource(tfDataConfigMapping.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchDataConfigMappingStatement(tfDataConfigMapping));) {

            setDataConfigMappingStatement(stmt, tfDataConfigMapping, true);

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneDataConfigMapping = new TFOneDataConfigMapping();
                    tfOneDataConfigMapping.setParentId(resultSet.getString(X_PARENT_ID));
                    tfOneDataConfigMapping.setPartClassObjId(resultSet.getString(X_PART_CLASS_OBJID));
                    tfOneDataConfigMapping.setRatePlan(resultSet.getString("X_RATE_PLAN"));
                    tfOneDataConfigMapping.setDataConfigObjId(resultSet.getString("X_DATA_CONFIG_OBJID"));
                    tfOneDataConfigMappings.add(tfOneDataConfigMapping);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneDataConfigMappings;
    }


    private void setDataConfigMappingStatement(PreparedStatement stmt, TracfoneOneDataConfigMapping tfDataConfigMapping, boolean isSearch) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tfDataConfigMapping.getParentId())) {
            stmt.setString(index++, tfDataConfigMapping.getParentId());
        }
        if (!StringUtils.isNullOrEmpty(tfDataConfigMapping.getPartClassObjId())) {
            stmt.setString(index++, tfDataConfigMapping.getPartClassObjId());
        }
        if (!StringUtils.isNullOrEmpty(tfDataConfigMapping.getRatePlan())) {
            if (isSearch)
                stmt.setString(index++, "%" + tfDataConfigMapping.getRatePlan().toUpperCase() + "%");
            else
                stmt.setString(index++, tfDataConfigMapping.getRatePlan());
        }
        if (!StringUtils.isNullOrEmpty(tfDataConfigMapping.getDataConfigObjId())) {
            stmt.setString(index, tfDataConfigMapping.getDataConfigObjId());
        }
    }

    private String getSearchDataConfigMappingStatement(TracfoneOneDataConfigMapping tfDataConfigMapping) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_DATA_CONFIG_MAPPING);
        if (!StringUtils.isNullOrEmpty(tfDataConfigMapping.getParentId())) {
            builder.append(PARENT_ID_VALUE);
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfDataConfigMapping.getPartClassObjId())) {
            builder.append(X_PART_CLASS_OBJID_VALUE);
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfDataConfigMapping.getRatePlan())) {
            builder.append("UPPER(X_RATE_PLAN) LIKE ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfDataConfigMapping.getDataConfigObjId())) {
            builder.append("X_DATA_CONFIG_OBJID = ?");
            builder.append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query for Data Config Mapping is : " + searchQuery);
        return searchQuery;
    }

    @Override
    public TFOneGeneralResponse insertDataConfigMapping(TracfoneOneDataConfigMapping tfDataConfigMapping, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfDataConfigMapping.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_DATA_CONFIG_MAPPING);) {

            setDataConfigMappingStatement(stmt, tfDataConfigMapping, false);

            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Data Config Mapping", "Inserted Data Config Mapping Object " + tfDataConfigMapping, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfDataConfigMapping.getParentId());
    }

    @Override
    public boolean validateDuplicateDataConfigMapping(TracfoneOneDataConfigMapping tfDataConfigMapping) throws TracfoneOneException {
        boolean dataConfigMappingExists = false;
        try (Connection con = dbControllerEJB.getDataSource(tfDataConfigMapping.getDbEnv()).getConnection();) {
            int count = 0;
            try (PreparedStatement stmt = con.prepareStatement(TRACFONE_DUPLICATE_DATA_CONFIG_MAPPING_CHECK);) {
                setDataConfigMappingStatement(stmt, tfDataConfigMapping, false);
                try (ResultSet resultSet = stmt.executeQuery();) {
                    LOGGER.info("What am I searching for? " + tfDataConfigMapping);
                    while (resultSet.next()) {
                        count = resultSet.getInt(1);
                        LOGGER.info("How many Data Config Mapping have been found? " + count);
                    }
                }
            }
            if (count > 0) {
                dataConfigMappingExists = true;
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return dataConfigMappingExists;
    }

    @Override
    public TFOneGeneralResponse deleteDataConfigMapping(TracfoneOneDataConfigMapping tfDataConfigMapping, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfDataConfigMapping.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_DATA_CONFIG_MAPPING);) {

            setDataConfigMappingStatement(stmt, tfDataConfigMapping, false);

            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Data Config Mapping", "Deleted Data Config Mapping Object " + tfDataConfigMapping, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfDataConfigMapping.getParentId());
    }

    @Override
    public TFOneGeneralResponse updateDataConfigMapping(TracfoneOneDataConfigMapping tfDataConfigMapping, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfDataConfigMapping.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_DATA_CONFIG_MAPPING);) {

            setDataConfigMappingStatementForUpdate(stmt, tfDataConfigMapping);

            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Data Config Mapping", "Updated Data Config Mapping Object " + tfDataConfigMapping, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfDataConfigMapping.getParentId());
    }

    private void setDataConfigMappingStatementForUpdate(PreparedStatement stmt, TracfoneOneDataConfigMapping tfDataConfigMapping) throws SQLException {
        LOGGER.info("All TracfoneOneDataConfigMapping Object is : " + tfDataConfigMapping);
        stmt.setString(1, tfDataConfigMapping.getParentId());
        stmt.setString(2, tfDataConfigMapping.getPartClassObjId());
        stmt.setString(3, tfDataConfigMapping.getRatePlan());
        stmt.setString(4, tfDataConfigMapping.getDataConfigObjId());

        stmt.setString(5, tfDataConfigMapping.getOldParentId());
        stmt.setString(6, tfDataConfigMapping.getOldPartClassObjId());
        stmt.setString(7, tfDataConfigMapping.getOldRatePlan());
        stmt.setString(8, tfDataConfigMapping.getOldDataConfigObjId());
    }

    @Override
    public TFOneGeneralResponse updateParent(TracfoneOneParent tracfoneOneParent, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneParent.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_PARENT);) {

            setParentStatement(stmt, tracfoneOneParent);

            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Parent", "Updated Parent Object " + tracfoneOneParent, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneParent.getObjId());
    }

    private void setParentStatement(PreparedStatement stmt, TracfoneOneParent tracfoneOneParent) throws SQLException {
        stmt.setString(1, tracfoneOneParent.getParentName());
        stmt.setString(2, tracfoneOneParent.getParentId());
        stmt.setString(3, tracfoneOneParent.getStatus());
        stmt.setString(4, tracfoneOneParent.getHoldAnalogDeac());
        stmt.setString(5, tracfoneOneParent.getHoldDigitalDeac());
        stmt.setString(6, tracfoneOneParent.getParent2TempQueue());
        stmt.setString(7, tracfoneOneParent.getNoInventory());
        stmt.setString(8, tracfoneOneParent.getVmAccessNum());
        stmt.setString(9, tracfoneOneParent.getAutoPortIn());
        stmt.setString(10, tracfoneOneParent.getAutoPortOut());
        stmt.setString(11, tracfoneOneParent.getNoMsid());
        stmt.setString(12, tracfoneOneParent.getOtaCarrier());
        stmt.setString(13, tracfoneOneParent.getOtaPsmsAddress());
        stmt.setString(14, tracfoneOneParent.getNextAvailable());
        stmt.setString(15, tracfoneOneParent.getQueueName());
        stmt.setString(16, tracfoneOneParent.getBlockPortIn());
        stmt.setString(17, tracfoneOneParent.getMeidCarrier());
        stmt.setString(18, tracfoneOneParent.getOtaReact());
        stmt.setString(19, tracfoneOneParent.getAggCarrCode());
        stmt.setString(20, tracfoneOneParent.getSuiRuleObjId());
        stmt.setString(21, tracfoneOneParent.getDeactSimExpDays());
        stmt.setString(22, tracfoneOneParent.getOverrideSmsAddress());
        stmt.setString(23, tracfoneOneParent.getTriggerId());
        stmt.setString(24, tracfoneOneParent.getParentShortName());
        if (StringUtils.isNullOrEmpty(tracfoneOneParent.getOtaStartDate())) {
            stmt.setNull(25, Types.DATE);
        } else {
            stmt.setDate(25, Date.valueOf(tracfoneOneParent.getOtaStartDate()));
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneParent.getOtaEndDate())) {
            stmt.setNull(26, Types.DATE);
        } else {
            stmt.setDate(26, Date.valueOf(tracfoneOneParent.getOtaEndDate()));
        }
        stmt.setString(27, tracfoneOneParent.getObjId());
    }

    @Override
    public TFOneGeneralResponse updateCarrierGroup(TracfoneOneCarrierGroup tracfoneOneCarrierGroup, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierGroup.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CARRIER_GROUP);) {

            setCarrierGroupStatement(stmt, tracfoneOneCarrierGroup);

            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Carrier Group", "Updated Carrier Group Object " + tracfoneOneCarrierGroup, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneCarrierGroup.getObjId());
    }


    private void setCarrierGroupStatement(PreparedStatement stmt, TracfoneOneCarrierGroup tracfoneOneCarrierGroup) throws SQLException {
        stmt.setString(1, tracfoneOneCarrierGroup.getCarrierGroupId());
        stmt.setString(2, tracfoneOneCarrierGroup.getCarrierName());
        stmt.setString(3, tracfoneOneCarrierGroup.getGroup2Address());
        stmt.setString(4, tracfoneOneCarrierGroup.getStatus());
        stmt.setString(5, tracfoneOneCarrierGroup.getCarrierGroup2Parent());
        stmt.setString(6, tracfoneOneCarrierGroup.getNoAutoPart());
        stmt.setString(7, tracfoneOneCarrierGroup.getObjId());
    }

    @Override
    public TFOneGeneralResponse updateCarrier(TracfoneOneCarrier tracfoneOneCarrier, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrier.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CARRIER);) {

            setCarrierStatement(stmt, tracfoneOneCarrier);

            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Carrier", "Updated Carrier Object " + tracfoneOneCarrier, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneCarrier.getObjId());
    }


    private void setCarrierStatement(PreparedStatement stmt, TracfoneOneCarrier tracfoneOneCarrier) throws SQLException {
        stmt.setString(1, tracfoneOneCarrier.getCarrierId());
        stmt.setString(2, tracfoneOneCarrier.getSubmarketName());
        stmt.setString(3, tracfoneOneCarrier.getSubmarketOf());
        stmt.setString(4, tracfoneOneCarrier.getCity());
        stmt.setString(5, tracfoneOneCarrier.getState());
        stmt.setString(6, tracfoneOneCarrier.getTapeReturnCharge());
        stmt.setString(7, tracfoneOneCarrier.getCountryCode());
        stmt.setString(8, tracfoneOneCarrier.getActiveLinePercent());
        stmt.setString(9, tracfoneOneCarrier.getStatus());
        stmt.setString(10, tracfoneOneCarrier.getLdProvider());
        stmt.setString(11, tracfoneOneCarrier.getLdAccount());
        stmt.setString(12, tracfoneOneCarrier.getLdPicCode());
        stmt.setString(13, tracfoneOneCarrier.getRatePlan());
        stmt.setString(14, tracfoneOneCarrier.getDummyEsn());
        stmt.setString(15, tracfoneOneCarrier.getVoiceMail());
        stmt.setString(16, tracfoneOneCarrier.getVmCode());
        stmt.setString(17, tracfoneOneCarrier.getVmPackage());
        stmt.setString(18, tracfoneOneCarrier.getCallerId());
        stmt.setString(19, tracfoneOneCarrier.getIdCode());
        stmt.setString(20, tracfoneOneCarrier.getIdPackage());
        stmt.setString(21, tracfoneOneCarrier.getCallWaiting());
        stmt.setString(22, tracfoneOneCarrier.getCwCode());
        stmt.setString(23, tracfoneOneCarrier.getCwPackage());
        stmt.setString(24, tracfoneOneCarrier.getReactTechnology());
        stmt.setString(25, tracfoneOneCarrier.getReactAnalog());
        stmt.setString(26, tracfoneOneCarrier.getActTechnology());
        stmt.setString(27, tracfoneOneCarrier.getActAnalog());
        stmt.setString(28, tracfoneOneCarrier.getDigitalRatePlan());
        stmt.setString(29, tracfoneOneCarrier.getDigitalFeature());
        stmt.setString(30, tracfoneOneCarrier.getPrlPreLoaded());
        stmt.setString(31, tracfoneOneCarrier.getCarrier2CarrierGroups().get(0));
        stmt.setString(32, tracfoneOneCarrier.getTapeReturnAddr2Address());
        stmt.setString(33, tracfoneOneCarrier.getCarrier2Provider());
        stmt.setString(34, tracfoneOneCarrier.getCarrier2Address());
        stmt.setString(35, tracfoneOneCarrier.getCarrier2Personality());
        stmt.setString(36, tracfoneOneCarrier.getCarrier2Rule());
        stmt.setString(37, tracfoneOneCarrier.getCarrier2CarrScript());
        stmt.setString(38, tracfoneOneCarrier.getSpecialMkt());
        stmt.setString(39, tracfoneOneCarrier.getNewAnalogPlan());
        stmt.setString(40, tracfoneOneCarrier.getNewDigitalPlan());
        stmt.setString(41, tracfoneOneCarrier.getSms());
        stmt.setString(42, tracfoneOneCarrier.getSmsCode());
        stmt.setString(43, tracfoneOneCarrier.getSmsPackage());
        stmt.setString(44, tracfoneOneCarrier.getVmSetUpLandLine());
        stmt.setString(45, tracfoneOneCarrier.getCarrier2RulesCdma());
        stmt.setString(46, tracfoneOneCarrier.getCarrier2RulesGsm());
        stmt.setString(47, tracfoneOneCarrier.getCarrier2RulesTdma());
        stmt.setString(48, tracfoneOneCarrier.getDataService());
        stmt.setString(49, tracfoneOneCarrier.getAutomated());
        if (StringUtils.isNullOrEmpty(tracfoneOneCarrier.getBillDate())) {
            stmt.setNull(50, Types.DATE);
        } else {
            stmt.setDate(50, Date.valueOf(tracfoneOneCarrier.getBillDate()));
        }
        stmt.setString(51, tracfoneOneCarrier.getObjId());
    }

    @Override
    public TFOneGeneralResponse updateCarrierRule(TracfoneOneCarrierRule tracfoneOneCarrierRule, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierRule.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CARRIER_RULE);) {

            setCarrierRuleStatement(stmt, tracfoneOneCarrierRule);

            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Carrier", "Updated Carrier Object " + tracfoneOneCarrierRule, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneCarrierRule.getObjId());
    }

    private void setCarrierRuleStatement(PreparedStatement stmt, TracfoneOneCarrierRule tracfoneOneCarrierRule) throws SQLException {
        stmt.setString(1, tracfoneOneCarrierRule.getCoolingPeriod());
        stmt.setString(2, tracfoneOneCarrierRule.getEsnChangeDays());
        stmt.setString(3, tracfoneOneCarrierRule.getLineExpireDays());
        stmt.setString(4, tracfoneOneCarrierRule.getLineReturnDays());
        stmt.setString(5, tracfoneOneCarrierRule.getCoolingAfterInsert());
        stmt.setString(6, tracfoneOneCarrierRule.getNpaNxxFlag());
        stmt.setString(7, tracfoneOneCarrierRule.getUsedLineExpireDays());
        stmt.setString(8, tracfoneOneCarrierRule.getGsmGracePeriod());
        stmt.setString(9, tracfoneOneCarrierRule.getTechnology());
        stmt.setString(10, tracfoneOneCarrierRule.getReserveOnSuspend());
        stmt.setString(11, tracfoneOneCarrierRule.getReservePeriod());
        stmt.setString(12, tracfoneOneCarrierRule.getDeacAfterGrace());
        stmt.setString(13, tracfoneOneCarrierRule.getCancelSuspendDays());
        stmt.setString(14, tracfoneOneCarrierRule.getCancelSuspend());
        stmt.setString(15, tracfoneOneCarrierRule.getBlockCreateActItem());
        stmt.setString(16, tracfoneOneCarrierRule.getAllow2gAct());
        stmt.setString(17, tracfoneOneCarrierRule.getAllow2gReact());
        stmt.setString(18, tracfoneOneCarrierRule.getAllowNonHdActs());
        stmt.setString(19, tracfoneOneCarrierRule.getAllowNonHdReacts());
        stmt.setString(20, tracfoneOneCarrierRule.getObjId());
    }


    @Override
    public TFOneGeneralResponse updateOrderType(TracfoneOneOrderType tracfoneOneOrderType, int userId) throws TracfoneOneException {
        LOGGER.info("Order Type being updated - " + tracfoneOneOrderType);
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneOrderType.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_ORDER_TYPE);) {

            setOrderTypeStatement(stmt, tracfoneOneOrderType);

            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Order Type", "Updated Order Type Object " + tracfoneOneOrderType, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneOrderType.getObjId());
    }


    private void setOrderTypeStatement(PreparedStatement stmt, TracfoneOneOrderType tracfoneOneOrderType) throws SQLException {
        stmt.setString(1, tracfoneOneOrderType.getOrderType());
        stmt.setString(2, tracfoneOneOrderType.getNpa());
        stmt.setString(3, tracfoneOneOrderType.getNxx());
        stmt.setString(4, tracfoneOneOrderType.getBillCycle());
        stmt.setString(5, tracfoneOneOrderType.getDealerCode());
        stmt.setString(6, tracfoneOneOrderType.getLdAccountNum());
        stmt.setString(7, tracfoneOneOrderType.getMarketCode());
        stmt.setString(8, tracfoneOneOrderType.getOrderType2xTransProfile());
        stmt.setString(9, tracfoneOneOrderType.getOrderType2xCarrier());
        stmt.setString(10, tracfoneOneOrderType.getObjId());
    }

    @Override
    public TFOneGeneralResponse insertParent(TracfoneOneParent tracfoneOneParent, int userId) throws TracfoneOneException {
        String objId = null;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneParent.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_PARENT);) {
            objId = getNextSequence(con, TRACFONE_PARENT_SEQ_STMT, "TABLE_X_PARENT_OBJID_SEQ");
            tracfoneOneParent.setObjId(objId);
            setParentStatement(stmt, tracfoneOneParent);

            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Parent", "Inserted Parent Object " + tracfoneOneParent, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneParent.getObjId());
    }

    @Override
    public TFOneGeneralResponse insertCarrierGroups(List<TracfoneOneCarrierGroup> tracfoneOneCarrierGroups, int userId) throws TracfoneOneException {
        LOGGER.info("Number of Carrier Groups to be added is : " + tracfoneOneCarrierGroups.size());
        String objId = null;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierGroups.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_CARRIER_GROUP);) {
            for (TracfoneOneCarrierGroup tracfoneOneCarrierGroup : tracfoneOneCarrierGroups) {
                objId = getNextSequence(con, TRACFONE_CARRIER_GROUP_SEQ_STMT, "CARRIER_GROUP_OBJID_SEQ");
                tracfoneOneCarrierGroup.setObjId(objId);
                setCarrierGroupStatement(stmt, tracfoneOneCarrierGroup);
                stmt.addBatch();
            }
            LOGGER.info("Carrier Groups lists going to be added " + tracfoneOneCarrierGroups);
            int[] count = stmt.executeBatch();
            LOGGER.info(CARRIER_GROUPS_LISTS_ADDED + count);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Carrier Group", "Inserted Carrier Group Object " + tracfoneOneCarrierGroups, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneCarrierGroups.get(0).getObjId());
    }

    @Override
    public TFOneGeneralResponse insertCarriers(List<TracfoneOneCarrier> tracfoneOneCarriers, int userId) throws TracfoneOneException {
        LOGGER.info("Number of Carrier to be added " + tracfoneOneCarriers.size());
        String objId = null;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarriers.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_CARRIER);) {
            for (TracfoneOneCarrier tracfoneOneCarrier : tracfoneOneCarriers) {
                objId = getNextSequence(con, TRACFONE_CARRIER_SEQ_STMT, "CARRIER_OBJID_SEQ");
                tracfoneOneCarrier.setObjId(objId);
                setCarrierStatement(stmt, tracfoneOneCarrier);
                stmt.addBatch();
            }
            int[] count = stmt.executeBatch();
            LOGGER.info("Carrier lists added " + count);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Carrier", "Inserted Carrier Object " + tracfoneOneCarriers, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneCarriers.get(0).getObjId());
    }

    @Override
    public TFOneGeneralResponse insertCarrierRule(TracfoneOneCarrierRule tracfoneOneCarrierRule, int userId) throws TracfoneOneException {
        String objId;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierRule.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_CARRIER_RULE);) {
            objId = getNextSequence(con, TRACFONE_CARRIER_RULE_SEQ_STMT, "CARRIER_RULE_OBJID_SEQ");
            tracfoneOneCarrierRule.setObjId(objId);
            setCarrierRuleStatement(stmt, tracfoneOneCarrierRule);

            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Carrier Rule", "Inserted Carrier Rule Object " + tracfoneOneCarrierRule, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, objId);
    }

    @Override
    public List<TFOneOrderType> insertOrderType(List<TracfoneOneOrderType> tracfoneOneOrderTypes, int userId) throws TracfoneOneException {
        LOGGER.info("Number of Order Type to be added is : " + tracfoneOneOrderTypes.size());
        List<TFOneOrderType> tfOneOrderTypes = new ArrayList<>(1);
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneOrderTypes.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_ORDER_TYPE);) {
            for (TracfoneOneOrderType tracfoneOneOrderType : tracfoneOneOrderTypes) {
                String objId = getNextSequence(con, TRACFONE_ORDER_TYPE_SEQ_STMT, "ORDER_TYPE_OBJID_SEQ");
                tracfoneOneOrderType.setObjId(objId);
                setOrderTypeStatement(stmt, tracfoneOneOrderType);
                tfOneOrderTypes.add(createOrderTypeResponseObject(tracfoneOneOrderType));
                stmt.addBatch();
            }
            int[] count = stmt.executeBatch();
            LOGGER.info("Order Type lists added " + count);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Order Type", "Inserted Order Type Object " + tracfoneOneOrderTypes, null);
            tracfoneAuditEvent.fire(audit);
        }
        return tfOneOrderTypes;
    }

    private TFOneOrderType createOrderTypeResponseObject(TracfoneOneOrderType tracfoneOneOrderType) {
        TFOneOrderType tfOneOrderType = new TFOneOrderType();
        tfOneOrderType.setNpa(tracfoneOneOrderType.getNpa());
        tfOneOrderType.setObjId(tracfoneOneOrderType.getObjId());
        tfOneOrderType.setOrderType2xCarrier(tracfoneOneOrderType.getOrderType2xCarrier());
        tfOneOrderType.setOrderType(tracfoneOneOrderType.getOrderType());
        tfOneOrderType.setOrderType2xTransProfile(tracfoneOneOrderType.getOrderType2xTransProfile());
        tfOneOrderType.setMarketCode(tracfoneOneOrderType.getMarketCode());
        tfOneOrderType.setLdAccountNum(tracfoneOneOrderType.getLdAccountNum());
        tfOneOrderType.setDealerCode(tracfoneOneOrderType.getDealerCode());
        tfOneOrderType.setBillCycle(tracfoneOneOrderType.getBillCycle());
        tfOneOrderType.setNxx(tracfoneOneOrderType.getNxx());
        return tfOneOrderType;
    }

    @Override
    public List<String> getCarrierGroupIds(String dbEnv, List<String> carrierGroupIds) throws TracfoneOneException {
        List<String> duplicateIds = new ArrayList<>(1);
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(getQueryForDuplicateCheck(carrierGroupIds, TRACFONE_SEARCH_DUPLICATE_CARRIER_GROUPS));) {
            int index = 1;
            for (String carrierGroupId : carrierGroupIds) {
                stmt.setString(index++, carrierGroupId);
            }
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    duplicateIds.add(resultSet.getString("X_CARRIER_GROUP_ID"));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return duplicateIds;
    }

    @Override
    public List<String> getCarrierIds(String dbEnv, List<String> carrierIds) throws TracfoneOneException {
        List<String> duplicateIds = new ArrayList<>(1);
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(getQueryForDuplicateCheck(carrierIds, TRACFONE_SEARCH_DUPLICATE_CARRIERS));) {
            int index = 1;
            for (String carrierId : carrierIds) {
                stmt.setString(index++, carrierId);
            }
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    duplicateIds.add(resultSet.getString("X_CARRIER_ID"));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return duplicateIds;
    }

    @Override
    public List<TFOneCarrierRule> searchCarrierRules(TracfoneOneCarrierRule tracfoneOneCarrierRule) throws TracfoneOneException {
        List<TFOneCarrierRule> tfOneCarrierRules = new ArrayList<>(1);
        TFOneCarrierRule tfOneCarrierRule;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierRule.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchCarrierRulesStatement(tracfoneOneCarrierRule));) {
            setCarrierRuleSearchParams(stmt, tracfoneOneCarrierRule);

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneCarrierRule = new TFOneCarrierRule();
                    tfOneCarrierRule.setObjId(resultSet.getString(OBJID));
                    tfOneCarrierRule.setCoolingPeriod(resultSet.getString("X_COOLING_PERIOD"));
                    tfOneCarrierRule.setEsnChangeDays(resultSet.getString("X_ESN_CHANGE_FLAG"));
                    tfOneCarrierRule.setLineExpireDays(resultSet.getString("X_LINE_EXPIRE_DAYS"));
                    tfOneCarrierRule.setLineReturnDays(resultSet.getString("X_LINE_RETURN_DAYS"));
                    tfOneCarrierRule.setCoolingAfterInsert(resultSet.getString("X_COOLING_AFTER_INSERT"));
                    tfOneCarrierRule.setNpaNxxFlag(resultSet.getString("X_NPA_NXX_FLAG"));
                    tfOneCarrierRule.setUsedLineExpireDays(resultSet.getString("X_USED_LINE_EXPIRE_DAYS"));
                    tfOneCarrierRule.setGsmGracePeriod(resultSet.getString("X_GSM_GRACE_PERIOD"));
                    tfOneCarrierRule.setTechnology(resultSet.getString("X_TECHNOLOGY"));
                    tfOneCarrierRule.setReserveOnSuspend(resultSet.getString("X_RESERVE_ON_SUSPEND"));
                    tfOneCarrierRule.setReservePeriod(resultSet.getString("X_RESERVE_PERIOD"));
                    tfOneCarrierRule.setDeacAfterGrace(resultSet.getString("X_DEAC_AFTER_GRACE"));
                    tfOneCarrierRule.setCancelSuspendDays(resultSet.getString("X_CANCEL_SUSPEND_DAYS"));
                    tfOneCarrierRule.setCancelSuspend(resultSet.getString("X_CANCEL_SUSPEND"));
                    tfOneCarrierRule.setBlockCreateActItem(resultSet.getString("X_BLOCK_CREATE_ACT_ITEM"));
                    tfOneCarrierRule.setAllow2gAct(resultSet.getString("X_ALLOW_2G_ACT"));
                    tfOneCarrierRule.setAllow2gReact(resultSet.getString("X_ALLOW_2G_REACT"));
                    tfOneCarrierRule.setAllowNonHdActs(resultSet.getString("ALLOW_NON_HD_ACTS"));
                    tfOneCarrierRule.setAllowNonHdReacts(resultSet.getString("ALLOW_NON_HD_REACTS"));
                    tfOneCarrierRules.add(tfOneCarrierRule);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneCarrierRules;
    }

    private void setCarrierRuleSearchParams(PreparedStatement stmt, TracfoneOneCarrierRule tracfoneOneCarrierRule) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getObjId())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getObjId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getAllow2gAct())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getAllow2gAct());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getAllow2gReact())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getAllow2gReact());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getAllowNonHdActs())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getAllowNonHdActs());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getAllowNonHdReacts())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getAllowNonHdReacts());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getCoolingPeriod())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getCoolingPeriod());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getCoolingAfterInsert())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getCoolingAfterInsert());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getDeacAfterGrace())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getDeacAfterGrace());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getBlockCreateActItem())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getBlockCreateActItem());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getCancelSuspend())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getCancelSuspend());
        }
        setCarrierRuleSearchParams2(index, stmt, tracfoneOneCarrierRule);
    }

    void setCarrierRuleSearchParams2(int index, PreparedStatement stmt, TracfoneOneCarrierRule tracfoneOneCarrierRule) throws SQLException {
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getCancelSuspendDays())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getCancelSuspendDays());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getEsnChangeDays())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getEsnChangeDays());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getGsmGracePeriod())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getGsmGracePeriod());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getLineExpireDays())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getLineExpireDays());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getLineReturnDays())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getLineReturnDays());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getUsedLineExpireDays())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getUsedLineExpireDays());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getNpaNxxFlag())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getNpaNxxFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getReserveOnSuspend())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getReserveOnSuspend());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getReservePeriod())) {
            stmt.setString(index++, tracfoneOneCarrierRule.getReservePeriod());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getTechnology())) {
            stmt.setString(index, tracfoneOneCarrierRule.getTechnology());
        }
    }

    private String getSearchCarrierRulesStatement(TracfoneOneCarrierRule tracfoneOneCarrierRule) {
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_CARRIER_RULES);
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getObjId())) {
            builder.append("OBJID =  ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getAllow2gAct())) {
            builder.append("X_ALLOW_2G_ACT = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getAllow2gReact())) {
            builder.append("X_ALLOW_2G_REACT = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getAllowNonHdActs())) {
            builder.append("ALLOW_NON_HD_ACTS = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getAllowNonHdReacts())) {
            builder.append("ALLOW_NON_HD_REACTS = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getCoolingPeriod())) {
            builder.append("X_COOLING_PERIOD = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getCoolingAfterInsert())) {
            builder.append("X_COOLING_AFTER_INSERT = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getDeacAfterGrace())) {
            builder.append("X_DEAC_AFTER_GRACE = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getBlockCreateActItem())) {
            builder.append("X_BLOCK_CREATE_ACT_ITEM = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getCancelSuspend())) {
            builder.append("X_CANCEL_SUSPEND = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getCancelSuspendDays())) {
            builder.append("X_CANCEL_SUSPEND_DAYS = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getEsnChangeDays())) {
            builder.append("X_ESN_CHANGE_FLAG = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getGsmGracePeriod())) {
            builder.append("X_GSM_GRACE_PERIOD = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getLineExpireDays())) {
            builder.append("X_LINE_EXPIRE_DAYS = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getLineReturnDays())) {
            builder.append("X_LINE_RETURN_DAYS = ?");
            builder.append(AND);
        }
        return getSearchCarrierRulesStatement2(builder, tracfoneOneCarrierRule);
    }

    private String getSearchCarrierRulesStatement2(StringBuilder builder, TracfoneOneCarrierRule tracfoneOneCarrierRule) {
        String searchQuery = "";
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getUsedLineExpireDays())) {
            builder.append("X_USED_LINE_EXPIRE_DAYS = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getNpaNxxFlag())) {
            builder.append("X_NPA_NXX_FLAG = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getReserveOnSuspend())) {
            builder.append("X_RESERVE_ON_SUSPEND = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getReservePeriod())) {
            builder.append("X_RESERVE_PERIOD = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierRule.getTechnology())) {
            builder.append("X_TECHNOLOGY = ?");
            builder.append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query for Carrier Rule is : " + searchQuery);
        return searchQuery;
    }

    private String getQueryForDuplicateCheck(List<String> carrierIds, String query) {
        StringBuilder builder = new StringBuilder(query);
        for (int i = 1; i < carrierIds.size(); i++) {
            builder.append(",?");
        }
        builder.append(")");
        LOGGER.info("Query created: " + builder.toString());
        return builder.toString();
    }

    private String getNextSequence(Connection con, String queryString, String seqId) throws SQLException {
        String sequenceId = null;
        try (PreparedStatement stmt = con.prepareStatement(queryString);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                sequenceId = resultSet.getString(seqId);
            }
        }
        return sequenceId;
    }

    @Override
    public List<TFOneDataConfig> searchDataConfigs(TracfoneOneDataConfig tracfoneOneDataConfig) throws TracfoneOneException {
        List<TFOneDataConfig> dataConfigs = new ArrayList<>(1);
        TFOneDataConfig dataConfig;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneDataConfig.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(searchDataConfigStatement(tracfoneOneDataConfig));) {
            setDataConfigStatement(stmt, tracfoneOneDataConfig);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    dataConfig = new TFOneDataConfig();
                    dataConfig.setObjId(resultSet.getString(OBJID));
                    dataConfig.setDev(resultSet.getString("DEV"));
                    dataConfig.setParentId(resultSet.getString(X_PARENT_ID));
                    dataConfig.setPartClassObjId(resultSet.getString(X_PART_CLASS_OBJID));
                    dataConfig.setxDefault(resultSet.getString("X_DEFAULT"));
                    dataConfig.setIpAddress(resultSet.getString("X_IP_ADDRESS"));
                    dataConfig.setApn(resultSet.getString("X_APN"));
                    dataConfig.setHomePage(resultSet.getString("X_HOMEPAGE"));
                    dataConfig.setMmsc(resultSet.getString("X_MMSC"));
                    dataConfig.setCmd148CarrierDataSwitch(resultSet.getString("CMD_148_CARRIER_DATA_SWITCH"));
                    dataConfig.setDataSwitch(resultSet.getString("X_DATA_SWITCH"));
                    dataConfig.setCmd71GprsApn(resultSet.getString("CMD_71_GPRS_APN"));
                    dataConfig.setCmd150ClearProxy(resultSet.getString("CMD_150_CLEAR_PROXY"));
                    dataConfig.setCmd121GatewayPortUpdate(resultSet.getString("CMD_121_GATEWAY_PORT_UPDATE"));
                    dataConfig.setCmd121GatewayIpUpdate(resultSet.getString("CMD_121_GATEWAY_IP_UPDATE"));
                    dataConfig.setCmd71MmscUpdate(resultSet.getString("CMD_71_MMSC_UPDATE"));
                    dataConfig.setCmd71GatewayHome(resultSet.getString("CMD_71_GATEWAY_HOME"));
                    dataConfig.setCmd121GatewayIpPortUpdate(resultSet.getString("CMD_121_GATEWAY_IP_PORT_UPDATE"));
                    dataConfigs.add(dataConfig);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return dataConfigs;
    }

    private void setDataConfigStatement(PreparedStatement stmt, TracfoneOneDataConfig tracfoneOneDataConfig) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getObjId())) {
            stmt.setString(index++, tracfoneOneDataConfig.getObjId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getParentId())) {
            stmt.setString(index++, tracfoneOneDataConfig.getParentId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getDev())) {
            stmt.setString(index++, tracfoneOneDataConfig.getDev());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getPartClassObjId())) {
            stmt.setString(index++, tracfoneOneDataConfig.getPartClassObjId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getxDefault())) {
            stmt.setString(index++, tracfoneOneDataConfig.getxDefault());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getIpAddress())) {
            stmt.setString(index++, tracfoneOneDataConfig.getIpAddress());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getApn())) {
            stmt.setString(index++, "%" + tracfoneOneDataConfig.getApn().toUpperCase() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getHomePage())) {
            stmt.setString(index++, tracfoneOneDataConfig.getHomePage());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getMmsc())) {
            stmt.setString(index++, tracfoneOneDataConfig.getMmsc());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd148CarrierDataSwitch())) {
            stmt.setString(index++, tracfoneOneDataConfig.getCmd148CarrierDataSwitch());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getDataSwitch())) {
            stmt.setString(index++, tracfoneOneDataConfig.getDataSwitch());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd71GprsApn())) {
            stmt.setString(index++, tracfoneOneDataConfig.getCmd71GprsApn());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd150ClearProxy())) {
            stmt.setString(index++, tracfoneOneDataConfig.getCmd150ClearProxy());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd121GatewayPortUpdate())) {
            stmt.setString(index++, tracfoneOneDataConfig.getCmd121GatewayPortUpdate());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd121GatewayIpUpdate())) {
            stmt.setString(index++, tracfoneOneDataConfig.getCmd121GatewayIpUpdate());
        }
        setDataConfigStatement2(stmt, index, tracfoneOneDataConfig);
    }

    private void setDataConfigStatement2(PreparedStatement stmt, int index, TracfoneOneDataConfig tracfoneOneDataConfig) throws SQLException {
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd71MmscUpdate())) {
            stmt.setString(index++, tracfoneOneDataConfig.getCmd71MmscUpdate());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd71GatewayHome())) {
            stmt.setString(index++, tracfoneOneDataConfig.getCmd71GatewayHome());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd121GatewayIpPortUpdate())) {
            stmt.setString(index, tracfoneOneDataConfig.getCmd121GatewayIpPortUpdate());
        }
    }

    private String searchDataConfigStatement(TracfoneOneDataConfig tracfoneOneDataConfig) {
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_DATA_CONFIGS);
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getObjId())) {
            builder.append(OBJID_VALUE);
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getParentId())) {
            builder.append(PARENT_ID_VALUE);
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getDev())) {
            builder.append("DEV = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getPartClassObjId())) {
            builder.append(X_PART_CLASS_OBJID_VALUE);
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getxDefault())) {
            builder.append("X_DEFAULT = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getIpAddress())) {
            builder.append("X_IP_ADDRESS = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getApn())) {
            builder.append("UPPER(X_APN) LIKE ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getHomePage())) {
            builder.append("X_HOMEPAGE = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getMmsc())) {
            builder.append("X_MMSC = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd148CarrierDataSwitch())) {
            builder.append("CMD_148_CARRIER_DATA_SWITCH = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getDataSwitch())) {
            builder.append("X_DATA_SWITCH = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd71GprsApn())) {
            builder.append("CMD_71_GPRS_APN = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd150ClearProxy())) {
            builder.append("CMD_150_CLEAR_PROXY = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd121GatewayPortUpdate())) {
            builder.append("CMD_121_GATEWAY_PORT_UPDATE = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd121GatewayIpUpdate())) {
            builder.append("CMD_121_GATEWAY_IP_UPDATE = ?");
            builder.append(AND);
        }
        return searchDataConfigStatement2(builder, tracfoneOneDataConfig);
    }

    private String searchDataConfigStatement2(StringBuilder builder, TracfoneOneDataConfig tracfoneOneDataConfig) {
        String searchQuery = "";
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd71MmscUpdate())) {
            builder.append("CMD_71_MMSC_UPDATE = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd71GatewayHome())) {
            builder.append("CMD_71_GATEWAY_HOME = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneDataConfig.getCmd121GatewayIpPortUpdate())) {
            builder.append("CMD_121_GATEWAY_IP_PORT_UPDATE = ?");
            builder.append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query for Data Config Mapping is : " + searchQuery);
        return searchQuery;
    }

    @Override
    public List<TFOnePartClass> getAllPartClasses(String dbEnv) throws TracfoneOneException {
        List<TFOnePartClass> partClasses = new ArrayList<>(1);
        TFOnePartClass partClass;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_PART_CLASSES);) {

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    partClass = new TFOnePartClass();
                    partClass.setObjId(resultSet.getString(OBJID));
                    partClass.setName(resultSet.getString("NAME"));
                    partClasses.add(partClass);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return partClasses;
    }

    @Override
    public TFOneGeneralResponse deleteOrderType(TracfoneOneOrderType tracfoneOneOrderType, int userId) throws TracfoneOneException {
        LOGGER.info("Order Type being deleted - " + tracfoneOneOrderType);
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneOrderType.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_ORDER_TYPE);) {
            stmt.setLong(1, Long.valueOf(tracfoneOneOrderType.getObjId()));
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Order Type",
                    "Deleted Order Type Object " + tracfoneOneOrderType.getObjId(), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneOrderType.getObjId());
    }

    @Override
    public TFOneGeneralResponse insertIgOrderTypes(TracfoneOneIgOrderType tracfoneOneIgOrderType, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneIgOrderType.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_IG_ORDER_TYPES);) {
            setIgOrderTypeStatement(stmt, tracfoneOneIgOrderType);
            stmt.execute();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert IG Order Type", "Inserted IG Order Type Object " + tracfoneOneIgOrderType, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneIgOrderType.getProgrammeName());
    }

    @Override
    public boolean isDuplicateOrderType(TracfoneOneIgOrderType searchOrderType) throws TracfoneOneException {
        boolean isDuplicate = false;
        try (Connection con = dbControllerEJB.getDataSource(searchOrderType.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_VIEW_IG_ORDER_TYPES);) {
            setSearchParams(stmt, searchOrderType);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    isDuplicate = true;
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return isDuplicate;
    }

    @Override
    public TFOneGeneralResponse insertThrottlePolicy(TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy, int userId) throws TracfoneOneException {
        String objid = "";
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneThrottlePolicy.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_THROTTLE_POLICY);) {
            TracfoneOneThrottlePolicy searchThrottlePolicy = new TracfoneOneThrottlePolicy();
            searchThrottlePolicy.setDbEnv(tracfoneOneThrottlePolicy.getDbEnv());
            searchThrottlePolicy.setPolicyName(tracfoneOneThrottlePolicy.getPolicyName());
            if (searchThrottlePolicies(searchThrottlePolicy).isEmpty()) {
                objid = getNextSequence(con, THROTTLE_POLICY_ID_SEQ_STMT, "THROTTLE_POLICY_ID_SEQ");
                tracfoneOneThrottlePolicy.setObjId(objid);
                setThrottlePolicyStatement(stmt, tracfoneOneThrottlePolicy);
                stmt.executeUpdate();
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Throttle Policy", "Inserted Throttle Policy" + tracfoneOneThrottlePolicy, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, objid);
    }

    @Override
    public TFOneGeneralResponse insertThrottleRules(List<TracfoneOneThrottleRule> tracfoneOneThrottleRules, int userId) throws TracfoneOneException {
        List<String> objIds = new ArrayList<>(1);
        LOGGER.info("Throttle Rules going to be added " + tracfoneOneThrottleRules);
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneThrottleRules.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_THROTTLE_RULE);) {
            // if there is only one rule being sent it is likely to be with multiple parent ids
            if (tracfoneOneThrottleRules.size() == 1) {
                TracfoneOneThrottleRule tracfoneOneThrottleRule = tracfoneOneThrottleRules.get(0);
                if (tracfoneOneThrottleRule.getParentId().contains(",")) {
                    tracfoneOneThrottleRules.clear();
                    tracfoneOneThrottleRules.addAll(splitParentIdsIntoRules(tracfoneOneThrottleRule));
                    LOGGER.info("Throttle Rules split by parent id " + tracfoneOneThrottleRules);
                }
            }
            for (TracfoneOneThrottleRule tracfoneOneThrottleRule : tracfoneOneThrottleRules) {
                // first check for duplicate before inserting
                TracfoneOneThrottleRule searchThrottleRule = getSearchThrottleRule(tracfoneOneThrottleRule, tracfoneOneThrottleRule.getParentId());
                if (searchThrottleRules(searchThrottleRule).isEmpty()) {
                    String objId = getNextSequence(con, THROTTLE_RULE_ID_SEQ_STMT, "THROTTLE_RULE_ID_SEQ");
                    tracfoneOneThrottleRule.setObjId(objId);
                    setThrottleRuleStatement(stmt, tracfoneOneThrottleRule);
                    stmt.addBatch();
                    objIds.add(objId);
                }
            }

            LOGGER.info("Throttle Rules going to be added " + tracfoneOneThrottleRules);
            int[] count = stmt.executeBatch();
            LOGGER.info(CARRIER_GROUPS_LISTS_ADDED + count);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Throttle Rule", "Inserted Throttle Rule" + tracfoneOneThrottleRules, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, objIds.toString());
    }

    private List<TracfoneOneThrottleRule> splitParentIdsIntoRules(TracfoneOneThrottleRule tracfoneOneThrottleRule) {
        List<TracfoneOneThrottleRule> rules = new ArrayList<>(1);
        TracfoneOneThrottleRule singleParentIdRule = null;
        for (String parentId : tracfoneOneThrottleRule.getParentId().split(",")) {
            singleParentIdRule = new TracfoneOneThrottleRule();
            singleParentIdRule.setStatus(tracfoneOneThrottleRule.getStatus());
            singleParentIdRule.setDbEnv(tracfoneOneThrottleRule.getDbEnv());
            singleParentIdRule.setParentId(parentId);
            singleParentIdRule.setPolicyId(tracfoneOneThrottleRule.getPolicyId());
            singleParentIdRule.setRuleDesc(tracfoneOneThrottleRule.getRuleDesc());
            rules.add(singleParentIdRule);
        }
        return rules;
    }

    private TracfoneOneThrottleRule getSearchThrottleRule(TracfoneOneThrottleRule tracfoneOneThrottleRule, String parentId) {
        TracfoneOneThrottleRule searchThrottleRule = new TracfoneOneThrottleRule();
        searchThrottleRule.setDbEnv(tracfoneOneThrottleRule.getDbEnv());
        searchThrottleRule.setRuleDesc(tracfoneOneThrottleRule.getRuleDesc());
        searchThrottleRule.setParentId(parentId);
        searchThrottleRule.setPolicyId(tracfoneOneThrottleRule.getPolicyId());
        return searchThrottleRule;
    }

    @Override
    public TFOneGeneralResponse insertThrottleFeatures(List<TracfoneOneThrottleFeature> tracfoneOneThrottleFeatures, int userId) throws TracfoneOneException {
        String objid = "";
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneThrottleFeatures.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_THROTTLE_FEATURE);) {
            for (TracfoneOneThrottleFeature tracfoneOneThrottleFeature : tracfoneOneThrottleFeatures) {
                // first check for duplicates
                TracfoneOneThrottleFeature searchThrottleFeatures = new TracfoneOneThrottleFeature();
                searchThrottleFeatures.setDbEnv(tracfoneOneThrottleFeature.getDbEnv());
                searchThrottleFeatures.setRuleId(tracfoneOneThrottleFeature.getRuleId());
                searchThrottleFeatures.setFeatureFlagName(tracfoneOneThrottleFeature.getFeatureFlagName());
                searchThrottleFeatures.setFeatureName(tracfoneOneThrottleFeature.getFeatureName());
                if (searchThrottleFeatures(searchThrottleFeatures).isEmpty()) {
                    objid = getNextSequence(con, THROTTLE_FEATURE_ID_SEQ_STMT, "THROTTLE_FEATURE_ID_SEQ");
                    tracfoneOneThrottleFeature.setObjId(objid);
                    setThrottleFeatureStatement(stmt, tracfoneOneThrottleFeature);
                    stmt.addBatch();
                }
            }
            LOGGER.info("Throttle Features going to be added " + tracfoneOneThrottleFeatures);
            int[] count = stmt.executeBatch();
            LOGGER.info(CARRIER_GROUPS_LISTS_ADDED + count);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Throttle Feature", "Inserted Throttle Feature" + tracfoneOneThrottleFeatures, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, objid);
    }

    @Override
    public List<TFOneThrottlePolicy> searchThrottlePolicies(TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy) throws TracfoneOneException {
        List<TFOneThrottlePolicy> tfOneThrottlePolicies = new ArrayList<>(1);
        TFOneThrottlePolicy tfOneThrottlePolicy;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneThrottlePolicy.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchThrottlePolicyStatement(tracfoneOneThrottlePolicy));) {
            setThrottlePolicyQueryParams(stmt, tracfoneOneThrottlePolicy);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneThrottlePolicy = new TFOneThrottlePolicy();
                    tfOneThrottlePolicy.setObjId(resultSet.getString(OBJID));
                    tfOneThrottlePolicy.setPolicyName(resultSet.getString("X_POLICY_NAME"));
                    tfOneThrottlePolicy.setPolicyDesc(resultSet.getString("X_POLICY_DESCRIPTION"));
                    tfOneThrottlePolicy.setBypassTransQueue(resultSet.getString("X_BYPASS_TRANS_QUEUE"));
                    tfOneThrottlePolicy.setDataSuspendedFlag(resultSet.getString("DATA_SUSPENDED_FLAG"));
                    tfOneThrottlePolicies.add(tfOneThrottlePolicy);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneThrottlePolicies;
    }

    @Override
    public List<TFOneThrottleRule> searchThrottleRules(TracfoneOneThrottleRule tracfoneOneThrottleRule) throws TracfoneOneException {
        List<TFOneThrottleRule> tfOneThrottleRules = new ArrayList<>(1);
        TFOneThrottleRule tfOneThrottleRule;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneThrottleRule.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchThrottleRuleStatement(tracfoneOneThrottleRule));) {
            setThrottleRuleQueryParams(stmt, tracfoneOneThrottleRule);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneThrottleRule = new TFOneThrottleRule();
                    tfOneThrottleRule.setObjId(resultSet.getString(OBJID));
                    tfOneThrottleRule.setParentId(resultSet.getString(X_PARENT_ID));
                    tfOneThrottleRule.setPolicyId(resultSet.getString("X_POLICY_ID"));
                    tfOneThrottleRule.setRuleDesc(resultSet.getString("X_RULE_DESCRIPTION"));
                    tfOneThrottleRule.setStatus(resultSet.getString(X_STATUS));
                    tfOneThrottleRules.add(tfOneThrottleRule);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneThrottleRules;
    }

    @Override
    public List<TFOneThrottleFeature> searchThrottleFeatures(TracfoneOneThrottleFeature tracfoneOneThrottleFeature) throws TracfoneOneException {
        List<TFOneThrottleFeature> tfOneThrottleFeatures = new ArrayList<>(1);
        TFOneThrottleFeature tfOneThrottleFeature;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneThrottleFeature.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchThrottleFeaturesStatement(tracfoneOneThrottleFeature));) {
            setThrottleFeatureQueryParams(stmt, tracfoneOneThrottleFeature);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneThrottleFeature = new TFOneThrottleFeature();
                    tfOneThrottleFeature.setObjId(resultSet.getString(OBJID));
                    tfOneThrottleFeature.setRuleId(resultSet.getString("X_RULE_ID"));
                    tfOneThrottleFeature.setFeatureFlagName(resultSet.getString("X_FEATURE_FLAG_NAME"));
                    tfOneThrottleFeature.setFeatureFlagValue(resultSet.getString("X_FEATURE_FLAG_VALUE"));
                    tfOneThrottleFeature.setFeatureName(resultSet.getString("X_FEATURE_NAME"));
                    tfOneThrottleFeature.setFeatureValue(resultSet.getString("X_FEATURE_VALUE"));
                    tfOneThrottleFeature.setStatus(resultSet.getString(X_STATUS));
                    tfOneThrottleFeatures.add(tfOneThrottleFeature);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneThrottleFeatures;
    }

    @Override
    public TFOneGeneralResponse updateThrottlePolicy(TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneThrottlePolicy.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_THROTTLE_POLICY);) {
            LOGGER.info("Throttle Policy sent for update is " + tracfoneOneThrottlePolicy);
            LOGGER.info(TRACFONE_UPDATE_THROTTLE_POLICY);
            setThrottlePolicyStatement(stmt, tracfoneOneThrottlePolicy);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Throttle Policy", "Updated Throttle Policy object " + tracfoneOneThrottlePolicy, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneThrottlePolicy.getObjId());
    }

    @Override
    public TFOneGeneralResponse updateThrottleRule(TracfoneOneThrottleRule tracfoneOneThrottleRule, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneThrottleRule.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_THROTTLE_RULE);) {
            LOGGER.info("Throttle Rule sent for update is " + tracfoneOneThrottleRule);
            LOGGER.info(TRACFONE_UPDATE_THROTTLE_RULE);
            setThrottleRuleStatement(stmt, tracfoneOneThrottleRule);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Throttle Rule", "Updated Throttle Rule object " + tracfoneOneThrottleRule, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneThrottleRule.getObjId());
    }

    @Override
    public TFOneGeneralResponse updateThrottleFeature(TracfoneOneThrottleFeature tracfoneOneThrottleFeature, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneThrottleFeature.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_THROTTLE_FEATURE);) {
            LOGGER.info("Throttle Feature sent for update is " + tracfoneOneThrottleFeature);
            LOGGER.info(TRACFONE_UPDATE_THROTTLE_FEATURE);
            setThrottleFeatureStatement(stmt, tracfoneOneThrottleFeature);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Throttle Feature", "Updated Throttle Feature object " + tracfoneOneThrottleFeature, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneThrottleFeature.getObjId());
    }

    @Override
    public TFOneGeneralResponse updateIgOrderTypes(TracfoneOneIgOrderType tracfoneOneIgOrderType, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneIgOrderType.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_IG_ORDER_TYPES);) {
            LOGGER.info("IG ORDER TYPE sent for update is " + tracfoneOneIgOrderType);
            setIgOrderTypeStatement(stmt, tracfoneOneIgOrderType);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update IG Order Type", "Updated IG Order Type object " + tracfoneOneIgOrderType, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneIgOrderType.getProgrammeName());
    }

    @Override
    public List<TFOneIgOrderType> searchIgOrderTypes(TracfoneOneIgOrderType tracfoneOneIgOrderType, boolean searchAll) throws TracfoneOneException {
        List<TFOneIgOrderType> tfOneIgOrderTypes = new ArrayList<>(1);
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneIgOrderType.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchIgOrderTypeStatement(tracfoneOneIgOrderType, searchAll));) {
            setIgOrderTypesQueryParams(stmt, tracfoneOneIgOrderType);
            TFOneIgOrderType tfOneIGOrderType;
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneIGOrderType = new TFOneIgOrderType();
                    if (searchAll) {
                        tfOneIGOrderType.setIgOrderType(resultSet.getString("X_IG_ORDER_TYPE"));
                    } else {
                        tfOneIGOrderType.setProgrammeName(resultSet.getString("X_PROGRAMME_NAME"));
                        tfOneIGOrderType.setActualOrderType(resultSet.getString("X_ACTUAL_ORDER_TYPE"));
                        tfOneIGOrderType.setIgOrderType(resultSet.getString("X_IG_ORDER_TYPE"));
                        tfOneIGOrderType.setSqlText(resultSet.getString("X_SQL_TEXT"));
                        tfOneIGOrderType.setPriority(resultSet.getString("X_PRIORITY"));
                        tfOneIGOrderType.setCreateSOGencodeFlag(resultSet.getString("CREATE_SO_GENCODE_FLAG"));
                        tfOneIGOrderType.setCreateMFormIGFlag(resultSet.getString("CREATE_MFORM_IG_FLAG"));
                        tfOneIGOrderType.setCreateMFormPortFlag(resultSet.getString("CREATE_MFORM_PORT_FLAG"));
                        tfOneIGOrderType.setSkipMinValidationForm(resultSet.getString("SKIP_MIN_VALIDATION_FLAG"));
                        tfOneIGOrderType.setSkipESNValidationFlag(resultSet.getString("SKIP_ESN_VALIDATION_FLAG"));
                        tfOneIGOrderType.setCreateIGAPNFlag(resultSet.getString("CREATE_IG_APN_FLAG"));
                        tfOneIGOrderType.setInsertILDTransFlag(resultSet.getString("INSERT_ILD_TRANS_FLAG"));
                        tfOneIGOrderType.setBogoConfigFlag(resultSet.getString("X_BOGO_CONFIG_FLAG"));
                        tfOneIGOrderType.setsUIActionType(resultSet.getString("SUI_ACTION_TYPE"));
                        tfOneIGOrderType.setUpdateMSIDFlag(resultSet.getString("UPDATE_MSID_FLAG"));
                        tfOneIGOrderType.setAddonCashCardFlag(resultSet.getString("ADDON_CASH_CARD_FLAG"));
                        tfOneIGOrderType.setContactPinUpdateFlag(resultSet.getString("CONTACT_PIN_UPDATE_FLAG"));
                        tfOneIGOrderType.setBrmNotificationFlag(resultSet.getString("BRM_NOTIFICATION_FLAG"));
                        tfOneIGOrderType.setNewerTransFlag(resultSet.getString("NEWER_TRANS_FLAG"));
                        tfOneIGOrderType.setSkipMinUpdateFlag(resultSet.getString("SKIP_MIN_UPDATE_FLAG"));
                        tfOneIGOrderType.setSafeLinkBatchFlag(resultSet.getString("SAFELINK_BATCH_FLAG"));
                        tfOneIGOrderType.setCreateBucketsFlag(resultSet.getString("CREATE_BUCKETS_FLAG"));
                        tfOneIGOrderType.setProcessIgateIN3Flag(resultSet.getString("PROCESS_IGATE_IN3_FLAG"));
                        tfOneIGOrderType.setProcessIgateIN3LiteFlag(resultSet.getString("PROCESS_IGATE_IN3_LITE_FLAG"));
                        tfOneIGOrderType.setUpdateXCase2TaskFlag(resultSet.getString("UPDATE_X_CASE2TASK_FLAG"));
                        tfOneIGOrderType.setDepIGTransFlag(resultSet.getString("DEP_IG_TRANS_FLAG"));
                        tfOneIGOrderType.setGenerateAccountFlag(resultSet.getString("GENERATE_ACCOUNT_FLAG"));
                        tfOneIGOrderType.setCreateIGACMFlag(resultSet.getString("CREATE_IG_ACM_FLAG"));
                    }
                    tfOneIgOrderTypes.add(tfOneIGOrderType);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneIgOrderTypes;
    }

    @Override
    public List<TFOneVerizonZipNPANXX> searchVerizonZipNPANXX(TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX) throws TracfoneOneException {
        List<TFOneVerizonZipNPANXX> tfOneVerizonZipNPANXXs = new ArrayList<>(1);
        TFOneVerizonZipNPANXX tfOneVerizonZipNPANXX;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneVerizonZipNPANXX.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchVerizonZipNPANXXStatement(tracfoneOneVerizonZipNPANXX));) {
            setVerizonZipNPANXXQueryParams(stmt, tracfoneOneVerizonZipNPANXX);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneVerizonZipNPANXX = new TFOneVerizonZipNPANXX();
                    tfOneVerizonZipNPANXX.setZip(resultSet.getString("ZIP"));
                    tfOneVerizonZipNPANXX.setnPA(resultSet.getString("NPA"));
                    tfOneVerizonZipNPANXX.setnXX(resultSet.getString("NXX"));
                    tfOneVerizonZipNPANXX.setnPANXX(resultSet.getString("NPANXX"));
                    tfOneVerizonZipNPANXX.setAccountNum(resultSet.getString("ACCOUNT_NUM"));
                    tfOneVerizonZipNPANXX.setTemplate(resultSet.getString("TEMPLATE"));
                    tfOneVerizonZipNPANXXs.add(tfOneVerizonZipNPANXX);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneVerizonZipNPANXXs;
    }

    @Override
    public TFOneGeneralResponse updateVerizonZipNPANXX(TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneVerizonZipNPANXX.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_VERIZON_ZIP_NPANXX);) {
            LOGGER.info("Verizon ZIP NPANXX sent for update is " + tracfoneOneVerizonZipNPANXX);
            LOGGER.info(TRACFONE_UPDATE_VERIZON_ZIP_NPANXX);
            setVerizonZipNPANXX(stmt, tracfoneOneVerizonZipNPANXX);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Verizon Zip NPANXX", "Updated Verizon Zip NPANXX " + tracfoneOneVerizonZipNPANXX, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneVerizonZipNPANXX.getnPANXX());
    }

    @Override
    public TFOneGeneralResponse insertVerizonZipNPANXX(TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX, int userId, String unique) throws TracfoneOneException {
        String uniqueId = "";
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneVerizonZipNPANXX.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_VERIZON_ZIP_NPANXX);) {
            TracfoneOneVerizonZipNPANXX searchVZN = new TracfoneOneVerizonZipNPANXX();
            searchVZN.setZip(tracfoneOneVerizonZipNPANXX.getZip());
            searchVZN.setnPANXX(tracfoneOneVerizonZipNPANXX.getnPANXX());
            searchVZN.setAccountNum(tracfoneOneVerizonZipNPANXX.getAccountNum());
            searchVZN.setDbEnv(tracfoneOneVerizonZipNPANXX.getDbEnv());
            if (searchVerizonZipNPANXX(searchVZN).isEmpty()) {
                uniqueId = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
                for (String zip : tracfoneOneVerizonZipNPANXX.getZip().split(",")) {
                    tracfoneOneVerizonZipNPANXX.setZip(zip);
                    setVerizonZipQueryParams(stmt, tracfoneOneVerizonZipNPANXX);
                    stmt.addBatch();
                }
                stmt.executeBatch();
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit;
            // Added this logic to track bulk insert of Verizon ZIP NPANXX
            if (StringUtils.isNullOrEmpty(unique)) {
                audit = new TracfoneAudit(userId, "Insert Verizon ZIP NPANXX",
                        "Inserted Verizon ZIP NPANXX Object " + tracfoneOneVerizonZipNPANXX, null);
            } else {
                audit = new TracfoneAudit(userId, "Bulk Verizon ZIP NPANXX Insert",
                        "Inserted Verizon ZIP NPANXXs Object " + tracfoneOneVerizonZipNPANXX, CARRIERID + unique);
            }
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, uniqueId);
    }

    @Override
    public TFOneGeneralResponse deleteVerizonZipNPANXX(TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneVerizonZipNPANXX.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_VERIZON_ZIP_NPANXX);) {
            LOGGER.info(TRACFONE_DELETE_VERIZON_ZIP_NPANXX);
            setVerizonZipNPANXXStatement(stmt, tracfoneOneVerizonZipNPANXX);
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Verizon ZIP NPZNXX", "Deleted Verizon ZIP NPZNXX Object " + tracfoneOneVerizonZipNPANXX, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneVerizonZipNPANXX.getnPANXX());
    }

    @Override
    public List<TFOneTmoZipNgp> searchTmoZipNgp(TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp) throws TracfoneOneException {
        List<TFOneTmoZipNgp> tfOneTmoZipNgps = new ArrayList<>(1);
        TFOneTmoZipNgp tfOneTmoZipNgp;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneTmoZipNgp.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchTmoZipNgpStatement(tracfoneOneTmoZipNgp));) {
            setTmoZipNgpQueryParams(stmt, tracfoneOneTmoZipNgp);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneTmoZipNgp = new TFOneTmoZipNgp();
                    tfOneTmoZipNgp.setZip(resultSet.getString("X_ZIP"));
                    tfOneTmoZipNgp.setNgp(resultSet.getString("X_NGP"));
                    tfOneTmoZipNgp.setNgpName(resultSet.getString("X_NGP_NAME"));
                    tfOneTmoZipNgp.setPriority(resultSet.getString("X_PRIORITY"));
                    tfOneTmoZipNgps.add(tfOneTmoZipNgp);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneTmoZipNgps;
    }

    @Override
    public TFOneGeneralResponse insertTmoZipNgp(TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp, int userId, String unique) throws TracfoneOneException {
        String uniqueId = "";
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneTmoZipNgp.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_TMO_ZIP_NGP);) {
            TracfoneOneTmoZipNgp searchTmoZipNgp = new TracfoneOneTmoZipNgp();
            searchTmoZipNgp.setZip(tracfoneOneTmoZipNgp.getZip());
            searchTmoZipNgp.setPriority(tracfoneOneTmoZipNgp.getPriority());
            searchTmoZipNgp.setDbEnv(tracfoneOneTmoZipNgp.getDbEnv());
            if (searchTmoZipNgp(searchTmoZipNgp).isEmpty()) {
                uniqueId = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
                for (String zip : tracfoneOneTmoZipNgp.getZip().split(",")) {
                    tracfoneOneTmoZipNgp.setZip(zip);
                    setTmoZipNgpParams(stmt, tracfoneOneTmoZipNgp);
                    stmt.addBatch();
                }
                stmt.executeBatch();
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit;
            // Added this logic to track bulk insert of TMO ZIP NGP
            if (StringUtils.isNullOrEmpty(unique)) {
                audit = new TracfoneAudit(userId, "Insert TMO ZIP NGP",
                        "Inserted TMO ZIP NGP Object " + tracfoneOneTmoZipNgp, null);
            } else {
                audit = new TracfoneAudit(userId, "Bulk TMO ZIP NGP Insert",
                        "Inserted TMO ZIP NGP Object " + tracfoneOneTmoZipNgp, CARRIERID + unique);
            }
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, uniqueId);
    }

    @Override
    public TFOneGeneralResponse updateTmoZipNgp(TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneTmoZipNgp.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_TMO_ZIP_NGP);) {
            LOGGER.info("TMO ZIP NGP sent for update is " + tracfoneOneTmoZipNgp);
            LOGGER.info(TRACFONE_UPDATE_TMO_ZIP_NGP);
            setTmoZipNgpUpdateParams(stmt, tracfoneOneTmoZipNgp);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update TMO ZIP NGP", "Updated TMO ZIP NGP" + tracfoneOneTmoZipNgp, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneTmoZipNgp.getNgp());
    }

    @Override
    public TFOneGeneralResponse deleteTmoZipNgp(TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneTmoZipNgp.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_TMO_ZIP_NGP);) {
            LOGGER.info(TRACFONE_DELETE_TMO_ZIP_NGP);
            setTmoZipNgpDeleteParams(stmt, tracfoneOneTmoZipNgp);
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Verizon ZIP NPZNXX", "Deleted Verizon ZIP NPZNXX Object " + tracfoneOneTmoZipNgp, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneTmoZipNgp.getNgp());
    }

    @Override
    public List<TFOneCingularMrktInfo> searchCingularMrktInfo(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo) throws TracfoneOneException {
        List<TFOneCingularMrktInfo> info = new ArrayList<>(1);
        TFOneCingularMrktInfo tfOneCingularMrktInfo;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCingularMrktInfo.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchCingularMrktInfoStatement(tracfoneOneCingularMrktInfo));) {
            setCingularMrktInfoQueryParams(stmt, tracfoneOneCingularMrktInfo);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneCingularMrktInfo = new TFOneCingularMrktInfo();
                    tfOneCingularMrktInfo.setMkt(resultSet.getString("MKT"));
                    tfOneCingularMrktInfo.setNpa(resultSet.getString("NPA"));
                    tfOneCingularMrktInfo.setNxx(resultSet.getString("NXX"));
                    tfOneCingularMrktInfo.setNpanxx(resultSet.getString("NPANXX"));
                    tfOneCingularMrktInfo.setRcNumber(resultSet.getString("RC_NUMBER"));
                    tfOneCingularMrktInfo.setRcName(resultSet.getString("RC_NAME"));
                    tfOneCingularMrktInfo.setRcState(resultSet.getString("RC_STATE"));
                    tfOneCingularMrktInfo.setZip(resultSet.getString("ZIP"));
                    tfOneCingularMrktInfo.setMktType(resultSet.getString("MKT_TYPE"));
                    tfOneCingularMrktInfo.setAccountNum(resultSet.getString("ACCOUNT_NUM"));
                    tfOneCingularMrktInfo.setMarketCode(resultSet.getString("MARKET_CODE"));
                    tfOneCingularMrktInfo.setDealerCode(resultSet.getString("DEALER_CODE"));
                    tfOneCingularMrktInfo.setSubMarketId(resultSet.getString("SUBMARKETID"));
                    tfOneCingularMrktInfo.setTemplate(resultSet.getString("TEMPLATE"));
                    info.add(tfOneCingularMrktInfo);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return info;
    }

    @Override
    public TFOneGeneralResponse insertCingularMrktInfo(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo, int userId, String unique) throws TracfoneOneException {
        String uniqueId = "";
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCingularMrktInfo.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_CINGULAR_MRKT_INFO);) {
            TracfoneOneCingularMrktInfo searchCingularMrktinfo = new TracfoneOneCingularMrktInfo();
            searchCingularMrktinfo.setDbEnv(tracfoneOneCingularMrktInfo.getDbEnv());
            searchCingularMrktinfo.setZip(tracfoneOneCingularMrktInfo.getZip());
            if (searchCingularMrktInfo(searchCingularMrktinfo).isEmpty()) {
                uniqueId = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
                for (String zip : tracfoneOneCingularMrktInfo.getZip().split(",")) {
                    tracfoneOneCingularMrktInfo.setZip(zip);
                    setCingularmrktinfoParams(stmt, tracfoneOneCingularMrktInfo);
                    stmt.addBatch();
                }
                stmt.executeBatch();
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit;
            // Added this logic to track bulk insert of TMO ZIP NGP
            if (StringUtils.isNullOrEmpty(unique)) {
                audit = new TracfoneAudit(userId, "Insert Cingular Mrkt Info",
                        "Inserted Cingular Mrkt Info Object " + tracfoneOneCingularMrktInfo, null);
            } else {
                audit = new TracfoneAudit(userId, "Bulk Cingular Mrkt Info Insert",
                        "Inserted Cingular Mrkt Info " + tracfoneOneCingularMrktInfo, CARRIERID + unique);
            }
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, uniqueId);
    }

    @Override
    public TFOneGeneralResponse updateCingularMrktInfo(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCingularMrktInfo.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CINGULAR_MRKT_INFO);) {
            LOGGER.info("Cingular Mrkt Info sent for update is " + tracfoneOneCingularMrktInfo);
            LOGGER.info(TRACFONE_UPDATE_CINGULAR_MRKT_INFO);
            setCingularMrktInfoUpdateParams(stmt, tracfoneOneCingularMrktInfo);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Cingular Mrkt Info", "Updated Cingular Mrkt Info" + tracfoneOneCingularMrktInfo, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneCingularMrktInfo.getZip());
    }

    @Override
    public TFOneGeneralResponse deleteCingularMrktInfo(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCingularMrktInfo.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_CINGULAR_MRKT_INFO);) {
            LOGGER.info(TRACFONE_DELETE_CINGULAR_MRKT_INFO);
            stmt.setString(1, tracfoneOneCingularMrktInfo.getZip());
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Cingular Mrkt Info", "Deleted Cingular Mrkt Info Object " + tracfoneOneCingularMrktInfo, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneCingularMrktInfo.getZip());
    }

    @Override
    public List<TFOneNotCertifyModel> searchNotCertifyModel(TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel) throws TracfoneOneException {
        List<TFOneNotCertifyModel> tfOneNotCertifyModels = new ArrayList<>(1);
        TFOneNotCertifyModel tfOneNotCertifyModel;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNotCertifyModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchNotcertifyModelStatement(tracfoneOneNotCertifyModel));) {
            setNotcertifyModelQueryParams(stmt, tracfoneOneNotCertifyModel);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneNotCertifyModel = new TFOneNotCertifyModel();
                    tfOneNotCertifyModel.setObjId(resultSet.getString(OBJID));
                    tfOneNotCertifyModel.setDev(resultSet.getString("DEV"));
                    tfOneNotCertifyModel.setParentId(resultSet.getString(X_PARENT_ID));
                    tfOneNotCertifyModel.setPartClassObjId(resultSet.getString(X_PART_CLASS_OBJID));
                    tfOneNotCertifyModels.add(tfOneNotCertifyModel);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneNotCertifyModels;
    }

    @Override
    public TFOneGeneralResponse insertNotCertifyModel(TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel, int userId, String unique) throws TracfoneOneException {
        String objid = "";
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNotCertifyModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_NOT_CERTIFY_MODEL);) {
            TracfoneOneNotCertifyModel searchNotCertifyModel = new TracfoneOneNotCertifyModel();
            searchNotCertifyModel.setDbEnv(tracfoneOneNotCertifyModel.getDbEnv());
            searchNotCertifyModel.setParentId(tracfoneOneNotCertifyModel.getParentId());
            searchNotCertifyModel.setPartClassObjId(tracfoneOneNotCertifyModel.getPartClassObjId());
            searchNotCertifyModel.setDev(tracfoneOneNotCertifyModel.getDev());
            if (searchNotCertifyModel(searchNotCertifyModel).isEmpty()) {
                objid = getNextSequence(con, SEQU_X_NOT_CERTIFY_MODELS_STMT, "SEQU_X_NOT_CERTIFY_MODELS_SEQ");
                tracfoneOneNotCertifyModel.setObjId(objid);
                setNotCertifyModelParams(stmt, tracfoneOneNotCertifyModel);
                stmt.executeUpdate();
            }

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit;
            // Added this logic to track bulk insert of Not Certify Model
            if (StringUtils.isNullOrEmpty(unique)) {
                audit = new TracfoneAudit(userId, "Insert Not Certify Model",
                        "Inserted Not Certify Model Object " + tracfoneOneNotCertifyModel, null);
            } else {
                audit = new TracfoneAudit(userId, "Bulk Not Certify Model Insert",
                        "Inserted Not Certify Model " + tracfoneOneNotCertifyModel, CARRIERID + unique);
            }
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, objid);
    }

    @Override
    public TFOneGeneralResponse updateNotCertifyModel(TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNotCertifyModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_NOT_CERTIFY_MODEL);) {
            LOGGER.info("Not Certify Model sent for update is " + tracfoneOneNotCertifyModel);
            LOGGER.info(TRACFONE_UPDATE_NOT_CERTIFY_MODEL);
            setNotCertifyModelUpdateParams(stmt, tracfoneOneNotCertifyModel);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Not Certify Model", "Updated Not Certify Model" + tracfoneOneNotCertifyModel, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneNotCertifyModel.getObjId());
    }

    @Override
    public TFOneGeneralResponse deleteNotCertifyModel(TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNotCertifyModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_NOT_CERTIFY_MODEL);) {
            LOGGER.info(TRACFONE_DELETE_NOT_CERTIFY_MODEL);
            stmt.setString(1, tracfoneOneNotCertifyModel.getObjId());
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Not Certify Model", "Deleted Not Certify Model " + tracfoneOneNotCertifyModel, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneNotCertifyModel.getObjId());
    }

    @Override
    public TFOneGeneralResponse bulkUpdateNotCertifyModel(List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModels, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNotCertifyModels.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_NOT_CERTIFY_MODEL);) {
            for (TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel : tracfoneOneNotCertifyModels) {
                TracfoneOneNotCertifyModel searchNotCertifyModel = new TracfoneOneNotCertifyModel();
                searchNotCertifyModel.setDbEnv(tracfoneOneNotCertifyModels.get(0).getDbEnv());
                searchNotCertifyModel.setDev(tracfoneOneNotCertifyModel.getDev());
                searchNotCertifyModel.setParentId(tracfoneOneNotCertifyModel.getParentId());
                searchNotCertifyModel.setPartClassObjId(tracfoneOneNotCertifyModel.getPartClassObjId());
                if (searchNotCertifyModel(searchNotCertifyModel).isEmpty()) {
                    setNotCertifyModelUpdateParams(stmt, tracfoneOneNotCertifyModel);
                    stmt.executeUpdate();
                }
            }

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Bulk Update Not Certify Model", "Bulk Updated Not Certify Model" + tracfoneOneNotCertifyModels, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneNotCertifyModels.get(0).getObjId());
    }

    private void setIgOrderTypeStatement(PreparedStatement stmt, TracfoneOneIgOrderType tracfoneOneIgOrderType) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneIgOrderType.getActualOrderType());
        stmt.setString(index++, tracfoneOneIgOrderType.getSqlText());
        stmt.setString(index++, tracfoneOneIgOrderType.getCreateSOGencodeFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getCreateMFormIGFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getCreateMFormPortFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getSkipMinValidationForm());
        stmt.setString(index++, tracfoneOneIgOrderType.getSkipESNValidationFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getCreateIGAPNFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getInsertILDTransFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getBogoConfigFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getsUIActionType());
        stmt.setString(index++, tracfoneOneIgOrderType.getUpdateMSIDFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getAddonCashCardFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getContactPinUpdateFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getBrmNotificationFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getNewerTransFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getSkipMinUpdateFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getSafeLinkBatchFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getCreateBucketsFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getProcessIgateIN3Flag());
        stmt.setString(index++, tracfoneOneIgOrderType.getProcessIgateIN3LiteFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getUpdateXCase2TaskFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getDepIGTransFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getGenerateAccountFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getCreateIGACMFlag());
        stmt.setString(index++, tracfoneOneIgOrderType.getProgrammeName());
        stmt.setString(index++, tracfoneOneIgOrderType.getIgOrderType());
        stmt.setString(index, tracfoneOneIgOrderType.getPriority());
    }

    private void setSearchParams(PreparedStatement stmt, TracfoneOneIgOrderType tracfoneOneIgOrderType) throws SQLException {
        stmt.setString(1, tracfoneOneIgOrderType.getProgrammeName().trim().toUpperCase());
        stmt.setString(2, tracfoneOneIgOrderType.getIgOrderType().trim().toUpperCase());
        stmt.setString(3, tracfoneOneIgOrderType.getPriority());
    }

    private int setIgOrderTypesQueryParams(PreparedStatement stmt, TracfoneOneIgOrderType tracfoneOneIgOrderType) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getProgrammeName())) {
            stmt.setString(index++, "%" + tracfoneOneIgOrderType.getProgrammeName().toUpperCase() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getActualOrderType())) {
            stmt.setString(index++, "%" + tracfoneOneIgOrderType.getActualOrderType().toUpperCase() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getIgOrderType())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getIgOrderType());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getSqlText())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getSqlText());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getPriority())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getPriority());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getCreateSOGencodeFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getCreateSOGencodeFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getCreateMFormIGFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getCreateMFormIGFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getCreateMFormPortFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getCreateMFormPortFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getSkipMinValidationForm())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getSkipMinValidationForm());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getSkipESNValidationFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getSkipESNValidationFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getCreateIGAPNFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getCreateIGAPNFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getInsertILDTransFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getInsertILDTransFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getBogoConfigFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getBogoConfigFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getsUIActionType())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getsUIActionType());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getUpdateMSIDFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getUpdateMSIDFlag());
        }
        return setIgOrderTypesQueryParams2(stmt, index, tracfoneOneIgOrderType);
    }

    private int setIgOrderTypesQueryParams2(PreparedStatement stmt, int index, TracfoneOneIgOrderType tracfoneOneIgOrderType) throws SQLException {
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getAddonCashCardFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getAddonCashCardFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getContactPinUpdateFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getContactPinUpdateFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getBrmNotificationFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getBrmNotificationFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getNewerTransFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getNewerTransFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getSkipMinUpdateFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getSkipMinUpdateFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getSafeLinkBatchFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getSafeLinkBatchFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getCreateBucketsFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getCreateBucketsFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getProcessIgateIN3Flag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getProcessIgateIN3Flag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getProcessIgateIN3LiteFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getProcessIgateIN3LiteFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getUpdateXCase2TaskFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getUpdateXCase2TaskFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getDepIGTransFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getDepIGTransFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getGenerateAccountFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getGenerateAccountFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getCreateIGACMFlag())) {
            stmt.setString(index++, tracfoneOneIgOrderType.getCreateIGACMFlag());
        }
        return index;
    }

    private String getSearchIgOrderTypeStatement(TracfoneOneIgOrderType tracfoneOneIgOrderType, boolean searchAll) {
        String searchQuery = "";
        if (searchAll) {
            searchQuery = TRACFONE_SEARCH_ALL_IG_ORDER_TYPES;
        } else {
            StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_IG_ORDER_TYPES);
            if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getProgrammeName())) {
                builder.append("UPPER(X_PROGRAMME_NAME) LIKE ? ").append(AND);
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getActualOrderType())) {
                builder.append("UPPER(X_ACTUAL_ORDER_TYPE) LIKE ? ").append(AND);
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getIgOrderType())) {
                builder.append("X_IG_ORDER_TYPE = ?").append(AND);
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getSqlText())) {
                builder.append("X_SQL_TEXT = ?").append(AND);
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getPriority())) {
                builder.append("X_PRIORITY = ?").append(AND);
            }
            searchQuery = getSearchIgOrderTypeStatementElse(builder, tracfoneOneIgOrderType);
        }
        LOGGER.info("Search Query for IG Order Types is : " + searchQuery);
        return searchQuery;
    }

    private String getSearchIgOrderTypeStatementElse(StringBuilder builder, TracfoneOneIgOrderType tracfoneOneIgOrderType) {
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getCreateSOGencodeFlag())) {
            builder.append("CREATE_SO_GENCODE_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getCreateMFormIGFlag())) {
            builder.append("CREATE_MFORM_IG_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getCreateMFormPortFlag())) {
            builder.append("CREATE_MFORM_PORT_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getSkipMinValidationForm())) {
            builder.append("SKIP_MIN_VALIDATION_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getSkipESNValidationFlag())) {
            builder.append("SKIP_ESN_VALIDATION_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getCreateIGAPNFlag())) {
            builder.append("CREATE_IG_APN_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getInsertILDTransFlag())) {
            builder.append("INSERT_ILD_TRANS_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getBogoConfigFlag())) {
            builder.append("X_BOGO_CONFIG_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getsUIActionType())) {
            builder.append("SUI_ACTION_TYPE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getUpdateMSIDFlag())) {
            builder.append("UPDATE_MSID_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getAddonCashCardFlag())) {
            builder.append("ADDON_CASH_CARD_FLAG = ?").append(AND);
        }
        return getSearchIgOrderTypeStatementElse2(builder, tracfoneOneIgOrderType);
    }

    String getSearchIgOrderTypeStatementElse2(StringBuilder builder, TracfoneOneIgOrderType tracfoneOneIgOrderType) {
        String searchQuery = "";
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getContactPinUpdateFlag())) {
            builder.append("CONTACT_PIN_UPDATE_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getBrmNotificationFlag())) {
            builder.append("BRM_NOTIFICATION_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getNewerTransFlag())) {
            builder.append("NEWER_TRANS_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getSkipMinUpdateFlag())) {
            builder.append("SKIP_MIN_UPDATE_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getSafeLinkBatchFlag())) {
            builder.append("SAFELINK_BATCH_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getCreateBucketsFlag())) {
            builder.append("CREATE_BUCKETS_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getProcessIgateIN3Flag())) {
            builder.append("PROCESS_IGATE_IN3_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getProcessIgateIN3LiteFlag())) {
            builder.append("PROCESS_IGATE_IN3_LITE_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getUpdateXCase2TaskFlag())) {
            builder.append("UPDATE_X_CASE2TASK_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getDepIGTransFlag())) {
            builder.append("DEP_IG_TRANS_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getGenerateAccountFlag())) {
            builder.append("GENERATE_ACCOUNT_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgOrderType.getCreateIGACMFlag())) {
            builder.append("CREATE_IG_ACM_FLAG = ?").append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        return searchQuery;
    }

    private String getSearchThrottlePolicyStatement(TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_THROTTLE_POLICY);
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottlePolicy.getObjId())) {
            builder.append(OBJID_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottlePolicy.getPolicyName())) {
            builder.append("X_POLICY_NAME = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottlePolicy.getPolicyDesc())) {
            builder.append("UPPER(X_POLICY_DESCRIPTION) LIKE ?").append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query for Throttle Policy is : " + searchQuery);
        return searchQuery;
    }

    private int setThrottlePolicyQueryParams(PreparedStatement stmt, TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottlePolicy.getObjId())) {
            stmt.setString(index++, tracfoneOneThrottlePolicy.getObjId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottlePolicy.getPolicyName())) {
            stmt.setString(index++, tracfoneOneThrottlePolicy.getPolicyName().toLowerCase());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottlePolicy.getPolicyDesc())) {
            stmt.setString(index++, "%" + tracfoneOneThrottlePolicy.getPolicyDesc().toUpperCase() + "%");
        }
        return index;
    }

    private String getSearchThrottleRuleStatement(TracfoneOneThrottleRule tracfoneOneThrottleRule) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_THROTTLE_RULE);
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleRule.getPolicyName())) {
            builder.append(", W3CI.TABLE_X_THROTTLING_POLICY tp where tp.OBJID = tr.x_policy_id and UPPER(tp.X_POLICY_NAME) LIKE ?")
                    .append(AND);
        } else {
            builder.append(" where ");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleRule.getParentId())) {
            builder.append("tr.X_PARENT_ID = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleRule.getPolicyId())) {
            builder.append("tr.X_POLICY_ID = ?").append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND)).concat(" order by tr.X_STATUS");
        }
        LOGGER.info("Search Query for Throttle Rule is : " + searchQuery);
        return searchQuery;
    }

    private int setThrottleRuleQueryParams(PreparedStatement stmt, TracfoneOneThrottleRule tracfoneOneThrottleRule) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleRule.getPolicyName())) {
            stmt.setString(index++, "%" + tracfoneOneThrottleRule.getPolicyName().toUpperCase() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleRule.getParentId())) {
            stmt.setString(index++, tracfoneOneThrottleRule.getParentId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleRule.getPolicyId())) {
            stmt.setString(index++, tracfoneOneThrottleRule.getPolicyId());
        }
        return index;
    }

    private String getSearchThrottleFeaturesStatement(TracfoneOneThrottleFeature tracfoneOneThrottleFeature) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_THROTTLE_FEATURES);
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleFeature.getRuleId())) {
            builder.append("X_RULE_ID = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleFeature.getFeatureFlagName())) {
            builder.append("X_FEATURE_FLAG_NAME = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleFeature.getFeatureName())) {
            builder.append("X_FEATURE_NAME = ?").append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query for Throttle Features is : " + searchQuery);
        return searchQuery;
    }

    private int setThrottleFeatureQueryParams(PreparedStatement stmt, TracfoneOneThrottleFeature tracfoneOneThrottleFeature) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleFeature.getRuleId())) {
            stmt.setString(index++, tracfoneOneThrottleFeature.getRuleId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleFeature.getFeatureFlagName())) {
            stmt.setString(index++, tracfoneOneThrottleFeature.getFeatureFlagName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleFeature.getFeatureName())) {
            stmt.setString(index++, tracfoneOneThrottleFeature.getFeatureName());
        }
        return index;
    }

    private void setThrottlePolicyStatement(PreparedStatement stmt, TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy) throws SQLException {
        stmt.setString(1, tracfoneOneThrottlePolicy.getPolicyName());
        stmt.setString(2, tracfoneOneThrottlePolicy.getPolicyDesc());
        stmt.setString(3, tracfoneOneThrottlePolicy.getBypassTransQueue());
        stmt.setString(4, tracfoneOneThrottlePolicy.getDataSuspendedFlag());
        stmt.setString(5, tracfoneOneThrottlePolicy.getObjId());
    }

    private void setThrottleRuleStatement(PreparedStatement stmt, TracfoneOneThrottleRule tracfoneOneThrottleRule) throws SQLException {
        stmt.setString(1, tracfoneOneThrottleRule.getParentId());
        stmt.setString(2, tracfoneOneThrottleRule.getPolicyId());
        stmt.setString(3, tracfoneOneThrottleRule.getRuleDesc());
        stmt.setString(4, tracfoneOneThrottleRule.getStatus());
        stmt.setString(5, tracfoneOneThrottleRule.getObjId());
    }

    private void setThrottleFeatureStatement(PreparedStatement stmt, TracfoneOneThrottleFeature tracfoneOneThrottleFeature) throws SQLException {
        stmt.setString(1, tracfoneOneThrottleFeature.getRuleId());
        stmt.setString(2, tracfoneOneThrottleFeature.getFeatureFlagName());
        stmt.setString(3, tracfoneOneThrottleFeature.getFeatureFlagValue());
        stmt.setString(4, tracfoneOneThrottleFeature.getFeatureName());
        stmt.setString(5, tracfoneOneThrottleFeature.getFeatureValue());
        stmt.setString(6, tracfoneOneThrottleFeature.getStatus());
        stmt.setString(7, tracfoneOneThrottleFeature.getObjId());
    }

    private String getSearchVerizonZipNPANXXStatement(TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_VERIZON_ZIP_NPANXX);
        if (!StringUtils.isNullOrEmpty(tracfoneOneVerizonZipNPANXX.getZip())) {
            builder.append(inClause("ZIP ", tracfoneOneVerizonZipNPANXX.getZip()))
                    .append("AND ");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneVerizonZipNPANXX.getnPANXX())) {
            builder.append("NPANXX = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneVerizonZipNPANXX.getnPA())) {
            builder.append("NPA = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneVerizonZipNPANXX.getnXX())) {
            builder.append(NXX_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneVerizonZipNPANXX.getAccountNum())) {
            builder.append("ACCOUNT_NUM = ?").append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query for Verizon ZIP NPANXX is : " + searchQuery);
        return searchQuery;
    }

    private int setVerizonZipNPANXXQueryParams(PreparedStatement stmt, TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneVerizonZipNPANXX.getZip())) {
            for (String fieldValue : tracfoneOneVerizonZipNPANXX.getZip().split(",")) {
                stmt.setString(index++, fieldValue);
            }
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneVerizonZipNPANXX.getnPANXX())) {
            stmt.setString(index++, tracfoneOneVerizonZipNPANXX.getnPANXX());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneVerizonZipNPANXX.getnPA())) {
            stmt.setString(index++, tracfoneOneVerizonZipNPANXX.getnPA());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneVerizonZipNPANXX.getnXX())) {
            stmt.setString(index++, tracfoneOneVerizonZipNPANXX.getnXX());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneVerizonZipNPANXX.getAccountNum())) {
            stmt.setString(index++, tracfoneOneVerizonZipNPANXX.getAccountNum());
        }
        return index;
    }

    private void setVerizonZipNPANXX(PreparedStatement stmt, TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX) throws SQLException {
        stmt.setString(1, tracfoneOneVerizonZipNPANXX.getZip());
        stmt.setString(2, tracfoneOneVerizonZipNPANXX.getnPA());
        stmt.setString(3, tracfoneOneVerizonZipNPANXX.getnXX());
        stmt.setString(4, tracfoneOneVerizonZipNPANXX.getnPANXX());
        stmt.setString(5, tracfoneOneVerizonZipNPANXX.getAccountNum());
        stmt.setString(6, tracfoneOneVerizonZipNPANXX.getTemplate());
        stmt.setString(7, tracfoneOneVerizonZipNPANXX.getOldZip());
        stmt.setString(8, tracfoneOneVerizonZipNPANXX.getOldNPANXX());
        stmt.setString(9, tracfoneOneVerizonZipNPANXX.getOldAccountNum());
    }


    private void setVerizonZipNPANXXStatement(PreparedStatement stmt, TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX) throws SQLException {
        stmt.setString(1, tracfoneOneVerizonZipNPANXX.getZip());
        stmt.setString(2, tracfoneOneVerizonZipNPANXX.getnPANXX());
        stmt.setString(3, tracfoneOneVerizonZipNPANXX.getAccountNum());
    }

    private String inClause(String fieldName, String fieldValues) {
        StringBuilder builder = new StringBuilder(fieldName);
        builder.append(" IN (");
        int total = fieldValues.split(",").length;
        int count = 1;
        while (count <= total) {
            builder.append("?,");
            count++;
        }
        builder.deleteCharAt(builder.length() - 1);
        builder.append(") ");
        return builder.toString();
    }

    private void setVerizonZipQueryParams(PreparedStatement stmt, TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneVerizonZipNPANXX.getZip());
        stmt.setString(index++, tracfoneOneVerizonZipNPANXX.getnPA());
        stmt.setString(index++, tracfoneOneVerizonZipNPANXX.getnXX());
        stmt.setString(index++, tracfoneOneVerizonZipNPANXX.getnPANXX());
        stmt.setString(index++, tracfoneOneVerizonZipNPANXX.getAccountNum());
        stmt.setString(index, tracfoneOneVerizonZipNPANXX.getTemplate());
    }

    private String getSearchTmoZipNgpStatement(TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_TMO_ZIP_NGP);
        if (!StringUtils.isNullOrEmpty(tracfoneOneTmoZipNgp.getZip())) {
            builder.append(inClause("X_ZIP ", tracfoneOneTmoZipNgp.getZip()))
                    .append("AND ");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneTmoZipNgp.getNgp())) {
            builder.append("X_NGP = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneTmoZipNgp.getNgpName())) {
            builder.append("X_NGP_NAME = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneTmoZipNgp.getPriority())) {
            builder.append("X_PRIORITY = ?").append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query for Verizon ZIP NPANXX is : " + searchQuery);
        return searchQuery;
    }

    private int setTmoZipNgpQueryParams(PreparedStatement stmt, TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneTmoZipNgp.getZip())) {
            for (String fieldValue : tracfoneOneTmoZipNgp.getZip().split(",")) {
                stmt.setString(index++, fieldValue);
            }
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneTmoZipNgp.getNgp())) {
            stmt.setString(index++, tracfoneOneTmoZipNgp.getNgp());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneTmoZipNgp.getNgpName())) {
            stmt.setString(index++, tracfoneOneTmoZipNgp.getNgpName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneTmoZipNgp.getPriority())) {
            stmt.setString(index++, tracfoneOneTmoZipNgp.getPriority());
        }
        return index;
    }

    private void setTmoZipNgpParams(PreparedStatement stmt, TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneTmoZipNgp.getZip());
        stmt.setString(index++, tracfoneOneTmoZipNgp.getNgp());
        stmt.setString(index++, tracfoneOneTmoZipNgp.getNgpName());
        stmt.setString(index, tracfoneOneTmoZipNgp.getPriority());
    }

    private void setTmoZipNgpUpdateParams(PreparedStatement stmt, TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp) throws SQLException {
        stmt.setString(1, tracfoneOneTmoZipNgp.getZip());
        stmt.setString(2, tracfoneOneTmoZipNgp.getNgp());
        stmt.setString(3, tracfoneOneTmoZipNgp.getNgpName());
        stmt.setString(4, tracfoneOneTmoZipNgp.getPriority());
        stmt.setString(5, tracfoneOneTmoZipNgp.getOldZip());
        stmt.setString(6, tracfoneOneTmoZipNgp.getOldPriority());
    }

    private void setTmoZipNgpDeleteParams(PreparedStatement stmt, TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp) throws SQLException {
        stmt.setString(1, tracfoneOneTmoZipNgp.getZip());
        stmt.setString(2, tracfoneOneTmoZipNgp.getPriority());
    }

    private String getSearchCingularMrktInfoStatement(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_CINGULAR_MRKT_INFO);
        if (!StringUtils.isNullOrEmpty(tracfoneOneCingularMrktInfo.getZip())) {
            builder.append(inClause("ZIP ", tracfoneOneCingularMrktInfo.getZip()))
                    .append("AND ");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCingularMrktInfo.getRcNumber())) {
            builder.append("RC_NUMBER = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCingularMrktInfo.getRcName())) {
            builder.append("RC_NAME = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCingularMrktInfo.getSubMarketId())) {
            builder.append("SUBMARKETID = ?").append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query for Cingular Mrkt Info is : " + searchQuery);
        return searchQuery;
    }

    private int setCingularMrktInfoQueryParams(PreparedStatement stmt, TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneCingularMrktInfo.getZip())) {
            for (String fieldValue : tracfoneOneCingularMrktInfo.getZip().split(",")) {
                stmt.setString(index++, fieldValue);
            }
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCingularMrktInfo.getRcNumber())) {
            stmt.setString(index++, tracfoneOneCingularMrktInfo.getRcNumber());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCingularMrktInfo.getRcName())) {
            stmt.setString(index++, tracfoneOneCingularMrktInfo.getRcName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCingularMrktInfo.getSubMarketId())) {
            stmt.setString(index++, tracfoneOneCingularMrktInfo.getSubMarketId());
        }
        return index;
    }

    private void setCingularmrktinfoParams(PreparedStatement stmt, TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getMkt());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getNpa());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getNxx());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getNpanxx());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getRcNumber());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getRcName());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getRcState());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getZip());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getMktType());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getAccountNum());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getMarketCode());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getDealerCode());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getSubMarketId());
        stmt.setString(index, tracfoneOneCingularMrktInfo.getTemplate());
    }

    private void setCingularMrktInfoUpdateParams(PreparedStatement stmt, TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo) throws SQLException {
        stmt.setString(1, tracfoneOneCingularMrktInfo.getMkt());
        stmt.setString(2, tracfoneOneCingularMrktInfo.getRcNumber());
        stmt.setString(3, tracfoneOneCingularMrktInfo.getRcName());
        stmt.setString(4, tracfoneOneCingularMrktInfo.getRcState());
        stmt.setString(5, tracfoneOneCingularMrktInfo.getZip());
        stmt.setString(6, tracfoneOneCingularMrktInfo.getMktType());
        stmt.setString(7, tracfoneOneCingularMrktInfo.getAccountNum());
        stmt.setString(8, tracfoneOneCingularMrktInfo.getMarketCode());
        stmt.setString(9, tracfoneOneCingularMrktInfo.getDealerCode());
        stmt.setString(10, tracfoneOneCingularMrktInfo.getSubMarketId());
        stmt.setString(11, tracfoneOneCingularMrktInfo.getTemplate());
        stmt.setString(12, tracfoneOneCingularMrktInfo.getOldZip());
    }

    private String getSearchNotcertifyModelStatement(TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_NOT_CERTIFY_MODEL);
        if (!StringUtils.isNullOrEmpty(tracfoneOneNotCertifyModel.getObjId())) {
            builder.append(OBJID_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNotCertifyModel.getDev())) {
            builder.append("DEV = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNotCertifyModel.getParentId())) {
            builder.append(PARENT_ID_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNotCertifyModel.getPartClassObjId())) {
            builder.append(X_PART_CLASS_OBJID_VALUE).append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query for Not Certify Model is : " + searchQuery);
        return searchQuery;
    }

    private int setNotcertifyModelQueryParams(PreparedStatement stmt, TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneNotCertifyModel.getObjId())) {
            stmt.setString(index++, tracfoneOneNotCertifyModel.getObjId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNotCertifyModel.getDev())) {
            stmt.setString(index++, tracfoneOneNotCertifyModel.getDev());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNotCertifyModel.getParentId())) {
            stmt.setString(index++, tracfoneOneNotCertifyModel.getParentId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNotCertifyModel.getPartClassObjId())) {
            stmt.setString(index++, tracfoneOneNotCertifyModel.getPartClassObjId());
        }
        return index;
    }

    private void setNotCertifyModelParams(PreparedStatement stmt, TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneNotCertifyModel.getObjId());
        stmt.setString(index++, tracfoneOneNotCertifyModel.getDev());
        stmt.setString(index++, tracfoneOneNotCertifyModel.getParentId());
        stmt.setString(index, tracfoneOneNotCertifyModel.getPartClassObjId());
    }

    private void setNotCertifyModelUpdateParams(PreparedStatement stmt, TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel) throws SQLException {
        stmt.setString(1, tracfoneOneNotCertifyModel.getDev());
        stmt.setString(2, tracfoneOneNotCertifyModel.getParentId());
        stmt.setString(3, tracfoneOneNotCertifyModel.getPartClassObjId());
        stmt.setString(4, tracfoneOneNotCertifyModel.getObjId());
    }

    @Override
    public TFOneGeneralResponse bulkUpdateTmoZipNgp(List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNgp, int userId) throws TracfoneOneException {
        String uniqueId = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneTmoZipNgp.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_TMO_ZIP_NGP);) {
            tracfoneOneTmoZipNgp.forEach(tmoZipNgp -> {
                try {
                    setTmoZipNgpUpdateParams(stmt, tmoZipNgp);
                    stmt.addBatch();
                } catch (SQLException ex) {
                    LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, ex);
                }
            });
            stmt.executeBatch();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update TMO ZIP NGP", "Updated TMO ZIP NGP" + tracfoneOneTmoZipNgp, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, uniqueId);
    }

    @Override
    public List<TFOneCarriersimpref> searchCarrierSimPref(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref) throws TracfoneOneException {
        List<TFOneCarriersimpref> tfOneCarriersimprefs = new ArrayList<>(1);
        TFOneCarriersimpref tfOneCarriersimpref;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarriersimpref.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchCarriersimpref(tracfoneOneCarriersimpref));) {
            setCarriersimprefQueryParams(stmt, tracfoneOneCarriersimpref);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneCarriersimpref = new TFOneCarriersimpref();
                    tfOneCarriersimpref.setCarrierName(resultSet.getString("CARRIER_NAME"));
                    tfOneCarriersimpref.setRank(resultSet.getString("RANK"));
                    tfOneCarriersimpref.setSimProfile(resultSet.getString("SIM_PROFILE"));
                    tfOneCarriersimpref.setMinDllExch(resultSet.getString("MIN_DLL_EXCH"));
                    tfOneCarriersimpref.setMaxDllExch(resultSet.getString("MAX_DLL_EXCH"));
                    tfOneCarriersimprefs.add(tfOneCarriersimpref);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneCarriersimprefs;
    }

    @Override
    public TFOneGeneralResponse insertCarrierSimPref(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref, int userId, String uniqueId) throws TracfoneOneException {
        String unique = "";
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarriersimpref.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_CARRIERSIMPREF);) {
            TracfoneOneCarrierSimPref searchCarriersimpref = new TracfoneOneCarrierSimPref();
            searchCarriersimpref.setDbEnv(tracfoneOneCarriersimpref.getDbEnv());
            searchCarriersimpref.setCarrierName(tracfoneOneCarriersimpref.getCarrierName());
            searchCarriersimpref.setSimProfile(tracfoneOneCarriersimpref.getSimProfile());
            searchCarriersimpref.setMinDllExch(tracfoneOneCarriersimpref.getMinDllExch());
            searchCarriersimpref.setMaxDllExch(tracfoneOneCarriersimpref.getMaxDllExch());
            List<TFOneCarriersimpref> tfOneCarriersimpref = searchCarrierSimPref(searchCarriersimpref);
            if (tfOneCarriersimpref.isEmpty()) {
                unique = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
                setCarriersimprefParams(stmt, tracfoneOneCarriersimpref);
                stmt.executeUpdate();
            } else if (!tfOneCarriersimpref.get(0).getRank().equals(tracfoneOneCarriersimpref.getRank())) {
                updateRank(tracfoneOneCarriersimpref, userId);
                unique = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit;
            // Added this logic to track bulk insert of Carrier sim pref
            if (StringUtils.isNullOrEmpty(uniqueId)) {
                audit = new TracfoneAudit(userId, "Insert Carrier sim pref",
                        "Inserted Carrier sim pref Object " + tracfoneOneCarriersimpref, null);
            }
            if (!StringUtils.isNullOrEmpty(unique)) {
                audit = new TracfoneAudit(userId, "Bulk Carrier sim pref Insert",
                        "Inserted Carrier sim pref " + tracfoneOneCarriersimpref, CARRIERID + uniqueId);
            } else {
                audit = new TracfoneAudit(userId, BULK_CARRIERSIMPREF_INSERT,
                        "Duplicate record found - " + tracfoneOneCarriersimpref, ERROR + uniqueId);
            }
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, unique);
    }

    private void updateRank(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarriersimpref.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CARRIERSIMPREF_RANK);) {
            LOGGER.info("Carrier Sim Pref sent for update is " + tracfoneOneCarriersimpref);
            LOGGER.info(TRACFONE_UPDATE_CARRIERSIMPREF_RANK);
            updateCarriersimprefRankParams(stmt, tracfoneOneCarriersimpref);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);

            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Rank for carrier sim pref", "Updated Rank for carrier sim pref" + tracfoneOneCarriersimpref, null);
            tracfoneAuditEvent.fire(audit);
        }
    }

    private void updateCarriersimprefRankParams(PreparedStatement stmt, TracfoneOneCarrierSimPref tracfoneOneCarriersimpref) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneCarriersimpref.getRank());
        stmt.setString(index++, tracfoneOneCarriersimpref.getCarrierName());
        stmt.setString(index++, tracfoneOneCarriersimpref.getSimProfile());
        stmt.setString(index++, tracfoneOneCarriersimpref.getMinDllExch());
        stmt.setString(index, tracfoneOneCarriersimpref.getMaxDllExch());
    }

    @Override
    public TFOneGeneralResponse updateCarrierSimPref(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarriersimpref.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CARRIERSIMPREF);) {
            LOGGER.info("Carrier Sim Pref sent for update is " + tracfoneOneCarriersimpref);
            LOGGER.info(TRACFONE_UPDATE_CARRIERSIMPREF);
            updateCarriersimprefParams(stmt, tracfoneOneCarriersimpref);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);

            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update carrier sim pref", "Updated carrier sim pref" + tracfoneOneCarriersimpref, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneCarriersimpref.getSimProfile());
    }

    @Override
    public TFOneGeneralResponse deleteCarrierSimPref(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarriersimpref.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_CARRIERSIMPREF);) {
            LOGGER.info(TRACFONE_DELETE_CARRIERSIMPREF);
            setCarriersimprefParams(stmt, tracfoneOneCarriersimpref);
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Carrier Sim Pref", "Deleted Carrier Sim Pref " + tracfoneOneCarriersimpref, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneCarriersimpref.getSimProfile());
    }

    @Override
    public TFOneGeneralResponse bulkUpdateCarrierSimPref(List<TracfoneOneCarrierSimPref> tracfoneOneCarrierSimPrefs, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierSimPrefs.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CARRIERSIMPREF);) {
            for (TracfoneOneCarrierSimPref carrierSimPref : tracfoneOneCarrierSimPrefs) {
                if (searchCarrierSimPref(carrierSimPref).isEmpty()) {
                    updateCarriersimprefParams(stmt, carrierSimPref);
                    stmt.executeUpdate();
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Bulk Update Carrier sim pref", "Bulk Updated Carrier sim pref" + tracfoneOneCarrierSimPrefs, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneCarrierSimPrefs.get(0).getSimProfile());
    }

    private String getSearchCarriersimpref(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_CARRIERSIMPREF);
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarriersimpref.getCarrierName())) {
            builder.append(CARRIER_NAME_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarriersimpref.getRank())) {
            builder.append("RANK = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarriersimpref.getSimProfile())) {
            builder.append("SIM_PROFILE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarriersimpref.getMinDllExch())) {
            builder.append("MIN_DLL_EXCH = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarriersimpref.getMaxDllExch())) {
            builder.append("MAX_DLL_EXCH = ?").append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query Carriersimpref is : " + searchQuery);
        return searchQuery;
    }

    private void setCarriersimprefQueryParams(PreparedStatement stmt, TracfoneOneCarrierSimPref tracfoneOneCarriersimpref) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarriersimpref.getCarrierName())) {
            stmt.setString(index++, tracfoneOneCarriersimpref.getCarrierName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarriersimpref.getRank())) {
            stmt.setString(index++, tracfoneOneCarriersimpref.getRank());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarriersimpref.getSimProfile())) {
            stmt.setString(index++, tracfoneOneCarriersimpref.getSimProfile());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarriersimpref.getMinDllExch())) {
            stmt.setString(index++, tracfoneOneCarriersimpref.getMinDllExch());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarriersimpref.getMaxDllExch())) {
            stmt.setString(index, tracfoneOneCarriersimpref.getMaxDllExch());
        }
    }

    private void setCarriersimprefParams(PreparedStatement stmt, TracfoneOneCarrierSimPref tracfoneOneCarriersimpref) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneCarriersimpref.getCarrierName());
        stmt.setString(index++, tracfoneOneCarriersimpref.getRank());
        stmt.setString(index++, tracfoneOneCarriersimpref.getSimProfile());
        stmt.setString(index++, tracfoneOneCarriersimpref.getMinDllExch());
        stmt.setString(index, tracfoneOneCarriersimpref.getMaxDllExch());
    }

    private void updateCarriersimprefParams(PreparedStatement stmt, TracfoneOneCarrierSimPref tracfoneOneCarriersimpref) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneCarriersimpref.getCarrierName());
        stmt.setString(index++, tracfoneOneCarriersimpref.getRank());
        stmt.setString(index++, tracfoneOneCarriersimpref.getSimProfile());
        stmt.setString(index++, tracfoneOneCarriersimpref.getMinDllExch());
        stmt.setString(index++, tracfoneOneCarriersimpref.getMaxDllExch());
        stmt.setString(index++, tracfoneOneCarriersimpref.getOldCarrierName());
        stmt.setString(index++, tracfoneOneCarriersimpref.getOldSimProfile());
        stmt.setString(index++, tracfoneOneCarriersimpref.getOldMinDllExch());
        stmt.setString(index, tracfoneOneCarriersimpref.getOldMaxDllExch());
    }

    @Override
    public TFOneGeneralResponse insertNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones, int userId, String uniqueId) throws TracfoneOneException {
        Gson gson = new Gson();
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNpanxx2Carrierzones.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_NPANXX_2_CARRIERZONES);) {
            setInsertNpanxx2Carrierzones(stmt, tracfoneOneNpanxx2Carrierzones);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Npanxx2Carrierzones", gson.toJson(tracfoneOneNpanxx2Carrierzones), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "NPANXX2CarrierZones has been inserted successfully");
    }

    @Override
    public TFOneGeneralResponse bulkinsertNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones, int userId, String uniqueId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNpanxx2Carrierzones.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_NPANXX_2_CARRIERZONES);) {
            TracfoneOneNpanxx2Carrierzones searchNpanxx = new TracfoneOneNpanxx2Carrierzones();
            searchNpanxx.setDbEnv(tracfoneOneNpanxx2Carrierzones.getDbEnv());
            searchNpanxx.setNpa(tracfoneOneNpanxx2Carrierzones.getNpa());
            searchNpanxx.setNxx(tracfoneOneNpanxx2Carrierzones.getNxx());
            searchNpanxx.setCarrierId(tracfoneOneNpanxx2Carrierzones.getCarrierId());
            searchNpanxx.setState(tracfoneOneNpanxx2Carrierzones.getState());
            searchNpanxx.setSid(tracfoneOneNpanxx2Carrierzones.getSid());
            searchNpanxx.setZone(tracfoneOneNpanxx2Carrierzones.getZone());
            searchNpanxx.setRateCenter(tracfoneOneNpanxx2Carrierzones.getRateCenter());
            if (!searchNpanxx2Carrierzones(searchNpanxx).getNpanxx2Carrierzones().isEmpty()) {
                replaceNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, userId);
            }
            else{
                setInsertNpanxx2Carrierzones(stmt, tracfoneOneNpanxx2Carrierzones);
                stmt.executeUpdate();
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, BULK_NPANXX2CARRIERZONES_INSERT, "Inserted Npa nxx 2Carrierzones " + tracfoneOneNpanxx2Carrierzones, CARRIERID + uniqueId);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Inserted");
    }

    private void setInsertNpanxx2Carrierzones(PreparedStatement stmt, TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getNpa());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getNxx());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCarrierId());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCarrierName());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getLeadTime());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getTargetLevel());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getRateCenter());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getState());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCarrierIdDescription());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getZone());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCounty());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getMarketId());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getMrktArea());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getSid());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getTechnology());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getFrequency1());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getFrequency2());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getBtaMktNumber());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getBtaMktName());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getGsmTech());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCdmaTech());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getTdmaTech());
        stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getMnc());
    }

    @Override
    public TFOneNpaNxx2CarrierZonesSearchResult searchNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) throws TracfoneOneException {
        TFOneNpaNxx2CarrierZonesSearchResult npaNxx2CarrierZonesSearchResult = new TFOneNpaNxx2CarrierZonesSearchResult();
        TFOneNpanxx2Carrierzones tfOneNpanxx2Carrierzone;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNpanxx2Carrierzones.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getNpanxx2CarrierzonesStatement(NPANXX_2_CARRIERZONES_START, tracfoneOneNpanxx2Carrierzones));
             PreparedStatement stmtCount = con.prepareStatement(getSearchNpanxx2Carrierzones(GET_NPANXX_2_CARRIERZONES_COUNT, tracfoneOneNpanxx2Carrierzones))) {
            setSearchNpanxx2Carrierzones(stmt, stmtCount, tracfoneOneNpanxx2Carrierzones);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneNpanxx2Carrierzone = new TFOneNpanxx2Carrierzones();
                    tfOneNpanxx2Carrierzone.setNpa(resultSet.getString("NPA"));
                    tfOneNpanxx2Carrierzone.setNxx(resultSet.getString("NXX"));
                    tfOneNpanxx2Carrierzone.setCarrierId(resultSet.getString(CARRIER_ID));
                    tfOneNpanxx2Carrierzone.setZone(resultSet.getString("ZONE"));
                    tfOneNpanxx2Carrierzone.setState(resultSet.getString("STATE"));
                    tfOneNpanxx2Carrierzone.setSid(resultSet.getString("SID"));
                    tfOneNpanxx2Carrierzone.setRateCenter(resultSet.getString("RATECENTER"));
                    tfOneNpanxx2Carrierzone.setCarrierName(resultSet.getString("CARRIER_NAME"));
                    tfOneNpanxx2Carrierzone.setLeadTime(resultSet.getString("LEAD_TIME"));
                    tfOneNpanxx2Carrierzone.setTargetLevel(resultSet.getString("TARGET_LEVEL"));
                    tfOneNpanxx2Carrierzone.setCarrierIdDescription(resultSet.getString("CARRIER_ID_DESCRIPTION"));
                    tfOneNpanxx2Carrierzone.setCounty(resultSet.getString(COUNTY));
                    tfOneNpanxx2Carrierzone.setMarketId(resultSet.getString("MARKETID"));
                    tfOneNpanxx2Carrierzone.setMrktArea(resultSet.getString("MRKT_AREA"));
                    tfOneNpanxx2Carrierzone.setTechnology(resultSet.getString("TECHNOLOGY"));
                    tfOneNpanxx2Carrierzone.setFrequency1(resultSet.getString("FREQUENCY1"));
                    tfOneNpanxx2Carrierzone.setFrequency2(resultSet.getString("FREQUENCY2"));
                    tfOneNpanxx2Carrierzone.setBtaMktNumber(resultSet.getString("BTA_MKT_NUMBER"));
                    tfOneNpanxx2Carrierzone.setBtaMktName(resultSet.getString("BTA_MKT_NAME"));
                    tfOneNpanxx2Carrierzone.setGsmTech(resultSet.getString("GSM_TECH"));
                    tfOneNpanxx2Carrierzone.setCdmaTech(resultSet.getString("CDMA_TECH"));
                    tfOneNpanxx2Carrierzone.setTdmaTech(resultSet.getString("TDMA_TECH"));
                    tfOneNpanxx2Carrierzone.setMnc(resultSet.getString("MNC"));
                    npaNxx2CarrierZonesSearchResult.getNpanxx2Carrierzones().add(tfOneNpanxx2Carrierzone);
                }
            }
            int count = 0;
            try (ResultSet resultSetCount = stmtCount.executeQuery()) {
                while (resultSetCount.next()) {
                    count = resultSetCount.getInt(1);
                }
            }
            LOGGER.info("Total Count " + count);
            TracfoneonePaginationSearch tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
            tracfoneonePaginationSearch.setStartIndex(tracfoneOneNpanxx2Carrierzones.getPaginationSearch().getStartIndex());
            tracfoneonePaginationSearch.setEndIndex(tracfoneOneNpanxx2Carrierzones.getPaginationSearch().getEndIndex());
            tracfoneonePaginationSearch.setTotal(count);
            npaNxx2CarrierZonesSearchResult.setPaginationSearch(tracfoneonePaginationSearch);
            LOGGER.info("Result " + tracfoneOneNpanxx2Carrierzones);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return npaNxx2CarrierZonesSearchResult;
    }

    private String getSearchNpanxx2Carrierzones(String query, TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(query);
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getNpa())) {
            builder.append(NPA).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getNxx())) {
            builder.append(NXX_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getCarrierId())) {
            builder.append(CARRIER_ID_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getState())) {
            builder.append(STATE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getSid())) {
            builder.append("SID = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getZone())) {
            builder.append(ZONE_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getRateCenter())) {
            builder.append("RATECENTER = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getCarrierName())) {
            builder.append(CARRIER_NAME_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getLeadTime())) {
            builder.append("LEAD_TIME = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getTargetLevel())) {
            builder.append("TARGET_LEVEL = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getCarrierIdDescription())) {
            builder.append("CARRIER_ID_DESCRIPTION = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getCounty())) {
            builder.append(COUNTY_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getMarketId())) {
            builder.append("MARKETID = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getMrktArea())) {
            builder.append("MRKT_AREA = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getTechnology())) {
            builder.append("TECHNOLOGY = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getFrequency1())) {
            builder.append("FREQUENCY1 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getFrequency2())) {
            builder.append("FREQUENCY2 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getBtaMktNumber())) {
            builder.append("BTA_MKT_NUMBER = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getBtaMktName())) {
            builder.append(BTA_MKT_NAME_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getGsmTech())) {
            builder.append("GSM_TECH = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getCdmaTech())) {
            builder.append("CDMA_TECH = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getTdmaTech())) {
            builder.append("TDMA_TECH = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getMnc())) {
            builder.append("MNC = ?").append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        return searchQuery;
    }

    private void setSearchNpanxx2Carrierzones(PreparedStatement stmt, PreparedStatement stmtCount, TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getNpa())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getNpa());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getNpa());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getNxx())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getNxx());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getNxx());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getCarrierId())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getCarrierId());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getCarrierId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getState())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getState());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getState());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getSid())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getSid());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getSid());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getZone())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getZone());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getZone());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getRateCenter())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getRateCenter());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getRateCenter());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getCarrierName())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getCarrierName());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getCarrierName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getLeadTime())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getLeadTime());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getLeadTime());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getTargetLevel())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getTargetLevel());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getTargetLevel());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getCarrierIdDescription())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getCarrierIdDescription());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getCarrierIdDescription());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getCounty())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getCounty());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getCounty());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getMarketId())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getMarketId());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getMarketId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getMrktArea())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getMrktArea());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getMrktArea());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getTechnology())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getTechnology());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getTechnology());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getFrequency1())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getFrequency1());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getFrequency1());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getFrequency2())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getFrequency2());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getFrequency2());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getBtaMktNumber())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getBtaMktNumber());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getBtaMktNumber());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getBtaMktName())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getBtaMktName());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getBtaMktName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getGsmTech())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getGsmTech());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getGsmTech());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getCdmaTech())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getCdmaTech());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getCdmaTech());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getTdmaTech())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getTdmaTech());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getTdmaTech());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getMnc())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getMnc());
            stmtCount.setString(index++, tracfoneOneNpanxx2Carrierzones.getMnc());
        }
    }

    @Override
    public TFOneGeneralResponse deleteNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNpanxx2Carrierzones.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_NPANXX_2_CARRIERZONES);) {
            setDeleteNpanxx2Carrierzones(stmt, tracfoneOneNpanxx2Carrierzones);
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete npanxx2carrierzones", "Deleted npanxx2carrierzones " + tracfoneOneNpanxx2Carrierzones, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneNpanxx2Carrierzones.getCarrierId());
    }

    private void setDeleteNpanxx2Carrierzones(PreparedStatement stmt, TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getNpa());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getNxx());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCarrierId());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getState());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getSid());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getZone());
        stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getRateCenter());
    }

    @Override
    public TFOneGeneralResponse updateNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNpanxx2Carrierzones.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(updateNpanxx2CarrierzonesStatement(tracfoneOneNpanxx2Carrierzones));) {
            updateNpanxx2CarrierzonesParams(stmt, tracfoneOneNpanxx2Carrierzones);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Npanxx2Carrierzones", "Updated Npanxx2Carrierzones" + tracfoneOneNpanxx2Carrierzones, null);
            tracfoneAuditEvent.fire(audit);
        }
        LOGGER.info("Update querry" + TRACFONE_UPDATE_NPANXX_2_CARRIERZONES);
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, UPDATED);
    }

    @Override
    public TFOneGeneralResponse bulkUpdateNpanxx2Carrierzones(List<TracfoneOneNpanxx2Carrierzones> tracfoneOneNpanxx2Carrierzones, int userId) throws TracfoneOneException {
        String uniqueId = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNpanxx2Carrierzones.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_NPANXX_2_CARRIERZONES);) {
            for (TracfoneOneNpanxx2Carrierzones npanxx2Carrierzones : tracfoneOneNpanxx2Carrierzones) {
                TracfoneOneNpanxx2Carrierzones npanxx2Carrierzone = new TracfoneOneNpanxx2Carrierzones();
                if (!npanxx2Carrierzones.isCheckDuplicate()) {
                    if (searchNpanxx2Carrierzones(npanxx2Carrierzones).getNpanxx2Carrierzones().isEmpty()) {
                        updateNpanxx2CarrierzonesParams(stmt, npanxx2Carrierzones);
                        stmt.executeUpdate();
                    }
                } else {
                    npanxx2Carrierzone.setDbEnv(npanxx2Carrierzones.getDbEnv());
                    npanxx2Carrierzone.setNpa(npanxx2Carrierzones.getNpa());
                    npanxx2Carrierzone.setNxx(npanxx2Carrierzones.getNxx());
                    npanxx2Carrierzone.setCarrierId(npanxx2Carrierzones.getCarrierId());
                    npanxx2Carrierzone.setZone(npanxx2Carrierzones.getZone());
                    npanxx2Carrierzone.setState(npanxx2Carrierzones.getState());
                    npanxx2Carrierzone.setSid(npanxx2Carrierzones.getSid());
                    npanxx2Carrierzone.setRateCenter(npanxx2Carrierzones.getRateCenter());
                    if (searchNpanxx2Carrierzones(npanxx2Carrierzone).getNpanxx2Carrierzones().isEmpty()) {
                        updateNpanxx2CarrierzonesParams(stmt, npanxx2Carrierzones);
                        stmt.executeUpdate();
                    }
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Bulk Update Npanxx2 Carrier zones", "Bulk Update Npanxx 2 Carrier zones" + tracfoneOneNpanxx2Carrierzones, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, uniqueId);
    }

    private void updateNpanxx2CarrierzonesParams(PreparedStatement stmt, TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCarrierName());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getNxx());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getNpa());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getZone());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getSid());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getState());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getRateCenter());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCarrierId());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getBtaMktName());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getBtaMktNumber());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCarrierIdDescription());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCdmaTech());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCounty());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getGsmTech());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getMnc());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getTdmaTech());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getMrktArea());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getTechnology());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getFrequency1());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getFrequency2());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getLeadTime());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getMarketId());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getTargetLevel());
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getOldNpa())) {
            stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getOldNpa());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getOldNxx())) {
            stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getOldNxx());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getOldCarrierId())) {
            stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getOldCarrierId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getOldZone())) {
            stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getOldZone());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getOldSid())) {
            stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getOldSid());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getOldState())) {
            stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getOldState());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getOldRateCenter())) {
            stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getOldRateCenter());
        }
    }

    @Override
    public List<TFOneArUsaPostalZips> getArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips) throws TracfoneOneException {
        List<TFOneArUsaPostalZips> tfOneArUsaPostalZips = new ArrayList<>();
        try {
            Query sql = cRtlArUsaPostalZipsFacadeLocal.getEntityManager().createNativeQuery(getSearchArUsaPostalZips(tracfoneOneArUsaPostalZips));
            setSearchArUsaPostalZips(sql, tracfoneOneArUsaPostalZips);
            List<Object[]> ctrlArUsaPostalZips = sql.getResultList();

            for (Object[] ctrlArUsaPostalZip : ctrlArUsaPostalZips) {
                tfOneArUsaPostalZips.add(getArUsaPostalZips(ctrlArUsaPostalZip));
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneArUsaPostalZips;
    }

    @Override
    public TFOneGeneralResponse insertArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            Query sql = cRtlArUsaPostalZipsFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_INSERT_AR_USA_POSTAL_ZIPS);
            setInsertArUsaPostalZips(sql, tracfoneOneArUsaPostalZips);
            LOGGER.info("Action " + tracfoneOneArUsaPostalZips);
            sql.executeUpdate();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert AR USA Postal Zips", gson.toJson(tracfoneOneArUsaPostalZips), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "AR USA Postal Zips Inserted");
    }

    @Override
    public TFOneGeneralResponse deleteArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            cRtlArUsaPostalZipsFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_DELETE_AR_USA_POSTAL_ZIPS).
                    setParameter(1, tracfoneOneArUsaPostalZips.getPostalCode()).executeUpdate();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Ar Usa Postal Zips", gson.toJson(tracfoneOneArUsaPostalZips), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Ar Usa Postal Zips details deleted");
    }

    @Override
    public TFOneGeneralResponse updateArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            Query sql = cRtlArUsaPostalZipsFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_UPDATE_AR_USA_POSTAL_ZIPS);
            setUpdateArUsaPostalZips(sql, tracfoneOneArUsaPostalZips);
            sql.executeUpdate();
        } catch (Exception e) {
            LOGGER.error(e);
            LOGGER.info("error" + e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Ar Usa Postal Zips", gson.toJson(tracfoneOneArUsaPostalZips), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Ar Usa Postal Zips Record Updated");
    }

    @Override
    public TFOneGeneralResponse bulkUpdateArUsaPostalZips(List<TracfoneOneArUsaPostalZips> tracfoneOneArUsaPostalZips, int userId) throws TracfoneOneException {
        String uniqueId = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        try {
            Query sql = cRtlArUsaPostalZipsFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_UPDATE_AR_USA_POSTAL_ZIPS);
            for (TracfoneOneArUsaPostalZips searchArUsaPostalZips : tracfoneOneArUsaPostalZips) {
                if (!searchArUsaPostalZips.isCheckDuplicate()) {
                    if (getArUsaPostalZips(searchArUsaPostalZips).isEmpty()) {
                        setUpdateArUsaPostalZips(sql, searchArUsaPostalZips);
                        sql.executeUpdate();
                    }
                } else {
                    TracfoneOneArUsaPostalZips searchArUsaPostalZip = new TracfoneOneArUsaPostalZips();
                    searchArUsaPostalZip.setPostalCode(searchArUsaPostalZips.getPostalCode());
                    if (getArUsaPostalZips(searchArUsaPostalZip).isEmpty()) {
                        setUpdateArUsaPostalZips(sql, searchArUsaPostalZips);
                        sql.executeUpdate();
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error(e);
            LOGGER.info("error" + e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Bulk Update Ar Usa Postal Zips", "Bulk Update Ar Usa Postal Zips" + tracfoneOneArUsaPostalZips, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, uniqueId);
    }

    private String getSearchArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_AR_USA_POSTAL_ZIPS);
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaPostalZips.getPostalCode())) {
            builder.append("POSTAL_CODE = ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaPostalZips.getKeyCode())) {
            builder.append("KEY_CODE = ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaPostalZips.getState())) {
            builder.append("STATE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaPostalZips.getCity())) {
            builder.append("CITY = ?").append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query for AR_USA_POSTAL_ZIPS : " + searchQuery);
        return searchQuery;
    }

    private void setSearchArUsaPostalZips(Query sql, TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaPostalZips.getPostalCode())) {
            sql.setParameter(index++, tracfoneOneArUsaPostalZips.getPostalCode());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaPostalZips.getKeyCode())) {
            sql.setParameter(index++, tracfoneOneArUsaPostalZips.getKeyCode());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaPostalZips.getState())) {
            sql.setParameter(index++, tracfoneOneArUsaPostalZips.getState());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaPostalZips.getCity())) {
            sql.setParameter(index, tracfoneOneArUsaPostalZips.getCity());
        }
    }

    private TFOneArUsaPostalZips getArUsaPostalZips(Object[] ctrlArUsaPostalZip) {
        TFOneArUsaPostalZips arUsaPostalZip = new TFOneArUsaPostalZips();
        if (ctrlArUsaPostalZip[0] != null) {
            arUsaPostalZip.setPostalCode(String.valueOf(ctrlArUsaPostalZip[0]));
        }
        if (ctrlArUsaPostalZip[1] != null) {
            arUsaPostalZip.setKeyCode(String.valueOf(ctrlArUsaPostalZip[1]));
        }
        if (ctrlArUsaPostalZip[2] != null) {
            arUsaPostalZip.setState(String.valueOf(ctrlArUsaPostalZip[2]));
        }
        if (ctrlArUsaPostalZip[3] != null) {
            arUsaPostalZip.setCity(String.valueOf(ctrlArUsaPostalZip[3]));
        }
        return arUsaPostalZip;
    }

    private void setInsertArUsaPostalZips(Query sql, TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips) throws SQLException {
        int index = 1;
        sql.setParameter(index++, tracfoneOneArUsaPostalZips.getPostalCode());
        sql.setParameter(index++, tracfoneOneArUsaPostalZips.getKeyCode());
        sql.setParameter(index++, tracfoneOneArUsaPostalZips.getState());
        sql.setParameter(index, tracfoneOneArUsaPostalZips.getCity());

    }


    private void setUpdateArUsaPostalZips(Query sql, TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips) throws SQLException {
        int index = 1;
        sql.setParameter(index++, tracfoneOneArUsaPostalZips.getPostalCode());
        sql.setParameter(index++, tracfoneOneArUsaPostalZips.getKeyCode());
        sql.setParameter(index++, tracfoneOneArUsaPostalZips.getState());
        sql.setParameter(index++, tracfoneOneArUsaPostalZips.getCity());
        sql.setParameter(index, tracfoneOneArUsaPostalZips.getOldPostalCode());
    }

    private String getNpanxx2CarrierzonesStatement(String query, TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) {
        boolean pagination = false;
        int startIndex = 0;
        int endIndex = 0;
        if (tracfoneOneNpanxx2Carrierzones.getPaginationSearch() != null) {
            startIndex = tracfoneOneNpanxx2Carrierzones.getPaginationSearch().getStartIndex();
            endIndex = tracfoneOneNpanxx2Carrierzones.getPaginationSearch().getEndIndex();
            pagination = (endIndex - startIndex) <= TracfoneOneConstant.FETCH_SIZE;
        }
        StringBuilder sBuilder = new StringBuilder(getSearchNpanxx2Carrierzones(query + TRACFONE_SEARCH_NPANXX_2_CARRIERZONES, tracfoneOneNpanxx2Carrierzones));
        // Pagination check for large result queries.
        if (pagination) {
            // Adding 1 to each of these since a ROWNUM of 0 never exists and it is being sent this way from the UI
            startIndex++;
            endIndex++;
            sBuilder.append(") a "
                    + "where ROWNUM < "
                    + endIndex + ") "
                    + "where rnum  >= " + startIndex);
        } else {
            TracfoneonePaginationSearch defaultPagination = new TracfoneonePaginationSearch();
            defaultPagination.setStartIndex(1);
            defaultPagination.setEndIndex(1000);
            tracfoneOneNpanxx2Carrierzones.setPaginationSearch(defaultPagination);
            sBuilder.append(") a "
                    + " where ROWNUM < "
                    + "1000 ) "
                    + "where rnum  >= 0");
        }
        LOGGER.info("The search query is " + sBuilder.toString());
        return sBuilder.toString();
    }

    @Override
    public TFOneArUsaMarketSearchResult getArUsaMarketDetails(TracfoneOneArUsaMarket tracfoneOneArUsaMarket) throws TracfoneOneException {
        TFOneArUsaMarketSearchResult arUsaMarketSearchResult = new TFOneArUsaMarketSearchResult();
        TFOneArUsaMarket tfOneArUsaMarkets;
        try {
            Query sql = cRtlArUsaMarketFacadeLocal.getEntityManager().createNativeQuery(getSearchArUsaMarketStatement(AR_USA_MARKET_START, tracfoneOneArUsaMarket));
            Query sqlCount = cRtlArUsaMarketFacadeLocal.getEntityManager().createNativeQuery(getSearchArUsaMarketDetails(GET_AR_USA_MARKET_COUNT, tracfoneOneArUsaMarket));
            setSearchArUsaMarketDetails(sql, sqlCount, tracfoneOneArUsaMarket);

            List<Object[]> cRtlArUsaMarkets = sql.getResultList();
            for (Object[] cRtlArUsaMarket : cRtlArUsaMarkets) {
                arUsaMarketSearchResult.getArUsaMarkets().add(getArUsaMarketDetails(cRtlArUsaMarket));
            }

            List<Object> arUsaMarket = sqlCount.getResultList();
            String count = "0";
            count = arUsaMarket.get(0).toString();

            LOGGER.info("Total Count " + count);
            TracfoneonePaginationSearch tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
            tracfoneonePaginationSearch.setStartIndex(tracfoneOneArUsaMarket.getPaginationSearch().getStartIndex());
            tracfoneonePaginationSearch.setEndIndex(tracfoneOneArUsaMarket.getPaginationSearch().getEndIndex());
            tracfoneonePaginationSearch.setTotal(Integer.parseInt(String.valueOf(count)));
            arUsaMarketSearchResult.setPaginationSearch(tracfoneonePaginationSearch);
            LOGGER.info("Result " + tracfoneOneArUsaMarket);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return arUsaMarketSearchResult;
    }

    @Override
    public TFOneGeneralResponse replaceArUsaMarketDetails(TracfoneOneArUsaMarket tracfoneOneArUsaMarket, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            Query sql = cRtlArUsaMarketFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_REPLACE_AR_USA_MARKET);
            setReplaceArUsaMarketDetails(sql, tracfoneOneArUsaMarket);
            sql.executeUpdate();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Ar Usa Market details", gson.toJson(tracfoneOneArUsaMarket), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Ar Usa Market details Record Updated");
    }

    private void setReplaceArUsaMarketDetails(Query sql, TracfoneOneArUsaMarket tracfoneOneArUsaMarket) throws SQLException {
        int index = 1;
        sql.setParameter(index++, tracfoneOneArUsaMarket.getNation());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCounty());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getMarketingName());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getMhzTotal());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getSpectrumBlocks());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktCode());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktName());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktNameAlternate());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktMultiState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktCode());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktName());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktNameAlternate());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktMultiState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktCode());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktName());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktNameAlternate());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktMultiState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getProtocol());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getExtendedServices());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Name());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Bsid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Bsid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Bsid3());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Mnc());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Name());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Bsid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Bsid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Bsid3());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Mnc());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Name());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Bsid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Bsid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Bsid3());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Mnc());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4Name());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4Bsid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4Bsid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4Bsid3());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4Mnc());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getKeyCode());
        sql.setParameter(index, tracfoneOneArUsaMarket.getCarrierEntity());
    }

    private String getSearchArUsaMarketStatement(String query, TracfoneOneArUsaMarket tracfoneOneArUsaMarket) {
        boolean pagination = false;
        int startIndex = 0;
        int endIndex = 0;
        if (tracfoneOneArUsaMarket.getPaginationSearch() != null) {
            startIndex = tracfoneOneArUsaMarket.getPaginationSearch().getStartIndex();
            endIndex = tracfoneOneArUsaMarket.getPaginationSearch().getEndIndex();
            pagination = (endIndex - startIndex) <= TracfoneOneConstant.FETCH_SIZE;
        }
        StringBuilder sBuilder = new StringBuilder(getSearchArUsaMarketDetails(query + TRACFONE_SEARCH_AR_USA_MARKET, tracfoneOneArUsaMarket));
        // Pagination check for large result queries.
        if (pagination) {
            // Adding 1 to each of these since a ROWNUM of 0 never exists and it is being sent this way from the UI
            startIndex++;
            endIndex++;
            sBuilder.append(") a "
                    + "where ROWNUM < "
                    + endIndex + ") "
                    + "where rnum  >= " + startIndex);
        } else {
            TracfoneonePaginationSearch defaultPagination = new TracfoneonePaginationSearch();
            defaultPagination.setStartIndex(1);
            defaultPagination.setEndIndex(1000);
            tracfoneOneArUsaMarket.setPaginationSearch(defaultPagination);
            sBuilder.append(") a "
                    + " where ROWNUM < "
                    + "1000 ) "
                    + "where rnum  >= 0");
        }
        LOGGER.info("The search query is " + sBuilder.toString());
        return sBuilder.toString();
    }

    private void setSearchArUsaMarketDetails(Query sql, Query sqlCount, TracfoneOneArUsaMarket tracfoneOneArUsaMarket) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getKeyCode())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getKeyCode());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getKeyCode());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getNation())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getNation());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getNation());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getState())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getState());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getState());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getCounty())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getCounty());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getCounty());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getCarrierEntity())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getCarrierEntity());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getCarrierEntity());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getMarketingName())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getMarketingName());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getMarketingName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getMhzTotal())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getMhzTotal());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getMhzTotal());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getSpectrumBlocks())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getSpectrumBlocks());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getSpectrumBlocks());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getCmaMktCode())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getCmaMktCode());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktCode());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getCmaMktState())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getCmaMktState());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktState());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getCmaMktName())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getCmaMktName());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getCmaMktNameAlternate())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getCmaMktNameAlternate());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktNameAlternate());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getCmaMktMultiState())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getCmaMktMultiState());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktMultiState());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBtaMktCode())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBtaMktCode());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktCode());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBtaMktState())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBtaMktState());
            sqlCount.setParameter(index, tracfoneOneArUsaMarket.getBtaMktState());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBtaMktName())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBtaMktName());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBtaMktNameAlternate())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBtaMktNameAlternate());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktNameAlternate());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBtaMktMultiState())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBtaMktMultiState());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktMultiState());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBeaMktCode())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBeaMktCode());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktCode());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBeaMktState())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBeaMktState());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktState());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBeaMktName())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBeaMktName());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBeaMktNameAlternate())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBeaMktNameAlternate());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktNameAlternate());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBeaMktMultiState())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBeaMktMultiState());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktMultiState());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getProtocol())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getProtocol());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getProtocol());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getExtendedServices())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getExtendedServices());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getExtendedServices());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid1())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid1());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid1());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid1Name())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid1Name());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid1Name());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid1Bsid1())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid1Bsid1());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid1Bsid1());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid1Bsid2())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid1Bsid2());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid1Bsid2());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid1Bsid3())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid1Bsid3());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid1Bsid3());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid1Mnc())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid1Mnc());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid1Mnc());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid2())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid2());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid2());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid2Name())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid2Name());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid2Name());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid2Bsid1())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid2Bsid1());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid2Bsid1());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid2Bsid2())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid2Bsid2());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid2Bsid2());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid2Bsid3())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid2Bsid3());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid2Bsid3());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid2Mnc())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid2Mnc());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid2Mnc());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid3());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid3());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3Name())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid3Name());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid3Name());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3Bsid1())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid3Bsid1());
            sqlCount.setParameter(index, tracfoneOneArUsaMarket.getBid3Bsid1());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3Bsid2())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid3Bsid2());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid3Bsid2());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3Bsid3())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid3Bsid3());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid3Bsid3());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3Mnc())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid3Mnc());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid3Mnc());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid4())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid4());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid4());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid4Name())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid4Name());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid4Name());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid4Bsid1())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid4Bsid1());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid4Bsid1());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid4Bsid2())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid4Bsid2());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid4Bsid2());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid4Bsid3())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid4Bsid3());
            sqlCount.setParameter(index++, tracfoneOneArUsaMarket.getBid4Bsid3());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid4Mnc())) {
            sql.setParameter(index, tracfoneOneArUsaMarket.getBid4Mnc());
            sqlCount.setParameter(index, tracfoneOneArUsaMarket.getBid4Mnc());
        }
    }


    private String getSearchArUsaMarketDetails(String query, TracfoneOneArUsaMarket tracfoneOneArUsaMarket) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(query);
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getKeyCode())) {
            builder.append("KEY_CODE = ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getNation())) {
            builder.append("NATION = ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getState())) {
            builder.append(STATE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getCounty())) {
            builder.append("COUNTY = ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getCarrierEntity())) {
            builder.append("CARRIER_ENTITY = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getMarketingName())) {
            builder.append("MARKETING_NAME = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getMhzTotal())) {
            builder.append("MHZ_TOTAL = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getSpectrumBlocks())) {
            builder.append("SPECTRUM_BLOCKS = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getCmaMktCode())) {
            builder.append("CMA_MKT_CODE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getCmaMktState())) {
            builder.append("CMA_MKT_STATE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getCmaMktName())) {
            builder.append("CMA_MKT_NAME = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getCmaMktNameAlternate())) {
            builder.append("CMA_MKT_NAME_ALTERNATE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getCmaMktMultiState())) {
            builder.append("CMA_MKT_MULTI_STATE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBtaMktCode())) {
            builder.append("BTA_MKT_CODE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBtaMktState())) {
            builder.append("BTA_MKT_STATE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBtaMktName())) {
            builder.append(BTA_MKT_NAME_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBtaMktNameAlternate())) {
            builder.append("BTA_MKT_NAME_ALTERNATE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBtaMktMultiState())) {
            builder.append("BTA_MKT_MULTI_STATE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBeaMktCode())) {
            builder.append("BEA_MKT_CODE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBeaMktState())) {
            builder.append("BEA_MKT_STATE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBeaMktName())) {
            builder.append("BEA_MKT_NAME = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBeaMktNameAlternate())) {
            builder.append("BEA_MKT_NAME_ALTERNATE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBeaMktMultiState())) {
            builder.append("BEA_MKT_MULTI_STATE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getProtocol())) {
            builder.append("PROTOCOL = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getExtendedServices())) {
            builder.append("EXTENDED_SERVICES = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid1())) {
            builder.append("BID1 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid1Name())) {
            builder.append("BID1_NAME = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid1Bsid1())) {
            builder.append("BID1_BSID1 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid1Bsid2())) {
            builder.append("BID1_BSID2 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid1Bsid3())) {
            builder.append("BID1_BSID3 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid1Mnc())) {
            builder.append("BID1_MNC = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid2())) {
            builder.append("BID2 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid2Name())) {
            builder.append("BID2_NAME = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid2Bsid1())) {
            builder.append("BID2_BSID1 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid2Bsid2())) {
            builder.append("BID2_BSID2 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid2Bsid3())) {
            builder.append("BID2_BSID3 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid2Mnc())) {
            builder.append("BID2_MNC = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3())) {
            builder.append("BID3 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3Name())) {
            builder.append("BID3_NAME = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3Bsid1())) {
            builder.append("BID3_BSID1 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3Bsid2())) {
            builder.append("BID3_BSID2 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3Bsid3())) {
            builder.append("BID3_BSID3 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3Mnc())) {
            builder.append("BID3_MNC = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid4())) {
            builder.append("BID4 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid4Name())) {
            builder.append("BID4_NAME = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3Bsid1())) {
            builder.append("BID4_BSID1 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3Bsid2())) {
            builder.append("BID4_BSID2 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3Bsid3())) {
            builder.append("BID4_BSID3 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneArUsaMarket.getBid3Mnc())) {
            builder.append("BID4_MNC = ?").append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("QUERY" + TRACFONE_SEARCH_AR_USA_MARKET);
        return searchQuery;
    }

    private TFOneArUsaMarket getArUsaMarketDetails(Object[] cRtlArUsaMarket) {
        TFOneArUsaMarket arUsaMarket = new TFOneArUsaMarket();
        if (cRtlArUsaMarket[0] != null) {
            arUsaMarket.setKeyCode(String.valueOf(cRtlArUsaMarket[0]));
        }
        if (cRtlArUsaMarket[1] != null) {
            arUsaMarket.setNation(String.valueOf(cRtlArUsaMarket[1]));
        }
        if (cRtlArUsaMarket[2] != null) {
            arUsaMarket.setState(String.valueOf(cRtlArUsaMarket[2]));
        }
        if (cRtlArUsaMarket[3] != null) {
            arUsaMarket.setCounty(String.valueOf(cRtlArUsaMarket[3]));
        }
        if (cRtlArUsaMarket[4] != null) {
            arUsaMarket.setCarrierEntity(String.valueOf(cRtlArUsaMarket[4]));
        }
        if (cRtlArUsaMarket[5] != null) {
            arUsaMarket.setMarketingName(String.valueOf(cRtlArUsaMarket[5]));
        }
        if (cRtlArUsaMarket[6] != null) {
            arUsaMarket.setMhzTotal(String.valueOf(cRtlArUsaMarket[6]));
        }
        if (cRtlArUsaMarket[7] != null) {
            arUsaMarket.setSpectrumBlocks(String.valueOf(cRtlArUsaMarket[7]));
        }
        if (cRtlArUsaMarket[8] != null) {
            arUsaMarket.setCmaMktCode(String.valueOf(cRtlArUsaMarket[8]));
        }
        if (cRtlArUsaMarket[9] != null) {
            arUsaMarket.setCmaMktState(String.valueOf(cRtlArUsaMarket[9]));
        }
        if (cRtlArUsaMarket[10] != null) {
            arUsaMarket.setCmaMktName(String.valueOf(cRtlArUsaMarket[10]));
        }
        if (cRtlArUsaMarket[11] != null) {
            arUsaMarket.setCmaMktNameAlternate(String.valueOf(cRtlArUsaMarket[11]));
        }
        if (cRtlArUsaMarket[12] != null) {
            arUsaMarket.setCmaMktMultiState(String.valueOf(cRtlArUsaMarket[12]));
        }
        if (cRtlArUsaMarket[13] != null) {
            arUsaMarket.setBtaMktCode(String.valueOf(cRtlArUsaMarket[13]));
        }
        if (cRtlArUsaMarket[14] != null) {
            arUsaMarket.setBtaMktState(String.valueOf(cRtlArUsaMarket[14]));
        }
        if (cRtlArUsaMarket[15] != null) {
            arUsaMarket.setBtaMktName(String.valueOf(cRtlArUsaMarket[15]));
        }
        if (cRtlArUsaMarket[16] != null) {
            arUsaMarket.setBtaMktNameAlternate(String.valueOf(cRtlArUsaMarket[16]));
        }
        if (cRtlArUsaMarket[17] != null) {
            arUsaMarket.setBtaMktMultiState(String.valueOf(cRtlArUsaMarket[17]));
        }
        if (cRtlArUsaMarket[18] != null) {
            arUsaMarket.setBeaMktCode(String.valueOf(cRtlArUsaMarket[18]));
        }
        if (cRtlArUsaMarket[19] != null) {
            arUsaMarket.setBeaMktState(String.valueOf(cRtlArUsaMarket[19]));
        }
        if (cRtlArUsaMarket[20] != null) {
            arUsaMarket.setBeaMktName(String.valueOf(cRtlArUsaMarket[20]));
        }
        if (cRtlArUsaMarket[21] != null) {
            arUsaMarket.setBeaMktNameAlternate(String.valueOf(cRtlArUsaMarket[21]));
        }
        if (cRtlArUsaMarket[22] != null) {
            arUsaMarket.setBeaMktMultiState(String.valueOf(cRtlArUsaMarket[22]));
        }
        if (cRtlArUsaMarket[23] != null) {
            arUsaMarket.setProtocol(String.valueOf(cRtlArUsaMarket[23]));
        }
        if (cRtlArUsaMarket[24] != null) {
            arUsaMarket.setExtendedServices(String.valueOf(cRtlArUsaMarket[24]));
        }
        if (cRtlArUsaMarket[25] != null) {
            arUsaMarket.setBid1(String.valueOf(cRtlArUsaMarket[25]));
        }
        if (cRtlArUsaMarket[26] != null) {
            arUsaMarket.setBid1Name(String.valueOf(cRtlArUsaMarket[26]));
        }
        if (cRtlArUsaMarket[27] != null) {
            arUsaMarket.setBid1Bsid1(String.valueOf(cRtlArUsaMarket[27]));
        }
        if (cRtlArUsaMarket[28] != null) {
            arUsaMarket.setBid1Bsid2(String.valueOf(cRtlArUsaMarket[28]));
        }
        if (cRtlArUsaMarket[29] != null) {
            arUsaMarket.setBid1Bsid3(String.valueOf(cRtlArUsaMarket[29]));
        }
        if (cRtlArUsaMarket[30] != null) {
            arUsaMarket.setBid1Mnc(String.valueOf(cRtlArUsaMarket[30]));
        }
        if (cRtlArUsaMarket[31] != null) {
            arUsaMarket.setBid2(String.valueOf(cRtlArUsaMarket[31]));
        }
        if (cRtlArUsaMarket[32] != null) {
            arUsaMarket.setBid2Name(String.valueOf(cRtlArUsaMarket[32]));
        }
        if (cRtlArUsaMarket[33] != null) {
            arUsaMarket.setBid2Bsid1(String.valueOf(cRtlArUsaMarket[33]));
        }
        if (cRtlArUsaMarket[34] != null) {
            arUsaMarket.setBid2Bsid2(String.valueOf(cRtlArUsaMarket[34]));
        }
        if (cRtlArUsaMarket[35] != null) {
            arUsaMarket.setBid2Bsid3(String.valueOf(cRtlArUsaMarket[35]));
        }
        if (cRtlArUsaMarket[36] != null) {
            arUsaMarket.setBid2Mnc(String.valueOf(cRtlArUsaMarket[36]));
        }
        if (cRtlArUsaMarket[37] != null) {
            arUsaMarket.setBid3(String.valueOf(cRtlArUsaMarket[37]));
        }
        if (cRtlArUsaMarket[38] != null) {
            arUsaMarket.setBid3Name(String.valueOf(cRtlArUsaMarket[38]));
        }
        if (cRtlArUsaMarket[39] != null) {
            arUsaMarket.setBid3Bsid1(String.valueOf(cRtlArUsaMarket[39]));
        }
        if (cRtlArUsaMarket[40] != null) {
            arUsaMarket.setBid3Bsid2(String.valueOf(cRtlArUsaMarket[40]));
        }
        if (cRtlArUsaMarket[41] != null) {
            arUsaMarket.setBid3Bsid3(String.valueOf(cRtlArUsaMarket[41]));
        }
        if (cRtlArUsaMarket[42] != null) {
            arUsaMarket.setBid3Mnc(String.valueOf(cRtlArUsaMarket[42]));
        }
        if (cRtlArUsaMarket[43] != null) {
            arUsaMarket.setBid4(String.valueOf(cRtlArUsaMarket[43]));
        }
        if (cRtlArUsaMarket[44] != null) {
            arUsaMarket.setBid4Name(String.valueOf(cRtlArUsaMarket[44]));
        }

        if (cRtlArUsaMarket[45] != null) {
            arUsaMarket.setBid4Bsid1(String.valueOf(cRtlArUsaMarket[45]));
        }
        if (cRtlArUsaMarket[46] != null) {
            arUsaMarket.setBid4Bsid2(String.valueOf(cRtlArUsaMarket[46]));
        }
        if (cRtlArUsaMarket[47] != null) {
            arUsaMarket.setBid4Bsid3(String.valueOf(cRtlArUsaMarket[47]));
        }
        if (cRtlArUsaMarket[48] != null) {
            arUsaMarket.setBid4Mnc(String.valueOf(cRtlArUsaMarket[48]));
        }
        return arUsaMarket;
    }

    @Override
    public TFOneGeneralResponse insertArUsaMarketDetails(TracfoneOneArUsaMarket tracfoneOneArUsaMarket, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            Query sql = cRtlArUsaMarketFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_INSERT_AR_USA_MARKET);
            setInsertArUsaMarketDetails(sql, tracfoneOneArUsaMarket);
            sql.executeUpdate();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Ar Usa Market", gson.toJson(tracfoneOneArUsaMarket), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Ar Usa Market details Inserted");
    }

    private void setInsertArUsaMarketDetails(Query sql, TracfoneOneArUsaMarket tracfoneOneArUsaMarket) throws SQLException {
        int index = 1;
        sql.setParameter(index++, tracfoneOneArUsaMarket.getKeyCode());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getNation());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCounty());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCarrierEntity());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getMarketingName());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getMhzTotal());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getSpectrumBlocks());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktCode());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktName());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktNameAlternate());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktMultiState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktCode());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktName());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktNameAlternate());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktMultiState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktCode());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktName());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktNameAlternate());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktMultiState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getProtocol());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getExtendedServices());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Name());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Bsid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Bsid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Bsid3());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Mnc());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Name());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Bsid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Bsid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Bsid3());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Mnc());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Name());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Bsid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Bsid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Bsid3());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Mnc());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4Name());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4Bsid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4Bsid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4Bsid3());
        sql.setParameter(index, tracfoneOneArUsaMarket.getBid4Mnc());
    }

    @Override
    public TFOneGeneralResponse deleteArUsaMarketDetails(TracfoneOneArUsaMarket tracfoneOneArUsaMarket, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            Query sql = cRtlArUsaMarketFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_DELETE_AR_USA_MARKET);
            setDeleteArUsaMarketDetails(sql, tracfoneOneArUsaMarket);
            sql.executeUpdate();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Deleted Ar Usa Market", gson.toJson(tracfoneOneArUsaMarket), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Ar Usa Market details deleted");
    }

    private void setDeleteArUsaMarketDetails(Query sql, TracfoneOneArUsaMarket tracfoneOneArUsaMarket) throws SQLException {
        int index = 1;
        sql.setParameter(index++, tracfoneOneArUsaMarket.getKeyCode());
        sql.setParameter(index, tracfoneOneArUsaMarket.getCarrierEntity());
    }

    @Override
    public TFOneGeneralResponse updateArUsaMarketDetails(TracfoneOneArUsaMarket tracfoneOneArUsaMarket, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            Query sql = cRtlArUsaMarketFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_UPDATE_AR_USA_MARKET);
            setUpdateArUsaMarketDetails(sql, tracfoneOneArUsaMarket);
            sql.executeUpdate();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Ar Usa Market details", gson.toJson(tracfoneOneArUsaMarket), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Ar Usa Market details Record Updated");
    }

    private void setUpdateArUsaMarketDetails(Query sql, TracfoneOneArUsaMarket tracfoneOneArUsaMarket) throws SQLException {
        int index = 1;
        sql.setParameter(index++, tracfoneOneArUsaMarket.getKeyCode());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getNation());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCounty());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCarrierEntity());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getMarketingName());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getMhzTotal());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getSpectrumBlocks());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktCode());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktName());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktNameAlternate());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getCmaMktMultiState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktCode());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktName());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktNameAlternate());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBtaMktMultiState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktCode());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktName());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktNameAlternate());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBeaMktMultiState());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getProtocol());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getExtendedServices());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Name());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Bsid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Bsid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Bsid3());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid1Mnc());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Name());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Bsid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Bsid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Bsid3());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid2Mnc());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Name());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Bsid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Bsid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Bsid3());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid3Mnc());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4Name());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4Bsid1());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4Bsid2());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4Bsid3());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getBid4Mnc());
        sql.setParameter(index++, tracfoneOneArUsaMarket.getOldKeyCode());
        sql.setParameter(index, tracfoneOneArUsaMarket.getOldCarrierEntity());
    }

    @Override
    public TFOneGeneralResponse bulkUpdateArUsaMarketDetails(List<TracfoneOneArUsaMarket> tracfoneOneArUsaMarket, int userId) throws TracfoneOneException {
        String uniqueId = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        try {
            Query sql = cRtlArUsaMarketFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_UPDATE_AR_USA_MARKET);
            for (TracfoneOneArUsaMarket searchArUsaMarket : tracfoneOneArUsaMarket) {
                if (!searchArUsaMarket.isCheckDuplicate()) {
                    if (getArUsaMarketDetails(searchArUsaMarket).getArUsaMarkets().isEmpty()) {
                        setUpdateArUsaMarketDetails(sql, searchArUsaMarket);
                        sql.executeUpdate();
                    }
                } else {
                    TracfoneOneArUsaMarket searchArUsaMarkets = new TracfoneOneArUsaMarket();
                    searchArUsaMarkets.setCarrierEntity(searchArUsaMarket.getCarrierEntity());
                    searchArUsaMarkets.setKeyCode(searchArUsaMarket.getKeyCode());
                    if (getArUsaMarketDetails(searchArUsaMarkets).getArUsaMarkets().isEmpty()) {
                        setUpdateArUsaMarketDetails(sql, searchArUsaMarket);
                        sql.executeUpdate();
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Bulk Update AR USA Market Details", "Bulk Update AR USA Market " + tracfoneOneArUsaMarket, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, uniqueId);
    }

    @Override
    public TFOneGeneralResponse bulkInsertArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips, int userId, String uniqueId) throws TracfoneOneException {
        try {
            Query sql = cRtlArUsaPostalZipsFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_INSERT_AR_USA_POSTAL_ZIPS);
            TracfoneOneArUsaPostalZips searchArUsaPostalZips = new TracfoneOneArUsaPostalZips();
            searchArUsaPostalZips.setPostalCode(tracfoneOneArUsaPostalZips.getPostalCode());
            if (getArUsaPostalZips(searchArUsaPostalZips).isEmpty()) {
                setInsertArUsaPostalZips(sql, tracfoneOneArUsaPostalZips);
                sql.executeUpdate();
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, BULK_AR_USA_POSTAL_ZIPS_INSERT, "Inserted AR USA Postal Zips" + tracfoneOneArUsaPostalZips, CARRIERID + uniqueId);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Inserted");
    }

    @Override
    public TFOneGeneralResponse bulkInsertArUsaMarket(TracfoneOneArUsaMarket tracfoneOneArUsaMarket, int userId, String uniqueId) throws TracfoneOneException {
        try {
            Query sql = cRtlArUsaMarketFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_INSERT_AR_USA_MARKET);
            TracfoneOneArUsaMarket searchArUsaMarket = new TracfoneOneArUsaMarket();
            searchArUsaMarket.setCarrierEntity(tracfoneOneArUsaMarket.getCarrierEntity());
            searchArUsaMarket.setKeyCode(tracfoneOneArUsaMarket.getKeyCode());
            if (getArUsaMarketDetails(searchArUsaMarket).getArUsaMarkets().isEmpty()) {
                setInsertArUsaMarketDetails(sql, tracfoneOneArUsaMarket);
                sql.executeUpdate();
            }
            else{
                replaceArUsaMarketDetails(tracfoneOneArUsaMarket,userId);
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, BULK_AR_USA_MARKET_INSERT, "Inserted AR USA Market" + tracfoneOneArUsaMarket, CARRIERID + uniqueId);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Inserted");
    }

    @Override
    public TFOneGeneralResponse insertGeoLoc(TracfoneOneGeoLoc tfOneGeoLoc, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            Query sql = cRtlArUsaMarketFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_INSERT_GEO_LOC);
            setInsertGeoLoc(sql, tfOneGeoLoc);
            sql.executeUpdate();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Geo Loc", gson.toJson(tfOneGeoLoc), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Geo Loc inserted successfully");
    }


    private void setInsertGeoLoc(Query sql, TracfoneOneGeoLoc tfOneGeoLoc) {
        int index = 1;
        sql.setParameter(index++, tfOneGeoLoc.getZip());
        sql.setParameter(index++, tfOneGeoLoc.getState());
        sql.setParameter(index++, tfOneGeoLoc.getPopcy());
        sql.setParameter(index++, tfOneGeoLoc.getPop05());
        sql.setParameter(index++, tfOneGeoLoc.getLatitude());
        sql.setParameter(index++, tfOneGeoLoc.getLongitude());
        sql.setParameter(index++, tfOneGeoLoc.getRlatitude());
        sql.setParameter(index++, tfOneGeoLoc.getRlongitude());
        sql.setParameter(index++, tfOneGeoLoc.getSrlatitude());
        sql.setParameter(index++, tfOneGeoLoc.getCrlatitude());
        sql.setParameter(index, tfOneGeoLoc.getRzg2user());
    }

    @Override
    public TFOneGeneralResponse deleteGeoLoc(TracfoneOneGeoLoc tfOneGeoLoc, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            cRtlArUsaMarketFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_DELETE_GEO_LOC)
                    .setParameter(1, tfOneGeoLoc.getZip()).executeUpdate();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Deleted Geo Loc", gson.toJson(tfOneGeoLoc), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Geo Loc deleted successfully");
    }

    @Override
    public TFOneGeneralResponse bulkInsertGeoLocs(TracfoneOneGeoLoc tfGeoLoc, int userId, String unique) throws TracfoneOneException {
        try {
            Query sql = cRtlArUsaMarketFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_INSERT_GEO_LOC);
            setInsertGeoLoc(sql, tfGeoLoc);
            sql.executeUpdate();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, BULK_GEO_LOC_INSERT,
                    "Inserted Geo Locs " + tfGeoLoc, CARRIERID + unique);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Geo Loc inserted successfully");
    }

    @Override
    public List<String> getUsers() throws TracfoneOneException {
        List<String> users = new ArrayList<>();
        try {
            users = cRtlArUsaMarketFacadeLocal.getEntityManager().
                    createNativeQuery(TRACFONE_GET_SEC_USER_ID).getResultList();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return users;
    }

    @Override
    public List<TFOneGeoLoc> searchGeoLoc(TracfoneOneGeoLoc tfOneGeoLoc) throws TracfoneOneException {
        List<TFOneGeoLoc> geoLocs = new ArrayList<>(1);
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_GEO_LOC);
        try {
            List<Object[]> crtlGeoLocs = new ArrayList<>(1);
            Query query = cRtlArUsaPostalZipsFacadeLocal.getEntityManager().
                    createNativeQuery(buildInClause(builder,
                            tfOneGeoLoc.getZip().split(",").length).toString());
            int index = 1;
            for (String zip : tfOneGeoLoc.getZip().split(",")) {
                query.setParameter(index++, zip);
            }
            crtlGeoLocs = query.getResultList();

            for (Object[] crtlGeoLoc : crtlGeoLocs) {
                geoLocs.add(setGeoLocs(crtlGeoLoc));
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return geoLocs;
    }

    private TFOneGeoLoc setGeoLocs(Object[] crtlGeoLoc) {
        TFOneGeoLoc tfOneGeoLoc = new TFOneGeoLoc();
        tfOneGeoLoc.setZip(String.valueOf(crtlGeoLoc[0]));
        if (crtlGeoLoc[1] != null) {
            tfOneGeoLoc.setState(String.valueOf(crtlGeoLoc[1]));
        }
        if (crtlGeoLoc[2] != null) {
            tfOneGeoLoc.setPopcy(String.valueOf(crtlGeoLoc[2]));
        }
        if (crtlGeoLoc[3] != null) {
            tfOneGeoLoc.setPop05(String.valueOf(crtlGeoLoc[3]));
        }
        if (crtlGeoLoc[4] != null) {
            tfOneGeoLoc.setLatitude(String.valueOf(crtlGeoLoc[4]));
        }
        if (crtlGeoLoc[5] != null) {
            tfOneGeoLoc.setLongitude(String.valueOf(crtlGeoLoc[5]));
        }
        if (crtlGeoLoc[6] != null) {
            tfOneGeoLoc.setRlatitude(String.valueOf(crtlGeoLoc[6]));
        }
        if (crtlGeoLoc[7] != null) {
            tfOneGeoLoc.setRlongitude(String.valueOf(crtlGeoLoc[7]));
        }
        if (crtlGeoLoc[8] != null) {
            tfOneGeoLoc.setSrlatitude(String.valueOf(crtlGeoLoc[8]));
        }
        if (crtlGeoLoc[9] != null) {
            tfOneGeoLoc.setCrlatitude(String.valueOf(crtlGeoLoc[9]));
        }
        if (crtlGeoLoc[10] != null) {
            tfOneGeoLoc.setRzg2user(String.valueOf(crtlGeoLoc[10]));
        }
        if (crtlGeoLoc[11] != null) {
            tfOneGeoLoc.setInsertDate(String.valueOf(crtlGeoLoc[11]));
        }
        if (crtlGeoLoc[12] != null) {
            tfOneGeoLoc.setUpdateDate(String.valueOf(crtlGeoLoc[12]));
        }
        return tfOneGeoLoc;
    }

    @Override
    public TFOneGeneralResponse updateGeoLoc(TracfoneOneGeoLoc tfGeoLoc, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            Query sql = cRtlArUsaMarketFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_UPDATE_GEO_LOC);
            setUpdateGeoLoc(sql, tfGeoLoc);
            sql.executeUpdate();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Geo Loc", gson.toJson(tfGeoLoc), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Geo Loc updated successfully");
    }

    private void setUpdateGeoLoc(Query sql, TracfoneOneGeoLoc tfOneGeoLoc) {
        int index = 1;
        sql.setParameter(index++, tfOneGeoLoc.getZip());
        sql.setParameter(index++, tfOneGeoLoc.getState());
        sql.setParameter(index++, tfOneGeoLoc.getPopcy());
        sql.setParameter(index++, tfOneGeoLoc.getPop05());
        sql.setParameter(index++, tfOneGeoLoc.getLatitude());
        sql.setParameter(index++, tfOneGeoLoc.getLongitude());
        sql.setParameter(index++, tfOneGeoLoc.getRlatitude());
        sql.setParameter(index++, tfOneGeoLoc.getRlongitude());
        sql.setParameter(index++, tfOneGeoLoc.getSrlatitude());
        sql.setParameter(index++, tfOneGeoLoc.getCrlatitude());
        sql.setParameter(index, tfOneGeoLoc.getOldZip());
    }

    @Override
    public TFOneGeneralResponse bulkUpdateGeoLoc(List<TracfoneOneGeoLoc> geoLocs, int userId) throws TracfoneOneException {
        String uniqueId = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        try {
            Query sql = cRtlArUsaMarketFacadeLocal.getEntityManager().createNativeQuery(TRACFONE_UPDATE_GEO_LOC);
            for (TracfoneOneGeoLoc geoLoc : geoLocs) {
                if (geoLoc.isCheckDuplicate()) {
                    if (searchGeoLoc(geoLoc).isEmpty()) {
                        setUpdateGeoLoc(sql, geoLoc);
                        sql.executeUpdate();
                    }
                } else {
                    setUpdateGeoLoc(sql, geoLoc);
                    sql.executeUpdate();
                }
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Bulk Update Geo Loc", "Bulk Update Geo Loc " + geoLocs, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, uniqueId);
    }

    @Override
    public List<TFOneCarrierZones> searchCarrierzones(TracfoneOneCarrierZones tracfoneOneCarrierZones) throws TracfoneOneException {
        List<TFOneCarrierZones> tfOneCarrierZones = new ArrayList<>(1);
        TFOneCarrierZones tfOneCarrierZone;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierZones.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchCarrierZones(tracfoneOneCarrierZones));) {
            setSearchCarrierZones(stmt, tracfoneOneCarrierZones);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneCarrierZone = new TFOneCarrierZones();
                    tfOneCarrierZone.setZipCode(resultSet.getString("ZIP"));
                    tfOneCarrierZone.setState(resultSet.getString("ST"));
                    tfOneCarrierZone.setCounty(resultSet.getString(COUNTY));
                    tfOneCarrierZone.setZone(resultSet.getString("ZONE"));
                    tfOneCarrierZone.setRateCente(resultSet.getString("RATE_CENTE"));
                    tfOneCarrierZone.setMarketId(resultSet.getString("MARKETID"));
                    tfOneCarrierZone.setMarketArea(resultSet.getString("MRKT_AREA"));
                    tfOneCarrierZone.setCity(resultSet.getString("CITY"));
                    tfOneCarrierZone.setBtaMarketNumber(resultSet.getString("BTA_MKT_NUMBER"));
                    tfOneCarrierZone.setBtaMarketName(resultSet.getString("BTA_MKT_NAME"));
                    tfOneCarrierZone.setCarrierId(resultSet.getString(CARRIER_ID));
                    tfOneCarrierZone.setCarrierName(resultSet.getString("CARRIER_NAME"));
                    tfOneCarrierZone.setZipStatus(resultSet.getString("ZIP_STATUS"));
                    tfOneCarrierZone.setSimProfile(resultSet.getString("SIM_PROFILE"));
                    tfOneCarrierZone.setSimProfile2(resultSet.getString("SIM_PROFILE_2"));
                    tfOneCarrierZone.setPlanType(resultSet.getString("PLANTYPE"));
                    tfOneCarrierZones.add(tfOneCarrierZone);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneCarrierZones;
    }

    private String getSearchCarrierZones(TracfoneOneCarrierZones tracfoneOneCarrierZones) {
        String Query = null;
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_CARRIERZONES);
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getZipCode())) {
            List<String> zips = Arrays.asList(tracfoneOneCarrierZones.getZipCode().split(","));
            int totalNumberOfZip = zips.size();
            LOGGER.info("Total number of zip to search Zip2Tech is : " + totalNumberOfZip);
            if (totalNumberOfZip < 1000) {
                builder.append("ZIP in(? ");
                buildInClause(builder, totalNumberOfZip);
            } else {
                builder.append("(");
                List<List<String>> splitZips = Lists.partition(zips, 1000);
                StringBuilder tempBuilder;
                for (List<String> splitedZips : splitZips) {
                    tempBuilder = new StringBuilder("ZIP in(? ");
                    buildInClause(tempBuilder, splitedZips.size());
                    builder.append(tempBuilder).append(" OR ");
                }
                builder.delete(builder.lastIndexOf(" OR "), builder.length());
                builder.append(")");
            }
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getState())) {
            builder.append(ST_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getCounty())) {
            builder.append(COUNTY_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getZone())) {
            builder.append(ZONE_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getRateCente())) {
            builder.append("RATE_CENTE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getMarketId())) {
            builder.append("MARKETID = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getMarketArea())) {
            builder.append("MRKT_AREA = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getCity())) {
            builder.append("CITY = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getBtaMarketNumber())) {
            builder.append("BTA_MKT_NUMBER = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getBtaMarketName())) {
            builder.append(BTA_MKT_NAME_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getCarrierId())) {
            builder.append(CARRIER_ID_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getCarrierName())) {
            builder.append(CARRIER_NAME_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getZipStatus())) {
            builder.append("ZIP_STATUS = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getSimProfile())) {
            builder.append("SIM_PROFILE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getSimProfile2())) {
            builder.append("SIM_PROFILE_2 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getPlanType())) {
            builder.append("PLANTYPE = ?").append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            Query = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Query Carrierzones is : " + Query);
        return Query;
    }

    private StringBuilder buildInClause(StringBuilder builder, int size) {
        int index = 1;
        while (index < size) {
            builder.append(",? ");
            index++;
        }
        return builder.append(")");
    }

    private void setSearchCarrierZones(PreparedStatement stmt, TracfoneOneCarrierZones tracfoneOneCarrierZones) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getZipCode())) {
            for (String zip : tracfoneOneCarrierZones.getZipCode().split(",")) {
                stmt.setString(index++, zip);
            }
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getState())) {
            stmt.setString(index++, tracfoneOneCarrierZones.getState());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getCounty())) {
            stmt.setString(index++, tracfoneOneCarrierZones.getCounty());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getZone())) {
            stmt.setString(index++, tracfoneOneCarrierZones.getZone());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getRateCente())) {
            stmt.setString(index++, tracfoneOneCarrierZones.getRateCente());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getMarketId())) {
            stmt.setString(index++, tracfoneOneCarrierZones.getMarketId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getMarketArea())) {
            stmt.setString(index++, tracfoneOneCarrierZones.getMarketArea());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getCity())) {
            stmt.setString(index++, tracfoneOneCarrierZones.getCity());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getBtaMarketNumber())) {
            stmt.setString(index++, tracfoneOneCarrierZones.getBtaMarketNumber());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getBtaMarketName())) {
            stmt.setString(index++, tracfoneOneCarrierZones.getBtaMarketName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getCarrierId())) {
            stmt.setString(index++, tracfoneOneCarrierZones.getCarrierId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getCarrierName())) {
            stmt.setString(index++, tracfoneOneCarrierZones.getCarrierName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getZipStatus())) {
            stmt.setString(index++, tracfoneOneCarrierZones.getZipStatus());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getSimProfile())) {
            stmt.setString(index++, tracfoneOneCarrierZones.getSimProfile());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getSimProfile2())) {
            stmt.setString(index++, tracfoneOneCarrierZones.getSimProfile2());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierZones.getPlanType())) {
            stmt.setString(index, tracfoneOneCarrierZones.getPlanType());
        }
    }

    @Override
    public TFOneGeneralResponse insertCarrierzones(TracfoneOneCarrierZones tracfoneOneCarrierZones, int userId, String uniqueId) throws TracfoneOneException {
        Gson gson = new Gson();
        String unique = "";
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierZones.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_CARRIERZONES);) {
            TracfoneOneCarrierZones searchCarrierZones = new TracfoneOneCarrierZones();
            searchCarrierZones.setDbEnv(tracfoneOneCarrierZones.getDbEnv());
            searchCarrierZones.setZipCode(tracfoneOneCarrierZones.getZipCode());
            searchCarrierZones.setState(tracfoneOneCarrierZones.getState());
            searchCarrierZones.setCounty(tracfoneOneCarrierZones.getCounty());
            searchCarrierZones.setZone(tracfoneOneCarrierZones.getZone());
            searchCarrierZones.setCarrierName(tracfoneOneCarrierZones.getCarrierName());
            List<TFOneCarrierZones> tfonecarrierzones = searchCarrierzones(searchCarrierZones);
            if (tfonecarrierzones.isEmpty()) {
                unique = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
                for (String zip : tracfoneOneCarrierZones.getZipCode().split(",")) {
                    LOGGER.info("zip" + zip);
                    tracfoneOneCarrierZones.setZipCode(zip);
                    LOGGER.info("request" + tracfoneOneCarrierZones);
                    setCarrierzones(stmt, tracfoneOneCarrierZones);
                    stmt.addBatch();
                }
                stmt.executeBatch();
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, BULK_CARRIERZONES_INSERT, gson.toJson(tracfoneOneCarrierZones), CARRIERID + uniqueId);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, unique);
    }

    private void setCarrierzones(PreparedStatement stmt, TracfoneOneCarrierZones tracfoneOneCarrierZones) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneCarrierZones.getZipCode());
        stmt.setString(index++, tracfoneOneCarrierZones.getState());
        stmt.setString(index++, tracfoneOneCarrierZones.getCounty());
        stmt.setString(index++, tracfoneOneCarrierZones.getZone());
        stmt.setString(index++, tracfoneOneCarrierZones.getRateCente());
        stmt.setString(index++, tracfoneOneCarrierZones.getMarketId());
        stmt.setString(index++, tracfoneOneCarrierZones.getMarketArea());
        stmt.setString(index++, tracfoneOneCarrierZones.getCity());
        stmt.setString(index++, tracfoneOneCarrierZones.getBtaMarketNumber());
        stmt.setString(index++, tracfoneOneCarrierZones.getBtaMarketName());
        stmt.setString(index++, tracfoneOneCarrierZones.getCarrierId());
        stmt.setString(index++, tracfoneOneCarrierZones.getCarrierName());
        stmt.setString(index++, tracfoneOneCarrierZones.getZipStatus());
        stmt.setString(index++, tracfoneOneCarrierZones.getSimProfile());
        stmt.setString(index++, tracfoneOneCarrierZones.getSimProfile2());
        stmt.setString(index, tracfoneOneCarrierZones.getPlanType());
    }

    @Override
    public TFOneGeneralResponse deleteCarrierzones(TracfoneOneCarrierZones tracfoneOneCarrierZones, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierZones.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_CARRIERZONES);) {
            setDeleteCarrierZones(stmt, tracfoneOneCarrierZones);
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete carrierzones", "Deleted carrierzones " + tracfoneOneCarrierZones, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Deleted");
    }

    private void setDeleteCarrierZones(PreparedStatement stmt, TracfoneOneCarrierZones tracfoneOneCarrierZones) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneCarrierZones.getZipCode());
        stmt.setString(index++, tracfoneOneCarrierZones.getState());
        stmt.setString(index++, tracfoneOneCarrierZones.getCounty());
        stmt.setString(index++, tracfoneOneCarrierZones.getZone());
        stmt.setString(index, tracfoneOneCarrierZones.getCarrierName());
    }

    @Override
    public TFOneGeneralResponse updateCarrierzones(TracfoneOneCarrierZones tracfoneOneCarrierZones, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierZones.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CARRIERZONES);) {
            setUpdateCarrierzones(stmt, tracfoneOneCarrierZones);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Carrierzones", "Updated Carrierzones" + tracfoneOneCarrierZones, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, UPDATED);
    }

    @Override
    public TFOneGeneralResponse bulkDeleteCarrierZones(TracfoneOneCarrierZones tracfoneOneCarrierZones, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierZones.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_CARRIERZONES);) {
            setDeleteCarrierZones(stmt, tracfoneOneCarrierZones);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Carrier Zones", "Deleted Carrier Zones Object " + tracfoneOneCarrierZones, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, String.valueOf(tracfoneOneCarrierZones.getZipCode()));
    }

    @Override
    public TFOneGeneralResponse bulkUpdateCarrierZones(List<TracfoneOneCarrierZones> tracfoneOneCarrierZones, int userId) throws TracfoneOneException {
        String uniqueId = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierZones.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CARRIERZONES);) {
            for (TracfoneOneCarrierZones Carrierzones : tracfoneOneCarrierZones) {
                TracfoneOneCarrierZones searchncarrierzones = new TracfoneOneCarrierZones();
                if (!Carrierzones.isCheckDuplicate()) {
                    if (searchCarrierzones(Carrierzones).isEmpty()) {
                        setUpdateCarrierzones(stmt, Carrierzones);
                        stmt.executeUpdate();
                    }
                } else {
                    searchncarrierzones.setDbEnv((Carrierzones.getDbEnv()));
                    searchncarrierzones.setZipCode(Carrierzones.getZipCode());
                    searchncarrierzones.setState(Carrierzones.getState());
                    searchncarrierzones.setZone(Carrierzones.getZone());
                    searchncarrierzones.setCounty(Carrierzones.getCounty());
                    searchncarrierzones.setCarrierName(Carrierzones.getCarrierName());
                    if (searchCarrierzones(searchncarrierzones).isEmpty()) {
                        setUpdateCarrierzones(stmt, Carrierzones);
                        stmt.executeUpdate();
                    }
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Bulk Update Carrier zones", "Bulk Update Npanxx 2 Carrier zones" + tracfoneOneCarrierZones, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, uniqueId);
    }

    private void setUpdateCarrierzones(PreparedStatement stmt, TracfoneOneCarrierZones tracfoneOneCarrierZones) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneCarrierZones.getZipCode());
        stmt.setString(index++, tracfoneOneCarrierZones.getState());
        stmt.setString(index++, tracfoneOneCarrierZones.getCounty());
        stmt.setString(index++, tracfoneOneCarrierZones.getZone());
        stmt.setString(index++, tracfoneOneCarrierZones.getRateCente());
        stmt.setString(index++, tracfoneOneCarrierZones.getMarketId());
        stmt.setString(index++, tracfoneOneCarrierZones.getMarketArea());
        stmt.setString(index++, tracfoneOneCarrierZones.getCity());
        stmt.setString(index++, tracfoneOneCarrierZones.getBtaMarketNumber());
        stmt.setString(index++, tracfoneOneCarrierZones.getBtaMarketName());
        stmt.setString(index++, tracfoneOneCarrierZones.getCarrierId());
        stmt.setString(index++, tracfoneOneCarrierZones.getCarrierName());
        stmt.setString(index++, tracfoneOneCarrierZones.getZipStatus());
        stmt.setString(index++, tracfoneOneCarrierZones.getSimProfile());
        stmt.setString(index++, tracfoneOneCarrierZones.getSimProfile2());
        stmt.setString(index++, tracfoneOneCarrierZones.getPlanType());
        stmt.setString(index++, tracfoneOneCarrierZones.getOldZipCode());
        stmt.setString(index++, tracfoneOneCarrierZones.getOldState());
        stmt.setString(index++, tracfoneOneCarrierZones.getOldCounty());
        stmt.setString(index++, tracfoneOneCarrierZones.getOldZone());
        stmt.setString(index, tracfoneOneCarrierZones.getOldCarrierName());
    }

    @Override
    public List<TFOneCarrierPref> searchCarrierpref(TracfoneOneCarrierPref tracfoneOneCarrierPref) throws TracfoneOneException {
        List<TFOneCarrierPref> tfOneCarrierprefs = new ArrayList<>(1);
        TFOneCarrierPref tfOneCarrierpref;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierPref.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchCarrierprefQuerry(tracfoneOneCarrierPref));) {
            setCarrierprefQuery(stmt, tracfoneOneCarrierPref);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneCarrierpref = new TFOneCarrierPref();
                    tfOneCarrierpref.setState(resultSet.getString("ST"));
                    tfOneCarrierpref.setCounty(resultSet.getString(COUNTY));
                    tfOneCarrierpref.setCarrierId(resultSet.getString(CARRIER_ID));
                    tfOneCarrierpref.setCarrierName(resultSet.getString("CARRIER_NAME"));
                    tfOneCarrierpref.setCarrierRank(resultSet.getString("CARRIER_RANK"));
                    tfOneCarrierpref.setNewRank(resultSet.getString("NEW_RANK"));
                    tfOneCarrierprefs.add(tfOneCarrierpref);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneCarrierprefs;
    }

    private String getSearchCarrierprefQuerry(TracfoneOneCarrierPref tracfoneOneCarrierPref) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_CARRIERPREF);
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getState())) {
            builder.append(ST_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCounty())) {
            builder.append(COUNTY_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCarrierId())) {
            builder.append(CARRIER_ID_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCarrierName())) {
            builder.append(CARRIER_NAME_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCarrierRank())) {
            builder.append(CARRIER_RANK_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getNewRank())) {
            builder.append(NEW_RANK_VALUE).append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        return searchQuery;
    }

    private void setCarrierprefQuery(PreparedStatement stmt, TracfoneOneCarrierPref tracfoneOneCarrierPref) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getState())) {
            stmt.setString(index++, tracfoneOneCarrierPref.getState());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCounty())) {
            stmt.setString(index++, tracfoneOneCarrierPref.getCounty());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCarrierId())) {
            stmt.setString(index++, tracfoneOneCarrierPref.getCarrierId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCarrierName())) {
            stmt.setString(index++, tracfoneOneCarrierPref.getCarrierName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCarrierRank())) {
            stmt.setString(index++, tracfoneOneCarrierPref.getCarrierRank());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getNewRank())) {
            stmt.setString(index, tracfoneOneCarrierPref.getNewRank());
        }
    }

    @Override
    public TFOneGeneralResponse insertCarrierpref(TracfoneOneCarrierPref tracfoneOneCarrierPref, int userId, String uniqueId) throws TracfoneOneException {
        Gson gson = new Gson();
        String unique = "";
        String Message ="";
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierPref.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_CARRIERPREF);) {
            TracfoneOneCarrierPref searchCarrierPrefs = new TracfoneOneCarrierPref();
            searchCarrierPrefs.setDbEnv((tracfoneOneCarrierPref.getDbEnv()));
            searchCarrierPrefs.setState(tracfoneOneCarrierPref.getState());
            searchCarrierPrefs.setCounty(tracfoneOneCarrierPref.getCounty());
            searchCarrierPrefs.setCarrierId(tracfoneOneCarrierPref.getCarrierId());
            searchCarrierPrefs.setCarrierName(tracfoneOneCarrierPref.getCarrierName());
            searchCarrierPrefs.setCarrierRank(tracfoneOneCarrierPref.getCarrierRank());
            searchCarrierPrefs.setNewRank(tracfoneOneCarrierPref.getNewRank());
            List<TFOneCarrierPref> tfonecarrierprefs = searchCarrierpref(searchCarrierPrefs);
            if (tfonecarrierprefs.isEmpty()) {
                TracfoneOneCarrierPref searchCarrierpref = new TracfoneOneCarrierPref();
                searchCarrierpref.setDbEnv((tracfoneOneCarrierPref.getDbEnv()));
                searchCarrierpref.setState(tracfoneOneCarrierPref.getState());
                searchCarrierpref.setCounty(tracfoneOneCarrierPref.getCounty());
                searchCarrierpref.setCarrierId(tracfoneOneCarrierPref.getCarrierId());
                List<TFOneCarrierPref> tfonecarrierpref = getNpaNxx2CarrierZones(searchCarrierpref);
                if (!tfonecarrierpref.isEmpty()) {
                    unique = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
                    Message ="Success";
                    setCarrierpref(stmt, tracfoneOneCarrierPref);
                    stmt.executeUpdate();
                } else {
                    Message ="Unable to insert Record";
                    unique = "Record not present in NPANXX2CarrierZones";
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, BULK_CARRIERPREF_INSERT, gson.toJson(tracfoneOneCarrierPref), CARRIERID + uniqueId);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(Message, unique);
    }

    private void setCarrierpref(PreparedStatement stmt, TracfoneOneCarrierPref tracfoneOneCarrierPref) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneCarrierPref.getState());
        stmt.setString(index++, tracfoneOneCarrierPref.getCounty());
        stmt.setString(index++, tracfoneOneCarrierPref.getCarrierId());
        stmt.setString(index++, tracfoneOneCarrierPref.getCarrierName());
        stmt.setString(index++, tracfoneOneCarrierPref.getCarrierRank());
        stmt.setString(index, tracfoneOneCarrierPref.getNewRank());
    }

    public List<TFOneCarrierPref> getNpaNxx2CarrierZones(TracfoneOneCarrierPref tracfoneOneCarrierPref) throws TracfoneOneException {
        List<TFOneCarrierPref> tfOneCarrierprefs = new ArrayList<>(1);
        TFOneCarrierPref tfOneCarrierpref;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierPref.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getNpaNxx2CarrierZonesprefQuerry(tracfoneOneCarrierPref));) {
            setNpaNxx2CarrierZonesprefQuerry(stmt, tracfoneOneCarrierPref);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneCarrierpref = new TFOneCarrierPref();
                    tfOneCarrierpref.setState(resultSet.getString("STATE"));
                    tfOneCarrierpref.setCounty(resultSet.getString(COUNTY));
                    tfOneCarrierpref.setCarrierId(resultSet.getString(CARRIER_ID));
                    tfOneCarrierprefs.add(tfOneCarrierpref);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneCarrierprefs;
    }

    private String getNpaNxx2CarrierZonesprefQuerry(TracfoneOneCarrierPref tracfoneOneCarrierPref) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_NPANXX_2_CARRIERZONES);
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getState())) {
            builder.append("STATE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCounty())) {
            builder.append(COUNTY_VALUE).append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCarrierId())) {
            builder.append(CARRIER_ID_VALUE).append(AND);
        }

        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        return searchQuery;
    }

    private void setNpaNxx2CarrierZonesprefQuerry(PreparedStatement stmt, TracfoneOneCarrierPref tracfoneOneCarrierPref) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getState())) {
            stmt.setString(index++, tracfoneOneCarrierPref.getState());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCounty())) {
            stmt.setString(index++, tracfoneOneCarrierPref.getCounty());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCarrierId())) {
            stmt.setString(index, tracfoneOneCarrierPref.getCarrierId());
        }
    }

    @Override
    public TFOneGeneralResponse deleteCarrierpref(TracfoneOneCarrierPref tracfoneOneCarrierPref, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierPref.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getCarrierprefStatement(tracfoneOneCarrierPref));) {
            setCarrierprefQuery(stmt, tracfoneOneCarrierPref);
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete carrierpref", "Deleted carrierpref" + tracfoneOneCarrierPref, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Deleted");
    }


    private String getCarrierprefStatement(TracfoneOneCarrierPref tracfoneOneCarrierPref) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_DELETE_CARRIERPREF);
        if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getState())) {
            builder.append(ST_IS_NULL).append(AND);
        } else {
            builder.append(ST_VALUE).append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCounty())) {
            builder.append(COUNTY_IS_NULL).append(AND);
        } else {
            builder.append(COUNTY_VALUE).append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCarrierId())) {
            builder.append(CARRIER_ID_IS_NULL).append(AND);
        } else {
            builder.append(CARRIER_ID_VALUE).append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCarrierName())) {
            builder.append(CARRIER_NAME_IS_NULL).append(AND);
        } else {
            builder.append(CARRIER_NAME_VALUE).append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getCarrierRank())) {
            builder.append(CARRIER_RANK_IS_NULL).append(AND);
        } else {
            builder.append(CARRIER_RANK_VALUE).append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getNewRank())) {
            builder.append(NEW_RANK_IS_NULL).append(AND);
        } else {
            builder.append(NEW_RANK_VALUE).append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }

        return searchQuery;
    }

    @Override
    public TFOneGeneralResponse updateCarrierpref(TracfoneOneCarrierPref tracfoneOneCarrierPref, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierPref.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getUpdateCarrierprefStatement(tracfoneOneCarrierPref));) {
            setUpdateCarrierpref(stmt, tracfoneOneCarrierPref);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Carrierzones", "Updated Carrierzones" + tracfoneOneCarrierPref, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, UPDATED);
    }

    private String getUpdateCarrierprefStatement(TracfoneOneCarrierPref tracfoneOneCarrierPref) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_UPDATE_CARRIERPREF);
        if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldState())) {
            builder.append(ST_IS_NULL).append(AND);
        } else {
            builder.append(ST_VALUE).append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldCounty())) {
            builder.append(COUNTY_IS_NULL).append(AND);
        } else {
            builder.append(COUNTY_VALUE).append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldCarrierId())) {
            builder.append(CARRIER_ID_IS_NULL).append(AND);
        } else {
            builder.append(CARRIER_ID_VALUE).append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldCarrierName())) {
            builder.append(CARRIER_NAME_IS_NULL).append(AND);
        } else {
            builder.append(CARRIER_NAME_VALUE).append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldCarrierRank())) {
            builder.append(CARRIER_RANK_IS_NULL).append(AND);
        } else {
            builder.append(CARRIER_RANK_VALUE).append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldNewRank())) {
            builder.append(NEW_RANK_IS_NULL).append(AND);
        } else {
            builder.append(NEW_RANK_VALUE).append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        return searchQuery;
    }

    private void setUpdateCarrierpref(PreparedStatement stmt, TracfoneOneCarrierPref tracfoneOneCarrierPref) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneCarrierPref.getState());
        stmt.setString(index++, tracfoneOneCarrierPref.getCounty());
        stmt.setString(index++, tracfoneOneCarrierPref.getCarrierId());
        stmt.setString(index++, tracfoneOneCarrierPref.getCarrierName());
        stmt.setString(index++, tracfoneOneCarrierPref.getCarrierRank());
        stmt.setString(index++, tracfoneOneCarrierPref.getNewRank());
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldState())) {
            stmt.setString(index++, tracfoneOneCarrierPref.getOldState());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldCounty())) {
            stmt.setString(index++, tracfoneOneCarrierPref.getOldCounty());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldCarrierId())) {
            stmt.setString(index++, tracfoneOneCarrierPref.getOldCarrierId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldCarrierName())) {
            stmt.setString(index++, tracfoneOneCarrierPref.getOldCarrierName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldCarrierRank())) {
            stmt.setString(index++, tracfoneOneCarrierPref.getOldCarrierRank());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldNewRank())) {
            stmt.setString(index, tracfoneOneCarrierPref.getOldNewRank());
        }
    }

    @Override
    public TFOneGeneralResponse bulkDeleteCarrierpref(TracfoneOneCarrierPref tracfoneOneCarrierPref, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierPref.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getCarrierprefStatement(tracfoneOneCarrierPref));) {
            setCarrierprefQuery(stmt, tracfoneOneCarrierPref);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Carrier Pref", "Deleted Carrier Pref Object " + tracfoneOneCarrierPref, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, String.valueOf(tracfoneOneCarrierPref.getCarrierId()));
    }

    @Override
    public TFOneGeneralResponse bulkUpdateCarrierpref(List<TracfoneOneCarrierPref> tracfoneOneCarrierPrefs, int userId) throws TracfoneOneException {
        String uniqueId = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierPrefs.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getBulkUpdateCarrierprefStatement(tracfoneOneCarrierPrefs));) {
            for (TracfoneOneCarrierPref tracfoneOneCarrierPref : tracfoneOneCarrierPrefs) {
                TracfoneOneCarrierPref searchCarrierPref = new TracfoneOneCarrierPref();
                searchCarrierPref.setDbEnv(tracfoneOneCarrierPref.getDbEnv());
                searchCarrierPref.setState(tracfoneOneCarrierPref.getState());
                searchCarrierPref.setCounty(tracfoneOneCarrierPref.getCounty());
                searchCarrierPref.setCarrierId(tracfoneOneCarrierPref.getCarrierId());
                searchCarrierPref.setCarrierName(tracfoneOneCarrierPref.getCarrierName());
                searchCarrierPref.setCarrierRank(tracfoneOneCarrierPref.getCarrierRank());
                searchCarrierPref.setNewRank(tracfoneOneCarrierPref.getNewRank());
                if (searchCarrierpref(searchCarrierPref).isEmpty()) {
                    setUpdateCarrierpref(stmt, tracfoneOneCarrierPref);
                    stmt.executeUpdate();
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Bulk Update Carrier pref", "Bulk Update  Carrier pref" + tracfoneOneCarrierPrefs, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, uniqueId);
    }
    private String getBulkUpdateCarrierprefStatement(List <TracfoneOneCarrierPref> tracfoneOneCarrierPrefs) {
        String searchQuery = "";
        for(TracfoneOneCarrierPref tracfoneOneCarrierPref : tracfoneOneCarrierPrefs){
            StringBuilder builder = new StringBuilder(TRACFONE_UPDATE_CARRIERPREF);
            if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldState())) {
                builder.append(ST_IS_NULL).append(AND);
            } else {
                builder.append(ST_VALUE).append(AND);
            }
            if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldCounty())) {
                builder.append(COUNTY_IS_NULL).append(AND);
            } else {
                builder.append(COUNTY_VALUE).append(AND);
            }
            if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldCarrierId())) {
                builder.append(CARRIER_ID_IS_NULL).append(AND);
            } else {
                builder.append(CARRIER_ID_VALUE).append(AND);
            }
            if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldCarrierName())) {
                builder.append(CARRIER_NAME_IS_NULL).append(AND);
            } else {
                builder.append(CARRIER_NAME_VALUE).append(AND);
            }
            if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldCarrierRank())) {
                builder.append(CARRIER_RANK_IS_NULL).append(AND);
            } else {
                builder.append(CARRIER_RANK_VALUE).append(AND);
            }
            if (StringUtils.isNullOrEmpty(tracfoneOneCarrierPref.getOldNewRank())) {
                builder.append(NEW_RANK_IS_NULL).append(AND);
            } else {
                builder.append(NEW_RANK_VALUE).append(AND);
            }
            if (builder.lastIndexOf(AND) != -1) {
                searchQuery = builder.substring(0, builder.lastIndexOf(AND));
            }
        }

        return searchQuery;
    }

    private String updateNpanxx2CarrierzonesStatement(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) {
        String updateQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_UPDATE_NPANXX_2_CARRIERZONES);
        if (StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getOldNpa())) {
            builder.append("NPA is null").append(AND);
        } else {
            builder.append("NPA = ?").append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getOldNxx())) {
            builder.append("NXX is null").append(AND);
        } else {
            builder.append(NXX_VALUE).append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getOldCarrierId())) {
            builder.append(CARRIER_ID_IS_NULL).append(AND);
        } else {
            builder.append(CARRIER_ID_VALUE).append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getOldZone())) {
            builder.append("ZONE is null").append(AND);
        } else {
            builder.append(ZONE_VALUE).append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getOldSid())) {
            builder.append("SID is null").append(AND);
        } else {
            builder.append("SID = ?").append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getOldState())) {
            builder.append("STATE is null").append(AND);
        } else {
            builder.append("STATE = ?").append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneNpanxx2Carrierzones.getOldRateCenter())) {
            builder.append("RATECENTER is null").append(AND);
        } else {
            builder.append("RATECENTER = ?").append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            updateQuery  = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Update Query npanxx2carrierzones is : " + updateQuery);

        return updateQuery;
    }

    @Override
    public TFOneGeneralResponse replaceNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNpanxx2Carrierzones.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_REPLACE_NPANXX_2_CARRIERZONES);) {
            replaceNpanxx2CarrierzonesParams(stmt, tracfoneOneNpanxx2Carrierzones);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Npanxx2Carrierzones", "Updated Npanxx2Carrierzones" + tracfoneOneNpanxx2Carrierzones, null);
            tracfoneAuditEvent.fire(audit);
        }
        LOGGER.info("Update querry" + TRACFONE_REPLACE_NPANXX_2_CARRIERZONES);
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, UPDATED);
    }

    private void replaceNpanxx2CarrierzonesParams(PreparedStatement stmt, TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCarrierName());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getNxx());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getNpa());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getZone());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getSid());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getState());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getRateCenter());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCarrierId());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getBtaMktName());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getBtaMktNumber());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCarrierIdDescription());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCdmaTech());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCounty());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getGsmTech());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getMnc());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getTdmaTech());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getMrktArea());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getTechnology());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getFrequency1());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getFrequency2());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getLeadTime());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getMarketId());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getTargetLevel());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getNpa());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getNxx());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getCarrierId());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getZone());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getSid());
        stmt.setString(index++, tracfoneOneNpanxx2Carrierzones.getState());
        stmt.setString(index, tracfoneOneNpanxx2Carrierzones.getRateCenter());
    }

}

