/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * TABLE: BUCKET_LIST
 *
 * @author Shireen Fathima
 */
public class TracfoneOneBucketList {

    private String dbEnv;
    @NotNull(message = "Bucket Id cannot be null")
    @Size(max = 30, message = "Bucket Id cannot have more than 30 characters")
    @Size(min = 1, message = "Bucket Id cannot be null")
    private String bucketId;
    @NotNull(message = "Bucket List Description cannot be null")
    @Size(max = 100, message = "Bucket List Description cannot have more than 100 characters")
    @Size(min = 1, message = "Bucket List Description cannot be null")
    private String description;
    @NotNull(message = "Active Flag cannot be null")
    @Size(max = 1, message = "Active Flag cannot have more than 1 character")
    @Size(min = 1, message = "Active Flag cannot be null")
    private String activeFlag;
    @NotNull(message = "Parent Short Name cannot be null")
    @Size(max = 6, message = "Parent Short Name cannot have more than 6 characters")
    @Size(min = 1, message = "Parent Short Name cannot be null")
    private String parentShortName;
    private boolean delete;
    private String profileId;
    private String servicePlanId;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getBucketId() {
        return bucketId;
    }

    public void setBucketId(String bucketId) {
        this.bucketId = bucketId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(String activeFlag) {
        this.activeFlag = activeFlag;
    }

    public String getParentShortName() {
        return parentShortName;
    }

    public void setParentShortName(String parentShortName) {
        this.parentShortName = parentShortName;
    }

    public boolean isDelete() {
        return delete;
    }

    public void setDelete(boolean delete) {
        this.delete = delete;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    @Override
    public String toString() {
        return "TracfoneOneBucketList{" + "bucketId=" + bucketId + ", "
                + "description=" + description + ", "
                + "activeFlag=" + activeFlag + ", "
                + "delete=" + delete + ", "
                + "parentShortName=" + parentShortName + '}';
    }


}
