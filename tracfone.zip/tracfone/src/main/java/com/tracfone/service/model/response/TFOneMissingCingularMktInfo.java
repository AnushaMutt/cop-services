package com.tracfone.service.model.response;

import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;

import java.util.List;

public class TFOneMissingCingularMktInfo {
    private List<TracfoneOneCingularMrktInfo> successRecords;
    private List<TracfoneOneCingularMrktInfo> failedRecords;

    public List<TracfoneOneCingularMrktInfo> getSuccessRecords() {
        return successRecords;
    }

    public void setSuccessRecords(List<TracfoneOneCingularMrktInfo> successRecords) {
        this.successRecords = successRecords;
    }

    public List<TracfoneOneCingularMrktInfo> getFailedRecords() {
        return failedRecords;
    }

    public void setFailedRecords(List<TracfoneOneCingularMrktInfo> failedRecords) {
        this.failedRecords = failedRecords;
    }

    @Override
    public String toString() {
        return "TFOneMissingCingularMktInfo{" +
                "successRecords=" + successRecords +
                ", failedRecords=" + failedRecords +
                '}';
    }
}
