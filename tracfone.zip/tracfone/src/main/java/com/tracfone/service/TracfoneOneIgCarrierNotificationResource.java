package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneOneIgCarrierNotficationControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import javax.ejb.EJB;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.tracfone.service.model.request.TracfoneOneIGCarrierNotification;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author Gaurav.Sharma
 */
@Path("igcarriernotification")
public class TracfoneOneIgCarrierNotificationResource {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneIgCarrierNotificationResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @EJB
    TracfoneOneIgCarrierNotficationControllerLocal carrierNotficationControllerLocal;

    /**
     * This method is used to get response from carrier API
     *
     * @param carrierNotification
     * @throws java.io.UnsupportedEncodingException
     * @return
     */
    @POST
    @Path("igcarrier/getcarriersresponse")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarriers(final TracfoneOneIGCarrierNotification carrierNotification) throws UnsupportedEncodingException {
        String carrierData = null;
        try {
            carrierData = carrierNotficationControllerLocal.getResponse(carrierNotification);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(carrierData).build();
    }
}
