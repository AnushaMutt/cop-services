package com.tracfone.service.model.response;

public class TFOneJobTask {
    private String objId;
    private String status;
    private String name;
    private String description;
    private String startRun;
    private String endRun;

    public TFOneJobTask() {
    }

    public TFOneJobTask(String objId, String status, String name, String description, String startRun, String endRun) {
        this.objId = objId;
        this.status = status;
        this.name = name;
        this.description = description;
        this.startRun = startRun;
        this.endRun = endRun;
    }

    @Override
    public String toString() {
        return "TFOneJobTask{" +
                "objId='" + objId + '\'' +
                ", status='" + status + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", startRun='" + startRun + '\'' +
                ", endRun='" + endRun + '\'' +
                '}';
    }
}
