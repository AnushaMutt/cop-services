/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.filter;

import com.tracfone.service.model.response.TFOneAdminUser;
import java.security.Principal;
import javax.ws.rs.core.SecurityContext;

/**
 *
 * @author druiz
 */
public class TracfoneOneSecurityContext implements SecurityContext{
    
    private final boolean secure;
    private final TFOneAdminUser tfUser;

    public TracfoneOneSecurityContext(TFOneAdminUser tfUser, boolean secure) {
        this.tfUser = tfUser;
        this.secure = secure;
    }

    @Override
    public TracfoneOnePrincipal getUserPrincipal() {
        return new TracfoneOnePrincipal(tfUser);
    }

    @Override
    public String getAuthenticationScheme() {
        return SecurityContext.BASIC_AUTH;
    }

    @Override
    public boolean isSecure() {
        return secure;
    }

    @Override
    public boolean isUserInRole(String role) {
        return true;
    }
 
    
}
