package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneCarrierMaintenanceControllerLocal;
import com.tracfone.service.controller.TracfoneOneDB2IntergateControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneDB2Intergate;
import com.tracfone.service.model.request.TracfoneOneIgOrderType;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneDB2Intergate;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIgOrderType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Gaurav.Sharma
 */
@Path("db2igupdate")
public class TracfoneOneDB2IntergateResource {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneDB2IntergateResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @EJB
    private TracfoneOneDB2IntergateControllerLocal db2IntergateController;

    @EJB
    private TracfoneCarrierMaintenanceControllerLocal tracfoneCarrierMaintenanceController;

    @Context
    private SecurityContext securityContext;

    /**
     * This method is used to view DB2 Intergate based on Search Criteria
     *
     * @param tracfoneOneDB2Intergate
     * @return
     */
    @POST
    @Path("db2igmaintenance/viewdb2ig")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response viewDB2Intergate(final TracfoneOneDB2Intergate tracfoneOneDB2Intergate) {
        List<TFOneDB2Intergate> viewData = new ArrayList<>();
        try {
            viewData = db2IntergateController.viewDB2Intergate(tracfoneOneDB2Intergate);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(viewData), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Order Types from X_IG_ORDER_TYPE
     *
     * @param tracfoneOneIgOrderType
     * @return
     */
    @POST
    @Path("db2igmaintenance/ordertypes")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getOrderTypes(TracfoneOneIgOrderType tracfoneOneIgOrderType) {
        List<TFOneIgOrderType> orderTypes = new ArrayList<>();
        try {
            orderTypes = tracfoneCarrierMaintenanceController.searchIgOrderTypes(tracfoneOneIgOrderType, true);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(orderTypes), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update DB2 Intergate
     *
     * @param tracfoneOneDB2Intergate
     * @return
     */
    @POST
    @Path("db2igmaintenance/updatedb2ig")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateDB2Intergate(final TracfoneOneDB2Intergate tracfoneOneDB2Intergate) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = db2IntergateController.updateDB2Intergate(tracfoneOneDB2Intergate, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves the user object making request from the principal.
     *
     * @return
     */
    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }
}
