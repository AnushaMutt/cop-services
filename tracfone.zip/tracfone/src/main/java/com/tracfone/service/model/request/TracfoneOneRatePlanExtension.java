/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * X_RP_EXTENSION
 * @author Pritesh Singh
 */
public class TracfoneOneRatePlanExtension {
    
    private String dbEnv;
    private String objId;
    @NotNull(message = "Line Status Code cannot be null")
    @Size(min=1, message = "Line Status Code cannot be blank")
    @Size(max=2, message = "Line Status Code cannot have more than 2 character")
    private String lineStatusCode;
    @NotNull(message = "Throttle Status Code cannot be null")
    @Size(min=1, message = "Throttle Status Code cannot be blank")
    @Size(max=2, message = "Throttle Status Code cannot have more than 2 character")
    private String throttleStatusCode;
    @NotNull(message = "Ancillary Code cannot be null")
    @Size(min=1, message = "Ancillary Code cannot be blank")
    @Size(max=5, message = "Ancillary Code cannot have more than 5 character")
    private String ancillaryCode;   

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getLineStatusCode() {
        return lineStatusCode;
    }

    public void setLineStatusCode(String lineStatusCode) {
        this.lineStatusCode = lineStatusCode;
    }

    public String getThrottleStatusCode() {
        return throttleStatusCode;
    }

    public void setThrottleStatusCode(String throttleStatusCode) {
        this.throttleStatusCode = throttleStatusCode;
    }

    public String getAncillaryCode() {
        return ancillaryCode;
    }

    public void setAncillaryCode(String ancillaryCode) {
        this.ancillaryCode = ancillaryCode;
    }

    @Override
    public String toString() {
        return "TracfoneOneRatePlanExtension{" + "dbEnv=" + dbEnv + ", "
                + "objId=" + objId + ", "
                + "lineStatusCode=" + lineStatusCode + ", "
                + "throttleStatusCode=" + throttleStatusCode + ", "
                + "ancillaryCode=" + ancillaryCode + '}';
    }
}
