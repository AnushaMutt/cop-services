package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneSearchCarrierFeatureModel;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchServicePlanModel;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneRatePlanExtensionLink;
import com.tracfone.service.model.response.TFOneServicePlanCarrierFeature;
import com.tracfone.service.util.ControllerUtil;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantPlanWizard;
import jersey.repackaged.com.google.common.collect.Lists;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Stateless
public class TracfoneServicePlanAction implements TracfoneServicePlanLocalAction, TracfoneOneConstantPlanWizard, TracfoneOneConstant {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneServicePlanAction.class);

    private static final String AND = " AND ";

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @EJB
    private DataBaseController dbControllerEJB;

    @Override
    public List<TFOneCarrierServicePlan> searchServicePlans(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> servicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneServicePlan;
        String queryToGetCarrierFeatureObjIds = getSearchStatementForProfileAndFeature(tfServicePlanModel);
        try (Connection con = dbControllerEJB.getDataSource(tfServicePlanModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchStatementForServicePlan(tfServicePlanModel, queryToGetCarrierFeatureObjIds));) {
            setSearchSPParameters(tfServicePlanModel, stmt);

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneServicePlan = setServicePlan(resultSet);
                    if (!tfServicePlanModel.isLegacy()) {
                        tfOneServicePlan.setServicePlanPurchase(resultSet.getString("service_plan_purchase"));
                    }
                    servicePlans.add(tfOneServicePlan);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return servicePlans;
    }

    private String getSearchStatementForProfileAndFeature(TracfoneOneSearchServicePlanModel tfServicePlanModel) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_GET_CARRIER_FEATURE_OBJID_FOR_SERVICE_PLAN);
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureName())) {
            builder.append("ec.feature_name = ? ");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureRequirement())) {
            builder.append("ec.feature_requirement = ? ");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getProfileId())) {
            builder.append("p.profile_id = ? ");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getProfileDesc())) {
            builder.append("UPPER(p.profile_desc) LIKE ?");
            builder.append(AND);
        }

        if (builder.lastIndexOf(AND) != -1) {
            if (tfServicePlanModel.isLegacy()) {
                searchQuery = builder.substring(0, builder.lastIndexOf(AND)).concat(") order by mtm.X_SERVICE_PLAN_ID");
            } else {
                searchQuery = builder.substring(0, builder.lastIndexOf(AND)).concat(") order by spmv.service_plan_objid");
            }
        }
        LOGGER.info("Search Query to get Carrier Feature Obj Ids : " + searchQuery);
        return searchQuery;
    }

    private String getSearchStatementForServicePlan(TracfoneOneSearchServicePlanModel tfServicePlanModel, String queryToGetCarrierFeatureObjIds) {
        String query = null;
        String searchQuery = TRACFONE_SEARCH_SERVICE_PLANS;
        if (tfServicePlanModel.isLegacy()) {
            searchQuery = TRACFONE_SEARCH_LEGACY_SERVICE_PLANS;
        }
        StringBuilder builder = new StringBuilder(searchQuery);
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getCarrierName())) {
            builder.append("cg.x_carrier_name = ? AND ");
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getServicePlanId())) {
            if (tfServicePlanModel.isLegacy()) {
                builder.append("mtm.X_SERVICE_PLAN_ID = ?");
            } else {
                builder.append("spmv.service_plan_objid = ?");
            }
            builder.append(AND);
        }
        if (!tfServicePlanModel.getBrands().isEmpty()) {
            LOGGER.info("Total number of brands is : " + tfServicePlanModel.getBrands().size());
            buildInClause(builder.append("cf.X_FEATURES2BUS_ORG in ("), tfServicePlanModel.getBrands().size());
            builder.append(AND);
        }
        if (!tfServicePlanModel.getRatePlans().isEmpty()) {
            LOGGER.info("Total number of rate plan is : " + tfServicePlanModel.getRatePlans().size());
            buildInClause(builder.append("cf.x_rate_plan in ("), tfServicePlanModel.getRatePlans().size());
            builder.append(AND);
        }
        if (tfServicePlanModel.isLegacy()) {
            if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId()) && !StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
                builder.append("(mtm.X_SERVICE_PLAN_ID in (select service_plan_id from sa.carrier_profile_buckets where bucket_id = ? and bucket_requirement = ?) or " +
                        "mtm.X_SERVICE_PLAN_ID in (select service_plan_id from sa.carrier_profile_child_buckets where bucket_id = ? and bucket_requirement = ?)) ");
                builder.append(AND);
            } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId())) {
                builder.append("(mtm.X_SERVICE_PLAN_ID in (select service_plan_id from sa.carrier_profile_buckets where bucket_id = ?) or " +
                        "mtm.X_SERVICE_PLAN_ID in (select service_plan_id from sa.carrier_profile_child_buckets where bucket_id = ?)) ");
                builder.append(AND);
            } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
                builder.append("(mtm.X_SERVICE_PLAN_ID in (select service_plan_id from sa.carrier_profile_buckets where bucket_requirement = ?) or " +
                        "mtm.X_SERVICE_PLAN_ID in (select service_plan_id from sa.carrier_profile_child_buckets where bucket_requirement = ?)) ");
                builder.append(AND);
            }
        } else {
            if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId()) && !StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
                builder.append("(spmv.service_plan_objid in (select service_plan_id from sa.carrier_profile_buckets where bucket_id = ? and bucket_requirement = ?) or " +
                        "spmv.service_plan_objid in (select service_plan_id from sa.carrier_profile_child_buckets where bucket_id = ? and bucket_requirement = ?)) ");
                builder.append(AND);
            } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId())) {
                builder.append("(spmv.service_plan_objid in (select service_plan_id from sa.carrier_profile_buckets where bucket_id = ?) or " +
                        "spmv.service_plan_objid in (select service_plan_id from sa.carrier_profile_child_buckets where bucket_id = ?)) ");
                builder.append(AND);
            } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
                builder.append("(spmv.service_plan_objid in (select service_plan_id from sa.carrier_profile_buckets where bucket_requirement = ?) or " +
                        "spmv.service_plan_objid in (select service_plan_id from sa.carrier_profile_child_buckets where bucket_requirement = ?)) ");
                builder.append(AND);
            }
        }

        if (!StringUtils.isNullOrEmpty(queryToGetCarrierFeatureObjIds)) {
            query = builder.append(queryToGetCarrierFeatureObjIds).toString();
        } else {
            if (tfServicePlanModel.isLegacy()) {
                query = builder.substring(0, builder.lastIndexOf(AND)).concat(" order by mtm.X_SERVICE_PLAN_ID");
            } else {
                query = builder.substring(0, builder.lastIndexOf(AND)).concat(" order by spmv.service_plan_objid");
            }
        }
        LOGGER.info("Search Service Plan Query is " + query);
        return query;
    }

    private void buildInClause(StringBuilder builder, long size) {
        int index = 1;
        while (index <= size) {
            builder.append("?,");
            index++;
        }
        builder.deleteCharAt(builder.length() - 1);
        builder.append(")");
    }

    private void setSearchSPParameters(TracfoneOneSearchServicePlanModel tfServicePlanModel, PreparedStatement stmt) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getCarrierName())) {
            stmt.setString(index++, tfServicePlanModel.getCarrierName());
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getServicePlanId())) {
            stmt.setString(index++, tfServicePlanModel.getServicePlanId());
        }
        if (tfServicePlanModel.getBrands() != null) {
            for (String brand : tfServicePlanModel.getBrands()) {
                stmt.setString(index++, brand);
            }
        }
        if (tfServicePlanModel.getRatePlans() != null) {
            for (String ratePlan : tfServicePlanModel.getRatePlans()) {
                stmt.setString(index++, ratePlan);
            }
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId()) && !StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
            stmt.setString(index++, tfServicePlanModel.getBucketId());
            stmt.setString(index++, tfServicePlanModel.getBucketRequirement());
            stmt.setString(index++, tfServicePlanModel.getBucketId());
            stmt.setString(index++, tfServicePlanModel.getBucketRequirement());
        } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId())) {
            stmt.setString(index++, tfServicePlanModel.getBucketId());
            stmt.setString(index++, tfServicePlanModel.getBucketId());
        } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
            stmt.setString(index++, tfServicePlanModel.getBucketRequirement());
            stmt.setString(index++, tfServicePlanModel.getBucketRequirement());
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureName())) {
            stmt.setString(index++, tfServicePlanModel.getFeatureName());
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureRequirement())) {
            stmt.setString(index++, tfServicePlanModel.getFeatureRequirement());
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getProfileId())) {
            stmt.setString(index++, tfServicePlanModel.getProfileId());
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getProfileDesc())) {
            stmt.setString(index, "%" + tfServicePlanModel.getProfileDesc().toUpperCase() + "%");
        }
    }

    private TFOneCarrierServicePlan setServicePlan(ResultSet resultSet) throws SQLException {
        TFOneCarrierServicePlan tfOneServicePlanView = new TFOneCarrierServicePlan();
        tfOneServicePlanView.setServicePlanId(resultSet.getString(OBJID));
        tfOneServicePlanView.setCarrierName(resultSet.getString("x_carrier_name"));
        tfOneServicePlanView.setParentName(resultSet.getString("x_parent_name"));
        tfOneServicePlanView.setDescription(resultSet.getString("description"));
        return tfOneServicePlanView;
    }

    @Override
    public List<TFOneCarrierFeature> viewServicePlanCarrierFeatures(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        List<String> columnNames = tfServicePlanModel.getCarrierFeatureColumns();
        try (Connection con = dbControllerEJB.getDataSource(tfServicePlanModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getViewSPCarrierFeaturesStatement(tfServicePlanModel));) {
            setSPCarrierFeaturesStatement(stmt, tfServicePlanModel);

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    TFOneCarrierFeature tfOneCarrierFeature = new TFOneCarrierFeature();
                    tfOneCarrierFeature.setObjId(resultSet.getString(OBJID));
                    for (String columnName : columnNames) {
                        setCFColumnValue(tfOneCarrierFeature, columnName, resultSet.getString(columnName));
                    }
                    carrierFeatures.add(tfOneCarrierFeature);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException ex) {
            LOGGER.error(TRACFONE_GET_CARRIER_FEATURES_ERROR_MESSAGE, ex);
            throw new TracfoneOneException(TRACFONE_GET_CARRIER_FEATURES_ERROR,
                    TRACFONE_GET_CARRIER_FEATURES_ERROR_MESSAGE, ex);
        }
        return carrierFeatures;
    }

    private void setSPCarrierFeaturesStatement(PreparedStatement stmt, TracfoneOneSearchServicePlanModel tfServicePlanModel) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getCarrierName())) {
            stmt.setString(index++, tfServicePlanModel.getCarrierName());
            if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getServicePlanId())) {
                stmt.setString(index++, tfServicePlanModel.getServicePlanId());
            }
        } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getServicePlanId())) {
            stmt.setString(index++, tfServicePlanModel.getServicePlanId());
        }
        if (!tfServicePlanModel.getRatePlans().isEmpty()) {
            for (String ratePlanName : tfServicePlanModel.getRatePlans()) {
                stmt.setString(index++, ratePlanName);
            }
        }
        if (!tfServicePlanModel.getBrands().isEmpty()) {
            for (String brand : tfServicePlanModel.getBrands()) {
                stmt.setString(index++, brand);
            }
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId()) && !StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
            stmt.setString(index++, tfServicePlanModel.getBucketId());
            stmt.setString(index++, tfServicePlanModel.getBucketRequirement());
            stmt.setString(index++, tfServicePlanModel.getBucketId());
            stmt.setString(index++, tfServicePlanModel.getBucketRequirement());
        } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId())) {
            stmt.setString(index++, tfServicePlanModel.getBucketId());
            stmt.setString(index++, tfServicePlanModel.getBucketId());
        } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
            stmt.setString(index++, tfServicePlanModel.getBucketRequirement());
            stmt.setString(index++, tfServicePlanModel.getBucketRequirement());
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureName())) {
            stmt.setString(index++, tfServicePlanModel.getFeatureName());
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureRequirement())) {
            stmt.setString(index++, tfServicePlanModel.getFeatureRequirement());
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getProfileId())) {
            stmt.setString(index++, tfServicePlanModel.getProfileId());
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getProfileDesc())) {
            stmt.setString(index, "%" + tfServicePlanModel.getProfileDesc().toUpperCase() + "%");
        }
    }

    @Override
    public List<TFOneCarrierServicePlan> getAllServicePlans(String dbEnv) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> tfOneCarrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneCarrierServicePlan;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_SERVICEPLANS);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                tfOneCarrierServicePlan = new TFOneCarrierServicePlan();
                tfOneCarrierServicePlan.setServicePlanId(resultSet.getString(OBJID));
                tfOneCarrierServicePlan.setMktName(resultSet.getString("mkt_name"));
                tfOneCarrierServicePlans.add(tfOneCarrierServicePlan);
            }

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfOneCarrierServicePlans;
    }

    @Override
    public List<TFOneCarrierFeature> getCarrierFeatureLinks(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        TFOneCarrierFeature tfOneCarrierFeature;
        List<TFOneRatePlanExtensionLink> links;
        TFOneRatePlanExtensionLink tfOneRatePlanExtensionLink;
        String query = getCarrierFeatureLinksQuery(tfServicePlanModel);
        try (Connection con = dbControllerEJB.getDataSource(tfServicePlanModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(query);) {

            List<TracfoneOneCarrierFeature> selectedCarrierFeatures = tfServicePlanModel.getSelectedCarrierFeatures();
            for (TracfoneOneCarrierFeature cf : selectedCarrierFeatures) {
                stmt.setLong(1, Long.valueOf(cf.getObjId()));
                setCarrierFeatureLinksStatement(stmt, tfServicePlanModel);
                try (ResultSet resultSet = stmt.executeQuery();) {
                    links = new ArrayList<>();
                    tfOneCarrierFeature = new TFOneCarrierFeature();
                    tfOneCarrierFeature.setObjId(cf.getObjId());

                    while (resultSet.next()) {
                        tfOneRatePlanExtensionLink = new TFOneRatePlanExtensionLink();
                        tfOneRatePlanExtensionLink.setObjId(resultSet.getString(OBJID));
                        tfOneRatePlanExtensionLink.setChildPlanId(resultSet.getString("CHILD_PLAN_ID"));
                        tfOneRatePlanExtensionLink.setChildPlanDescription(resultSet.getString("CHILD_DESCRIPTION"));
                        tfOneRatePlanExtensionLink.setProfileId(resultSet.getString("PROFILE_ID"));
                        tfOneRatePlanExtensionLink.setProfileDescription(resultSet.getString("PROFILE_DESC"));
                        tfOneRatePlanExtensionLink.setRatePlanExtensionId(resultSet.getString("RP_EXTENSION_OBJID"));
                        tfOneRatePlanExtensionLink.setLineStatusCode(resultSet.getString("LINE_STATUS_CODE"));
                        tfOneRatePlanExtensionLink.setThrottleStatusCode(resultSet.getString("THROTTLE_STATUS_CODE"));
                        tfOneRatePlanExtensionLink.setAncillaryCode(resultSet.getString("ANCILLARY_CODE"));
                        links.add(tfOneRatePlanExtensionLink);
                    }
                    tfOneCarrierFeature.setRpExtensionLinks(links);
                    carrierFeatures.add(tfOneCarrierFeature);
                } catch (SQLException ex) {
                    LOGGER.error("Unable to get RP Extension Linsk for " + cf.getObjId(), ex);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return carrierFeatures;
    }

    @Override
    public List<String> getAllServicePlanCarrierNames(String dbEnv, String servicePlanId, boolean isLegacy) throws TracfoneOneException {
        List<String> carrierNames = new ArrayList<>();
        String query = TRACFONE_GET_ALL_SERVICE_PLAN_CARRIERS;
        if (isLegacy) {
            query = TRACFONE_GET_ALL_LEGACY_SERVICE_PLAN_CARRIERS;
        }
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setString(1, servicePlanId);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    carrierNames.add(resultSet.getString("x_carrier_name"));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return carrierNames;
    }

    @Override
    public List<TFOneCarrierServicePlan> getServicePlansForCopy(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> tfOneCarrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneCarrierServicePlan;
        String query = TRACFONE_GET_ALL_SERVICE_PLANS_FOR_COPY;
        if (tracfoneOneSearchPlanModel.isLegacy()) {
            query = TRACFONE_GET_ALL_LEGACY_SERVICE_PLANS_FOR_COPY;
        }
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneSearchPlanModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setString(1, tracfoneOneSearchPlanModel.getCarrierName());
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneCarrierServicePlan = new TFOneCarrierServicePlan();
                    tfOneCarrierServicePlan.setServicePlanId(resultSet.getString(OBJID));
                    tfOneCarrierServicePlan.setMktName(resultSet.getString("mkt_name"));
                    tfOneCarrierServicePlans.add(tfOneCarrierServicePlan);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneCarrierServicePlans;
    }

    private void setCarrierFeatureLinksStatement(PreparedStatement stmt, TracfoneOneSearchServicePlanModel tfServicePlanModel) throws SQLException {
        int index = 2;
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getProfileId())) {
            stmt.setString(index++, tfServicePlanModel.getProfileId());
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getProfileDesc())) {
            stmt.setString(index++, "%" + tfServicePlanModel.getProfileDesc().toUpperCase() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureName())) {
            stmt.setString(index++, tfServicePlanModel.getFeatureName());
            if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureRequirement())) {
                stmt.setString(index++, tfServicePlanModel.getFeatureRequirement());
            }
        } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureRequirement())) {
            stmt.setString(index++, tfServicePlanModel.getFeatureRequirement());
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId())) {
            if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
                stmt.setString(index++, tfServicePlanModel.getBucketId());
                stmt.setString(index++, tfServicePlanModel.getBucketRequirement());
                stmt.setString(index++, tfServicePlanModel.getBucketId());
                stmt.setString(index++, tfServicePlanModel.getBucketRequirement());
            } else {
                stmt.setString(index++, tfServicePlanModel.getBucketId());
                stmt.setString(index++, tfServicePlanModel.getBucketId());
            }
        } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
            stmt.setString(index++, tfServicePlanModel.getBucketRequirement());
            stmt.setString(index++, tfServicePlanModel.getBucketRequirement());
        }
    }

    public String getCarrierFeatureLinksQuery(TracfoneOneSearchServicePlanModel tfServicePlanModel) {
        String query = "";
        StringBuilder builder = new StringBuilder(TRACFONE_VIEW_RP_EXTENSION_LINK_FOR_CF);
        builder.append(AND);
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getProfileId())) {
            builder.append("el.profile_id = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getProfileDesc())) {
            builder.append("p.profile_desc like ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureName())) {
            builder.append("el.PROFILE_ID in (select profile_id from sa.x_rp_extension_config where feature_name = ?)");
            if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureRequirement())) {
                builder.deleteCharAt(builder.length() - 1);
                builder.append(AND);
                builder.append("feature_requirement = ?)");
            }
            builder.append(AND);
        } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureRequirement())) {
            builder.append("el.PROFILE_ID in (select profile_id from sa.x_rp_extension_config where feature_requirement = ?)");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId())) {
            if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
                builder.append("(el.PROFILE_ID in (select profile_id from sa.carrier_profile_buckets where bucket_id = ? and bucket_requirement = ?) " +
                        "or el.PROFILE_ID in (select profile_id from sa.carrier_profile_child_buckets where bucket_id = ? and bucket_requirement = ?))");
            } else {
                builder.append("(el.PROFILE_ID in (select profile_id from sa.carrier_profile_buckets where bucket_id = ?) " +
                        "or el.PROFILE_ID in (select profile_id from sa.carrier_profile_child_buckets where bucket_id = ?))");
            }
            builder.append(AND);
        } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
            builder.append("(el.PROFILE_ID in (select profile_id from sa.carrier_profile_buckets where bucket_requirement = ?) " +
                    "or el.PROFILE_ID in (select profile_id from sa.carrier_profile_child_buckets where bucket_requirement = ?))");
            builder.append(AND);
        }

        if (builder.lastIndexOf(AND) != -1) {
            query = builder.substring(0, builder.lastIndexOf(AND)).concat(" order by el.RP_EXTENSION_OBJID");
        } else {
            query = builder.append(" order by el.RP_EXTENSION_OBJID").toString();
        }
        return query;
    }

    private void setCFColumnValue(TFOneCarrierFeature tfOneCarrierFeature, String columnName, String columnValue) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        if (PRIORITY.equalsIgnoreCase(columnName)) {
            TFOneServicePlanCarrierFeature servicePlanCarrierFeature = new TFOneServicePlanCarrierFeature();
            servicePlanCarrierFeature.setPriority(columnValue);
            tfOneCarrierFeature.setServicePlanCarrierFeature(servicePlanCarrierFeature);
        } else {
            Method m = tfOneCarrierFeature.getClass().getMethod(ControllerUtil.getCarrierFeatureSetter(columnName), String.class);
            Object element = m.invoke(tfOneCarrierFeature, columnValue);
            LOGGER.info("element " + element);
        }
    }

    private String getViewSPCarrierFeaturesStatement(TracfoneOneSearchServicePlanModel tfServicePlanModel) {
        String query = "";
        StringBuilder builder = new StringBuilder();
        boolean hasPriority = false;
        boolean hasBrand = false;
        // Handling priority coming from different table
        if (tfServicePlanModel.getCarrierFeatureColumns().contains(PRIORITY)) {
            builder.append("SELECT DISTINCT MTM.PRIORITY, CF.");
            tfServicePlanModel.getCarrierFeatureColumns().remove(PRIORITY);
            hasPriority = true;
        } else {
            builder.append("SELECT DISTINCT CF.");
        }
        // Handling Brand to give the value and not just the id
        if (tfServicePlanModel.getCarrierFeatureColumns().contains(X_FEATURES2BUS_ORG)) {
            query = ", (select org_id from sa.table_bus_org bo where bo.objid = cf.X_FEATURES2BUS_ORG) X_FEATURES2BUS_ORG";
            tfServicePlanModel.getCarrierFeatureColumns().remove(X_FEATURES2BUS_ORG);
            hasBrand = true;
        }
        tfServicePlanModel.getCarrierFeatureColumns().add(OBJID);
        builder.append(String.join(", CF.", tfServicePlanModel.getCarrierFeatureColumns()));
        // Adding these back so that we can pick them up from search results
        if (hasBrand) {
            builder.append(query);
            tfServicePlanModel.getCarrierFeatureColumns().add(X_FEATURES2BUS_ORG);
        }
        if (hasPriority) {
            tfServicePlanModel.getCarrierFeatureColumns().add(PRIORITY);
        }

        builder.append(" from sa.table_x_carrier_features cf, ");
        if (tfServicePlanModel.isLegacy()) {
            builder.append("sa.mtm_sp_carrierfeatures_dflt mtm ");
        } else {
            builder.append("sa.mtm_sp_carrierfeatures mtm ");
        }
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getCarrierName())) {
            builder.append(", sa.table_x_carrier c, sa.table_x_carrier_group cg ");
            builder.append("where cf.objid = mtm.x_carrier_features_id and ");
            builder.append("cf.x_feature2x_carrier = c.objid and ");
            builder.append("c.carrier2carrier_group = cg.objid and ");
            builder.append("cg.x_carrier_name = ?");
            builder.append(AND);
            if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getServicePlanId())) {
                builder.append("mtm.x_service_plan_id = ?");
                builder.append(AND);
            }
        } else {
            builder.append(" where cf.objid = mtm.x_carrier_features_id");
            builder.append(AND);
            if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getServicePlanId())) {
                builder.append("mtm.x_service_plan_id = ?");
                builder.append(AND);
            }
        }

        if (!tfServicePlanModel.getRatePlans().isEmpty()) {
            buildInClause(builder.append("cf.x_rate_plan in ("), tfServicePlanModel.getRatePlans().size());
            builder.append(AND);
        }
        if (!tfServicePlanModel.getBrands().isEmpty()) {
            buildInClause(builder.append("cf.X_FEATURES2BUS_ORG in ("), tfServicePlanModel.getBrands().size());
            builder.append(AND);
        }

        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId()) && !StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
            builder.append("(mtm.x_service_plan_id in (select service_plan_id from sa.carrier_profile_buckets where bucket_id = ? and bucket_requirement = ?) or " +
                    "mtm.x_service_plan_id in (select service_plan_id from sa.carrier_profile_child_buckets where bucket_id = ? and bucket_requirement = ?)) ");
            builder.append(AND);
        } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId())) {
            builder.append("(mtm.x_service_plan_id in (select service_plan_id from sa.carrier_profile_buckets where bucket_id = ?) or " +
                    "mtm.x_service_plan_id in (select service_plan_id from sa.carrier_profile_child_buckets where bucket_id = ?)) ");
            builder.append(AND);
        } else if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
            builder.append("(mtm.x_service_plan_id in (select service_plan_id from sa.carrier_profile_buckets where bucket_requirement = ?) or " +
                    "mtm.x_service_plan_id in (select service_plan_id from sa.carrier_profile_child_buckets where bucket_requirement = ?)) ");
            builder.append(AND);
        }

        String queryToGetCarrierFeatureObjIds = getSearchStatementForProfileAndFeature(tfServicePlanModel);
        if (!StringUtils.isNullOrEmpty(queryToGetCarrierFeatureObjIds)) {
            builder.append(queryToGetCarrierFeatureObjIds);
            query = builder.substring(0, builder.lastIndexOf(")") + 1);
        } else {
            query = builder.substring(0, builder.lastIndexOf(AND));
        }

        LOGGER.info("Query to retrieve all carrier features for a SP is " + query);
        return query;
    }

    @Override
    public int countBucketsByLinkObjId(String dbEnv, Set<String> profileIds, String servicePlanId) throws TracfoneOneException {
        int count = 0;
        LOGGER.info("How many link objids? " + profileIds);
        StringBuilder builder = new StringBuilder(TRACFONE_COUNT_BUCKETS_BY_LINK_OBJID);
        for (int i = 1; i < profileIds.size(); i++) {
            builder.append(", ?");
        }
        builder.append("))");
        LOGGER.info("query for counting buckets - " + builder.toString());
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(builder.toString());) {
            int index = 1;
            stmt.setString(index++, servicePlanId);
            for (String profileId : profileIds) {
                stmt.setString(index++, profileId);
            }
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    count = resultSet.getInt(1);
                    LOGGER.info("How many buckets have been found? " + count);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return count;
    }

    @Override
    public int countChildBucketsByLinkObjId(String dbEnv, Set<String> profileIds, String servicePlanId) throws TracfoneOneException {
        int count = 0;
        LOGGER.info("How many link objids? " + profileIds);
        StringBuilder builder = new StringBuilder(TRACFONE_COUNT_CHILD_BUCKETS_BY_LINK_OBJID);
        for (int i = 1; i < profileIds.size(); i++) {
            builder.append(", ?");
        }
        builder.append("))");
        LOGGER.info("query for counting child buckets - " + builder.toString());
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(builder.toString());) {
            int index = 1;
            stmt.setString(index++, servicePlanId);
            for (String profileId : profileIds) {
                stmt.setString(index++, profileId);
            }
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    count = resultSet.getInt(1);
                    LOGGER.info("How many child buckets have been found? " + count);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return count;
    }

    @Override
    public void deleteDummyCarrierFeature(String dbEnv, String toServicePlanId, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DUMMY_LEGACY_PLANS_FROM_MTM);) {
            stmt.setString(1, toServicePlanId);
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Dummy Carrier Feature",
                    "Deleted Dummy Carrier Feature Object for Service Plan Id " + toServicePlanId, null);
            tracfoneAuditEvent.fire(audit);
        }
    }

    @Override
    public int countCarrierFeatures(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws TracfoneOneException {
        int count = 0;
        LOGGER.info("service plan id is " + tfCarrierFeatureModel);
        String query = TRACFONE_COUNT_CARRIER_FEATURE;
        if (tfCarrierFeatureModel.isLegacy()) {
            query = TRACFONE_COUNT_LEGACY_CARRIER_FEATURE;
        }
        try (Connection con = dbControllerEJB.getDataSource(tfCarrierFeatureModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setString(1, tfCarrierFeatureModel.getCarrierName());
            stmt.setString(2, tfCarrierFeatureModel.getServicePlanId());

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    count = resultSet.getInt(1);
                    LOGGER.info("How many carrier features have been found? " + count);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return count;
    }

    @Override
    public List<TFOneCarrierServicePlan> getAllLegacyPaygoPlans(String dbEnv, String carrierName) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> tfOneCarrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneCarrierServicePlan;
        String query = TRACFONE_GET_ALL_LEGACY_PAYGO_PLANS;
        if (!StringUtils.isNullOrEmpty(carrierName)) {
            query = TRACFONE_GET_LEGACY_PLANS_BY_CARRIER;
        }

        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(query);) {
            if (!StringUtils.isNullOrEmpty(carrierName)) {
                stmt.setString(1, carrierName);
            }
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneCarrierServicePlan = new TFOneCarrierServicePlan();
                    tfOneCarrierServicePlan.setServicePlanId(resultSet.getString("X_SERVICE_PLAN_ID"));
                    tfOneCarrierServicePlan.setMktName(tfOneCarrierServicePlan.getServicePlanId());
                    tfOneCarrierServicePlans.add(tfOneCarrierServicePlan);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfOneCarrierServicePlans;
    }

    @Override
    public int getMspBucketCount(String query, TracfoneOneSearchPlanModel searchPlanModel, List<String> profileIds) throws TracfoneOneException {
        int count = 0;
        StringBuilder countQuery = new StringBuilder(query);
        buildInClause(countQuery, profileIds.size());
        try (Connection con = dbControllerEJB.getDataSource(searchPlanModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(countQuery.toString());) {
            int index = 1;
            stmt.setString(index++, searchPlanModel.getServicePlanId());
            for (String profileId : profileIds) {
                stmt.setString(index++, profileId);
            }

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    count = resultSet.getInt(1);
                    LOGGER.info("Result for " + query + " is " + count);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return count;
    }

    @Override
    public List<String> getMspProfileCount(TracfoneOneSearchPlanModel searchPlanModel) throws TracfoneOneException {
        List<String> profileIds = new ArrayList<>();
        StringBuilder query = new StringBuilder(TRACFONE_COUNT_LINKS_BY_SP);
        if (!searchPlanModel.getRemovedCarrierFeatures().isEmpty()) {
            if (searchPlanModel.getRemovedCarrierFeatures().size() < 1000) {
                query.append(" and x_carrier_features_id not in (");
                buildInClause(query, searchPlanModel.getRemovedCarrierFeatures().size());
            } else {
                List<List<String>> splitIds = Lists.partition(searchPlanModel.getRemovedCarrierFeatures(), 1000);
                StringBuilder tempBuilder;
                for (List<String> carrierFeatureIds : splitIds) {
                    tempBuilder = new StringBuilder(" and x_carrier_features_id not in (");
                    buildInClause(tempBuilder, carrierFeatureIds.size());
                    query.append(tempBuilder);
                }
            }
        }
        query.append(")");
        LOGGER.info("Query is " + query);
        try (Connection con = dbControllerEJB.getDataSource(searchPlanModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(query.toString());) {
            int index = 1;
            stmt.setString(index++, searchPlanModel.getCarrierName());
            stmt.setString(index++, searchPlanModel.getServicePlanId());
            for (String carrierFeature : searchPlanModel.getRemovedCarrierFeatures()) {
                stmt.setString(index++, carrierFeature);
            }

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    profileIds.add(resultSet.getString("profile_id"));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        LOGGER.info("Number of profiles found is " + profileIds.size());
        LOGGER.info("Result for " + query + " is " + profileIds);
        return profileIds;
    }

}
