package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneBPTech;
import com.tracfone.service.model.request.TracfoneOneZip2Tech;
import com.tracfone.service.model.response.TFOneBPTech;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneZip2Tech;
import com.tracfone.service.util.TracfoneOneConstantZip2Tech;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import java.security.SecureRandom;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;

@Stateless
public class TracfoneOneZip2TechController implements TracfoneOneZip2TechControllerLocal, TracfoneOneConstantZip2Tech {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneZip2TechController.class);

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @EJB
    private TracfoneOneZip2TechActionLocal tracfoneOneZip2TechAction;

    @Override
    public List<TFOneZip2Tech> searchZip2Tech(TracfoneOneZip2Tech tfZip2Tech) throws TracfoneOneException {
        List<TFOneZip2Tech> zip2Techs = null;
        try {
            zip2Techs = tracfoneOneZip2TechAction.searchZip2Tech(tfZip2Tech);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_ZIP2TECH_ERROR, TRACFONE_SEARCH_ZIP2TECH_ERROR_MESSAGE, ex);
        }

        return zip2Techs;
    }

    @Override
    public List<String> getZip2TechColumnValues(String columnName, String dbEnv) throws TracfoneOneException {
        List<String> columnValue = null;
        try {
            columnValue = tracfoneOneZip2TechAction.getZip2TechColumnValues(columnName, dbEnv);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ZIP2TECH_COLUMN_ERROR,
                    TRACFONE_GET_ZIP2TECH_COLUMN_ERROR_MESSAGE.concat(columnName.toLowerCase()), ex);
        }
        return columnValue;
    }

    @Override
    public TFOneGeneralResponse insertZip2Tech(TracfoneOneZip2Tech tfZip2Tech, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneOneZip2TechAction.insertZip2Tech(tfZip2Tech, userId, null);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_ZIP2TECH_ERROR, TRACFONE_ADD_ZIP2TECH_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse updateZip2Techs(List<TracfoneOneZip2Tech> tfZip2Techs, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneOneZip2TechAction.updateZip2Techs(tfZip2Techs, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_ZIP2TECH_ERROR, TRACFONE_UPDATE_ZIP2TECH_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<TFOneBPTech> searchBPTech(TracfoneOneBPTech tfBPTech) throws TracfoneOneException {
        List<TFOneBPTech> bpTechs = null;
        try {
            bpTechs = tracfoneOneZip2TechAction.searchBPTech(tfBPTech);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_BPTECH_ERROR, TRACFONE_SEARCH_BPTECH_ERROR_MESSAGE, ex);
        }

        return bpTechs;
    }

    @Override
    public List<String> getBPTechColumn(String columnName, String dbEnv) throws TracfoneOneException {
        List<String> columnValue = null;
        try {
            columnValue = tracfoneOneZip2TechAction.getBPTechColumn(columnName, dbEnv);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_BPTECH_COLUMN_ERROR,
                    TRACFONE_GET_BPTECH_COLUMN_ERROR_MESSAGE.concat(columnName.toLowerCase()), ex);
        }
        return columnValue;
    }

    @Override
    public TFOneGeneralResponse updateBPTechs(List<TracfoneOneBPTech> tfBPTechs, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneOneZip2TechAction.updateBPTechs(tfBPTechs, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_BPTECH_ERROR, TRACFONE_UPDATE_BPTECH_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse deleteZip2Techs(TracfoneOneZip2Tech tfZip2Tech, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneOneZip2TechAction.deleteZip2Techs(tfZip2Tech, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_ZIP2TECH_ERROR, TRACFONE_DELETE_ZIP2TECH_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public void bulkInsertZip2Tech(List<TracfoneOneZip2Tech> tfZip2Techs, int userId) throws TracfoneOneException {
        // Generate a unique identifier
        long unique = (new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        // Create a record in cop_audit table for this bulk insert
        triggerAudit(userId, ZIP2TECH_BULK_INSERT,
                "Requested a bulk insert of Zip2Tech -" + tfZip2Techs.size(),
                tfZip2Techs.size() + "_" + unique);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {

                for (TracfoneOneZip2Tech tfZip2Tech : tfZip2Techs) {
                    tfZip2Tech.setAction("action=");
                    tfZip2Tech.setMarket("&market=");
                    tfZip2Tech.setZip2("&zip=".concat(tfZip2Tech.getZips()));
                    tfZip2Tech.setAid("&aid=");
                    tfZip2Tech.setVid("&vid=");
                    tfZip2Tech.setVc("&vc=");
                    tfZip2Tech.setSahcid("&sahcid=");
                    tfZip2Tech.setCom("&com=");
                    tfZip2Tech.setLocale("&locale=en");
                    tfZip2Tech.setSiteType("&siteType=");
                    tfZip2Tech.setGotoPhoneList("&gotoPhonelist=");
                    tfZip2Tech.setTech("tech=");
                    tfZip2Tech.setTechZip("&techzip=".concat(tfZip2Tech.getZips()));
                    try {
                        LOGGER.info("Going to insert Zip2Tech " + tfZip2Tech);
                        tracfoneOneZip2TechAction.insertZip2Tech(tfZip2Tech, userId, String.valueOf(unique));
                    } catch (TracfoneOneException ex) {
                        LOGGER.error("Bulk Zip2Tech Insertion failed " + tfZip2Tech, ex);
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(ex.getErrorMessage())) {
                            triggerAudit(userId, ZIP2TECH_BULK_INSERT,
                                    "Inserted Zip2Tech " + tfZip2Tech, "CARRIER ID_" + unique);
                        }
                        triggerAudit(userId, ZIP2TECH_BULK_INSERT,
                                "Bulk Insert Failed for " + tfZip2Tech + " - " + ex.getErrorMessage(),
                                "ERROR_" + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_BULK_ADD_ZIP2TECH_ERROR, TRACFONE_BULK_ADD_ZIP2TECH_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public void bulkDeleteZip2Tech(List<TracfoneOneZip2Tech> tfZip2Techs, int userId) throws TracfoneOneException {
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {

                for (TracfoneOneZip2Tech tfZip2Tech : tfZip2Techs) {
                    try {
                        LOGGER.info("Going to delete Zip2Tech " + tfZip2Tech);
                        tracfoneOneZip2TechAction.deleteZip2Techs(tfZip2Tech, userId);
                    } catch (TracfoneOneException ex) {
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_BULK_DELETE_ZIP2TECH_ERROR, TRACFONE_BULK_DELETE_ZIP2TECH_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public TFOneGeneralResponse insertBpTech(TracfoneOneBPTech tfBPTech, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneOneZip2TechAction.insertBpTech(tfBPTech, userId, null);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_BPTECH_ERROR, TRACFONE_ADD_BPTECH_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public void bulkInsertBPTech(List<TracfoneOneBPTech> tfBPTechs, int userId) throws TracfoneOneException {
        // Generate a unique identifier
        long unique = (new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        // Create a record in cop_audit table for this bulk insert
        triggerAudit(userId, BP2TECH_BULK_INSERT,
                "Requested a bulk insert of BPTech -" + tfBPTechs.size(),
                tfBPTechs.size() + "_" + unique);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {

                for (TracfoneOneBPTech tfBPTech : tfBPTechs) {
                    try {
                        LOGGER.info("Going to insert BPTech " + tfBPTech);
                        tracfoneOneZip2TechAction.insertBpTech(tfBPTech, userId, String.valueOf(unique));
                    } catch (TracfoneOneException ex) {
                        LOGGER.error("Bulk BPTech Insertion failed " + tfBPTech, ex);
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(ex.getErrorMessage())) {
                            triggerAudit(userId, BP2TECH_BULK_INSERT,
                                    "Inserted BPTech " + tfBPTech, "CARRIER ID_" + unique);
                        }
                        triggerAudit(userId, BP2TECH_BULK_INSERT,
                                "Bulk Insert Failed for " + tfBPTech + " - " + ex.getErrorMessage(),
                                "ERROR_" + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_BULK_ADD_BPTECH_ERROR, TRACFONE_BULK_ADD_BPTECH_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public TFOneGeneralResponse deleteBpTech(TracfoneOneBPTech tfBPTech, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
        zip2Tech.setDbEnv(tfBPTech.getDbEnv());
        zip2Tech.setTechkey(tfBPTech.getTechkey());
        //dependency check in zip2tech table
        if (tracfoneOneZip2TechAction.searchTechKey(zip2Tech)) {
            throw new TracfoneOneException(TRACFONE_BPTECH_DEPENDENCY_ERROR, TRACFONE_BPTECH_DEPENDENCY_ERROR_MESSAGE);
        }
        try {
            response = tracfoneOneZip2TechAction.deleteBpTech(tfBPTech, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_BPTECH_ERROR, TRACFONE_DELETE_BPTECH_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public void bulkDeleteBpTech(List<TracfoneOneBPTech> tfBPTechs, int userId) throws TracfoneOneException {
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {

                for (TracfoneOneBPTech tfBPTech : tfBPTechs) {
                    try {
                        LOGGER.info("Going to delete BPTech " + tfBPTech);
                        TracfoneOneZip2Tech zip2Tech = new TracfoneOneZip2Tech();
                        zip2Tech.setDbEnv(tfBPTech.getDbEnv());
                        zip2Tech.setTechkey(tfBPTech.getTechkey());
                        //dependency check in zip2tech table
                        if (!tracfoneOneZip2TechAction.searchTechKey(zip2Tech)) {
                            tracfoneOneZip2TechAction.deleteBpTech(tfBPTech, userId);
                        } else {
                            LOGGER.info("Dependency Techkey found ", zip2Tech.getTechkey());
                        }
                    } catch (TracfoneOneException ex) {
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_BULK_DELETE_BPTECH_ERROR, TRACFONE_BULK_DELETE_BPTECH_ERROR_MESSAGE, ex);
        }
    }

    private void triggerAudit(int userId, String action, String details, String carrierId) {
        TracfoneAudit errorAudit = new TracfoneAudit(userId, action, details, carrierId);
        tracfoneAuditEvent.fire(errorAudit);
    }
}
