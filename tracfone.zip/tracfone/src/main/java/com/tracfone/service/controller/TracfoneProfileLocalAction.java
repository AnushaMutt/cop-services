/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneAncillaryCode;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeConfig;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeDiscount;
import com.tracfone.service.model.request.TracfoneOneChildPlan;
import com.tracfone.service.model.request.TracfoneOneLineStatusCode;
import com.tracfone.service.model.request.TracfoneOneMultiRatePlanEsn;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtension;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionLink;
import com.tracfone.service.model.request.TracfoneOneRatePlanProfile;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneThrottleStatusCode;
import com.tracfone.service.model.response.TFOneAncillaryCode;
import com.tracfone.service.model.response.TFOneAncillaryCodeConfig;
import com.tracfone.service.model.response.TFOneAncillaryCodeDiscount;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneMultiRatePlanEsn;
import com.tracfone.service.model.response.TFOneRatePlanExtension;
import com.tracfone.service.model.response.TFOneRatePlanProfile;

import javax.ejb.Local;
import java.util.List;

/**
 * @author Shireen Fathima
 */
@Local
public interface TracfoneProfileLocalAction {

    TFOneGeneralResponse insertProfile(TracfoneOneRatePlanProfile tfRatePlanProfile, int userId) throws TracfoneOneException;

    TFOneRatePlanProfile viewProfile(TracfoneOneRatePlanProfile tfRatePlanProfile) throws TracfoneOneException;

    TFOneGeneralResponse updateProfile(TracfoneOneRatePlanProfile tfRatePlanProfile, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteProfile(String dbEnv, List<String> idsToBeDeleted, int userId) throws TracfoneOneException;

    List<TFOneAncillaryCode> getAllAncillaryCodes(String dbEnv) throws TracfoneOneException;

    List<TFOneChildPlan> getAllChildPlans(String dbEnv) throws TracfoneOneException;

    List<TFOneRatePlanProfile> searchProfile(TracfoneOneSearchProfileModel tfRatePlanProfile) throws TracfoneOneException;

    List<TFOneRatePlanProfile> searchProfilesForUpdate(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) throws TracfoneOneException;

    TFOneGeneralResponse updateChildPlan(TracfoneOneChildPlan tfOneChildPlan, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertChildPlan(TracfoneOneChildPlan tfOneChildPlan, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteChildPlan(TracfoneOneChildPlan tfOneChildPlan, int userId) throws TracfoneOneException;

    TFOneChildPlan viewChildPlan(TracfoneOneChildPlan searchPlan) throws TracfoneOneException;

    boolean checkChildPlanDependencies(TracfoneOneChildPlan tfOneChildPlan) throws TracfoneOneException;

    TFOneGeneralResponse insertAncillaryCode(TracfoneOneAncillaryCode ancillaryCode, int userId) throws TracfoneOneException;

    boolean checkRpExtensionCodeDependencies(TracfoneOneRatePlanExtension tfOneRatePlanExtension) throws TracfoneOneException;

    TFOneGeneralResponse deleteAncillaryCode(TracfoneOneAncillaryCode ancillaryCode, int userId) throws TracfoneOneException;

    List<TFOneAncillaryCode> searchAncillaryCodes(TracfoneOneAncillaryCode ancillaryCode) throws TracfoneOneException;

    TFOneGeneralResponse updateAncillaryCode(TracfoneOneAncillaryCode ancillaryCode, int userId) throws TracfoneOneException;

    List<TFOneRatePlanExtension> searchRpExtensions(TracfoneOneRatePlanExtension searchRpExtension) throws TracfoneOneException;

    boolean checkRpExtensionDependencies(TracfoneOneRatePlanExtension tfRpExtension) throws TracfoneOneException;

    TFOneGeneralResponse deleteRpExtension(TracfoneOneRatePlanExtension tfRpExtension, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertRpExtension(TracfoneOneRatePlanExtension tfRpExtension, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertRpExtensionLink(TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteRpExtensionLink(TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateRpExtensionLink(TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink, int userId) throws TracfoneOneException;

    List<TFOneCarrierServicePlan> getProfileServicePlans(String dbEnv, String profileId) throws TracfoneOneException;

    List<TFOneCarrierServicePlan> getRatePlanServicePlans(String dbEnv, String ratePlan) throws TracfoneOneException;

    TFOneGeneralResponse insertAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig, int userId) throws TracfoneOneException;

    List<TFOneAncillaryCodeConfig> getAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig) throws TracfoneOneException;

    TFOneGeneralResponse insertAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount, int userId) throws TracfoneOneException;

    List<TFOneAncillaryCodeDiscount> searchAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount) throws TracfoneOneException;

    TFOneGeneralResponse deleteThrottleStatusCode(TracfoneOneThrottleStatusCode tfOneThrottleStatusCode, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteLineStatusCode(TracfoneOneLineStatusCode tfOneLineStatus, int userId) throws TracfoneOneException;

    long checkAncillaryCodeDiscountDependencies(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount) throws TracfoneOneException;

    TFOneGeneralResponse insertMultiRatePlanEsn(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn, int userId, String uniqueId) throws TracfoneOneException;

    TFOneGeneralResponse updateMultiRatePlanEsn(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteMultiRatePlanEsn(List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsn, int userId) throws TracfoneOneException;

    List<TFOneMultiRatePlanEsn> searchMultiRatePlanEsns(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn) throws TracfoneOneException;

    List<String> searchProfilesByDesc(List<TracfoneOneRatePlanProfile> tfRatePlanProfiles) throws TracfoneOneException;

    public TFOneGeneralResponse bulkDeleteMultiRatePlanEsn(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns, int userId) throws TracfoneOneException;
}
