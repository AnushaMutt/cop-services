/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.response;

import java.util.List;

/**
 *
 * @author Shireen Fathima
 */
public class TFOneChildPlan {
    
    private String childPlanId;
    private String childDescription;
    String childPlanName;    
          
    List<TFOneRatePlanProfile> ratePlanProfile;

	public void setChildPlanName(String childPlanName) {
        this.childPlanName = childPlanName;
    }

    public String getChildPlanId() {
        return childPlanId;
    }

    public void setChildPlanId(String childPlanId) {
        this.childPlanId = childPlanId;
    }

    public List<TFOneRatePlanProfile> getRatePlanProfiles() {
        return ratePlanProfile;
    }

    public void setRatePlanProfiles(List<TFOneRatePlanProfile> ratePlanProfiles) {
        this.ratePlanProfile = ratePlanProfiles;
    }
   

    public String getChildDescription() {
        return childDescription;
    }

    public void setChildDescription(String childDescription) {
        this.childDescription = childDescription;
    }

    @Override
    public String toString() {
        return "TFOneChildPlan{" + "childPlanId=" + childPlanId + ", childDescription=" + childDescription + '}';
    }
    
}
