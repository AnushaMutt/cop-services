package com.tracfone.service.model.response;

import java.util.ArrayList;
import java.util.List;

public class TFOneUserTask {
    private String id;
    private String taskName;
    private String description;
    private String userId;
    private String assignedUserId;
    private String assignedUserName;
    private String type;
    private List<String> status;
    private String creationDate;
    private List<TFOneUserTaskDetail> tfOneUserTaskDetail;

    public TFOneUserTask() {
        tfOneUserTaskDetail = new ArrayList<>();
        status = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAssignedUserId() {
        return assignedUserId;
    }

    public void setAssignedUserId(String assignedUserId) {
        this.assignedUserId = assignedUserId;
    }

    public String getAssignedUserName() {
        return assignedUserName;
    }

    public void setAssignedUserName(String assignedUserName) {
        this.assignedUserName = assignedUserName;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getStatus() {
        return status;
    }

    public void setStatus(List<String> status) {
        this.status = status;
    }

    public List<TFOneUserTaskDetail> getTfOneUserTaskDetail() {
        return tfOneUserTaskDetail;
    }

    public void setTfOneUserTaskDetail(List<TFOneUserTaskDetail> tfOneUserTaskDetail) {
        this.tfOneUserTaskDetail = tfOneUserTaskDetail;
    }

    @Override
    public String toString() {
        return "TFOneUserTask{" +
                "id='" + id + '\'' +
                ", taskName='" + taskName + '\'' +
                ", description='" + description + '\'' +
                ", userId='" + userId + '\'' +
                ", assignedUserId='" + assignedUserId + '\'' +
                ", assignedUserName='" + assignedUserName + '\'' +
                ", type='" + type + '\'' +
                ", status=" + status +
                ", creationDate='" + creationDate + '\'' +
                ", tfOneUserTaskDetail=" + tfOneUserTaskDetail +
                '}';
    }
}
