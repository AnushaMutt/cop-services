/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneApn;
import com.tracfone.service.model.request.TracfoneOneBucketList;
import com.tracfone.service.model.request.TracfoneOneCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucketTier;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildTier;
import com.tracfone.service.model.request.TracfoneOneRatePlan;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionLink;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.request.TracfoneOneSearchCarrierFeatureModel;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneServicePlanCarrierFeature;
import com.tracfone.service.model.response.TFOneApn;
import com.tracfone.service.model.response.TFOneBusinessOrganization;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOneRatePlan;
import com.tracfone.service.util.TracfoneOneConstantPlanWizard;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Shireen Fathima
 */
@Stateless
public class TracfoneRatePlanController implements TracfoneRatePlanControllerLocal, TracfoneOneConstantPlanWizard {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneRatePlanController.class);

    @EJB
    TracfoneRatePlanLocalAction tracfoneRatePlanAction;

    @EJB
    TracfoneBucketLocalAction tracfoneBucketAction;

    @EJB
    TracfoneServicePlanLocalAction tracfoneServicePlanAction;

    @Override
    public TFOneGeneralResponse insertRatePlan(TracfoneOneRatePlan tfRatePlan, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        validateRatePlanAlreadyExists(tfRatePlan);
        try {
            response = tracfoneRatePlanAction.insertRatePlan(tfRatePlan, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_ADD_RATE_PLAN_ERROR, TRACFONE_ADD_RATE_PLAN_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneRatePlan viewRatePlan(TracfoneOneRatePlan tfRatePlan) throws TracfoneOneException {
        TFOneRatePlan tfOneRatePlan = null;
        try {
            tfOneRatePlan = tracfoneRatePlanAction.viewRatePlan(tfRatePlan, true);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_VIEW_RATE_PLAN_ERROR, TRACFONE_VIEW_RATE_PLAN_ERROR_MESSAGE, ex);
        }

        return tfOneRatePlan;
    }

    @Override
    public TFOneGeneralResponse updateRatePlan(TracfoneOneRatePlan tfRatePlan, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneRatePlanAction.updateRatePlan(tfRatePlan, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_RATE_PLAN_ERROR, TRACFONE_UPDATE_RATE_PLAN_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneGeneralResponse deleteRatePlan(TracfoneOneRatePlan tfRatePlan, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            List<String> idsToBeDeleted = new ArrayList<>();
            idsToBeDeleted.add(tfRatePlan.getRatePlanName());
            response = tracfoneRatePlanAction.deleteRatePlan(tfRatePlan.getDbEnv(),
                    idsToBeDeleted,
                    userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DELETE_RATE_PLAN_ERROR, TRACFONE_DELETE_RATE_PLAN_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public List<TFOneCarrierServicePlan> getServicePlansForCarrier(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        try {
            if (tracfoneOneSearchPlanModel.isLegacy()) {
                carrierServicePlans = tracfoneServicePlanAction.getAllLegacyPaygoPlans(tracfoneOneSearchPlanModel.getDbEnv(),
                        tracfoneOneSearchPlanModel.getCarrierName());
            } else {
                if (!StringUtils.isNullOrEmpty(tracfoneOneSearchPlanModel.getCarrierName())) {
                    carrierServicePlans = tracfoneRatePlanAction.getServicePlansForCarrier(tracfoneOneSearchPlanModel.getCarrierName(),
                            tracfoneOneSearchPlanModel.getDbEnv());
                } else {
                    carrierServicePlans = tracfoneServicePlanAction.getAllServicePlans(tracfoneOneSearchPlanModel.getDbEnv());
                }
            }
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_SERVICE_PLAN_ERROR, TRACFONE_GET_SERVICE_PLAN_ERROR_MESSAGE, ex);
        }

        return carrierServicePlans;
    }

    @Override
    public List<TFOneBusinessOrganization> getAllBusinessOrgs(String dbEnv) throws TracfoneOneException {
        List<TFOneBusinessOrganization> allBusOrgs = new ArrayList<>();
        try {
            allBusOrgs = tracfoneRatePlanAction.getAllBusinessOrgs(dbEnv);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_ALL_BUS_ORGS_ERROR, TRACFONE_GET_ALL_BUS_ORGS_ERROR_MESSAGE, ex);
        }

        return allBusOrgs;
    }

    private void validateRatePlanAlreadyExists(TracfoneOneRatePlan tfRatePlan) throws TracfoneOneException {
        TracfoneOneRatePlan searchRatePlan = new TracfoneOneRatePlan();
        searchRatePlan.setDbEnv(tfRatePlan.getDbEnv());
        searchRatePlan.setRatePlanName(tfRatePlan.getRatePlanName().trim());
        TFOneRatePlan ratePlan = tracfoneRatePlanAction.viewRatePlan(searchRatePlan, false);
        // Search only based on rate plan name
        if (null != ratePlan && !StringUtils.isNullOrEmpty(ratePlan.getRatePlanName())) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_RATE_PLAN_ERROR, TRACFONE_DUPLICATE_RATE_PLAN_ERROR_MESSAGE);
        }
    }

    @Override
    public List<TFOneRatePlan> getMasterRatePlans(String dbEnv) throws TracfoneOneException {
        List<TFOneRatePlan> allRatePlans = new ArrayList<>();
        try {
            allRatePlans = tracfoneRatePlanAction.getMasterRatePlans(dbEnv);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_MASTER_RATE_PLANS_ERROR, TRACFONE_GET_MASTER_RATE_PLANS_ERROR_MESSAGE, ex);
        }

        return allRatePlans;
    }

    @Override
    public TFOneGeneralResponse updateCarrierFeature(TracfoneOneCarrierFeature tfCarrierFeature, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        validateCarrierFeatureAlreadyExists(tfCarrierFeature, true);
        try {
            response = tracfoneRatePlanAction.updateCarrierFeature(tfCarrierFeature, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_CF_ERROR, TRACFONE_UPDATE_CF_ERROR_MESSAGE, ex);
        }
        return response;
    }

    private void validateCarrierFeatureAlreadyExists(TracfoneOneCarrierFeature tfCarrierFeature, boolean isUpdate) throws TracfoneOneException {
        boolean duplicate = false;
        List<String> objIds = tracfoneRatePlanAction.duplicateCarrierFeatures(tfCarrierFeature);
        if (!objIds.isEmpty()) {
            if (isUpdate && !objIds.contains(tfCarrierFeature.getObjId())) {
                duplicate = true;
            } else if (!isUpdate && StringUtils.isNullOrEmpty(tfCarrierFeature.getObjId())) {
                duplicate = true;
            }
        }
        if (duplicate) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_CARRIER_FEATURE_ERROR, TRACFONE_DUPLICATE_CARRIER_FEATURE_ERROR_MESSAGE);
        }
    }

    @Override
    public List<TFOneCarrierFeature> searchCarrierFeatures(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        try {
            carrierFeatures = tracfoneRatePlanAction.searchCarrierFeatures(tfCarrierFeatureModel);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_CARRIER_FEATURES_ERROR, TRACFONE_SEARCH_CARRIER_FEATURES_ERROR_MESSAGE, ex);
        }

        return carrierFeatures;
    }

    @Override
    public List<String> getAllCarrierNames(String dbEnv) throws TracfoneOneException {
        List<String> carrierNames = new ArrayList<>();
        try {
            carrierNames = tracfoneRatePlanAction.getAllCarrierNames(dbEnv);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_ALL_CARRIERS_ERROR, TRACFONE_GET_ALL_CARRIERS_ERROR_MESSAGE, ex);
        }

        return carrierNames;
    }

    @Override
    public TFOneGeneralResponse insertApn(TracfoneOneApn tfOneApn, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        validateApnAlreadyExists(tfOneApn, false);
        try {
            response = tracfoneRatePlanAction.insertApn(tfOneApn, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_ADD_APN_ERROR, TRACFONE_ADD_APN_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneGeneralResponse updateApn(TracfoneOneApn tfOneApn, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        validateApnAlreadyExists(tfOneApn, true);
        try {
            response = tracfoneRatePlanAction.updateApn(tfOneApn, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_APN_ERROR, TRACFONE_UPDATE_APN_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneGeneralResponse deleteApn(TracfoneOneApn tfOneApn, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneRatePlanAction.deleteApn(tfOneApn, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DELETE_APN_ERROR, TRACFONE_DELETE_APN_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public List<TFOneParent> getAllParentNames(String dbEnv, String carrierName) throws TracfoneOneException {
        List<TFOneParent> allParentNames = new ArrayList<>();
        try {
            allParentNames = tracfoneRatePlanAction.getAllParentNames(dbEnv, carrierName);
            if (!allParentNames.isEmpty()) {
                allParentNames = allParentNames.stream()
                        .sorted(Comparator.comparing(a -> Long.valueOf(a.getParentId())))
                        .collect(Collectors.toList());
            }
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_ALL_PARENT_NAMES_ERROR, TRACFONE_GET_ALL_PARENT_NAMES_ERROR_MESSAGE, ex);
        }

        return allParentNames;
    }

    @Override
    public List<TFOneRatePlan> searchRatePlansForUpdate(TracfoneOneRatePlan tracfoneOneRatePlan) throws TracfoneOneException {
        List<TFOneRatePlan> tfOneRatePlans = new ArrayList<>();
        try {
            tfOneRatePlans = tracfoneRatePlanAction.searchRatePlansForUpdate(tracfoneOneRatePlan);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_UNLINKED_RP_ERROR, TRACFONE_SEARCH_UNLINKED_RP_ERROR_MESSAGE, ex);
        }

        return tfOneRatePlans;
    }

    @Override
    public List<TFOneApn> getAllRatePlanApns(TracfoneOneApn tracfoneOneApn) throws TracfoneOneException {
        List<TFOneApn> ratePlanApns = new ArrayList<>();
        try {
            ratePlanApns = tracfoneRatePlanAction.getAllRatePlanApns(tracfoneOneApn);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_RATEPLAN_APNS_ERROR, TRACFONE_GET_RATEPLAN_APNS_ERROR_MESSAGE, ex);
        }

        return ratePlanApns;
    }

    /**
     * logic for update duplicate check (Sample: apn 1 orgId 1, oldApn 1
     * oldOrgId 2. If the old and new values are same, go ahead and update. no
     * need for duplicate check. If they are different, check if values exist for new
     * values, if yes, then throw error
     *
     * @param tfOneApn
     * @param isUpdate
     * @throws TracfoneOneException
     */
    private void validateApnAlreadyExists(TracfoneOneApn tfOneApn, boolean isUpdate) throws TracfoneOneException {
        if (!isUpdate
                || !tfOneApn.getOldApn().equalsIgnoreCase(tfOneApn.getApn())
                || !tfOneApn.getOldOrgId().equalsIgnoreCase(tfOneApn.getOrgId())
                || !tfOneApn.getOldParentName().equalsIgnoreCase(tfOneApn.getxParentName())) {
            TracfoneOneApn searchApn = new TracfoneOneApn();
            searchApn.setDbEnv(tfOneApn.getDbEnv());
            searchApn.setRatePlan(tfOneApn.getRatePlan());
            searchApn.setApn(tfOneApn.getApn());
            searchApn.setOrgId(tfOneApn.getOrgId());
            searchApn.setxParentName(tfOneApn.getxParentName());
            if (tracfoneRatePlanAction.isDuplicateApn(searchApn)) {
                throw new TracfoneOneException(TRACFONE_DUPLICATE_APN_ERROR, TRACFONE_DUPLICATE_APN_ERROR_MESSAGE);
            }
        }
    }

    @Override
    public List<TFOneCarrierFeature> getCarrierFeatureLinks(List<TracfoneOneCarrierFeature> selectedCarrierFeatures) throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        try {
            carrierFeatures = tracfoneRatePlanAction.getCarrierFeatureLinks(selectedCarrierFeatures);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_CF_LINKS_ERROR, TRACFONE_GET_CF_LINKS_ERROR_MESSAGE, ex);
        }

        return carrierFeatures;
    }

    @Override
    public TFOneGeneralResponse insertRatePlanAssociation(TracfoneOneCarrierFeature tfOneCarrierFeature, String carrierId, String servicePlanId, String ratePlanName, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        // set all the right values from the request into the object - rateplan, carrierid and service plan id
        tfOneCarrierFeature.setxRatePlan(ratePlanName);
        tfOneCarrierFeature.setxFeature2xCarrier(carrierId);
        TracfoneOneServicePlanCarrierFeature spCarrierFeature = new TracfoneOneServicePlanCarrierFeature();
        spCarrierFeature.setServicePlanId(servicePlanId);
        if (tfOneCarrierFeature.getServicePlanCarrierFeature() != null) {
            spCarrierFeature.setPriority(tfOneCarrierFeature.getServicePlanCarrierFeature().getPriority());
        }
        tfOneCarrierFeature.setServicePlanCarrierFeature(spCarrierFeature);
        validateCarrierFeatureAlreadyExists(tfOneCarrierFeature, false);
        try {
            // This method is needed to ensure that the unique constraints on the bucket and child bucket tables are handled
            validateBucketsForDuplicates(tfOneCarrierFeature);
            validateAndInsertBucketLists(tfOneCarrierFeature, userId);
            response = tracfoneRatePlanAction.insertRatePlanAssociation(tfOneCarrierFeature, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_INSERT_RP_ASSOCIATION_ERROR, TRACFONE_INSERT_RP_ASSOCIATION_ERROR_MESSAGE, ex);
        }

        return response;
    }

    private void validateAndInsertBucketLists(TracfoneOneCarrierFeature tfOneCarrierFeature, int userId) throws TracfoneOneException {
        Map<String, TracfoneOneBucketList> bucketListMap = new HashMap<>();
        List<TracfoneOneRatePlanExtensionLink> links = tfOneCarrierFeature.getRatePlanExtensionLinks();
        if (!links.isEmpty()) {
            TracfoneOneBucketList bucketList = null;
            for (TracfoneOneRatePlanExtensionLink link : links) {
                List<TracfoneOneCarrierProfileBucket> buckets = link.getTracfoneOneCarrierProfileBuckets();
                LOGGER.info("buckets " + buckets);
                for (TracfoneOneCarrierProfileBucket bucket : buckets) {
                    if (bucketListMap.get(bucket.getBucketId()) == null || !StringUtils.isNullOrEmpty(bucket.getBucketDesc())) {
                        bucketList = new TracfoneOneBucketList();
                        bucketList.setDbEnv(tfOneCarrierFeature.getDbEnv());
                        bucketList.setBucketId(bucket.getBucketId());
                        bucketList.setDescription(bucket.getBucketDesc());
                        bucketList.setActiveFlag("Y");
                        bucketList.setParentShortName(bucket.getParentShortName());
                        bucketListMap.put(bucketList.getBucketId(), bucketList);
                    }
                }
                List<TracfoneOneCarrierProfileChildBucket> childBuckets = link.getTracfoneOneCarrierProfileChildBuckets();
                LOGGER.info("childBuckets " + childBuckets);
                for (TracfoneOneCarrierProfileChildBucket childBucket : childBuckets) {
                    if (bucketListMap.get(childBucket.getBucketId()) == null || !StringUtils.isNullOrEmpty(childBucket.getBucketDesc())) {
                        bucketList = new TracfoneOneBucketList();
                        bucketList.setDbEnv(tfOneCarrierFeature.getDbEnv());
                        bucketList.setBucketId(childBucket.getBucketId());
                        bucketList.setDescription(childBucket.getBucketDesc());
                        bucketList.setActiveFlag("Y");
                        bucketList.setParentShortName(childBucket.getParentShortName());
                        bucketListMap.put(bucketList.getBucketId(), bucketList);
                    }
                }
            }
        }
        LOGGER.info("Total Bucket Ids " + bucketListMap.keySet());
        if (!bucketListMap.isEmpty()) {
            List<String> existingBucketIds = tracfoneBucketAction.getBucketListByBucketIds(bucketListMap.keySet(), tfOneCarrierFeature.getDbEnv());
            LOGGER.info("Total existing Bucket Ids " + existingBucketIds);
            for (String existingBucketId : existingBucketIds) {
                bucketListMap.remove(existingBucketId);
            }
            LOGGER.info("Total Buckets to be added in DB with Bucket id " + bucketListMap.keySet());
            if (!bucketListMap.isEmpty()) {
                tracfoneBucketAction.insertBucketList(bucketListMap.values(), userId);
            }
        }
    }

    private void validateBucketsForDuplicates(TracfoneOneCarrierFeature tfOneCarrierFeature) throws TracfoneOneException {
        List<TracfoneOneRatePlanExtensionLink> links = tfOneCarrierFeature.getRatePlanExtensionLinks();
        if (!links.isEmpty()) {
            for (TracfoneOneRatePlanExtensionLink link : links) {
                List<TracfoneOneCarrierProfileBucket> buckets = link.getTracfoneOneCarrierProfileBuckets();
                if (!buckets.isEmpty()) {
                    validateForDuplicate(tfOneCarrierFeature, link, false);
                }
                List<TracfoneOneCarrierProfileChildBucket> childBuckets = link.getTracfoneOneCarrierProfileChildBuckets();
                if (!childBuckets.isEmpty()) {
                    validateForDuplicate(tfOneCarrierFeature, link, true);
                }
            }
        }
    }

    private void validateForDuplicate(TracfoneOneCarrierFeature tfOneCarrierFeature, TracfoneOneRatePlanExtensionLink link, boolean isChild) throws TracfoneOneException {
        TracfoneOneSearchBucketModel bucketModel = new TracfoneOneSearchBucketModel();
        bucketModel.setDbEnv(tfOneCarrierFeature.getDbEnv());
        List<String> servicePlanIds = new ArrayList<>();
        servicePlanIds.add(tfOneCarrierFeature.getServicePlanCarrierFeature().getServicePlanId());
        bucketModel.setServicePlanIds(servicePlanIds);
        List<String> profileIds = new ArrayList<>();
        profileIds.add(link.getProfileId());
        bucketModel.setProfileIds(profileIds);
        String key = bucketModel.getServicePlanIds().get(0) + "-" + bucketModel.getProfileIds().get(0);
        if (!isChild) {
            LOGGER.info("Trying to validate bucket for key " + key);
            // get buckets from DB for service plan and profile combo
            List<TFOneCarrierProfileBucket> profileBuckets = tracfoneBucketAction.searchCarrierProfileBuckets(bucketModel);
            LOGGER.info("Any buckets in DB with this key? " + profileBuckets);
            // create a map that will be used for duplicate check with key as service plan id - profile id - bucket id
            List<String> bucketList = populateBucketList(profileBuckets, null, key);
            LOGGER.info("Unique list for buckets? " + bucketList);
            // validate list in links does not contain any duplicates and remove them
            removeDuplicates(link, bucketList, key, false);
        } else {
            LOGGER.info("Trying to validate child bucket for key " + key);
            // get child buckets from DB for service plan and profile combo
            List<TFOneCarrierProfileChildBucket> profileChildBuckets = tracfoneBucketAction.searchCarrierProfileChildBuckets(bucketModel);
            LOGGER.info("Any child buckets in DB with this key? " + profileChildBuckets);
            // create a map that will be used for duplicate check with key as service plan id - profile id - bucket id - child plan id
            List<String> childBucketList = populateBucketList(null, profileChildBuckets, key);
            LOGGER.info("Unique list for buckets? " + childBucketList);
            // validate list in links does not contain any duplicates and remove them
            removeDuplicates(link, childBucketList, key, true);
        }
    }

    private void removeDuplicates(TracfoneOneRatePlanExtensionLink link, List<String> bucketList, String key, boolean isChild) {
        if (isChild) {
            List<TracfoneOneCarrierProfileChildBucket> childBuckets = link.getTracfoneOneCarrierProfileChildBuckets();
            if (!childBuckets.isEmpty()) {
                Iterator<TracfoneOneCarrierProfileChildBucket> iterator = childBuckets.iterator();
                while (iterator.hasNext()) {
                    TracfoneOneCarrierProfileChildBucket childBucket = iterator.next();
                    String bucketKey = key + "-" + childBucket.getBucketId();
                    if (!StringUtils.isNullOrEmpty(childBucket.getChildPlanId())) {
                        bucketKey = bucketKey + "-" + childBucket.getChildPlanId();
                    }
                    if (bucketList.contains(bucketKey)) {
                        iterator.remove();
                    } else {
                        bucketList.add(bucketKey);
                        checkChildBucketTier(childBucket.getTracfoneOneCarrierProfileChildTiers());
                    }
                }
            }
            LOGGER.info("Final list for child buckets from the link? " + childBuckets);
        } else {
            List<TracfoneOneCarrierProfileBucket> buckets = link.getTracfoneOneCarrierProfileBuckets();
            if (!buckets.isEmpty()) {
                Iterator<TracfoneOneCarrierProfileBucket> iterator = buckets.iterator();
                while (iterator.hasNext()) {
                    TracfoneOneCarrierProfileBucket bucket = iterator.next();
                    String bucketKey = key + "-" + bucket.getBucketId();
                    if (bucketList.contains(bucketKey)) {
                        iterator.remove();
                    } else {
                        bucketList.add(bucketKey);
                        checkBucketTier(bucket.getTracfoneOneCarrierProfileBucketTiers());
                    }
                }
            }
            LOGGER.info("Final list for buckets from the link? " + buckets);
        }
    }

    private void checkChildBucketTier(List<TracfoneOneCarrierProfileChildTier> childBucketTiers) {
        if (!childBucketTiers.isEmpty()) {
            List<String> tierIds = new ArrayList<>();
            Iterator<TracfoneOneCarrierProfileChildTier> iterator = childBucketTiers.iterator();
            while (iterator.hasNext()) {
                TracfoneOneCarrierProfileChildTier tier = iterator.next();
                if (tierIds.contains(tier.getUsageTierId())) {
                    iterator.remove();
                } else {
                    tierIds.add(tier.getUsageTierId());
                }
            }
        }
        LOGGER.info("Final list for child bucket tiers from the link? " + childBucketTiers);
    }

    private void checkBucketTier(List<TracfoneOneCarrierProfileBucketTier> bucketTiers) {
        if (!bucketTiers.isEmpty()) {
            List<String> tierIds = new ArrayList<>();
            Iterator<TracfoneOneCarrierProfileBucketTier> iterator = bucketTiers.iterator();
            while (iterator.hasNext()) {
                TracfoneOneCarrierProfileBucketTier tier = iterator.next();
                if (tierIds.contains(tier.getUsageTierId())) {
                    iterator.remove();
                } else {
                    tierIds.add(tier.getUsageTierId());
                }
            }
        }
        LOGGER.info("Final list for bucket tiers from the link? " + bucketTiers);
    }

    private List<String> populateBucketList(List<TFOneCarrierProfileBucket> profileBuckets, List<TFOneCarrierProfileChildBucket> profileChildBuckets, String key) {
        List<String> bucketMap = new ArrayList<>();

        if (null != profileBuckets) {
            for (TFOneCarrierProfileBucket bucket : profileBuckets) {
                String bucketKey = key + "-" + bucket.getBucketId();
                bucketMap.add(bucketKey);
            }
        }
        if (null != profileChildBuckets) {
            for (TFOneCarrierProfileChildBucket childBucket : profileChildBuckets) {
                String bucketKey = key + "-" + childBucket.getBucketId();
                if (!StringUtils.isNullOrEmpty(childBucket.getChildPlanId())) {
                    bucketKey = bucketKey + "-" + childBucket.getChildPlanId();
                }
                bucketMap.add(bucketKey);
            }
        }
        return bucketMap;
    }

    @Override
    public List<TFOneCarrierFeature> searchCarrierFeaturesForUpdate(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        try {
            carrierFeatures = tracfoneRatePlanAction.searchCarrierFeaturesForUpdate(tfCarrierFeatureModel);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_CARRIER_FEATURES_ERROR, TRACFONE_SEARCH_CARRIER_FEATURES_ERROR_MESSAGE, ex);
        }

        return carrierFeatures;
    }

    @Override
    public List<TFOneRatePlan> getCarrierRatePlans(String dbEnv, String carrierName) throws TracfoneOneException {
        List<TFOneRatePlan> ratePlans = new ArrayList<>();
        try {
            ratePlans = tracfoneRatePlanAction.getCarrierRatePlans(dbEnv, carrierName);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_CF_RATE_PLANS_ERROR, TRACFONE_GET_CF_RATE_PLANS_ERROR_MESSAGE, ex);
        }

        return ratePlans;
    }

}
