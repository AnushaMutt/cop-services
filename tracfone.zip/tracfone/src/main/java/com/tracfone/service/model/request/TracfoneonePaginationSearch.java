/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.request;

/**
 *
 * @author user
 */public class TracfoneonePaginationSearch {
    
    private int startIndex;
    private int endIndex;
    private int total;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getStartIndex() {
        return startIndex;
    }

    public void setStartIndex(int startIndex) {
        this.startIndex = startIndex;
    }

    public int getEndIndex() {
        return endIndex;
    }

    public void setEndIndex(int endIndex) {
        this.endIndex = endIndex;
    }

    @Override
    public String toString() {
        return "TracfoneonePaginationSearch{" +
                "startIndex=" + startIndex +
                ", endIndex=" + endIndex +
                ", total=" + total +
                '}';
    }
}
