/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.event.processors;

import com.tracfone.ejb.entity.session.AuditFacadeLocal;
import com.tracfone.service.model.event.TracfoneAudit;
import javax.ejb.Asynchronous;
import javax.ejb.EJB;
import javax.ejb.Singleton;

import javax.enterprise.event.Observes;
import javax.inject.Named;

/**
 *
 * @author jflores
 */
@Named
@Singleton
public class AuditEventProcessor {
    
    @EJB
    AuditFacadeLocal auditEJB;    
    
    @Asynchronous 
    public void observeItemEvent(@Observes TracfoneAudit tracfoneAudit) {
        com.tracfone.ejb.entity.Audit auditEntity = new com.tracfone.ejb.entity.Audit();
        auditEntity.setAction(tracfoneAudit.getAction());
        auditEntity.setCarrierId(tracfoneAudit.getCarrierId());
        auditEntity.setUserId(tracfoneAudit.getUserId());
        auditEntity.setDetails(tracfoneAudit.getDetails());
        auditEJB.create(auditEntity);
    }
    
}
