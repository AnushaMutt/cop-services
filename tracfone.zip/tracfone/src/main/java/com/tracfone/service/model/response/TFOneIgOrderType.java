package com.tracfone.service.model.response;

public class TFOneIgOrderType {
    private String programmeName;
    private String actualOrderType;
    private String igOrderType;
    private String sqlText;
    private String priority;
    private String createSOGencodeFlag;
    private String createMFormIGFlag;
    private String createMFormPortFlag;
    private String skipMinValidationForm;
    private String skipESNValidationFlag;
    private String createIGAPNFlag;
    private String insertILDTransFlag;
    private String bogoConfigFlag;
    private String sUIActionType;
    private String updateMSIDFlag;
    private String addonCashCardFlag;
    private String contactPinUpdateFlag;
    private String brmNotificationFlag;
    private String newerTransFlag;
    private String skipMinUpdateFlag;
    private String safeLinkBatchFlag;
    private String createBucketsFlag;
    private String processIgateIN3Flag;
    private String processIgateIN3LiteFlag;
    private String updateXCase2TaskFlag;
    private String depIGTransFlag;
    private String generateAccountFlag;
    private String createIGACMFlag;

    public String getProgrammeName() {
        return programmeName;
    }

    public void setProgrammeName(String programmeName) {
        this.programmeName = programmeName;
    }

    public String getActualOrderType() {
        return actualOrderType;
    }

    public void setActualOrderType(String actualOrderType) {
        this.actualOrderType = actualOrderType;
    }

    public String getIgOrderType() {
        return igOrderType;
    }

    public void setIgOrderType(String igOrderType) {
        this.igOrderType = igOrderType;
    }

    public String getSqlText() {
        return sqlText;
    }

    public void setSqlText(String sqlText) {
        this.sqlText = sqlText;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getCreateSOGencodeFlag() {
        return createSOGencodeFlag;
    }

    public void setCreateSOGencodeFlag(String createSOGencodeFlag) {
        this.createSOGencodeFlag = createSOGencodeFlag;
    }

    public String getCreateMFormIGFlag() {
        return createMFormIGFlag;
    }

    public void setCreateMFormIGFlag(String createMFormIGFlag) {
        this.createMFormIGFlag = createMFormIGFlag;
    }

    public String getCreateMFormPortFlag() {
        return createMFormPortFlag;
    }

    public void setCreateMFormPortFlag(String createMFormPortFlag) {
        this.createMFormPortFlag = createMFormPortFlag;
    }

    public String getSkipMinValidationForm() {
        return skipMinValidationForm;
    }

    public void setSkipMinValidationForm(String skipMinValidationForm) {
        this.skipMinValidationForm = skipMinValidationForm;
    }

    public String getSkipESNValidationFlag() {
        return skipESNValidationFlag;
    }

    public void setSkipESNValidationFlag(String skipESNValidationFlag) {
        this.skipESNValidationFlag = skipESNValidationFlag;
    }

    public String getCreateIGAPNFlag() {
        return createIGAPNFlag;
    }

    public void setCreateIGAPNFlag(String createIGAPNFlag) {
        this.createIGAPNFlag = createIGAPNFlag;
    }

    public String getInsertILDTransFlag() {
        return insertILDTransFlag;
    }

    public void setInsertILDTransFlag(String insertILDTransFlag) {
        this.insertILDTransFlag = insertILDTransFlag;
    }

    public String getBogoConfigFlag() {
        return bogoConfigFlag;
    }

    public void setBogoConfigFlag(String bogoConfigFlag) {
        this.bogoConfigFlag = bogoConfigFlag;
    }

    public String getsUIActionType() {
        return sUIActionType;
    }

    public void setsUIActionType(String sUIActionType) {
        this.sUIActionType = sUIActionType;
    }

    public String getUpdateMSIDFlag() {
        return updateMSIDFlag;
    }

    public void setUpdateMSIDFlag(String updateMSIDFlag) {
        this.updateMSIDFlag = updateMSIDFlag;
    }

    public String getAddonCashCardFlag() {
        return addonCashCardFlag;
    }

    public void setAddonCashCardFlag(String addonCashCardFlag) {
        this.addonCashCardFlag = addonCashCardFlag;
    }

    public String getContactPinUpdateFlag() {
        return contactPinUpdateFlag;
    }

    public void setContactPinUpdateFlag(String contactPinUpdateFlag) {
        this.contactPinUpdateFlag = contactPinUpdateFlag;
    }

    public String getBrmNotificationFlag() {
        return brmNotificationFlag;
    }

    public void setBrmNotificationFlag(String brmNotificationFlag) {
        this.brmNotificationFlag = brmNotificationFlag;
    }

    public String getNewerTransFlag() {
        return newerTransFlag;
    }

    public void setNewerTransFlag(String newerTransFlag) {
        this.newerTransFlag = newerTransFlag;
    }

    public String getSkipMinUpdateFlag() {
        return skipMinUpdateFlag;
    }

    public void setSkipMinUpdateFlag(String skipMinUpdateFlag) {
        this.skipMinUpdateFlag = skipMinUpdateFlag;
    }

    public String getSafeLinkBatchFlag() {
        return safeLinkBatchFlag;
    }

    public void setSafeLinkBatchFlag(String safeLinkBatchFlag) {
        this.safeLinkBatchFlag = safeLinkBatchFlag;
    }

    public String getCreateBucketsFlag() {
        return createBucketsFlag;
    }

    public void setCreateBucketsFlag(String createBucketsFlag) {
        this.createBucketsFlag = createBucketsFlag;
    }

    public String getProcessIgateIN3Flag() {
        return processIgateIN3Flag;
    }

    public void setProcessIgateIN3Flag(String processIgateIN3Flag) {
        this.processIgateIN3Flag = processIgateIN3Flag;
    }

    public String getProcessIgateIN3LiteFlag() {
        return processIgateIN3LiteFlag;
    }

    public void setProcessIgateIN3LiteFlag(String processIgateIN3LiteFlag) {
        this.processIgateIN3LiteFlag = processIgateIN3LiteFlag;
    }

    public String getUpdateXCase2TaskFlag() {
        return updateXCase2TaskFlag;
    }

    public void setUpdateXCase2TaskFlag(String updateXCase2TaskFlag) {
        this.updateXCase2TaskFlag = updateXCase2TaskFlag;
    }

    public String getDepIGTransFlag() {
        return depIGTransFlag;
    }

    public void setDepIGTransFlag(String depIGTransFlag) {
        this.depIGTransFlag = depIGTransFlag;
    }

    public String getGenerateAccountFlag() {
        return generateAccountFlag;
    }

    public void setGenerateAccountFlag(String generateAccountFlag) {
        this.generateAccountFlag = generateAccountFlag;
    }

    public String getCreateIGACMFlag() {
        return createIGACMFlag;
    }

    public void setCreateIGACMFlag(String createIGACMFlag) {
        this.createIGACMFlag = createIGACMFlag;
    }

    @Override
    public String toString() {
        return "TFOneIgOrderType{" +
                "programmeName='" + programmeName + '\'' +
                ", actualOrderType='" + actualOrderType + '\'' +
                ", igOrderType='" + igOrderType + '\'' +
                ", sqlText='" + sqlText + '\'' +
                ", priority='" + priority + '\'' +
                ", createSOGencodeFlag='" + createSOGencodeFlag + '\'' +
                ", createMFormIGFlag='" + createMFormIGFlag + '\'' +
                ", createMFormPortFlag='" + createMFormPortFlag + '\'' +
                ", skipMinValidationForm='" + skipMinValidationForm + '\'' +
                ", skipESNValidationFlag='" + skipESNValidationFlag + '\'' +
                ", createIGAPNFlag='" + createIGAPNFlag + '\'' +
                ", insertILDTransFlag='" + insertILDTransFlag + '\'' +
                ", bogoConfigFlag='" + bogoConfigFlag + '\'' +
                ", sUIActionType='" + sUIActionType + '\'' +
                ", updateMSIDFlag='" + updateMSIDFlag + '\'' +
                ", addonCashCardFlag='" + addonCashCardFlag + '\'' +
                ", contactPinUpdateFlag='" + contactPinUpdateFlag + '\'' +
                ", brmNotificationFlag='" + brmNotificationFlag + '\'' +
                ", newerTransFlag='" + newerTransFlag + '\'' +
                ", skipMinUpdateFlag='" + skipMinUpdateFlag + '\'' +
                ", safeLinkBatchFlag='" + safeLinkBatchFlag + '\'' +
                ", createBucketsFlag='" + createBucketsFlag + '\'' +
                ", processIgateIN3Flag='" + processIgateIN3Flag + '\'' +
                ", processIgateIN3LiteFlag='" + processIgateIN3LiteFlag + '\'' +
                ", updateXCase2TaskFlag='" + updateXCase2TaskFlag + '\'' +
                ", depIGTransFlag='" + depIGTransFlag + '\'' +
                ", generateAccountFlag='" + generateAccountFlag + '\'' +
                ", createIGACMFlag='" + createIGACMFlag + '\'' +
                '}';
    }
}