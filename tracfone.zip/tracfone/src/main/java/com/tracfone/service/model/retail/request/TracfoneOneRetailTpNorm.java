package com.tracfone.service.model.retail.request;

public class TracfoneOneRetailTpNorm {
    private String tp2Zip;
    private String tp2CarrierDtl;
    private String rank;
    private String state;
    private String coverage;
    private String coverageNotes;

    public String getTp2Zip() {
        return tp2Zip;
    }

    public void setTp2Zip(String tp2Zip) {
        this.tp2Zip = tp2Zip;
    }

    public String getTp2CarrierDtl() {
        return tp2CarrierDtl;
    }

    public void setTp2CarrierDtl(String tp2CarrierDtl) {
        this.tp2CarrierDtl = tp2CarrierDtl;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCoverage() {
        return coverage;
    }

    public void setCoverage(String coverage) {
        this.coverage = coverage;
    }

    public String getCoverageNotes() {
        return coverageNotes;
    }

    public void setCoverageNotes(String coverageNotes) {
        this.coverageNotes = coverageNotes;
    }

    @Override
    public String toString() {
        return "TracfoneOneRetailTpNorm{" +
                "tp2Zip='" + tp2Zip + '\'' +
                ", tp2CarrierDtl='" + tp2CarrierDtl + '\'' +
                ", rank='" + rank + '\'' +
                ", state='" + state + '\'' +
                ", coverage='" + coverage + '\'' +
                ", coverageNotes='" + coverageNotes + '\'' +
                '}';
    }
}
