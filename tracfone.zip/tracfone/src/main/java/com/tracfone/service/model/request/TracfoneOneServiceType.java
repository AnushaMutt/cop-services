package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * TABLE_OUTAGE_SERVICE_TYPE
 *
 * @author Gaurav.Sharma
 */
public class TracfoneOneServiceType {

    private String dbEnv;
    @Digits(integer = 38, fraction = 0, message = "Obj Id must be a number")
    private String objId;
    @NotNull(message = "Service Type cannot be null")
    @Size(max = 100, message = "Service Type cannot have more than 100 characters")
    private String serviceType;
    @NotNull(message = "Service Type Category cannot be null")
    @Size(max = 100, message = "Service Type Category cannot have more than 100 characters")
    private String serviceTypeCategory;
    @Size(max = 200, message = "Remarks cannot have more than 200 characters")
    private String remarks;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getServiceTypeCategory() {
        return serviceTypeCategory;
    }

    public void setServiceTypeCategory(String serviceTypeCategory) {
        this.serviceTypeCategory = serviceTypeCategory;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "TracfoneOneServiceType{" +
                "dbEnv='" + dbEnv + '\'' +
                ", objId='" + objId + '\'' +
                ", serviceType='" + serviceType + '\'' +
                ", serviceTypeCategory='" + serviceTypeCategory + '\'' +
                ", remarks='" + remarks + '\'' +
                '}';
    }
}
