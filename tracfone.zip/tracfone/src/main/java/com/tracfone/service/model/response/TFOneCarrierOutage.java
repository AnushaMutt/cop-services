package com.tracfone.service.model.response;

public class TFOneCarrierOutage {
    private String objId;
    private String parentShortName;
    private String brand;
    private String channel;
    private String zipCode;
    private String serviceType;
    private String outageType;
    private String startTime;
    private String endTime;
    private String createdBy;
    private String scriptId;
    private String scriptText;
    private String outageDescription;
    private boolean archived;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getParentShortName() {
        return parentShortName;
    }

    public void setParentShortName(String parentShortName) {
        this.parentShortName = parentShortName;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getOutageType() {
        return outageType;
    }

    public void setOutageType(String outageType) {
        this.outageType = outageType;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getScriptId() {
        return scriptId;
    }

    public void setScriptId(String scriptId) {
        this.scriptId = scriptId;
    }

    public String getScriptText() {
        return scriptText;
    }

    public void setScriptText(String scriptText) {
        this.scriptText = scriptText;
    }

    public String getOutageDescription() {
        return outageDescription;
    }

    public void setOutageDescription(String outageDescription) {
        this.outageDescription = outageDescription;
    }

    public boolean isArchived() {
        return archived;
    }

    public void setArchived(boolean archived) {
        this.archived = archived;
    }

    @Override
    public String toString() {
        return "TFOneCarrierOutage{" +
                "objId='" + objId + '\'' +
                ", parentShortName='" + parentShortName + '\'' +
                ", brand='" + brand + '\'' +
                ", channel='" + channel + '\'' +
                ", zipCode='" + zipCode + '\'' +
                ", serviceType='" + serviceType + '\'' +
                ", outageType='" + outageType + '\'' +
                ", startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", scriptId='" + scriptId + '\'' +
                ", scriptText='" + scriptText + '\'' +
                ", outageDescription='" + outageDescription + '\'' +
                ", archived=" + archived +
                '}';
    }
}