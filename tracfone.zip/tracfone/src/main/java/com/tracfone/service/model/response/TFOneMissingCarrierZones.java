package com.tracfone.service.model.response;

import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import java.util.List;

/**
 *
 * @author Gaurav.Sharma
 */
public class TFOneMissingCarrierZones {
    private List<TracfoneOneCarrierZones> successRecords;
    private List<TracfoneOneCarrierZones> failedRecords;

    public List<TracfoneOneCarrierZones> getSuccessRecords() {
        return successRecords;
    }

    public void setSuccessRecords(List<TracfoneOneCarrierZones> successRecords) {
        this.successRecords = successRecords;
    }

    public List<TracfoneOneCarrierZones> getFailedRecords() {
        return failedRecords;
    }

    public void setFailedRecords(List<TracfoneOneCarrierZones> failedRecords) {
        this.failedRecords = failedRecords;
    }

    @Override
    public String toString() {
        return "TFOneMissingCarrierZones{" + "successRecords=" + successRecords + ", failedRecords=" + failedRecords + '}';
    }
}
