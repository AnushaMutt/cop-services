package com.tracfone.service.schedulers;

import com.google.gson.Gson;
import com.tracfone.service.model.event.TracfoneOneReportRequest;
import com.tracfone.service.model.report.TFOneReportTTGraphReport;
import com.tracfone.service.report.workers.throttle.MonitorTTGraphWorkerBean;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Singleton
public class TTMonitorGraphReportJob {

    @EJB
    MonitorTTGraphWorkerBean ttGraphWorkerBean;

    @Inject
    private Event<TracfoneOneReportRequest> tracfoneOneConstantReportEvent;

    private static final Logger LOGGER = LogManager.getLogger(TTMonitorGraphReportJob.class);


//    @Schedule(second = "*/50", minute = "*", hour = "*", persistent = false)
    public void runTTMonitorGraphReport() {
        try {
            List<TFOneReportTTGraphReport> ttMonitorGraphReport = new ArrayList<>();
//            List<TFOneReportTTGraphReport> ttMonitorGraphReport = ttGraphWorkerBean.runTTMonitorGraphReport();

            if (!ttMonitorGraphReport.isEmpty()) {
                Gson gson = new Gson();
                TracfoneOneReportRequest reportRequest = new TracfoneOneReportRequest();
                reportRequest.setJsonResponse(gson.toJson(ttMonitorGraphReport));
                reportRequest.setReportName(TracfoneOneConstantReport.TRACFONE_REPORTNAME_TT_MONITOR_GRAPH);
                tracfoneOneConstantReportEvent.fire(reportRequest);

            } else {
                LOGGER.info("Throttle Monitor Graph WorkerBean returned an empty response.");
            }
        } catch (Exception ex) {
            LOGGER.error("Throttle Monitor Graph report could not be retrieved because of an exception ", ex);
        }
    }

}
