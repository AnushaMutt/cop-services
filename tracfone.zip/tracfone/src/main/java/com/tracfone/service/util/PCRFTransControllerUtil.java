package com.tracfone.service.util;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Gaurav.Sharma
 */
public class PCRFTransControllerUtil {
    protected static final Map<String, String> columnMap = new HashMap<>();

    private PCRFTransControllerUtil() {
        throw new IllegalStateException("Utility class");
    }

    static {
        // PCRF Transaction Column names with Table parent.
        PCRFTransControllerUtil.columnMap.put("objId", "OBJID");
        PCRFTransControllerUtil.columnMap.put("min", "MIN");
        PCRFTransControllerUtil.columnMap.put("esn", "ESN");
        PCRFTransControllerUtil.columnMap.put("subscriberId", "SUBSCRIBER_ID");
        PCRFTransControllerUtil.columnMap.put("groupId", "GROUP_ID");
        PCRFTransControllerUtil.columnMap.put("orderType", "ORDER_TYPE");
        PCRFTransControllerUtil.columnMap.put("phoneManufacturer", "PHONE_MANUFACTURER");
        PCRFTransControllerUtil.columnMap.put("actionType", "ACTION_TYPE");
        PCRFTransControllerUtil.columnMap.put("sim", "SIM");
        PCRFTransControllerUtil.columnMap.put("zipCode", "ZIPCODE");
        PCRFTransControllerUtil.columnMap.put("servicePlanId", "SERVICE_PLAN_ID");
        PCRFTransControllerUtil.columnMap.put("caseId", "CASE_ID");
        PCRFTransControllerUtil.columnMap.put("pcrfStatusCode", "PCRF_STATUS_CODE");
        PCRFTransControllerUtil.columnMap.put("statusMessage", "STATUS_MESSAGE");
        PCRFTransControllerUtil.columnMap.put("webObjId", "WEB_OBJID");
        PCRFTransControllerUtil.columnMap.put("brand", "BRAND");
        PCRFTransControllerUtil.columnMap.put("sourceSystem", "SOURCESYSTEM");
        PCRFTransControllerUtil.columnMap.put("template", "TEMPLATE");
        PCRFTransControllerUtil.columnMap.put("ratePlan", "RATE_PLAN");
        PCRFTransControllerUtil.columnMap.put("retryCount", "RETRY_COUNT");
        PCRFTransControllerUtil.columnMap.put("dataUsage", "DATA_USAGE");
        PCRFTransControllerUtil.columnMap.put("hiSpeedDataUsage", "HI_SPEED_DATA_USAGE");
        PCRFTransControllerUtil.columnMap.put("conversionFactor", "CONVERSION_FACTOR");
        PCRFTransControllerUtil.columnMap.put("dealerId", "DEALER_ID");
        PCRFTransControllerUtil.columnMap.put("denomination", "DENOMINATION");
        PCRFTransControllerUtil.columnMap.put("pcrfParentName", "PCRF_PARENT_NAME");
        PCRFTransControllerUtil.columnMap.put("propagateFlag", "PROPAGATE_FLAG");
        PCRFTransControllerUtil.columnMap.put("servicePlanType", "SERVICE_PLAN_TYPE");
        PCRFTransControllerUtil.columnMap.put("partInstStatus", "PART_INST_STATUS");
        PCRFTransControllerUtil.columnMap.put("phoneModel", "PHONE_MODEL");
        PCRFTransControllerUtil.columnMap.put("contentDeliveryFormat", "CONTENT_DELIVERY_FORMAT");
        PCRFTransControllerUtil.columnMap.put("language", "LANGUAGE");
        PCRFTransControllerUtil.columnMap.put("wfMacId", "WF_MAC_ID");
        PCRFTransControllerUtil.columnMap.put("mdn", "MDN");
        PCRFTransControllerUtil.columnMap.put("pcrfCos", "PCRF_COS");
        PCRFTransControllerUtil.columnMap.put("contactObjId", "CONTACT_OBJID");
        PCRFTransControllerUtil.columnMap.put("imsi", "IMSI");
        PCRFTransControllerUtil.columnMap.put("lifeLineId", "LIFELINE_ID");
        PCRFTransControllerUtil.columnMap.put("programParameterId", "PROGRAM_PARAMETER_ID");
        PCRFTransControllerUtil.columnMap.put("vmbcCertificationFlag", "VMBC_CERTIFICATION_FLAG");
        PCRFTransControllerUtil.columnMap.put("charField1", "CHAR_FIELD_1");
        PCRFTransControllerUtil.columnMap.put("charField2", "CHAR_FIELD_2");
        PCRFTransControllerUtil.columnMap.put("charField3", "CHAR_FIELD_3");
        PCRFTransControllerUtil.columnMap.put("addonsFlag", "ADDONS_FLAG");
        PCRFTransControllerUtil.columnMap.put("rcsEnableFlag", "RCS_ENABLE_FLAG");
        PCRFTransControllerUtil.columnMap.put("posaFlag", "POSA_FLAG");
        PCRFTransControllerUtil.columnMap.put("unlockStatus", "UNLOCK_STATUS");
    }

    /**
     * @param key
     * @return
     */
    public static String getDBColumnName(String key) {
        return PCRFTransControllerUtil.columnMap.get(key);
    }
}
