package com.tracfone.service.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Gaurav.Sharma
 */
public class CarrierZonesControllerUtil {

    // create map to store carrier names
    protected static final Map<String, List<String>> carrierMap = new HashMap<>();

    // create map to store zones
    protected static final Map<String, String> zones = new HashMap<>();

    //Create map to store states
    protected static final Map<String, String> states = new HashMap<>();

    //Create map to store Sim profile1
    protected static final Map<String, String> simProfile = new HashMap<>();

    //Create map to store Sim profile2
    protected static final Map<String, String> simProfile2 = new HashMap<>();

    private static String VERIZON_WIRELESS = "VERIZON WIRELESS";
    private static String VERIZON_SAFELINK = "VERIZON SAFELINK";
    private static String VERIZON_WIRELESS_PPP = "VERIZON WIRELESS_PPP";
    private static String ATT_WIRELESS = "AT&T WIRELESS";
    private static String ATT_WIRELESS_LL = "AT&T WIRELESS LL";
    private static String ATT_PREPAY_PLATFORM = "AT&T PREPAY PLATFORM";
    private static String T_MOBILE = "T-MOBILE";
    private static String T_MOBILE_SAFELINK = "T-MOBILE SAFELINK";
    private static String T_MOBILE_PREPAY_PLATFORM = "T-MOBILE PREPAY PLATFORM";
    private static String T_MOBILE_SIMPLE = "T-MOBILE SIMPLE";
    private static String T_MOBILE_UNLIMITED = "T-MOBILE UNLIMITED";
    private static String T_MOBILE_WFM = "T-MOBILE WFM";
    private static String TF64SIMC4 = "TF64SIMC4";
    private static String TF64SIMT5 = "TF64SIMT5";
    private static String TFSIMC4 = "TFSIMC4";
    private static String TFSIMT5 = "TFSIMT5";
    private static String CLARO = "CLARO";
    private static String CLARO_LL = "CLARO LL";
    private static String TF64SIMCL7 = "TF64SIMCL7";

    static {
        List<String> vzw = new ArrayList<>(1);
        vzw.add(VERIZON_WIRELESS);
        vzw.add(VERIZON_SAFELINK);
        vzw.add(VERIZON_WIRELESS_PPP);

        List<String> att = new ArrayList<>(1);
        att.add(ATT_WIRELESS);
        att.add(ATT_WIRELESS_LL);
        att.add(ATT_PREPAY_PLATFORM);

        List<String> tmo = new ArrayList<>(1);
        tmo.add(T_MOBILE);
        tmo.add(T_MOBILE_SAFELINK);
        tmo.add(T_MOBILE_PREPAY_PLATFORM);
        tmo.add(T_MOBILE_SIMPLE);
        tmo.add(T_MOBILE_UNLIMITED);
        tmo.add(T_MOBILE_WFM);

        List<String> claro = new ArrayList<>(1);
        claro.add(CLARO);
        claro.add(CLARO_LL);

        CarrierZonesControllerUtil.carrierMap.put("VERIZON", vzw);
        CarrierZonesControllerUtil.carrierMap.put("ATT", att);
        CarrierZonesControllerUtil.carrierMap.put("TMOBILE", tmo);
        CarrierZonesControllerUtil.carrierMap.put(CLARO, claro);

        //Zones
        //VERIZON
        CarrierZonesControllerUtil.zones.put(VERIZON_WIRELESS, "VZW_TF-");
        CarrierZonesControllerUtil.zones.put(VERIZON_SAFELINK, "VZW_SL-");
        CarrierZonesControllerUtil.zones.put(VERIZON_WIRELESS_PPP, "VZW_ST-");
        //ATT
        CarrierZonesControllerUtil.zones.put(ATT_WIRELESS, "ATT_TF-");
        CarrierZonesControllerUtil.zones.put(ATT_WIRELESS_LL, "ATT_SL-");
        CarrierZonesControllerUtil.zones.put(ATT_PREPAY_PLATFORM, "ATT_ST-");
        //TMO
        CarrierZonesControllerUtil.zones.put(T_MOBILE, "TMO_TF-");
        CarrierZonesControllerUtil.zones.put(T_MOBILE_SAFELINK, "TMO_SL-");
        CarrierZonesControllerUtil.zones.put(T_MOBILE_PREPAY_PLATFORM, "TMO_ST-");
        CarrierZonesControllerUtil.zones.put(T_MOBILE_SIMPLE, "TMO_SM-");
        CarrierZonesControllerUtil.zones.put(T_MOBILE_UNLIMITED, "TMO_UN-");
        CarrierZonesControllerUtil.zones.put(T_MOBILE_WFM, "WFM");

        //Claro
        CarrierZonesControllerUtil.zones.put(CLARO, CLARO);
        CarrierZonesControllerUtil.zones.put(CLARO_LL, "CLARO_SAFELINK");

        //States
        CarrierZonesControllerUtil.states.put("Alabama", "AL");
        CarrierZonesControllerUtil.states.put("Alaska", "AK");
        CarrierZonesControllerUtil.states.put("Arizona", "AZ");
        CarrierZonesControllerUtil.states.put("Arkansas", "AR");
        CarrierZonesControllerUtil.states.put("California", "CA");
        CarrierZonesControllerUtil.states.put("Colorado", "CO");
        CarrierZonesControllerUtil.states.put("Connecticut", "CT");
        CarrierZonesControllerUtil.states.put("Delaware", "DE");
        CarrierZonesControllerUtil.states.put("District of Columbia", "DC");
        CarrierZonesControllerUtil.states.put("Florida", "FL");
        CarrierZonesControllerUtil.states.put("Georgia", "GA");
        CarrierZonesControllerUtil.states.put("Hawaii", "HI");

        CarrierZonesControllerUtil.states.put("Idaho", "ID");
        CarrierZonesControllerUtil.states.put("Illinois", "IL");
        CarrierZonesControllerUtil.states.put("Indiana", "IN");
        CarrierZonesControllerUtil.states.put("Iowa", "IA");
        CarrierZonesControllerUtil.states.put("Kansas", "KS");
        CarrierZonesControllerUtil.states.put("Kentucky", "KY");
        CarrierZonesControllerUtil.states.put("Louisiana", "LA");
        CarrierZonesControllerUtil.states.put("Maine", "ME");
        CarrierZonesControllerUtil.states.put("Maryland", "MD");
        CarrierZonesControllerUtil.states.put("Massachusetts", "MA");
        CarrierZonesControllerUtil.states.put("Michigan", "MI");
        CarrierZonesControllerUtil.states.put("Minnesota", "MN");

        CarrierZonesControllerUtil.states.put("Mississippi", "MS");
        CarrierZonesControllerUtil.states.put("Missouri", "MO");
        CarrierZonesControllerUtil.states.put("Montana", "MT");
        CarrierZonesControllerUtil.states.put("Nebraska", "NE");
        CarrierZonesControllerUtil.states.put("Nevada", "NV");
        CarrierZonesControllerUtil.states.put("New Hampshire", "NH");
        CarrierZonesControllerUtil.states.put("New Jersey", "NJ");
        CarrierZonesControllerUtil.states.put("New Mexico", "NM");
        CarrierZonesControllerUtil.states.put("New York", "NY");
        CarrierZonesControllerUtil.states.put("North Carolina", "NC");
        CarrierZonesControllerUtil.states.put("North Dakota", "ND");
        CarrierZonesControllerUtil.states.put("Ohio", "OH");

        CarrierZonesControllerUtil.states.put("Oklahoma", "OK");
        CarrierZonesControllerUtil.states.put("Oregon", "OR");
        CarrierZonesControllerUtil.states.put("Pennsylvania", "PA");
        CarrierZonesControllerUtil.states.put("Rhode Island", "RI");
        CarrierZonesControllerUtil.states.put("South Carolina", "SC");
        CarrierZonesControllerUtil.states.put("South Dakota", "SD");
        CarrierZonesControllerUtil.states.put("Tennessee", "TN");
        CarrierZonesControllerUtil.states.put("Texas", "TX");
        CarrierZonesControllerUtil.states.put("Utah", "UT");
        CarrierZonesControllerUtil.states.put("Vermont", "VT");
        CarrierZonesControllerUtil.states.put("Virginia", "VA");
        CarrierZonesControllerUtil.states.put("Washington", "WA");

        CarrierZonesControllerUtil.states.put("West Virginia", "WV");
        CarrierZonesControllerUtil.states.put("Wisconsin", "WI");
        CarrierZonesControllerUtil.states.put("Wyoming", "WY");

        //Sim Profile
        //VERIZON
        CarrierZonesControllerUtil.simProfile.put(VERIZON_WIRELESS, null);
        CarrierZonesControllerUtil.simProfile.put(VERIZON_SAFELINK, null);
        CarrierZonesControllerUtil.simProfile.put(VERIZON_WIRELESS_PPP, null);
        //ATT
        CarrierZonesControllerUtil.simProfile.put(ATT_WIRELESS, TF64SIMC4);
        CarrierZonesControllerUtil.simProfile.put(ATT_WIRELESS_LL, TF64SIMC4);
        CarrierZonesControllerUtil.simProfile.put(ATT_PREPAY_PLATFORM, TF64SIMC4);
        //TMO
        CarrierZonesControllerUtil.simProfile.put(T_MOBILE, TF64SIMT5);
        CarrierZonesControllerUtil.simProfile.put(T_MOBILE_SAFELINK, TF64SIMT5);
        CarrierZonesControllerUtil.simProfile.put(T_MOBILE_PREPAY_PLATFORM, TF64SIMT5);
        CarrierZonesControllerUtil.simProfile.put(T_MOBILE_SIMPLE, "SM64PSIMT5");
        CarrierZonesControllerUtil.simProfile.put(T_MOBILE_UNLIMITED, TF64SIMT5);
        CarrierZonesControllerUtil.simProfile.put(T_MOBILE_WFM, "WFM128PSIMT5");
        //CLARO
        CarrierZonesControllerUtil.simProfile.put(CLARO, TF64SIMCL7);
        CarrierZonesControllerUtil.simProfile.put(CLARO_LL, TF64SIMCL7);

        //Sim Profile2
        //VERIZON
        CarrierZonesControllerUtil.simProfile2.put(VERIZON_WIRELESS, null);
        CarrierZonesControllerUtil.simProfile.put(VERIZON_SAFELINK, null);
        CarrierZonesControllerUtil.simProfile.put(VERIZON_WIRELESS_PPP, null);
        //ATT
        CarrierZonesControllerUtil.simProfile2.put(ATT_WIRELESS, TFSIMC4);
        CarrierZonesControllerUtil.simProfile2.put(ATT_WIRELESS_LL, TFSIMC4);
        CarrierZonesControllerUtil.simProfile2.put(ATT_PREPAY_PLATFORM, TFSIMC4);
        //TMO
        CarrierZonesControllerUtil.simProfile2.put(T_MOBILE, TFSIMT5);
        CarrierZonesControllerUtil.simProfile2.put(T_MOBILE_SAFELINK, TFSIMT5);
        CarrierZonesControllerUtil.simProfile2.put(T_MOBILE_PREPAY_PLATFORM, TFSIMT5);
        CarrierZonesControllerUtil.simProfile2.put(T_MOBILE_SIMPLE, "SM64PSIMT5");
        CarrierZonesControllerUtil.simProfile2.put(T_MOBILE_UNLIMITED, TFSIMT5);
        CarrierZonesControllerUtil.simProfile2.put(T_MOBILE_WFM, "WFM128PSIMT5");
        //CLARO
        CarrierZonesControllerUtil.simProfile2.put(CLARO, TF64SIMCL7);
        CarrierZonesControllerUtil.simProfile2.put(CLARO_LL, TF64SIMCL7);
    }

    /**
     * @param key
     * @return
     */
    public static List<String> getCarrierName(String key) {
        return CarrierZonesControllerUtil.carrierMap.get(key);
    }

    /**
     * @param key
     * @return
     */
    public static String getZones(String key) {
        return CarrierZonesControllerUtil.zones.get(key);
    }

    /**
     * @param key
     * @return
     */
    public static String getStates(String key) {
        return CarrierZonesControllerUtil.states.get(key);
    }

    /**
     * @param key
     * @return
     */
    public static String getSimProfile(String key) {
        return CarrierZonesControllerUtil.simProfile.get(key);
    }

    /**
     * @param key
     * @return
     */
    public static String getSimProfile2(String key) {
        return CarrierZonesControllerUtil.simProfile2.get(key);
    }
}
