package com.tracfone.service.model.request;

import java.util.*;

/**
 * @author Pritesh.Singh
 */
public class TracfoneOneTTransactionNotes {
    private String dbEnv;
    private List<String> objIds;
    private String notes;

    public TracfoneOneTTransactionNotes() {
        objIds = new ArrayList<>(1);
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public List<String> getObjIds() {
        return objIds;
    }

    public void setObjIds(List<String> objIds) {
        this.objIds = objIds;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    @Override
    public String toString() {
        return "TracfoneOneTTransactionNotes{" +
                "dbEnv='" + dbEnv + '\'' +
                ", objIds=" + objIds +
                ", notes='" + notes + '\'' +
                '}';
    }
}
