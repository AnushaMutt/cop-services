/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

import java.util.List;

/**
 *
 * @author Srinivas Murthy Pulavarthy
 */
public class TFOneAdminProfile {

   //String userName;
   // String email;
    public TFOneAdminUser tfUser;
    public List<TFOneAdminGroup> tfGroups;
    public TFOneAdminRole tfRole;

    public TFOneAdminUser getTfUser() {
        return tfUser;
    }

    public void setTfUser(TFOneAdminUser tfUser) {
        this.tfUser = tfUser;
    }

    

    public List<TFOneAdminGroup> getTfGroups() {
        return tfGroups;
    }

    public void setTfGroups(List<TFOneAdminGroup> tfGroups) {
        this.tfGroups = tfGroups;
    }

    public TFOneAdminRole getTfRole() {
        return tfRole;
    }

    public void setTfRole(TFOneAdminRole tfRole) {
        this.tfRole = tfRole;
    }

}
