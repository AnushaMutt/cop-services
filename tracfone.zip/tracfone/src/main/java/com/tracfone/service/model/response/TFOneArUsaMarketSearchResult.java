package com.tracfone.service.model.response;

import com.tracfone.service.model.request.TracfoneonePaginationSearch;

import java.util.ArrayList;
import java.util.List;

public class TFOneArUsaMarketSearchResult {
    private TracfoneonePaginationSearch paginationSearch;
    private List<TFOneArUsaMarket> arUsaMarkets;

    public TFOneArUsaMarketSearchResult() {
        arUsaMarkets = new ArrayList<>();
    }

    public TracfoneonePaginationSearch getPaginationSearch() {
        return paginationSearch;
    }

    public void setPaginationSearch(TracfoneonePaginationSearch paginationSearch) {
        this.paginationSearch = paginationSearch;
    }

    public List<TFOneArUsaMarket> getArUsaMarkets() {
        return arUsaMarkets;
    }

    public void setArUsaMarkets(List<TFOneArUsaMarket> arUsaMarkets) {
        this.arUsaMarkets = arUsaMarkets;
    }

    @Override
    public String toString() {
        return "TFArUsaMarketSearchResult{" +
                "paginationSearch=" + paginationSearch +
                ", arUsaMarkets=" + arUsaMarkets +
                '}';
    }
}
