/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.util;

/**
 * @author user
 */
public interface TracfoneOneConstant {

    String CANCELLED = "CANCELLED";
    String ASSIGNED = "ASSIGNED";
    String TASK_DETAILS = "TASK_DETAILS";
    String ID_DETAIL = "ID_DETAIL";
    public static String BUCKET_ = "BUCKET_";
    String INSERT_TRANSACTION_BUCKETS_STATEMENT = "      insert into gw1.ig_transaction_buckets(transaction_id,bucket_id,recharge_date,bucket_balance,bucket_value,expiration_date,direction,benefit_type,bucket_type,bucket_usage,data_expiration_date,unit_of_measure,bucket_group,bucket_requirement,auto_renew_flag,auto_renew_frequency,auto_renew_value,auto_renew_day, bucket_action)\n";

    //Fetch Size for View Action Item Id
    int FETCH_SIZE = 5000;

    //PURGE Job Constants for User Audit
    int NUMBER_OF_DAYS_BEFORE_AUDIT_TO_PURGE = -7; //days

    //PURGE Job Constants For Reports
    int NUMBER_OF_DAYS_BEFORE_REPORT_TO_PURGE = -7; //days

    //PURGE Job Constants FOR User Task
    int NUMBER_OF_DAYS_BEFORE_USER_TASK_TO_PURGE = -10; //days

    //PURGE Job Constants FOR User Hisotry
    int NUMBER_OF_DAYS_BEFORE_USER_HISTORY_TO_PURGE = -10; //days


    //DEACTIVATION Job Constants
    int NUMBER_OF_DAYS_TO_DEACTIVATE = -10; //days
    /**
     * Administration level error codes
     */
    int TRACFONE_ROLEPRIORITY_ROOT = 100;
    int TRACFONE_ROLEPRIORITY_ADMIN = 2;

    String TRACFONE_INVALID_LOGIN_ERROR_CODE = "TFE001";
    String TRACFONE_INVALID_LOGIN_ERROR_MESSAGE = "Invalid Login. Please check your User/Password credentials.";

    String TRACFONE_INVALID_TRACFONEONE_LOGIN_ERROR_CODE = "TFE002";
    String TRACFONE_INVALID_TRACFONEONE_LOGIN_ERROR_MESSAGE = "User not found.";

    String TRACFONE_INVALID_TRACFONEONE_LOGOUT_ERROR_CODE = "TFE002-1";
    String TRACFONE_INVALID_TRACFONEONE_LOGOUT_ERROR_MESSAGE = "Unable to remove session to logout user.";

    String TRACFONE_ROLES_RETRIEVAL_ERROR_CODE = "TFE003";
    String TRACFONE_ROLES_RETRIEVAL_ERROR_MESSAGE = "User Role cannot be retrieved/verified.";

    String TRACFONE_USERS_RETRIEVAL_ERROR_CODE = "TFE004";
    String TRACFONE_USERS_RETRIEVAL_ERROR_MESSAGE = "Users List failed to be retrieved.";

    String TRACFONE_GROUP_RETRIEVAL_ERROR_CODE = "TFE005";
    String TRACFONE_GROUP_RETRIEVAL_ERROR_MESSAGE = "Group details could not be retrieved.";

    String TRACFONE_PROFILE_RETRIEVAL_ERROR_CODE = "TFE006";
    String TRACFONE_PROFILE_RETRIEVAL_ERROR_MESSAGE = "Profile could not be retrieved, user has incomplete profile.";

    String TRACFONE_USER_UPDATE_ERROR_CODE = "TFE007";
    String TRACFONE_USER_UPDATE_ERROR_MESSAGE = "User update failed.";
    String TRACFONE_USER_UPDATE_BADID_ERROR_MESSAGE = "User update failed. User Invalid User ID.";
    String TRACFONE_USER_UPDATE_NOTINDB_ERROR_MESSAGE = "User update failed. User does not exists.";

    String TRACFONE_USER_CREATE_ERROR_CODE = "TFE008";
    String TRACFONE_USER_CREATE_ERROR_MESSAGE = "User creation failed.";

    String TRACFONE_GROUP_CREATE_ERROR_CODE = "TFE009";
    String TRACFONE_GROUP_CREATE_ERROR_MESSAGE = "Failed to create Group.";

    String TRACFONE_REPORT_MONITOR_ERROR_CODE = "TFE012";
    String TRACFONE_REPORT_MONITOR_ERROR_MESSAGE = "Retrieve monitor report error.";

    String TRACFONE_AUDIT_HISTORY_RETRIEVAL_ERROR_CODE = "TFE014";
    String TRACFONE_AUDIT_HISTORY_RETRIEVAL_ERROR_MESSAGE = "Audit History cannot be retrieved.";

    String TRACFONE_REPORT_ADHOC_MONITOR_ERROR_CODE = "TFE015";
    String TRACFONE_REPORT_ADHOC_MONITOR_ERROR_MESSAGE = "Unable to retrieve adhoc monitor report.";

    String TRACFONE_DELETE_PROFILE_ERROR_CODE = "TFE016";
    String TRACFONE_DELETE_PROFILE_ERROR_MESSAGE = "Profile could not be deleted.";

    String TRACFONE_ACTION_RETRIEVAL_ERROR_CODE = "TFE017";
    String TRACFONE_ACTION_RETRIEVAL_ERROR_MESSAGE = "List of actions failed to be loaded.";

    String TRACFONE_GROUP_UPDATE_ERROR_CODE = "TFE018";
    String TRACFONE_GROUP_UPDATE_ERROR_MESSAGE = "Failed to update group with actions requested.";

    String TRACFONE_USER_LOOKUP_ERROR_CODE = "TFE019";
    String TRACFONE_USER_LOOKUP_ERROR_MESSAGE = "Invalid user name";

    String TRACFONE_REPORT_ALL_IG_FAILURES_ERROR_CODE = "TFE020";
    String TRACFONE_REPORT_ALL_IG_FAILURES_ERROR_MESSAGE = "Retrieve IG Failures report error.";

    String TRACFONE_PURGE_AUDIT_ERROR_CODE = "TFE021";
    String TRACFONE_PURGE_AUDIT_ERROR_MESSAGE = "Failed to run the Purge job for Audit Table.";

    String TRACFONE_PURGE_REPORT_ERROR_CODE = "TFE022";
    String TRACFONE_PURGE_REPORT_ERROR_MESSAGE = "Failed to run the Purge job for Report Table.";

    String TRACFONE_REPORT_MONITOR_GRAPH_ERROR_CODE = "TFE023";
    String TRACFONE_REPORT_MONITOR_GRAPH_ERROR_MESSAGE = "Retrieve monitor graph report error.";

    String TRACFONE_DEACTIVATE_JOB_REPORT_ERROR_CODE = "TFE022";
    String TRACFONE_DEACTIVATE_JOB_ERROR_MESSAGE = "Failed to run the deactivation job.";

    String TRACFONE_USER_TASK_CREATE_ERROR_CODE = "TFE023";
    String TRACFONE_USER_TASK_CREATE_ERROR_MESSAGE = "Failed to create User Task.";

    String TRACFONE_USER_TASK_UPDATE_ERROR_CODE = "TFE024";
    String TRACFONE_USER_TASK_UPDATE_ERROR_MESSAGE = "Failed to update User Task.";

    String TRACFONE_USER_TASK_RETRIEVAL_ERROR_CODE = "TFE025";
    String TRACFONE_USER_TASK_RETRIEVAL_ERROR_MESSAGE = "User Task cannot be retrieved.";

    String TRACFONE_PURGE_USER_HISTORY_ERROR_CODE = "TFE026";
    String TRACFONE_PURGE_USER_HISTORY_ERROR_MESSAGE = "Failed to run the Purge job for User History Table.";

    String TRACFONE_PURGE_USER_TASK_ERROR_CODE = "TFE027";
    String TRACFONE_PURGE_USER_TASK_ERROR_MESSAGE = "Failed to run the Purge job for User Task Table.";

    String TRACFONE_DUPLICATE_USER_ERROR_CODE = "TFE028";
    String TRACFONE_DUPLICATE_USER_ERROR_MESSAGE = "This user name already exists";

    String TRACFONE_BULK_INSERT_ERROR_CODE = "TFE030";
    String TRACFONE_BULK_INSERT_ERROR_MESSAGE = "Failed to insert Bulk IG Transactions";

    String TRACFONE_GET_ALL_USER_TASKS_ERROR_CODE = "TFE031";
    String TRACFONE_GET_ALL_USER_TASKS_ERROR_MESSAGE = "User Task could not be retrieved.";

    String TRACFONE_REASSIGN_TRANSACTION_ERROR_CODE = "TFE032";
    String TRACFONE_REASSIGN_TRANSACTION_ERROR_CODE_MESSAGE = "Unable to reassign transactions";

    String TRACFONE_DUPLICATE_SIGNATURE_ERROR_CODE = "TFE033";
    String TRACFONE_DUPLICATE_SIGNATURE_ERROR_MESSAGE = "This signature already exists";

    String TRACFONE_GET_ASSIGN_REPORT_ERROR_CODE = "TFE034";
    String TRACFONE_GET_ASSIGN_REPORT_ERROR_MESSAGE = "Unable to get assign report";

    String TRACFONE_GET_TRANSACTION_REPORT_ERROR_CODE = "TFE035";
    String TRACFONE_GET_TRANSACTION_REPORT_ERROR_MESSAGE = "Unable to get transaction type report";

    String TRACFONE_REPORT_ALL_TT_FAILURES_ERROR_CODE = "TFE036";
    String TRACFONE_REPORT_ALL_TT_FAILURES_ERROR_MESSAGE = "Unable to retrieve TT Failures report";

    String TRACFONE_REPORT_TT_MONITOR_ERROR_CODE = "TFE037";
    String TRACFONE_REPORT_TT_MONITOR_ERROR_MESSAGE = "Unable to retrieve TT Monitor report";

    String TRACFONE_REPORT_ADHOC_TT_MONITOR_ERROR_CODE = "TFE038";
    String TRACFONE_REPORT_ADHOC_TT_MONITOR_ERROR_MESSAGE = "Unable to retrieve Adhoc TT Monitor report.";

    String TRACFONE_REPORT_ADHOC_PCRF_MONITOR_ERROR_CODE = "TFE039";
    String TRACFONE_REPORT_ADHOC_PCRF_MONITOR_ERROR_MESSAGE = "Unable to retrieve Adhoc PCRF Monitor report.";

    String TRACFONE_REPORT_ALL_PCRF_FAILURES_ERROR_CODE = "TFE040";
    String TRACFONE_REPORT_ALL_PCRF_FAILURES_ERROR_MESSAGE = "Unable to retrieve PCRF Failures report";

    String TRACFONE_REPORT_TT_MONITOR_GRAPH_ERROR_CODE = "TFE041";
    String TRACFONE_REPORT_TT_MONITOR_GRAPH_ERROR_MESSAGE = "Unable to retrieve TT Monitor Status Graph report";

    String TRACFONE_REPORT_PCRF_MONITOR_GRAPH_ERROR_CODE = "TFE042";
    String TRACFONE_REPORT_PCRF_MONITOR_GRAPH_ERROR_MESSAGE = "Unable to retrieve PCRF Monitor Status Graph report";

    String TRACFONE_REPORT_PCRF_MONITOR_ERROR_CODE = "TFE043";
    String TRACFONE_REPORT_PCRF_MONITOR_ERROR_MESSAGE = "Unable to retrieve PCRF Monitor report";
    /**
     * Authentication/Authorization level error codes
     */
    String TRACFONE_INVALID_TOKEN_ERROR_CODE = "TFE100";
    String TRACFONE_INVALID_TOKEN_ERROR_MESSAGE = "Invalid Authentication Token.";

    String TRACFONE_INVALID_ROLE_ERROR_CODE = "TFE101";
    String TRACFONE_INVALID_ROLE_ERROR_MESSAGE = "Invalid Role priority for requested action.";

    String TRACFONE_UNAUTHORIZED_ERROR_CODE = "TFE102";
    String TRACFONE_UNAUTHORIZED_ERROR_MESSAGE = "User not authorzied to access the requested resource.";

    /**
     * Database level error codes
     */
    String TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE = "TFE200";
    String TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE_NAME = "TFE200A";
    String TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE = "Unable to get response from DB.";

    String TRACFONE_INSERT_IG_REPORT_ERROR_CODE = "TFE201";
    String TRACFONE_INSERT_IG_REPORT_ERROR_MESSAGE = "Error while inserting IG Report record.";

    String TRACFONE_DATASOURCE_INALIDTID_ERROR_CODE = "TFE204";
    String TRACFONE_DATASOURCE_INALIDTID_ERROR_MESSAGE = "Invalid transaction ID received.";

    String TRACFONE_DATASOURCE_ENV_ERROR_CODE = "TFE205";
    String TRACFONE_DATASOURCE_ENV_ERROR_MESSAGE = "Invalid database environment received.";

    String TRACFONE_DATASOURCE_AID_SEQ_ERROR_CODE = "TFE206";
    String TRACFONE_DATASOURCE_AID_SEQ_ERROR_MESSAGE = "Error while retrieving AID sequence";

    String TRACFONE_DATASOURCE_QUERY_TIMEOUT_ERROR_CODE = "TFE222";
    String TRACFONE_DATASOURCE_QUERY_TIMEOUT_ERROR_MESSAGE = "Query Timedout. Please refine your search criteria.";

    String TRACFONE_VIEWTRANSACTION_PRIMARYMISSING_CODE = "TFE304";
    String TRACFONE_VIEWTRANSACTION_PRIMARYMISSING_MESSAGE = "Mandatory field missing. At least one primary field must be present.";


    // Success constants messages.
    String TRACFONE_USER_CREATE_SUCCESS = "User Profile created successfully.";
    String TRACFONE_USER_UPDATE_SUCCESS = "User Profile updated successfully.";
    String TRACFONE_USER_REMOVED_SUCCESS = "User Profile has been deleted successfully.";
    String TRACFONE_GROUP_CREATE_SUCCESS = "Group created successfully.";
    String TRACFONE_GROUP_UPDATE_SUCCESS = "Group updated successfully.";
    String TRACFONE_USER_TASK_CREATE_SUCCESS = "User Task created successfully.";

    /**
     * Buckets
     */
    String KEY_BUCKET_ID = "v_bucket_id1";
    String KEY_BUCKET_BALANCE = "v_bucket_bal";
    String KEY_BUCKET_BENEFIT = "v_bucket_benefit";
    String KEY_BUCKET_TYPE = "v_bucket_type";
    String KEY_BUCKET_DATE = "v_expire_date";

    /**
     * Database Queries
     */
    String TRACFONE_BUCKET_DETAIL_SELECT_QUERY = "select \n"
            + "    igb.BUCKET_ID,\n"
            + "    igb.RECHARGE_DATE,\n"
            + "    igb.BUCKET_BALANCE,\n"
            + "    igb.BUCKET_VALUE,\n"
            + "    igb.EXPIRATION_DATE,\n"
            + "    igb.DATA_EXPIRATION_DATE,\n"
            + "    igb.UNIT_OF_MEASURE,\n"
            + "    igb.BUCKET_GROUP,\n"
            + "    igb.BUCKET_REQUIREMENT,\n"
            + "    igb.AUTO_RENEW_FLAG,\n"
            + "    igb.AUTO_RENEW_FREQUENCY,\n"
            + "    igb.AUTO_RENEW_VALUE,\n"
            + "    igb.AUTO_RENEW_DAY,\n"
            + "    igb.DIRECTION,\n"
            + "    igb.BENEFIT_TYPE,\n"
            + "    igb.BUCKET_TYPE,\n"
            + "    igb.BUCKET_USAGE,\n"
            + "    igb.BUCKET_ACTION, \n"
            + "    ig.TEMPLATE, \n"
            + "   (select BUCKET_DESC from gw1.ig_buckets where bucket_id = igb.bucket_id and rownum =1) BUCKET_DESC \n"
            + " from gw1.ig_transaction ig, gw1.ig_transaction_buckets igb"
            + " where ig.transaction_id = igb.transaction_id \n"
            + " and igb.transaction_id = ?";

    String TRACFONE_TOOL_NGP_SELECT_QUERY = "SELECT * from C_RTL_ZIP_GEOLOC_BUFF where ZIP = ? and DISTANCE <= ? ";

    String TRACFONE_REQUEUE_QUERY = "UPDATE ig_transaction\n"
            + "SET    status_message='',\n"
            + "       status= 'Q'\n"
            + "WHERE 1=1 ";

    String STRING = "        \n";
    String END_IF = "end if;\n";
    String END_IF1 = "     end if;\n";
    String END_IF2 = "     end if; \n";
    String TRACFONE_INSERT_TRANSACTION
            = "declare counter                 number      :=0;\n"
            + STRING
            + "        user_history_id         number :=0;\n"
            + "        trans_hold              number(22,0);\n"
            + "        v_app_sys               varchar2(30):=?;\n"
            + "        v_rate_plan_profile_id  number:=?;\n"
            + "        v_carr_feat             number:=?;  \n"
            + "        v_template              varchar2(30):=?;\n"
            + "        v_action_item_id        varchar2(30):=?;\n"
            + "        v_carrier_id            varchar2(30):=?;\n"
            + "        v_order_type            varchar2(30):=?;\n"
            + "        v_esn                   varchar2(30):=?;\n"
            + "        v_esn_hex               varchar2(30):=?;\n"
            + "        v_iccid                 varchar2(30):=?;\n"
            + "        v_min                   varchar2(30):=?;\n"
            + "        v_msid                  varchar2(30):=?;\n"
            + "        v_rate_plan             varchar2(50):=?;\n"
            + "        v_network_login         varchar2(30):=?;\n"
            + "        v_network_password      varchar2(30):=?;\n"
            + "        v_account_num           varchar2(30):=?;\n"
            + "        v_dealer_code           varchar2(30):=?;\n"
            + "        v_market_code           varchar2(30):=?;\n"
            + "        v_com_port              varchar2(30):=?;\n"
            + "        v_rate_center_no        varchar2(30):=?;\n"
            + "        v_zip_code              varchar2(30):=?;\n"
            + "        v_status                varchar2(30):=?;\n"
            + "        v_q_transaction         varchar2(30):=?;\n"
            + "        v_ld_provider           varchar2(30):=?;\n"
            + "        v_tech_flag             varchar2(30):=?;\n"
            + "        v_trans_method          varchar2(30):=?;\n"
            + "        v_balance               varchar2(30):=?;\n"
            + "        v_old_min               varchar2(30):=?;\n"
            + "        v_digital_feature       varchar2(30):=?;\n"
            + "        v_digital_feature_code  varchar2(30):=?;\n"
            + "        v_voice_mail            varchar2(30):=?;\n"
            + "        v_voice_mail_package    varchar2(30):=?;\n"
            + "        v_caller_id             varchar2(30):=?;\n"
            + "        v_caller_id_package     varchar2(30):=?;\n"
            + "        v_call_waiting          varchar2(30):=?;\n"
            + "        v_call_waiting_package  varchar2(30):=?;\n"
            + "        v_sms                   varchar2(30):=?;\n"
            + "        v_sms_package           varchar2(30):=?;\n"
            + "        v_mpn                   varchar2(30):=?;\n"
            + "        v_mpn_code              varchar2(30):=?;\n"
            + "        v_ip_pool               varchar2(30):=?;\n"
            + "        v_language              varchar2(30):=?;\n"
            + "        v_data_saver            varchar2(30):=?;\n"
            + "        v_data_saver_code       varchar2(30):=?;\n"
            + "        v_bucket_id1            varchar2(30):=?;\n"
            + "        v_bucket_bal1           varchar2(30):=?;\n"
            + "        v_bucket_val1           varchar2(30):=?;\n"
            + "        v_bucket_benefit1       varchar2(30):=?;\n"
            + "        v_bucket_type1          varchar2(30):=?;\n"
            + "        v_bucket_usage1         varchar2(30):=?;\n"
            + "        v_unit_of_measure1      varchar2(40):=?;\n"
            + "        v_bucket_group1         varchar2(30):=?;\n"
            + "        v_bucket_req1           varchar2(200):=?;\n"
            + "        v_auto_renew_flag1      varchar2(1):=?;\n"
            + "        v_auto_renew_freq1      varchar2(3):=?;\n"
            + "        v_auto_renew_val1       varchar2(30):=?;\n"
            + "        v_auto_renew_day1       varchar2(30):=?;\n"
            + "        v_bucket_action1        varchar2(50):=?;\n"
            + "        v_expire_date1          date:=?;\n"
            + "        v_recharge_date1        date:=?;\n"
            + "        v_data_exp_date1        date:=?;\n"
            + "        v_bucket_id2            varchar2(30):=?;\n"
            + "        v_bucket_bal2           varchar2(30):=?;\n"
            + "        v_bucket_val2           varchar2(30):=?;\n"
            + "        v_bucket_benefit2       varchar2(30):=?;\n"
            + "        v_bucket_type2          varchar2(30):=?;\n"
            + "        v_bucket_usage2         varchar2(30):=?;\n"
            + "        v_unit_of_measure2      varchar2(40):=?;\n"
            + "        v_bucket_group2         varchar2(30):=?;\n"
            + "        v_bucket_req2           varchar2(200):=?;\n"
            + "        v_auto_renew_flag2      varchar2(1):=?;\n"
            + "        v_auto_renew_freq2      varchar2(3):=?;\n"
            + "        v_auto_renew_val2       varchar2(30):=?;\n"
            + "        v_auto_renew_day2       varchar2(30):=?;\n"
            + "        v_bucket_action2        varchar2(50):=?;\n"
            + "        v_expire_date2          date:=?;--to_date('07/05/2017','mm/dd/yyyy');--null;\n"
            + "        v_recharge_date2        date:=?;\n"
            + "        v_data_exp_date2        date:=?;\n"
            + "        v_bucket_id3            varchar2(30):=?;\n"
            + "        v_bucket_bal3           varchar2(30):=?;\n"
            + "        v_bucket_val3           varchar2(30):=?;\n"
            + "        v_bucket_benefit3       varchar2(30):=?;\n"
            + "        v_bucket_type3          varchar2(30):=?;\n"
            + "        v_bucket_usage3         varchar2(30):=?;\n"
            + "        v_unit_of_measure3      varchar2(40):=?;\n"
            + "        v_bucket_group3         varchar2(30):=?;\n"
            + "        v_bucket_req3           varchar2(200):=?;\n"
            + "        v_auto_renew_flag3      varchar2(1):=?;\n"
            + "        v_auto_renew_freq3      varchar2(3):=?;\n"
            + "        v_auto_renew_val3       varchar2(30):=?;\n"
            + "        v_auto_renew_day3       varchar2(30):=?;\n"
            + "        v_bucket_action3        varchar2(50):=?;\n"
            + "        v_expire_date3          date:=?;--=to_date('07/05/2017','mm/dd/yyyy');--null;null;\n"
            + "        v_recharge_date3        date:=?;\n"
            + "        v_data_exp_date3        date:=?;\n"
            + "        v_bucket_id4            varchar2(30):=?;\n"
            + "        v_bucket_bal4           varchar2(30):=?;\n"
            + "        v_bucket_val4           varchar2(30):=?;\n"
            + "        v_bucket_benefit4       varchar2(30):=?;\n"
            + "        v_bucket_type4          varchar2(30):=?;\n"
            + "        v_bucket_usage4         varchar2(30):=?;\n"
            + "        v_unit_of_measure4      varchar2(40):=?;\n"
            + "        v_bucket_group4         varchar2(30):=?;\n"
            + "        v_bucket_req4           varchar2(200):=?;\n"
            + "        v_auto_renew_flag4      varchar2(1):=?;\n"
            + "        v_auto_renew_freq4      varchar2(3):=?;\n"
            + "        v_auto_renew_val4       varchar2(30):=?;\n"
            + "        v_auto_renew_day4       varchar2(30):=?;\n"
            + "        v_bucket_action4        varchar2(50):=?;\n"
            + "        v_expire_date4          date:=?;\n"
            + "        v_recharge_date4        date:=?;\n"
            + "        v_data_exp_date4        date:=?;\n"
            + "        v_bucket_id5            varchar2(30):=?;\n"
            + "        v_bucket_bal5           varchar2(30):=?;\n"
            + "        v_bucket_val5           varchar2(30):=?;\n"
            + "        v_bucket_benefit5       varchar2(30):=?;\n"
            + "        v_bucket_type5          varchar2(30):=?;\n"
            + "        v_bucket_usage5         varchar2(30):=?;\n"
            + "        v_unit_of_measure5      varchar2(40):=?;\n"
            + "        v_bucket_group5         varchar2(30):=?;\n"
            + "        v_bucket_req5           varchar2(200):=?;\n"
            + "        v_auto_renew_flag5      varchar2(1):=?;\n"
            + "        v_auto_renew_freq5      varchar2(3):=?;\n"
            + "        v_auto_renew_val5       varchar2(30):=?;\n"
            + "        v_auto_renew_day5       varchar2(30):=?;\n"
            + "        v_bucket_action5        varchar2(50):=?;\n"
            + "        v_expire_date5          date:=?;--to_date('07/05/2017','mm/dd/yyyy');\n"
            + "        v_recharge_date5        date:=?;\n"
            + "        v_data_exp_date5        date:=?;\n"
            + "        v_bucket_id6            varchar2(30):=?;\n"
            + "        v_bucket_bal6           varchar2(30):=?;\n"
            + "        v_bucket_val6           varchar2(30):=?;\n"
            + "        v_bucket_benefit6       varchar2(30):=?;\n"
            + "        v_bucket_type6          varchar2(30):=?;\n"
            + "        v_bucket_usage6         varchar2(30):=?;\n"
            + "        v_unit_of_measure6      varchar2(40):=?;\n"
            + "        v_bucket_group6         varchar2(30):=?;\n"
            + "        v_bucket_req6           varchar2(200):=?;\n"
            + "        v_auto_renew_flag6      varchar2(1):=?;\n"
            + "        v_auto_renew_freq6      varchar2(3):=?;\n"
            + "        v_auto_renew_val6       varchar2(30):=?;\n"
            + "        v_auto_renew_day6       varchar2(30):=?;\n"
            + "        v_bucket_action6        varchar2(50):=?;\n"
            + "        v_expire_date6          date:=?;--to_date('07/05/2017','mm/dd/yyyy');--null;\n"
            + "        v_recharge_date6        date:=?;\n"
            + "        v_data_exp_date6        date:=?;\n"
            + "        v_bucket_id7            varchar2(30):=?;\n"
            + "        v_bucket_bal7           varchar2(30):=?;\n"
            + "        v_bucket_val7           varchar2(30):=?;\n"
            + "        v_bucket_benefit7       varchar2(30):=?;\n"
            + "        v_bucket_type7          varchar2(30):=?;\n"
            + "        v_bucket_usage7         varchar2(30):=?;\n"
            + "        v_unit_of_measure7      varchar2(40):=?;\n"
            + "        v_bucket_group7         varchar2(30):=?;\n"
            + "        v_bucket_req7           varchar2(200):=?;\n"
            + "        v_auto_renew_flag7      varchar2(1):=?;\n"
            + "        v_auto_renew_freq7      varchar2(3):=?;\n"
            + "        v_auto_renew_val7       varchar2(30):=?;\n"
            + "        v_auto_renew_day7       varchar2(30):=?;\n"
            + "        v_bucket_action7        varchar2(50):=?;\n"
            + "        v_expire_date7          date:=?;--=to_date('07/05/2017','mm/dd/yyyy');--null;null;\n"
            + "        v_recharge_date7        date:=?;\n"
            + "        v_data_exp_date7        date:=?;\n"
            + "        v_bucket_id8            varchar2(30):=?;\n"
            + "        v_bucket_bal8           varchar2(30):=?;\n"
            + "        v_bucket_val8           varchar2(30):=?;\n"
            + "        v_bucket_benefit8       varchar2(30):=?;\n"
            + "        v_bucket_type8          varchar2(30):=?;\n"
            + "        v_bucket_usage8         varchar2(30):=?;\n"
            + "        v_unit_of_measure8      varchar2(40):=?;\n"
            + "        v_bucket_group8         varchar2(30):=?;\n"
            + "        v_bucket_req8           varchar2(200):=?;\n"
            + "        v_auto_renew_flag8      varchar2(1):=?;\n"
            + "        v_auto_renew_freq8      varchar2(3):=?;\n"
            + "        v_auto_renew_val8       varchar2(30):=?;\n"
            + "        v_auto_renew_day8       varchar2(30):=?;\n"
            + "        v_bucket_action8        varchar2(50):=?;\n"
            + "        v_expire_date8          date:=?;\n"
            + "        v_recharge_date8        date:=?;\n"
            + "        v_data_exp_date8        date:=?;\n"

            + "        v_bucket_id9            varchar2(30):=?;\n"
            + "        v_bucket_bal9           varchar2(30):=?;\n"
            + "        v_bucket_val9           varchar2(30):=?;\n"
            + "        v_bucket_benefit9       varchar2(30):=?;\n"
            + "        v_bucket_type9          varchar2(30):=?;\n"
            + "        v_bucket_usage9         varchar2(30):=?;\n"
            + "        v_unit_of_measure9      varchar2(40):=?;\n"
            + "        v_bucket_group9         varchar2(30):=?;\n"
            + "        v_bucket_req9           varchar2(200):=?;\n"
            + "        v_auto_renew_flag9      varchar2(1):=?;\n"
            + "        v_auto_renew_freq9      varchar2(3):=?;\n"
            + "        v_auto_renew_val9       varchar2(30):=?;\n"
            + "        v_auto_renew_day9       varchar2(30):=?;\n"
            + "        v_bucket_action9        varchar2(50):=?;\n"
            + "        v_expire_date9          date:=?;\n"
            + "        v_recharge_date9        date:=?;\n"
            + "        v_data_exp_date9        date:=?;\n"
            + "        v_bucket_id10            varchar2(30):=?;\n"
            + "        v_bucket_bal10           varchar2(30):=?;\n"
            + "        v_bucket_val10           varchar2(30):=?;\n"
            + "        v_bucket_benefit10       varchar2(30):=?;\n"
            + "        v_bucket_type10          varchar2(30):=?;\n"
            + "        v_bucket_usage10         varchar2(30):=?;\n"
            + "        v_unit_of_measure10      varchar2(40):=?;\n"
            + "        v_bucket_group10         varchar2(30):=?;\n"
            + "        v_bucket_req10           varchar2(200):=?;\n"
            + "        v_auto_renew_flag10      varchar2(1):=?;\n"
            + "        v_auto_renew_freq10      varchar2(3):=?;\n"
            + "        v_auto_renew_val10       varchar2(30):=?;\n"
            + "        v_auto_renew_day10       varchar2(30):=?;\n"
            + "        v_bucket_action10        varchar2(50):=?;\n"
            + "        v_expire_date10          date:=?;\n"
            + "        v_recharge_date10        date:=?;\n"
            + "        v_data_exp_date10        date:=?;\n"
            + "        v_bucket_id11            varchar2(30):=?;\n"
            + "        v_bucket_bal11           varchar2(30):=?;\n"
            + "        v_bucket_val11           varchar2(30):=?;\n"
            + "        v_bucket_benefit11       varchar2(30):=?;\n"
            + "        v_bucket_type11          varchar2(30):=?;\n"
            + "        v_bucket_usage11         varchar2(30):=?;\n"
            + "        v_unit_of_measure11      varchar2(40):=?;\n"
            + "        v_bucket_group11         varchar2(30):=?;\n"
            + "        v_bucket_req11           varchar2(200):=?;\n"
            + "        v_auto_renew_flag11      varchar2(1):=?;\n"
            + "        v_auto_renew_freq11      varchar2(3):=?;\n"
            + "        v_auto_renew_val11       varchar2(30):=?;\n"
            + "        v_auto_renew_day11       varchar2(30):=?;\n"
            + "        v_bucket_action11        varchar2(50):=?;\n"
            + "        v_expire_date11          date:=?;\n"
            + "        v_recharge_date11        date:=?;\n"
            + "        v_data_exp_date11        date:=?;\n"
            + "        v_bucket_id12            varchar2(30):=?;\n"
            + "        v_bucket_bal12           varchar2(30):=?;\n"
            + "        v_bucket_val12           varchar2(30):=?;\n"
            + "        v_bucket_benefit12       varchar2(30):=?;\n"
            + "        v_bucket_type12          varchar2(30):=?;\n"
            + "        v_bucket_usage12         varchar2(30):=?;\n"
            + "        v_unit_of_measure12      varchar2(40):=?;\n"
            + "        v_bucket_group12         varchar2(30):=?;\n"
            + "        v_bucket_req12           varchar2(200):=?;\n"
            + "        v_auto_renew_flag12      varchar2(1):=?;\n"
            + "        v_auto_renew_freq12      varchar2(3):=?;\n"
            + "        v_auto_renew_val12       varchar2(30):=?;\n"
            + "        v_auto_renew_day12       varchar2(30):=?;\n"
            + "        v_bucket_action12        varchar2(50):=?;\n"
            + "        v_expire_date12          date:=?;\n"
            + "        v_recharge_date12        date:=?;\n"
            + "        v_data_exp_date12        date:=?;\n"
            + "        v_bucket_id13            varchar2(30):=?;\n"
            + "        v_bucket_bal13           varchar2(30):=?;\n"
            + "        v_bucket_val13           varchar2(30):=?;\n"
            + "        v_bucket_benefit13       varchar2(30):=?;\n"
            + "        v_bucket_type13          varchar2(30):=?;\n"
            + "        v_bucket_usage13         varchar2(30):=?;\n"
            + "        v_unit_of_measure13      varchar2(40):=?;\n"
            + "        v_bucket_group13         varchar2(30):=?;\n"
            + "        v_bucket_req13           varchar2(200):=?;\n"
            + "        v_auto_renew_flag13      varchar2(1):=?;\n"
            + "        v_auto_renew_freq13      varchar2(3):=?;\n"
            + "        v_auto_renew_val13       varchar2(30):=?;\n"
            + "        v_auto_renew_day13       varchar2(30):=?;\n"
            + "        v_bucket_action13        varchar2(50):=?;\n"
            + "        v_expire_date13          date:=?;\n"
            + "        v_recharge_date13        date:=?;\n"
            + "        v_data_exp_date13        date:=?;\n"
            + "        v_bucket_id14            varchar2(30):=?;\n"
            + "        v_bucket_bal14           varchar2(30):=?;\n"
            + "        v_bucket_val14           varchar2(30):=?;\n"
            + "        v_bucket_benefit14       varchar2(30):=?;\n"
            + "        v_bucket_type14          varchar2(30):=?;\n"
            + "        v_bucket_usage14         varchar2(30):=?;\n"
            + "        v_unit_of_measure14      varchar2(40):=?;\n"
            + "        v_bucket_group14         varchar2(30):=?;\n"
            + "        v_bucket_req14           varchar2(200):=?;\n"
            + "        v_auto_renew_flag14      varchar2(1):=?;\n"
            + "        v_auto_renew_freq14      varchar2(3):=?;\n"
            + "        v_auto_renew_val14       varchar2(30):=?;\n"
            + "        v_auto_renew_day14       varchar2(30):=?;\n"
            + "        v_bucket_action14        varchar2(50):=?;\n"
            + "        v_expire_date14          date:=?;\n"
            + "        v_recharge_date14        date:=?;\n"
            + "        v_data_exp_date14        date:=?;\n"
            + "        v_bucket_id15            varchar2(30):=?;\n"
            + "        v_bucket_bal15           varchar2(30):=?;\n"
            + "        v_bucket_val15           varchar2(30):=?;\n"
            + "        v_bucket_benefit15       varchar2(30):=?;\n"
            + "        v_bucket_type15          varchar2(30):=?;\n"
            + "        v_bucket_usage15         varchar2(30):=?;\n"
            + "        v_unit_of_measure15      varchar2(40):=?;\n"
            + "        v_bucket_group15         varchar2(30):=?;\n"
            + "        v_bucket_req15           varchar2(200):=?;\n"
            + "        v_auto_renew_flag15      varchar2(1):=?;\n"
            + "        v_auto_renew_freq15      varchar2(3):=?;\n"
            + "        v_auto_renew_val15       varchar2(30):=?;\n"
            + "        v_auto_renew_day15       varchar2(30):=?;\n"
            + "        v_bucket_action15        varchar2(50):=?;\n"
            + "        v_expire_date15          date:=?;\n"
            + "        v_recharge_date15        date:=?;\n"
            + "        v_data_exp_date15        date:=?;\n"
            + "        v_bucket_id16            varchar2(30):=?;\n"
            + "        v_bucket_bal16           varchar2(30):=?;\n"
            + "        v_bucket_val16           varchar2(30):=?;\n"
            + "        v_bucket_benefit16       varchar2(30):=?;\n"
            + "        v_bucket_type16          varchar2(30):=?;\n"
            + "        v_bucket_usage16         varchar2(30):=?;\n"
            + "        v_unit_of_measure16      varchar2(40):=?;\n"
            + "        v_bucket_group16         varchar2(30):=?;\n"
            + "        v_bucket_req16           varchar2(200):=?;\n"
            + "        v_auto_renew_flag16      varchar2(1):=?;\n"
            + "        v_auto_renew_freq16      varchar2(3):=?;\n"
            + "        v_auto_renew_val16       varchar2(30):=?;\n"
            + "        v_auto_renew_day16       varchar2(30):=?;\n"
            + "        v_bucket_action16        varchar2(50):=?;\n"
            + "        v_expire_date16          date:=?;\n"
            + "        v_recharge_date16        date:=?;\n"
            + "        v_data_exp_date16        date:=?;\n"
            + "        v_bucket_id17            varchar2(30):=?;\n"
            + "        v_bucket_bal17           varchar2(30):=?;\n"
            + "        v_bucket_val17           varchar2(30):=?;\n"
            + "        v_bucket_benefit17       varchar2(30):=?;\n"
            + "        v_bucket_type17          varchar2(30):=?;\n"
            + "        v_bucket_usage17         varchar2(30):=?;\n"
            + "        v_unit_of_measure17      varchar2(40):=?;\n"
            + "        v_bucket_group17         varchar2(30):=?;\n"
            + "        v_bucket_req17           varchar2(200):=?;\n"
            + "        v_auto_renew_flag17      varchar2(1):=?;\n"
            + "        v_auto_renew_freq17      varchar2(3):=?;\n"
            + "        v_auto_renew_val17       varchar2(30):=?;\n"
            + "        v_auto_renew_day17       varchar2(30):=?;\n"
            + "        v_bucket_action17        varchar2(50):=?;\n"
            + "        v_expire_date17          date:=?;\n"
            + "        v_recharge_date17        date:=?;\n"
            + "        v_data_exp_date17        date:=?;\n"
            + "        v_bucket_id18            varchar2(30):=?;\n"
            + "        v_bucket_bal18           varchar2(30):=?;\n"
            + "        v_bucket_val18           varchar2(30):=?;\n"
            + "        v_bucket_benefit18       varchar2(30):=?;\n"
            + "        v_bucket_type18          varchar2(30):=?;\n"
            + "        v_bucket_usage18         varchar2(30):=?;\n"
            + "        v_unit_of_measure18      varchar2(40):=?;\n"
            + "        v_bucket_group18         varchar2(30):=?;\n"
            + "        v_bucket_req18           varchar2(200):=?;\n"
            + "        v_auto_renew_flag18      varchar2(1):=?;\n"
            + "        v_auto_renew_freq18      varchar2(3):=?;\n"
            + "        v_auto_renew_val18       varchar2(30):=?;\n"
            + "        v_auto_renew_day18       varchar2(30):=?;\n"
            + "        v_bucket_action18        varchar2(50):=?;\n"
            + "        v_expire_date18          date:=?;\n"
            + "        v_recharge_date18        date:=?;\n"
            + "        v_data_exp_date18        date:=?;\n"
            + "        v_bucket_id19            varchar2(30):=?;\n"
            + "        v_bucket_bal19           varchar2(30):=?;\n"
            + "        v_bucket_val19           varchar2(30):=?;\n"
            + "        v_bucket_benefit19       varchar2(30):=?;\n"
            + "        v_bucket_type19          varchar2(30):=?;\n"
            + "        v_bucket_usage19         varchar2(30):=?;\n"
            + "        v_unit_of_measure19      varchar2(40):=?;\n"
            + "        v_bucket_group19         varchar2(30):=?;\n"
            + "        v_bucket_req19           varchar2(200):=?;\n"
            + "        v_auto_renew_flag19      varchar2(1):=?;\n"
            + "        v_auto_renew_freq19      varchar2(3):=?;\n"
            + "        v_auto_renew_val19       varchar2(30):=?;\n"
            + "        v_auto_renew_day19       varchar2(30):=?;\n"
            + "        v_bucket_action19        varchar2(50):=?;\n"
            + "        v_expire_date19          date:=?;\n"
            + "        v_recharge_date19        date:=?;\n"
            + "        v_data_exp_date19        date:=?;\n"
            + "        v_bucket_id20            varchar2(30):=?;\n"
            + "        v_bucket_val20           varchar2(30):=?;\n"
            + "        v_bucket_bal20           varchar2(30):=?;\n"
            + "        v_bucket_benefit20       varchar2(30):=?;\n"
            + "        v_bucket_type20          varchar2(30):=?;\n"
            + "        v_bucket_usage20         varchar2(30):=?;\n"
            + "        v_unit_of_measure20      varchar2(40):=?;\n"
            + "        v_bucket_group20         varchar2(30):=?;\n"
            + "        v_bucket_req20           varchar2(200):=?;\n"
            + "        v_auto_renew_flag20      varchar2(1):=?;\n"
            + "        v_auto_renew_freq20      varchar2(3):=?;\n"
            + "        v_auto_renew_val20       varchar2(30):=?;\n"
            + "        v_auto_renew_day20       varchar2(30):=?;\n"
            + "        v_bucket_action20        varchar2(50):=?;\n"
            + "        v_expire_date20          date:=?;\n"
            + "        v_recharge_date20        date:=?;\n"
            + "        v_data_exp_date20        date:=?;\n"

            + "        v_phone_manf            varchar2(30):=?;\n"
            + "        v_expire_date           date:=?;\n"
            + "        v_download_dt           date:=?;\n"
            + "        v_exp_dt                date:=?;\n"
            + "        v_first_name            varchar2(50):=?;\n"
            + "        v_last_name             varchar2(50):=?;\n"
            + "        v_address_1             varchar2(150):=?;\n"
            + "        v_address_2             varchar2(150):=?;\n"
            + "        v_city                  varchar2(50):=?;\n"
            + "        v_state                 varchar2(2):=?;\n"
            + "        v_zip_code1             varchar2(5):=?;\n"
            + "        v_prl_number            varchar2(150):=?;\n"
            + "        v_make                  varchar2(150):=?;\n"
            + "        v_model                 varchar2(150):=?;\n"
            //Added recently for missing IGAdditionalInformation
            + "        v_middleInitial         varchar2(50):=?;\n"
            + "        v_suffix                varchar2(10) := ?;\n"
            + "         v_prefix                varchar2(10) := ?;\n"
            + "         v_ssnlast4              varchar2(10) := ?;\n"
            + "         v_country               varchar2(50) := ?;\n"
            + "         v_ospaccount            varchar2(20) := ?;\n"
            + "         v_curraddrhousenumber   varchar2(50) := ?;\n"
            + "         v_curraddrdirection     varchar2(50) := ?;\n"
            + "         v_curraddrstreetname    varchar2(50) := ?;\n"
            + "         v_curraddrstreettype    varchar2(50) := ?;\n"
            + "         v_curraddressunit       varchar2(50) := ?;\n"
            //The remaining Transaction Fields go here
            + "         v_oldEsn       varchar2(30) := ?;\n"
            + "         v_oldEsnHex       varchar2(30) := ?;\n"
            + "         v_subscriberUpdate  varchar2(1) := ?;\n"
            + "         v_systemLogin       varchar2(30) := ?;\n"
            + "         v_systemPassword    varchar2(30) := ?;\n"
            //+"         v_carrFeatObjId       varchar2(30) := ?;\n"
            + "         v_imsi       varchar2(40) := ?;\n"
            + "         v_newImsiFlag       varchar2(10) := ?;\n"
            + "         v_pin       varchar2(30) := ?;\n"
            + "         v_cfExtensionCount       varchar2(3) := ?;\n"
            //+"         v_cfProfileId       varchar2(30) := ?;\n"
            + "         v_xCampaignName       varchar2(60) := ?;\n"
            + "         v_amount       varchar2(10) := ?;\n"
            + "         v_faxBatchSize       varchar2(30) := ?;\n"
            + "         v_faxNum2       varchar2(40) := ?;\n"
            + "         v_faxNum       varchar2(40) := ?;\n"
            + "         v_faxBatchQtime       varchar2(30) := ?;\n"
            + "         v_onlineNum       varchar2(40) := ?;\n"
            + "         v_onlineNum2       varchar2(40) := ?;\n"
            + "         v_email       varchar2(35) := ?;\n"
            + "         v_sequenceNum       varchar2(30) := ?;\n"
            + "         v_otaType       varchar2(10) := ?;\n"
            + "         v_rtpServer       varchar2(30) := ?;\n"
            + "         v_stateField       varchar2(30) := ?;\n"
            + "         v_exeName       varchar2(160) := ?;\n"
            + "         v_expidite       varchar2(30) := ?;\n"
            + "         v_blackoutWait       varchar2(30) := ?;\n"
            + "         v_tuxItiServer       varchar2(20) := ?;\n"
            + "         v_transProfKey       varchar2(30) := ?;\n"
            + "        v_rpExtObjid          number := ?;\n"
            + "        v_carrierAccountId    number:=?;  \n"
            + "        v_servicePlanId       number:=?;  \n"
            + "        v_userId              number:=?;  \n"
            + "        v_tmoNextGenFlag      varchar2(1) := ?;\n"
            + "        v_endUser             varchar2(40):=?;  \n"
            + "        v_xMode               varchar2(100):=?;  \n"
            + "        v_newMsidFlag         varchar2(10):=?;  \n"
            + "        v_eSimFlag         varchar2(1):=?;  \n"

            //Added by Srinivas after a great idea to insert the features
            + "        v_featureOutResponse    varchar2(4000);\n"
            + " v_featureTyps sa.ig_transaction_features_tab:=sa.ig_transaction_features_tab();\n"
            + STRING
            + "\n"
            + "cursor att_nan_curs (c_zip in varchar2) is\n"
            + "select rc_number, account_num, market_code, dealer_code\n"
            + "  from sa.x_cingular_mrkt_info\n"
            + "where template = 'CSI_TLG'\n"
            + "   and zip = c_zip;\n"
            + "att_nan_rec     att_nan_curs%rowtype;\n"
            + "\n"
            + "cursor vzw_nan_curs (c_zip in varchar2) is\n"
            + "select npanxx,account_num \n"
            + "  from sa.X_VERIZON_ZIP_NPANXX\n"
            + "where zip = c_zip;\n"
            + "vzw_nan_rec     vzw_nan_curs%rowtype;\n"
            + "\n"
            + "cursor spr_nan_curs (c_zip in varchar2) is\n"
            + "select rc_number,rc_name\n"
            + "  from sa.x_cingular_mrkt_info\n"
            + "where template = 'SPRINT'\n"
            + "   and zip = c_zip;\n"
            + "spr_nan_rec     spr_nan_curs%rowtype;\n"
            + "\n"
            + "FUNCTION fun_get_next_ai RETURN VARCHAR2 AS \n"
            + " v_action_item_id gw1.ig_transaction.action_item_id%TYPE;\n"
            + "BEGIN\n"
            + "  SELECT next_seq\n"
            + "  INTO   v_action_item_id\n"
            + "  FROM   (select to_char(replace(action_item_id,'EGG'||to_char(sysdate,'mmddyy'),null)+1) next_seq ,action_item_Id\n"
            + "          from   ig_transaction ig \n"
            + "          where  1=1\n"
            + "            and  action_item_id like 'EGG'||to_char(sysdate,'mmddyy')||'%'\n"
            + "          order by replace(action_item_id,'EGG'||to_char(sysdate,'mmddyy'),null) desc)\n"
            + "  WHERE  rownum<2;    \n"
            + "return 'EGG'||to_char(sysdate,'mmddyy')||v_action_item_id;\n"
            + "exception\n"
            + "when others then\n"
            + "  return 'EGG'||to_char(sysdate,'mmddyy')||'0';\n"
            + "END fun_get_next_ai; \n"
            + "\n"
            + "  procedure generate_trans_id as -- * * * procedure to generate next available transaction_id  * * \n"
            + "      v_count number:= 0;  \n"
            + "      v_count1 number:= 0;  \n"
            + "\n"
            + "    begin\n"
            + "      <<new_trans>>\n"
            + "       trans_hold:=  gw1.trans_id_seq.NEXTVAL + POWER(2 ,28);\n"
            + "       user_history_id := COP.SEQ_COP_ID_USER_HISTORY.NEXTVAL;\n"
            + "       select count(*)cnt\n"
            + "              into v_count \n"
            + "       from gw1.ig_transaction \n"
            + "       where transaction_id = trans_hold;\n"
            + "       \n"
            + "        select count(*)cnt1\n"
            + "            into v_count1 \n"
            + "       from gw1.ig_transaction_buckets\n"
            + "       where transaction_id = trans_hold;\n"
            + STRING
            + "       if v_count > 0 or v_count1 > 0 then\n"
            + "          --dbms_output.put_line('trans_id: '|| Trans_hold || ' exist in ig, getting a new trans_id');\n"
            + "          goto new_trans;\n"
            + "       end if;\n"
            + "    end generate_trans_id; -- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n"
            + "\n"
            + "\n"
            + "begin\n"
            + "\n"
            + " if v_action_item_id is null then\n"
            + "  v_action_item_id:=fun_get_next_ai;\n"
            + "  dbms_output.put_line('used next ai in seq');\n"
            + "else  \n"
            + "  dbms_output.put_line('used explicit ai');\n"
            + END_IF
            + "\n"
            + "if v_template in ('RSS','SUREPAY') and v_min is null\n"
            + "  then \n"
            + "   open vzw_nan_curs (v_zip_code);\n"
            + "   fetch vzw_nan_curs into vzw_nan_rec;\n"
            + "         v_account_num    := vzw_nan_rec.account_num;\n"
            + "         v_rate_center_no := null;\n"
            + "         v_min            := 'T'||vzw_nan_rec.npanxx||'1111';\n"
            + "         v_msid           := 'T'||vzw_nan_rec.npanxx||'1111';\n"
            + "   close vzw_nan_curs;\n"
            + "  elsif v_template in ('RSS','SUREPAY') and v_min is not null\n"
            + "   then \n"
            + "    open vzw_nan_curs (v_zip_code);\n"
            + "   fetch vzw_nan_curs into vzw_nan_rec;\n"
            + "         v_account_num    := vzw_nan_rec.account_num;\n"
            + "         v_rate_center_no := null;\n"
            + "   close vzw_nan_curs;\n"
            + END_IF
            + "\n"
            + " if v_template = 'CSI_TLG' and v_rate_center_no is null\n"
            + "  then \n"
            + "   open att_nan_curs (v_zip_code);\n"
            + "   fetch att_nan_curs into att_nan_rec;\n"
            + "         v_account_num    := att_nan_rec.account_num;\n"
            + "         v_rate_center_no := att_nan_rec.rc_number;\n"
            + "         v_market_code    := att_nan_rec.market_code;\n"
            + "         v_dealer_code    := att_nan_rec.dealer_code;\n"
            + "   close att_nan_curs;\n"
            + "  elsif v_template = 'CSI_TLG' and v_rate_center_no is not null\n"
            + "   then\n"
            + "   open att_nan_curs (v_zip_code);\n"
            + "   fetch att_nan_curs into att_nan_rec;\n"
            + "         v_account_num    := att_nan_rec.account_num;\n"
            + "         v_market_code    := att_nan_rec.market_code;\n"
            + "         v_dealer_code    := att_nan_rec.dealer_code;\n"
            + "   close att_nan_curs; \n"
            + " end if;\n"
            + "\n"
            + " if v_template = 'SPRINT' then \n"
            + "   open spr_nan_curs(v_zip_code);\n"
            + "   fetch spr_nan_curs into spr_nan_rec;\n"
            + "   close spr_nan_curs;\n"
            + "   dbms_output.put_line('SPR RC_NUMBER: '||spr_nan_rec.rc_number);\n"
            + "   dbms_output.put_line('SPR RC_NAME: '||spr_nan_rec.rc_name);\n"
            + END_IF
            + "\n"
            + "generate_trans_id();\n"
            // + "\n v_action_item_id := v_action_item_id ||  SA. SEQU_TASK.nextval; "
            + "insert into ig_transaction\n"
            + "             (\n"
            + "              application_system,\n"
            + "              transaction_id,\n"
            + "              template,\n"
            + "              action_item_id,\n"
            + "              carrier_id,\n"
            + "              order_type,\n"
            + "              esn,\n"
            + "              esn_hex,\n"
            + "              iccid,\n"
            + "              min,\n"
            + "              msid,\n"
            + "              rate_plan,\n"
            + "              network_login,\n"
            + "              network_password,\n"
            + "              account_num,\n"
            + "              dealer_code,\n"
            + "              market_code,\n"
            + "              COM_PORT,\n"
            + "              rate_center_no,\n"
            + "              zip_code,\n"
            + "              status,\n"
            + "              q_transaction,\n"
            + "              ld_provider,\n"
            + "              technology_flag,\n"
            + "              transmission_method,\n"
            + "              balance,\n"
            + "              old_min,\n"
            + "              digital_feature,\n"
            + "              digital_feature_code,\n"
            + "              voice_mail,\n"
            + "              voice_mail_package,\n"
            + "              caller_id,\n"
            + "              caller_id_package,\n"
            + "              call_waiting,\n"
            + "              call_waiting_package,\n"
            + "              sms,\n"
            + "              sms_package,\n"
            + "              x_mpn,\n"
            + "              x_mpn_code,\n"
            + "              x_pool_name,\n"
            + "              language,\n"
            + "              phone_manf,\n"
            + "              download_date,\n"
            + "              EXP_DATE,\n"
            + "              prl_number,\n"
            + "              carrier_feature_objid,\n"
            + "              CF_PROFILE_ID,\n"
            + "              DATA_SAVER,\n"
            + "              DATA_SAVER_CODE,\n"
            + "              x_make,\n"
            + "              x_model,\n"

            + "              old_esn,\n"
            + "              old_esn_hex,\n"
            + "              subscriber_update,\n"
            + "              system_login,\n"
            + "              system_password,\n"
            + "              imsi,\n"
            + "              new_imsi_flag,\n"
            + "              pin,\n"
            + "              cf_extension_count,\n"
            + "              x_campaign_name,\n"
            + "              amount,\n"
            + "              fax_batch_size,\n"
            + "              fax_num2,\n"
            + "              fax_num,\n"
            + "              fax_batch_q_time,\n"
            + "              online_num,\n"
            + "              online_num2,\n"
            + "              email,\n"
            + "              sequence_num,\n"
            + "              ota_type,\n"
            + "              rtp_server,\n"
            + "              state_field,\n"
            + "              exe_name,\n"
            + "              expidite,\n"
            + "              blackout_wait,\n"
            + "              tux_iti_server,\n"
            + "              TRANS_PROF_KEY,\n"
            + "              rp_ext_objid,\n"
            + "              carrier_account_id,\n"
            + "              service_plan_id,\n"

            + "              TMO_NEXT_GEN_FLAG,\n"
            + "              END_USER,\n"
            + "              X_MODE,\n"
            + "              NEW_MSID_FLAG,\n"
            + "              E_SIM_FLAG\n"

            + "             )\n"
            + "      values (\n"
            + "              v_app_sys,\n"
            + "              trans_hold,\n"
            + "              v_template,\n"
            + "              v_action_item_id,\n"
            + "              v_carrier_id,\n"
            + "              v_order_type,\n"
            + "              v_esn,\n"
            + "              nvl(v_esn_hex,igate.f_get_hex_esn(v_esn)),--'A0000019980E6B',--\n"
            + "              v_iccid,\n"
            + "              v_min,\n"
            + "              v_msid,\n"
            + "              v_rate_plan,\n"
            + "              v_network_login,\n"
            + "              v_network_password,\n"
            + "              v_account_num,\n"
            + "              v_dealer_code,\n"
            + "              v_market_code,\n"
            + "              v_com_port,\n"
            + "              v_rate_center_no,\n"
            + "              v_zip_code,\n"
            + "              v_status,\n"
            + "              v_q_transaction,\n"
            + "              v_ld_provider,\n"
            + "              v_tech_flag,\n"
            + "              v_trans_method,\n"
            + "              v_balance,\n"
            + "              v_old_min,\n"
            + "              v_digital_feature,\n"
            + "              v_digital_feature_code,\n"
            + "              v_voice_mail,\n"
            + "              v_voice_mail_package,\n"
            + "              v_caller_id,\n"
            + "              v_caller_id_package,\n"
            + "              v_call_waiting,\n"
            + "              v_call_waiting_package,\n"
            + "              v_sms,\n"
            + "              v_sms_package,\n"
            + "              v_mpn,\n"
            + "              v_mpn_code,\n"
            + "              v_ip_pool,\n"
            + "              v_language,\n"
            + "              v_phone_manf,\n"
            + "              v_download_dt,\n"
            + "              v_exp_dt,\n"
            + "              v_prl_number,\n"
            + "              v_carr_feat,\n"
            + "              v_rate_plan_profile_id,\n"
            + "              v_data_saver,\n"
            + "              v_data_saver_code,\n"
            + "              v_make,\n"
            + "              v_model,\n"
            + "         v_oldEsn ,\n"
            + "         v_oldEsnHex,\n"
            + "         v_subscriberUpdate,\n"
            + "         v_systemLogin,\n"
            + "         v_systemPassword ,\n"
            + "         v_imsi,\n"
            + "         v_newImsiFlag ,\n"
            + "         v_pin ,\n"
            + "         v_cfExtensionCount,\n"
            + "         v_xCampaignName,\n"
            + "         v_amount ,\n"
            + "         v_faxBatchSize ,\n"
            + "         v_faxNum2,\n"
            + "         v_faxNum  ,\n"
            + "         v_faxBatchQtime ,\n"
            + "         v_onlineNum ,\n"
            + "         v_onlineNum2 ,\n"
            + "         v_email ,\n"
            + "         v_sequenceNum  ,\n"
            + "         v_otaType   ,\n"
            + "         v_rtpServer ,\n"
            + "         v_stateField  ,\n"
            + "         v_exeName  ,\n"
            + "         v_expidite,\n"
            + "         v_blackoutWait  ,\n"
            + "         v_tuxItiServer  ,\n"
            + "         v_transProfKey, \n"
            + "         v_rpExtObjid,  \n"
            + "         v_carrierAccountId,  \n"
            + "         v_servicePlanId,  \n"
            + "         v_tmoNextGenFlag,  \n"
            + "         v_endUser,  \n"
            + "         v_xMode , \n"
            + "         v_newMsidFlag , \n"
            +"          v_eSimFlag  \n"

            + "             );\n"
            + "     insert into COP.COP_ID_USER_HISTORY (ID, USER_ID, TYPE, CREATION_DATE, UPDATE_DATE) \n"
            + "     values (user_history_id, v_userId, 'INSERT', sysdate, sysdate);\n"
            + "     insert into COP.COP_ID_USER_HISTORY_DETAIL (ID, HISTORY_ID, ID_TYPE, ID_DETAIL, CREATION_DATE, UPDATE_DATE)\n"
            + "     values (COP.SEQ_COP_ID_USER_HISTORY_DETAIL.NEXTVAL, user_history_id, 'AID', v_action_item_id, sysdate, sysdate);\n"
            + "    \n"
            + "     if v_bucket_id1 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id1,v_recharge_date1,v_bucket_bal1,v_bucket_val1,v_expire_date1,'OUTBOUND',v_bucket_benefit1,v_bucket_type1,v_bucket_usage1,v_data_exp_date1,v_unit_of_measure1,v_bucket_group1,v_bucket_req1,v_auto_renew_flag1,v_auto_renew_freq1,v_auto_renew_val1,v_auto_renew_day1,v_bucket_action1);--);--\n"
            + END_IF1
            + "    if v_bucket_id2 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id2,v_recharge_date2,v_bucket_bal2,v_bucket_val2,v_expire_date2,'OUTBOUND',v_bucket_benefit2,v_bucket_type2,v_bucket_usage2,v_data_exp_date2,v_unit_of_measure2,v_bucket_group2,v_bucket_req2,v_auto_renew_flag2,v_auto_renew_freq2,v_auto_renew_val2,v_auto_renew_day2,v_bucket_action2);--);--\n"
            + END_IF2
            + "     if v_bucket_id3 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id3,v_recharge_date3,v_bucket_bal3,v_bucket_val3,v_expire_date3,'OUTBOUND',v_bucket_benefit3,v_bucket_type3,v_bucket_usage3,v_data_exp_date3,v_unit_of_measure3,v_bucket_group3,v_bucket_req3,v_auto_renew_flag3,v_auto_renew_freq3,v_auto_renew_val3,v_auto_renew_day3,v_bucket_action3);--);--\n"
            + END_IF2
            + "     if v_bucket_id4 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id4,v_recharge_date4,v_bucket_bal4,v_bucket_val4,v_expire_date4,'OUTBOUND',v_bucket_benefit4,v_bucket_type4,v_bucket_usage4,v_data_exp_date4,v_unit_of_measure4,v_bucket_group4,v_bucket_req4,v_auto_renew_flag4,v_auto_renew_freq4,v_auto_renew_val4,v_auto_renew_day4,v_bucket_action4);--);--\n"
            + END_IF1
            + "     if v_bucket_id5 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id5,v_recharge_date5,v_bucket_bal5,v_bucket_val5,v_expire_date5,'OUTBOUND',v_bucket_benefit5,v_bucket_type5,v_bucket_usage5,v_data_exp_date5,v_unit_of_measure5,v_bucket_group5,v_bucket_req5,v_auto_renew_flag5,v_auto_renew_freq5,v_auto_renew_val5,v_auto_renew_day5,v_bucket_action5);--);--\n"
            + END_IF1
            + "     if v_bucket_id6 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id6,v_recharge_date6,v_bucket_bal6,v_bucket_val6,v_expire_date6,'OUTBOUND',v_bucket_benefit6,v_bucket_type6,v_bucket_usage6,v_data_exp_date6,v_unit_of_measure6,v_bucket_group6,v_bucket_req6,v_auto_renew_flag6,v_auto_renew_freq6,v_auto_renew_val6,v_auto_renew_day6,v_bucket_action6);--);--\n"
            + END_IF1
            + "     if v_bucket_id7 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id7,v_recharge_date7,v_bucket_bal7,v_bucket_val7,v_expire_date7,'OUTBOUND',v_bucket_benefit7,v_bucket_type7,v_bucket_usage7,v_data_exp_date7,v_unit_of_measure7,v_bucket_group7,v_bucket_req7,v_auto_renew_flag7,v_auto_renew_freq7,v_auto_renew_val7,v_auto_renew_day7,v_bucket_action7);--);--\n"
            + END_IF1
            + "     if v_bucket_id8 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id8,v_recharge_date8,v_bucket_bal8,v_bucket_val8,v_expire_date8,'OUTBOUND',v_bucket_benefit8,v_bucket_type8,v_bucket_usage8,v_data_exp_date8,v_unit_of_measure8,v_bucket_group8,v_bucket_req8,v_auto_renew_flag8,v_auto_renew_freq8,v_auto_renew_val8,v_auto_renew_day8,v_bucket_action8);--);--\n"
            + END_IF1

            + "     if v_bucket_id9 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id9,v_recharge_date9,v_bucket_bal9,v_bucket_val9,v_expire_date9,'OUTBOUND',v_bucket_benefit9,v_bucket_type9,v_bucket_usage9,v_data_exp_date9,v_unit_of_measure9,v_bucket_group9,v_bucket_req9,v_auto_renew_flag9,v_auto_renew_freq9,v_auto_renew_val9,v_auto_renew_day9,v_bucket_action9);--);--\n"
            + END_IF1
            + "    if v_bucket_id10 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id10,v_recharge_date10,v_bucket_bal10,v_bucket_val10,v_expire_date10,'OUTBOUND',v_bucket_benefit10,v_bucket_type10,v_bucket_usage10,v_data_exp_date10,v_unit_of_measure10,v_bucket_group10,v_bucket_req10,v_auto_renew_flag10,v_auto_renew_freq10,v_auto_renew_val10,v_auto_renew_day10,v_bucket_action10);--);--\n"
            + END_IF2
            + "     if v_bucket_id11 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id11,v_recharge_date11,v_bucket_bal11,v_bucket_val11,v_expire_date11,'OUTBOUND',v_bucket_benefit11,v_bucket_type11,v_bucket_usage11,v_data_exp_date11,v_unit_of_measure11,v_bucket_group11,v_bucket_req11,v_auto_renew_flag11,v_auto_renew_freq11,v_auto_renew_val11,v_auto_renew_day11,v_bucket_action11);--);--\n"
            + END_IF2
            + "     if v_bucket_id12 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id12,v_recharge_date12,v_bucket_bal12,v_bucket_val12,v_expire_date12,'OUTBOUND',v_bucket_benefit12,v_bucket_type12,v_bucket_usage12,v_data_exp_date12,v_unit_of_measure12,v_bucket_group12,v_bucket_req12,v_auto_renew_flag12,v_auto_renew_freq12,v_auto_renew_val12,v_auto_renew_day12,v_bucket_action12);--);--\n"
            + END_IF1
            + "     if v_bucket_id13 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id13,v_recharge_date13,v_bucket_bal13,v_bucket_val13,v_expire_date13,'OUTBOUND',v_bucket_benefit13,v_bucket_type13,v_bucket_usage13,v_data_exp_date13,v_unit_of_measure13,v_bucket_group13,v_bucket_req13,v_auto_renew_flag13,v_auto_renew_freq13,v_auto_renew_val13,v_auto_renew_day13,v_bucket_action13);--);--\n"
            + END_IF1
            + "     if v_bucket_id14 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id14,v_recharge_date14,v_bucket_bal14,v_bucket_val14,v_expire_date1,'OUTBOUND',v_bucket_benefit14,v_bucket_type14,v_bucket_usage14,v_data_exp_date14,v_unit_of_measure14,v_bucket_group14,v_bucket_req14,v_auto_renew_flag14,v_auto_renew_freq14,v_auto_renew_val14,v_auto_renew_day14,v_bucket_action14);--);--\n"
            + END_IF1
            + "     if v_bucket_id15 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id15,v_recharge_date15,v_bucket_bal15,v_bucket_val15,v_expire_date15,'OUTBOUND',v_bucket_benefit15,v_bucket_type15,v_bucket_usage15,v_data_exp_date15,v_unit_of_measure15,v_bucket_group15,v_bucket_req15,v_auto_renew_flag15,v_auto_renew_freq15,v_auto_renew_val15,v_auto_renew_day15,v_bucket_action15);--);--\n"
            + END_IF1
            + "     if v_bucket_id16 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id16,v_recharge_date16,v_bucket_bal16,v_bucket_val16,v_expire_date16,'OUTBOUND',v_bucket_benefit16,v_bucket_type16,v_bucket_usage16,v_data_exp_date16,v_unit_of_measure16,v_bucket_group16,v_bucket_req16,v_auto_renew_flag16,v_auto_renew_freq16,v_auto_renew_val16,v_auto_renew_day16,v_bucket_action16);--);--\n"
            + END_IF1
            + "     if v_bucket_id17 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id17,v_recharge_date17,v_bucket_bal17,v_bucket_val17,v_expire_date17,'OUTBOUND',v_bucket_benefit17,v_bucket_type17,v_bucket_usage17,v_data_exp_date17,v_unit_of_measure17,v_bucket_group17,v_bucket_req17,v_auto_renew_flag17,v_auto_renew_freq17,v_auto_renew_val17,v_auto_renew_day17,v_bucket_action17);--);--\n"
            + END_IF1
            + "     if v_bucket_id18 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id18,v_recharge_date18,v_bucket_bal18,v_bucket_val18,v_expire_date18,'OUTBOUND',v_bucket_benefit18,v_bucket_type18,v_bucket_usage18,v_data_exp_date18,v_unit_of_measure18,v_bucket_group18,v_bucket_req18,v_auto_renew_flag18,v_auto_renew_freq18,v_auto_renew_val18,v_auto_renew_day18,v_bucket_action18);--);--\n"
            + END_IF1
            + "     if v_bucket_id19 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id19,v_recharge_date19,v_bucket_bal19,v_bucket_val19,v_expire_date19,'OUTBOUND',v_bucket_benefit19,v_bucket_type19,v_bucket_usage19,v_data_exp_date19,v_unit_of_measure19,v_bucket_group19,v_bucket_req19,v_auto_renew_flag19,v_auto_renew_freq19,v_auto_renew_val19,v_auto_renew_day19,v_bucket_action19);--);--\n"
            + END_IF1
            + "     if v_bucket_id20 is not null then\n"
            + INSERT_TRANSACTION_BUCKETS_STATEMENT
            + "       values(trans_hold,v_bucket_id20,v_recharge_date20,v_bucket_bal20,v_bucket_val20,v_expire_date20,'OUTBOUND',v_bucket_benefit20,v_bucket_type20,v_bucket_usage20,v_data_exp_date20,v_unit_of_measure20,v_bucket_group20,v_bucket_req20,v_auto_renew_flag20,v_auto_renew_freq20,v_auto_renew_val20,v_auto_renew_day20,v_bucket_action20);--);--\n"
            + END_IF1

            + "     if v_first_name is not null then\n"
            + "      insert into gw1.IG_TRANSACTION_ADDL_INFO\n"
            + "      ( transaction_id,first_name,last_name,address_1,address_2,city,state,zip_code, middle_initial, suffix, prefix, SSN_LAST_4, country,osp_account, curr_addr_house_number, curr_addr_direction, curr_addr_street_name, curr_addr_street_type, CURR_ADDR_UNIT )\n"
            + "      values(trans_hold,v_first_name,v_last_name,v_address_1,v_address_2,v_city,v_state,v_zip_code1, v_middleInitial, v_suffix, v_prefix, v_ssnlast4, v_country, v_ospaccount, v_curraddrhousenumber, v_curraddrdirection, v_curraddrstreetname, v_curraddrstreettype, v_curraddressunit);\n"
            + END_IF2;
    String TRACFONE_INSERT_FEATURES_BLOCK =
            "   sa.insert_ig_transaction_features(v_featureTyps, v_featureOutResponse); \n";
    String TRACFONE_INSERT_TRANSACTION_FINAL_BLOCK =
            "                 \n"
                    + "    commit;\n"
                    + "    \n"
                    + "end;";

    String VIEW_ACTION_ITEMID_SQL_COUNT
            = "SELECT Count(1) AS totalRecords\n"
            + "FROM   gw1.ig_transaction ig\n"
            + "WHERE  1 = 1  ";

    String GET_OBJID_TABLE_X_CARRIER_FEATURE = "select objid \n" +
            "from table_x_carrier_features cf\n" +
            "where cf.USE_CF_EXTENSION_FLAG = 'Y' and cf.X_RATE_PLAN = #param_ratePlanName and rownum = 1";

    String GET_ATT_ADDITIONAL_FIELDS = "select account_num, market_code, dealer_code, submarketid from sa.x_cingular_mrkt_info mt where zip = ?";

    // USER HISTORY RELATED TABLES
    String TRACFONE_SEARCH_ALL_USER_HISTORY = "select ID, USER_ID, TYPE, " +
            "to_char(CREATION_DATE, 'yyyy:MM:DD HH24:MI:SS') as CREATION_DATE from COP.COP_ID_USER_HISTORY " +
            "where USER_ID = ? AND TRUNC(CREATION_DATE) >= TO_DATE(?, 'yyyy:MM:DD') AND TRUNC(CREATION_DATE) <= TO_DATE(?, 'yyyy:MM:DD') ";

    String TRACFONE_SEARCH_ALL_USER_HISTORY_DETAILS = "select * from COP.COP_ID_USER_HISTORY_DETAIL " +
            "where HISTORY_ID = ?";

    String TRACFONE_REASSIGN_TRANSACTION_SUCCESS = "Transaction reassigned Successfully";

    String TRACFONE_GET_USER_TASK = "SELECT ut.ID, ut.TASK_NAME, ut.DESCRIPTION, ut.USER_ID, ut.ASSIGNED_USERID, ut.TYPE, " +
            "ut.STATUS, ut.CREATION_DATE, utd.TASK_DETAILS, utd.ID, utd.USER_COMMENTS, " +
            "(select USERNAME from cop.cop_tracfoneoneuser u where u.id = ut.ASSIGNED_USERID) USERNAME FROM cop.COP_USER_TASK ut  " +
            "LEFT outer JOIN cop.COP_USER_TASK_detail utd on ut.ID = utd.USER_TASK_ID " +
            "where TRUNC(ut.CREATION_DATE) >= TO_DATE(?, 'DD/MM/yyyy') " +
            "AND TRUNC(ut.CREATION_DATE) <= TO_DATE(?, 'DD/MM/yyyy') and ut.STATUS in (?";

    String TRACFONE_GET_BULK_INSERTED_SUMMARY_RECORDS = "select to_char(CREATEDATE, 'yyyy:MM:DD HH24:MI:SS') as CREATEDATE, " +
            "CARRIERID, ID from cop.cop_audit where userid = ? and action = ? and carrierid not like 'ERROR%' and " +
            "carrierid not like 'CARRIER_ID%' order by createdate desc";

    String TRACFONE_GET_RECORD_COUNT_AND_CARRERID = "select carrierid,count(1) as COUNT from cop.cop_audit where userid = ? and carrierid in(?, ?) group by carrierid";

    String TRACFONE_GET_RECORD_COUNT = "select count(1) from cop.cop_audit where userid = ? and action = ? " +
            "and carrierid = ? ";

    String TRACFONE_GET_ERROR_DETAILS = "select to_char(CREATEDATE, 'yyyy:MM:DD HH24:MI:SS') as CREATEDATE, " +
            "CARRIERID, ID, DETAILS from cop.cop_audit where carrierid = ? ";

    String TRACFONE_GET_CARRIER_ID_BY_ID = "select CARRIERID from cop.cop_audit where ID = ?";

    String TRACFONE_GET_ASSIGN_TRANSACTION_REPORT = "SELECT ut.ID, ut.status FROM COP.COP_USER_TASK ut where ut.ASSIGNED_USERID = ? " +
            "and ut.CREATION_DATE >= TO_DATE(?, 'DD/MM/yyyy HH24:MI:SS') AND ut.CREATION_DATE <= TO_DATE(?, 'DD/MM/yyyy HH24:MI:SS') " +
            "and ut.type = ? ORDER by ut.status";

    String TRACFONE_GET_TASK_DETAILS = "SELECT TASK_DETAILS FROM COP.COP_USER_TASK_DETAIL UTD where UTD.USER_TASK_ID IN (?";

    String TRACFONE_GET_TRANSACTION_TYPE_REPORT = "select uh.ID, uh.TYPE from COP.COP_ID_USER_HISTORY uh where uh.USER_ID = ? " +
            "AND uh.CREATION_DATE >= TO_DATE(?, 'DD/MM/yyyy HH24:MI:SS') AND uh.CREATION_DATE <= TO_DATE(?, 'DD/MM/yyyy HH24:MI:SS') AND ";

    String TRACFONE_GET_HISTORY_DETAILS = "SELECT ID_DETAIL FROM COP.COP_ID_USER_HISTORY_DETAIL uhd where uhd.HISTORY_ID IN (?";

    String TRACFONE_GET_IG_TRANSACTION_IN_PROGRESS = "select * from GW1.IG_TRANSACTION_IN_PROGRESS where ";

    String TRACFONE_DELETE_IG_TRANSACTION_IN_PROGRESS = "delete from GW1.IG_TRANSACTION_IN_PROGRESS where " +
            "TRANSACTION_ID = ? and trunc(CREATION_DATE)  = TO_DATE(?, 'yyyy:MM:DD') and ";

    String TRACFONE_INSERT_USER_HISTORY = "insert into COP.COP_ID_USER_HISTORY (ID, USER_ID, TYPE, CREATION_DATE, UPDATE_DATE)" +
            " values(?, ?, 'BULK_INSERT', sysdate, sysdate)";

    String TRACFONE_INSERT_USER_HISTORY_DETAIL = "insert into COP.COP_ID_USER_HISTORY_DETAIL (ID, HISTORY_ID, ID_TYPE, ID_DETAIL, " +
            "CREATION_DATE, UPDATE_DATE) values " +
            "(COP.SEQ_COP_ID_USER_HISTORY_DETAIL.NEXTVAL, ?, ?, ?, sysdate, sysdate)";

    String TRACFONE_USER_HISTORY_SEQ_STMT = "SELECT COP.SEQ_COP_ID_USER_HISTORY.NEXTVAL AS USER_HISTORY_ID_SEQ FROM DUAL";

    String TRACFONE_GET_USER_HISTORY_DETAIL = "SELECT uhd.ID_DETAIL from COP.COP_ID_USER_HISTORY_DETAIL uhd, " +
            "cop.COP_ID_USER_HISTORY uh where uh.id = uhd.history_id and uhd.ID_TYPE = ? and " +
            "uh.user_id = ? and uh.type = 'BULK_INSERT'";

    String TRACFONE_INSERT_TEST_OTA_ESN = "INSERT INTO gw1.test_ota_esn (esn) VALUES (?)";

    String TRACFONE_INSERT_TEST_IGATE_ESN = "INSERT INTO SA.TEST_IGATE_ESN (esn, esn_type) VALUES (?, ?)";

    String TRACFONE_CHECK_ESN_TEST_OTA_ESN = "SELECT count(1) from gw1.test_ota_esn where ESN = ?";

    String TRACFONE_CHECK_ESN_TEST_IGATE_ESN = "SELECT count(1) from SA.TEST_IGATE_ESN where ESN = ?";

    String TRACFONE_GET_IG_FAIL_LOGS = "select * from gw1.ig_failed_log where ACTION_ITEM_ID = ?";

    String TRACFONE_GET_COLUMN_DESC = "select COLUMN_NAME, DATA_TYPE, DATA_LENGTH, DATA_PRECISION, DATA_SCALE " +
            "from all_tab_columns where table_name = ? ";
}