
package com.tracfone.service.exception;

/**
 * @author druiz
 * Exception to be thrown from Resource only for UI COP application.
 * Used to bypass the DataPower issue where all HTTP codes besides 200
 * are transformed to 500 fatal.
 */
public class CopUIErrorResponse{
   
    private String errorCode;
    private String errorMessage;
    private int httpCode;
    
        public CopUIErrorResponse(String errorMessage, int httpCode) {
        this.errorCode = "000";
        this.errorMessage = errorMessage;
        this.httpCode = httpCode;
    } 
    
    public CopUIErrorResponse(String errorCode, String errorMessage, int httpCode) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.httpCode = httpCode;
    }   
    
    public CopUIErrorResponse(TracfoneOneException tfOneException, int httpCode) {
        this(tfOneException.getErrorCode(), tfOneException.getErrorMessage(), httpCode);
    }
    
    public CopUIErrorResponse(TracfoneOneException tfOneException) {
        this(tfOneException.getErrorCode(), tfOneException.getErrorMessage(), tfOneException.getHttpCode());
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public int getHttpCode() {
        return httpCode;
    }

    public void setHttpCode(int httpCode) {
        this.httpCode = httpCode;
    }
}