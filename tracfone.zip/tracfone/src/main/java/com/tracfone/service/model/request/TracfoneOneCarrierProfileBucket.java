/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Shireen Fathima
 */
public class TracfoneOneCarrierProfileBucket {

    private String dbEnv;
    private String objectId;
    @NotNull (message = "Profile Id cannot be null")
    @NotBlank (message = "Profile Id cannot be blank")
    @Digits(integer=38, fraction=0, message = "Profile Id must be a number")
    private String profileId;
    @NotNull (message = "Bucket Id cannot be null")
    @NotBlank (message = "Bucket Id cannot be blank")
    @Size(max=30, message = "Bucket Id cannot have more than 30 characters")
    private String bucketId;
    @NotNull (message = "Service Plan Id cannot be null")
    @NotBlank (message = "Service Plan Id cannot be blank")
    @Digits(integer=38, fraction=0, message = "Service Plan Id must be a number")
    private String servicePlanId;
    @NotNull (message = "Active Flag cannot be null")
    @NotBlank (message = "Active Flag cannot be blank")
    @Size(max=1, message = "Active Flag cannot have more than 1 character")
    private String activeFlag;
    @Size(max=40, message = "Unit of Measure cannot have more than 40 characters")
    private String unitOfMeasure;
    @Size(max=50, message = "Bucket Type cannot have more than 50 characters")
    private String bucketType;
    @Size(max=30, message = "Bucket Group cannot have more than 30 characters")
    private String bucketGroup;
    @Size(max=200, message = "Bucket Requirement cannot have more than 200 characters")
    private String bucketRequirement;
    @NotNull (message = "Auto Renew Flag cannot be null")
    @NotBlank (message = "Auto Renew Flag cannot be blank")
    @Size(max=1, message = "Auto Renew Flag cannot have more than 1 character")
    private String autoRenewFlag;
    @Size(max=3, message = "Auto Renew Frequency cannot have more than 3 characters")
    private String autoRenewFrequency;
    @Size(max=30, message = "Auto Renew Value cannot have more than 30 characters")
    private String autoRenewValue;
    @Size(max=30, message = "Auto Renew Day cannot have more than 30 characters")
    private String autoRenewDay;
    @Size(max=100, message = "Benefit Type cannot have more than 100 characters")
    private String benefitType;
    @Digits(integer=38, fraction=0, message = "Bucket Value must be a number")
    private String bucketValue;
    @Size(max=50, message = "SUI Display Type cannot have more than 50 characters")
    private String suiDisplayType;
    @Digits(integer=2, fraction=0, message = "Priority must be a number not more than 99")
    private String priority;
    @Size(max=1, message = "Hide UBI Flag cannot have more than 1 character")
    private String hideUbiFlag;
    private String bucketDesc;
    private String parentShortName;
    private boolean edited;
    @Valid
    private List<TracfoneOneCarrierProfileBucketTier> tracfoneOneCarrierProfileBucketTiers;

    public TracfoneOneCarrierProfileBucket() {
        tracfoneOneCarrierProfileBucketTiers = new ArrayList<>();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getBucketId() {
        return bucketId;
    }

    public void setBucketId(String bucketId) {
        this.bucketId = bucketId;
    }

    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public String getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(String activeFlag) {
        this.activeFlag = activeFlag;
    }

    public String getUnitOfMeasure() {
        return unitOfMeasure;
    }

    public void setUnitOfMeasure(String unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }

    public String getBucketType() {
        return bucketType;
    }

    public void setBucketType(String bucketType) {
        this.bucketType = bucketType;
    }

    public String getBucketGroup() {
        return bucketGroup;
    }

    public void setBucketGroup(String bucketGroup) {
        this.bucketGroup = bucketGroup;
    }

    public String getBucketRequirement() {
        return bucketRequirement;
    }

    public void setBucketRequirement(String bucketRequirement) {
        this.bucketRequirement = bucketRequirement;
    }

    public String getAutoRenewFlag() {
        return autoRenewFlag;
    }

    public void setAutoRenewFlag(String autoRenewFlag) {
        this.autoRenewFlag = autoRenewFlag;
    }

    public String getAutoRenewFrequency() {
        return autoRenewFrequency;
    }

    public void setAutoRenewFrequency(String autoRenewFrequency) {
        this.autoRenewFrequency = autoRenewFrequency;
    }

    public String getAutoRenewValue() {
        return autoRenewValue;
    }

    public void setAutoRenewValue(String autoRenewValue) {
        this.autoRenewValue = autoRenewValue;
    }

    public String getAutoRenewDay() {
        return autoRenewDay;
    }

    public void setAutoRenewDay(String autoRenewDay) {
        this.autoRenewDay = autoRenewDay;
    }

    public String getBenefitType() {
        return benefitType;
    }

    public void setBenefitType(String benefitType) {
        this.benefitType = benefitType;
    }

    public String getBucketValue() {
        return bucketValue;
    }

    public void setBucketValue(String bucketValue) {
        this.bucketValue = bucketValue;
    }

    public String getSuiDisplayType() {
        return suiDisplayType;
    }

    public void setSuiDisplayType(String suiDisplayType) {
        this.suiDisplayType = suiDisplayType;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getHideUbiFlag() {
        return hideUbiFlag;
    }

    public void setHideUbiFlag(String hideUbiFlag) {
        this.hideUbiFlag = hideUbiFlag;
    }

    public boolean isEdited() { return edited; }

    public void setEdited(boolean edited) { this.edited = edited; }

    public String getBucketDesc() {
        return bucketDesc;
    }

    public void setBucketDesc(String bucketDesc) {
        this.bucketDesc = bucketDesc;
    }

    public String getParentShortName() {
        return parentShortName;
    }

    public void setParentShortName(String parentShortName) {
        this.parentShortName = parentShortName;
    }

    public List<TracfoneOneCarrierProfileBucketTier> getTracfoneOneCarrierProfileBucketTiers() {
        return tracfoneOneCarrierProfileBucketTiers;
    }

    public void setTracfoneOneCarrierProfileBucketTiers(List<TracfoneOneCarrierProfileBucketTier> tracfoneOneCarrierProfileBucketTiers) {
        this.tracfoneOneCarrierProfileBucketTiers = tracfoneOneCarrierProfileBucketTiers;
    }
    
    @Override
    public String toString() {
        return "TracfoneOneCarrierProfileBucket{" + "dbEnv=" + dbEnv + ", "
                + "objectId=" + objectId + ", "
                + "profileId=" + profileId + ", "
                + "bucketId=" + bucketId + ", "
                + "servicePlanId=" + servicePlanId + ", "
                + "activeFlag=" + activeFlag + ", "
                + "unitOfMeasure=" + unitOfMeasure + ", "
                + "bucketType=" + bucketType + ", "
                + "bucketGroup=" + bucketGroup + ", "
                + "bucketRequirement=" + bucketRequirement + ", "
                + "autoRenewFlag=" + autoRenewFlag + ", "
                + "autoRenewFrequency=" + autoRenewFrequency + ", "
                + "autoRenewValue=" + autoRenewValue + ", "
                + "autoRenewDay=" + autoRenewDay + ", "
                + "benefitType=" + benefitType + ", "
                + "bucketValue=" + bucketValue + ", "
                + "suiDisplayType=" + suiDisplayType + ", "
                + "priority=" + priority + ", "
                + "hideUbiFlag=" + hideUbiFlag + ", "
                + "bucketDesc=" + bucketDesc + ", "
                + "parentShortName=" + parentShortName + ", "
                + "edited" + edited + ", "
                + "tracfoneOneCarrierProfileBucketTiers=" + tracfoneOneCarrierProfileBucketTiers + '}';
    }
    

}
