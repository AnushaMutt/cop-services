package com.tracfone.service.model.retail.response;

public class TFOneRetailBrand {
    private String objId;
    private String oneSecUserId;
    private String status;
    private String brand;
    private String brandLong;
    private String insertDate;
    private String updateDate;
    private String cRtlTraitLogicRuleId;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getBrandLong() {
        return brandLong;
    }

    public void setBrandLong(String brandLong) {
        this.brandLong = brandLong;
    }

    public String getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(String insertDate) {
        this.insertDate = insertDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getOneSecUserId() {
        return oneSecUserId;
    }

    public void setOneSecUserId(String oneSecUserId) {
        this.oneSecUserId = oneSecUserId;
    }

    public String getcRtlTraitLogicRuleId() {
        return cRtlTraitLogicRuleId;
    }

    public void setcRtlTraitLogicRuleId(String cRtlTraitLogicRuleId) {
        this.cRtlTraitLogicRuleId = cRtlTraitLogicRuleId;
    }

    @Override
    public String toString() {
        return "TFOneRetailBrand{" +
                "objId='" + objId + '\'' +
                ", oneSecUserId='" + oneSecUserId + '\'' +
                ", status='" + status + '\'' +
                ", brand='" + brand + '\'' +
                ", brandLong='" + brandLong + '\'' +
                ", insertDate=" + insertDate +
                ", updateDate=" + updateDate +
                ", cRtlTraitLogicRuleId='" + cRtlTraitLogicRuleId + '\'' +
                '}';
    }
}
