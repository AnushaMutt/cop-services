/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.report.TracfoneAdhocReportRequest;
import com.tracfone.service.model.response.TracfoneOneReport;

import javax.ejb.Local;

/**
 * @author spulavarthy
 */
@Local
public interface TracfoneControllerReportLocal {

    TracfoneOneReport runAdhocMonitorReport(TracfoneAdhocReportRequest request) throws TracfoneOneException;

    TracfoneOneReport runAdhocPCRFMonitorReport(TracfoneAdhocReportRequest adhocReportRequest) throws TracfoneOneException;

    TracfoneOneReport runAdhocTTMonitorReport(TracfoneAdhocReportRequest adhocReportRequest) throws TracfoneOneException;
}
