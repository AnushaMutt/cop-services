package com.tracfone.service.controller;

import com.tracfone.service.model.request.TracfoneOneIGCarrierNotification;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import java.io.UnsupportedEncodingException;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Gaurav.Sharma
 */
@Local
public interface TracfoneOneIgCarrierNotficationControllerLocal {

    public String getResponse(TracfoneOneIGCarrierNotification carrierNotification) throws TracfoneOneException, UnsupportedEncodingException;
    
}
