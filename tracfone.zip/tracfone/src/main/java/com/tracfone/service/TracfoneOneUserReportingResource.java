package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.controller.TracfoneOneUserReportingControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneUserTask;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneUserReporting;
import com.tracfone.service.model.response.TFOneUserTask;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.List;

@Path("dashboard")
public class TracfoneOneUserReportingResource {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneUserReportingResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @Context
    private SecurityContext securityContext;

    @EJB
    private TracfoneControllerLocal tracfoneController;

    @EJB
    private TracfoneControllerLocalAction tracfoneControllerAction;

    @EJB
    private TracfoneOneUserReportingControllerLocal tracfoneOneUserReportingController;

    @GET
    @Path("userreporting/userlist")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllUsers() {
        List<TFOneAdminUser> tfOneAdminUsers = null;
        try {
            tfOneAdminUsers = tracfoneController.getAllUsers(getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            LOGGER.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneAdminUsers), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("userreporting/updateusertask")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateUserTask(final TracfoneOneUserTask tfOneUserTask) {
        TFOneUserTask tfUserTask;
        try {
            tfUserTask = tracfoneControllerAction.updateUserTask(tfOneUserTask, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfUserTask), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("userreporting/allusertasks")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllUserTasks(TracfoneOneUserTask tracfoneOneUserTask) {
        List<TFOneUserTask> userTasks;
        try {
            userTasks = tracfoneOneUserReportingController.getAllUserTasks(tracfoneOneUserTask);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(userTasks), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("userreporting/reassigntransaction")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response reassignTransaction(TracfoneOneUserTask tracfoneOneUserTask) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneUserReportingController.reassignTransaction(tracfoneOneUserTask,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("userreporting/assigntransactionreport")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response assignTransactionReport(TracfoneOneUserTask tracfoneOneUserTask) {
        List<TFOneUserReporting> response;
        try {
            response = tracfoneOneUserReportingController.assignTransactionReport(tracfoneOneUserTask);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("userreporting/transactiontypereport")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response transactionTypeReport(TracfoneOneUserTask tracfoneOneUserTask) {
        List<TFOneUserReporting> response;
        try {
            response = tracfoneOneUserReportingController.transactionTypeReport(tracfoneOneUserTask);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves the user object making request from the principal.
     *
     * @return
     */
    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }

}
