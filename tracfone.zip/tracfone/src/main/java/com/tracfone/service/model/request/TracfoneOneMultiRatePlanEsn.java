package com.tracfone.service.model.request;


import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * X_MULTI_RATE_PLAN_ESNS
 *
 * @author Pritesh.Singh
 */
public class TracfoneOneMultiRatePlanEsn {
    private String dbEnv;
    @NotNull(message = "X Esn cannot be null")
    @NotBlank(message = "X Esn cannot be blank")
    @Size(max = 30, message = "X Esn cannot have more than 30 characters")
    private String xEsn;
    @Digits(integer=38, fraction=0, message = "X Priority must be a number")
    private String xPriority;
    @NotNull (message = "Service Plan Id cannot be null")
    @NotBlank (message = "Service Plan Id cannot be blank")
    @Digits(integer=38, fraction=0, message = "Service Plan Id must be a number")
    private String xServicePlanId;
    @Size(max = 300, message = "X Reason cannot have more than 300 characters")
    private String xReason;
    @Size(max = 1, message = "Del Flag cannot have more than 1 characters")
    private String delFlag;
    @Size(max = 30, message = "X Product Id cannot have more than 30 characters")
    private String xProductId;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getxEsn() {
        return xEsn;
    }

    public void setxEsn(String xEsn) {
        this.xEsn = xEsn;
    }

    public String getxPriority() {
        return xPriority;
    }

    public void setxPriority(String xPriority) {
        this.xPriority = xPriority;
    }

    public String getxServicePlanId() {
        return xServicePlanId;
    }

    public void setxServicePlanId(String xServicePlanId) {
        this.xServicePlanId = xServicePlanId;
    }

    public String getxReason() {
        return xReason;
    }

    public void setxReason(String xReason) {
        this.xReason = xReason;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public String getxProductId() {
        return xProductId;
    }

    public void setxProductId(String xProductId) {
        this.xProductId = xProductId;
    }

    @Override
    public String toString() {
        return "TracfoneOneMultiRatePlanEsns{" +
                "dbEnv='" + dbEnv + '\'' +
                ", xEsn='" + xEsn + '\'' +
                ", xPriority='" + xPriority + '\'' +
                ", xServicePlanId='" + xServicePlanId + '\'' +
                ", xReason='" + xReason + '\'' +
                ", delFlag='" + delFlag + '\'' +
                ", xProductId='" + xProductId + '\'' +
                '}';
    }
}
