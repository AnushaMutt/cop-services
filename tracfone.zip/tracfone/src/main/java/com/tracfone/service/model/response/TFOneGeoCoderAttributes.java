package com.tracfone.service.model.response;

public class TFOneGeoCoderAttributes {
    private String address;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
