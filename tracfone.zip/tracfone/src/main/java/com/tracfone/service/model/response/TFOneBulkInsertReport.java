package com.tracfone.service.model.response;

public class TFOneBulkInsertReport {
    private String id;
    private String createDate;
    private String status;
    private String totalRecord;
    private String successCount;
    private String errorCount;
    private String details;
    private String uniqueIdentifier;

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTotalRecord() {
        return totalRecord;
    }

    public void setTotalRecord(String totalRecord) {
        this.totalRecord = totalRecord;
    }

    public String getSuccessCount() {
        return successCount;
    }

    public void setSuccessCount(String successCount) {
        this.successCount = successCount;
    }

    public String getErrorCount() {
        return errorCount;
    }

    public void setErrorCount(String errorCount) {
        this.errorCount = errorCount;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getUniqueIdentifier() {
        return uniqueIdentifier;
    }

    public void setUniqueIdentifier(String uniqueIdentifier) {
        this.uniqueIdentifier = uniqueIdentifier;
    }

    @Override
    public String toString() {
        return "TFOneBulkInsertReport{" +
                "id='" + id + '\'' +
                ", createDate='" + createDate + '\'' +
                ", status='" + status + '\'' +
                ", totalRecord='" + totalRecord + '\'' +
                ", successCount='" + successCount + '\'' +
                ", errorCount='" + errorCount + '\'' +
                ", details='" + details + '\'' +
                ", uniqueIdentifier='" + uniqueIdentifier + '\'' +
                '}';
    }
}
