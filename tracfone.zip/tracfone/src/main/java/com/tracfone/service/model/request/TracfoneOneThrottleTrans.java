package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * W3CI.table_x_throttling_transaction
 * used for rework & requeue
 */
public class TracfoneOneThrottleTrans {

    private String dbEnv;
    private String objId;
    @Size(max = 30, message = "Transaction Num cannot have more than 30 characters")
    private String transactionNum;
    @Digits(integer = 38, fraction = 0, message = "Rule Id must be a number")
    private String ruleId;
    @Size(max = 30, message = "MIN cannot have more than 30 characters")
    private String min;
    @Size(max = 30, message = "ESN cannot have more than 30 characters")
    private String esn;
    @Size(max = 30, message = "Transact Type cannot have more than 30 characters")
    private String transactionType;
    @Size(max = 10, message = "Status cannot have more than 10 characters")
    private String status;
    @Size(max = 30, message = "API Status cannot have more than 30 characters")
    private String apiStatus;
    @Size(max = 256, message = "API Message cannot have more than 256 characters")
    private String apiMessage;
    @Digits(integer = 38, fraction = 0, message = "Subscriber Id must be a number")
    private String subscriberId;
    @Digits(integer = 38, fraction = 0, message = "Group Id must be a number")
    private String groupId;
    @Digits(integer = 4, fraction = 0, message = "Propagate Flag Value must be a number")
    private String propagateFlagValue;
    @Size(max = 40, message = "Parent Name cannot have more than 40 characters")
    private String parentName;
    @Digits(integer = 2, fraction = 0, message = "Usage Tier Id must be a number")
    private String usageTierId;
    @Size(max = 30, message = "Cos cannot have more than 30 characters")
    private String cos;
    @Size(max = 30, message = "Policy Name cannot have more than 30 characters")
    private String policyName;
    @Size(max = 30, message = "Entitlement cannot have more than 30 characters")
    private String entitlement;
    @Digits(integer = 38, fraction = 0, message = "Priority must be a number")
    private String priority;
    @Digits(integer = 15, fraction = 2, message = "Threshold must be a number")
    private String threshold;
    @Size(max = 2, message = "Throttle Group Type cannot have more than 2 characters")
    private String throttleGroupType;
    private String creationDate;

    private boolean sitOrTst;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getTransactionNum() {
        return transactionNum;
    }

    public void setTransactionNum(String transactionNum) {
        this.transactionNum = transactionNum;
    }

    public String getRuleId() {
        return ruleId;
    }

    public void setRuleId(String ruleId) {
        this.ruleId = ruleId;
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getEsn() {
        return esn;
    }

    public void setEsn(String esn) {
        this.esn = esn;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getApiStatus() {
        return apiStatus;
    }

    public void setApiStatus(String apiStatus) {
        this.apiStatus = apiStatus;
    }

    public String getApiMessage() {
        return apiMessage;
    }

    public void setApiMessage(String apiMessage) {
        this.apiMessage = apiMessage;
    }

    public String getSubscriberId() {
        return subscriberId;
    }

    public void setSubscriberId(String subscriberId) {
        this.subscriberId = subscriberId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getPropagateFlagValue() {
        return propagateFlagValue;
    }

    public void setPropagateFlagValue(String propagateFlagValue) {
        this.propagateFlagValue = propagateFlagValue;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public String getUsageTierId() {
        return usageTierId;
    }

    public void setUsageTierId(String usageTierId) {
        this.usageTierId = usageTierId;
    }

    public String getCos() {
        return cos;
    }

    public void setCos(String cos) {
        this.cos = cos;
    }

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    public String getEntitlement() {
        return entitlement;
    }

    public void setEntitlement(String entitlement) {
        this.entitlement = entitlement;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getThreshold() {
        return threshold;
    }

    public void setThreshold(String threshold) {
        this.threshold = threshold;
    }

    public String getThrottleGroupType() {
        return throttleGroupType;
    }

    public void setThrottleGroupType(String throttleGroupType) {
        this.throttleGroupType = throttleGroupType;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public boolean isSitOrTst() {
        return sitOrTst;
    }

    public void setSitOrTst(boolean sitOrTst) {
        this.sitOrTst = sitOrTst;
    }

    @Override
    public String toString() {
        return "TracfoneOneThrottleTrans{" +
                "dbEnv='" + dbEnv + '\'' +
                ", objId='" + objId + '\'' +
                ", transactionNum='" + transactionNum + '\'' +
                ", ruleId='" + ruleId + '\'' +
                ", min='" + min + '\'' +
                ", esn='" + esn + '\'' +
                ", transactionType='" + transactionType + '\'' +
                ", status='" + status + '\'' +
                ", apiStatus='" + apiStatus + '\'' +
                ", apiMessage='" + apiMessage + '\'' +
                ", subscriberId='" + subscriberId + '\'' +
                ", groupId='" + groupId + '\'' +
                ", propagateFlagValue='" + propagateFlagValue + '\'' +
                ", parentName='" + parentName + '\'' +
                ", usageTierId='" + usageTierId + '\'' +
                ", cos='" + cos + '\'' +
                ", policyName='" + policyName + '\'' +
                ", entitlement='" + entitlement + '\'' +
                ", priority='" + priority + '\'' +
                ", threshold='" + threshold + '\'' +
                ", throttleGroupType='" + throttleGroupType + '\'' +
                ", creationDate='" + creationDate + '\'' +
                ", sitOrTst=" + sitOrTst +
                '}';
    }
}
