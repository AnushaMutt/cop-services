package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TFRatePlan;
import com.tracfone.service.model.request.TracfoneOneNewTransaction;
import com.tracfone.service.model.request.TracfoneOneSearchServicePlanModel;
import com.tracfone.service.model.request.TracfoneOneWizardArchive;
import com.tracfone.service.model.response.TFOneActionItemBucket;
import com.tracfone.service.model.response.TFOneCarrierChildPlan;
import com.tracfone.service.model.response.TFOneCarrierRatePlan;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneFeatures;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneRPFeatureNameList;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import com.tracfone.service.model.response.TFOneServicePlan;
import com.tracfone.service.model.response.TFOneTransactionArchive;
import com.tracfone.service.model.response.TFTransactionCarrier;

import javax.ejb.Local;
import java.util.HashMap;
import java.util.List;

/**
 * @author Srinivas Murthy Pulavarthy
 */
@Local
public interface TracfoneTransactionWizardControllerLocal {

    /**
     * @param userId
     * @param showTemplates
     * @return
     * @throws TracfoneOneException
     */
    List<TFTransactionCarrier> getCarriers(Integer userId, boolean showTemplates) throws TracfoneOneException;

    /**
     * @param userId
     * @param carrier
     * @return
     * @throws TracfoneOneException
     */
    TFOneCarrierRatePlan getCarrierRatePlan(Integer userId, String carrier) throws TracfoneOneException;

    /**
     * @param userId
     * @param carrier
     * @return
     * @throws TracfoneOneException
     */
    TFOneCarrierServicePlan getCarrierServicePlans(Integer userId, String carrier) throws TracfoneOneException;

    /**
     * @param userId
     * @param carrier
     * @return
     * @throws TracfoneOneException
     */
    TFOneCarrierChildPlan getCarrierChildPlans(Integer userId, String carrier) throws TracfoneOneException;

    /**
     * @param userId
     * @param profileId
     * @return
     * @throws TracfoneOneException
     */
    List<TFOneServicePlan> getServicePlansForProfileId(Integer userId, String profileId) throws TracfoneOneException;

    /**
     * @param userId
     * @param profileId
     * @return
     * @throws TracfoneOneException
     */
    TFOneRatePlanProfile getFeatures(Integer userId, String profileId) throws TracfoneOneException;

    /**
     * @param userId
     * @param tfRatePlan
     * @return
     * @throws TracfoneOneException
     */
    List<TFOneActionItemBucket> getBuckets(Integer userId, TFRatePlan tfRatePlan) throws TracfoneOneException;

    /**
     * @param userId
     * @param profileId
     * @param servicePlanId
     * @return
     * @throws TracfoneOneException
     */
    List<TFOneActionItemBucket> getBucketsForProfileIdAndServicePlan(Integer userId, String profileId, String servicePlanId) throws TracfoneOneException;

    /**
     * @param tfOneNewTransaction
     * @param userId
     * @param userInitials
     * @return
     * @throws TracfoneOneException
     */
    TFOneGeneralResponse insertTransaction(TracfoneOneNewTransaction tfOneNewTransaction, int userId, String userInitials) throws TracfoneOneException;

    /**
     * @param userId
     * @param profileId
     * @param dbEnv
     * @return
     * @throws TracfoneOneException
     */
    List<TFOneTransactionArchive> getTransactionsInsertedByUser(Integer userId, int profileId, String dbEnv) throws TracfoneOneException;


    /**
     * @param profileId
     * @param dbEnv
     * @return
     * @throws TracfoneOneException
     */
    List<TFOneTransactionArchive> getAllTransactionsInserted(int profileId, String dbEnv) throws TracfoneOneException;

    /**
     * @param request
     * @return
     * @throws TracfoneOneException
     */
    TFOneGeneralResponse extendDeactDateDefault(TracfoneOneWizardArchive request) throws TracfoneOneException;


    /**
     * @param request
     * @return
     * @throws TracfoneOneException
     */
    TFOneGeneralResponse extendDeactDateManual(List<TracfoneOneWizardArchive> request) throws TracfoneOneException;

    /**
     * @param featureValuesString
     * @return
     * @throws TracfoneOneException
     */
    HashMap<String, String> getMatchingFeaturesNames(String featureValuesString) throws TracfoneOneException;

    /**
     * @param userId
     * @param ratePlanName
     * @return
     */
    TFOneCarrierRatePlan getCarrierRatePlanDefaultProfile(int userId, String ratePlanName) throws TracfoneOneException;

    List<TFOneRatePlanProfile> getProfilesForFeature(int userId, TracfoneOneSearchServicePlanModel tracfoneOneSearchServicePlanModel) throws TracfoneOneException;

    List<TFOneFeatures> getRatePlanByProfile(int userId, String profileid) throws TracfoneOneException;

    List<TFOneRPFeatureNameList> getAllMasterFeatures() throws TracfoneOneException;
}