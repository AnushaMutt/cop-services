package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.retail.TracfoneOneRetailAdminActionLocal;
import com.tracfone.service.controller.retail.TracfoneOneRetailStoreControllerLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneJobTask;
import com.tracfone.service.model.retail.request.TracfoneOneRetailBrand;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrier;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierDetail;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierPrefDetail;
import com.tracfone.service.model.retail.request.TracfoneOneRetailCarrierPrefGroup;
import com.tracfone.service.model.retail.request.TracfoneOneRetailMaster;
import com.tracfone.service.model.retail.request.TracfoneOneRetailParent;
import com.tracfone.service.model.retail.request.TracfoneOneRetailParentRule;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTech;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTpAdminSearchModel;
import com.tracfone.service.model.retail.request.TracfoneOneTraitLogicRule;
import com.tracfone.service.model.retail.response.TFOneRetailBrand;
import com.tracfone.service.model.retail.response.TFOneRetailCarrier;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierDetail;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierPrefDetail;
import com.tracfone.service.model.retail.response.TFOneRetailCarrierPrefGroup;
import com.tracfone.service.model.retail.response.TFOneRetailMaster;
import com.tracfone.service.model.retail.response.TFOneRetailParent;
import com.tracfone.service.model.retail.response.TFOneRetailParentRule;
import com.tracfone.service.model.retail.response.TFOneRetailTech;
import com.tracfone.service.model.retail.response.TFOneRetailTpAdminSearchResults;
import com.tracfone.service.model.retail.response.TFOneTraitLogicRule;
import com.tracfone.service.util.TracfoneOneConstantRetailStore;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.validation.Valid;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Path("admin")
public class TracfoneOneRetailStoreAdminResource implements TracfoneOneConstantRetailStore {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneRetailStoreAdminResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @Context
    private SecurityContext securityContext;

    @EJB
    private TracfoneOneRetailAdminActionLocal tracfoneOneRetailAdminAction;

    @EJB
    private TracfoneOneRetailStoreControllerLocal tracfoneOneRetailStoreController;

    /**
     * This method is used to get all Carriers
     *
     * @return
     */
    @GET
    @Path("retailmanagement/getcarriers")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarriers() {
        List<TFOneRetailCarrier> tfOneRetailCarriers = new ArrayList<>();
        try {
            tfOneRetailCarriers = tracfoneOneRetailAdminAction.getCarriers();
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_CARRIERS, TRACFONE_GET_ALL_CARRIERS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailCarriers), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a carrier
     *
     * @param tracfoneOneRetailCarrier
     * @return
     */
    @POST
    @Path("retailmanagement/addcarrier")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarrier(@Valid final TracfoneOneRetailCarrier tracfoneOneRetailCarrier) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.insertCarrier(tracfoneOneRetailCarrier,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_ADD_CARRIER, TRACFONE_ADD_CARRIER_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a carrier
     *
     * @param tracfoneOneRetailCarrier
     * @return
     */
    @POST
    @Path("retailmanagement/updatecarrier")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrier(@Valid final TracfoneOneRetailCarrier tracfoneOneRetailCarrier) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.updateCarrier(tracfoneOneRetailCarrier,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_UPDATE_CARRIER, TRACFONE_UPDATE_CARRIER_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Brands
     *
     * @return
     */
    @GET
    @Path("retailmanagement/getbrands")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBrands() {
        List<TFOneRetailBrand> tfOneRetailBrands = new ArrayList<>();
        try {
            tfOneRetailBrands = tracfoneOneRetailAdminAction.getBrands();
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_BRANDS, TRACFONE_GET_ALL_BRANDS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailBrands), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a Brand
     *
     * @param tracfoneOneRetailBrand
     * @return
     */
    @POST
    @Path("retailmanagement/addbrand")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertBrand(@Valid final TracfoneOneRetailBrand tracfoneOneRetailBrand) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.insertBrand(tracfoneOneRetailBrand,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_ADD_BRAND, TRACFONE_ADD_BRAND_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a Brand
     *
     * @param tracfoneOneRetailBrand
     * @return
     */
    @POST
    @Path("retailmanagement/updatebrand")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateBrand(@Valid final TracfoneOneRetailBrand tracfoneOneRetailBrand) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.updateBrand(tracfoneOneRetailBrand,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_UPDATE_BRAND, TRACFONE_UPDATE_BRAND_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Brands
     *
     * @return
     */
    @GET
    @Path("retailmanagement/gettraitlogicrules")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getTraitLogicRules() {
        List<TFOneTraitLogicRule> tfOneTraitLogicRules = new ArrayList<>();
        try {
            tfOneTraitLogicRules = tracfoneOneRetailAdminAction.getTraitLogicRules();
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_TRAIT_LOGIC_RULES, TRACFONE_GET_ALL_TRAIT_LOGIC_RULES_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneTraitLogicRules), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a record into C_RTL_TRAIT_LOGIC_RULE
     *
     * @param tracfoneOneTraitLogicRule
     * @return
     */
    @POST
    @Path("retailmanagement/addtraitlogicrule")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertTraitLogicRule(final TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.insertTraitLogicRule(tracfoneOneTraitLogicRule,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_ADD_TRAIT_LOGIC_RULE, TRACFONE_ADD_TRAIT_LOGIC_RULE_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a record into C_RTL_TRAIT_LOGIC_RULE based on OBJID
     *
     * @param tracfoneOneTraitLogicRule
     * @return
     */
    @POST
    @Path("retailmanagement/updatetraitlogicrule")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateTraitLogicRule(final TracfoneOneTraitLogicRule tracfoneOneTraitLogicRule) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.updateTraitLogicRule(tracfoneOneTraitLogicRule,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_UPDATE_TRAIT_LOGIC_RULE, TRACFONE_UPDATE_TRAIT_LOGIC_RULE_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Techs
     *
     * @return
     */
    @GET
    @Path("retailmanagement/gettechs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getTechs() {
        List<TFOneRetailTech> tfOneRetailTechs = new ArrayList<>();
        try {
            tfOneRetailTechs = tracfoneOneRetailAdminAction.getTechs();
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_TECHS, TRACFONE_GET_ALL_TECHS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailTechs), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a record
     *
     * @param tracfoneOneRetailTech
     * @return
     */
    @POST
    @Path("retailmanagement/addtech")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertTech(final TracfoneOneRetailTech tracfoneOneRetailTech) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.insertTech(tracfoneOneRetailTech,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_ADD_TECH, TRACFONE_ADD_TECH_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a tech record
     *
     * @param tracfoneOneRetailTech
     * @return
     */
    @POST
    @Path("retailmanagement/updatetech")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateTech(final TracfoneOneRetailTech tracfoneOneRetailTech) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.updateTech(tracfoneOneRetailTech,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_UPDATE_TECH, TRACFONE_UPDATE_TECH_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Carrier Details
     *
     * @return
     */
    @GET
    @Path("retailmanagement/getcarrierdetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierDetails() {
        List<TFOneRetailCarrierDetail> tfOneRetailCarrierDetails = new ArrayList<>();
        try {
            tfOneRetailCarrierDetails = tracfoneOneRetailAdminAction.getCarrierDetails();
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_CARRIER_DETAILS, TRACFONE_GET_ALL_CARRIER_DETAILS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailCarrierDetails), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Carrier Details
     *
     * @return
     */
    @GET
    @Path("retailmanagement/getallcarrierdetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllCarrierDetails() {
        List<TFOneRetailCarrierDetail> tfOneRetailCarrierDetails = new ArrayList<>();
        try {
            tfOneRetailCarrierDetails = tracfoneOneRetailAdminAction.getAllCarrierDetails();
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_CARRIER_DETAILS, TRACFONE_GET_ALL_CARRIER_DETAILS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailCarrierDetails), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Carrier Details
     *
     * @return
     */
    @GET
    @Path("retailmanagement/{brandid}/getcarrierdetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierDetailsByBrand(@PathParam("brandid") final String brandId) {
        List<TFOneRetailCarrierDetail> tfOneRetailCarrierDetails = new ArrayList<>();
        try {
            tfOneRetailCarrierDetails = tracfoneOneRetailAdminAction.getCarrierDetailsByBrand(brandId);
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_CARRIER_DETAILS, TRACFONE_GET_ALL_CARRIER_DETAILS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailCarrierDetails), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a record in carrier detail
     *
     * @param tracfoneOneRetailCarrierDetail
     * @return
     */
    @POST
    @Path("retailmanagement/addcarrierdetail")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarrierDetail(@Valid final TracfoneOneRetailCarrierDetail tracfoneOneRetailCarrierDetail) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.insertCarrierDetail(tracfoneOneRetailCarrierDetail,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_ADD_CARRIER_DETAIL, TRACFONE_ADD_CARRIER_DETAIL_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a record in carrier detail
     *
     * @param tracfoneOneRetailCarrierDetail
     * @return
     */
    @POST
    @Path("retailmanagement/updatecarrierdetail")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrierDetail(@Valid final TracfoneOneRetailCarrierDetail tracfoneOneRetailCarrierDetail) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.updateCarrierDetail(tracfoneOneRetailCarrierDetail,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_UPDATE_CARRIER_DETAIL, TRACFONE_UPDATE_CARRIER_DETAIL_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Carrier Details
     *
     * @return
     */
    @GET
    @Path("retailmanagement/getcarrierprefgroups")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierPrefGroups() {
        List<TFOneRetailCarrierPrefGroup> tfOneRetailCarrierPrefGroups = new ArrayList<>();
        try {
            tfOneRetailCarrierPrefGroups = tracfoneOneRetailAdminAction.getCarrierPrefGroups();
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_CARRIER_PREF_GROUPS, TRACFONE_GET_ALL_CARRIER_PREF_GROUPS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailCarrierPrefGroups), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Carrier Details
     *
     * @return
     */
    @GET
    @Path("retailmanagement/{carrierprefgroupid}/getcarrierprefdetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierPrefDetails(@PathParam("carrierprefgroupid") final String carrierPrefGroupId) {
        List<TFOneRetailCarrierPrefDetail> tfOneRetailCarrierPrefDetails = new ArrayList<>();
        try {
            tfOneRetailCarrierPrefDetails = tracfoneOneRetailAdminAction.getCarrierPrefDetails(carrierPrefGroupId);
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_CARRIER_DETAILS, TRACFONE_GET_ALL_CARRIER_DETAILS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailCarrierPrefDetails), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a new Carrier Pref Details
     *
     * @return
     */
    @POST
    @Path("retailmanagement/addcarrierprefdetail")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarrierPrefDetail(@Valid final TracfoneOneRetailCarrierPrefDetail tracfoneOneRetailCarrierPrefDetail) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.insertCarrierPrefDetail(tracfoneOneRetailCarrierPrefDetail,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_ADD_CARRIER_PREF, TRACFONE_ADD_CARRIER_PREF_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete a Carrier Pref Details
     *
     * @return
     */
    @POST
    @Path("retailmanagement/deletecarrierprefdetail/{carrierprefdetailid}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteCarrierPrefDetail(@PathParam("carrierprefdetailid") final String carrierPrefDetailId) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.deleteCarrierPrefDetail(carrierPrefDetailId,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_DELETE_CARRIER_PREF, TRACFONE_DELETE_CARRIER_PREF_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a record in carrier pref group
     *
     * @param tracfoneOneRetailCarrierPrefGroup
     * @return
     */
    @POST
    @Path("retailmanagement/addcarrierprefgroup")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarrierPrefGroup(@Valid final TracfoneOneRetailCarrierPrefGroup tracfoneOneRetailCarrierPrefGroup) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.insertCarrierPrefGroup(tracfoneOneRetailCarrierPrefGroup,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_ADD_CARRIER_PREF_GROUP, TRACFONE_ADD_CARRIER_PREF_GROUP_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a record in carrier pref group
     *
     * @param tracfoneOneRetailCarrierPrefGroup
     * @return
     */
    @POST
    @Path("retailmanagement/updatecarrierprefgroup")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrierPrefGroup(@Valid final TracfoneOneRetailCarrierPrefGroup tracfoneOneRetailCarrierPrefGroup) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.updateCarrierPrefGroup(tracfoneOneRetailCarrierPrefGroup,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_UPDATE_CARRIER_PREF_GROUP, TRACFONE_UPDATE_CARRIER_PREF_GROUP_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Parents
     *
     * @return
     */
    @GET
    @Path("retailmanagement/getparents")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getParents() {
        List<TFOneRetailParent> tfOneRetailParents = new ArrayList<>();
        try {
            tfOneRetailParents = tracfoneOneRetailAdminAction.getParents();
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_PARENTS, TRACFONE_GET_ALL_PARENTS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailParents), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a record in parent
     *
     * @param tracfoneOneRetailParent
     * @return
     */
    @POST
    @Path("retailmanagement/addparent")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertParent(@Valid final TracfoneOneRetailParent tracfoneOneRetailParent) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.insertParent(tracfoneOneRetailParent,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_ADD_PARENT, TRACFONE_ADD_PARENT_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a record in parent
     *
     * @param tracfoneOneRetailParent
     * @return
     */
    @POST
    @Path("retailmanagement/updateparent")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateParent(@Valid final TracfoneOneRetailParent tracfoneOneRetailParent) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.updateParent(tracfoneOneRetailParent,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_UPDATE_PARENT, TRACFONE_UPDATE_PARENT_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Masters
     *
     * @return
     */
    @GET
    @Path("retailmanagement/{parentid}/getmasters")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getMasters(@PathParam("parentid") final String parentId) {
        List<TFOneRetailMaster> tfOneRetailMasters = new ArrayList<>();
        try {
            tfOneRetailMasters = tracfoneOneRetailAdminAction.getMasters(parentId);
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_MASTERS, TRACFONE_GET_ALL_MASTERS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailMasters), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a record in master
     *
     * @param tracfoneOneRetailMaster
     * @return
     */
    @POST
    @Path("retailmanagement/addmaster")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertMaster(@Valid final TracfoneOneRetailMaster tracfoneOneRetailMaster) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.insertMaster(tracfoneOneRetailMaster,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_ADD_MASTER, TRACFONE_ADD_MASTER_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a record in master
     *
     * @param tracfoneOneRetailMaster
     * @return
     */
    @POST
    @Path("retailmanagement/updatemaster")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateMaster(@Valid final TracfoneOneRetailMaster tracfoneOneRetailMaster) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.updateMaster(tracfoneOneRetailMaster,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_UPDATE_MASTER, TRACFONE_UPDATE_MASTER_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Masters
     *
     * @return
     */
    @GET
    @Path("retailmanagement/{parentid}/getparentrules")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getParentRules(@PathParam("parentid") final String parentId) {
        List<TFOneRetailParentRule> tfOneRetailParentRules = new ArrayList<>();
        try {
            tfOneRetailParentRules = tracfoneOneRetailAdminAction.getParentRules(parentId);
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_PARENT_RULES, TRACFONE_GET_ALL_PARENT_RULES_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailParentRules), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a record in parent rule
     *
     * @param tracfoneOneRetailParentRule
     * @return
     */
    @POST
    @Path("retailmanagement/addparentrule")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertParentRule(@Valid final TracfoneOneRetailParentRule tracfoneOneRetailParentRule) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.insertParentRule(tracfoneOneRetailParentRule,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_ADD_PARENT_RULE, TRACFONE_ADD_PARENT_RULE_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a record in parent rule
     *
     * @param tracfoneOneRetailParentRule
     * @return
     */
    @POST
    @Path("retailmanagement/updateparentrule")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateParentRule(@Valid final TracfoneOneRetailParentRule tracfoneOneRetailParentRule) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.updateParentRule(tracfoneOneRetailParentRule,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_UPDATE_PARENT_RULE, TRACFONE_UPDATE_PARENT_RULE_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for a record in C RTL TP NORM
     *
     * @param retailTpAdminSearchModel
     * @return
     */
    @POST
    @Path("retailmanagement/searchtpnorm")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchTpNorm(final TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel) {
        TFOneRetailTpAdminSearchResults tfOneRetailTpAdminSearchResults;
        try {
            tfOneRetailTpAdminSearchResults = tracfoneOneRetailAdminAction.searchTpNorm(retailTpAdminSearchModel);
        } catch (Exception e) {
            return handleException(e, TRACFONE_SEARCH_TP_NORMS, TRACFONE_SEARCH_TP_NORMS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailTpAdminSearchResults), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update tp norm
     *
     * @param retailTpAdminSearchModel
     * @return
     */
    @POST
    @Path("retailmanagement/updatetpnorms")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateTpNorms(final TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.updateTpNorms(retailTpAdminSearchModel,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_UPDATE_TP_NORM, TRACFONE_UPDATE_TP_NORM_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert tp norms
     *
     * @param retailTpAdminSearchModel
     * @return
     */
    @POST
    @Path("retailmanagement/addtpnorms")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertTpNorms(final TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailStoreController.insertTpNorms(retailTpAdminSearchModel,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_INSERT_TP_NORM, TRACFONE_INSERT_TP_NORM_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all States for TP Admin tab
     *
     * @return
     */
    @GET
    @Path("retailmanagement/getstates")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getStates() {
        List<String> states = new ArrayList<>();
        try {
            states = tracfoneOneRetailAdminAction.getStates();
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_STATES, TRACFONE_GET_ALL_STATES_MESSAGE);
        }
        return Response.ok(gson.toJson(states), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to run traits in Parent Admin
     *
     * @return
     */
    @GET
    @Path("retailmanagement/{parentid}/runtraits")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response runTraits(@PathParam("parentid") final String parentId) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.runTraits(parentId, getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_RUN_TRAITS, TRACFONE_RUN_TRAITS_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to run traits in TP Admin Admin
     *
     * @return
     */
    @GET
    @Path("retailmanagement/runtpnormtraits")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response runTpNormTraits() {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.runTpNormTraits(getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_RUN_TP_NORM_TRAITS, TRACFONE_RUN_TP_NORM_TRAITS_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all the stats that are shown regarding the last run tp norm traits
     *
     * @return
     */
    @GET
    @Path("retailmanagement/gettpnormstats")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getTpNormStats() {
        TFOneRetailTpAdminSearchResults retailTpAdminSearchResults;
        try {
            retailTpAdminSearchResults = tracfoneOneRetailAdminAction.getTpNormStats();
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_TP_NORM_STATS, TRACFONE_GET_TP_NORM_STATS_MESSAGE);
        }
        return Response.ok(gson.toJson(retailTpAdminSearchResults), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a rank C_RTL_CARRIER_PREF
     *
     * @return
     */
    @GET
    @Path("retailmanagement/{objid}/{rank}/updaterank")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateRank(@PathParam("objid") final String objId,
                               @PathParam("rank") final String rank) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.updateRank(objId, rank,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_UPDATE_RANK, TRACFONE_UPDATE_RANK_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to run traits Summary in Parent Admin
     *
     * @return
     */
    @GET
    @Path("retailmanagement/runtraitssummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response runTraitsSummary() {
        List<TFOneJobTask> response = new ArrayList<>();
        try {
            response = tracfoneOneRetailAdminAction.runTraitsSummary();
        } catch (Exception e) {
            return handleException(e, TRACFONE_RUN_TRAITS_SUMMARY, TRACFONE_RUN_TRAITS_SUMMARY_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }


    /**
     * This method is used to update a rank C_RTL_CARRIER_PREF
     *
     * @param carrierPrefDetail
     * @return response
     */
    @POST
    @Path("retailmanagement/updatenewrank")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateNewRank(List<TracfoneOneRetailCarrierPrefDetail> carrierPrefDetail) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.updateNewRank(carrierPrefDetail,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_UPDATE_RANK, TRACFONE_UPDATE_RANK_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves the user object making request from the principal.
     *
     * @return
     */
    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }

    /**
     * To handle the exception in a way the UI understands it
     *
     * @param e
     * @param errorCode
     * @param errorMessage
     * @return
     */
    private Response handleException(Exception e, String errorCode, String errorMessage) {
        LOGGER.error(e);
        TracfoneOneException tfoEx = new TracfoneOneException(errorCode, errorMessage, e);
        Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
        return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
    }

}
