package com.tracfone.service.util;

public interface TracfoneOneConstantZip2Tech {

    String ZIP2TECH_BULK_INSERT = "Bulk Zip2Tech Insert";
    String BP2TECH_BULK_INSERT = "Bulk BPTech Insert";

    String TRACFONE_SEARCH_ZIP2TECH_ERROR = "TFE3100";
    String TRACFONE_SEARCH_ZIP2TECH_ERROR_MESSAGE = "Unable to search Zip2Tech";

    String TRACFONE_GET_ZIP2TECH_COLUMN_ERROR = "TFE3101";
    String TRACFONE_GET_ZIP2TECH_COLUMN_ERROR_MESSAGE = "Unable to get ";

    String TRACFONE_ADD_ZIP2TECH_ERROR = "TFE3102";
    String TRACFONE_ADD_ZIP2TECH_ERROR_MESSAGE = "Unable to add Zip2Tech";

    String TRACFONE_UPDATE_ZIP2TECH_ERROR = "TFE3103";
    String TRACFONE_UPDATE_ZIP2TECH_ERROR_MESSAGE = "Unable to update Zip2Tech";

    String TRACFONE_SEARCH_BPTECH_ERROR = "TFE3104";
    String TRACFONE_SEARCH_BPTECH_ERROR_MESSAGE = "Unable to search BPTech";

    String TRACFONE_GET_BPTECH_COLUMN_ERROR = "TFE3105";
    String TRACFONE_GET_BPTECH_COLUMN_ERROR_MESSAGE = "Unable to get ";

    String TRACFONE_UPDATE_BPTECH_ERROR = "TFE3106";
    String TRACFONE_UPDATE_BPTECH_ERROR_MESSAGE = "Unable to update BPTech";

    String TRACFONE_DELETE_ZIP2TECH_ERROR = "TFE3107";
    String TRACFONE_DELETE_ZIP2TECH_ERROR_MESSAGE = "Unable to delete Zip2Tech";

    String TRACFONE_ADD_BPTECH_ERROR = "TFE3108";
    String TRACFONE_ADD_BPTECH_ERROR_MESSAGE = "Unable to add BPTech";

    String TRACFONE_BULK_ADD_BPTECH_ERROR = "TFE3109";
    String TRACFONE_BULK_ADD_BPTECH_ERROR_MESSAGE = "Unable to add bpTech";

    String TRACFONE_DELETE_BPTECH_ERROR = "TFE3110";
    String TRACFONE_DELETE_BPTECH_ERROR_MESSAGE = "Unable to delete BPTech";

    String TRACFONE_BULK_DELETE_BPTECH_ERROR = "TFE3111";
    String TRACFONE_BULK_DELETE_BPTECH_ERROR_MESSAGE = "Unable to delete BPTech";

    String TRACFONE_BPTECH_DEPENDENCY_ERROR = "TFE3112";
    String TRACFONE_BPTECH_DEPENDENCY_ERROR_MESSAGE = "This BPTech cannot be deleted since it has dependencies";

    String TRACFONE_BULK_ADD_ZIP2TECH_ERROR = "TFE3113";
    String TRACFONE_BULK_ADD_ZIP2TECH_ERROR_MESSAGE = "Unable to add Zip2Tech";

    String TRACFONE_BULK_DELETE_ZIP2TECH_ERROR = "TFE3114";
    String TRACFONE_BULK_DELETE_ZIP2TECH_ERROR_MESSAGE = "Unable to delete Zip2Tech";

    String TRACFONE_SEARCH_ZIP2TECH = "SELECT ZIP, STATE, COUNTY, PREF1, PREF2, SERVICE, LANGUAGE, ACTION, " +
            "MARKET, ZIP2, AID, VID, VC, SAHCID, COM, LOCALE, SITETYPE, GOTOPHONELIST, TECH, TECHZIP, " +
            "TECHKEY, X_PREF_PARENT FROM (select zip2techs.*, rownum rnum from " +
            "(select ZIP, STATE, COUNTY, PREF1, PREF2, SERVICE, LANGUAGE, ACTION, MARKET, ZIP2, AID, " +
            "VID, VC, SAHCID, COM, LOCALE, SITETYPE, GOTOPHONELIST, TECH, TECHZIP, " +
            "TECHKEY, X_PREF_PARENT from mapinfo.eg_zip2tech where ";

    String GET_ZIP2TECH_TRANSACTION_COUNT = "SELECT count(1) AS totalRecords FROM mapinfo.eg_zip2tech where ";

    String TRACFONE_INSERT_ZIP2TECH = "insert into mapinfo.eg_zip2tech(ZIP, STATE, COUNTY, PREF1, PREF2, SERVICE," +
            " LANGUAGE, ACTION, MARKET, ZIP2, AID, " +
            "VID, VC, SAHCID, COM, LOCALE, SITETYPE, GOTOPHONELIST, TECH, TECHZIP, TECHKEY, X_PREF_PARENT) values" +
            "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    String TRACFONE_UPDATE_ZIP2TECH = "update mapinfo.eg_zip2tech set SERVICE = ?, TECHKEY = ?, X_PREF_PARENT = ?, " +
            "ZIP = ?, ZIP2 = ?, TECHZIP = ? where " +
            "ZIP = ? and STATE = ? and COUNTY = ? and LANGUAGE = ? and SERVICE = ? and TECHKEY = ? and X_PREF_PARENT = ?";

    String TRACFONE_SEARCH_BPTECH = "SELECT TECHKEY, SERVICE, BP_CODE, PRODUCT_KEY from mapinfo.EG_BPTECH where ";

    String TRACFONE_UPDATE_BPTECH = "update mapinfo.EG_BPTECH set TECHKEY = ?, SERVICE = ?, BP_CODE = ?, " +
            "PRODUCT_KEY = ? where TECHKEY = ? and SERVICE = ? and BP_CODE = ?";

    String TRACFONE_DELETE_ZIP2TECH = "delete from mapinfo.eg_zip2tech where ZIP = ? and LANGUAGE = ? and SERVICE = ? and TECHKEY = ?";

    String TRACFONE_INSERT_BPTECH = "insert into mapinfo.EG_BPTECH(TECHKEY, SERVICE, BP_CODE, PRODUCT_KEY) values " +
            "(?, ?, ?, ?)";

    String TRACFONE_DELETE_BPTECH = "delete from mapinfo.EG_BPTECH where TECHKEY = ? and SERVICE = ? and BP_CODE = ?";

    //dependency check in zip2tech table
    String TRACFONE_COUNT_TECHKEY = "SELECT count(1) as TECHKEY FROM mapinfo.eg_zip2tech where TECHKEY = ?";
}
