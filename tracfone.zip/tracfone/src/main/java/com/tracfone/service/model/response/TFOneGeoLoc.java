package com.tracfone.service.model.response;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * @author Pritesh.Singh
 */
public class TFOneGeoLoc {
    private String zip;
    private String state;
    private String popcy;
    private String pop05;
    private String latitude;
    private String longitude;
    private String rlatitude;
    private String rlongitude;
    private String srlatitude;
    private String crlatitude;
    private String rzg2user;
    private String insertDate;
    private String updateDate;

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPopcy() {
        return popcy;
    }

    public void setPopcy(String popcy) {
        this.popcy = popcy;
    }

    public String getPop05() {
        return pop05;
    }

    public void setPop05(String pop05) {
        this.pop05 = pop05;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getRlatitude() {
        return rlatitude;
    }

    public void setRlatitude(String rlatitude) {
        this.rlatitude = rlatitude;
    }

    public String getRlongitude() {
        return rlongitude;
    }

    public void setRlongitude(String rlongitude) {
        this.rlongitude = rlongitude;
    }

    public String getSrlatitude() {
        return srlatitude;
    }

    public void setSrlatitude(String srlatitude) {
        this.srlatitude = srlatitude;
    }

    public String getCrlatitude() {
        return crlatitude;
    }

    public void setCrlatitude(String crlatitude) {
        this.crlatitude = crlatitude;
    }

    public String getRzg2user() {
        return rzg2user;
    }

    public void setRzg2user(String rzg2user) {
        this.rzg2user = rzg2user;
    }

    public String getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(String insertDate) {
        this.insertDate = insertDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    @Override
    public String toString() {
        return "TFOneGeoLoc{" +
                "zip='" + zip + '\'' +
                ", state='" + state + '\'' +
                ", popcy='" + popcy + '\'' +
                ", pop05='" + pop05 + '\'' +
                ", latitude='" + latitude + '\'' +
                ", longitude='" + longitude + '\'' +
                ", rlatitude='" + rlatitude + '\'' +
                ", rlongitude='" + rlongitude + '\'' +
                ", srlatitude='" + srlatitude + '\'' +
                ", crlatitude='" + crlatitude + '\'' +
                ", rzg2user='" + rzg2user + '\'' +
                ", insertDate='" + insertDate + '\'' +
                ", updateDate='" + updateDate + '\'' +
                '}';
    }
}

