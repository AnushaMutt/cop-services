package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneBPTech;
import com.tracfone.service.model.request.TracfoneOneZip2Tech;
import com.tracfone.service.model.response.TFOneBPTech;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneZip2Tech;

import javax.ejb.Local;
import java.util.Collection;
import java.util.List;

@Local
public interface TracfoneOneZip2TechActionLocal {
    List<TFOneZip2Tech> searchZip2Tech(TracfoneOneZip2Tech tfZip2Tech) throws TracfoneOneException;

    List<String> getZip2TechColumnValues(String columnName, String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse insertZip2Tech(TracfoneOneZip2Tech tfZip2Tech, int userId, String uniqueId) throws TracfoneOneException;

    TFOneGeneralResponse updateZip2Techs(List<TracfoneOneZip2Tech> tfZip2Techs, int userId) throws TracfoneOneException;

    List<TFOneBPTech> searchBPTech(TracfoneOneBPTech tfBPTech) throws TracfoneOneException;

    List<String> getBPTechColumn(String columnName, String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse updateBPTechs(List<TracfoneOneBPTech> tfBPTechs, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteZip2Techs(TracfoneOneZip2Tech tfZip2Tech, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertBpTech(TracfoneOneBPTech tfBPTech, int userId, String unique) throws TracfoneOneException;

    TFOneGeneralResponse deleteBpTech(TracfoneOneBPTech tfBPTech, int userId) throws TracfoneOneException;

    boolean searchTechKey(TracfoneOneZip2Tech zip2Tech) throws TracfoneOneException;
}
