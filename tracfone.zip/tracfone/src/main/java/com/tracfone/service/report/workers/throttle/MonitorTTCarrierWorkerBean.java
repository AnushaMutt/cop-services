package com.tracfone.service.report.workers.throttle;

import com.tracfone.service.model.report.TFOneReportTTMonitor;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Resource;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author thejaswini
 */
@Stateless
public class MonitorTTCarrierWorkerBean {

    @Resource(lookup = "jndi/cop_report")
    private DataSource dataSourceReports;

    private AtomicBoolean busy = new AtomicBoolean(false);
    private static final Logger LOGGER = LogManager.getLogger(MonitorTTCarrierWorkerBean.class);

    @Lock(LockType.READ)
    public List<TFOneReportTTMonitor> runMonitorReport() {
        List<TFOneReportTTMonitor> ttMonitorReports = new ArrayList<>();

        if (!busy.compareAndSet(false, true)) {
            return ttMonitorReports;
        }

        try (Connection con = dataSourceReports.getConnection();
             PreparedStatement stmt = con.prepareStatement(TracfoneOneConstantReport.REPORT_SQL_TT_MONITOR);
             ResultSet resultSet = stmt.executeQuery();) {
            while (resultSet.next()) {
                TFOneReportTTMonitor tfOneReportTTMonitor = new TFOneReportTTMonitor();
                tfOneReportTTMonitor.setCarrier(resultSet.getString("x_carrier"));
                tfOneReportTTMonitor.setTransNum(resultSet.getString("x_transaction_num"));
                tfOneReportTTMonitor.setxDate(resultSet.getString("x_date"));
                tfOneReportTTMonitor.setTransType(resultSet.getString("x_transact_type"));
                tfOneReportTTMonitor.setSumAllQ(resultSet.getString("sum_all_q"));
                tfOneReportTTMonitor.setSumAllL(resultSet.getString("sum_all_l"));
                tfOneReportTTMonitor.setSumAllCp(resultSet.getString("sum_all_cp"));
                tfOneReportTTMonitor.setSumAllS(resultSet.getString("sum_all_s"));
                tfOneReportTTMonitor.setSumAllNt(resultSet.getString("sum_all_nt"));
                tfOneReportTTMonitor.setSumAllE(resultSet.getString("sum_all_e"));
                tfOneReportTTMonitor.setSumAllC(resultSet.getString("sum_all_c"));
                tfOneReportTTMonitor.setSumAllTf(resultSet.getString("sum_all_tf"));
                tfOneReportTTMonitor.setSumOther(resultSet.getString("sum_other"));
                tfOneReportTTMonitor.setTotalTransCount(resultSet.getString("total_trans_count"));
                tfOneReportTTMonitor.setTotalTransSegment(resultSet.getString("total_trans_by_segment"));
                tfOneReportTTMonitor.setFailureCount(resultSet.getString("failure_count"));
                tfOneReportTTMonitor.setComp11Min(resultSet.getString("comp_11_min"));
                tfOneReportTTMonitor.setComp15Min(resultSet.getString("comp_15_min"));
                tfOneReportTTMonitor.setComp30Min(resultSet.getString("comp_30_min"));
                tfOneReportTTMonitor.setCompGt30Min(resultSet.getString("comp_GT30_min"));
                ttMonitorReports.add(tfOneReportTTMonitor);
            }
        } catch (Exception e) {
            LOGGER.error("Throttle Monitor Report Retrieval Error - ", e);
        } finally {
            busy.set(false);
        }
        return ttMonitorReports;
    }
}