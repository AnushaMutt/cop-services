package com.tracfone.service.util;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Gaurav.Sharma
 */
public class ThrottleTransControllerUtil {
    protected static final Map<String, String> columnMap = new HashMap<>();

    private ThrottleTransControllerUtil() {
        throw new IllegalStateException("Utility class");
    }

    static {
        // Throttling Transaction Column names with Table parent.
        ThrottleTransControllerUtil.columnMap.put("objId", "OBJID");
        ThrottleTransControllerUtil.columnMap.put("transactionNum", "X_TRANSACTION_NUM");
        ThrottleTransControllerUtil.columnMap.put("status", "X_STATUS");
        ThrottleTransControllerUtil.columnMap.put("min", "X_MIN");
        ThrottleTransControllerUtil.columnMap.put("esn", "X_ESN");
        ThrottleTransControllerUtil.columnMap.put("transactionType", "X_TRANSACT_TYPE");
        ThrottleTransControllerUtil.columnMap.put("ruleId", "X_RULE_ID");
        ThrottleTransControllerUtil.columnMap.put("apiMessage", "X_API_MESSAGE");
        ThrottleTransControllerUtil.columnMap.put("apiStatus", "X_API_STATUS");
        ThrottleTransControllerUtil.columnMap.put("cos", "COS");
        ThrottleTransControllerUtil.columnMap.put("entitlement", "ENTITLEMENT");
        ThrottleTransControllerUtil.columnMap.put("parentName", "PARENT_NAME");
        ThrottleTransControllerUtil.columnMap.put("policyName", "POLICY_NAME");
        ThrottleTransControllerUtil.columnMap.put("priority", "PRIORITY");
        ThrottleTransControllerUtil.columnMap.put("propagateFlagValue", "PROPAGATE_FLAG_VALUE");
        ThrottleTransControllerUtil.columnMap.put("subscriberId", "X_SUBSCRIBER_ID");
        ThrottleTransControllerUtil.columnMap.put("threshold", "THRESHOLD");
        ThrottleTransControllerUtil.columnMap.put("throttleGroupType", "THROTTLE_GROUP_TYPE");
        ThrottleTransControllerUtil.columnMap.put("usageTierId", "USAGE_TIER_ID");
        ThrottleTransControllerUtil.columnMap.put("groupId", "X_GROUP_ID");

    }

    /**
     * @param key
     * @return
     */
    public static String getDBColumnName(String key) {
        return ThrottleTransControllerUtil.columnMap.get(key);
    }

}
