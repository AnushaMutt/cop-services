package com.tracfone.service.model.response;

public class TFOneCarrierGroup {
    private String objId;
    private String carrierGroupId;
    private String carrierName;
    private String group2Address;
    private String status;
    private String carrierGroup2Parent;
    private String noAutoPart;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getCarrierGroupId() {
        return carrierGroupId;
    }

    public void setCarrierGroupId(String carrierGroupId) {
        this.carrierGroupId = carrierGroupId;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getGroup2Address() {
        return group2Address;
    }

    public void setGroup2Address(String group2Address) {
        this.group2Address = group2Address;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCarrierGroup2Parent() {
        return carrierGroup2Parent;
    }

    public void setCarrierGroup2Parent(String carrierGroup2Parent) {
        this.carrierGroup2Parent = carrierGroup2Parent;
    }

    public String getNoAutoPart() {
        return noAutoPart;
    }

    public void setNoAutoPart(String noAutoPart) {
        this.noAutoPart = noAutoPart;
    }

    @Override
    public String toString() {
        return "TFOneCarrierGroup{" +
                "objId='" + objId + '\'' +
                ", carrierGroupId='" + carrierGroupId + '\'' +
                ", carrierName='" + carrierName + '\'' +
                ", group2Address='" + group2Address + '\'' +
                ", status='" + status + '\'' +
                ", carrierGroup2Parent='" + carrierGroup2Parent + '\'' +
                ", noAutoPart='" + noAutoPart + '\'' +
                '}';
    }
}
