package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneActionItemId;
import com.tracfone.service.model.request.TracfoneOneBucketDetail;
import com.tracfone.service.model.request.TracfoneOneBulkTransaction;
import com.tracfone.service.model.request.TracfoneOneColumnDesc;
import com.tracfone.service.model.request.TracfoneOneNewTransaction;
import com.tracfone.service.model.request.TracfoneOneRework;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.request.TracfoneOneUserTask;
import com.tracfone.service.model.response.TFOneActionItemBucket;
import com.tracfone.service.model.response.TFOneAdminActionItem;
import com.tracfone.service.model.response.TFOneBulkInsertReport;
import com.tracfone.service.model.response.TFOneCarrierTransactionResponse;
import com.tracfone.service.model.response.TFOneColumnDesc;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGFailLogs;
import com.tracfone.service.model.response.TFOneUserHistory;
import com.tracfone.service.model.response.TFOneUserTask;
import com.tracfone.service.model.response.TracfoneOneViewActionItems;

import javax.ejb.Local;
import java.util.List;

/**
 * @author user
 */
@Local
public interface TracfoneControllerLocalAction {

    /**
     * @param tracfoneOneActionItemId
     * @param userId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    TracfoneOneViewActionItems viewActionitemId(TracfoneOneActionItemId tracfoneOneActionItemId, Integer userId) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * @param tracfoneOneRework
     * @param userId
     * @return
     * @throws TracfoneOneException Responsible for both reworking and re-queuing transactions.
     */
    TFOneGeneralResponse reworkBatchTransaction(TracfoneOneRework tracfoneOneRework, boolean isRework, Integer userId) throws TracfoneOneException;

    /**
     * @param tfOneNewTransaction
     * @param userId
     * @param userInitials
     * @return
     * @throws TracfoneOneException
     */
    TFOneGeneralResponse insertTransaction(TracfoneOneNewTransaction tfOneNewTransaction, int userId, String userInitials) throws TracfoneOneException;

    /**
     * @param tfOneNewTransaction
     * @param userId
     * @param userInitials
     * @param fireArchiveEvent
     * @param bulkInsertIdentifier
     * @return
     * @throws TracfoneOneException
     */
    TFOneGeneralResponse insertTransaction(TracfoneOneNewTransaction tfOneNewTransaction, int userId, String userInitials, boolean fireArchiveEvent, String bulkInsertIdentifier) throws TracfoneOneException;

    /**
     * @param bucketDetail
     * @param userId
     * @return
     * @throws TracfoneOneException
     */
    List<TFOneActionItemBucket> bucketsDetailTransaction(TracfoneOneBucketDetail bucketDetail, int userId) throws TracfoneOneException;


    /**
     * @param tracfoneOneActionItemId
     * @param userId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    TracfoneOneViewActionItems viewFailedTransaction(TracfoneOneActionItemId tracfoneOneActionItemId, Integer userId) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * @param tracfoneOneActionItemId
     * @param userId
     * @return
     * @throws TracfoneOneException
     */
    TFOneCarrierTransactionResponse getTransactionCarrierResponse(TracfoneOneActionItemId tracfoneOneActionItemId, int userId) throws TracfoneOneException;

    /**
     * @param tfOneUserHistory
     * @return
     * @throws TracfoneOneException
     */
    List<TFOneUserHistory> getUserHistoryByUserId(TracfoneOneUserHistory tfOneUserHistory)
            throws TracfoneOneException;

    /**
     * @param tfOneUserTask
     * @param userId
     * @return
     * @throws TracfoneOneException
     */
    TFOneGeneralResponse insertUserTask(TracfoneOneUserTask tfOneUserTask, int userId) throws TracfoneOneException;

    /**
     * @param tfOneUserTask
     * @param userId
     * @return
     * @throws TracfoneOneException
     */
    TFOneUserTask updateUserTask(TracfoneOneUserTask tfOneUserTask, int userId) throws TracfoneOneException;

    /**
     * @param tfOneUserTask
     * @return
     * @throws TracfoneOneException
     */
    List<TFOneUserTask> getUserTaskByUserId(TracfoneOneUserTask tfOneUserTask) throws TracfoneOneException;

    /**
     * @param tfOneBulkTransaction
     * @param userId
     * @param description
     * @throws TracfoneOneException
     */
    void insertBulkTransactions(TracfoneOneBulkTransaction tfOneBulkTransaction, int userId, String description) throws TracfoneOneException;

    /**
     * @param dbEnv
     * @param action
     * @param userId
     * @return
     * @throws TracfoneOneException
     */
    List<TFOneBulkInsertReport> getBulkInsertSummary(String dbEnv, String action, int userId) throws TracfoneOneException;

    /**
     * @param tracfoneOneUserHistory
     * @return
     * @throws TracfoneOneException
     */
    List<TFOneBulkInsertReport> getErrorRecordDetails(TracfoneOneUserHistory tracfoneOneUserHistory) throws TracfoneOneException;

    /**
     * @param tracfoneOneNewTransaction
     * @return
     */
    List<TFOneAdminActionItem> getIgTransactionsInProgress(TracfoneOneNewTransaction tracfoneOneNewTransaction) throws TracfoneOneException;

    /**
     * @param tracfoneOneNewTransaction
     * @param userId
     * @return
     */
    TFOneGeneralResponse deleteIgTransactionInProgress(TracfoneOneNewTransaction tracfoneOneNewTransaction, int userId) throws TracfoneOneException;

    /**
     * @param dbEnv
     * @param uniqueKey
     * @param userId
     * @return
     */
    TFOneGeneralResponse getUserHistoryDetailByIdType(String dbEnv, String uniqueKey, int userId) throws TracfoneOneException;

    List<TFOneIGFailLogs> getIgFailLogs(TracfoneOneNewTransaction tracfoneOneNewTransaction) throws TracfoneOneException;

    List<TFOneColumnDesc> getTableDesc(TracfoneOneColumnDesc tfColumnDesc) throws TracfoneOneException;
}