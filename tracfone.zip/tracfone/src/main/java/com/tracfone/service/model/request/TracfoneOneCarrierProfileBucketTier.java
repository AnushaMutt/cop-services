/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Shireen Fathima
 */
public class TracfoneOneCarrierProfileBucketTier {
  
    private String dbEnv;
    private String objId;
    private String carrierProfileBucketsObjId;
    @NotNull (message = "Usage Tier Id cannot be null")
    @NotBlank (message = "Usage Tier Id cannot be blank")
    @Digits(integer=2, fraction=0, message = "Usage Tier Id must be a number not greater than 99")
    private String usageTierId;
    @Size(max=100, message = "Tier Description cannot have more than 100 characters")
    private String tierDescription;
    @Digits(integer=38, fraction=0, message = "Tier Value must be a number")
    private String tierValue;
    @Size(max=60, message = "Tier Behavior cannot have more than 60 characters")
    private String tierBehavior;
    private boolean edited;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getCarrierProfileBucketsObjId() {
        return carrierProfileBucketsObjId;
    }

    public void setCarrierProfileBucketsObjId(String carrierProfileBucketsObjId) {
        this.carrierProfileBucketsObjId = carrierProfileBucketsObjId;
    }

    public String getUsageTierId() {
        return usageTierId;
    }

    public void setUsageTierId(String usageTierId) {
        this.usageTierId = usageTierId;
    }

    public String getTierDescription() {
        return tierDescription;
    }

    public void setTierDescription(String tierDescription) {
        this.tierDescription = tierDescription;
    }

    public String getTierValue() {
        return tierValue;
    }

    public void setTierValue(String tierValue) {
        this.tierValue = tierValue;
    }

    public String getTierBehavior() {
        return tierBehavior;
    }

    public void setTierBehavior(String tierBehavior) {
        this.tierBehavior = tierBehavior;
    }

    public boolean isEdited() { return edited; }

    public void setEdited(boolean edited) { this.edited = edited; }

    @Override
    public String toString() {
        return "TracfoneOneCarrierProfileBucketTier{" + "dbEnv=" + dbEnv + ", "
                + "objId=" + objId + ", "
                + "carrierProfileBucketsObjId=" + carrierProfileBucketsObjId + ", "
                + "usageTierId=" + usageTierId + ", "
                + "tierDescription=" + tierDescription + ", "
                + "tierValue=" + tierValue + ", "
                + "tierBehavior=" + tierBehavior + '}';
    }
    
    
}
