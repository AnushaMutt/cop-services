package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneArUsaMarket;
import com.tracfone.service.model.request.TracfoneOneArUsaPostalZips;
import com.tracfone.service.model.request.TracfoneOneCarrier;
import com.tracfone.service.model.request.TracfoneOneCarrierGroup;
import com.tracfone.service.model.request.TracfoneOneCarrierPref;
import com.tracfone.service.model.request.TracfoneOneCarrierRule;
import com.tracfone.service.model.request.TracfoneOneCarrierSimPref;
import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;
import com.tracfone.service.model.request.TracfoneOneDataConfig;
import com.tracfone.service.model.request.TracfoneOneDataConfigMapping;
import com.tracfone.service.model.request.TracfoneOneGeoLoc;
import com.tracfone.service.model.request.TracfoneOneIgOrderType;
import com.tracfone.service.model.request.TracfoneOneNotCertifyModel;
import com.tracfone.service.model.request.TracfoneOneNpanxx2Carrierzones;
import com.tracfone.service.model.request.TracfoneOneOrderType;
import com.tracfone.service.model.request.TracfoneOneParent;
import com.tracfone.service.model.request.TracfoneOneThrottleFeature;
import com.tracfone.service.model.request.TracfoneOneThrottlePolicy;
import com.tracfone.service.model.request.TracfoneOneThrottleRule;
import com.tracfone.service.model.request.TracfoneOneTmoZipNgp;
import com.tracfone.service.model.request.TracfoneOneVerizonZipNPANXX;
import com.tracfone.service.model.response.TFOneArUsaMarketSearchResult;
import com.tracfone.service.model.response.TFOneArUsaPostalZips;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierGroup;
import com.tracfone.service.model.response.TFOneCarrierPref;
import com.tracfone.service.model.response.TFOneCarrierRule;
import com.tracfone.service.model.response.TFOneCarrierZones;
import com.tracfone.service.model.response.TFOneCarriersimpref;
import com.tracfone.service.model.response.TFOneCingularMrktInfo;
import com.tracfone.service.model.response.TFOneDataConfig;
import com.tracfone.service.model.response.TFOneDataConfigMapping;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneGeoLoc;
import com.tracfone.service.model.response.TFOneIgOrderType;
import com.tracfone.service.model.response.TFOneNotCertifyModel;
import com.tracfone.service.model.response.TFOneNpaNxx2CarrierZonesSearchResult;
import com.tracfone.service.model.response.TFOneOrderType;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOnePartClass;
import com.tracfone.service.model.response.TFOneThrottleFeature;
import com.tracfone.service.model.response.TFOneThrottlePolicy;
import com.tracfone.service.model.response.TFOneThrottleRule;
import com.tracfone.service.model.response.TFOneTmoZipNgp;
import com.tracfone.service.model.response.TFOneVerizonZipNPANXX;
import com.tracfone.service.util.TracfoneOneConstantPlanWizard;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;

/**
 * @author Pritesh Singh
 */
@Stateless
public class TracfoneCarrierMaintenanceController implements TracfoneCarrierMaintenanceControllerLocal, TracfoneOneConstantPlanWizard {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneCarrierMaintenanceController.class);

    @EJB
    TracfoneCarrierMaintenanceLocalAction tracfoneCarrierMaintenanceAction;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @Override
    public List<TFOneCarrierGroup> searchCarrierGroups(TracfoneOneCarrierGroup tracfoneOneCarrierGroup) throws TracfoneOneException {
        List<TFOneCarrierGroup> carrierGroups = new ArrayList<>();
        try {
            carrierGroups = tracfoneCarrierMaintenanceAction.searchCarrierGroups(tracfoneOneCarrierGroup);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_CARRIER_GROUP_ERROR, TRACFONE_GET_CARRIER_GROUP_ERROR_MESSAGE, ex);
        }
        return carrierGroups;
    }


    @Override
    public List<TFOneOrderType> searchOrderTypes(TracfoneOneOrderType tracfoneOneOrderType) throws TracfoneOneException {
        List<TFOneOrderType> orderTypes = new ArrayList<>();
        try {
            orderTypes = tracfoneCarrierMaintenanceAction.searchOrderTypes(tracfoneOneOrderType);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_ORDER_TYPES_ERROR, TRACFONE_GET_ORDER_TYPES_ERROR_MESSAGE, ex);
        }
        return orderTypes;
    }

    @Override
    public List<TFOneParent> searchParent(TracfoneOneParent tracfoneOneParent) throws TracfoneOneException {
        List<TFOneParent> tfOneParents = new ArrayList<>();
        try {
            tfOneParents = tracfoneCarrierMaintenanceAction.searchParent(tracfoneOneParent);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_PARENT_ERROR, TRACFONE_SEARCH_PARENT_ERROR_MESSAGE, ex);
        }
        return tfOneParents;
    }

    @Override
    public List<TFOneCarrier> searchCarrier(TracfoneOneCarrier tracfoneOneCarrier) throws TracfoneOneException {
        List<TFOneCarrier> tfOneCarriers = new ArrayList<>();
        try {
            tfOneCarriers = tracfoneCarrierMaintenanceAction.searchCarrier(tracfoneOneCarrier);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_CARRIER_ERROR, TRACFONE_SEARCH_CARRIER_ERROR_MESSAGE, ex);
        }
        return tfOneCarriers;
    }

    @Override
    public List<TFOneDataConfigMapping> searchDataConfigMapping(TracfoneOneDataConfigMapping tfDataConfigMapping) throws TracfoneOneException {
        List<TFOneDataConfigMapping> tfOneDataConfigMappings = new ArrayList<>();
        try {
            tfOneDataConfigMappings = tracfoneCarrierMaintenanceAction.searchDataConfigMapping(tfDataConfigMapping);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_DATA_CONFIG_MAPPING_ERROR, TRACFONE_SEARCH_DATA_CONFIG_MAPPING_ERROR_MESSAGE, ex);
        }
        return tfOneDataConfigMappings;
    }

    @Override
    public TFOneGeneralResponse insertDataConfigMapping(TracfoneOneDataConfigMapping tfDataConfigMapping, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        validateDuplicateDataConfigMapping(tfDataConfigMapping);
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertDataConfigMapping(tfDataConfigMapping, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_ADD_DATA_CONFIG_MAPPING_ERROR, TRACFONE_ADD_DATA_CONFIG_MAPPING_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse deleteDataConfigMapping(TracfoneOneDataConfigMapping tfDataConfigMapping, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteDataConfigMapping(tfDataConfigMapping, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DELETE_DATA_CONFIG_MAPPING_ERROR, TRACFONE_DELETE_DATA_CONFIG_MAPPING_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse updateDataConfigMapping(TracfoneOneDataConfigMapping tfDataConfigMapping, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        validateDuplicateDataConfigMapping(tfDataConfigMapping);
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateDataConfigMapping(tfDataConfigMapping, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_DATA_CONFIG_MAPPING_ERROR, TRACFONE_UPDATE_DATA_CONFIG_MAPPING_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    private void validateDuplicateDataConfigMapping(TracfoneOneDataConfigMapping tfDataConfigMapping) throws TracfoneOneException {
        if (tracfoneCarrierMaintenanceAction.validateDuplicateDataConfigMapping(tfDataConfigMapping)) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_DATA_CONFIG_MAPPING_ERROR, TRACFONE_DUPLICATE_DATA_CONFIG_MAPPING_ERROR_MESSAGE);
        }
    }

    @Override
    public TFOneGeneralResponse updateParent(TracfoneOneParent tracfoneOneParent, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateParent(tracfoneOneParent, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_PARENT_ERROR, TRACFONE_UPDATE_PARENT_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse updateCarrierGroup(TracfoneOneCarrierGroup tracfoneOneCarrierGroup, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateCarrierGroup(tracfoneOneCarrierGroup, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_CARRIER_GROUP_ERROR, TRACFONE_UPDATE_CARRIER_GROUP_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse updateCarrier(TracfoneOneCarrier tracfoneOneCarrier, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateCarrier(tracfoneOneCarrier, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_CARRIER_ERROR, TRACFONE_UPDATE_CARRIER_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse updateCarrierRule(TracfoneOneCarrierRule tracfoneOneCarrierRule, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateCarrierRule(tracfoneOneCarrierRule, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_CARRIER_RULE_ERROR, TRACFONE_UPDATE_CARRIER_RULE_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse updateOrderType(TracfoneOneOrderType tracfoneOneOrderType, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateOrderType(tracfoneOneOrderType, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_ORDER_TYPE_ERROR, TRACFONE_UPDATE_ORDER_TYPE_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse insertParent(TracfoneOneParent tracfoneOneParent, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertParent(tracfoneOneParent, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_INSERT_PARENT_ERROR, TRACFONE_INSERT_PARENT_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse insertCarrierGroups(List<TracfoneOneCarrierGroup> tracfoneOneCarrierGroups, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        validateDuplicateCarrierGroupId(tracfoneOneCarrierGroups);
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertCarrierGroups(tracfoneOneCarrierGroups, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_INSERT_CARRIER_GROUP_ERROR, TRACFONE_INSERT_CARRIER_GROUP_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    private void validateDuplicateCarrierGroupId(List<TracfoneOneCarrierGroup> tracfoneOneCarrierGroups) throws TracfoneOneException {
        List<String> carrierGroupIds = new ArrayList<>();
        for (TracfoneOneCarrierGroup carrierGroup : tracfoneOneCarrierGroups) {
            carrierGroupIds.add(carrierGroup.getCarrierGroupId());
        }
        List<String> duplicateIds = tracfoneCarrierMaintenanceAction.getCarrierGroupIds(tracfoneOneCarrierGroups.get(0).getDbEnv(), carrierGroupIds);
        if (!duplicateIds.isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_CARRIER_GROUP_ID_ERROR, TRACFONE_DUPLICATE_CARRIER_GROUP_ID_ERROR_MESSAGE + duplicateIds);
        }
    }

    @Override
    public TFOneGeneralResponse insertCarriers(List<TracfoneOneCarrier> tracfoneOneCarriers, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        validateDuplicateCarrierId(tracfoneOneCarriers);
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertCarriers(tracfoneOneCarriers, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_INSERT_CARRIER_ERROR, TRACFONE_INSERT_CARRIER_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    private void validateDuplicateCarrierId(List<TracfoneOneCarrier> tracfoneOneCarriers) throws TracfoneOneException {
        List<String> carrierIds = new ArrayList<>();
        for (TracfoneOneCarrier carrier : tracfoneOneCarriers) {
            carrierIds.add(carrier.getCarrierId());
        }
        List<String> duplicateIds = tracfoneCarrierMaintenanceAction.getCarrierIds(tracfoneOneCarriers.get(0).getDbEnv(), carrierIds);
        if (!duplicateIds.isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_CARRIER_ID_ERROR, TRACFONE_DUPLICATE_CARRIER_ID_ERROR_MESSAGE + duplicateIds);
        }
    }

    @Override
    public TFOneGeneralResponse insertCarrierRule(TracfoneOneCarrierRule tracfoneOneCarrierRule, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertCarrierRule(tracfoneOneCarrierRule, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_INSERT_CARRIER_RULE_ERROR, TRACFONE_INSERT_CARRIER_RULE_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public List<TFOneOrderType> insertOrderType(List<TracfoneOneOrderType> tracfoneOneOrderTypes, int userId) throws TracfoneOneException {
        List<TFOneOrderType> tfOneOrderTypes = new ArrayList<>();
        try {
            tfOneOrderTypes = tracfoneCarrierMaintenanceAction.insertOrderType(tracfoneOneOrderTypes, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_INSERT_ORDER_TYPE_ERROR, TRACFONE_INSERT_ORDER_TYPE_ERROR_MESSAGE, ex);
        }
        return tfOneOrderTypes;
    }

    @Override
    public List<TFOneCarrierRule> searchCarrierRules(TracfoneOneCarrierRule tracfoneOneCarrierRule) throws TracfoneOneException {
        List<TFOneCarrierRule> tfOneCarrierRules = new ArrayList<>();
        try {
            tfOneCarrierRules = tracfoneCarrierMaintenanceAction.searchCarrierRules(tracfoneOneCarrierRule);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_CARRIER_RULE_ERROR, TRACFONE_SEARCH_CARRIER_RULE_ERROR_MESSAGE, ex);
        }
        return tfOneCarrierRules;
    }

    @Override
    public List<TFOneDataConfig> searchDataConfigs(TracfoneOneDataConfig tracfoneOneDataConfig) throws TracfoneOneException {
        List<TFOneDataConfig> dataConfigs = new ArrayList<>();
        try {
            dataConfigs = tracfoneCarrierMaintenanceAction.searchDataConfigs(tracfoneOneDataConfig);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_DATA_CONFIG_ERROR, TRACFONE_SEARCH_DATA_CONFIG_ERROR_MESSAGE, ex);
        }
        return dataConfigs;
    }

    @Override
    public List<TFOnePartClass> getAllPartClasses(String dbEnv) throws TracfoneOneException {
        List<TFOnePartClass> parentClasses = new ArrayList<>();
        try {
            parentClasses = tracfoneCarrierMaintenanceAction.getAllPartClasses(dbEnv);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_ALL_PART_CLASS_ERROR, TRACFONE_GET_ALL_PART_CLASS_ERROR_MESSAGE, ex);
        }
        return parentClasses;
    }

    @Override
    public TFOneGeneralResponse deleteOrderType(TracfoneOneOrderType tracfoneOneOrderType, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteOrderType(tracfoneOneOrderType, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DELETE_ORDER_TYPE_ERROR, TRACFONE_DELETE_ORDER_TYPE_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse insertIgOrderTypes(TracfoneOneIgOrderType tracfoneOneIgOrderType, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        validateOrderTypeAlreadyExists(tracfoneOneIgOrderType);
        try {
            response = tracfoneCarrierMaintenanceAction.insertIgOrderTypes(tracfoneOneIgOrderType, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_INSERT_IG_ORDER_TYPES_ERROR, TRACFONE_INSERT_IG_ORDER_TYPES_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse updateIgOrderTypes(TracfoneOneIgOrderType tracfoneOneIgOrderType, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateIgOrderTypes(tracfoneOneIgOrderType, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_IG_ORDER_TYPES_ERROR, TRACFONE_UPDATE_IG_ORDER_TYPES_ERROR_MESSAGE, ex);
        }

        return tfOneGeneralResponse;
    }

    @Override
    public List<TFOneIgOrderType> searchIgOrderTypes(TracfoneOneIgOrderType tracfoneOneIgOrderType, boolean searchAll) throws TracfoneOneException {
        List<TFOneIgOrderType> tfOneIGOrderType = new ArrayList<>();
        try {
            tfOneIGOrderType = tracfoneCarrierMaintenanceAction.searchIgOrderTypes(tracfoneOneIgOrderType, searchAll);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_IG_ORDER_TYPES_ERROR, TRACFONE_SEARCH_IG_ORDER_TYPES_ERROR_MESSAGE, ex);
        }
        return tfOneIGOrderType;
    }

    @Override
    public TFOneGeneralResponse insertThrottlePolicy(TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneCarrierMaintenanceAction.insertThrottlePolicy(tracfoneOneThrottlePolicy, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_INSERT_THROTTLE_POLICY_ERROR, TRACFONE_INSERT_THROTTLE_POLICY_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse insertThrottleRules(List<TracfoneOneThrottleRule> tracfoneOneThrottleRules, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            List<String> parentIds = new ArrayList<>();
            List<TracfoneOneThrottleRule> uniqueRules = new ArrayList<>();
            tracfoneOneThrottleRules.forEach(rule -> {
                if (!parentIds.contains(rule.getParentId())) {
                    uniqueRules.add(rule);
                    parentIds.add(rule.getParentId());
                }
            });
            LOGGER.info("UNIQUE list of Rules " + uniqueRules);
            response = tracfoneCarrierMaintenanceAction.insertThrottleRules(uniqueRules, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_INSERT_THROTTLE_RULE_ERROR, TRACFONE_INSERT_THROTTLE_RULE_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse insertThrottleFeatures(List<TracfoneOneThrottleFeature> tracfoneOneThrottleFeatures, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            List<String> uniqueIds = new ArrayList<>();
            List<TracfoneOneThrottleFeature> uniqueFeatures = new ArrayList<>();
            tracfoneOneThrottleFeatures.forEach(feature -> {
                String id = feature.getFeatureName() + feature.getFeatureFlagName();
                if (!uniqueIds.contains(id)) {
                    uniqueFeatures.add(feature);
                    uniqueIds.add(id);
                }
            });
            LOGGER.info("UNIQUE list of Features " + uniqueFeatures);
            response = tracfoneCarrierMaintenanceAction.insertThrottleFeatures(uniqueFeatures, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_INSERT_THROTTLE_FEATURE_ERROR, TRACFONE_INSERT_THROTTLE_FEATURE_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<TFOneThrottlePolicy> searchThrottlePolicies(TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy) throws TracfoneOneException {
        List<TFOneThrottlePolicy> tfOneThrottlePolicy = new ArrayList<>();
        try {
            tfOneThrottlePolicy = tracfoneCarrierMaintenanceAction.searchThrottlePolicies(tracfoneOneThrottlePolicy);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_THROTTLE_POLICY_ERROR, TRACFONE_SEARCH_THROTTLE_POLICY_ERROR_MESSAGE, ex);
        }
        return tfOneThrottlePolicy;
    }

    @Override
    public List<TFOneThrottleRule> searchThrottleRules(TracfoneOneThrottleRule tracfoneOneThrottleRule) throws TracfoneOneException {
        List<TFOneThrottleRule> tfOneThrottleRule = new ArrayList<>();
        try {
            tfOneThrottleRule = tracfoneCarrierMaintenanceAction.searchThrottleRules(tracfoneOneThrottleRule);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_THROTTLE_RULE_ERROR, TRACFONE_SEARCH_THROTTLE_RULE_ERROR_MESSAGE, ex);
        }
        return tfOneThrottleRule;
    }

    @Override
    public List<TFOneThrottleFeature> searchThrottleFeatures(TracfoneOneThrottleFeature tracfoneOneThrottleFeature) throws TracfoneOneException {
        List<TFOneThrottleFeature> tfOneThrottleFeatures = new ArrayList<>();
        try {
            tfOneThrottleFeatures = tracfoneCarrierMaintenanceAction.searchThrottleFeatures(tracfoneOneThrottleFeature);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_THROTTLE_FEATURES_ERROR, TRACFONE_SEARCH_THROTTLE_FEATURES_ERROR_MESSAGE, ex);
        }
        return tfOneThrottleFeatures;
    }

    @Override
    public TFOneGeneralResponse updateThrottlePolicy(TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        validateThrottlePolicyAlreadyExists(tracfoneOneThrottlePolicy);
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateThrottlePolicy(tracfoneOneThrottlePolicy, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_THROTTLE_POLICY_ERROR, TRACFONE_UPDATE_THROTTLE_POLICY_ERROR_MESSAGE, ex);
        }

        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse updateThrottleRule(TracfoneOneThrottleRule tracfoneOneThrottleRule, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        validateThrottleRuleAlreadyExists(tracfoneOneThrottleRule);
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateThrottleRule(tracfoneOneThrottleRule, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_THROTTLE_RULE_ERROR, TRACFONE_UPDATE_THROTTLE_RULE_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse updateThrottleFeature(TracfoneOneThrottleFeature tracfoneOneThrottleFeature, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        validateThrottleFeatureAlreadyExists(tracfoneOneThrottleFeature);
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateThrottleFeature(tracfoneOneThrottleFeature, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_THROTTLE_FEATURES_ERROR, TRACFONE_UPDATE_THROTTLE_FEATURES_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public List<TFOneVerizonZipNPANXX> searchVerizonZipNPANXX(TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX) throws TracfoneOneException {
        List<TFOneVerizonZipNPANXX> tfOneVerizonZipNPANXX = new ArrayList<>();
        try {
            tfOneVerizonZipNPANXX = tracfoneCarrierMaintenanceAction.searchVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_VERIZON_ZIP_NPANXX_ERROR, TRACFONE_SEARCH_VERIZON_ZIP_NPANXX_ERROR_MESSAGE, ex);
        }
        return tfOneVerizonZipNPANXX;
    }

    @Override
    public TFOneGeneralResponse updateVerizonZipNPANXX(TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        if (tracfoneOneVerizonZipNPANXX.isCheckDuplicate()) {
            validateVerizonZipNpanxxAlreadyExists(tracfoneOneVerizonZipNPANXX);
        }
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_VERIZON_ZIP_NPANXX_ERROR, TRACFONE_UPDATE_VERIZON_ZIP_NPANXX_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse insertVerizonZipNPANXX(TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneCarrierMaintenanceAction.insertVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, userId, null);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_VERIZON_ZIP_NPANXX_ERROR, TRACFONE_ADD_VERIZON_ZIP_NPANXX_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse deleteVerizonZipNPANXX(TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DELETE_VERIZON_ZIP_NPANXX_ERROR, TRACFONE_DELETE_VERIZON_ZIP_NPANXX_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public void bulkInsertVerizonZipNPANXX(List<TracfoneOneVerizonZipNPANXX> tracfoneOneVerizonZipNPANXXs, int userId) throws TracfoneOneException {
        // Generate a unique identifier
        long unique = (new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        // Create a record in cop_audit table for this bulk insert
        triggerAudit(userId, BULK_VERIZON_ZIP_NPANXX_INSERT,
                "Requested a bulk insert of Verizon Zip NPANXX -" + tracfoneOneVerizonZipNPANXXs.size(),
                String.valueOf(tracfoneOneVerizonZipNPANXXs.size()) + "_" + unique);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {

                for (TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX : tracfoneOneVerizonZipNPANXXs) {
                    try {
                        LOGGER.info(INSERTION + tracfoneOneVerizonZipNPANXX);
                        tracfoneCarrierMaintenanceAction.insertVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, userId, String.valueOf(unique));
                    } catch (TracfoneOneException ex) {
                        LOGGER.error(BULK_INSERT_FAILED + tracfoneOneVerizonZipNPANXX, ex);
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(ex.getErrorMessage())) {
                            triggerAudit(userId, BULK_VERIZON_ZIP_NPANXX_INSERT,
                                    "Inserted Verizon Zip NPANXX " + tracfoneOneVerizonZipNPANXX, CARRIERID + unique);
                        }
                        triggerAudit(userId, BULK_VERIZON_ZIP_NPANXX_INSERT,
                                BULK_INSERT_FAILED_FOR + tracfoneOneVerizonZipNPANXX + " - " + ex.getErrorMessage(),
                                ERROR + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_VERIZON_ZIP_NPANXX_ERROR, TRACFONE_ADD_VERIZON_ZIP_NPANXX_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public List<TFOneTmoZipNgp> searchTmoZipNgp(TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp) throws TracfoneOneException {
        List<TFOneTmoZipNgp> tfOneTmoZipNgp = new ArrayList<>();
        try {
            tfOneTmoZipNgp = tracfoneCarrierMaintenanceAction.searchTmoZipNgp(tracfoneOneTmoZipNgp);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_TMO_ZIP_NGP_ERROR, TRACFONE_SEARCH_TMO_ZIP_NGP_ERROR_MESSAGE, ex);
        }
        return tfOneTmoZipNgp;
    }

    @Override
    public TFOneGeneralResponse insertTmoZipNgp(TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneCarrierMaintenanceAction.insertTmoZipNgp(tracfoneOneTmoZipNgp, userId, null);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_TMO_ZIP_NGP_ERROR, TRACFONE_ADD_TMO_ZIP_NGP_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse updateTmoZipNgp(TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        if (tracfoneOneTmoZipNgp.isCheckDuplicate()) {
            validateTmoZipNgpAlreadyExists(tracfoneOneTmoZipNgp);
        }
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateTmoZipNgp(tracfoneOneTmoZipNgp, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR, TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse deleteTmoZipNgp(TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteTmoZipNgp(tracfoneOneTmoZipNgp, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DELETE_TMO_ZIP_NGP_ERROR, TRACFONE_DELETE_TMO_ZIP_NGP_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public void bulkInsertTmoZipNgp(List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNGPs, int userId) throws TracfoneOneException {
        // Generate a unique identifier
        long unique = (new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        // Create a record in cop_audit table for this bulk insert
        triggerAudit(userId, BULK_TMO_ZIP_NGP_INSERT,
                "Requested a bulk insert of TMO ZIP NGP -" + tracfoneOneTmoZipNGPs.size(),
                String.valueOf(tracfoneOneTmoZipNGPs.size()) + "_" + unique);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {

                for (TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp : tracfoneOneTmoZipNGPs) {
                    try {
                        LOGGER.info(INSERTION + tracfoneOneTmoZipNgp);
                        tracfoneCarrierMaintenanceAction.insertTmoZipNgp(tracfoneOneTmoZipNgp, userId, String.valueOf(unique));
                    } catch (TracfoneOneException ex) {
                        LOGGER.error(BULK_INSERT_FAILED + tracfoneOneTmoZipNgp, ex);
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(ex.getErrorMessage())) {
                            triggerAudit(userId, BULK_TMO_ZIP_NGP_INSERT,
                                    "Inserted TMO ZIP NGP " + tracfoneOneTmoZipNgp, CARRIERID + unique);
                        }
                        triggerAudit(userId, BULK_TMO_ZIP_NGP_INSERT,
                                BULK_INSERT_FAILED_FOR + tracfoneOneTmoZipNgp + " - " + ex.getErrorMessage(),
                                ERROR + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_TMO_ZIP_NGP_ERROR, TRACFONE_ADD_TMO_ZIP_NGP_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public List<TFOneCingularMrktInfo> searchCingularMrktInfo(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo) throws TracfoneOneException {
        List<TFOneCingularMrktInfo> tfOneCingularMrktInfo = new ArrayList<>();
        try {
            tfOneCingularMrktInfo = tracfoneCarrierMaintenanceAction.searchCingularMrktInfo(tracfoneOneCingularMrktInfo);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_CINGULAR_MRKT_INFO_ERROR, TRACFONE_SEARCH_CINGULAR_MRKT_INFO_ERROR_MESSAGE, ex);
        }
        return tfOneCingularMrktInfo;
    }

    @Override
    public TFOneGeneralResponse insertCingularMrktInfo(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneCarrierMaintenanceAction.insertCingularMrktInfo(tracfoneOneCingularMrktInfo, userId, null);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_CINGULAR_MRKT_INFO_ERROR, TRACFONE_ADD_CINGULAR_MRKT_INFO_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse updateCingularMrktInfo(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        validateCingularMrktInfoAlreadyExists(tracfoneOneCingularMrktInfo);
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateCingularMrktInfo(tracfoneOneCingularMrktInfo, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_CINGULAR_MRKT_INFO_ERROR, TRACFONE_UPDATE_CINGULAR_MRKT_INFO_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse deleteCingularMrktInfo(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteCingularMrktInfo(tracfoneOneCingularMrktInfo, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DELETE_CINGULAR_MRKT_INFO_ERROR, TRACFONE_DELETE_CINGULAR_MRKT_INFO_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public void bulkInsertCingularMrktInfo(List<TracfoneOneCingularMrktInfo> tracfoneOneCingularMrktsInfo, int userId) throws TracfoneOneException {
        // Generate a unique identifier
        long unique = (new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        // Create a record in cop_audit table for this bulk insert
        triggerAudit(userId, BULK_CINGULAR_MKT_INFO_INSERT,
                "Requested a bulk insert of Cingular Mrkt Info -" + tracfoneOneCingularMrktsInfo.size(),
                String.valueOf(tracfoneOneCingularMrktsInfo.size()) + "_" + unique);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {

                for (TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo : tracfoneOneCingularMrktsInfo) {
                    try {
                        LOGGER.info(INSERTION + tracfoneOneCingularMrktInfo);
                        tracfoneCarrierMaintenanceAction.insertCingularMrktInfo(tracfoneOneCingularMrktInfo, userId, String.valueOf(unique));
                    } catch (TracfoneOneException ex) {
                        LOGGER.error(BULK_INSERT_FAILED + tracfoneOneCingularMrktInfo, ex);
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(ex.getErrorMessage())) {
                            triggerAudit(userId, BULK_CINGULAR_MKT_INFO_INSERT,
                                    "Inserted Cingular Mrkt Info " + tracfoneOneCingularMrktInfo, CARRIERID + unique);
                        }
                        triggerAudit(userId, BULK_CINGULAR_MKT_INFO_INSERT,
                                BULK_INSERT_FAILED_FOR + tracfoneOneCingularMrktInfo + " - " + ex.getErrorMessage(),
                                ERROR + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_CINGULAR_MRKT_INFO_ERROR, TRACFONE_ADD_CINGULAR_MRKT_INFO_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public List<TFOneNotCertifyModel> searchNotCertifyModel(TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel) throws TracfoneOneException {
        List<TFOneNotCertifyModel> tfOneNotCertifyModel = new ArrayList<>();
        try {
            tfOneNotCertifyModel = tracfoneCarrierMaintenanceAction.searchNotCertifyModel(tracfoneOneNotCertifyModel);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_NOT_CERTIFY_MODEL_ERROR, TRACFONE_SEARCH_NOT_CERTIFY_MODEL_ERROR_MESSAGE, ex);
        }
        return tfOneNotCertifyModel;
    }

    @Override
    public TFOneGeneralResponse insertNotCertifyModel(TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneCarrierMaintenanceAction.insertNotCertifyModel(tracfoneOneNotCertifyModel, userId, null);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_NOT_CERTIFY_MODEL_ERROR, TRACFONE_ADD_NOT_CERTIFY_MODEL_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse updateNotCertifyModel(TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel, int userId) throws TracfoneOneException {
        validateNotCertifyModel(tracfoneOneNotCertifyModel);
        TFOneGeneralResponse tfOneGeneralResponse = null;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateNotCertifyModel(tracfoneOneNotCertifyModel, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR, TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse deleteNotCertifyModel(TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteNotCertifyModel(tracfoneOneNotCertifyModel, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DELETE_NOT_CERTIFY_MODEL_ERROR, TRACFONE_DELETE_NOT_CERTIFY_MODEL_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public void bulkInsertNotCertifyModel(List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModels, int userId) throws TracfoneOneException {
        // Generate a unique identifier
        long unique = (new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        // Create a record in cop_audit table for this bulk insert
        triggerAudit(userId, BULK_NOT_CERTIFY_MODEL_INSERT,
                "Requested a bulk insert of Not Certify Model -" + tracfoneOneNotCertifyModels.size(),
                String.valueOf(tracfoneOneNotCertifyModels.size()) + "_" + unique);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {

                for (TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel : tracfoneOneNotCertifyModels) {
                    try {
                        LOGGER.info(INSERTION + tracfoneOneNotCertifyModel);
                        tracfoneCarrierMaintenanceAction.insertNotCertifyModel(tracfoneOneNotCertifyModel, userId, String.valueOf(unique));
                    } catch (TracfoneOneException ex) {
                        LOGGER.error(BULK_INSERT_FAILED + tracfoneOneNotCertifyModel, ex);
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(ex.getErrorMessage())) {
                            triggerAudit(userId, BULK_NOT_CERTIFY_MODEL_INSERT,
                                    "Inserted Not Certify Model " + tracfoneOneNotCertifyModel, CARRIERID + unique);
                        }
                        triggerAudit(userId, BULK_NOT_CERTIFY_MODEL_INSERT,
                                BULK_INSERT_FAILED_FOR + tracfoneOneNotCertifyModel + " - " + ex.getErrorMessage(),
                                ERROR + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_NOT_CERTIFY_MODEL_ERROR, TRACFONE_ADD_NOT_CERTIFY_MODEL_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public TFOneGeneralResponse bulkUpdateNotCertifyModel(List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModels, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.bulkUpdateNotCertifyModel(tracfoneOneNotCertifyModels, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR, TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    private void validateOrderTypeAlreadyExists(TracfoneOneIgOrderType tracfoneOneIgOrderType) throws TracfoneOneException {
        TracfoneOneIgOrderType searchOrderType = new TracfoneOneIgOrderType();
        searchOrderType.setDbEnv(tracfoneOneIgOrderType.getDbEnv());
        searchOrderType.setProgrammeName(tracfoneOneIgOrderType.getProgrammeName());
        searchOrderType.setIgOrderType(tracfoneOneIgOrderType.getIgOrderType());
        searchOrderType.setPriority(tracfoneOneIgOrderType.getPriority());
        if (tracfoneCarrierMaintenanceAction.isDuplicateOrderType(searchOrderType)) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_IG_ORDER_TYPES_ERROR, TRACFONE_DUPLICATE_IG_ORDER_TYPES_ERROR_MESSAGE);
        }
    }

    private void validateThrottlePolicyAlreadyExists(TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy) throws TracfoneOneException {
        TracfoneOneThrottlePolicy searchThrottlePolicy = new TracfoneOneThrottlePolicy();
        searchThrottlePolicy.setDbEnv(tracfoneOneThrottlePolicy.getDbEnv());
        searchThrottlePolicy.setPolicyName(tracfoneOneThrottlePolicy.getPolicyName());
        List<TFOneThrottlePolicy> policies = tracfoneCarrierMaintenanceAction.searchThrottlePolicies(searchThrottlePolicy);
        if (!policies.isEmpty() && !policies.get(0).getObjId().equals(tracfoneOneThrottlePolicy.getObjId())) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_THROTTLE_POLICY_ERROR, TRACFONE_DUPLICATE_THROTTLE_POLICY_ERROR_MESSAGE);
        }
    }

    private void validateThrottleRuleAlreadyExists(TracfoneOneThrottleRule tracfoneOneThrottleRule) throws TracfoneOneException {
        TracfoneOneThrottleRule searchThrottleRule = new TracfoneOneThrottleRule();
        searchThrottleRule.setDbEnv(tracfoneOneThrottleRule.getDbEnv());
        searchThrottleRule.setRuleDesc(tracfoneOneThrottleRule.getRuleDesc());
        searchThrottleRule.setParentId(tracfoneOneThrottleRule.getParentId());
        searchThrottleRule.setPolicyId(tracfoneOneThrottleRule.getPolicyId());
        List<TFOneThrottleRule> rules = tracfoneCarrierMaintenanceAction.searchThrottleRules(searchThrottleRule);
        if (!rules.isEmpty() && !rules.get(0).getObjId().equals(tracfoneOneThrottleRule.getObjId())) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_THROTTLE_RULE_ERROR, TRACFONE_DUPLICATE_THROTTLE_RULE_ERROR_MESSAGE);
        }
    }

    private void validateThrottleFeatureAlreadyExists(TracfoneOneThrottleFeature tracfoneOneThrottleFeature) throws TracfoneOneException {
        TracfoneOneThrottleFeature searchThrottleFeatures = new TracfoneOneThrottleFeature();
        searchThrottleFeatures.setDbEnv(tracfoneOneThrottleFeature.getDbEnv());
        searchThrottleFeatures.setRuleId(tracfoneOneThrottleFeature.getRuleId());
        searchThrottleFeatures.setFeatureFlagName(tracfoneOneThrottleFeature.getFeatureFlagName());
        searchThrottleFeatures.setFeatureName(tracfoneOneThrottleFeature.getFeatureName());
        List<TFOneThrottleFeature> features = tracfoneCarrierMaintenanceAction.searchThrottleFeatures(searchThrottleFeatures);
        if (!features.isEmpty() && !features.get(0).getObjId().equals(tracfoneOneThrottleFeature.getObjId())) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_THROTTLE_FEATURE_ERROR, TRACFONE_DUPLICATE_THROTTLE_FEATURE_ERROR_MESSAGE);
        }
    }

    private void validateVerizonZipNpanxxAlreadyExists(TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX) throws TracfoneOneException {
        TracfoneOneVerizonZipNPANXX searchVerizonZipNpanxx = new TracfoneOneVerizonZipNPANXX();
        searchVerizonZipNpanxx.setDbEnv(tracfoneOneVerizonZipNPANXX.getDbEnv());
        searchVerizonZipNpanxx.setZip(tracfoneOneVerizonZipNPANXX.getZip());
        searchVerizonZipNpanxx.setnPANXX(tracfoneOneVerizonZipNPANXX.getnPANXX());
        searchVerizonZipNpanxx.setAccountNum(tracfoneOneVerizonZipNPANXX.getAccountNum());
        List<TFOneVerizonZipNPANXX> tfOneTmoZipNgp = tracfoneCarrierMaintenanceAction.searchVerizonZipNPANXX(searchVerizonZipNpanxx);
        if (!tfOneTmoZipNgp.isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_VERIZON_ZIP_NPANXX_ERROR, TRACFONE_DUPLICATE_VERIZON_ZIP_NPANXX_ERROR_MESSAGE);
        }
    }

    private void validateTmoZipNgpAlreadyExists(TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp) throws TracfoneOneException {
        TracfoneOneTmoZipNgp searchTmoZipNgp = new TracfoneOneTmoZipNgp();
        searchTmoZipNgp.setDbEnv(tracfoneOneTmoZipNgp.getDbEnv());
        searchTmoZipNgp.setZip(tracfoneOneTmoZipNgp.getZip());
        searchTmoZipNgp.setPriority(tracfoneOneTmoZipNgp.getPriority());
        List<TFOneTmoZipNgp> tfOneTmoZipNgp = tracfoneCarrierMaintenanceAction.searchTmoZipNgp(searchTmoZipNgp);
        if (!tfOneTmoZipNgp.isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_TMO_ZIP_NGP_ERROR, TRACFONE_DUPLICATE_TMO_ZIP_NGP_ERROR_MESSAGE);
        }
    }

    private void validateCingularMrktInfoAlreadyExists(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo) throws TracfoneOneException {
        TracfoneOneCingularMrktInfo searchCingularMrktInfo = new TracfoneOneCingularMrktInfo();
        searchCingularMrktInfo.setDbEnv(tracfoneOneCingularMrktInfo.getDbEnv());
        searchCingularMrktInfo.setZip(tracfoneOneCingularMrktInfo.getZip());
        List<TFOneCingularMrktInfo> info = tracfoneCarrierMaintenanceAction.searchCingularMrktInfo(searchCingularMrktInfo);
        if (!info.isEmpty() && !info.get(0).getZip().equals(tracfoneOneCingularMrktInfo.getOldZip())) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_CINGULAR_MRKT_INFO_ERROR, TRACFONE_DUPLICATE_CINGULAR_MRKT_INFO_ERROR_MESSAGE);
        }
    }

    private void validateNotCertifyModel(TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel) throws TracfoneOneException {
        TracfoneOneNotCertifyModel searchNotCertifyModel = new TracfoneOneNotCertifyModel();
        searchNotCertifyModel.setDbEnv(tracfoneOneNotCertifyModel.getDbEnv());
        searchNotCertifyModel.setParentId(tracfoneOneNotCertifyModel.getParentId());
        searchNotCertifyModel.setPartClassObjId(tracfoneOneNotCertifyModel.getPartClassObjId());
        searchNotCertifyModel.setDev(tracfoneOneNotCertifyModel.getDev());
        List<TFOneNotCertifyModel> notCertifyModel = tracfoneCarrierMaintenanceAction.searchNotCertifyModel(searchNotCertifyModel);
        if (!notCertifyModel.isEmpty() && !notCertifyModel.get(0).getObjId().equals(tracfoneOneNotCertifyModel.getObjId())) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_NOT_CERTIFY_MODEL_ERROR, TRACFONE_DUPLICATE_NOT_CERTIFY_MODEL_ERROR_MESSAGE);
        }
    }

    private void triggerAudit(int userId, String action, String details, String carrierId) {
        TracfoneAudit errorAudit = new TracfoneAudit(userId, action, details, carrierId);
        tracfoneAuditEvent.fire(errorAudit);
    }

    @Override
    public TFOneGeneralResponse bulkUpdateTmoZipNgp(List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNgp, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.bulkUpdateTmoZipNgp(tracfoneOneTmoZipNgp, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR, TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public List<TFOneCarriersimpref> searchCarrierSimPref(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref) throws TracfoneOneException {
        List<TFOneCarriersimpref> tfOneCarriersimpref = new ArrayList<>(1);
        try {
            tfOneCarriersimpref = tracfoneCarrierMaintenanceAction.searchCarrierSimPref(tracfoneOneCarriersimpref);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_CARRIERSIMPREF_ERROR, TRACFONE_SEARCH_CARRIERSIMPREF_ERROR_MESSAGE, ex);
        }
        return tfOneCarriersimpref;
    }

    @Override
    public TFOneGeneralResponse insertCarrierSimPref(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneCarrierMaintenanceAction.insertCarrierSimPref(tracfoneOneCarriersimpref, userId, null);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_CARRIERSIMPREF_ERROR, TRACFONE_ADD_CARRIERSIMPREF_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse updateCarrierSimPref(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        validateCarrierSimPref(tracfoneOneCarriersimpref);
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateCarrierSimPref(tracfoneOneCarriersimpref, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_CARRIERSIMPREF_ERROR, TRACFONE_UPDATE_CARRIERSIMPREF_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse deleteCarrierSimPref(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteCarrierSimPref(tracfoneOneCarriersimpref, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DELETE_CARRIERSIMPREF_ERROR, TRACFONE_DELETE_CARRIERSIMPREF_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public void bulkInsertCarrierSimPref(List<TracfoneOneCarrierSimPref> tracfoneOneCarrierSimPrefs, int userId) throws TracfoneOneException {
        // Generate a unique identifier
        long unique = (new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        // Create a record in cop_audit table for this bulk insert
        triggerAudit(userId, BULK_CARRIERSIMPREF_INSERT,
                "Requested a bulk insert of Carrier sim pref -" + tracfoneOneCarrierSimPrefs.size(),
                String.valueOf(tracfoneOneCarrierSimPrefs.size()) + "_" + unique);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {

                for (TracfoneOneCarrierSimPref tracfoneOneCarriersimpref : tracfoneOneCarrierSimPrefs) {
                    try {
                        LOGGER.info(INSERTION + tracfoneOneCarriersimpref);
                        tracfoneCarrierMaintenanceAction.insertCarrierSimPref(tracfoneOneCarriersimpref, userId, String.valueOf(unique));
                    } catch (TracfoneOneException ex) {
                        LOGGER.error(BULK_INSERT_FAILED + tracfoneOneCarriersimpref, ex);
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(ex.getErrorMessage())) {
                            triggerAudit(userId, BULK_CARRIERSIMPREF_INSERT,
                                    "Inserted Carrier sim pref " + tracfoneOneCarriersimpref, CARRIERID + unique);
                        }
                        triggerAudit(userId, BULK_CARRIERSIMPREF_INSERT,
                                BULK_INSERT_FAILED_FOR + tracfoneOneCarriersimpref + " - " + ex.getErrorMessage(),
                                ERROR + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_CARRIERSIMPREF_ERROR, TRACFONE_ADD_CARRIERSIMPREF_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public TFOneGeneralResponse bulkUpdateCarrierSimPref(List<TracfoneOneCarrierSimPref> tracfoneOneCarrierSimPrefs, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.bulkUpdateCarrierSimPref(tracfoneOneCarrierSimPrefs, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_CARRIERSIMPREF_ERROR, TRACFONE_UPDATE_CARRIERSIMPREF_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    private void validateCarrierSimPref(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref) throws TracfoneOneException {
        List<TFOneCarriersimpref> tfOneCarriersimpref = tracfoneCarrierMaintenanceAction.searchCarrierSimPref(tracfoneOneCarriersimpref);
        if (!tfOneCarriersimpref.isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_CARRIERSIMPREF_ERROR, TRACFONE_DUPLICATE_CARRIERSIMPREF_ERROR_MESSAGE);
        }
    }

    @Override
    public TFOneGeneralResponse insertNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        TracfoneOneNpanxx2Carrierzones searchNpanxx = new TracfoneOneNpanxx2Carrierzones();
        searchNpanxx.setDbEnv(tracfoneOneNpanxx2Carrierzones.getDbEnv());
        searchNpanxx.setNpa(tracfoneOneNpanxx2Carrierzones.getNpa());
        searchNpanxx.setNxx(tracfoneOneNpanxx2Carrierzones.getNxx());
        searchNpanxx.setCarrierId(tracfoneOneNpanxx2Carrierzones.getCarrierId());
        searchNpanxx.setState(tracfoneOneNpanxx2Carrierzones.getState());
        searchNpanxx.setSid(tracfoneOneNpanxx2Carrierzones.getSid());
        searchNpanxx.setZone(tracfoneOneNpanxx2Carrierzones.getZone());
        searchNpanxx.setRateCenter(tracfoneOneNpanxx2Carrierzones.getRateCenter());
        TFOneNpaNxx2CarrierZonesSearchResult tfOneNpanxx2Carrierzones = tracfoneCarrierMaintenanceAction.searchNpanxx2Carrierzones(searchNpanxx);
        try {
            if (!tfOneNpanxx2Carrierzones.getNpanxx2Carrierzones().isEmpty()) {
                response = tracfoneCarrierMaintenanceAction.replaceNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, userId);
                response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_REPLACED_NPANXX_2_CARRIERZONES_DETAILS);
            }
            else{
                response = tracfoneCarrierMaintenanceAction.insertNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, userId,null);
                response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
            }
        }
        catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_NPANXX_2_CARRIERZONES_ERROR, TRACFONE_ADD_NPANXX_2_CARRIERZONES_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneNpaNxx2CarrierZonesSearchResult searchNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) throws TracfoneOneException {
        TFOneNpaNxx2CarrierZonesSearchResult tfOneNpanxx2Carrierzones;
        try {
            tfOneNpanxx2Carrierzones = tracfoneCarrierMaintenanceAction.searchNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_NPANXX_2_CARRIERZONES_ERROR, TRACFONE_NPANXX_2_CARRIERZONES_ERROR_MESSAGE, ex);
        }
        return tfOneNpanxx2Carrierzones;
    }


    @Override
    public TFOneGeneralResponse deleteNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_NPANXX_2_CARRIERZONES_ERROR, TRACFONE_DELETE_NPANXX_2_CARRIERZONES_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse updateNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        if (tracfoneOneNpanxx2Carrierzones.isCheckDuplicate()) {
            validateNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        }
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_NPANXX2CARRIERZONES_ERROR, TRACFONE_UPDATE_NPANXX2CARRIERZONES_ERROR_MESSAGE, ex);
        }

        return tfOneGeneralResponse;
    }

    public void validateInsertNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones searchNpanxx = new TracfoneOneNpanxx2Carrierzones();
        searchNpanxx.setDbEnv(tracfoneOneNpanxx2Carrierzones.getDbEnv());
        searchNpanxx.setNpa(tracfoneOneNpanxx2Carrierzones.getNpa());
        searchNpanxx.setNxx(tracfoneOneNpanxx2Carrierzones.getNxx());
        searchNpanxx.setCarrierId(tracfoneOneNpanxx2Carrierzones.getCarrierId());
        searchNpanxx.setState(tracfoneOneNpanxx2Carrierzones.getState());
        searchNpanxx.setSid(tracfoneOneNpanxx2Carrierzones.getSid());
        searchNpanxx.setZone(tracfoneOneNpanxx2Carrierzones.getZone());
        searchNpanxx.setRateCenter(tracfoneOneNpanxx2Carrierzones.getRateCenter());
        TFOneNpaNxx2CarrierZonesSearchResult tfOneNpanxx2Carrierzones = tracfoneCarrierMaintenanceAction.searchNpanxx2Carrierzones(searchNpanxx);
        if (!tfOneNpanxx2Carrierzones.getNpanxx2Carrierzones().isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_NPANXX2CARRIERZONES_ERROR, TRACFONE_DUPLICATE_NPANXX2CARRIERZONES_ERROR_MESSAGE);
        }
    }

    private void validateNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) throws TracfoneOneException {
        TracfoneOneNpanxx2Carrierzones searchnpanpxx = new TracfoneOneNpanxx2Carrierzones();
        searchnpanpxx.setDbEnv((tracfoneOneNpanxx2Carrierzones.getDbEnv()));
        searchnpanpxx.setNpa(tracfoneOneNpanxx2Carrierzones.getNpa());
        searchnpanpxx.setNxx(tracfoneOneNpanxx2Carrierzones.getNxx());
        searchnpanpxx.setCarrierId(tracfoneOneNpanxx2Carrierzones.getCarrierId());
        searchnpanpxx.setState(tracfoneOneNpanxx2Carrierzones.getState());
        searchnpanpxx.setSid(tracfoneOneNpanxx2Carrierzones.getSid());
        searchnpanpxx.setZone(tracfoneOneNpanxx2Carrierzones.getZone());
        searchnpanpxx.setRateCenter(tracfoneOneNpanxx2Carrierzones.getRateCenter());
        TFOneNpaNxx2CarrierZonesSearchResult tfOneNpanxx2Carrierzones = tracfoneCarrierMaintenanceAction.searchNpanxx2Carrierzones(searchnpanpxx);
        if (!tfOneNpanxx2Carrierzones.getNpanxx2Carrierzones().isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_NPANXX2CARRIERZONES_ERROR, TRACFONE_DUPLICATE_NPANXX2CARRIERZONES_ERROR_MESSAGE);
        }
    }

    @Override
    public void bulkInsertNpanxx2Carrierzones(List<TracfoneOneNpanxx2Carrierzones> tracfoneOneNpanxx2Carrierzones, int userId, String description) throws TracfoneOneException {
        // Generate a unique identifier
        String unique = description + (new SecureRandom().nextInt((99999 - 10000) + 1) + 10000);
        // Create a record in cop_audit table for this bulk insert
        triggerAudit(userId, BULK_NPANXX2CARRIERZONES_INSERT,
                "Requested a bulk insert of Npa nxx 2Carrierzones -" + tracfoneOneNpanxx2Carrierzones.size(),
                String.valueOf(tracfoneOneNpanxx2Carrierzones.size()) + "_" + unique);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {

                for (TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzone : tracfoneOneNpanxx2Carrierzones) {
                    try {
                        tracfoneCarrierMaintenanceAction.bulkinsertNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzone, userId, unique);
                    } catch (TracfoneOneException ex) {
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(ex.getErrorMessage())) {
                            triggerAudit(userId, BULK_NPANXX2CARRIERZONES_INSERT,
                                    "Inserted Npa nxx 2Carrierzones " + tracfoneOneNpanxx2Carrierzone, CARRIERID + unique);
                        }
                        triggerAudit(userId, BULK_NPANXX2CARRIERZONES_INSERT,
                                BULK_INSERT_FAILED_FOR + tracfoneOneNpanxx2Carrierzone + " - " + ex.getErrorMessage(),
                                ERROR_VALUE + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_NPANXX_2_CARRIERZONES_ERROR, TRACFONE_ADD_NPANXX_2_CARRIERZONES_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public TFOneGeneralResponse bulkUpdateNpanxx2Carrierzones(List<TracfoneOneNpanxx2Carrierzones> tracfoneOneNpanxx2Carrierzones, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        try {
            for (TracfoneOneNpanxx2Carrierzones npanxx2Carrierzones : tracfoneOneNpanxx2Carrierzones) {
                TracfoneOneNpanxx2Carrierzones npanxx2Carrierzone = new TracfoneOneNpanxx2Carrierzones();
                if (!npanxx2Carrierzones.isCheckDuplicate()) {
                    if (searchNpanxx2Carrierzones(npanxx2Carrierzones).getNpanxx2Carrierzones().isEmpty()) {
                        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateNpanxx2Carrierzones(npanxx2Carrierzones, userId);
                    }
                } else {
                    npanxx2Carrierzone.setDbEnv(npanxx2Carrierzones.getDbEnv());
                    npanxx2Carrierzone.setNpa(npanxx2Carrierzones.getNpa());
                    npanxx2Carrierzone.setNxx(npanxx2Carrierzones.getNxx());
                    npanxx2Carrierzone.setCarrierId(npanxx2Carrierzones.getCarrierId());
                    npanxx2Carrierzone.setZone(npanxx2Carrierzones.getZone());
                    npanxx2Carrierzone.setState(npanxx2Carrierzones.getState());
                    npanxx2Carrierzone.setSid(npanxx2Carrierzones.getSid());
                    npanxx2Carrierzone.setRateCenter(npanxx2Carrierzones.getRateCenter());
                    if (searchNpanxx2Carrierzones(npanxx2Carrierzone).getNpanxx2Carrierzones().isEmpty()) {
                        tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateNpanxx2Carrierzones(npanxx2Carrierzones, userId);
                    }
                }
            }
//                tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.bulkUpdateNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_NPANXX2CARRIERZONES_ERROR, TRACFONE_UPDATE_NPANXX2CARRIERZONES_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public List<TFOneArUsaPostalZips> getArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips) throws TracfoneOneException {
        List<TFOneArUsaPostalZips> tfOneArUsaPostalZips = null;
        try {
            tfOneArUsaPostalZips = tracfoneCarrierMaintenanceAction.getArUsaPostalZips(tracfoneOneArUsaPostalZips);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_AR_USA_POSTAL_ZIPS_ERROR, TRACFONE_GET_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE, ex);
        }
        return tfOneArUsaPostalZips;
    }

    @Override
    public TFOneGeneralResponse insertArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        validateinsertArUsaPostalZips(tracfoneOneArUsaPostalZips);
        try {
            response = tracfoneCarrierMaintenanceAction.insertArUsaPostalZips(tracfoneOneArUsaPostalZips, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_AR_USA_POSTAL_ZIPS_ERROR, TRACFONE_ADD_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse deleteArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        LOGGER.info("deleteArUsaPostalZips controller" + tracfoneOneArUsaPostalZips);
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteArUsaPostalZips(tracfoneOneArUsaPostalZips, userId);
        } catch (Exception ex) {
            LOGGER.info("deleteArUsaPostalZips controller Error" + ex);
            throw new TracfoneOneException(TRACFONE_DELETE_AR_USA_POSTAL_ZIPS_ERROR, TRACFONE_DELETE_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse updateArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;

        if (tracfoneOneArUsaPostalZips.isCheckDuplicate()) {
            validateArUsaPostalZips(tracfoneOneArUsaPostalZips);
        }
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateArUsaPostalZips(tracfoneOneArUsaPostalZips, userId);
        } catch (Exception ex) {
            LOGGER.info("update error" + ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_AR_USA_POSTAL_ZIPS_ERROR, TRACFONE_UPDATE_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE, ex);
        }

        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse bulkUpdateArUsaPostalZips(List<TracfoneOneArUsaPostalZips> tracfoneOneArUsaPostalZips, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        LOGGER.info("Controller" + tracfoneOneArUsaPostalZips);
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.bulkUpdateArUsaPostalZips(tracfoneOneArUsaPostalZips, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_AR_USA_POSTAL_ZIPS_ERROR, TRACFONE_UPDATE_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    private void validateinsertArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips) throws TracfoneOneException {
        TracfoneOneArUsaPostalZips searchArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        searchArUsaPostalZips.setDbEnv(tracfoneOneArUsaPostalZips.getDbEnv());
        searchArUsaPostalZips.setPostalCode(tracfoneOneArUsaPostalZips.getPostalCode());
        List<TFOneArUsaPostalZips> tfOneArUsaPostalZips = tracfoneCarrierMaintenanceAction.getArUsaPostalZips(searchArUsaPostalZips);
        if (!tfOneArUsaPostalZips.isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_AR_USA_POSTAL_ZIPS_ERROR, TRACFONE_DUPLICATE_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE);
        }
    }

    private void validateArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips) throws TracfoneOneException {
        TracfoneOneArUsaPostalZips searchArUsaPostalZips = new TracfoneOneArUsaPostalZips();
        searchArUsaPostalZips.setDbEnv(tracfoneOneArUsaPostalZips.getDbEnv());
        searchArUsaPostalZips.setPostalCode(tracfoneOneArUsaPostalZips.getPostalCode());
        List<TFOneArUsaPostalZips> tfOneArUsaPostalZips = tracfoneCarrierMaintenanceAction.getArUsaPostalZips(searchArUsaPostalZips);
        if (!tfOneArUsaPostalZips.isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_AR_USA_POSTAL_ZIPS_ERROR, TRACFONE_DUPLICATE_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE);

        }
    }

    @Override
    public TFOneArUsaMarketSearchResult getArUsaMarketDetails(TracfoneOneArUsaMarket tracfoneOneArUsaMarket) throws TracfoneOneException {
        TFOneArUsaMarketSearchResult tfOneArUsaMarket = null;
        try {
            tfOneArUsaMarket = tracfoneCarrierMaintenanceAction.getArUsaMarketDetails(tracfoneOneArUsaMarket);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_AR_USA_MARKET_DETAILS_ERROR, TRACFONE_GET_AR_USA_MARKET_DETAILS_ERROR_MESSAGE, ex);
        }
        return tfOneArUsaMarket;
    }

    @Override
    public TFOneGeneralResponse insertArUsaMarketDetails(TracfoneOneArUsaMarket tracfoneOneArUsaMarket, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        TracfoneOneArUsaMarket searchArUsaMarket = new TracfoneOneArUsaMarket();
        searchArUsaMarket.setDbEnv(tracfoneOneArUsaMarket.getDbEnv());
        searchArUsaMarket.setKeyCode(tracfoneOneArUsaMarket.getKeyCode());
        searchArUsaMarket.setCarrierEntity(tracfoneOneArUsaMarket.getCarrierEntity());
        TFOneArUsaMarketSearchResult tfOneArUsaMarket = tracfoneCarrierMaintenanceAction.getArUsaMarketDetails(searchArUsaMarket);
        try {
            if (!tfOneArUsaMarket.getArUsaMarkets().isEmpty()) {
                response = tracfoneCarrierMaintenanceAction.replaceArUsaMarketDetails(tracfoneOneArUsaMarket, userId);
                response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_REPLACED_AR_USA_MARKET_DETAILS);
            }
            else{
                response = tracfoneCarrierMaintenanceAction.insertArUsaMarketDetails(tracfoneOneArUsaMarket, userId);
                response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
            }

        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_AR_USA_MARKET_DETAILS_ERROR, TRACFONE_ADD_AR_USA_MARKET_DETAILS_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse deleteArUsaMarketDetails(TracfoneOneArUsaMarket tracfoneOneArUsaMarket, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteArUsaMarketDetails(tracfoneOneArUsaMarket, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_AR_USA_MARKET_DETAILS_ERROR, TRACFONE_DELETE_AR_USA_MARKET_DETAILS_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse updateArUsaMarketDetails(TracfoneOneArUsaMarket tracfoneOneArUsaMarket, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;

        if (tracfoneOneArUsaMarket.isCheckDuplicate()) {
            validateArUsaMarketDetails(tracfoneOneArUsaMarket);
        }
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateArUsaMarketDetails(tracfoneOneArUsaMarket, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_AR_USA_MARKET_DETAILS_ERROR, TRACFONE_UPDATE_AR_USA_MARKET_DETAILS_ERROR_MESSAGE, ex);
        }

        return tfOneGeneralResponse;
    }

    private void validateArUsaMarketDetails(TracfoneOneArUsaMarket tracfoneOneArUsaMarket) throws TracfoneOneException {
        TracfoneOneArUsaMarket searcharusamarket = new TracfoneOneArUsaMarket();
        searcharusamarket.setDbEnv((tracfoneOneArUsaMarket.getDbEnv()));
        searcharusamarket.setKeyCode(tracfoneOneArUsaMarket.getKeyCode());
        searcharusamarket.setCarrierEntity(tracfoneOneArUsaMarket.getCarrierEntity());
        TFOneArUsaMarketSearchResult tfOneArUsaMarket = tracfoneCarrierMaintenanceAction.getArUsaMarketDetails(searcharusamarket);
        if (!tfOneArUsaMarket.getArUsaMarkets().isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_AR_USA_MARKET_DETAILS_ERROR, TRACFONE_DUPLICATE_AR_USA_MARKET_DETAILS_ERROR_MESSAGE);

        }
    }

    @Override
    public TFOneGeneralResponse bulkUpdateArUsaMarketDetails(List<TracfoneOneArUsaMarket> tracfoneOneArUsaMarket, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.bulkUpdateArUsaMarketDetails(tracfoneOneArUsaMarket, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_AR_USA_MARKET_DETAILS_ERROR, TRACFONE_UPDATE_AR_USA_MARKET_DETAILS_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public void bulkInsertArUsaPostalZips(List<TracfoneOneArUsaPostalZips> tracfoneOneArUsaPostalZips, int userId, String description) throws TracfoneOneException {
        // Generate a unique identifier
        String unique = description + (new SecureRandom().nextInt((99999 - 10000) + 1) + 10000);
        // Create a record in cop_audit table for this bulk insert
        triggerAudit(userId, BULK_AR_USA_POSTAL_ZIPS_INSERT,
                "Requested a bulk insert of AR USA Postal Zips -" + tracfoneOneArUsaPostalZips.size(),
                String.valueOf(tracfoneOneArUsaPostalZips.size()) + "_" + unique);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZip : tracfoneOneArUsaPostalZips) {
                    try {
                        tracfoneCarrierMaintenanceAction.bulkInsertArUsaPostalZips(tracfoneOneArUsaPostalZip, userId, unique);
                    } catch (TracfoneOneException ex) {
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(ex.getErrorMessage())) {
                            triggerAudit(userId, BULK_AR_USA_POSTAL_ZIPS_INSERT,
                                    "Inserted AR USA Market " + tracfoneOneArUsaPostalZip, CARRIERID + unique);
                        }
                        triggerAudit(userId, BULK_AR_USA_POSTAL_ZIPS_INSERT,
                                BULK_INSERT_FAILED_FOR + tracfoneOneArUsaPostalZip + " - " + ex.getErrorMessage(),
                                ERROR_VALUE + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_AR_USA_POSTAL_ZIPS_ERROR, TRACFONE_ADD_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public void bulkInsertArUsaMarket(List<TracfoneOneArUsaMarket> tracfoneOneArUsaMarkets, int userId, String description) throws TracfoneOneException {
        // Generate a unique identifier
        String unique = description + (new SecureRandom().nextInt((99999 - 10000) + 1) + 10000);
        // Create a record in cop_audit table for this bulk insert
        triggerAudit(userId, BULK_AR_USA_MARKET_INSERT,
                "Requested a bulk insert of AR USA Market -" + tracfoneOneArUsaMarkets.size(),
                String.valueOf(tracfoneOneArUsaMarkets.size()) + "_" + unique);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (TracfoneOneArUsaMarket tracfoneOneArUsaMarket : tracfoneOneArUsaMarkets) {
                    try {
                        tracfoneCarrierMaintenanceAction.bulkInsertArUsaMarket(tracfoneOneArUsaMarket, userId, unique);
                    } catch (TracfoneOneException ex) {
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(ex.getErrorMessage())) {
                            triggerAudit(userId, BULK_AR_USA_MARKET_INSERT,
                                    "Inserted AR USA Market " + tracfoneOneArUsaMarket, CARRIERID + unique);
                        }
                        triggerAudit(userId, BULK_AR_USA_MARKET_INSERT,
                                BULK_INSERT_FAILED_FOR + tracfoneOneArUsaMarket + " - " + ex.getErrorMessage(),
                                ERROR_VALUE + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_AR_USA_MARKET_DETAILS_ERROR, TRACFONE_ADD_AR_USA_MARKET_DETAILS_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public TFOneGeneralResponse insertGeoLoc(TracfoneOneGeoLoc tfOneGeoLoc, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        validateDuplicateGeoLoc(tfOneGeoLoc);
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.insertGeoLoc(tfOneGeoLoc, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_ADD_GEO_LOC_ERROR, TRACFONE_ADD_GEO_LOC_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    private void validateDuplicateGeoLoc(TracfoneOneGeoLoc tfOneGeoLoc) throws TracfoneOneException {
        if (!tracfoneCarrierMaintenanceAction.searchGeoLoc(tfOneGeoLoc).isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_GEO_LOC_ERROR,
                    TRACFONE_DUPLICATE_GEO_LOC_ERROR_MESSAGE);
        }
    }

    @Override
    public TFOneGeneralResponse deleteGeoLoc(TracfoneOneGeoLoc tfOneGeoLoc, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteGeoLoc(tfOneGeoLoc, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_GEO_LOC_ERROR, TRACFONE_DELETE_GEO_LOC_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public void bulkInsertGeoLoc(List<TracfoneOneGeoLoc> tfGeoLocs, int userId, String description) throws TracfoneOneException {
        // Generate a unique identifier
        String unique = description + (new SecureRandom().nextInt((99999 - 10000) + 1) + 10000);
        // Create a record in cop_audit table for this bulk insert
        triggerAudit(userId, BULK_GEO_LOC_INSERT,
                "Requested a bulk insert of Geo Loc -" + tfGeoLocs.size(),
                String.valueOf(tfGeoLocs.size()) + "_" + unique);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (TracfoneOneGeoLoc tfGeoLoc : tfGeoLocs) {
                    try {

                        tracfoneCarrierMaintenanceAction.bulkInsertGeoLocs(tfGeoLoc, userId, unique);

                    } catch (TracfoneOneException ex) {
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(ex.getErrorMessage())) {
                            triggerAudit(userId, BULK_GEO_LOC_INSERT,
                                    "Inserted Geo Locs " + tfGeoLoc, CARRIERID + unique);
                        }
                        triggerAudit(userId, BULK_GEO_LOC_INSERT,
                                BULK_INSERT_FAILED_FOR + tfGeoLoc + " - " + ex.getErrorMessage(),
                                ERROR_VALUE + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_GEO_LOC_ERROR, TRACFONE_ADD_GEO_LOC_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public List<String> getUsers() throws TracfoneOneException {
        List<String> userList = new ArrayList<>();
        try {
            userList = tracfoneCarrierMaintenanceAction.getUsers();
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_USER_ERROR, TRACFONE_GET_USER_ERROR_MESSAGE, ex);
        }
        return userList;
    }

    @Override
    public List<TFOneGeoLoc> searchGeoLoc(TracfoneOneGeoLoc tfOneGeoLoc) throws TracfoneOneException {
        List<TFOneGeoLoc> geoLocs = new ArrayList<>();
        try {
            geoLocs = tracfoneCarrierMaintenanceAction.searchGeoLoc(tfOneGeoLoc);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_GEO_LOC_ERROR, TRACFONE_GET_GEO_LOC_ERROR_MESSAGE, ex);
        }
        return geoLocs;
    }

    @Override
    public TFOneGeneralResponse updateGeoLoc(TracfoneOneGeoLoc tfGeoLoc, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        if (tfGeoLoc.isCheckDuplicate()) {
            validateDuplicateGeoLoc(tfGeoLoc);
        }
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateGeoLoc(tfGeoLoc, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_GEO_LOC_ERROR, TRACFONE_UPDATE_GEO_LOC_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse bulkUpdateGeoLoc(List<TracfoneOneGeoLoc> geoLocs, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.bulkUpdateGeoLoc(geoLocs, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_GEO_LOC_ERROR, TRACFONE_UPDATE_GEO_LOC_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public List<TFOneCarrierZones> searchCarrierzones(TracfoneOneCarrierZones tracfoneOneCarrierZones) throws TracfoneOneException {
        List<TFOneCarrierZones> tfOneCarrierZones = null;
        try {
            tfOneCarrierZones = tracfoneCarrierMaintenanceAction.searchCarrierzones(tracfoneOneCarrierZones);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_CARRIERZONES_ERROR, TRACFONE_CARRIERZONES_ERROR_MESSAGE, ex);
        }
        return tfOneCarrierZones;
    }

    @Override
    public TFOneGeneralResponse insertCarrierzones(TracfoneOneCarrierZones tracfoneOneCarrierZones, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneCarrierMaintenanceAction.insertCarrierzones(tracfoneOneCarrierZones, userId, null);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_CARRIERZONES_ERROR, TRACFONE_ADD_CARRIERZONES_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse deleteCarrierzones(TracfoneOneCarrierZones tracfoneOneCarrierZones, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteCarrierzones(tracfoneOneCarrierZones, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_CARRIERZONES_ERROR, TRACFONE_DELETE_CARRIERZONES_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse updateCarrierzones(TracfoneOneCarrierZones tracfoneOneCarrierZones, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        if (tracfoneOneCarrierZones.isCheckDuplicate()) {
            validateCarrierzones(tracfoneOneCarrierZones);
        }
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateCarrierzones(tracfoneOneCarrierZones, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_CARRIERZONES_ERROR, TRACFONE_UPDATE_CARRIERZONES_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse bulkUpdateCarrierZones(List<TracfoneOneCarrierZones> tracfoneOneCarrierZones, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.bulkUpdateCarrierZones(tracfoneOneCarrierZones, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_CARRIERZONES_ERROR, TRACFONE_UPDATE_CARRIERZONES_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    private void validateCarrierzones(TracfoneOneCarrierZones tracfoneOneCarrierZones) throws TracfoneOneException {
        TracfoneOneCarrierZones searchncarrierzones = new TracfoneOneCarrierZones();
        searchncarrierzones.setDbEnv((tracfoneOneCarrierZones.getDbEnv()));
        searchncarrierzones.setZipCode(tracfoneOneCarrierZones.getZipCode());
        searchncarrierzones.setState(tracfoneOneCarrierZones.getState());
        searchncarrierzones.setZone(tracfoneOneCarrierZones.getZone());
        searchncarrierzones.setCounty(tracfoneOneCarrierZones.getCounty());
        searchncarrierzones.setCarrierName(tracfoneOneCarrierZones.getCarrierName());
        List<TFOneCarrierZones> tfOneCarrierZones = tracfoneCarrierMaintenanceAction.searchCarrierzones(searchncarrierzones);
        if (!tfOneCarrierZones.isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_CARRIERZONES_ERROR, TRACFONE_DUPLICATE_CARRIERZONES_ERROR_MESSAGE);
        }
    }

    @Override
    public void bulkInsertCarrierzones(List<TracfoneOneCarrierZones> tracfoneOneCarrierZones, int userId) throws TracfoneOneException {
        // Generate a unique identifier
        long unique = (new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        // Create a record in cop_audit table for this bulk insert
        triggerAudit(userId, BULK_CARRIERZONES_INSERT,
                "Requested a bulk insert of Carrierzones -" + tracfoneOneCarrierZones.size(),
                String.valueOf(tracfoneOneCarrierZones.size()) + "_" + unique);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (TracfoneOneCarrierZones tracfoneOneCarrierZone : tracfoneOneCarrierZones) {
                    try {
                        tracfoneCarrierMaintenanceAction.insertCarrierzones(tracfoneOneCarrierZone, userId, String.valueOf(unique));
                    } catch (TracfoneOneException ex) {
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(ex.getErrorMessage())) {
                            triggerAudit(userId, BULK_CARRIERZONES_INSERT,
                                    "Inserted into Carrierzones " + tracfoneOneCarrierZone, CARRIERID + unique);
                        }
                        triggerAudit(userId, BULK_CARRIERZONES_INSERT,
                                BULK_INSERT_FAILED_FOR + tracfoneOneCarrierZone + " - " + ex.getErrorMessage(),
                                ERROR_VALUE + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_CARRIERZONES_ERROR, TRACFONE_ADD_CARRIERZONES_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public void bulkDeleteCarrierZones(List<TracfoneOneCarrierZones> tracfoneOneCarrierZones, int userId) throws TracfoneOneException {
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (TracfoneOneCarrierZones tracfoneOneCarrierZone : tracfoneOneCarrierZones) {
                    try {
                        tracfoneCarrierMaintenanceAction.bulkDeleteCarrierZones(tracfoneOneCarrierZone, userId);
                    } catch (TracfoneOneException ex) {
                        LOGGER.info(CONTROLLER_ERROR, ex);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_CARRIERZONES_ERROR, TRACFONE_DELETE_CARRIERZONES_ERROR, ex);
        }
    }

    @Override
    public void bulkDeleteNpanxx2CarrierZones(List<TracfoneOneNpanxx2Carrierzones> tracfoneOneNpanxx2Carrierzones, int userId) throws TracfoneOneException {
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzone : tracfoneOneNpanxx2Carrierzones) {
                    try {
                        tracfoneCarrierMaintenanceAction.deleteNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzone, userId);
                    } catch (TracfoneOneException ex) {
                        LOGGER.info(CONTROLLER_ERROR, ex);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_NPANXX_2_CARRIERZONES_ERROR, TRACFONE_DELETE_NPANXX_2_CARRIERZONES_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public void bulkDeleteArUsaPostalZips(List<TracfoneOneArUsaPostalZips> tracfoneOneArUsaPostalZips, int userId) throws TracfoneOneException {
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZip : tracfoneOneArUsaPostalZips) {
                    try {
                        tracfoneCarrierMaintenanceAction.deleteArUsaPostalZips(tracfoneOneArUsaPostalZip, userId);
                    } catch (TracfoneOneException ex) {
                        LOGGER.info(CONTROLLER_ERROR, ex);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_AR_USA_POSTAL_ZIPS_ERROR, TRACFONE_DELETE_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public void bulkDeleteArUsaMarket(List<TracfoneOneArUsaMarket> tracfoneOneArUsaMarkets, int userId) throws TracfoneOneException {
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (TracfoneOneArUsaMarket tracfoneOneArUsaMarket : tracfoneOneArUsaMarkets) {
                    try {
                        tracfoneCarrierMaintenanceAction.deleteArUsaMarketDetails(tracfoneOneArUsaMarket, userId);
                    } catch (TracfoneOneException ex) {
                        LOGGER.info(CONTROLLER_ERROR, ex);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_AR_USA_MARKET_DETAILS_ERROR, TRACFONE_DELETE_AR_USA_MARKET_DETAILS_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public List<TFOneCarrierPref> searchCarrierpref(TracfoneOneCarrierPref tracfoneOneCarrierPref) throws TracfoneOneException {
        List<TFOneCarrierPref> tfOneCarrierPref = null;
        try {
            tfOneCarrierPref = tracfoneCarrierMaintenanceAction.searchCarrierpref(tracfoneOneCarrierPref);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_CARRIERPREF_ERROR, TRACFONE_CARRIERPREF_ERROR_MESSAGE, ex);
        }
        return tfOneCarrierPref;
    }

    @Override
    public TFOneGeneralResponse insertCarrierpref(TracfoneOneCarrierPref tracfoneOneCarrierPref, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        validateCarrierpref(tracfoneOneCarrierPref);
        try {
            response = tracfoneCarrierMaintenanceAction.insertCarrierpref(tracfoneOneCarrierPref, userId, null);
            response = new TFOneGeneralResponse(response.getStatus(), response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_CARRIERPREF_ERROR, TRACFONE_ADD_CARRIERPREF_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse deleteCarrierpref(TracfoneOneCarrierPref tracfoneOneCarrierPref, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.deleteCarrierpref(tracfoneOneCarrierPref, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_CARRIERPREF_ERROR, TRACFONE_DELETE_CARRIERPREF_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse updateCarrierpref(TracfoneOneCarrierPref tracfoneOneCarrierPref, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        validateCarrierpref(tracfoneOneCarrierPref);
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.updateCarrierpref(tracfoneOneCarrierPref, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_CARRIERPREF_ERROR, TRACFONE_UPDATE_CARRIERPREF_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse bulkUpdateCarrierpref(List<TracfoneOneCarrierPref> tracfoneOneCarrierPref, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        try {
            tfOneGeneralResponse = tracfoneCarrierMaintenanceAction.bulkUpdateCarrierpref(tracfoneOneCarrierPref, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_CARRIERPREF_ERROR, TRACFONE_UPDATE_CARRIERPREF_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    private void validateCarrierpref(TracfoneOneCarrierPref tracfoneOneCarrierPref) throws TracfoneOneException {
        TracfoneOneCarrierPref searchncarrierpref = new TracfoneOneCarrierPref();
        searchncarrierpref.setDbEnv((tracfoneOneCarrierPref.getDbEnv()));
        searchncarrierpref.setState(tracfoneOneCarrierPref.getState());
        searchncarrierpref.setCounty(tracfoneOneCarrierPref.getCounty());
        searchncarrierpref.setCarrierId(tracfoneOneCarrierPref.getCarrierId());
        searchncarrierpref.setCarrierName(tracfoneOneCarrierPref.getCarrierName());
        searchncarrierpref.setCarrierRank(tracfoneOneCarrierPref.getCarrierRank());
        searchncarrierpref.setNewRank(tracfoneOneCarrierPref.getNewRank());
        List<TFOneCarrierPref> tfOneCarrierpref = tracfoneCarrierMaintenanceAction.searchCarrierpref(searchncarrierpref);
        if (!tfOneCarrierpref.isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_CARRIERPREF_ERROR, TRACFONE_DUPLICATE_CARRIERPREF_ERROR_MESSAGE);
        }
    }

    @Override
    public void bulkInsertCarrierpref(List<TracfoneOneCarrierPref> tracfoneOneCarrierPrefs, int userId, String description) throws TracfoneOneException {
        // Generate a unique identifier
        String unique = description + (new SecureRandom().nextInt((99999 - 10000) + 1) + 10000);
        // Create a record in cop_audit table for this bulk insert
        triggerAudit(userId, BULK_CARRIERPREF_INSERT,
                "Requested a bulk insert of Carrierpref -" + tracfoneOneCarrierPrefs.size(),
                String.valueOf(tracfoneOneCarrierPrefs.size()) + "_" + unique);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (TracfoneOneCarrierPref tracfoneOneCarrierPref : tracfoneOneCarrierPrefs) {
                    try {
                        tracfoneCarrierMaintenanceAction.insertCarrierpref(tracfoneOneCarrierPref, userId, unique);
                    } catch (TracfoneOneException ex) {
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(ex.getErrorMessage())) {
                            triggerAudit(userId, BULK_AR_USA_MARKET_INSERT,
                                    "Inserted Carrierpref " + tracfoneOneCarrierPref, CARRIERID + unique);
                        }
                        triggerAudit(userId, BULK_AR_USA_MARKET_INSERT,
                                BULK_INSERT_FAILED_FOR + tracfoneOneCarrierPref + " - " + ex.getErrorMessage(),
                                ERROR_VALUE + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_AR_USA_MARKET_DETAILS_ERROR, TRACFONE_ADD_AR_USA_MARKET_DETAILS_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public void bulkDeleteCarrierpref(List<TracfoneOneCarrierPref> tracfoneOneCarrierPrefs, int userId) throws TracfoneOneException {
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (TracfoneOneCarrierPref tracfoneOneCarrierPref : tracfoneOneCarrierPrefs) {
                    try {
                        tracfoneCarrierMaintenanceAction.bulkDeleteCarrierpref(tracfoneOneCarrierPref, userId);
                    } catch (TracfoneOneException ex) {
                        LOGGER.info(CONTROLLER_ERROR, ex);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_CARRIERPREF_ERROR, TRACFONE_DELETE_CARRIERPREF_ERROR, ex);
        }
    }

}

