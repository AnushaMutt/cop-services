/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

/**
 *
 * @author druiz
 */
public class TFOneGeneralResponse {
    
    public static final String SUCCESS = "Success";
    public static final String FAILED = "Error";
    
    private String status;
    private String message;

    public TFOneGeneralResponse(String status, String message) {
        this.status = status;
        this.message = message;
    }
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
