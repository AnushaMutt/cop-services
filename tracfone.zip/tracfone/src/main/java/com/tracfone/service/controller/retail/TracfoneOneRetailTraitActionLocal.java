package com.tracfone.service.controller.retail;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.retail.request.TracfoneOneRetailLocation;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTraitSearchModel;
import com.tracfone.service.model.retail.response.TFOneRetailLocation;
import com.tracfone.service.model.retail.response.TFOneTraitDetail;
import com.tracfone.service.model.retail.response.TracfoneOneRetailAvailability;

import javax.ejb.Local;
import java.util.List;
import java.util.Map;

@Local
public interface TracfoneOneRetailTraitActionLocal {

    List<TracfoneOneRetailAvailability> viewAvailability(TracfoneOneRetailTraitSearchModel tracfoneOneRetailLocation) throws TracfoneOneException;

    TFOneGeneralResponse closeStores(String objIds, String parentId, int userId) throws TracfoneOneException;

    List<TFOneRetailLocation> searchRetailLocations(TracfoneOneRetailTraitSearchModel retailTraitSearchModel) throws TracfoneOneException;

    boolean addUpdateRetailStore(TracfoneOneRetailLocation tracfoneOneRetailLocation, int userId);

    TFOneGeneralResponse reopenStores(String objIds, String parentId, int userId) throws TracfoneOneException;

    List<TFOneTraitDetail> getTraitDetails(String locationId) throws TracfoneOneException;

    TFOneGeneralResponse deleteStores(String objIds, int userId) throws TracfoneOneException;

    TFOneGeneralResponse approveTraits(String objId, int userId);

    List<String> getRadius() throws TracfoneOneException;

    Map<String, String> analyseTraits(TracfoneOneRetailTraitSearchModel retailTraitSearchModel, int userId) throws TracfoneOneException;

    int getTraitCountForLocation(String objIds);

    List<TFOneRetailLocation> searchClosedStores(TracfoneOneRetailTraitSearchModel retailTraitSearchModel) throws TracfoneOneException;

    TFOneGeneralResponse countStores(String parentId, int userId) throws TracfoneOneException;
}
