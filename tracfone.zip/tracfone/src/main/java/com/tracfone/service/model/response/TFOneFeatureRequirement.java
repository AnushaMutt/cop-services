package com.tracfone.service.model.response;

public class TFOneFeatureRequirement {
    private String featureRequirement;
    private String description;

    public String getFeatureRequirement() {
        return featureRequirement;
    }

    public void setFeatureRequirement(String featureRequirement) {
        this.featureRequirement = featureRequirement;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "TFOneFeatureRequirement{" +
                "featureRequirement='" + featureRequirement + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
