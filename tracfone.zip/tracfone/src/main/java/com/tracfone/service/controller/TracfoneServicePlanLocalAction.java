package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneSearchCarrierFeatureModel;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchServicePlanModel;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;

import javax.ejb.Local;
import java.util.List;
import java.util.Set;

@Local
public interface TracfoneServicePlanLocalAction {
    List<TFOneCarrierServicePlan> searchServicePlans(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException;

    List<TFOneCarrierFeature> viewServicePlanCarrierFeatures(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException;

    List<TFOneCarrierServicePlan> getAllServicePlans(String dbEnv) throws TracfoneOneException;

    List<TFOneCarrierServicePlan> getAllLegacyPaygoPlans(String dbEnv, String carrierName) throws TracfoneOneException;

    List<TFOneCarrierFeature> getCarrierFeatureLinks(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException;

    List<String> getAllServicePlanCarrierNames(String dbEnv, String servicePlanId, boolean isLegacy) throws TracfoneOneException;

    List<TFOneCarrierServicePlan> getServicePlansForCopy(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException;

    int countBucketsByLinkObjId(String dbEnv, Set<String> profileIds, String servicePlanId) throws TracfoneOneException;

    int countChildBucketsByLinkObjId(String dbEnv, Set<String> profileIds, String servicePlanId) throws TracfoneOneException;

    void deleteDummyCarrierFeature(String dbEnv, String toServicePlanId, int userId) throws TracfoneOneException;

    int countCarrierFeatures(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws TracfoneOneException;

    int getMspBucketCount(String query, TracfoneOneSearchPlanModel searchPlanModel, List<String> profileIds) throws TracfoneOneException;

    List<String> getMspProfileCount(TracfoneOneSearchPlanModel searchPlanModel) throws TracfoneOneException;
}
