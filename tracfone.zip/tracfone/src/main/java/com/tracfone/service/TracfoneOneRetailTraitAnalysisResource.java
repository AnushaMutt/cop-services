package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.retail.TracfoneOneRetailAdminActionLocal;
import com.tracfone.service.controller.retail.TracfoneOneRetailStoreControllerLocal;
import com.tracfone.service.controller.retail.TracfoneOneRetailTraitActionLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.retail.request.TracfoneOneRetailLocation;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTraitSearchModel;
import com.tracfone.service.model.retail.response.TFOneRetailBrand;
import com.tracfone.service.model.retail.response.TFOneRetailCarrier;
import com.tracfone.service.model.retail.response.TFOneRetailLocation;
import com.tracfone.service.model.retail.response.TFOneRetailMaster;
import com.tracfone.service.model.retail.response.TFOneRetailParent;
import com.tracfone.service.model.retail.response.TFOneTraitDetail;
import com.tracfone.service.model.retail.response.TracfoneOneRetailAvailability;
import com.tracfone.service.util.TracfoneOneConstantRetailStore;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Path("traitanalysis")
public class TracfoneOneRetailTraitAnalysisResource implements TracfoneOneConstantRetailStore {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneRetailTraitAnalysisResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @Context
    private SecurityContext securityContext;

    @EJB
    private TracfoneOneRetailAdminActionLocal tracfoneOneRetailAdminAction;

    @EJB
    private TracfoneOneRetailTraitActionLocal tracfoneOneRetailTraitAction;

    @EJB
    private TracfoneOneRetailStoreControllerLocal tracfoneOneRetailStoreController;

    /**
     * This method is used to get all Parents
     *
     * @return
     */
    @GET
    @Path("retailmanagementview/getparents")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getParents() {
        List<TFOneRetailParent> tfOneRetailParents = new ArrayList<>();
        try {
            tfOneRetailParents = tracfoneOneRetailAdminAction.getParents();
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_PARENTS, TRACFONE_GET_ALL_PARENTS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailParents), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Brands
     *
     * @return
     */
    @GET
    @Path("retailmanagementview/getbrands")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBrands() {
        List<TFOneRetailBrand> tfOneRetailBrands = new ArrayList<>();
        try {
            tfOneRetailBrands = tracfoneOneRetailAdminAction.getBrands();
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_BRANDS, TRACFONE_GET_ALL_BRANDS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailBrands), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Carriers
     *
     * @return
     */
    @GET
    @Path("retailmanagementview/getcarriers")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarriers() {
        List<TFOneRetailCarrier> tfOneRetailCarriers = new ArrayList<>();
        try {
            tfOneRetailCarriers = tracfoneOneRetailAdminAction.getCarriers();
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_CARRIERS, TRACFONE_GET_ALL_CARRIERS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailCarriers), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all radius
     *
     * @return
     */
    @GET
    @Path("retailmanagementview/getradius")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getRadius() {
        List<String> response = new ArrayList<>();
        try {
            response = tracfoneOneRetailTraitAction.getRadius();
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_RADIUS, TRACFONE_GET_ALL_RADIUS_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all Masters
     *
     * @return
     */
    @GET
    @Path("retailmanagementview/{parentid}/getmasters")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getMasters(@PathParam("parentid") final String parentId) {
        List<TFOneRetailMaster> tfOneRetailMasters = new ArrayList<>();
        try {
            tfOneRetailMasters = tracfoneOneRetailAdminAction.getMasters(parentId);
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_ALL_MASTERS, TRACFONE_GET_ALL_MASTERS_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneRetailMasters), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for C RTL LOCATION for a parent
     *
     * @param retailTraitSearchModel
     * @return
     */
    @POST
    @Path("retailmanagementview/searchlocations")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchRetailLocations(final TracfoneOneRetailTraitSearchModel retailTraitSearchModel) {
        List<TFOneRetailLocation> retailLocations = new ArrayList<>();
        try {
            retailLocations = tracfoneOneRetailTraitAction.searchRetailLocations(retailTraitSearchModel);
        } catch (Exception e) {
            return handleException(e, TRACFONE_SEARCH_RETAIL_LOCATIONS, TRACFONE_SEARCH_RETAIL_LOCATIONS_MESSAGE);
        }
        return Response.ok(gson.toJson(retailLocations), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add stores
     *
     * @param tracfoneOneRetailLocation
     * @return
     */
    @POST
    @Path("retailmanagementview/openstores")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response openStores(List<TracfoneOneRetailLocation> tracfoneOneRetailLocation) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailStoreController.openStores(tracfoneOneRetailLocation,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_ADD_STORE, TRACFONE_ADD_STORE_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update radius into C_RTL_LOCATION
     *
     * @param tracfoneOneRetailLocations
     * @return
     */
    @POST
    @Path("retailmanagementview/updatestoreradius")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateRetailLocationRadius(final List<TracfoneOneRetailLocation> tracfoneOneRetailLocations) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailStoreController.updateRetailLocationRadius(tracfoneOneRetailLocations,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_UPDATE_RETAIL_LOCATIONS, TRACFONE_UPDATE_RETAIL_LOCATIONS_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used for view availability
     *
     * @param tracfoneOneRetailTraitSearchModel
     * @return
     */
    @POST
    @Path("retailmanagementview/viewavailability")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response viewAvailability(final TracfoneOneRetailTraitSearchModel tracfoneOneRetailTraitSearchModel) {
        List<TracfoneOneRetailAvailability> response = new ArrayList<>();
        try {
            response = tracfoneOneRetailTraitAction.viewAvailability(tracfoneOneRetailTraitSearchModel);
        } catch (Exception e) {
            return handleException(e, TRACFONE_VIEW_AVAILABILITY, TRACFONE_VIEW_AVAILABILITY_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to close stores (setting status = C)
     *
     * @return
     */
    @POST
    @Path("retailmanagementview/closestores")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response closeStores(final TracfoneOneRetailLocation tracfoneOneRetailLocation) {
        TFOneGeneralResponse response;
        try {
            LOGGER.info("TracfoneOneRetailLocation- " + tracfoneOneRetailLocation);
            response = tracfoneOneRetailTraitAction.closeStores(tracfoneOneRetailLocation.getObjIds(),
                    tracfoneOneRetailLocation.getParentId(),
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_CLOSE_STORE, TRACFONE_CLOSE_STORE_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to re open stores (setting status = A)
     *
     * @return
     */
    @POST
    @Path("retailmanagementview/reopenstores")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response reopenStores(final TracfoneOneRetailLocation tracfoneOneRetailLocation) {
        TFOneGeneralResponse response;
        LOGGER.info("TracfoneOneRetailLocation - " + tracfoneOneRetailLocation);
        try {
            response = tracfoneOneRetailTraitAction.reopenStores(tracfoneOneRetailLocation.getObjIds(),
                    tracfoneOneRetailLocation.getParentId(),
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_REOPEN_STORE, TRACFONE_REOPEN_STORE_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete a Carrier Pref Details
     *
     * @return
     */
    @POST
    @Path("retailmanagementview/deletestores")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteStores(final TracfoneOneRetailLocation tracfoneOneRetailLocation) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailTraitAction.deleteStores(tracfoneOneRetailLocation.getObjIds(),
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_DELETE_STORES, TRACFONE_DELETE_STORES_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all trait details based on location obj id
     *
     * @return
     */
    @GET
    @Path("retailmanagementview/gettraitdetails/{locationid}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getTraitDetails(@PathParam("locationid") final String locationId) {
        List<TFOneTraitDetail> traitDetails = new ArrayList<>();
        try {
            traitDetails = tracfoneOneRetailTraitAction.getTraitDetails(locationId);
        } catch (Exception e) {
            return handleException(e, TRACFONE_GET_TRAIT_DETAILS, TRACFONE_GET_TRAIT_DETAILS_MESSAGE);
        }
        return Response.ok(gson.toJson(traitDetails), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used for trait analysis
     *
     * @param tracfoneOneRetailTraitSearchModel
     * @return
     */
    @POST
    @Path("retailmanagementview/analysetraits")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response analyseTraits(final TracfoneOneRetailTraitSearchModel tracfoneOneRetailTraitSearchModel) {
        Map<String, String> response;
        try {
            response = tracfoneOneRetailTraitAction.analyseTraits(tracfoneOneRetailTraitSearchModel,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_ANALYSE_TRAITS, TRACFONE_ANALYSE_TRAITS_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for closed stores
     *
     * @param retailTraitSearchModel
     * @return
     */
    @POST
    @Path("retailmanagementview/searchclosedstores")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchClosedStores(final TracfoneOneRetailTraitSearchModel retailTraitSearchModel) {
        List<TFOneRetailLocation> retailLocations = new ArrayList<>();
        try {
            retailLocations = tracfoneOneRetailTraitAction.searchClosedStores(retailTraitSearchModel);
        } catch (Exception e) {
            return handleException(e, TRACFONE_SEARCH_CLOSED_STORES, TRACFONE_SEARCH_CLOSED_STORES_MESSAGE);
        }
        return Response.ok(gson.toJson(retailLocations), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get END TIME based on X_NAME = parentId_PARENT_UPDATE
     *
     * @return
     */
    @GET
    @Path("retailmanagementview/{parentid}/getlasttraitrundate")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getLastTraitRunDate(@PathParam("parentid") final String parentId) {
        TFOneGeneralResponse tfOneResponse;
        try {
            String endRun = tracfoneOneRetailAdminAction.getLastTraitRunDate(parentId);
            tfOneResponse = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, endRun);
        } catch (Exception e) {
            return handleException(e, TRACFONE_LAST_TRAIT_RUN_DATE, TRACFONE_LAST_TRAIT_RUN_DATE_MESSAGE);
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to run traits for a Store
     *
     * @return
     */
    @POST
    @Path("retailmanagementview/runstoretraits")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response runStoreTraits(TracfoneOneRetailLocation tracfoneOneRetailLocation) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneRetailAdminAction.runStoreTraits(tracfoneOneRetailLocation,
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_RUN_STORE_TRAITS, TRACFONE_RUN_STORE_TRAITS_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves the user object making request from the principal.
     *
     * @return
     */
    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }

    /**
     * To handle the exception in a way the UI understands it
     *
     * @param e
     * @param errorCode
     * @param errorMessage
     * @return
     */
    private Response handleException(Exception e, String errorCode, String errorMessage) {
        LOGGER.error(e);
        TracfoneOneException tfoEx = new TracfoneOneException(errorCode, errorMessage, e);
        Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
        return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to count stores for a Parent
     *
     * @return
     */
    @POST
    @Path("retailmanagementview/countstores")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response countStores(final TracfoneOneRetailLocation tracfoneOneRetailLocation) {
        TFOneGeneralResponse response;
        LOGGER.info("TracfoneOneRetailLocation - " + tracfoneOneRetailLocation);
        try {
            response = tracfoneOneRetailTraitAction.countStores(tracfoneOneRetailLocation.getParentId(),
                    getUserFromPrincipal().getUserId());
        } catch (Exception e) {
            return handleException(e, TRACFONE_COUNT_STORE, TRACFONE_COUNT_STORE_MESSAGE);
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }
}
