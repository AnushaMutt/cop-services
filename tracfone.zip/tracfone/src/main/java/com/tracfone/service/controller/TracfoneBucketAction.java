/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneBucket;
import com.tracfone.service.model.request.TracfoneOneBucketList;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucketTier;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildTier;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.response.TFOneBucket;
import com.tracfone.service.model.response.TFOneBucketList;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileBucketTier;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildTier;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneRatePlan;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantPlanWizard;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

/**
 * @author Shireen Fathima
 */
@Stateless
public class TracfoneBucketAction implements TracfoneBucketLocalAction,
        TracfoneOneConstant,
        TracfoneOneConstantPlanWizard {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneBucketAction.class);

    @EJB
    DataBaseController dbControllerEJB;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    private static final String COMMA = ", ";

    private static final String AND = " AND ";

    @Override
    public TFOneGeneralResponse insertLegacyBucket(List<TracfoneOneBucket> tfBuckets, int userId) throws TracfoneOneException {
        int[] countBuckets;
        List<String> duplicateBuckets = new ArrayList<>();
        LOGGER.info("Number of IG Buckets to be inserted is " + tfBuckets.size());
        try (Connection con = dbControllerEJB.getDataSource(tfBuckets.get(0).getDbEnv()).getConnection();
             PreparedStatement igBucketStmt = con.prepareStatement(TRACFONE_INSERT_IG_BUCKETS);) {

            for (TracfoneOneBucket tfOneBucket : tfBuckets) {
                TFOneBucket duplicate = viewBucket(tfOneBucket);
                if (null != duplicate && !StringUtils.isNullOrEmpty(duplicate.getBucketId())) {
                    duplicateBuckets.add(duplicate.getBucketId());
                } else {
                    setIgBucketQueryParameters(igBucketStmt, tfOneBucket, false);
                    igBucketStmt.addBatch();
                }
            }

            countBuckets = igBucketStmt.executeBatch();
            LOGGER.info("Number of IG Buckets inserted is " + countBuckets.length);

            if (countBuckets.length != (tfBuckets.size() - duplicateBuckets.size())) {
                LOGGER.info("Mismatch in the records inserted into ig_bucket and number of records passed into method");
            }

            //TODO need to know how to handle this duplicate check when many buckets are there
            if (!duplicateBuckets.isEmpty()) {
                LOGGER.info("The duplicate IG Buckets identified is " + duplicateBuckets);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert IG Bucket", "Inserted IG Bucket objects " + tfBuckets, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfBuckets.get(0).getBucketId());
    }

    private TFOneBucket viewBucket(TracfoneOneBucket tfBucket) throws TracfoneOneException {
        TFOneBucket tfOneBucket = new TFOneBucket();
        try (Connection con = dbControllerEJB.getDataSource(tfBucket.getDbEnv()).getConnection();
             PreparedStatement stmt = getSelectStatement(con, tfBucket);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                tfOneBucket.setBucketId(resultSet.getString(BUCKET_ID));
            }

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfOneBucket;
    }

    private PreparedStatement getSelectStatement(Connection con, TracfoneOneBucket tfBucket) throws SQLException {
        PreparedStatement stmt = con.prepareStatement(TRACFONE_VIEW_IG_BUCKETS);
        stmt.setString(1, tfBucket.getBucketId());
        stmt.setString(2, tfBucket.getRatePlan());
        return stmt;
    }

    private void setIgBucketQueryParameters(PreparedStatement stmt, TracfoneOneBucket tfBucket, boolean isUpdate) throws SQLException {
        int index = 1;
        stmt.setString(index++, tfBucket.getBucketId());
        if (!StringUtils.isNullOrEmpty(tfBucket.getMeasureUnit())) {
            stmt.setString(index++, tfBucket.getMeasureUnit().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfBucket.getBucketDesc())) {
            stmt.setString(index++, tfBucket.getBucketDesc().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfBucket.getBucketType())) {
            stmt.setString(index++, tfBucket.getBucketType().trim().toUpperCase());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        stmt.setString(index++, tfBucket.getRatePlan().trim());
        stmt.setString(index++, tfBucket.getActiveFlag().trim().toUpperCase());
        if (!StringUtils.isNullOrEmpty(tfBucket.getSuiDisplayType())) {
            stmt.setString(index++, tfBucket.getSuiDisplayType().trim().toUpperCase());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfBucket.getBucketGroup())) {
            stmt.setString(index++, tfBucket.getBucketGroup().trim().toUpperCase());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfBucket.getPriorityGroup())) {
            stmt.setString(index++, tfBucket.getPriorityGroup().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (isUpdate) {
            stmt.setString(index++, tfBucket.getBucketId().trim());
            stmt.setString(index, tfBucket.getRatePlan().trim());
        }
    }

    private void setInsertCarrierProfileBucketStmtQueryParameters(PreparedStatement stmt, TracfoneOneCarrierProfileBucket carrierProfileBucket) throws SQLException {
        int index = 1;
        stmt.setLong(index++, Long.valueOf(carrierProfileBucket.getObjectId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileBucket.getProfileId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileBucket.getServicePlanId()));
        stmt.setString(index++, carrierProfileBucket.getBucketId());
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getBucketValue())) {
            stmt.setLong(index++, Long.valueOf(carrierProfileBucket.getBucketValue()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getUnitOfMeasure())) {
            stmt.setString(index++, carrierProfileBucket.getUnitOfMeasure());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getBucketType())) {
            stmt.setString(index++, carrierProfileBucket.getBucketType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getBucketGroup())) {
            stmt.setString(index++, carrierProfileBucket.getBucketGroup());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getBucketRequirement())) {
            stmt.setString(index++, carrierProfileBucket.getBucketRequirement());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        stmt.setString(index++, carrierProfileBucket.getActiveFlag().toUpperCase());
        stmt.setString(index++, carrierProfileBucket.getAutoRenewFlag());
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getAutoRenewFrequency())) {
            stmt.setString(index++, carrierProfileBucket.getAutoRenewFrequency());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getAutoRenewValue())) {
            stmt.setString(index++, carrierProfileBucket.getAutoRenewValue());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getAutoRenewDay())) {
            stmt.setString(index++, carrierProfileBucket.getAutoRenewDay());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getBenefitType())) {
            stmt.setString(index++, carrierProfileBucket.getBenefitType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getSuiDisplayType())) {
            stmt.setString(index++, carrierProfileBucket.getSuiDisplayType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getPriority())) {
            stmt.setLong(index++, Long.valueOf(carrierProfileBucket.getPriority()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getHideUbiFlag())) {
            stmt.setString(index, carrierProfileBucket.getHideUbiFlag());
        } else {
            stmt.setNull(index, Types.VARCHAR);
        }
    }

    private void setInsertCarrierProfileBucketTierQueryParameters(PreparedStatement stmt, TracfoneOneCarrierProfileBucketTier carrierProfileBucketTier) throws SQLException {
        int index = 1;
        stmt.setLong(index++, Long.valueOf(carrierProfileBucketTier.getObjId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileBucketTier.getCarrierProfileBucketsObjId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileBucketTier.getUsageTierId()));
        if (!StringUtils.isNullOrEmpty(carrierProfileBucketTier.getTierDescription())) {
            stmt.setString(index++, carrierProfileBucketTier.getTierDescription());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucketTier.getTierValue())) {
            stmt.setLong(index++, Long.valueOf(carrierProfileBucketTier.getTierValue()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucketTier.getTierBehavior())) {
            stmt.setString(index, carrierProfileBucketTier.getTierBehavior());
        } else {
            stmt.setNull(index, Types.VARCHAR);
        }
    }

    private void setInsertCarrierProfileChildBucketStmtQueryParameters(PreparedStatement stmt, TracfoneOneCarrierProfileChildBucket carrierProfileChildBucket) throws SQLException {
        int index = 1;
        stmt.setLong(index++, Long.valueOf(carrierProfileChildBucket.getObjId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileChildBucket.getProfileId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileChildBucket.getServicePlanId()));
        stmt.setString(index++, carrierProfileChildBucket.getChildPlanId());
        stmt.setString(index++, carrierProfileChildBucket.getBucketId());
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getBucketValue())) {
            stmt.setLong(index++, Long.valueOf(carrierProfileChildBucket.getBucketValue()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getUnitOfMeasure())) {
            stmt.setString(index++, carrierProfileChildBucket.getUnitOfMeasure());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getBucketType())) {
            stmt.setString(index++, carrierProfileChildBucket.getBucketType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getBucketGroup())) {
            stmt.setString(index++, carrierProfileChildBucket.getBucketGroup());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getBucketRequirement())) {
            stmt.setString(index++, carrierProfileChildBucket.getBucketRequirement());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        stmt.setString(index++, carrierProfileChildBucket.getActiveFlag().toUpperCase());
        stmt.setString(index++, carrierProfileChildBucket.getAutoRenewFlag());
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getAutoRenewFrequency())) {
            stmt.setString(index++, carrierProfileChildBucket.getAutoRenewFrequency());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getAutoRenewValue())) {
            stmt.setString(index++, carrierProfileChildBucket.getAutoRenewValue());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getAutoRenewDay())) {
            stmt.setString(index++, carrierProfileChildBucket.getAutoRenewDay());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getBenefitType())) {
            stmt.setString(index++, carrierProfileChildBucket.getBenefitType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getHideUbiFlag())) {
            stmt.setString(index++, carrierProfileChildBucket.getHideUbiFlag());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getPriority())) {
            stmt.setLong(index, Long.valueOf(carrierProfileChildBucket.getPriority()));
        } else {
            stmt.setNull(index, Types.INTEGER);
        }
    }

    private void setInsertCarrierProfileChildBucketTierQueryParameters(PreparedStatement stmt, TracfoneOneCarrierProfileChildTier carrierProfileChildTier) throws SQLException {
        int index = 1;
        stmt.setLong(index++, Long.valueOf(carrierProfileChildTier.getObjId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileChildTier.getCarrierProfileChildObjId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileChildTier.getUsageTierId()));
        if (!StringUtils.isNullOrEmpty(carrierProfileChildTier.getTierDescription())) {
            stmt.setString(index++, carrierProfileChildTier.getTierDescription());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildTier.getTierValue())) {
            stmt.setLong(index++, Long.valueOf(carrierProfileChildTier.getTierValue()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildTier.getTierBehavior())) {
            stmt.setString(index, carrierProfileChildTier.getTierBehavior());
        } else {
            stmt.setNull(index, Types.VARCHAR);
        }
    }

    private String getNextSequence(Connection con, String queryString, String seqId) throws SQLException {
        String sequenceId = null;
        PreparedStatement stmt = con.prepareStatement(queryString);
        ResultSet resultSet = stmt.executeQuery();

        while (resultSet.next()) {
            sequenceId = resultSet.getString(seqId);
        }

        return sequenceId;
    }

    @Override
    public List<TracfoneOneBucketList> getAllBucketList(String dbEnv) throws TracfoneOneException {
        List<TracfoneOneBucketList> tracfoneOneBucketLists = new ArrayList<>();

        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_VIEW_BUCKET_LIST);) {

            ResultSet rs = stmt.executeQuery();

            TracfoneOneBucketList tracfoneOneBucketList;
            while (rs.next()) {
                tracfoneOneBucketList = new TracfoneOneBucketList();
                tracfoneOneBucketList.setBucketId(rs.getString(1));
                tracfoneOneBucketList.setDescription(rs.getString(2));
                tracfoneOneBucketList.setActiveFlag(rs.getString(3));
                tracfoneOneBucketList.setParentShortName(rs.getString(4));
                tracfoneOneBucketLists.add(tracfoneOneBucketList);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tracfoneOneBucketLists;
    }

    private void setInLongQuery(PreparedStatement stmt, List<String> idsToBeDeleted) throws SQLException {
        int index = 1;
        for (String id : idsToBeDeleted) {
            stmt.setLong(index++, Long.valueOf(id));
        }
    }

    private String buildInClause(String deleteQuery, int size) {
        StringBuilder query = new StringBuilder(deleteQuery);
        if (size != 1) {
            int index = 1;
            while (index < size) {
                query.append(", ?");
                index++;
            }
        }
        query.append(")");

        return query.toString();
    }

    @Override
    public TFOneGeneralResponse updateIgBucket(TracfoneOneBucket tfOneIgBucket, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneIgBucket.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_IG_BUCKETS);) {

            setIgBucketQueryParameters(stmt, tfOneIgBucket, true);

            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update IG Bucket", "Updated IG Bucket " + tfOneIgBucket, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneIgBucket.getBucketId());
    }

    private void setUpdateQueryParams(PreparedStatement stmt, TracfoneOneCarrierProfileBucket tfCarrierProfileBucket) throws SQLException {
        int index = 1;
        stmt.setString(index++, tfCarrierProfileBucket.getBucketId());
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getUnitOfMeasure())) {
            stmt.setString(index++, tfCarrierProfileBucket.getUnitOfMeasure());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getBucketType())) {
            stmt.setString(index++, tfCarrierProfileBucket.getBucketType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getBucketGroup())) {
            stmt.setString(index++, tfCarrierProfileBucket.getBucketGroup());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        stmt.setString(index++, tfCarrierProfileBucket.getActiveFlag().toUpperCase());
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getBucketRequirement())) {
            stmt.setString(index++, tfCarrierProfileBucket.getBucketRequirement());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        stmt.setString(index++, tfCarrierProfileBucket.getAutoRenewFlag());
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getAutoRenewFrequency())) {
            stmt.setString(index++, tfCarrierProfileBucket.getAutoRenewFrequency());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getAutoRenewValue())) {
            stmt.setString(index++, tfCarrierProfileBucket.getAutoRenewValue());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getAutoRenewDay())) {
            stmt.setString(index++, tfCarrierProfileBucket.getAutoRenewDay());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getBenefitType())) {
            stmt.setString(index++, tfCarrierProfileBucket.getBenefitType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getBucketValue())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierProfileBucket.getBucketValue()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getSuiDisplayType())) {
            stmt.setString(index++, tfCarrierProfileBucket.getSuiDisplayType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getPriority())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierProfileBucket.getPriority()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getHideUbiFlag())) {
            stmt.setString(index++, tfCarrierProfileBucket.getHideUbiFlag());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        stmt.setLong(index, Long.valueOf(tfCarrierProfileBucket.getObjectId()));
    }

    private void setUpdateQueryParams(PreparedStatement stmt, TracfoneOneCarrierProfileBucketTier tfOneCarrierProfileBucketTier) throws SQLException {
        int index = 1;
        stmt.setLong(index++, Long.valueOf(tfOneCarrierProfileBucketTier.getUsageTierId()));
        if (!StringUtils.isNullOrEmpty(tfOneCarrierProfileBucketTier.getTierDescription())) {
            stmt.setString(index++, tfOneCarrierProfileBucketTier.getTierDescription());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneCarrierProfileBucketTier.getTierValue())) {
            stmt.setLong(index++, Long.valueOf(tfOneCarrierProfileBucketTier.getTierValue()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfOneCarrierProfileBucketTier.getTierBehavior())) {
            stmt.setString(index++, tfOneCarrierProfileBucketTier.getTierBehavior());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        stmt.setString(index, tfOneCarrierProfileBucketTier.getObjId());
    }

    @Override
    public List<TFOneBucket> searchIgBuckets(TracfoneOneSearchBucketModel tfOneSearchBucketModel) throws TracfoneOneException {
        List<TFOneBucket> buckets = new ArrayList<>();
        List<String> ratePlanNames = tfOneSearchBucketModel.getRatePlanNames();
        String searchQuery = buildInClause(TRACFONE_SEARCH_IG_BUCKETS, ratePlanNames.size());
        try (Connection con = dbControllerEJB.getDataSource(tfOneSearchBucketModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(searchQuery);) {
            int index = 1;
            for (String ratePlan : ratePlanNames) {
                stmt.setString(index++, ratePlan);
            }

            try (ResultSet rs = stmt.executeQuery();) {
                TFOneBucket tfOneBucket;
                while (rs.next()) {
                    tfOneBucket = new TFOneBucket();
                    tfOneBucket.setBucketId(rs.getString(BUCKET_ID));
                    tfOneBucket.setMeasureUnit(rs.getString("MEASURE_UNIT"));
                    tfOneBucket.setBucketDesc(rs.getString("BUCKET_DESC"));
                    tfOneBucket.setBucketType(rs.getString(BUCKET_TYPE));
                    tfOneBucket.setRatePlan(rs.getString("RATE_PLAN"));
                    tfOneBucket.setActiveFlag(rs.getString(ACTIVE_FLAG));
                    tfOneBucket.setSuiDisplayType(rs.getString("SUI_DISPLAY_TYPE"));
                    tfOneBucket.setBucketGroup(rs.getString(BUCKET_GROUP));
                    tfOneBucket.setPriorityGroup(rs.getString("PRIORITY_GROUP"));
                    buckets.add(tfOneBucket);
                }
            }
        } catch (NamingException | SQLException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return buckets;
    }

    @Override
    public List<TFOneCarrierProfileBucket> searchCarrierProfileBuckets(TracfoneOneSearchBucketModel tfOneSearchBucketModel) throws TracfoneOneException {
        List<TFOneCarrierProfileBucket> buckets = new ArrayList<>();
        String searchQuery = getSearchCpBucketQuery(TRACFONE_SEARCH_CP_BUCKETS,
                tfOneSearchBucketModel.getServicePlanIds(),
                tfOneSearchBucketModel.getProfileIds(),
                null);
        try (Connection con = dbControllerEJB.getDataSource(tfOneSearchBucketModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(searchQuery);) {

            int index = 1;
            List<String> ids = tfOneSearchBucketModel.getProfileIds();
            if (null != ids && !ids.isEmpty()) {
                stmt.setLong(index++, Long.valueOf(ids.get(0)));
            }
            ids = tfOneSearchBucketModel.getServicePlanIds();
            if (null != ids && !ids.isEmpty()) {
                stmt.setLong(index++, Long.valueOf(ids.get(0)));
            }

            try (ResultSet rs = stmt.executeQuery();) {
                TFOneCarrierProfileBucket tfOneCarrierProfileBucket;
                while (rs.next()) {
                    tfOneCarrierProfileBucket = setCarrierProfileBucket(rs);
                    tfOneCarrierProfileBucket.setTfOneCarrierProfileBucketTiers(getAllTiersForCarrierProfileBucket(con, tfOneCarrierProfileBucket.getObjid()));
                    buckets.add(tfOneCarrierProfileBucket);
                }
            }
        } catch (NamingException | SQLException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return buckets;
    }

    private String getSearchCpBucketQuery(String searchQuery, List<String> servicePlanIds, List<String> profileIds, String childPlanId) {
        String query = null;
        StringBuilder builder = new StringBuilder(searchQuery);
        if (null != profileIds && !profileIds.isEmpty()) {
            builder.append("PROFILE_ID = ?");
            builder.append(AND);
        }
        if (null != servicePlanIds && !servicePlanIds.isEmpty()) {
            builder.append("SERVICE_PLAN_ID = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(childPlanId)) {
            builder.append("CHILD_PLAN_ID = ?");
            builder.append(AND);
        }
        // if the query ends with AND, there is something to search with. Otherwise, there is no need to 
        // fire an update query
        if (builder.lastIndexOf(AND) != -1) {
            query = builder.substring(0, builder.lastIndexOf(AND));
            query = query + " ORDER BY BUCKET_REQUIREMENT, BUCKET_ID";
        }

        return query;
    }

    private TFOneCarrierProfileBucket setCarrierProfileBucket(ResultSet rs) throws SQLException {
        TFOneCarrierProfileBucket tfOneCarrierProfileBucket = new TFOneCarrierProfileBucket();
        tfOneCarrierProfileBucket.setObjid(rs.getString(OBJID));
        tfOneCarrierProfileBucket.setProfileId(rs.getString("PROFILE_ID"));
        tfOneCarrierProfileBucket.setServicePlanId(rs.getString("SERVICE_PLAN_ID"));
        tfOneCarrierProfileBucket.setBucketId(rs.getString(BUCKET_ID));
        tfOneCarrierProfileBucket.setBucketValue(rs.getString("BUCKET_VALUE"));
        tfOneCarrierProfileBucket.setUnitOfMeasure(rs.getString("UNIT_OF_MEASURE"));
        tfOneCarrierProfileBucket.setBucketType(rs.getString(BUCKET_TYPE));
        tfOneCarrierProfileBucket.setBucketGroup(rs.getString(BUCKET_GROUP));
        tfOneCarrierProfileBucket.setBucketRequirement(rs.getString("BUCKET_REQUIREMENT"));
        tfOneCarrierProfileBucket.setActiveFlag(rs.getString(ACTIVE_FLAG));
        tfOneCarrierProfileBucket.setAutoRenewFlag(rs.getString("AUTO_RENEW_FLAG"));
        tfOneCarrierProfileBucket.setAutoRenewFrequency(rs.getString("AUTO_RENEW_FREQUENCY"));
        tfOneCarrierProfileBucket.setAutoRenewValue(rs.getString("AUTO_RENEW_VALUE"));
        tfOneCarrierProfileBucket.setAutoRenewDay(rs.getString("AUTO_RENEW_DAY"));
        tfOneCarrierProfileBucket.setBenefitType(rs.getString(BENEFIT_TYPE));
        tfOneCarrierProfileBucket.setSuiDisplayType(rs.getString("SUI_DISPLAY_TYPE"));
        tfOneCarrierProfileBucket.setPriority(rs.getString("PRIORITY"));
        tfOneCarrierProfileBucket.setHideUbiFlag(rs.getString("HIDE_UBI_FLAG"));
        return tfOneCarrierProfileBucket;
    }

    private List<TFOneCarrierProfileBucketTier> getAllTiersForCarrierProfileBucket(Connection con, String objid) throws SQLException {
        List<TFOneCarrierProfileBucketTier> bucketTiers = new ArrayList<>();
        try (PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_TIERS_FOR_BUCKET);) {
            stmt.setLong(1, Long.valueOf(objid));
            try (ResultSet rs = stmt.executeQuery();) {

                TFOneCarrierProfileBucketTier tfOneCarrierProfileBucketTier;
                while (rs.next()) {
                    tfOneCarrierProfileBucketTier = setCarrierProfileBucketTier(rs);
                    bucketTiers.add(tfOneCarrierProfileBucketTier);
                }
            }
        }
        return bucketTiers;
    }

    private TFOneCarrierProfileBucketTier setCarrierProfileBucketTier(ResultSet rs) throws SQLException {
        TFOneCarrierProfileBucketTier tfOneCarrierProfileBucketTier = new TFOneCarrierProfileBucketTier();
        tfOneCarrierProfileBucketTier.setObjId(rs.getString(OBJID));
        tfOneCarrierProfileBucketTier.setCarrierProfileBucketsObjId(rs.getString("CARRIER_PROFILE_BUCKETS_OBJID"));
        tfOneCarrierProfileBucketTier.setUsageTierId(rs.getString("USAGE_TIER_ID"));
        tfOneCarrierProfileBucketTier.setTierDescription(rs.getString("TIER_DESCRIPTION"));
        tfOneCarrierProfileBucketTier.setTierValue(rs.getString("TIER_VALUE"));
        tfOneCarrierProfileBucketTier.setTierBehavior(rs.getString("TIER_BEHAVIOR"));
        return tfOneCarrierProfileBucketTier;
    }

    @Override
    public TFOneGeneralResponse deleteIgBucket(String dbEnv, String ratePlanName, List<String> idsToBeDeleted, int userId) throws TracfoneOneException {
        String deleteQuery = buildInClause(TRACFONE_DELETE_IG_BUCKETS, idsToBeDeleted.size());
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement igBucketStmt = con.prepareStatement(deleteQuery);) {

            setDeleteParam(igBucketStmt, ratePlanName, idsToBeDeleted);
            igBucketStmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete IG Bucket", "Deleted IG Bucket Ids for rate plan " + idsToBeDeleted + AND + ratePlanName, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, idsToBeDeleted.toString());
    }

    private void setDeleteParam(PreparedStatement stmt, String ratePlanName, List<String> idsToBeDeleted) throws SQLException {
        int index = 1;
        stmt.setString(index++, ratePlanName);
        for (String id : idsToBeDeleted) {
            stmt.setString(index++, id);
        }
    }

    @Override
    public List<TFOneCarrierProfileChildBucket> searchCarrierProfileChildBuckets(TracfoneOneSearchBucketModel tfOneSearchBucketModel) throws TracfoneOneException {
        List<TFOneCarrierProfileChildBucket> buckets = new ArrayList<>();
        String searchQuery = getSearchCpBucketQuery(TRACFONE_SEARCH_CHILD_BUCKET,
                tfOneSearchBucketModel.getServicePlanIds(),
                tfOneSearchBucketModel.getProfileIds(),
                tfOneSearchBucketModel.getChildPlanId());
        try (Connection con = dbControllerEJB.getDataSource(tfOneSearchBucketModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(searchQuery);) {

            int index = 1;
            List<String> ids = tfOneSearchBucketModel.getProfileIds();
            if (null != ids && !ids.isEmpty()) {
                stmt.setLong(index++, Long.valueOf(ids.get(0)));
            }
            ids = tfOneSearchBucketModel.getServicePlanIds();
            if (null != ids && !ids.isEmpty()) {
                stmt.setLong(index++, Long.valueOf(ids.get(0)));
            }
            if (!StringUtils.isNullOrEmpty(tfOneSearchBucketModel.getChildPlanId())) {
                stmt.setString(index++, tfOneSearchBucketModel.getChildPlanId());
            }

            try (ResultSet rs = stmt.executeQuery();) {
                TFOneCarrierProfileChildBucket tfOneCarrierProfileChildBucket;
                while (rs.next()) {
                    tfOneCarrierProfileChildBucket = setCarrierProfileChildBucket(rs);
                    tfOneCarrierProfileChildBucket.setTfOneCarrierProfileChildTiers(getAllTiersForCarrierProfileChildBucket(con, tfOneCarrierProfileChildBucket.getObjId()));
                    buckets.add(tfOneCarrierProfileChildBucket);
                }
            }
        } catch (NamingException | SQLException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return buckets;
    }

    private TFOneCarrierProfileChildBucket setCarrierProfileChildBucket(ResultSet rs) throws SQLException {
        TFOneCarrierProfileChildBucket tfOneCarrierProfileChildBucket = new TFOneCarrierProfileChildBucket();
        tfOneCarrierProfileChildBucket.setObjId(rs.getString(OBJID));
        tfOneCarrierProfileChildBucket.setProfileId(rs.getString("PROFILE_ID"));
        tfOneCarrierProfileChildBucket.setServicePlanId(rs.getString("SERVICE_PLAN_ID"));
        tfOneCarrierProfileChildBucket.setChildPlanId(rs.getString("CHILD_PLAN_ID"));
        tfOneCarrierProfileChildBucket.setBucketId(rs.getString(BUCKET_ID));
        tfOneCarrierProfileChildBucket.setBucketValue(rs.getString("BUCKET_VALUE"));
        tfOneCarrierProfileChildBucket.setUnitOfMeasure(rs.getString("UNIT_OF_MEASURE"));
        tfOneCarrierProfileChildBucket.setBucketType(rs.getString(BUCKET_TYPE));
        tfOneCarrierProfileChildBucket.setBucketGroup(rs.getString(BUCKET_GROUP));
        tfOneCarrierProfileChildBucket.setBucketRequirement(rs.getString("BUCKET_REQUIREMENT"));
        tfOneCarrierProfileChildBucket.setActiveFlag(rs.getString(ACTIVE_FLAG));
        tfOneCarrierProfileChildBucket.setAutoRenewFlag(rs.getString("AUTO_RENEW_FLAG"));
        tfOneCarrierProfileChildBucket.setAutoRenewFrequency(rs.getString("AUTO_RENEW_FREQUENCY"));
        tfOneCarrierProfileChildBucket.setAutoRenewValue(rs.getString("AUTO_RENEW_VALUE"));
        tfOneCarrierProfileChildBucket.setAutoRenewDay(rs.getString("AUTO_RENEW_DAY"));
        tfOneCarrierProfileChildBucket.setBenefitType(rs.getString(BENEFIT_TYPE));
        tfOneCarrierProfileChildBucket.setPriority(rs.getString("PRIORITY"));
        tfOneCarrierProfileChildBucket.setHideUbiFlag(rs.getString("HIDE_UBI_FLAG"));
        return tfOneCarrierProfileChildBucket;
    }

    private List<TFOneCarrierProfileChildTier> getAllTiersForCarrierProfileChildBucket(Connection con, String objid) throws SQLException {
        List<TFOneCarrierProfileChildTier> bucketTiers = new ArrayList<>();
        try (PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_TIERS_FOR_CHILD_BUCKET);) {
            stmt.setLong(1, Long.valueOf(objid));
            try (ResultSet rs = stmt.executeQuery();) {

                TFOneCarrierProfileChildTier tfOneCarrierProfileChildTier;
                while (rs.next()) {
                    tfOneCarrierProfileChildTier = setCarrierProfileChildTier(rs);
                    bucketTiers.add(tfOneCarrierProfileChildTier);
                }
            }
        }
        return bucketTiers;
    }

    private TFOneCarrierProfileChildTier setCarrierProfileChildTier(ResultSet rs) throws SQLException {
        TFOneCarrierProfileChildTier tfOneCarrierProfileChildTier = new TFOneCarrierProfileChildTier();
        tfOneCarrierProfileChildTier.setObjId(rs.getString(OBJID));
        tfOneCarrierProfileChildTier.setCarrierProfileChildObjId(rs.getString("CARRIER_PROFILE_CHILD_OBJID"));
        tfOneCarrierProfileChildTier.setUsageTierId(rs.getString("USAGE_TIER_ID"));
        tfOneCarrierProfileChildTier.setTierDescription(rs.getString("TIER_DESCRIPTION"));
        tfOneCarrierProfileChildTier.setTierValue(rs.getString("TIER_VALUE"));
        tfOneCarrierProfileChildTier.setTierBehavior(rs.getString("TIER_BEHAVIOR"));
        return tfOneCarrierProfileChildTier;
    }

    @Override
    public List<TFOneCarrierProfileBucket> insertCarrierProfileBuckets(List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets, int userId) throws TracfoneOneException {
        String carrierProfileBucketId = null;
        List<TFOneCarrierProfileBucket> buckets = new ArrayList<>();
        TFOneCarrierProfileBucket tfOneCarrierProfileBucket;
        try (Connection con = dbControllerEJB.getDataSource(tfCarrierProfileBuckets.get(0).getDbEnv()).getConnection();
             PreparedStatement carrierProfileBucketStmt = con.prepareStatement(TRACFONE_INSERT_CARRIER_PROFILE_BUCKET);
             PreparedStatement carrierProfileBucketTierStmt = con.prepareStatement(TRACFONE_INSERT_BUCKET_TIER);) {
            LOGGER.info("Number of Carrier Profile Buckets to be added is " + tfCarrierProfileBuckets.size());
            for (TracfoneOneCarrierProfileBucket tfCarrierProfileBucket : tfCarrierProfileBuckets) {
                carrierProfileBucketId = getNextSequence(con, TRACFONE_CARRIER_PROFILE_BUCKET_SEQ_STMT, "CARRIER_PROFILE_BUCKETID_SEQ");
                tfCarrierProfileBucket.setObjectId(carrierProfileBucketId);
                setInsertCarrierProfileBucketStmtQueryParameters(carrierProfileBucketStmt, tfCarrierProfileBucket);
                carrierProfileBucketStmt.execute();
                if (!tfCarrierProfileBucket.getTracfoneOneCarrierProfileBucketTiers().isEmpty()) {
                    for (TracfoneOneCarrierProfileBucketTier carrierProfileBucketTier : tfCarrierProfileBucket.getTracfoneOneCarrierProfileBucketTiers()) {
                        // Get the carrier profile bucket tier id from the sequence
                        carrierProfileBucketTier.setObjId(getNextSequence(con, TRACFONE_BUCKET_TIER_SEQ_STMT, "BUCKET_TIERID_SEQ"));
                        carrierProfileBucketTier.setCarrierProfileBucketsObjId(carrierProfileBucketId);
                        setInsertCarrierProfileBucketTierQueryParameters(carrierProfileBucketTierStmt, carrierProfileBucketTier);
                        carrierProfileBucketTierStmt.addBatch();
                    }
                    int[] tierCount = carrierProfileBucketTierStmt.executeBatch();
                    if (tierCount != null) {
                        LOGGER.info("Number of bucket tiers added " + tierCount.length);
                    }
                }
                tfOneCarrierProfileBucket = setCarrierProfileBucketResponse(tfCarrierProfileBucket);
                buckets.add(tfOneCarrierProfileBucket);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId,
                    "Insert Carrier Profile Buckets and Tiers",
                    "Inserted Carrier Profile Buckets and Tiers " + tfCarrierProfileBuckets,
                    null);
            tracfoneAuditEvent.fire(audit);
        }
        return buckets;
    }

    private TFOneCarrierProfileBucket setCarrierProfileBucketResponse(TracfoneOneCarrierProfileBucket tfCarrierProfileBucket) {
        TFOneCarrierProfileBucket tfOneCarrierProfileBucket = new TFOneCarrierProfileBucket();
        tfOneCarrierProfileBucket.setObjid(tfCarrierProfileBucket.getObjectId());
        tfOneCarrierProfileBucket.setProfileId(tfCarrierProfileBucket.getProfileId());
        tfOneCarrierProfileBucket.setServicePlanId(tfCarrierProfileBucket.getServicePlanId());
        tfOneCarrierProfileBucket.setBucketId(tfCarrierProfileBucket.getBucketId());
        tfOneCarrierProfileBucket.setBucketValue(tfCarrierProfileBucket.getBucketValue());
        tfOneCarrierProfileBucket.setUnitOfMeasure(tfCarrierProfileBucket.getUnitOfMeasure());
        tfOneCarrierProfileBucket.setBucketType(tfCarrierProfileBucket.getBucketType());
        tfOneCarrierProfileBucket.setBucketGroup(tfCarrierProfileBucket.getBucketGroup());
        tfOneCarrierProfileBucket.setBucketRequirement(tfCarrierProfileBucket.getBucketRequirement());
        tfOneCarrierProfileBucket.setActiveFlag(tfCarrierProfileBucket.getActiveFlag());
        tfOneCarrierProfileBucket.setAutoRenewFlag(tfCarrierProfileBucket.getAutoRenewFlag());
        tfOneCarrierProfileBucket.setAutoRenewFrequency(tfCarrierProfileBucket.getAutoRenewFrequency());
        tfOneCarrierProfileBucket.setAutoRenewValue(tfCarrierProfileBucket.getAutoRenewValue());
        tfOneCarrierProfileBucket.setAutoRenewDay(tfCarrierProfileBucket.getAutoRenewDay());
        tfOneCarrierProfileBucket.setBenefitType(tfCarrierProfileBucket.getBenefitType());
        tfOneCarrierProfileBucket.setSuiDisplayType(tfCarrierProfileBucket.getSuiDisplayType());
        tfOneCarrierProfileBucket.setPriority(tfCarrierProfileBucket.getPriority());
        tfOneCarrierProfileBucket.setHideUbiFlag(tfCarrierProfileBucket.getHideUbiFlag());
        tfOneCarrierProfileBucket.setTfOneCarrierProfileBucketTiers(setCarrierProfileBucketTierResponse(tfCarrierProfileBucket.getTracfoneOneCarrierProfileBucketTiers()));
        return tfOneCarrierProfileBucket;
    }

    private List<TFOneCarrierProfileBucketTier> setCarrierProfileBucketTierResponse(List<TracfoneOneCarrierProfileBucketTier> tracfoneOneCarrierProfileBucketTiers) {
        List<TFOneCarrierProfileBucketTier> tfCarrierProfileBucketTiers = new ArrayList<>();
        TFOneCarrierProfileBucketTier tfCarrierProfileChildTier;
        for (TracfoneOneCarrierProfileBucketTier tfOneCarrierProfileChildTier : tracfoneOneCarrierProfileBucketTiers) {
            tfCarrierProfileChildTier = new TFOneCarrierProfileBucketTier();
            tfCarrierProfileChildTier.setObjId(tfOneCarrierProfileChildTier.getObjId());
            tfCarrierProfileChildTier.setTierBehavior(tfOneCarrierProfileChildTier.getTierBehavior());
            tfCarrierProfileChildTier.setTierDescription(tfOneCarrierProfileChildTier.getTierDescription());
            tfCarrierProfileChildTier.setUsageTierId(tfOneCarrierProfileChildTier.getUsageTierId());
            tfCarrierProfileChildTier.setCarrierProfileBucketsObjId(tfOneCarrierProfileChildTier.getCarrierProfileBucketsObjId());
            tfCarrierProfileChildTier.setTierValue(tfOneCarrierProfileChildTier.getTierValue());
            tfCarrierProfileBucketTiers.add(tfCarrierProfileChildTier);
        }
        return tfCarrierProfileBucketTiers;
    }

    @Override
    public TFOneGeneralResponse updateCarrierProfileBucket(TracfoneOneCarrierProfileBucket tfCarrierProfileBucket, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfCarrierProfileBucket.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CARRIER_PROFILE_BUCKET);) {
            setUpdateQueryParams(stmt, tfCarrierProfileBucket);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Carrier Profile Bucket", "Updated Carrier Profile Bucket object " + tfCarrierProfileBucket, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfCarrierProfileBucket.getObjectId());
    }

    @Override
    public TFOneGeneralResponse deleteCarrierProfileBuckets(String dbEnv, List<String> idsToBeDeleted, int userId) throws TracfoneOneException {
        String bucketQuery = buildInClause(TRACFONE_DELETE_CARRIER_PROFILE_BUCKET, idsToBeDeleted.size());
        String tierQuery = buildInClause(TRACFONE_DELETE_BUCKET_TIER, idsToBeDeleted.size());
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement carrierProfileBucketStmt = con.prepareStatement(bucketQuery);
             PreparedStatement carrierProfileBucketTierStmt = con.prepareStatement(tierQuery);) {

            setInLongQuery(carrierProfileBucketTierStmt, idsToBeDeleted);
            carrierProfileBucketTierStmt.executeQuery();

            setInLongQuery(carrierProfileBucketStmt, idsToBeDeleted);
            carrierProfileBucketStmt.executeQuery();

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId,
                    "Delete Carrier Profile Buckets and Tiers",
                    "Deleted Carrier Profild Bucket Ids " + idsToBeDeleted, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, idsToBeDeleted.toString());
    }

    @Override
    public TFOneGeneralResponse updateCarrierProfileBucketTier(TracfoneOneCarrierProfileBucketTier tfCarrierProfileBucketTier, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfCarrierProfileBucketTier.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_BUCKET_TIER)) {
            setUpdateQueryParams(stmt, tfCarrierProfileBucketTier);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Carrier Profile Bucket Tier", "Updated Carrier Profile Bucket Tier object " + tfCarrierProfileBucketTier, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfCarrierProfileBucketTier.getObjId());
    }

    @Override
    public TFOneGeneralResponse deleteCarrierProfileBucketTier(TracfoneOneCarrierProfileBucketTier tfCarrierProfileBucketTier, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfCarrierProfileBucketTier.getDbEnv()).getConnection();
             PreparedStatement carrierProfileBucketTierStmt = con.prepareStatement(TRACFONE_DELETE_BUCKET_TIER_BY_OBJID);) {
            carrierProfileBucketTierStmt.setString(1, tfCarrierProfileBucketTier.getObjId());
            carrierProfileBucketTierStmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Carrier Profile Bucket Tier", "Deleted Carrier Profile Bucket Tier objId " + tfCarrierProfileBucketTier.getObjId(), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfCarrierProfileBucketTier.getObjId());
    }

    @Override
    public List<TFOneCarrierProfileChildBucket> insertCarrierProfileChildBuckets(List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets, int userId) throws TracfoneOneException {
        String carrierProfileChildBucketId = null;
        List<TFOneCarrierProfileChildBucket> buckets = new ArrayList<>();
        TFOneCarrierProfileChildBucket tfOneCarrierProfileChildBucket;
        try (Connection con = dbControllerEJB.getDataSource(tfCarrierProfileChildBuckets.get(0).getDbEnv()).getConnection();
             PreparedStatement carrierProfileChildBucketStmt = con.prepareStatement(TRACFONE_INSERT_CHILD_BUCKET);
             PreparedStatement carrierProfileChildBucketTierStmt = con.prepareStatement(TRACFONE_INSERT_CHILD_BUCKET_TIER);) {

            LOGGER.info("Number of Carrier Profile Child Buckets to be added is " + tfCarrierProfileChildBuckets.size());
            for (TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket : tfCarrierProfileChildBuckets) {
                carrierProfileChildBucketId = getNextSequence(con, TRACFONE_CHILD_BUCKET_SEQ_STMT, "CHILD_BUCKETID_SEQ");
                tfCarrierProfileChildBucket.setObjId(carrierProfileChildBucketId);
                setInsertCarrierProfileChildBucketStmtQueryParameters(carrierProfileChildBucketStmt, tfCarrierProfileChildBucket);
                carrierProfileChildBucketStmt.execute();
                if (!tfCarrierProfileChildBucket.getTracfoneOneCarrierProfileChildTiers().isEmpty()) {
                    for (TracfoneOneCarrierProfileChildTier carrierProfileChildTier : tfCarrierProfileChildBucket.getTracfoneOneCarrierProfileChildTiers()) {
                        carrierProfileChildTier.setObjId(getNextSequence(con, TRACFONE_CHILD_BUCKET_TIER_SEQ_STMT, "CHILD_BUCKET_TIERID_SEQ"));
                        carrierProfileChildTier.setCarrierProfileChildObjId(carrierProfileChildBucketId);
                        setInsertCarrierProfileChildBucketTierQueryParameters(carrierProfileChildBucketTierStmt, carrierProfileChildTier);
                        carrierProfileChildBucketTierStmt.addBatch();
                    }
                    int[] tierCount = carrierProfileChildBucketTierStmt.executeBatch();
                    if (tierCount != null) {
                        LOGGER.info("Number of bucket tiers added " + tierCount.length);
                    }
                }
                tfOneCarrierProfileChildBucket = setCarrierProfileChildBucketResponse(tfCarrierProfileChildBucket);
                buckets.add(tfOneCarrierProfileChildBucket);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId,
                    "Insert Carrier Profile Child Buckets and Tiers",
                    "Inserted Carrier Profile Child Buckets and Tiers " + tfCarrierProfileChildBuckets,
                    null);
            tracfoneAuditEvent.fire(audit);
        }
        return buckets;
    }

    private TFOneCarrierProfileChildBucket setCarrierProfileChildBucketResponse(TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket) {
        TFOneCarrierProfileChildBucket tfOneCarrierProfileChildBucket = new TFOneCarrierProfileChildBucket();
        tfOneCarrierProfileChildBucket.setObjId(tfCarrierProfileChildBucket.getObjId());
        tfOneCarrierProfileChildBucket.setProfileId(tfCarrierProfileChildBucket.getProfileId());
        tfOneCarrierProfileChildBucket.setServicePlanId(tfCarrierProfileChildBucket.getServicePlanId());
        tfOneCarrierProfileChildBucket.setChildPlanId(tfCarrierProfileChildBucket.getChildPlanId());
        tfOneCarrierProfileChildBucket.setBucketId(tfCarrierProfileChildBucket.getBucketId());
        tfOneCarrierProfileChildBucket.setBucketValue(tfCarrierProfileChildBucket.getBucketValue());
        tfOneCarrierProfileChildBucket.setUnitOfMeasure(tfCarrierProfileChildBucket.getUnitOfMeasure());
        tfOneCarrierProfileChildBucket.setBucketType(tfCarrierProfileChildBucket.getBucketType());
        tfOneCarrierProfileChildBucket.setBucketGroup(tfCarrierProfileChildBucket.getBucketGroup());
        tfOneCarrierProfileChildBucket.setBucketRequirement(tfCarrierProfileChildBucket.getBucketRequirement());
        tfOneCarrierProfileChildBucket.setActiveFlag(tfCarrierProfileChildBucket.getActiveFlag());
        tfOneCarrierProfileChildBucket.setAutoRenewFlag(tfCarrierProfileChildBucket.getAutoRenewFlag());
        tfOneCarrierProfileChildBucket.setAutoRenewFrequency(tfCarrierProfileChildBucket.getAutoRenewFrequency());
        tfOneCarrierProfileChildBucket.setAutoRenewValue(tfCarrierProfileChildBucket.getAutoRenewValue());
        tfOneCarrierProfileChildBucket.setAutoRenewDay(tfCarrierProfileChildBucket.getAutoRenewDay());
        tfOneCarrierProfileChildBucket.setBenefitType(tfCarrierProfileChildBucket.getBenefitType());
        tfOneCarrierProfileChildBucket.setPriority(tfCarrierProfileChildBucket.getPriority());
        tfOneCarrierProfileChildBucket.setHideUbiFlag(tfCarrierProfileChildBucket.getHideUbiFlag());
        tfOneCarrierProfileChildBucket.setTfOneCarrierProfileChildTiers(setCarrierProfileChildBucketTierResponse(tfCarrierProfileChildBucket.getTracfoneOneCarrierProfileChildTiers()));
        return tfOneCarrierProfileChildBucket;
    }

    private List<TFOneCarrierProfileChildTier> setCarrierProfileChildBucketTierResponse(List<TracfoneOneCarrierProfileChildTier> tracfoneOneCarrierProfileChildTiers) {
        List<TFOneCarrierProfileChildTier> tfCarrierProfileChildTiers = new ArrayList<>();
        TFOneCarrierProfileChildTier tfCarrierProfileChildTier;
        for (TracfoneOneCarrierProfileChildTier tfOneCarrierProfileChildTier : tracfoneOneCarrierProfileChildTiers) {
            tfCarrierProfileChildTier = new TFOneCarrierProfileChildTier();
            tfCarrierProfileChildTier.setObjId(tfOneCarrierProfileChildTier.getObjId());
            tfCarrierProfileChildTier.setTierBehavior(tfOneCarrierProfileChildTier.getTierBehavior());
            tfCarrierProfileChildTier.setTierDescription(tfOneCarrierProfileChildTier.getTierDescription());
            tfCarrierProfileChildTier.setUsageTierId(tfOneCarrierProfileChildTier.getUsageTierId());
            tfCarrierProfileChildTier.setCarrierProfileChildObjId(tfOneCarrierProfileChildTier.getCarrierProfileChildObjId());
            tfCarrierProfileChildTier.setTierValue(tfOneCarrierProfileChildTier.getTierValue());
            tfCarrierProfileChildTiers.add(tfCarrierProfileChildTier);
        }
        return tfCarrierProfileChildTiers;
    }

    @Override
    public TFOneGeneralResponse updateCarrierProfileChildBucket(TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfCarrierProfileChildBucket.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CHILD_BUCKET);) {
            setUpdateQueryParamsForChildBuckets(stmt, tfCarrierProfileChildBucket);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Carrier Profile Child Bucket", "Updated Carrier Profile Child Bucket object " + tfCarrierProfileChildBucket, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfCarrierProfileChildBucket.getObjId());
    }

    private void setUpdateQueryParamsForChildBuckets(PreparedStatement stmt, TracfoneOneCarrierProfileChildBucket tfCarrierProfileBucket) throws SQLException {
        int index = 1;
        stmt.setString(index++, tfCarrierProfileBucket.getChildPlanId());
        stmt.setString(index++, tfCarrierProfileBucket.getBucketId());
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getUnitOfMeasure())) {
            stmt.setString(index++, tfCarrierProfileBucket.getUnitOfMeasure());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getBucketType())) {
            stmt.setString(index++, tfCarrierProfileBucket.getBucketType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getBucketGroup())) {
            stmt.setString(index++, tfCarrierProfileBucket.getBucketGroup());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        stmt.setString(index++, tfCarrierProfileBucket.getActiveFlag().toUpperCase());
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getBucketRequirement())) {
            stmt.setString(index++, tfCarrierProfileBucket.getBucketRequirement());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        stmt.setString(index++, tfCarrierProfileBucket.getAutoRenewFlag());
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getAutoRenewFrequency())) {
            stmt.setString(index++, tfCarrierProfileBucket.getAutoRenewFrequency());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getAutoRenewValue())) {
            stmt.setString(index++, tfCarrierProfileBucket.getAutoRenewValue());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getAutoRenewDay())) {
            stmt.setString(index++, tfCarrierProfileBucket.getAutoRenewDay());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getPriority())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierProfileBucket.getPriority()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getBucketValue())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierProfileBucket.getBucketValue()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getBenefitType())) {
            stmt.setString(index++, tfCarrierProfileBucket.getBenefitType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileBucket.getHideUbiFlag())) {
            stmt.setString(index++, tfCarrierProfileBucket.getHideUbiFlag());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        stmt.setLong(index, Long.valueOf(tfCarrierProfileBucket.getObjId()));
    }

    @Override
    public TFOneGeneralResponse deleteCarrierProfileChildBuckets(String dbEnv, List<String> idsToBeDeleted, int userId) throws TracfoneOneException {
        String bucketQuery = buildInClause(TRACFONE_DELETE_CHILD_BUCKET, idsToBeDeleted.size());
        String tierQuery = buildInClause(TRACFONE_DELETE_CHILD_BUCKET_TIER, idsToBeDeleted.size());
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement carrierProfileChildBucketStmt = con.prepareStatement(bucketQuery);
             PreparedStatement carrierProfileChildTierStmt = con.prepareStatement(tierQuery);) {

            setInLongQuery(carrierProfileChildTierStmt, idsToBeDeleted);
            carrierProfileChildTierStmt.executeQuery();

            setInLongQuery(carrierProfileChildBucketStmt, idsToBeDeleted);
            carrierProfileChildBucketStmt.executeQuery();

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId,
                    "Delete Carrier Profile Child Buckets and Tiers",
                    "Deleted Carrier Profild Child Bucket Ids " + idsToBeDeleted,
                    null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, idsToBeDeleted.toString());
    }

    @Override
    public TFOneGeneralResponse updateCarrierProfileChildBucketTier(TracfoneOneCarrierProfileChildTier tfCarrierProfileChildBucketTier, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfCarrierProfileChildBucketTier.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CHILD_BUCKET_TIER);) {
            setUpdateQueryParamsForChildTier(stmt, tfCarrierProfileChildBucketTier);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Carrier Profile Child Bucket Tier", "Updated Carrier Profile Child Bucket Tier object " + tfCarrierProfileChildBucketTier, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfCarrierProfileChildBucketTier.getObjId());
    }

    private void setUpdateQueryParamsForChildTier(PreparedStatement stmt, TracfoneOneCarrierProfileChildTier tfCarrierProfileChildBucketTier) throws SQLException {
        int index = 1;
        stmt.setLong(index++, Long.valueOf(tfCarrierProfileChildBucketTier.getUsageTierId()));
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileChildBucketTier.getTierDescription())) {
            stmt.setString(index++, tfCarrierProfileChildBucketTier.getTierDescription());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileChildBucketTier.getTierValue())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierProfileChildBucketTier.getTierValue()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierProfileChildBucketTier.getTierBehavior())) {
            stmt.setString(index++, tfCarrierProfileChildBucketTier.getTierBehavior());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        stmt.setString(index, tfCarrierProfileChildBucketTier.getObjId());
    }

    @Override
    public TFOneGeneralResponse deleteCarrierProfileChildBucketTier(TracfoneOneCarrierProfileChildTier tfCarrierProfileChildTier, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfCarrierProfileChildTier.getDbEnv()).getConnection();
             PreparedStatement carrierProfileChildTierStmt = con.prepareStatement(TRACFONE_DELETE_CHILD_BUCKET_TIER_BY_OBJID);) {
            carrierProfileChildTierStmt.setString(1, tfCarrierProfileChildTier.getObjId());
            carrierProfileChildTierStmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Carrier Profile Child Bucket Tier", "Deleted Carrier Profile Child Bucket Tier objId " + tfCarrierProfileChildTier.getObjId(), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfCarrierProfileChildTier.getObjId());
    }

    @Override
    public TFOneGeneralResponse deleteAllBucketsAndTiers(TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneSearchBucketModel.getDbEnv()).getConnection();
             PreparedStatement carrierProfileBucketStmt = con.prepareStatement(TRACFONE_DELETE_ALL_BUCKETS);
             PreparedStatement carrierProfileBucketTierStmt = con.prepareStatement(TRACFONE_DELETE_ALL_BUCKET_TIERS);
             PreparedStatement carrierProfileChildBucketStmt = con.prepareStatement(TRACFONE_DELETE_ALL_CHILD_BUCKETS);
             PreparedStatement carrierProfileChildTierStmt = con.prepareStatement(TRACFONE_DELETE_ALL_CHILD_BUCKET_TIERS);) {

            String servicePlanId = tracfoneOneSearchBucketModel.getServicePlanIds().get(0);
            String profileId = tracfoneOneSearchBucketModel.getProfileIds().get(0);
            setDeleteBucketParams(carrierProfileBucketTierStmt, servicePlanId, profileId);
            setDeleteBucketParams(carrierProfileBucketStmt, servicePlanId, profileId);
            setDeleteBucketParams(carrierProfileChildTierStmt, servicePlanId, profileId);
            setDeleteBucketParams(carrierProfileChildBucketStmt, servicePlanId, profileId);

            carrierProfileBucketTierStmt.executeQuery();
            carrierProfileBucketStmt.executeQuery();
            carrierProfileChildTierStmt.executeQuery();
            carrierProfileChildBucketStmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId,
                    "Delete Carrier Profile Bucket, Tiers, Child Buckets and Tiers",
                    "Deleted Carrier Profile Buckets & Child Buckets by service plan id " + tracfoneOneSearchBucketModel.getServicePlanIds()
                            + "and profile id " + tracfoneOneSearchBucketModel.getProfileIds(), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneSearchBucketModel.getProfileIds().get(0));
    }

    private void setDeleteBucketParams(PreparedStatement stmt, String servicePlanId, String profileId) throws SQLException {
        stmt.setString(1, servicePlanId);
        stmt.setString(2, profileId);
    }

    @Override
    public TFOneGeneralResponse updateAllBucketsWithProfileId(TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneSearchBucketModel.getDbEnv()).getConnection();
             PreparedStatement carrierProfileBucketStmt = con.prepareStatement(TRACFONE_UPDATE_ALL_BUCKET);
             PreparedStatement carrierProfileChildBucketStmt = con.prepareStatement(TRACFONE_UPDATE_ALL_CHILD_BUCKET);) {
            setBucketParamForUpdate(carrierProfileBucketStmt, tracfoneOneSearchBucketModel);
            carrierProfileBucketStmt.executeUpdate();
            setBucketParamForUpdate(carrierProfileChildBucketStmt, tracfoneOneSearchBucketModel);
            carrierProfileChildBucketStmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update all Carrier Profile Buckets",
                    "Updated Carrier Profile Buckets profile id  " + tracfoneOneSearchBucketModel.getProfileIds(), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneSearchBucketModel.getProfileIds().get(0));
    }

    @Override
    public List<TFOneRatePlan> getIgBucketRatePlans(String dbEnv) throws TracfoneOneException {
        List<TFOneRatePlan> tfRatePlans = new ArrayList<>();
        TFOneRatePlan tfOneRatePlan;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_IG_BUCKET_RATE_PLANS);
             ResultSet resultSet = stmt.executeQuery();) {
            while (resultSet.next()) {
                tfOneRatePlan = new TFOneRatePlan();
                tfOneRatePlan.setObjId(resultSet.getString(OBJID));
                tfOneRatePlan.setRatePlanName(resultSet.getString("X_RATE_PLAN"));
                tfRatePlans.add(tfOneRatePlan);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfRatePlans;
    }

    @Override
    public List<String> getBucketListByBucketIds(Set<String> bucketIds, String dbEnv) throws TracfoneOneException {
        List<String> existingBucketIds = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(buildInClause(TRACFONE_GET_BUCKET_LIST_BY_BUCKET_IDS, bucketIds.size()));) {
            int index = 1;
            for (String bucketId : bucketIds) {
                stmt.setString(index++, bucketId);
            }
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    existingBucketIds.add(resultSet.getString(BUCKET_ID));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return existingBucketIds;
    }

    @Override
    public void insertBucketList(Collection<TracfoneOneBucketList> bucketLists, int userId) throws TracfoneOneException {
        LOGGER.info("bucket lists to be added " + bucketLists.size());
        try (Connection con = dbControllerEJB.getDataSource(bucketLists.iterator().next().getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_BUCKET_LIST);) {
            for (TracfoneOneBucketList bucketList : bucketLists) {
                stmt.setString(1, bucketList.getBucketId());
                stmt.setString(2, bucketList.getDescription());
                stmt.setString(3, bucketList.getActiveFlag());
                stmt.setString(4, bucketList.getParentShortName());
                stmt.addBatch();
            }
            int[] count = stmt.executeBatch();
            LOGGER.info("bucket lists added " + count);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Bucket List", "Inserted Bucket List Object " + bucketLists, null);
            tracfoneAuditEvent.fire(audit);
        }
    }

    private void setBucketParamForUpdate(PreparedStatement stmt, TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel) throws SQLException {
        stmt.setString(1, tracfoneOneSearchBucketModel.getProfileIds().get(0));
        stmt.setString(2, tracfoneOneSearchBucketModel.getServicePlanIds().get(0));
        stmt.setString(3, tracfoneOneSearchBucketModel.getOldProfileId());
    }

    @Override
    public TFOneGeneralResponse updateBucketList(TracfoneOneBucketList tfOneBucketList, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneBucketList.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_BUCKET_LIST);) {

            setBucketListQueryParameters(stmt, tfOneBucketList, true);

            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Bucket List", "Updated Bucket List" + tfOneBucketList, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneBucketList.getBucketId());
    }

    private void setBucketListQueryParameters(PreparedStatement stmt, TracfoneOneBucketList tfOneBucketList, boolean isUpdate) throws SQLException {
        int index = 1;
        if (isUpdate) {
            stmt.setString(index++, tfOneBucketList.getDescription());
        } else {
            if (!StringUtils.isNullOrEmpty(tfOneBucketList.getDescription())) {
                stmt.setString(index++, "%" + tfOneBucketList.getDescription().toUpperCase() + "%");
            }
        }
        if (!StringUtils.isNullOrEmpty(tfOneBucketList.getActiveFlag())) {
            stmt.setString(index++, tfOneBucketList.getActiveFlag());
        }
        if (!StringUtils.isNullOrEmpty(tfOneBucketList.getParentShortName())) {
            stmt.setString(index++, tfOneBucketList.getParentShortName());
        }
        if (!StringUtils.isNullOrEmpty(tfOneBucketList.getBucketId())) {
            stmt.setString(index, tfOneBucketList.getBucketId());
        }
    }

    @Override
    public List<TFOneBucketList> searchBucketList(TracfoneOneBucketList tracfoneOneBucketList) throws TracfoneOneException {
        List<TFOneBucketList> tfOneBucketLists = new ArrayList<>();
        TFOneBucketList tfOneBucketList;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneBucketList.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchProfileStatement(tracfoneOneBucketList));) {
            setBucketListQueryParameters(stmt, tracfoneOneBucketList, false);

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneBucketList = new TFOneBucketList();
                    tfOneBucketList.setBucketId(resultSet.getString(BUCKET_ID));
                    tfOneBucketList.setDescription(resultSet.getString("DESCRIPTION"));
                    tfOneBucketList.setActiveFlag(resultSet.getString(ACTIVE_FLAG));
                    tfOneBucketList.setParentShortName(resultSet.getString("PARENT_SHORT_NAME"));
                    tfOneBucketLists.add(tfOneBucketList);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneBucketLists;
    }


    private String getSearchProfileStatement(TracfoneOneBucketList tracfoneOneBucketList) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_BUCKET_LIST);
        if (!StringUtils.isNullOrEmpty(tracfoneOneBucketList.getDescription())) {
            builder.append("UPPER(DESCRIPTION) LIKE ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneBucketList.getActiveFlag())) {
            builder.append("ACTIVE_FLAG = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneBucketList.getParentShortName())) {
            builder.append("PARENT_SHORT_NAME = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneBucketList.getBucketId())) {
            builder.append("BUCKET_ID = ?");
            builder.append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        return searchQuery;
    }

    @Override
    public TFOneGeneralResponse deleteBucketList(TracfoneOneBucketList tracfoneOneBucketList, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneBucketList.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_BUCKET_LIST);) {
            stmt.setString(1, tracfoneOneBucketList.getBucketId());
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Bucket List", "Deleted Bucket List Id " + tracfoneOneBucketList.getBucketId(), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneBucketList.getBucketId());
    }

    @Override
    public long checkBucketListDependencies(TracfoneOneBucketList tracfoneOneBucketList) throws TracfoneOneException {
        long count = 0;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneBucketList.getDbEnv()).getConnection();) {
            PreparedStatement stmt = con.prepareStatement(TRACFONE_COUNT_BUCKET_LIST_DEPENDENCIES);
            stmt.setString(1, tracfoneOneBucketList.getBucketId());
            stmt.setString(2, tracfoneOneBucketList.getBucketId());
            stmt.setString(3, tracfoneOneBucketList.getBucketId());
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    count = count + resultSet.getLong(1);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        LOGGER.info("Total number of Buckets that are associated to this Bucket Id : " + count);
        return count;
    }

    @Override
    public boolean validateBucketIdExist(TracfoneOneBucketList tracfoneOneBucketList) throws TracfoneOneException {
        boolean bucketIdExists = false;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneBucketList.getDbEnv()).getConnection();) {
            int count = 0;
            try (PreparedStatement stmt = con.prepareStatement(TRACFONE_DUPLICATE_BUCKET_ID_CHECK);) {
                stmt.setString(1, tracfoneOneBucketList.getBucketId());
                try (ResultSet resultSet = stmt.executeQuery();) {
                    LOGGER.info("What am I searching for? " + tracfoneOneBucketList);
                    while (resultSet.next()) {
                        count = resultSet.getInt(1);
                        LOGGER.info("How many bucket ids have been found? " + count);
                    }
                }
            }
            if (count > 0) {
                bucketIdExists = true;
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return bucketIdExists;
    }

    @Override
    public TFOneCarrierProfileBucket getBucketDetails(TracfoneOneBucketList tracfoneOneBucketList) throws TracfoneOneException {
        TFOneCarrierProfileBucket tfOneCarrierProfileBucket = new TFOneCarrierProfileBucket();
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneBucketList.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_BUCKET_DETAILS);) {
            stmt.setString(1,tracfoneOneBucketList.getBucketId());
            stmt.setString(2,tracfoneOneBucketList.getParentShortName());
            stmt.setString(3,tracfoneOneBucketList.getProfileId());
            stmt.setString(4,tracfoneOneBucketList.getServicePlanId());
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneCarrierProfileBucket = new TFOneCarrierProfileBucket();
                    tfOneCarrierProfileBucket.setBucketId(resultSet.getString(BUCKET_ID));
                    tfOneCarrierProfileBucket.setBucketType(resultSet.getString(BUCKET_TYPE));
                    tfOneCarrierProfileBucket.setBucketGroup(resultSet.getString(BUCKET_GROUP));
                    tfOneCarrierProfileBucket.setBenefitType(resultSet.getString(BENEFIT_TYPE));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneCarrierProfileBucket;
    }

}
