package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.List;

public class TracfoneOneSearchServicePlanModel {
    private String dbEnv;
    private String carrierName;
    private String servicePlanId;
    private String featureName;
    private String featureRequirement;
    private String profileId;
    private String profileDesc;
    private String bucketId;
    private String bucketRequirement;
    private String rpExtensionId;
    private boolean legacy;
    private List<String> brands;
    private List<String> ratePlans;
    private List<String> carrierFeatureColumns;
    private List<TracfoneOneCarrierFeature> selectedCarrierFeatures;

    public TracfoneOneSearchServicePlanModel() {
        carrierFeatureColumns = new ArrayList<>();
        brands = new ArrayList<>();
        ratePlans = new ArrayList<>();
        selectedCarrierFeatures = new ArrayList<>();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public List<String> getBrands() {
        return brands;
    }

    public void setBrands(List<String> brands) {
        this.brands = brands;
    }

    public List<String> getRatePlans() {
        return ratePlans;
    }

    public void setRatePlans(List<String> ratePlans) {
        this.ratePlans = ratePlans;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public String getFeatureRequirement() {
        return featureRequirement;
    }

    public void setFeatureRequirement(String featureRequirement) {
        this.featureRequirement = featureRequirement;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getProfileDesc() {
        return profileDesc;
    }

    public void setProfileDesc(String profileDesc) {
        this.profileDesc = profileDesc;
    }

    public String getBucketId() {
        return bucketId;
    }

    public void setBucketId(String bucketId) {
        this.bucketId = bucketId;
    }

    public String getBucketRequirement() {
        return bucketRequirement;
    }

    public void setBucketRequirement(String bucketRequirement) {
        this.bucketRequirement = bucketRequirement;
    }

    public String getRpExtensionId() {
        return rpExtensionId;
    }

    public void setRpExtensionId(String rpExtensionId) {
        this.rpExtensionId = rpExtensionId;
    }

    public boolean isLegacy() { return legacy; }

    public void setLegacy(boolean legacy) { this.legacy = legacy; }

    public List<String> getCarrierFeatureColumns() {
        return carrierFeatureColumns;
    }

    public void setCarrierFeatureColumns(List<String> carrierFeatureColumns) { this.carrierFeatureColumns = carrierFeatureColumns; }

    public List<TracfoneOneCarrierFeature> getSelectedCarrierFeatures() {
        return selectedCarrierFeatures;
    }

    public void setSelectedCarrierFeatures(List<TracfoneOneCarrierFeature> selectedCarrierFeatures) { this.selectedCarrierFeatures = selectedCarrierFeatures; }

    @Override
    public String toString() {
        return "TracfoneOneSearchServicePlanModel{" +
                "dbEnv='" + dbEnv + '\'' +
                ", carrierName='" + carrierName + '\'' +
                ", servicePlanId='" + servicePlanId + '\'' +
                ", brands=" + brands +
                ", ratePlans=" + ratePlans +
                ", featureName='" + featureName + '\'' +
                ", featureRequirement='" + featureRequirement + '\'' +
                ", profileId='" + profileId + '\'' +
                ", profileDesc='" + profileDesc + '\'' +
                ", bucketId='" + bucketId + '\'' +
                ", bucketRequirement='" + bucketRequirement + '\'' +
                ", rpExtensionId='" + rpExtensionId + '\'' +
                ", legacy='" + legacy + '\'' +
                ", carrierFeatureColumns=" + carrierFeatureColumns +
                ", selectedCarrierFeatures=" + selectedCarrierFeatures +
                '}';
    }
}
