package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneTTransactionNotes;
import com.tracfone.service.model.response.TFOneGeneralResponse;

import javax.ejb.Local;

/**
 * @author Pritesh.Singh
 */
@Local
public interface TracfoneOneTTransNotesControllerLocal {
    TFOneGeneralResponse insertThrottleTransNotes(TracfoneOneTTransactionNotes tfTTransactionNotes, String userName) throws TracfoneOneException;
}
