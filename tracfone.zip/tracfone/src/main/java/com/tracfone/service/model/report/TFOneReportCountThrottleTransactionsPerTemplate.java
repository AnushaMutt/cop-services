package com.tracfone.service.model.report;

/**
 *
 * @author druiz
 */
public class TFOneReportCountThrottleTransactionsPerTemplate {

    private String carrier;
    private String time;
    private String transactionType;
    private String sumQ;
    private String sumL;
    private String sumS;
    private String sumNt;
    private String sumE;
    private String sumC;
    private String sumOther;
    private String totalTransactions;
    
    
    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getSumQ() {
        return sumQ;
    }

    public void setSumQ(String sumQ) {
        this.sumQ = sumQ;
    }

    public String getSumL() {
        return sumL;
    }

    public void setSumL(String sumL) {
        this.sumL = sumL;
    }

    public String getSumS() {
        return sumS;
    }

    public void setSumS(String sumS) {
        this.sumS = sumS;
    }

    public String getSumNT() {
        return sumNt;
    }

    public void setSumNT(String sumNT) {
        this.sumNt = sumNT;
    }

    public String getSumE() {
        return sumE;
    }

    public void setSumE(String sumE) {
        this.sumE = sumE;
    }

    public String getSumC() {
        return sumC;
    }

    public void setSumC(String sumC) {
        this.sumC = sumC;
    }

    public String getSumOther() {
        return sumOther;
    }

    public void setSumOther(String sumOther) {
        this.sumOther = sumOther;
    }

    public String getTotalTransactions() {
        return totalTransactions;
    }

    public void setTotalTransactions(String totalTransactions) {
        this.totalTransactions = totalTransactions;
    }

}
