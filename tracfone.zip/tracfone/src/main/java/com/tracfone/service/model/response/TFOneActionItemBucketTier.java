/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

/**
 *
 * @author ramartinez
 */
public class TFOneActionItemBucketTier {
    private String usageTierId;
    private String tierValue;
    private String tierBehavior;
       
    public String getUsageTierId() {
        return usageTierId;
    }

    public void setUsageTierId(String usageTierId) {
        this.usageTierId = usageTierId;
    }

    public String getTierValue() {
        return tierValue;
    }

    public void setTierValue(String tierValue) {
        this.tierValue = tierValue;
    }

    public String getTierBehavior() {
        return tierBehavior;
    }

    public void setTierBehavior(String tierBehavior) {
        this.tierBehavior = tierBehavior;
    }

    @Override
    public String toString() {
        return "TFOneActionItemBucketTier{" +
                "usageTierId='" + usageTierId + '\'' +
                ", tierValue='" + tierValue + '\'' +
                ", tierBehavior='" + tierBehavior + '\'' +
                '}';
    }
}
