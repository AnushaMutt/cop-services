/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.response;

import java.util.List;

/**
 *
 * @author Shireen Fathima
 */
public class TFOneCarrierProfileBucket {
    private String objid;
    private String profileId;
    private String bucketId;
    private String servicePlanId;
    private String activeFlag;
    private String unitOfMeasure;
    private String bucketType;
    private String bucketGroup;
    private String bucketRequirement;
    private String autoRenewFlag;
    private String autoRenewFrequency;
    private String autoRenewValue;
    private String autoRenewDay;
    private String benefitType;
    private String bucketValue;
    private String suiDisplayType;
    private String priority;
    private String hideUbiFlag;
    private List<TFOneCarrierProfileBucketTier> tfOneCarrierProfileBucketTiers;

    public String getObjid() {
        return objid;
    }

    public void setObjid(String objid) {
        this.objid = objid;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getBucketId() {
        return bucketId;
    }

    public void setBucketId(String bucketId) {
        this.bucketId = bucketId;
    }

    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public String getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(String activeFlag) {
        this.activeFlag = activeFlag;
    }

    public String getUnitOfMeasure() {
        return unitOfMeasure;
    }

    public void setUnitOfMeasure(String unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }

    public String getBucketType() {
        return bucketType;
    }

    public void setBucketType(String bucketType) {
        this.bucketType = bucketType;
    }

    public String getBucketGroup() {
        return bucketGroup;
    }

    public void setBucketGroup(String bucketGroup) {
        this.bucketGroup = bucketGroup;
    }

    public String getBucketRequirement() {
        return bucketRequirement;
    }

    public void setBucketRequirement(String bucketRequirement) {
        this.bucketRequirement = bucketRequirement;
    }

    public String getAutoRenewFlag() {
        return autoRenewFlag;
    }

    public void setAutoRenewFlag(String autoRenewFlag) {
        this.autoRenewFlag = autoRenewFlag;
    }

    public String getAutoRenewFrequency() {
        return autoRenewFrequency;
    }

    public void setAutoRenewFrequency(String autoRenewFrequency) {
        this.autoRenewFrequency = autoRenewFrequency;
    }

    public String getAutoRenewValue() {
        return autoRenewValue;
    }

    public void setAutoRenewValue(String autoRenewValue) {
        this.autoRenewValue = autoRenewValue;
    }

    public String getAutoRenewDay() {
        return autoRenewDay;
    }

    public void setAutoRenewDay(String autoRenewDay) {
        this.autoRenewDay = autoRenewDay;
    }

    public String getBenefitType() {
        return benefitType;
    }

    public void setBenefitType(String benefitType) {
        this.benefitType = benefitType;
    }

    public String getBucketValue() {
        return bucketValue;
    }

    public void setBucketValue(String bucketValue) {
        this.bucketValue = bucketValue;
    }

    public String getSuiDisplayType() {
        return suiDisplayType;
    }

    public void setSuiDisplayType(String suiDisplayType) {
        this.suiDisplayType = suiDisplayType;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getHideUbiFlag() {
        return hideUbiFlag;
    }

    public void setHideUbiFlag(String hideUbiFlag) {
        this.hideUbiFlag = hideUbiFlag;
    }

    public List<TFOneCarrierProfileBucketTier> getTfOneCarrierProfileBucketTiers() {
        return tfOneCarrierProfileBucketTiers;
    }

    public void setTfOneCarrierProfileBucketTiers(List<TFOneCarrierProfileBucketTier> tfOneCarrierProfileBucketTiers) {
        this.tfOneCarrierProfileBucketTiers = tfOneCarrierProfileBucketTiers;
    }

    @Override
    public String toString() {
        return "TFOneCarrierProfileBucket{" + "objid=" + objid + ", "
                + "profileId=" + profileId + ", "
                + "bucketId=" + bucketId + ", "
                + "servicePlanId=" + servicePlanId + ", "
                + "activeFlag=" + activeFlag + ", "
                + "unitOfMeasure=" + unitOfMeasure + ", "
                + "bucketType=" + bucketType + ", "
                + "bucketGroup=" + bucketGroup + ", "
                + "bucketRequirement=" + bucketRequirement + ", "
                + "autoRenewFlag=" + autoRenewFlag + ","
                + "autoRenewFrequency=" + autoRenewFrequency + ", "
                + "autoRenewValue=" + autoRenewValue + ", "
                + "autoRenewDay=" + autoRenewDay + ", "
                + "benefitType=" + benefitType + ", "
                + "bucketValue=" + bucketValue + ", "
                + "suiDisplayType=" + suiDisplayType + ", "
                + "priority=" + priority + ", "
                + "hideUbiFlag=" + hideUbiFlag + ", "
                + "tfOneCarrierProfileBucketTiers=" + tfOneCarrierProfileBucketTiers + '}';
    }
    
    
}
