/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Table sa.x_rp_extension_config
 *
 * @author Nidhi Mantri
 */
public class TFOneRatePlanExtensionConfig {

    String objid;
    String profileId;
    String profileDescription;
    String featureName;
    String featureValue;
    String featureRequirement;
    String toggleFlag;
    String notes;
    String displaySUIFlag;
    String restrictSUIFlag;
    String dbEnv;
    String rowNum;
    Map<String, List<String>> errorMessages;

    public TFOneRatePlanExtensionConfig() {
        errorMessages = new HashMap<>();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjid() {
        return objid;
    }

    public void setObjid(String objid) {
        this.objid = objid;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getProfileDescription() {
        return profileDescription;
    }

    public void setProfileDescription(String profileDescription) {
        this.profileDescription = profileDescription;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public String getFeatureValue() {
        return featureValue;
    }

    public void setFeatureValue(String featureValue) {
        this.featureValue = featureValue;
    }

    public String getFeatureRequirement() {
        return featureRequirement;
    }

    public void setFeatureRequirement(String featureRequirement) {
        this.featureRequirement = featureRequirement;
    }

    public String getToggleFlag() {
        return toggleFlag;
    }

    public void setToggleFlag(String toggleFlag) {
        this.toggleFlag = toggleFlag;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getDisplaySUIFlag() {
        return displaySUIFlag;
    }

    public void setDisplaySUIFlag(String displaySUIFlag) {
        this.displaySUIFlag = displaySUIFlag;
    }

    public String getRestrictSUIFlag() {
        return restrictSUIFlag;
    }

    public void setRestrictSUIFlag(String restrictSUIFlag) {
        this.restrictSUIFlag = restrictSUIFlag;
    }

    public String getRowNum() {
        return rowNum;
    }

    public void setRowNum(String rowNum) {
        this.rowNum = rowNum;
    }

    public Map<String, List<String>> getErrorMessages() {
        return errorMessages;
    }

    public void setErrorMessages(Map<String, List<String>> errorMessages) {
        this.errorMessages = errorMessages;
    }

    @Override
    public String toString() {
        return "TFOneRatePlanExtensionConfig{" + "objid=" + objid + ", "
                + "profileId=" + profileId + ", "
                + "profileDescription=" + profileDescription + ", "
                + "featureName=" + featureName + ", "
                + "featureValue=" + featureValue + ", "
                + "featureRequirement=" + featureRequirement + ", "
                + "toggleFlag=" + toggleFlag + ", "
                + "notes=" + notes + ", "
                + "displaySUIFlag=" + displaySUIFlag + ", "
                + "restrictSUIFlag=" + restrictSUIFlag + ", "
                + "rowNum=" + rowNum + ", "
                + "errorMessages=" + errorMessages + ", "
                + "dbEnv=" + dbEnv + '}';
    }

}
