package com.tracfone.service.model.report;

public class TFOneReportAllPCRFFailures {
    private String pcrfParentName;
    private String sourceSystem;
    private String xTimeSegment;
    private String totalTransCount;
    private String failureCount;
    private String orderType;
    private String percentFailure;
    private String sumF;

    public String getPcrfParentName() {
        return pcrfParentName;
    }

    public void setPcrfParentName(String pcrfParentName) {
        this.pcrfParentName = pcrfParentName;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getxTimeSegment() {
        return xTimeSegment;
    }

    public void setxTimeSegment(String xTimeSegment) {
        this.xTimeSegment = xTimeSegment;
    }

    public String getTotalTransCount() {
        return totalTransCount;
    }

    public void setTotalTransCount(String totalTransCount) {
        this.totalTransCount = totalTransCount;
    }

    public String getFailureCount() {
        return failureCount;
    }

    public void setFailureCount(String failureCount) {
        this.failureCount = failureCount;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }


    public String getPercentFailure() {
        return percentFailure;
    }

    public void setPercentFailure(String percentFailure) {
        this.percentFailure = percentFailure;
    }

    public String getSumF() {
        return sumF;
    }

    public void setSumF(String sumF) {
        this.sumF = sumF;
    }

    @Override
    public String toString() {
        return "TFOneReportAllPCRFFailures{" +
                "pcrfParentName='" + pcrfParentName + '\'' +
                ", sourceSystem='" + sourceSystem + '\'' +
                ", xTimeSegment='" + xTimeSegment + '\'' +
                ", totalTransCount='" + totalTransCount + '\'' +
                ", failureCount='" + failureCount + '\'' +
                ", orderType='" + orderType + '\'' +
                ", percentFailure='" + percentFailure + '\'' +
                ", sumF='" + sumF + '\'' +
                '}';
    }
}
