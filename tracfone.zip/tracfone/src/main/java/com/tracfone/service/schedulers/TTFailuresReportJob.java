package com.tracfone.service.schedulers;

import com.google.gson.Gson;
import com.tracfone.service.model.event.TracfoneOneReportRequest;
import com.tracfone.service.model.report.TFOneReportAllTTFailures;
import com.tracfone.service.report.workers.throttle.AllTTFailuresWorkerBean;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Singleton
public class TTFailuresReportJob {

    @EJB
    AllTTFailuresWorkerBean ttFailuresWorkerBean;

    @Inject
    private Event<TracfoneOneReportRequest> tracfoneOneConstantReportEvent;

    private static final Logger LOGGER = LogManager.getLogger(TTFailuresReportJob.class);

//    @Schedule(second = "*/55", minute = "*", hour = "*", persistent = false)
    public void runAllTTFailuresReport() {
        try {
            List<TFOneReportAllTTFailures> ttFailures = new ArrayList<>();
//            List<TFOneReportAllTTFailures> ttFailures = ttFailuresWorkerBean.runAllTTFailuresReport();
            if (!ttFailures.isEmpty()) {
                Gson gson = new Gson();
                TracfoneOneReportRequest reportRequest = new TracfoneOneReportRequest();
                reportRequest.setJsonResponse(gson.toJson(ttFailures));
                reportRequest.setReportName(TracfoneOneConstantReport.TRACFONE_REPORTNAME_ALL_TT_FAILURES);
                tracfoneOneConstantReportEvent.fire(reportRequest);
            } else {
                LOGGER.info("AllTTFailuresWorkerBean returned an empty response.");
            }
        } catch (Exception ex) {
            LOGGER.error("TT Failures report could not be retrieved because of an exception", ex);
        }
    }
}
