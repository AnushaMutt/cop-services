/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.request;

import java.util.List;
import java.util.Map;

/**
 * @author druiz
 */
public class TracfoneOneCarrierSubscriber {
    private String min;
    private String sim;
    private String carrier;
    private String carrierUrl;
    private List<Map<String, String>> additionalFields;
    private String accountNumber;
    private boolean querySimV2;
    private boolean bulkInquiry;

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getSim() {
        return sim;
    }

    public void setSim(String sim) {
        this.sim = sim;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getCarrierUrl() {
        return carrierUrl;
    }

    public void setCarrierUrl(String carrierUrl) {
        this.carrierUrl = carrierUrl;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public boolean isQuerySimV2() {
        return querySimV2;
    }

    public void setQuerySimV2(boolean querySimV2) {
        this.querySimV2 = querySimV2;
    }

    public boolean isBulkInquiry() {
        return bulkInquiry;
    }

    public void setBulkInquiry(boolean bulkInquiry) {
        this.bulkInquiry = bulkInquiry;
    }

    public List<Map<String, String>> getAdditionalFields() {
        return additionalFields;
    }

    public void setAdditionalFields(List<Map<String, String>> additionalFields) {
        this.additionalFields = additionalFields;
    }
}
