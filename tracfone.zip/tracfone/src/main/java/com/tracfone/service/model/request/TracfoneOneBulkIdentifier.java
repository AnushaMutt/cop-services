package com.tracfone.service.model.request;

public class TracfoneOneBulkIdentifier {
    private String min;
    private String esn;
    private String iccid;
    private String zipCode;
    private String esnHex;
    private Integer ratePlanProfileId;
    private Integer servicePlanId;
    private String ratePlan;
    private Integer carrFeat;
    private String eSimFlag;

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getEsn() {
        return esn;
    }

    public void setEsn(String esn) {
        this.esn = esn;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getEsnHex() {
        return esnHex;
    }

    public void setEsnHex(String esnHex) {
        this.esnHex = esnHex;
    }

    public Integer getRatePlanProfileId() {
        return ratePlanProfileId;
    }

    public void setRatePlanProfileId(Integer ratePlanProfileId) {
        this.ratePlanProfileId = ratePlanProfileId;
    }

    public Integer getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(Integer servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public String getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(String ratePlan) {
        this.ratePlan = ratePlan;
    }

    public Integer getCarrFeat() {
        return carrFeat;
    }

    public void setCarrFeat(Integer carrFeat) {
        this.carrFeat = carrFeat;
    }

    public String geteSimFlag() {
        return eSimFlag;
    }

    public void seteSimFlag(String eSimFlag) {
        this.eSimFlag = eSimFlag;
    }

    @Override
    public String toString() {
        return "TracfoneOneBulkIdentifier{" +
                "min='" + min + '\'' +
                ", esn='" + esn + '\'' +
                ", iccid='" + iccid + '\'' +
                ", zipCode='" + zipCode + '\'' +
                ", esnHex='" + esnHex + '\'' +
                ", ratePlanProfileId=" + ratePlanProfileId +
                ", servicePlanId=" + servicePlanId +
                ", ratePlan='" + ratePlan + '\'' +
                ", carrFeat=" + carrFeat +
                ", eSimFlag='" + eSimFlag + '\'' +
                '}';
    }
}
