package com.tracfone.service.controller;

import com.tracfone.ejb.entity.TFTransactionArchive;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneGroup;
import com.tracfone.service.model.request.TracfoneOneUserProfile;
import com.tracfone.service.model.response.TFOneAdminAction;
import com.tracfone.service.model.response.TFOneAdminGroup;
import com.tracfone.service.model.response.TFOneAdminProfile;
import com.tracfone.service.model.response.TFOneAdminRole;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneAuditHistory;
import com.tracfone.service.model.response.TFOneDatabaseEnvironment;
import com.tracfone.service.model.response.TFOneGeneralResponse;

import javax.ejb.Local;
import java.util.List;

/**
 * @author Srinivas Murthy Pulavarthy
 */
@Local
public interface TracfoneControllerLocal {

    /**
     * @param userName
     * @param userLDAPPassword
     * @return
     * @throws com.tracfone.service.exception.TracfoneOneException
     */
    TFOneAdminUser login(String userName, String userLDAPPassword) throws TracfoneOneException;

    /**
     * @param token
     * @return
     * @throws TracfoneOneException
     */
    TFOneGeneralResponse logout(String token) throws TracfoneOneException;

    /**
     * @param token
     * @return
     * @throws TracfoneOneException
     */
    TFOneAdminUser validateToken(String token) throws TracfoneOneException;

    /**
     * @param userId
     * @param requestedResource
     * @return
     * @throws TracfoneOneException
     */
    int checkAccessForRequestedResource(int userId, String requestedResource) throws TracfoneOneException;

    /**
     * @param userId
     * @return
     * @throws TracfoneOneException
     * @throws TracfoneOneAuthorizationException
     */
    List<TFOneAdminRole> getRoles(Integer userId) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * @param userId
     * @param adminUserId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    TFOneAdminRole getRole(Integer userId, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * @param adminUserId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    List<TFOneAdminUser> getAllUsers(Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * @param actionId
     * @param adminUserId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    List<TFOneAdminUser> getAllUsersWithAction(Integer actionId, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * @param userId
     * @param adminUserId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    List<TFOneAdminAction> getAllActions(Integer userId, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * Retrieves all groups that the user has. If user is root, it will return
     * all available groups.
     *
     * @param userId
     * @param adminUserId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    List<TFOneAdminGroup> getAllGroups(Integer userId, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * Retrieves all groups that the user has. If user is root, it will return
     * all available groups if boolean checkPriority is true. If false, it will
     * only return the groups that belong to the user.
     *
     * @param userId
     * @param adminUserId
     * @param checkPriority
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    List<TFOneAdminGroup> getAllGroups(Integer userId, Integer adminUserId, boolean checkPriority) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * @param groupId
     * @param adminUserId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    TFOneAdminGroup getGroup(Integer groupId, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * @param userId
     * @param adminuserId
     * @param allowRootRetrieval
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    TFOneAdminProfile getProfile(Integer userId, Integer adminuserId, boolean allowRootRetrieval) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * Delete a user Profile
     *
     * @param userId
     * @param adminUserId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    TFOneGeneralResponse deleteUserProfile(Integer userId, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * @param groupRequestModel
     * @param adminUserId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    TFOneGeneralResponse updateGroup(TracfoneOneGroup groupRequestModel, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * @param groupRequestModel
     * @param adminUserId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    TFOneGeneralResponse createGroup(TracfoneOneGroup groupRequestModel, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * @param userProfileRequestModel
     * @param adminUserId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    TFOneGeneralResponse updateUser(TracfoneOneUserProfile userProfileRequestModel, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * @param userProfileRequestModel
     * @param adminUserId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    TFOneGeneralResponse createUser(TracfoneOneUserProfile userProfileRequestModel, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException;

    /**
     * @param reportName
     * @param reportSql
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    String getMonitorReport(String reportName, String reportSql) throws TracfoneOneException;

    /**
     * @param reportName
     * @param reportSql
     * @return
     * @throws TracfoneOneException
     */
    String getMonitorGraphReport(String reportName, String reportSql) throws TracfoneOneException;

    /**
     * @param reportName
     * @param flag
     * @return
     * @throws TracfoneOneException
     */
    String getAllFailures(String reportName, boolean flag) throws TracfoneOneException;

    /**
     * @param userId
     * @return
     * @throws TracfoneOneException
     */
    List<TFOneAuditHistory> getAuditHistoryForUserId(Integer userId) throws TracfoneOneException;

    /**
     * @param userId
     * @return
     * @throws TracfoneOneException
     */
    List<TFOneDatabaseEnvironment> getDatabaseEnvironments(int userId) throws TracfoneOneException;

    /**
     * @return
     * @throws
     */
    void purgeUserAudit() throws TracfoneOneException;

    /**
     * @return
     * @throws
     */
    void purgeTFOneReport() throws TracfoneOneException;

    /**
     * @return
     * @throws
     */
    List<TFTransactionArchive> deactiveCOPTransactionArchive() throws TracfoneOneException;

    /**
     * @return
     * @throws
     */
    void purgeUserHistory() throws TracfoneOneException;

    /**
     * @return
     * @throws
     */
    void purgeUserTasks() throws TracfoneOneException;

    /**
     * @param username
     * @throws TracfoneOneException
     */
    void duplicateUserNameCheck(String username) throws TracfoneOneException;

    /**
     * @param description
     * @throws TracfoneOneException
     */
    void duplicateSignatureCheck(String description) throws TracfoneOneException;
}
