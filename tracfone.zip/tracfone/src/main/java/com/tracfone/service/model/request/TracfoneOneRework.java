/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.request;

import com.tracfone.service.model.response.TFOneAdminActionItem;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author druiz
 */
@XmlRootElement(name = "ReworkTransactionRequest")
public class TracfoneOneRework {
    
    @XmlElement(name = "searchCriteria")
    private TracfoneOneActionItemId searchCriteria;
    
    @XmlElement(name = "reworkCriteria")
    private TFOneAdminActionItem reworkCriteria;

    @XmlElement(name = "chunkSize")
    private String chunkSize;

    public TracfoneOneActionItemId getSearchCriteria() {
        return searchCriteria;
    }

    public void setSearchCriteria(TracfoneOneActionItemId searchCriteria) {
        this.searchCriteria = searchCriteria;
    }

    public TFOneAdminActionItem getReworkCriteria() {
        return reworkCriteria;
    }

    public void setReworkCriteria(TFOneAdminActionItem reworkCriteria) {
        this.reworkCriteria = reworkCriteria;
    }

    public String getChunkSize() {
        return chunkSize;
    }

    public void setChunkSize(String chunkSize) {
        this.chunkSize = chunkSize;
    }
}