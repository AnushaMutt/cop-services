package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * table_carrier_outage
 *
 * @author Pritesh Singh
 */
public class TracfoneOneCarrierOutage {
    private String objIds;
    private String dbEnv;
    @Digits(integer = 38, fraction = 0, message = "Obj Id must be a number")
    private String objId;
    @Size(max = 50, message = "Parent Short Name cannot have more than 50 characters")
    private String parentShortName;
    @Size(max = 50, message = "Brand cannot have more than 50 characters")
    private String brand;
    @Size(max = 50, message = "Channel cannot have more than 50 characters")
    private String channel;
    private String zipCode;
    @Size(max = 50, message = "Service Type cannot have more than 50 characters")
    private String serviceType;
    @Size(max = 50, message = "Outage Type cannot have more than 50 characters")
    private String outageType;
    private String startTime;
    private String endTime;
    @Size(max = 50, message = "Created By cannot have more than 50 characters")
    private String createdBy;
    @Size(max = 20, message = "Script Id cannot have more than 20 characters")
    private String scriptId;
    @Size(max = 100, message = "Script Text cannot have more than 100 characters")
    private String scriptText;
    @Size(max = 250, message = "Outage Description cannot have more than 250 characters")
    private String outageDescription;
    private boolean showArchivedOutage;
    private boolean validate;

    public String getObjIds() {
        return objIds;
    }

    public void setObjIds(String objIds) {
        this.objIds = objIds;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getParentShortName() {
        return parentShortName;
    }

    public void setParentShortName(String parentShortName) {
        this.parentShortName = parentShortName;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getOutageType() {
        return outageType;
    }

    public void setOutageType(String outageType) {
        this.outageType = outageType;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getScriptId() {
        return scriptId;
    }

    public void setScriptId(String scriptId) {
        this.scriptId = scriptId;
    }

    public String getScriptText() {
        return scriptText;
    }

    public void setScriptText(String scriptText) {
        this.scriptText = scriptText;
    }

    public String getOutageDescription() {
        return outageDescription;
    }

    public void setOutageDescription(String outageDescription) {
        this.outageDescription = outageDescription;
    }

    public boolean isShowArchivedOutage() {
        return showArchivedOutage;
    }

    public void setShowArchivedOutage(boolean showArchivedOutage) {
        this.showArchivedOutage = showArchivedOutage;
    }

    public boolean isValidate() {
        return validate;
    }

    public void setValidate(boolean validate) {
        this.validate = validate;
    }

    @Override
    public String toString() {
        return "TracfoneOneCarrierOutage{" +
                "objIds='" + objIds + '\'' +
                ", dbEnv='" + dbEnv + '\'' +
                ", objId='" + objId + '\'' +
                ", parentShortName='" + parentShortName + '\'' +
                ", brand='" + brand + '\'' +
                ", channel='" + channel + '\'' +
                ", zipCode='" + zipCode + '\'' +
                ", serviceType='" + serviceType + '\'' +
                ", outageType='" + outageType + '\'' +
                ", startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", scriptId='" + scriptId + '\'' +
                ", scriptText='" + scriptText + '\'' +
                ", outageDescription='" + outageDescription + '\'' +
                ", showArchivedOutage=" + showArchivedOutage +
                ", validate=" + validate +
                '}';
    }
}
