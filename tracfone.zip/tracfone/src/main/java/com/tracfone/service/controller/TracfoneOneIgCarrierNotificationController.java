package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneIGCarrierNotification;
import java.io.UnsupportedEncodingException;
import javax.ejb.Stateless;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author Gaurav.Sharma
 */
@Stateless
public class TracfoneOneIgCarrierNotificationController implements TracfoneOneIgCarrierNotficationControllerLocal {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneIgCarrierNotificationController.class);
    String UNABLE_TO_GET_CARRIER_RESPONSE =  "Unable to get carrier response";
    String CONTENT_TYPE = "Content-type";

    @Override
    public String getResponse(TracfoneOneIGCarrierNotification carrierNotification) throws TracfoneOneException, UnsupportedEncodingException {
        String httpResponse = "";
        PoolingHttpClientConnectionManager connectionManager = HttpConnectionController.getHttpConnectionPool();
        try (CloseableHttpClient client = HttpClients.custom().setConnectionManager(connectionManager)
                .setConnectionManagerShared(true).build();
                CloseableHttpResponse response = client.execute(createRequest(carrierNotification))) {
            if (response != null) {
                httpResponse = EntityUtils.toString(response.getEntity());
                LOGGER.error("response from carrier service call "+response);
            } else {
                LOGGER.error(UNABLE_TO_GET_CARRIER_RESPONSE, httpResponse);
                throw new TracfoneOneException(UNABLE_TO_GET_CARRIER_RESPONSE, httpResponse);
            }
        } catch (Exception e) {
            LOGGER.error("TF-4000", UNABLE_TO_GET_CARRIER_RESPONSE, e);
            throw new TracfoneOneException("TF-4000", UNABLE_TO_GET_CARRIER_RESPONSE, e);
        }
        return httpResponse;
    }

    private HttpUriRequest createRequest(TracfoneOneIGCarrierNotification carrierNotification) throws UnsupportedEncodingException {

        if (!StringUtils.isNullOrEmpty(carrierNotification.getRequestMethod())) {
            switch (carrierNotification.getRequestMethod()) {
                case "GET":
                    HttpGet httpGet = new HttpGet(carrierNotification.getUrl());
                    httpGet.setHeader(CONTENT_TYPE, carrierNotification.getRequestType());
                    return httpGet;
                case "POST":
                    HttpPost httpPost = new HttpPost(carrierNotification.getUrl());
                    httpPost.setHeader(CONTENT_TYPE, carrierNotification.getRequestType());
                    httpPost.setEntity(new StringEntity(carrierNotification.getRequest()));
                    return httpPost;
                case "PUT":
                    HttpPut httpPut = new HttpPut(carrierNotification.getUrl());
                    httpPut.setHeader(CONTENT_TYPE, carrierNotification.getRequestType());
                    httpPut.setEntity(new StringEntity(carrierNotification.getRequest()));
                    return httpPut;
                case "DELETE":
                    HttpDelete httpDelete = new HttpDelete(carrierNotification.getUrl());
                    httpDelete.setHeader(CONTENT_TYPE, carrierNotification.getRequestType());
                    return httpDelete;
                default:
                    return null;
            }
        } else {
            return null;
        }
    }
}
