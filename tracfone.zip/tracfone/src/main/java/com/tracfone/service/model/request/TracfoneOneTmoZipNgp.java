package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * @author Thejaswini
 */
public class TracfoneOneTmoZipNgp {
    @Size(min = 1, message = "Zip cannot be null")
    private String zip;
    @Size(min = 1, message = "NGP cannot be null")
    @Size(max = 30, message = "NGP cannot have more than 30 characters")
    private String ngp;
    @Size(min = 1, message = "NGP Name cannot be null")
    @Size(max = 255, message = "NGP Name cannot have more than 255 characters")
    private String ngpName;
    @Size(min = 1, message = "Priority cannot be null")
    @Digits(integer=38, fraction=0, message = "Priority must be a number")
    private String priority;
    private String dbEnv;
    private String oldZip;
    private String oldPriority;
    private boolean checkDuplicate;

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getNgp() {
        return ngp;
    }

    public void setNgp(String ngp) {
        this.ngp = ngp;
    }

    public String getNgpName() {
        return ngpName;
    }

    public void setNgpName(String ngpName) {
        this.ngpName = ngpName;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getOldZip() {
        return oldZip;
    }

    public void setOldZip(String oldZip) {
        this.oldZip = oldZip;
    }

    public String getOldPriority() {
        return oldPriority;
    }

    public void setOldPriority(String oldPriority) {
        this.oldPriority = oldPriority;
    }

    public boolean isCheckDuplicate() {
        return checkDuplicate;
    }

    public void setCheckDuplicate(boolean checkDuplicate) {
        this.checkDuplicate = checkDuplicate;
    }

    @Override
    public String toString() {
        return "TracfoneOneTmoZipNgp{" +
                "zip='" + zip + '\'' +
                ", ngp='" + ngp + '\'' +
                ", ngpName='" + ngpName + '\'' +
                ", priority='" + priority + '\'' +
                '}';
    }
}
