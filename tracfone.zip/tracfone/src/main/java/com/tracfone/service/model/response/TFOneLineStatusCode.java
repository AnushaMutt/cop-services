package com.tracfone.service.model.response;

public class TFOneLineStatusCode {
    private String lineStatusCode;
    private String description;

    public String getLineStatusCode() {
        return lineStatusCode;
    }

    public void setLineStatusCode(String lineStatusCode) {
        this.lineStatusCode = lineStatusCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "TFOneLineStatusCode{" +
                "lineStatusCode='" + lineStatusCode + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
