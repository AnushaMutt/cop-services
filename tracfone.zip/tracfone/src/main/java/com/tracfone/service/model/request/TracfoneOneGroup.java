
package com.tracfone.service.model.request;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author druiz
 */
@XmlRootElement(name = "UserGroup")
public class TracfoneOneGroup {
    public static final short ENABLED = 1; 
    public static final short DISABLED = 0; 
    
    @XmlElement(name = "groupId")
    private Integer groupId;
        
    @XmlElement(name = "groupName")
    private String groupName;
    
    @XmlElement(name = "groupDescription")
    private String groupDescription;
    
    @XmlElement(name = "tfActions")
    private List<TracfoneOneAction> tfActions;

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupDescription() {
        return groupDescription;
    }

    public void setGroupDescription(String groupDescription) {
        this.groupDescription = groupDescription;
    }

    public List<TracfoneOneAction> getTfActions() {
        return tfActions;
    }

    public void setTfActions(List<TracfoneOneAction> tfActions) {
        this.tfActions = tfActions;
    }

    
}
