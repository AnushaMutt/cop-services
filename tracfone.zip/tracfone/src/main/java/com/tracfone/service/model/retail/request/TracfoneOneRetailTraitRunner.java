package com.tracfone.service.model.retail.request;

public class TracfoneOneRetailTraitRunner {
    private String parentId;
    private String storeName;
    private String storeNum;
    private String zip;
    private String radius;

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getStoreNum() {
        return storeNum;
    }

    public void setStoreNum(String storeNum) {
        this.storeNum = storeNum;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getRadius() {
        return radius;
    }

    public void setRadius(String radius) {
        this.radius = radius;
    }

    @Override
    public String toString() {
        return "TracfoneOneRetailTraitRunner{" +
                "parentId='" + parentId + '\'' +
                ", storeName='" + storeName + '\'' +
                ", storeNum='" + storeNum + '\'' +
                ", zip='" + zip + '\'' +
                ", radius='" + radius + '\'' +
                '}';
    }
}
