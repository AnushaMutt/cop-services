package com.tracfone.service.controller;

import java.util.Hashtable;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;

import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author spulavarthy
 */
@Singleton
public class JmsController {

    public static final String JMS_HEADER_TRANSID = "TRANSACTION_ID";
    public static final String JMS_HEADER_MIN = "MIN";
    public static final String JMS_HEADER_ESN = "ESN";
    public static final String JMS_HEADER_APPSYSNAME = "APPLICATION_SYSTEM_NAME";
    private static Logger LOGGER = LogManager.getLogger(JmsController.class);

    @Lock(LockType.READ)
    public void sendJMS(String messageBody, String queueLink) throws Exception {

        QueueSender jmsSender = null;
        QueueSession jmsSession = null;
        QueueConnection jmsConnection = null;
        try {
            Hashtable<String, String> environmentConfigMap = new Hashtable<String, String>();
            TextMessage jmsMsg = null;
            environmentConfigMap.put(Context.PROVIDER_URL, "t3://localhost:8301");
            environmentConfigMap.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
            InitialContext initCtx = new InitialContext(environmentConfigMap);
            QueueConnectionFactory qcf = (QueueConnectionFactory) initCtx.lookup("IGConnectionFactory2");
            jmsConnection = qcf.createQueueConnection();
            jmsSession = jmsConnection.createQueueSession(false, 0);
            Queue queue = (Queue) initCtx.lookup(queueLink);
            jmsSender = jmsSession.createSender(queue);
            jmsMsg = jmsSession.createTextMessage(messageBody);
            jmsSender.send(jmsMsg);
        } catch (Exception ex) {
            LOGGER.error("Error while sending JMS :  " + ex);
        } finally {
            try {
                if (jmsSender != null) {
                    jmsSender.close();
                }
            } catch (Exception ex) {
            }

            try {
                if (jmsSession != null) {
                    jmsSession.close();
                }
            } catch (Exception ex) {
            }

            try {
                if (jmsConnection != null) {
                    jmsConnection.close();
                }
            } catch (Exception ex) {
            }
        }
    }
}
