/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.request;

import java.util.List;

/**
 *
 * @author user
 */
public class TracfoneOneSearchAdditionalModel {
    
    private String searchColumnName;
    private String searchColumnType;
    private List<String> searchValues;
    private boolean searchIsColumnNotIn;
    private boolean searchIsColumnLike;

    public boolean isSearchIsColumnNotIn() {
        return searchIsColumnNotIn;
    }

    public void setSearchIsColumnNotIn(boolean searchIsColumnNotIn) {
        this.searchIsColumnNotIn = searchIsColumnNotIn;
    }

    public boolean isSearchIsColumnLike() {
        return searchIsColumnLike;
    }

    public void setSearchIsColumnLike(boolean searchIsColumnLike) {
        this.searchIsColumnLike = searchIsColumnLike;
    }

    public String getSearchColumnName() {
        return searchColumnName;
    }

    public void setSearchColumnName(String searchColumnName) {
        this.searchColumnName = searchColumnName;
    }

    public String getSearchColumnType() {
        return searchColumnType;
    }

    public void setSearchColumnType(String searchColumnType) {
        this.searchColumnType = searchColumnType;
    }

    public List<String> getSearchValues() {
        return searchValues;
    }

    public void setSearchValues(List<String> searchValues) {
        this.searchValues = searchValues;
    }
}
