package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneIgFailLogs;
import com.tracfone.service.model.response.TFOneIGFailLogs;
import com.tracfone.service.model.response.TFOneIgFailLogSearchModel;

import javax.ejb.Local;
import java.util.List;

/**
 * @author thejaswini
 */
@Local
public interface TracfoneOneIgFailLogsActionLocal {

    TFOneIgFailLogSearchModel getIgFailLogs(TracfoneOneIgFailLogs tracfoneOneIgFailLogs) throws TracfoneOneException;

}
