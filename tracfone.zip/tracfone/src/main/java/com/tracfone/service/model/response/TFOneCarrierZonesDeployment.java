package com.tracfone.service.model.response;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Gaurav.Sharma
 */
public class TFOneCarrierZonesDeployment {

    private List<String> newZipCodes;
    private List<TFOneCarrierZones> carrierZones;
    private List<TFOneVerizonZipNPANXX> zipNPANXXs;
    private List<TFOneCarrierZones> arUsaData;
    private List<TFOneCingularMrktInfo> cingularMrktInfos;
    private List<TFOneZipMktSubMkt> zipMktSubMkts;
    private List<TFOneNextAvailable> tmoNextAvailable;

    public TFOneCarrierZonesDeployment() {
        carrierZones = new ArrayList<>();
        newZipCodes = new ArrayList<>();
        cingularMrktInfos = new ArrayList<>();
        zipNPANXXs = new ArrayList<>();
        arUsaData = new ArrayList<>();
        zipMktSubMkts = new ArrayList<>();
        tmoNextAvailable = new ArrayList<>();
    }

    public List<String> getNewZipCodes() {
        return newZipCodes;
    }

    public void setNewZipCodes(List<String> newZipCodes) {
        this.newZipCodes = newZipCodes;
    }

    public List<TFOneCarrierZones> getCarrierZones() {
        return carrierZones;
    }

    public void setCarrierZones(List<TFOneCarrierZones> carrierZones) {
        this.carrierZones = carrierZones;
    }

    public List<TFOneVerizonZipNPANXX> getZipNPANXXs() {
        return zipNPANXXs;
    }

    public void setZipNPANXXs(List<TFOneVerizonZipNPANXX> zipNPANXXs) {
        this.zipNPANXXs = zipNPANXXs;
    }

    public List<TFOneCarrierZones> getArUsaData() {
        return arUsaData;
    }

    public void setArUsaData(List<TFOneCarrierZones> arUsaData) {
        this.arUsaData = arUsaData;
    }

    public List<TFOneCingularMrktInfo> getCingularMrktInfos() {
        return cingularMrktInfos;
    }

    public void setCingularMrktInfos(List<TFOneCingularMrktInfo> cingularMrktInfos) {
        this.cingularMrktInfos = cingularMrktInfos;
    }

    public List<TFOneZipMktSubMkt> getZipMktSubMkts() {
        return zipMktSubMkts;
    }

    public void setZipMktSubMkts(List<TFOneZipMktSubMkt> zipMktSubMkts) {
        this.zipMktSubMkts = zipMktSubMkts;
    }

    public List<TFOneNextAvailable> getTmoNextAvailable() {
        return tmoNextAvailable;
    }

    public void setTmoNextAvailable(List<TFOneNextAvailable> tmoNextAvailable) {
        this.tmoNextAvailable = tmoNextAvailable;
    }

    @Override
    public String toString() {
        return "TFOneCarrierZonesDeployment{" +
                "newZipCodes=" + newZipCodes +
                ", carrierZones=" + carrierZones +
                ", zipNPANXXs=" + zipNPANXXs +
                ", arUsaData=" + arUsaData +
                ", cingularMrktInfos=" + cingularMrktInfos +
                ", zipMktSubMkts=" + zipMktSubMkts +
                ", tmoNextAvailable=" + tmoNextAvailable +
                '}';
    }
}
