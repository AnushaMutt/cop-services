/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneBucket;
import com.tracfone.service.model.request.TracfoneOneBucketList;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucketTier;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildTier;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.response.TFOneBucket;
import com.tracfone.service.model.response.TFOneBucketList;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneRatePlan;

import javax.ejb.Local;
import java.util.List;

/**
 * @author Shireen Fathima
 */
@Local
public interface TracfoneBucketControllerLocal {

    TFOneGeneralResponse insertLegacyBucket(List<TracfoneOneBucket> tfBucket, String parentShortName, int userId) throws TracfoneOneException;

    List<TracfoneOneBucketList> getAllBucketList(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse updateIgBucket(TracfoneOneBucket tfOneIgBucket, int userId) throws TracfoneOneException;

    List<TFOneBucket> searchIgBuckets(TracfoneOneSearchBucketModel tfOneSearchBucketModel) throws TracfoneOneException;

    List<TFOneCarrierProfileBucket> searchCarrierProfileBuckets(TracfoneOneSearchBucketModel tfOneSearchBucketModel) throws TracfoneOneException;

    List<TFOneCarrierProfileChildBucket> searchCarrierProfileChildBuckets(TracfoneOneSearchBucketModel tfOneSearchBucketModel) throws TracfoneOneException;

    TFOneGeneralResponse deleteIgBucket(TracfoneOneBucket tfBucket, int userId) throws TracfoneOneException;

    List<TFOneCarrierProfileBucket> insertCarrierProfileBucket(List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets, String parentShortName, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrierProfileBucket(TracfoneOneCarrierProfileBucket tfCarrierProfileBucket, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteCarrierProfileBucket(List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrierProfileBucketTier(TracfoneOneCarrierProfileBucketTier tfCarrierProfileBucketTier, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteCarrierProfileBucketTier(TracfoneOneCarrierProfileBucketTier tfCarrierProfileBucketTier, int userId) throws TracfoneOneException;

    List<TFOneCarrierProfileChildBucket> insertCarrierProfileChildBucket(List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets, String parentShortName, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrierProfileChildBucket(TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteCarrierProfileChildBucket(List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrierProfileChildBucketTier(TracfoneOneCarrierProfileChildTier tfCarrierProfileChildBucketTier, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteCarrierProfileChildBucketTier(TracfoneOneCarrierProfileChildTier tfCarrierProfileChildTier, int userId) throws TracfoneOneException;

    TFOneGeneralResponse copyAllBucketsFromProfile(TracfoneOneSearchBucketModel tfOneSearchBucketModel, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteAllBucketsAndTiers(TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateAllBucketsWithProfileId(TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel, int userId) throws TracfoneOneException;

    List<TFOneRatePlan> getIgBucketRatePlans(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse insertBucketList(List<TracfoneOneBucketList> tracfoneOneBucketLists, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateBucketList(TracfoneOneBucketList tfOneBucketList, int userId) throws TracfoneOneException;

    List<TFOneBucketList> searchBucketList(TracfoneOneBucketList tracfoneOneBucketList) throws TracfoneOneException;

    TFOneGeneralResponse deleteBucketList(TracfoneOneBucketList tracfoneOneBucketList, int userId) throws TracfoneOneException;

    TFOneCarrierProfileBucket getBucketDetails(TracfoneOneBucketList tracfoneOneBucketList) throws TracfoneOneException;

}
