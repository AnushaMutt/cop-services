package com.tracfone.service.model.request;

/**
 *
 * @author Gaurav.Sharma
 */
public class TracfoneOneIGCarrierNotification {

    private String url;
    private String request;
    private String requestMethod;
    private String requestType;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public String getRequestMethod() {
        return requestMethod;
    }

    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    @Override
    public String toString() {
        return "TracfoneOneIGCarrierNotification{" + "url=" + url + ", request=" + request + ", requestMethod=" + requestMethod + ", requestType=" + requestType + '}';
    }
}
