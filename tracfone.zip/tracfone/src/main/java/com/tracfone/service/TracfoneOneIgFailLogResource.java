package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneOneIgFailLogsControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.model.request.TracfoneOneIgFailLogs;
import com.tracfone.service.model.response.TFOneIGFailLogs;
import com.tracfone.service.model.response.TFOneIgFailLogSearchModel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.List;

/**
 * @author thejaswini
 */
@Path("iglogs")
public class TracfoneOneIgFailLogResource {
    @Context
    private SecurityContext securityContext;

    @EJB
    private TracfoneOneIgFailLogsControllerLocal tracfoneIgFailLogsController;

    private static Logger logger = LogManager.getLogger(TracfoneOneIgFailLogResource.class);

    private static Gson gson = new GsonBuilder().serializeNulls().create();

    @POST
    @Path("igfaillogs/getIgfaillogs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getIgFailLogs(TracfoneOneIgFailLogs tracfoneOneIgFailLogs) {
        TFOneIgFailLogSearchModel igFailLogs;
        try {
            igFailLogs = tracfoneIgFailLogsController.getIgFailLogs(tracfoneOneIgFailLogs);
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(igFailLogs), MediaType.APPLICATION_JSON).build();
    }

}
