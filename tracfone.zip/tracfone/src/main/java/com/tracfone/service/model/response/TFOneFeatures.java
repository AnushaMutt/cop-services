/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

import java.lang.reflect.Constructor;
import java.util.Comparator;

/**
 *
 * @author Srinivas Murthy Pulavarthy
 */
public class TFOneFeatures implements Comparable<TFOneFeatures>{

    long id;
    long profileId;
    String featureName;
    String featureValue;
    String featureRequirement;
    String toggleFlag;
    String throttleStatuCode;
    String displaySUIFlag;
    String restrictSUIFlag;
        /**
     * Converts the requirement of the feature into the values understood by IG.
     * @return Y if it is ADD, N if it is remove, empty otherwise.
     */
    public String getFeatureRequirementFlag() {
        switch (getFeatureRequirement()){
            case "ADD":
                return "Y";
            case "REM":
                return "N";
            default:
                return "";
        }
    }

    public String getThrottleStatuCode() {
        return throttleStatuCode;
    }

    public void setThrottleStatuCode(String throttleStatuCode) {
        this.throttleStatuCode = throttleStatuCode;
    }

    public String getDisplaySUIFlag() {
        return displaySUIFlag;
    }

    public void setDisplaySUIFlag(String displaySUIFlag) {
        this.displaySUIFlag = displaySUIFlag;
    }

    public String getRestrictSUIFlag() {
        return restrictSUIFlag;
    }

    public void setRestrictSUIFlag(String restrictSUIFlag) {
        this.restrictSUIFlag = restrictSUIFlag;
    }

    public String getToggleFlag() {
        return toggleFlag;
    }

    public void setToggleFlag(String toggleFlag) {
        this.toggleFlag = toggleFlag;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public String getFeatureValue() {
        return featureValue;
    }

    public void setFeatureValue(String featureValue) {
        this.featureValue = featureValue;
    }

    public String getFeatureRequirement() {
        return featureRequirement;
    }

    public void setFeatureRequirement(String featureRequirement) {
        this.featureRequirement = featureRequirement;
    }

    public long getProfileId() {
        return profileId;
    }

    public void setProfileId(long profileId) {
        this.profileId = profileId;
    }

    @Override
    public int compareTo(TFOneFeatures o) {
     return this.getFeatureRequirement().compareTo(o.getFeatureRequirement());    
    }

    @Override
    public String toString() {
        return "TFOneFeatures{" +
                "id=" + id +
                ", profileId=" + profileId +
                ", featureName='" + featureName + '\'' +
                ", featureValue='" + featureValue + '\'' +
                ", featureRequirement='" + featureRequirement + '\'' +
                ", toggleFlag='" + toggleFlag + '\'' +
                ", throttleStatuCode='" + throttleStatuCode + '\'' +
                ", displaySUIFlag='" + displaySUIFlag + '\'' +
                ", restrictSUIFlag='" + restrictSUIFlag + '\'' +
                '}';
    }
}


