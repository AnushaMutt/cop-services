/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneFeatureRequirement;
import com.tracfone.service.model.request.TracfoneOneLineStatusCode;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionConfig;
import com.tracfone.service.model.request.TracfoneOneRatePlanProfile;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneThrottleStatusCode;
import com.tracfone.service.model.request.TracfoneOneUploadProfileFeatures;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneFeatureRequirement;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneLineStatusCode;
import com.tracfone.service.model.response.TFOneRPFeatureNameList;
import com.tracfone.service.model.response.TFOneRatePlanExtensionConfig;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import com.tracfone.service.model.response.TFOneThrottleStatusCode;
import com.tracfone.service.model.response.TFOneUploadProfileFeatures;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantPlanWizard;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author Nidhi Mantri
 */
@Stateless
public class TracfoneFeatureController implements TracfoneFeatureControllerLocal, TracfoneOneConstantPlanWizard, TracfoneOneConstant {

    private static final String CANNOT_BE_BLANK = " cannot be blank.";

    private static final Logger LOGGER = LogManager.getLogger(TracfoneFeatureController.class);

    private List<String> featureRequirements;

    enum ProfileFeature {
        ROWNUM("Row Num", "rowNum"),
        FEATURENAME("Feature Name", "featureName"),
        FEATUREVALUE("Feature Value", "featureValue"),
        FEATUREREQUIREMENT("Feature Requirement", "featureRequirement"),
        DISPLAYSUIFLAG("Display SUI Flag", "displaySUIFlag"),
        TOGGLEFLAG("Toggle Flag", "toggleFlag"),
        PROFILEID("Profile Id", "profileId"),
        RESTRICTSUIFLAG("Restrict SUI Flag", "restrictSUIFlag");

        private String fieldName;
        private String propertyName;

        private ProfileFeature(String fieldName, String propertyName) {
            this.fieldName = fieldName;
            this.propertyName = propertyName;
        }

        private String getFieldName() {
            return fieldName;
        }

        private String getPropertyName() {
            return propertyName;
        }
    }

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @EJB
    TracfoneFeatureLocalAction tracfoneFeatureAction;

    @EJB
    TracfoneProfileLocalAction tracfoneProfileAction;

    @Override
    public List<TFOneRPFeatureNameList> getAllMasterFeatures(String dbEnv) throws TracfoneOneException {
        List<TFOneRPFeatureNameList> featureList = null;
        try {
            featureList = tracfoneFeatureAction.getAllMasterFeatures(dbEnv);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ALL_MASTER_FEATURE_ERROR, TRACFONE_GET_ALL_MASTER_FEATURE_ERROR_MESSAGE, ex);
        }

        return featureList;
    }

    @Override
    public TFOneGeneralResponse insertRpExtensionConfig(List<TracfoneOneRatePlanExtensionConfig> tfOneRatePlanExtensionConfigs, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        addNewFeaturesIntoMaster(tfOneRatePlanExtensionConfigs, userId);
        checkForDuplicateFeatureValue(tfOneRatePlanExtensionConfigs);
        try {
            response = tracfoneFeatureAction.insertRpExtensionConfig(tfOneRatePlanExtensionConfigs, userId, null);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_INSERT_RP_EXTENSION_CONFIG_ERROR, TRACFONE_INSERT_RP_EXTENSION_CONFIG_ERROR_MESSAGE, ex);
        }

        return response;
    }

    private void checkForDuplicateFeatureValue(List<TracfoneOneRatePlanExtensionConfig> tfOneRatePlanExtensionConfigs) throws TracfoneOneException {
        // get list of feature values from DB based on profile id. Match and check for duplicates
        Set<String> featureValues = tracfoneFeatureAction.getAllFeatureValuesByProfileId(tfOneRatePlanExtensionConfigs.get(0));
        for (TracfoneOneRatePlanExtensionConfig feature : tfOneRatePlanExtensionConfigs) {
            if (featureValues.contains(feature.getFeatureValue())) {
                throw new TracfoneOneException(TRACFONE_DUPLICATE_RP_EXTENSION_CONFIG_ERROR, TRACFONE_DUPLICATE_RP_EXTENSION_CONFIG_ERROR_MESSAGE + feature.getFeatureValue());
            } else {
                featureValues.add(feature.getFeatureValue());
            }
        }
    }

    @Override
    public List<TFOneRatePlanProfile> getAllProfileFeatures(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) throws TracfoneOneException {
        List<TFOneRatePlanProfile> profileFeatures = new ArrayList<>();
        TFOneRatePlanProfile updatedFeaturesProfile;
        try {
            updatedFeaturesProfile = new TFOneRatePlanProfile();
            updatedFeaturesProfile.setProfileId(tracfoneOneSearchProfileModel.getProfileId());
            updatedFeaturesProfile.setRpExtensionConfigs(tracfoneFeatureAction.getAllProfileFeatures(tracfoneOneSearchProfileModel));
            profileFeatures.add(updatedFeaturesProfile);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_PROFILE_FEATURE_ERROR, TRACFONE_GET_PROFILE_FEATURE_ERROR_MESSAGE, ex);
        }

        return profileFeatures;
    }

    @Override
    public TFOneGeneralResponse updateRpExtensionConfig(TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig, int userId) throws TracfoneOneException {
        List<TracfoneOneRatePlanExtensionConfig> tfOneRatePlanExtensionConfigs = new ArrayList<>();
        tfOneRatePlanExtensionConfigs.add(tfOneRpExtensionConfig);
        addNewFeaturesIntoMaster(tfOneRatePlanExtensionConfigs, userId);
        TFOneGeneralResponse response = tracfoneFeatureAction.updateRpExtensionConfig(tfOneRpExtensionConfig, userId);
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
    }

    @Override
    public TFOneGeneralResponse deleteRpExtensionConfig(TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        List<String> idToBeDeleted;
        try {
            idToBeDeleted= new ArrayList<>();
            for (String objid : tfOneRpExtensionConfig.getObjid().split(",")){
                idToBeDeleted.add(objid);
            }
            response = tracfoneFeatureAction.deleteRpExtensionConfigs(tfOneRpExtensionConfig.getDbEnv(), idToBeDeleted, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_RP_EXTENSION_CONFIG_ERROR, TRACFONE_DELETE_RP_EXTENSION_CONFIG_ERROR_MESSAGE, ex);
        }

        return response;
    }

    private void addNewFeaturesIntoMaster(List<TracfoneOneRatePlanExtensionConfig> tfOneRatePlanExtensionConfigs, int userId) throws TracfoneOneException {
        try {
            Set<String> featureNames = new HashSet<>();
            String dbEnv = tfOneRatePlanExtensionConfigs.get(0).getDbEnv();
            for (TracfoneOneRatePlanExtensionConfig profileFeature : tfOneRatePlanExtensionConfigs) {
                featureNames.add(profileFeature.getFeatureName());
            }
            LOGGER.info("Total feature names " + featureNames);
            List<String> existingFeatures = tracfoneFeatureAction.findExistingMasterFeatures(dbEnv, featureNames);
            LOGGER.info("Total existing feature names " + existingFeatures);
            featureNames.removeAll(existingFeatures);
            LOGGER.info("Total feature names to be added in DB " + featureNames);
            if (!featureNames.isEmpty()) {
                tracfoneFeatureAction.insertMasterFeature(dbEnv, featureNames, userId);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_INSERT_MASTER_FEATURE_ERROR, TRACFONE_INSERT_MASTER_FEATURE_ERROR_MESSAGE, ex);
        }
    }


    @Override
    public TFOneUploadProfileFeatures validateAndAddProfileFeatures(TracfoneOneUploadProfileFeatures tfUploadProfileFeatures, int userId) throws TracfoneOneException {
        TFOneUploadProfileFeatures tfOneUploadProfileFeatures = new TFOneUploadProfileFeatures();
        List<TracfoneOneRatePlanExtensionConfig> errorRpExtensionConfigs = tfUploadProfileFeatures.getErrorRpExtensionConfigs();
        List<TracfoneOneRatePlanExtensionConfig> successRpExtensionConfigs = tfUploadProfileFeatures.getSuccessRpExtensionConfigs();
        try {
            /* validations
             Basic bean validations
             Check for uniqueness
             Check whether profile id exists in DB*/
            LOGGER.info("Are there error records for me to validate? " + errorRpExtensionConfigs);
            if (!errorRpExtensionConfigs.isEmpty()) {
                LOGGER.info("Start validation for file upload of Profile Features");
                List<String> allFeatureValuesForDuplicateChecks = addSuccessFeatureNames(successRpExtensionConfigs);
                tfOneUploadProfileFeatures = validateFileUpload(errorRpExtensionConfigs, tfUploadProfileFeatures.getProfileId(), tfUploadProfileFeatures.getDbEnv(), allFeatureValuesForDuplicateChecks);
                LOGGER.info("End validation for file upload of Profile Features");
                // Create the success response object to set in the response object.
                List<TFOneRatePlanExtensionConfig> allSuccessRpExtensionConfigs = setResponseList(successRpExtensionConfigs);
                if (!tfOneUploadProfileFeatures.getSuccessRpExtensionConfigs().isEmpty()) {
                    allSuccessRpExtensionConfigs.addAll(tfOneUploadProfileFeatures.getSuccessRpExtensionConfigs());
                }
                tfOneUploadProfileFeatures.setSuccessRpExtensionConfigs(allSuccessRpExtensionConfigs);
            }

            /*check whether insert should be done and then just call insert
            set the objids created into the response object.*/
            if ("Y".equalsIgnoreCase(tfUploadProfileFeatures.getInsertFlag()) && tfOneUploadProfileFeatures.getErrorRpExtensionConfigs().isEmpty()) {
                LOGGER.info("Start database insertion for file upload of Profile Features " + successRpExtensionConfigs);
                insertRpExtensionConfig(successRpExtensionConfigs, userId);
                LOGGER.info("End database insertion for file upload of Profile Features");
                LOGGER.info("Start adding object ids for file upload of Profile Features");
                tfOneUploadProfileFeatures.setSuccessRpExtensionConfigs(setObjIdsForSuccessList(successRpExtensionConfigs));
                LOGGER.info("End adding object ids for file upload of Profile Features " + tfOneUploadProfileFeatures.getSuccessRpExtensionConfigs());
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_FEATURE_FILE_UPLOAD_ERROR, TRACFONE_FEATURE_FILE_UPLOAD_ERROR_MESSAGE, ex);
        }
        return tfOneUploadProfileFeatures;
    }

    private List<String> addSuccessFeatureNames(List<TracfoneOneRatePlanExtensionConfig> successRpExtensionConfigs) {
        List<String> allFeatureValuesForDuplicateChecks = new ArrayList<>();
        // add all success configs for duplicate check
        if (!successRpExtensionConfigs.isEmpty()) {
            for (TracfoneOneRatePlanExtensionConfig success : successRpExtensionConfigs) {
                allFeatureValuesForDuplicateChecks.add(success.getFeatureValue());
            }
        }
        return allFeatureValuesForDuplicateChecks;
    }

    private List<TFOneRatePlanExtensionConfig> setResponseList(List<TracfoneOneRatePlanExtensionConfig> successRpExtensionConfigs) {
        List<TFOneRatePlanExtensionConfig> successExtensionConfigs = new ArrayList<>();
        for (TracfoneOneRatePlanExtensionConfig successRpExtensionConfig : successRpExtensionConfigs) {
            successExtensionConfigs.add(createResponseObject(successRpExtensionConfig));
        }
        return successExtensionConfigs;
    }

    private TFOneUploadProfileFeatures validateFileUpload(List<TracfoneOneRatePlanExtensionConfig> rpExtensionConfigs,
                                                          String profileId,
                                                          String dbEnv,
                                                          List<String> allFeatureValuesForDuplicateChecks) throws TracfoneOneException {
        // This map will have key as the feature name and value as the response object. This will be used for duplicate checks
        List<TFOneRatePlanExtensionConfig> fullList = new ArrayList<>();
        TFOneRatePlanExtensionConfig responseObject;
        LOGGER.info("Start check for whether the Profile Id exists in DB or not " + profileId);
        boolean doesProfileExist = validateProfileExists(dbEnv, profileId);
        if (doesProfileExist) {
            LOGGER.info("Start Get all features for the profile from the DB");
            addConfigsFromDbForDuplicateCheck(allFeatureValuesForDuplicateChecks, profileId, dbEnv);
            LOGGER.info("End Get all features for the profile from the DB");
        }
        LOGGER.info("End check for whether the Profile Id exists in DB or not" + doesProfileExist);

        for (TracfoneOneRatePlanExtensionConfig extensionConfig : rpExtensionConfigs) {
            extensionConfig.setDbEnv(dbEnv);
            extensionConfig.setProfileId(profileId);
            responseObject = createResponseObject(extensionConfig);
            if (!doesProfileExist) {
                addErrorMessage(responseObject,
                        ProfileFeature.PROFILEID.getPropertyName(),
                        ProfileFeature.PROFILEID.getFieldName() + ": " + profileId + " does not exist.");
            }
            LOGGER.info("Start check for duplicate feature");
            validateDuplicateCheck(allFeatureValuesForDuplicateChecks, responseObject);
            LOGGER.info("End check for duplicate feature");
            LOGGER.info("Start check for mandatory fields for profile feature");
            validateMandatoryFields(responseObject, dbEnv);
            LOGGER.info("End check for mandatory fields for profile feature");
            fullList.add(responseObject);
        }

        // split fulllist into success and error
        LOGGER.info("Start split into success and error lists");
        return createSuccessAndErrorLists(fullList);
    }

    private void addConfigsFromDbForDuplicateCheck(List<String> allFeatureValuesForDuplicateChecks,
                                                   String profileId,
                                                   String dbEnv) throws TracfoneOneException {
        TracfoneOneRatePlanExtensionConfig searchConfig = new TracfoneOneRatePlanExtensionConfig();
        searchConfig.setDbEnv(dbEnv);
        searchConfig.setProfileId(profileId);
        // Get all existing features for that profile from the DB
        List<TFOneRatePlanExtensionConfig> existingConfigsForProfile = tracfoneFeatureAction.viewRpExtensionConfig(searchConfig);
        // Add it to the existing config map
        if (!existingConfigsForProfile.isEmpty()) {
            for (TFOneRatePlanExtensionConfig config : existingConfigsForProfile) {
                allFeatureValuesForDuplicateChecks.add(config.getFeatureValue());
            }
        }
    }

    private void validateMandatoryFields(TFOneRatePlanExtensionConfig rpExtensionConfig, String dbEnv) {
        if (StringUtils.isNullOrEmpty(rpExtensionConfig.getRowNum())) {
            addErrorMessage(rpExtensionConfig, ProfileFeature.ROWNUM.getPropertyName(), ProfileFeature.ROWNUM.getFieldName() + CANNOT_BE_BLANK);
        }
        if (StringUtils.isNullOrEmpty(rpExtensionConfig.getFeatureName())) {
            addErrorMessage(rpExtensionConfig, ProfileFeature.FEATURENAME.getPropertyName(), ProfileFeature.FEATURENAME.getFieldName() + CANNOT_BE_BLANK);
        } else {
            validateFieldSize(rpExtensionConfig, ProfileFeature.FEATURENAME.getPropertyName(), ProfileFeature.FEATURENAME.getFieldName(), rpExtensionConfig.getFeatureName(), 100);
        }
        if (StringUtils.isNullOrEmpty(rpExtensionConfig.getFeatureValue())) {
            addErrorMessage(rpExtensionConfig, ProfileFeature.FEATUREVALUE.getPropertyName(), ProfileFeature.FEATUREVALUE.getFieldName() + CANNOT_BE_BLANK);
        } else {
            validateFieldSize(rpExtensionConfig, ProfileFeature.FEATUREVALUE.getPropertyName(), ProfileFeature.FEATUREVALUE.getFieldName(), rpExtensionConfig.getFeatureValue(), 100);
        }
        if (StringUtils.isNullOrEmpty(rpExtensionConfig.getFeatureRequirement())) {
            addErrorMessage(rpExtensionConfig, ProfileFeature.FEATUREREQUIREMENT.getPropertyName(), ProfileFeature.FEATUREREQUIREMENT.getFieldName() + CANNOT_BE_BLANK);
        } else {
            validateFieldSize(rpExtensionConfig, ProfileFeature.FEATUREREQUIREMENT.getPropertyName(), ProfileFeature.FEATUREREQUIREMENT.getFieldName(), rpExtensionConfig.getFeatureRequirement(), 3);
            validateFeatureRequirement(rpExtensionConfig, dbEnv);
        }
        if (StringUtils.isNullOrEmpty(rpExtensionConfig.getDisplaySUIFlag())) {
            addErrorMessage(rpExtensionConfig, ProfileFeature.DISPLAYSUIFLAG.getPropertyName(), ProfileFeature.DISPLAYSUIFLAG.getFieldName() + CANNOT_BE_BLANK);
        } else {
            validateFieldSize(rpExtensionConfig, ProfileFeature.DISPLAYSUIFLAG.getPropertyName(), ProfileFeature.DISPLAYSUIFLAG.getFieldName(), rpExtensionConfig.getDisplaySUIFlag(), 1);
            validateFlag(rpExtensionConfig, ProfileFeature.DISPLAYSUIFLAG.getPropertyName(), ProfileFeature.DISPLAYSUIFLAG.getFieldName(), rpExtensionConfig.getDisplaySUIFlag());
        }
        if (StringUtils.isNullOrEmpty(rpExtensionConfig.getRestrictSUIFlag())) {
            addErrorMessage(rpExtensionConfig, ProfileFeature.RESTRICTSUIFLAG.getPropertyName(), ProfileFeature.RESTRICTSUIFLAG.getFieldName() + CANNOT_BE_BLANK);
        } else {
            validateFieldSize(rpExtensionConfig, ProfileFeature.RESTRICTSUIFLAG.getPropertyName(), ProfileFeature.RESTRICTSUIFLAG.getFieldName(), rpExtensionConfig.getRestrictSUIFlag(), 1);
            validateFlag(rpExtensionConfig, ProfileFeature.RESTRICTSUIFLAG.getPropertyName(), ProfileFeature.RESTRICTSUIFLAG.getFieldName(), rpExtensionConfig.getRestrictSUIFlag());
        }
        if (StringUtils.isNullOrEmpty(rpExtensionConfig.getToggleFlag())) {
            addErrorMessage(rpExtensionConfig, ProfileFeature.TOGGLEFLAG.getPropertyName(), ProfileFeature.TOGGLEFLAG.getFieldName() + CANNOT_BE_BLANK);
        } else {
            validateFieldSize(rpExtensionConfig, ProfileFeature.TOGGLEFLAG.getPropertyName(), ProfileFeature.TOGGLEFLAG.getFieldName(), rpExtensionConfig.getToggleFlag(), 1);
            validateFlag(rpExtensionConfig, ProfileFeature.TOGGLEFLAG.getPropertyName(), ProfileFeature.TOGGLEFLAG.getFieldName(), rpExtensionConfig.getToggleFlag());
        }
        if (StringUtils.isNullOrEmpty(rpExtensionConfig.getProfileId())) {
            addErrorMessage(rpExtensionConfig, ProfileFeature.PROFILEID.getPropertyName(), ProfileFeature.PROFILEID.getFieldName() + CANNOT_BE_BLANK);
        } else {
            validateFieldSize(rpExtensionConfig, ProfileFeature.PROFILEID.getPropertyName(), ProfileFeature.PROFILEID.getFieldName(), rpExtensionConfig.getProfileId(), 38);
        }
    }

    private void validateFeatureRequirement(TFOneRatePlanExtensionConfig rpExtensionConfig, String dbEnv) {
        try {
            if (featureRequirements == null) {
                featureRequirements = new ArrayList<>();
                List<TFOneFeatureRequirement> tfFeatureRequirements = tracfoneFeatureAction.getAllFeatureRequirements(dbEnv);
                for (TFOneFeatureRequirement featureRequirement : tfFeatureRequirements) {
                    featureRequirements.add(featureRequirement.getFeatureRequirement());
                }
            }
            if (!featureRequirements.contains(rpExtensionConfig.getFeatureRequirement())) {
                addErrorMessage(rpExtensionConfig, ProfileFeature.FEATUREREQUIREMENT.getPropertyName(), rpExtensionConfig.getFeatureRequirement() + " cannot be a value for " + ProfileFeature.FEATUREREQUIREMENT.fieldName + ".");
            }
        } catch (TracfoneOneException e) {
            addErrorMessage(rpExtensionConfig, ProfileFeature.FEATUREREQUIREMENT.getPropertyName(), "Could not validate " + ProfileFeature.FEATUREREQUIREMENT.fieldName + ".");
        }
    }

    private void validateFieldSize(TFOneRatePlanExtensionConfig rpExtensionConfig, String propertyName, String fieldName, String fieldValue, int fieldSize) {
        if (fieldValue.length() > fieldSize) {
            addErrorMessage(rpExtensionConfig, propertyName, fieldName + " cannot be more than " + fieldSize + " character(s).");
        }
    }

    private boolean validateProfileExists(String dbEnv, String profileId) throws TracfoneOneException {
        boolean doesExist = false;
        TracfoneOneRatePlanProfile searchProfile = new TracfoneOneRatePlanProfile();
        searchProfile.setDbEnv(dbEnv);
        searchProfile.setProfileId(profileId);
        TFOneRatePlanProfile profile = tracfoneProfileAction.viewProfile(searchProfile);
        if (profile != null && !StringUtils.isNullOrEmpty(profile.getProfileId())) {
            doesExist = true;
        }
        return doesExist;
    }

    private void validateDuplicateCheck(List<String> allFeatureValuesForDuplicateChecks,
                                        TFOneRatePlanExtensionConfig extensionConfig) {
        // Duplicate check needs to be done on the list that the user has tried to upload as well as from the DB
        if (allFeatureValuesForDuplicateChecks.contains(extensionConfig.getFeatureValue())) {
            addErrorMessage(extensionConfig, "default", "A profile feature with the same feature value exists for this profile.");
        } else {
            allFeatureValuesForDuplicateChecks.add(extensionConfig.getFeatureValue());
        }
    }

    private TFOneRatePlanExtensionConfig createResponseObject(TracfoneOneRatePlanExtensionConfig extensionConfig) {
        TFOneRatePlanExtensionConfig rpExtensionConfig = new TFOneRatePlanExtensionConfig();
        rpExtensionConfig.setRowNum(extensionConfig.getRowNum());
        rpExtensionConfig.setProfileId(extensionConfig.getProfileId());
        rpExtensionConfig.setFeatureName(extensionConfig.getFeatureName());
        rpExtensionConfig.setFeatureValue(extensionConfig.getFeatureValue());
        rpExtensionConfig.setFeatureRequirement(extensionConfig.getFeatureRequirement());
        rpExtensionConfig.setToggleFlag(extensionConfig.getToggleFlag());
        rpExtensionConfig.setDisplaySUIFlag(extensionConfig.getDisplaySUIFlag());
        rpExtensionConfig.setRestrictSUIFlag(extensionConfig.getRestrictSUIFlag());
        rpExtensionConfig.setNotes(extensionConfig.getNotes());
        return rpExtensionConfig;
    }

    private void validateFlag(TFOneRatePlanExtensionConfig rpExtensionConfig, String propertyName, String fieldName, String fieldValue) {
        if (!"Y".equalsIgnoreCase(fieldValue) && !"N".equalsIgnoreCase(fieldValue)) {
            addErrorMessage(rpExtensionConfig, propertyName, fieldName + " should only have a value of either Y or N.");
        }
    }

    private TFOneUploadProfileFeatures createSuccessAndErrorLists(List<TFOneRatePlanExtensionConfig> fullList) {
        List<TFOneRatePlanExtensionConfig> successList = new ArrayList<>();
        List<TFOneRatePlanExtensionConfig> errorList = new ArrayList<>();
        fullList.stream().forEach(extensionConfig -> {
            if (extensionConfig.getErrorMessages().isEmpty()) {
                successList.add(extensionConfig);
            } else {
                errorList.add(extensionConfig);
            }
        });
        TFOneUploadProfileFeatures tfOneUploadProfileFeatures = new TFOneUploadProfileFeatures();
        tfOneUploadProfileFeatures.setErrorRpExtensionConfigs(errorList);
        tfOneUploadProfileFeatures.setSuccessRpExtensionConfigs(successList);
        LOGGER.info("End split into success and error lists");
        return tfOneUploadProfileFeatures;
    }

    private void addErrorMessage(TFOneRatePlanExtensionConfig rpExtensionConfig, String propertyName, String errorMessage) {
        if (!rpExtensionConfig.getErrorMessages().containsKey(propertyName)) {
            List<String> errors = new ArrayList<>();
            errors.add(errorMessage);
            rpExtensionConfig.getErrorMessages().put(propertyName, errors);
        } else {
            rpExtensionConfig.getErrorMessages().get(propertyName).add(errorMessage);
        }
    }

    private List<TFOneRatePlanExtensionConfig> setObjIdsForSuccessList(List<TracfoneOneRatePlanExtensionConfig> rpExtensionConfigs) {
        List<TFOneRatePlanExtensionConfig> successListWithObjId = new ArrayList<>();
        TFOneRatePlanExtensionConfig configWithObjId;
        for (TracfoneOneRatePlanExtensionConfig config : rpExtensionConfigs) {
            configWithObjId = createResponseObject(config);
            configWithObjId.setObjid(config.getObjid());
            successListWithObjId.add(configWithObjId);
        }
        return successListWithObjId;
    }

    @Override
    public List<TFOneRatePlanProfile> searchBucketProfile(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException {
        List<TFOneRatePlanProfile> filteredProfiles = null;
        try {
            filteredProfiles = tracfoneFeatureAction.searchBucketProfile(tracfoneOneSearchPlanModel.getDbEnv(),
                    tracfoneOneSearchPlanModel.getServicePlanId(),
                    false);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_PROFILE_ERROR, TRACFONE_SEARCH_PROFILE_ERROR_MESSAGE, ex);
        }

        return filteredProfiles;
    }

    @Override
    public List<TFOneRatePlanProfile> searchChildBucketProfile(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException {
        List<TFOneRatePlanProfile> filteredProfiles = null;
        try {
            filteredProfiles = tracfoneFeatureAction.searchBucketProfile(tracfoneOneSearchPlanModel.getDbEnv(),
                    tracfoneOneSearchPlanModel.getServicePlanId(),
                    true);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_PROFILE_ERROR, TRACFONE_SEARCH_PROFILE_ERROR_MESSAGE, ex);
        }

        return filteredProfiles;
    }

    @Override
    public List<TFOneCarrierServicePlan> getChildBucketServicePlansForCopy(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> bucketServicePlans = new ArrayList<>();
        try {
            bucketServicePlans = tracfoneFeatureAction.getBucketServicePlansForCopy(tracfoneOneSearchPlanModel.getDbEnv(), true);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_SERVICE_PLAN_ERROR, TRACFONE_GET_SERVICE_PLAN_ERROR_MESSAGE, ex);
        }

        return bucketServicePlans;
    }

    @Override
    public List<TFOneCarrierServicePlan> getBucketServicePlansForCopy(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> bucketServicePlans = new ArrayList<>();
        try {
            bucketServicePlans = tracfoneFeatureAction.getBucketServicePlansForCopy(tracfoneOneSearchPlanModel.getDbEnv(), false);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_SERVICE_PLAN_ERROR, TRACFONE_GET_SERVICE_PLAN_ERROR_MESSAGE, ex);
        }

        return bucketServicePlans;
    }

    @Override
    public List<TFOneChildPlan> getBucketChildPlans(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException {
        List<TFOneChildPlan> allChildPlans;
        try {
            allChildPlans = tracfoneFeatureAction.getBucketChildPlans(tracfoneOneSearchPlanModel.getDbEnv(),
                    tracfoneOneSearchPlanModel.getProfileId(),
                    tracfoneOneSearchPlanModel.getServicePlanId());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_VIEW_ALL_CHILD_PLANS_ERROR, TRACFONE_VIEW_ALL_CHILD_PLANS_ERROR_MESSAGE, ex);
        }

        return allChildPlans;
    }

    @Override
    public List<TFOneLineStatusCode> getAllLineStatusCodes(String dbEnv) throws TracfoneOneException {
        List<TFOneLineStatusCode> lineStatusCodes;
        try {
            lineStatusCodes = tracfoneFeatureAction.getAllLineStatusCodes(dbEnv);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_VIEW_ALL_LINE_STATUS_CODES_ERROR, TRACFONE_VIEW_ALL_LINE_STATUS_CODES_ERROR_MESSAGE, ex);
        }

        return lineStatusCodes;
    }

    @Override
    public TFOneGeneralResponse insertLineStatusCode(TracfoneOneLineStatusCode tfOneLineStatus, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneFeatureAction.insertLineStatusCode(tfOneLineStatus, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_LINE_STATUS_CODE_ERROR, TRACFONE_ADD_LINE_STATUS_CODE_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse updateLineStatusCode(TracfoneOneLineStatusCode tfOneLineStatus, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneFeatureAction.updateLineStatusCode(tfOneLineStatus, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_LINE_STATUS_CODE_ERROR, TRACFONE_UPDATE_LINE_STATUS_CODE_ERROR_MESSAGE, ex);
        }
        return response;
    }


    @Override
    public List<TFOneThrottleStatusCode> getAllThrottleStatusCodes(String dbEnv) throws TracfoneOneException {
        List<TFOneThrottleStatusCode> throttleStatusCodes;
        try {
            throttleStatusCodes = tracfoneFeatureAction.getAllThrottleStatusCodes(dbEnv);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_VIEW_ALL_THROTTLE_STATUS_CODES_ERROR, TRACFONE_VIEW_ALL_THROTTLE_STATUS_CODES_ERROR_MESSAGE, ex);
        }

        return throttleStatusCodes;
    }

    @Override
    public TFOneGeneralResponse insertThrottleStatusCode(TracfoneOneThrottleStatusCode tfThrottleStatusCode, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneFeatureAction.insertThrottleStatusCode(tfThrottleStatusCode, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_THROTTLE_STATUS_CODE_ERROR, TRACFONE_ADD_THROTTLE_STATUS_CODE_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse updateThrottleStatusCode(TracfoneOneThrottleStatusCode tfThrottleStatusCode, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneFeatureAction.updateThrottleStatusCode(tfThrottleStatusCode, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_THROTTLE_STATUS_CODE_ERROR, TRACFONE_UPDATE_THROTTLE_STATUS_CODE_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse insertFeatureRequirement(TracfoneOneFeatureRequirement tfFeatureRequirement, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneFeatureAction.insertFeatureRequirement(tfFeatureRequirement, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_FEATURE_REQUIREMENT_ERROR, TRACFONE_ADD_FEATURE_REQUIREMENT_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse updateFeatureRequirement(TracfoneOneFeatureRequirement tfFeatureRequirement, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneFeatureAction.updateFeatureRequirement(tfFeatureRequirement, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_FEATURE_REQUIREMENT_ERROR, TRACFONE_UPDATE_FEATURE_REQUIREMENT_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<TFOneFeatureRequirement> getAllFeatureRequirements(String dbEnv) throws TracfoneOneException {
        List<TFOneFeatureRequirement> tfFeatureRequirements;
        try {
            tfFeatureRequirements = tracfoneFeatureAction.getAllFeatureRequirements(dbEnv);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_VIEW_FEATURE_REQUIREMENT_ERROR, TRACFONE_VIEW_FEATURE_REQUIREMENT_ERROR_MESSAGE, ex);
        }
        return tfFeatureRequirements;
    }

    @Override
    public List<TFOneCarrier> getAllCarrierIds(String dbEnv, String carrierName, String parent) throws TracfoneOneException {
        List<TFOneCarrier> carriers = new ArrayList<>();
        try {
            carriers = tracfoneFeatureAction.getAllCarrierIds(dbEnv, carrierName, parent);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_CARRIER_IDS_ERROR, TRACFONE_GET_CARRIER_IDS_ERROR_MESSAGE, ex);
        }
        return carriers;
    }

    @Override
    public TFOneGeneralResponse deleteFeatureRequirement(TracfoneOneFeatureRequirement tfOneFeatureRequirement, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        checkFeatureRequirementDependenciesExist(tfOneFeatureRequirement);
        try {
            response = tracfoneFeatureAction.deleteFeatureRequirement(tfOneFeatureRequirement, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_FEATURE_REQUIREMENT_ERROR, TRACFONE_DELETE_FEATURE_REQUIREMENT_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<TFOneRatePlanExtensionConfig> searchProfileFeatures(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) throws TracfoneOneException {
        List<TFOneRatePlanExtensionConfig> tfOneFeatures = new ArrayList<>();
        try {
            tfOneFeatures = tracfoneFeatureAction.searchProfileFeatures(tracfoneOneSearchProfileModel);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_PROFILE_FEATURES_ERROR, TRACFONE_SEARCH_PROFILE_FEATURES_ERROR_MESSAGE, ex);
        }
        return tfOneFeatures;
    }

    @Override
    public List<String> getAllFeatureValues(String dbEnv) throws TracfoneOneException {
        List<String> featureValues;
        try {
            featureValues = tracfoneFeatureAction.getAllFeatureValues(dbEnv);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_VIEW_FEATURE_VALUE_ERROR, TRACFONE_VIEW_FEATURE_VALUE_ERROR_MESSAGE, ex);
        }
        return featureValues;
    }

    @Override
    public TFOneGeneralResponse bulkUpdateProfileFeatures(TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getFeatureName())) {
            List<TracfoneOneRatePlanExtensionConfig> tfOneRatePlanExtensionConfigs = new ArrayList<>();
            tfOneRatePlanExtensionConfigs.add(tfOneRpExtensionConfig);
            addNewFeaturesIntoMaster(tfOneRatePlanExtensionConfigs, userId);
        }
        try {
            response = tracfoneFeatureAction.bulkUpdateProfileFeatures(tfOneRpExtensionConfig, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_BULK_UPDATE_PROFILE_FEATURES_CODE_ERROR, TRACFONE_BULK_UPDATE_PROFILE_FEATURES_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public void bulkInsertProfileFeatures(List<TracfoneOneRatePlanExtensionConfig> tfOneRpExtensionConfigs, int userId) throws TracfoneOneException {
        try {
            LOGGER.info(tfOneRpExtensionConfigs);
            // Add all new feature names into Master table
            addNewFeaturesIntoMaster(tfOneRpExtensionConfigs, userId);
            // Get the string containing list of comma separated profile ids
            String profileIds = tfOneRpExtensionConfigs.get(0).getProfileId();
            // Generate a unique identifier
            long unique = (new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
            // Create a record in cop_audit table for this bulk insert
            triggerAudit(userId, BULK_PF_INSERT,
                    "Requested a bulk insert of Profile Features-" + profileIds.split(",").length,
                    profileIds.split(",").length + "_" + unique);

            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (String profileId : profileIds.split(",")) {
                    LOGGER.info(profileId);
                    tfOneRpExtensionConfigs.forEach(config -> config.setProfileId(profileId));
                    try {
                        LOGGER.info("Going to insert this " + tfOneRpExtensionConfigs);
                        tracfoneFeatureAction.insertRpExtensionConfig(tfOneRpExtensionConfigs, userId, String.valueOf(unique));
                    } catch (TracfoneOneException e) {
                        LOGGER.error("Bulk Insertion of Profile Features failed " + tfOneRpExtensionConfigs, e);
                        // This success record is required for the case when it fails insert owing to duplicate feature value.
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(e.getErrorMessage())) {
                            triggerAudit(userId, BULK_PF_INSERT,
                                    "Inserted RP Extension Config profile id " + profileId, "CARRIER ID_" + unique);
                        }
                        triggerAudit(userId, BULK_PF_INSERT,
                                "No profile features were inserted for Profile Id " + profileId + " - " + e.getErrorMessage(),
                                "ERROR_" + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_INSERT_RP_EXTENSION_CONFIG_ERROR, TRACFONE_INSERT_RP_EXTENSION_CONFIG_ERROR_MESSAGE, ex);
        }
    }

    private void triggerAudit(int userId, String action, String details, String carrierId) {
        TracfoneAudit errorAudit = new TracfoneAudit(userId, action, details, carrierId);
        tracfoneAuditEvent.fire(errorAudit);
    }

    private void checkFeatureRequirementDependenciesExist(TracfoneOneFeatureRequirement tfOneFeatureRequirement) throws TracfoneOneException {
        if (tracfoneFeatureAction.checkFeatureRequirementDependencies(tfOneFeatureRequirement)) {
            throw new TracfoneOneException(TRACFONE_FEATURE_REQUIREMENT_DEPENDENCY_ERROR, TRACFONE_FEATURE_REQUIREMENT_DEPENDENCY_ERROR_MESSAGE);
        }
    }

}
