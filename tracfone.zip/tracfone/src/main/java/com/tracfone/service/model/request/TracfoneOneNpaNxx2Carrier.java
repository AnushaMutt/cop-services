package com.tracfone.service.model.request;

/**
 * @author Gaurav.Sharma
 */
public class TracfoneOneNpaNxx2Carrier {
    private String dbEnv;
    private String npa;
    private String nxx;
    private String carrierId;
    private String carrierName;
    private String leadTime;
    private String targetLevel;
    private String rateCente;
    private String state;
    private String carrierIdDescription;
    private String zone;
    private String county;
    private String marketId;
    private String marketArea;
    private String sid;
    private String technology;
    private String frequency1;
    private String frequency2;
    private String btaMarketNumber;
    private String btaMarketName;
    private String gsmTech;
    private String cdmaTech;
    private String tdmaTech;
    private String mnc;
    private String coverageType;
    private String zipCode;
    private String reasonToFail;
    private String techReasonToFail;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getNpa() {
        return npa;
    }

    public void setNpa(String npa) {
        this.npa = npa;
    }

    public String getNxx() {
        return nxx;
    }

    public void setNxx(String nxx) {
        this.nxx = nxx;
    }

    public String getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(String carrierId) {
        this.carrierId = carrierId;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getLeadTime() {
        return leadTime;
    }

    public void setLeadTime(String leadTime) {
        this.leadTime = leadTime;
    }

    public String getTargetLevel() {
        return targetLevel;
    }

    public void setTargetLevel(String targetLevel) {
        this.targetLevel = targetLevel;
    }

    public String getRateCente() {
        return rateCente;
    }

    public void setRateCente(String rateCente) {
        this.rateCente = rateCente;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCarrierIdDescription() {
        return carrierIdDescription;
    }

    public void setCarrierIdDescription(String carrierIdDescription) {
        this.carrierIdDescription = carrierIdDescription;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getMarketId() {
        return marketId;
    }

    public void setMarketId(String marketId) {
        this.marketId = marketId;
    }

    public String getMarketArea() {
        return marketArea;
    }

    public void setMarketArea(String marketArea) {
        this.marketArea = marketArea;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getTechnology() {
        return technology;
    }

    public void setTechnology(String technology) {
        this.technology = technology;
    }

    public String getFrequency1() {
        return frequency1;
    }

    public void setFrequency1(String frequency1) {
        this.frequency1 = frequency1;
    }

    public String getFrequency2() {
        return frequency2;
    }

    public void setFrequency2(String frequency2) {
        this.frequency2 = frequency2;
    }

    public String getBtaMarketNumber() {
        return btaMarketNumber;
    }

    public void setBtaMarketNumber(String btaMarketNumber) {
        this.btaMarketNumber = btaMarketNumber;
    }

    public String getBtaMarketName() {
        return btaMarketName;
    }

    public void setBtaMarketName(String btaMarketName) {
        this.btaMarketName = btaMarketName;
    }

    public String getGsmTech() {
        return gsmTech;
    }

    public void setGsmTech(String gsmTech) {
        this.gsmTech = gsmTech;
    }

    public String getCdmaTech() {
        return cdmaTech;
    }

    public void setCdmaTech(String cdmaTech) {
        this.cdmaTech = cdmaTech;
    }

    public String getTdmaTech() {
        return tdmaTech;
    }

    public void setTdmaTech(String tdmaTech) {
        this.tdmaTech = tdmaTech;
    }

    public String getMnc() {
        return mnc;
    }

    public void setMnc(String mnc) {
        this.mnc = mnc;
    }

    public String getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getReasonToFail() {
        return reasonToFail;
    }

    public void setReasonToFail(String reasonToFail) {
        this.reasonToFail = reasonToFail;
    }

    public String getTechReasonToFail() {
        return techReasonToFail;
    }

    public void setTechReasonToFail(String techReasonToFail) {
        this.techReasonToFail = techReasonToFail;
    }

    @Override
    public String toString() {
        return "TracfoneOneNpaNxx2Carrier{" +
                "dbEnv='" + dbEnv + '\'' +
                ", npa='" + npa + '\'' +
                ", nxx='" + nxx + '\'' +
                ", carrierId='" + carrierId + '\'' +
                ", carrierName='" + carrierName + '\'' +
                ", leadTime='" + leadTime + '\'' +
                ", targetLevel='" + targetLevel + '\'' +
                ", rateCente='" + rateCente + '\'' +
                ", state='" + state + '\'' +
                ", carrierIdDescription='" + carrierIdDescription + '\'' +
                ", zone='" + zone + '\'' +
                ", county='" + county + '\'' +
                ", marketId='" + marketId + '\'' +
                ", marketArea='" + marketArea + '\'' +
                ", sid='" + sid + '\'' +
                ", technology='" + technology + '\'' +
                ", frequency1='" + frequency1 + '\'' +
                ", frequency2='" + frequency2 + '\'' +
                ", btaMarketNumber='" + btaMarketNumber + '\'' +
                ", btaMarketName='" + btaMarketName + '\'' +
                ", gsmTech='" + gsmTech + '\'' +
                ", cdmaTech='" + cdmaTech + '\'' +
                ", tdmaTech='" + tdmaTech + '\'' +
                ", mnc='" + mnc + '\'' +
                ", coverageType='" + coverageType + '\'' +
                ", zipCode='" + zipCode + '\'' +
                ", reasonToFail='" + reasonToFail + '\'' +
                ", techReasonToFail='" + techReasonToFail + '\'' +
                '}';
    }
}
