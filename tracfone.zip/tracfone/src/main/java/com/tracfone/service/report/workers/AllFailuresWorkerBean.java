/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.report.workers;

import com.tracfone.service.model.report.TFOneReportAllFailures;
import com.tracfone.service.util.TracfoneOneConstantReport;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.annotation.Resource;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Stateless;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author druiz
 */
@Stateless
public class AllFailuresWorkerBean {

    @Resource(lookup = "jndi/cop_report")
    private DataSource dataSourceReports;
    private AtomicBoolean busy = new AtomicBoolean(false);
    private static final Logger LOGGER = LogManager.getLogger(AllFailuresWorkerBean.class);

    @Lock(LockType.READ)
    public List<TFOneReportAllFailures> runAllFailuresReport() {
        List<TFOneReportAllFailures> igFailures = new ArrayList<>();

        if (!busy.compareAndSet(false, true)) {
            return igFailures;
        }

        try (Connection con = dataSourceReports.getConnection();
             PreparedStatement stmt = con.prepareStatement(TracfoneOneConstantReport.REPORT_SQL_ALLFAILURES);
             ResultSet resultSet = stmt.executeQuery();) {
            while (resultSet.next()) {
                TFOneReportAllFailures tfOneReportAllFailures = new TFOneReportAllFailures();
                tfOneReportAllFailures.setTransType(resultSet.getString("TRANS_TYPE"));
                tfOneReportAllFailures.setxCarrier(resultSet.getString("X_CARRIER"));
                tfOneReportAllFailures.setxTimesegment(resultSet.getString("X_TIME_SEGMENT"));
                tfOneReportAllFailures.setOrderTypeGroup(resultSet.getString("ORDER_TYPE_GROUP"));
                tfOneReportAllFailures.setTotalTranscount(resultSet.getString("TOTAL_TRANS_COUNT"));
                tfOneReportAllFailures.setPercentFailure(resultSet.getString("PERCENT_FAILURE"));
                tfOneReportAllFailures.setFailureCount(resultSet.getString("FAILURE_COUNT"));
                tfOneReportAllFailures.setSumF(resultSet.getString("SUM_F"));
                igFailures.add(tfOneReportAllFailures);
            }
        } catch (Exception e) {
            LOGGER.error("AllFailures Report retrival error. EX: ", e);
        } finally {
            busy.set(false);
        }
        return igFailures;
    }
}
