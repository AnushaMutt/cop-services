/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneAncillaryCode;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeConfig;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeDiscount;
import com.tracfone.service.model.request.TracfoneOneChildPlan;
import com.tracfone.service.model.request.TracfoneOneLineStatusCode;
import com.tracfone.service.model.request.TracfoneOneMultiRatePlanEsn;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtension;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionLink;
import com.tracfone.service.model.request.TracfoneOneRatePlanProfile;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneThrottleStatusCode;
import com.tracfone.service.model.response.TFOneAncillaryCode;
import com.tracfone.service.model.response.TFOneAncillaryCodeConfig;
import com.tracfone.service.model.response.TFOneAncillaryCodeDiscount;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneMultiRatePlanEsn;
import com.tracfone.service.model.response.TFOneRatePlanExtension;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantPlanWizard;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Shireen Fathima
 */
@Stateless
public class TracfoneProfileAction implements TracfoneProfileLocalAction, TracfoneOneConstantPlanWizard, TracfoneOneConstant {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneProfileAction.class);

    @EJB
    DataBaseController dbControllerEJB;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    private static final String AND = " AND ";
    private static final String COMMA = ", ";

    @Override
    public TFOneGeneralResponse insertProfile(TracfoneOneRatePlanProfile tfRatePlanProfile, int userId) throws TracfoneOneException {
        String profileId = "";
        try (Connection con = dbControllerEJB.getDataSource(tfRatePlanProfile.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_RATEPLAN_PROFILE);) {

            profileId = getNextSequence(con, TRACFONE_RATEPLAN_PROFILE_SEQ_STMT, "RATEPLAN_PROFILEID_SEQ");

            tfRatePlanProfile.setProfileId(profileId);
            setInsertQueryParameters(stmt, tfRatePlanProfile);
            stmt.executeUpdate();

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Profile", "Inserted Profile with profile id " + profileId, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, profileId);
    }

    private String getNextSequence(Connection con, String queryString, String seqId) throws SQLException {
        String sequenceId = null;
        try (PreparedStatement stmt = con.prepareStatement(queryString);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                sequenceId = resultSet.getString(seqId);
            }
        }

        return sequenceId;
    }

    @Override
    public TFOneRatePlanProfile viewProfile(TracfoneOneRatePlanProfile tfRatePlanProfile) throws TracfoneOneException {
        TFOneRatePlanProfile tfOneRatePlanProfile = new TFOneRatePlanProfile();
        try (Connection con = dbControllerEJB.getDataSource(tfRatePlanProfile.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(buildQueryForView(tfRatePlanProfile));) {
            int index = 1;
            if (!StringUtils.isNullOrEmpty(tfRatePlanProfile.getProfileId())) {
                stmt.setString(index++, tfRatePlanProfile.getProfileId());
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlanProfile.getProfileDescription())) {
                stmt.setString(index++, tfRatePlanProfile.getProfileDescription());
            }
            try (ResultSet resultSet = stmt.executeQuery();) {
                LOGGER.info(tfRatePlanProfile.toString());

                while (resultSet.next()) {
                    tfOneRatePlanProfile = setRatePlanProfile(resultSet);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfOneRatePlanProfile;
    }

    /**
     * @param tfRatePlanProfile
     * @param userId
     * @return
     * @throws TracfoneOneException
     */
    @Override
    public TFOneGeneralResponse updateProfile(TracfoneOneRatePlanProfile tfRatePlanProfile, int userId) throws TracfoneOneException {
        // Only update if there is a change to the profile description
        if (!StringUtils.isNullOrEmpty(tfRatePlanProfile.getProfileDescription())) {
            try (Connection con = dbControllerEJB.getDataSource(tfRatePlanProfile.getDbEnv()).getConnection();
                 PreparedStatement stmt = con.prepareStatement(generateUpdateQuery(tfRatePlanProfile, TRACFONE_UPDATE_RATEPLAN_PROFILE));) {
                int index = 1;
                if (!StringUtils.isNullOrEmpty(tfRatePlanProfile.getProfileDescription())) {
                    stmt.setString(index++, tfRatePlanProfile.getProfileDescription());
                }
                stmt.setLong(index++, Long.valueOf(tfRatePlanProfile.getProfileId()));

                stmt.executeUpdate();
            } catch (SQLException | NamingException e) {
                LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
                throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                        TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            } finally {
                TracfoneAudit audit = new TracfoneAudit(userId, "Update Profile", "Updated Profile with details " + tfRatePlanProfile, null);
                tracfoneAuditEvent.fire(audit);
            }
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfRatePlanProfile.getProfileId());
    }

    @Override
    public TFOneGeneralResponse deleteProfile(String dbEnv, List<String> idsToBeDeleted, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(buildInClause(TRACFONE_DELETE_RATEPLAN_PROFILE, idsToBeDeleted.size()));
             PreparedStatement linkStmt = con.prepareStatement(buildInClause(TRACFONE_DELETE_PROFILE_LINKS, idsToBeDeleted.size()));
             PreparedStatement configStmt = con.prepareStatement(buildInClause(TRACFONE_DELETE_PROFILE_CONFIGS, idsToBeDeleted.size()));) {

            setDeleteParameters(linkStmt, idsToBeDeleted);
            linkStmt.executeUpdate();
            LOGGER.info("RP Extension Links are deleted");
            setDeleteParameters(configStmt, idsToBeDeleted);
            configStmt.executeUpdate();
            LOGGER.info("RP Extension Configs are deleted");
            setDeleteParameters(stmt, idsToBeDeleted);
            stmt.executeUpdate();
            LOGGER.info("Profiles with ids are deleted " + idsToBeDeleted);
            LOGGER.info("Commit complete");
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Profile", "Deleted Profile with profile id " + idsToBeDeleted, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, idsToBeDeleted.toString());
    }

    private void setInsertQueryParameters(PreparedStatement stmt,
                                          TracfoneOneRatePlanExtensionLink extensionLink) throws SQLException {
        stmt.setLong(1, Long.valueOf(extensionLink.getObjId()));
        stmt.setLong(2, Long.valueOf(extensionLink.getCarrierFeatureId()));
        stmt.setLong(3, Long.valueOf(extensionLink.getRatePlanExtensionId()));
        stmt.setLong(4, Long.valueOf(extensionLink.getProfileId()));
        if (!StringUtils.isNullOrEmpty(extensionLink.getChildPlanId())) {
            stmt.setString(5, extensionLink.getChildPlanId().trim());
        } else {
            stmt.setNull(5, Types.VARCHAR);
        }
    }

    @Override
    public List<TFOneAncillaryCode> getAllAncillaryCodes(String dbEnv) throws TracfoneOneException {
        List<TFOneAncillaryCode> tfAllAncillaryCodes = new ArrayList<>();
        TFOneAncillaryCode tfOneAncillaryCode;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_ANCILLARY_CODES);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                tfOneAncillaryCode = new TFOneAncillaryCode();
                tfOneAncillaryCode.setAncillaryCode(resultSet.getString(ANCILLARY_CODE));
                tfOneAncillaryCode.setDescription(resultSet.getString("DESCRIPTION"));
                tfAllAncillaryCodes.add(tfOneAncillaryCode);
            }

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfAllAncillaryCodes;
    }

    private void setInsertQueryParameters(PreparedStatement stmt, TracfoneOneRatePlanProfile tfRatePlanProfile) throws SQLException {
        stmt.setLong(1, Long.valueOf(tfRatePlanProfile.getProfileId()));
        stmt.setString(2, tfRatePlanProfile.getProfileDescription().trim());
    }

    @Override
    public List<TFOneChildPlan> getAllChildPlans(String dbEnv) throws TracfoneOneException {
        List<TFOneChildPlan> tfAllChildPlans = new ArrayList<>();
        TFOneChildPlan tfOneChildPlan;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_CHILD_PLANS);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                tfOneChildPlan = new TFOneChildPlan();
                tfOneChildPlan.setChildPlanId(resultSet.getString("CHILD_ID"));
                tfOneChildPlan.setChildDescription(resultSet.getString("CHILD_DESCRIPTION"));
                tfAllChildPlans.add(tfOneChildPlan);
            }

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfAllChildPlans;
    }

    private String buildQueryForView(TracfoneOneRatePlanProfile tfRatePlanProfile) {
        String query = null;
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_PROFILE);
        if (!StringUtils.isNullOrEmpty(tfRatePlanProfile.getProfileId())) {
            builder.append("profile_id = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfRatePlanProfile.getProfileDescription())) {
            builder.append("profile_desc = ?");
            builder.append(AND);
        }

        if (builder.lastIndexOf(AND) != -1) {
            query = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info(query);
        return query;
    }

    private void setDeleteParameters(PreparedStatement stmt, List<String> idsToBeDeleted) throws SQLException {
        int index = 1;
        for (String id : idsToBeDeleted) {
            stmt.setLong(index++, Long.valueOf(id));
        }
    }

    private String buildInClause(String deleteQuery, int size) {
        StringBuilder query = new StringBuilder(deleteQuery);
        if (size != 1) {
            int index = 1;
            while (index < size) {
                query.append(", ?");
                index++;
            }
        }
        query.append(")");
        LOGGER.info("Query with IN Clause is " + query.toString());
        return query.toString();
    }

    private String generateUpdateQuery(TracfoneOneRatePlanProfile tfRatePlanProfile, String query) {
        String updateQuery = "";
        StringBuilder builder = new StringBuilder(query);
        if (!StringUtils.isNullOrEmpty(tfRatePlanProfile.getProfileDescription())) {
            builder.append("profile_desc = ?");
            builder.append(COMMA);
        }

        if (builder.lastIndexOf(COMMA) != -1) {
            updateQuery = builder.substring(0, builder.lastIndexOf(COMMA));
            updateQuery = updateQuery + " where profile_id = ?";
        }
        return updateQuery;
    }

    private TFOneRatePlanProfile setRatePlanProfile(ResultSet resultSet) throws SQLException {
        TFOneRatePlanProfile tfOneRatePlanProfile = new TFOneRatePlanProfile();
        tfOneRatePlanProfile.setProfileId(resultSet.getString(PROFILE_ID));
        tfOneRatePlanProfile.setProfileDescription(resultSet.getString(PROFILE_DESC));
        return tfOneRatePlanProfile;
    }

    @Override
    public List<TFOneRatePlanProfile> searchProfile(TracfoneOneSearchProfileModel tfRatePlanProfile) throws TracfoneOneException {
        List<TFOneRatePlanProfile> tfFilteredProfiles = new ArrayList<>();
        TFOneRatePlanProfile tfOneProfile;
        try (Connection con = dbControllerEJB.getDataSource(tfRatePlanProfile.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getFilterProfileStatement(tfRatePlanProfile));) {
            int index = 1;
            if (!StringUtils.isNullOrEmpty(tfRatePlanProfile.getProfileId())) {
                for (String profileId : tfRatePlanProfile.getProfileId().split(",")) {
                    stmt.setString(index++, profileId);
                }
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlanProfile.getProfileDesc())) {
                stmt.setString(index++, "%" + tfRatePlanProfile.getProfileDesc().toUpperCase() + "%");
            }

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneProfile = new TFOneRatePlanProfile();
                    tfOneProfile.setProfileId(resultSet.getString(PROFILE_ID));
                    tfOneProfile.setProfileDescription(resultSet.getString(PROFILE_DESC));
                    tfFilteredProfiles.add(tfOneProfile);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfFilteredProfiles;
    }

    private String getFilterProfileStatement(TracfoneOneSearchProfileModel tfRatePlanProfile) {
        String searchQuery = "";
        StringBuilder builder;
        if (tfRatePlanProfile.isProfileWithoutFeatures()) {
            builder = new StringBuilder(TRACFONE_SEARCH_PROFILES_WITHOUT_FEATURES);
        } else {
            builder = new StringBuilder(TRACFONE_SEARCH_PROFILE);
        }
        if (!StringUtils.isNullOrEmpty(tfRatePlanProfile.getProfileId())) {
            builder.append("PROFILE_ID in (?")
                    .append(buildInClause("", tfRatePlanProfile.getProfileId().split(",").length))
                    .append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfRatePlanProfile.getProfileDesc())) {
            builder.append("UPPER(PROFILE_DESC) LIKE ?").append(AND);
        }

        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("search profile query is " + searchQuery);
        return searchQuery;
    }

    @Override
    public List<TFOneRatePlanProfile> searchProfilesForUpdate(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) throws TracfoneOneException {
        List<TFOneRatePlanProfile> tfUnlinkedProfiles = new ArrayList<>();
        TFOneRatePlanProfile tfOneProfile;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneSearchProfileModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchProfileStatement(tracfoneOneSearchProfileModel));) {
            setSearchUnlinkedProfileParams(tracfoneOneSearchProfileModel, stmt);

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneProfile = new TFOneRatePlanProfile();
                    tfOneProfile.setProfileId(resultSet.getString(PROFILE_ID));
                    tfOneProfile.setProfileDescription(resultSet.getString(PROFILE_DESC));
                    tfUnlinkedProfiles.add(tfOneProfile);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfUnlinkedProfiles;
    }

    private void setSearchUnlinkedProfileParams(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel, PreparedStatement stmt) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getProfileId())) {
            stmt.setString(index++, tracfoneOneSearchProfileModel.getProfileId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getProfileDesc())) {
            stmt.setString(index++, "%" + tracfoneOneSearchProfileModel.getProfileDesc().toUpperCase() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getFeatureName())) {
            stmt.setString(index++, "%" + tracfoneOneSearchProfileModel.getFeatureName().toUpperCase() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getFeatureValue())) {
            stmt.setString(index, "%" + tracfoneOneSearchProfileModel.getFeatureValue().toUpperCase() + "%");
        }
    }

    private String getSearchProfileStatement(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) {
        String query = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_UNLINKED_PROFILES);
        if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getProfileId())) {
            builder.append("p.PROFILE_ID = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getProfileDesc())) {
            builder.append("UPPER(p.PROFILE_DESC) LIKE ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getFeatureName())) {
            builder.append("UPPER(ec.FEATURE_NAME) LIKE ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getFeatureValue())) {
            builder.append("UPPER(ec.FEATURE_VALUE) LIKE ?");
            builder.append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            query = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Profile Query is +" + query);
        return query;
    }

    @Override
    public TFOneGeneralResponse updateChildPlan(TracfoneOneChildPlan tfOneChildPlan, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneChildPlan.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CHILD_PLAN);) {
            stmt.setString(1, tfOneChildPlan.getChildDescription());
            stmt.setString(2, tfOneChildPlan.getChildPlanId());
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Child Plan", "Updated Child Plan Object " + tfOneChildPlan, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneChildPlan.getChildPlanId());
    }

    @Override
    public TFOneGeneralResponse insertChildPlan(TracfoneOneChildPlan tfOneChildPlan, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneChildPlan.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_CHILD_PLAN);) {
            stmt.setString(1, tfOneChildPlan.getChildPlanId());
            stmt.setString(2, tfOneChildPlan.getChildDescription());
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Child Plan", "Inserted Child Plan Object " + tfOneChildPlan, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneChildPlan.getChildPlanId());
    }

    @Override
    public TFOneGeneralResponse deleteChildPlan(TracfoneOneChildPlan tfOneChildPlan, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneChildPlan.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_CHILD_PLAN);) {
            stmt.setString(1, tfOneChildPlan.getChildPlanId());
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Child Plan", "Deleted Child Plan Object " + tfOneChildPlan, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneChildPlan.getChildPlanId());
    }

    @Override
    public TFOneChildPlan viewChildPlan(TracfoneOneChildPlan searchPlan) throws TracfoneOneException {
        TFOneChildPlan tfOneChildPlan = new TFOneChildPlan();
        try (Connection con = dbControllerEJB.getDataSource(searchPlan.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_VIEW_CHILD_PLAN);) {

            stmt.setString(1, searchPlan.getChildPlanId());
            try (ResultSet resultSet = stmt.executeQuery();) {
                LOGGER.info(SEARCH_OBJECT + searchPlan);
                while (resultSet.next()) {
                    tfOneChildPlan.setChildPlanId(resultSet.getString("CHILD_ID"));
                    tfOneChildPlan.setChildDescription(resultSet.getString("CHILD_DESCRIPTION"));
                }
                LOGGER.info("What I found? " + tfOneChildPlan);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfOneChildPlan;
    }

    /**
     * This method is used to check if the child plan id that is being deleted
     * has links either in the x_rp_extension_link or the
     * carrier_profile_child_bucket table.
     *
     * @param tfOneChildPlan
     * @return
     * @throws TracfoneOneException
     */
    @Override
    public boolean checkChildPlanDependencies(TracfoneOneChildPlan tfOneChildPlan) throws TracfoneOneException {
        boolean dependencyExists = false;
        try (Connection con = dbControllerEJB.getDataSource(tfOneChildPlan.getDbEnv()).getConnection();) {
            // retrieve links
            dependencyExists = checkForDependency(con, TRACFONE_COUNT_CHILD_PLAN_LINKS, tfOneChildPlan);

            // retrieve buckets
            if (!dependencyExists) {
                dependencyExists = checkForDependency(con, TRACFONE_COUNT_CHILD_PLAN_BUCKETS, tfOneChildPlan);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return dependencyExists;
    }

    private boolean checkForDependency(Connection con, String query, TracfoneOneChildPlan tfOneChildPlan) throws SQLException {
        boolean dependencyExists = false;
        int count = 0;
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setString(1, tfOneChildPlan.getChildPlanId());
            try (ResultSet resultSet = stmt.executeQuery();) {
                LOGGER.info(SEARCH_OBJECT + tfOneChildPlan);
                while (resultSet.next()) {
                    count = resultSet.getInt(1);
                    LOGGER.info("How many child plan links or buckets have been found? " + count);
                }
            }
        }
        if (count > 0) {
            dependencyExists = true;
        }
        return dependencyExists;
    }

    @Override
    public TFOneGeneralResponse deleteAncillaryCode(TracfoneOneAncillaryCode ancillaryCode, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(ancillaryCode.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_ANCILLARY_CODE);) {
            stmt.setString(1, ancillaryCode.getAncillaryCode());
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Ancillary Code", "Deleted Ancillary code " + ancillaryCode.getAncillaryCode(), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, ancillaryCode.getAncillaryCode());
    }

    @Override
    public boolean checkRpExtensionCodeDependencies(TracfoneOneRatePlanExtension tfOneRatePlanExtension) throws TracfoneOneException {
        boolean dependencyExists = false;
        try (Connection con = dbControllerEJB.getDataSource(tfOneRatePlanExtension.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getQueryStatement(TRACFONE_COUNT_ANCILLARY_CODE_EXTENSIONS, tfOneRatePlanExtension))) {
            if (!StringUtils.isNullOrEmpty(tfOneRatePlanExtension.getAncillaryCode())) {
                stmt.setString(1, tfOneRatePlanExtension.getAncillaryCode());
            }
            if (!StringUtils.isNullOrEmpty(tfOneRatePlanExtension.getThrottleStatusCode())) {
                stmt.setString(1, tfOneRatePlanExtension.getThrottleStatusCode());
            }
            if (!StringUtils.isNullOrEmpty(tfOneRatePlanExtension.getLineStatusCode())) {
                stmt.setString(1, tfOneRatePlanExtension.getLineStatusCode());
            }
            int count = 0;
            try (ResultSet resultSet = stmt.executeQuery();) {
                LOGGER.info(SEARCH_OBJECT + tfOneRatePlanExtension);
                while (resultSet.next()) {
                    count = resultSet.getInt(1);
                    LOGGER.info("How many RP Extension Code have been found? " + count);
                }
                if (count > 0) {
                    dependencyExists = true;
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return dependencyExists;
    }

    private String getQueryStatement(String query, TracfoneOneRatePlanExtension tfOneRatePlanExtension) {
        StringBuilder builder = new StringBuilder(query);
        if (!StringUtils.isNullOrEmpty(tfOneRatePlanExtension.getAncillaryCode())) {
            builder.append("ANCILLARY_CODE = ?");
        } else if (!StringUtils.isNullOrEmpty(tfOneRatePlanExtension.getLineStatusCode())) {
            builder.append("LINE_STATUS_CODE = ?");
        } else if (!StringUtils.isNullOrEmpty(tfOneRatePlanExtension.getThrottleStatusCode())) {
            builder.append("THROTTLE_STATUS_CODE = ?");
        }
        LOGGER.info("Search Rp extension Query " + builder);
        return builder.toString();
    }

    @Override
    public List<TFOneAncillaryCode> searchAncillaryCodes(TracfoneOneAncillaryCode searchAncillaryCode) throws TracfoneOneException {
        List<TFOneAncillaryCode> ancillaryCodes = new ArrayList<>();
        TFOneAncillaryCode tfOneAncillaryCode;
        String query = getSearchAncillaryCodeQuery(searchAncillaryCode);
        try (Connection con = dbControllerEJB.getDataSource(searchAncillaryCode.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(query);) {
            int index = 1;
            if (!StringUtils.isNullOrEmpty(searchAncillaryCode.getAncillaryCode())) {
                stmt.setString(index++, "%" + searchAncillaryCode.getAncillaryCode().toUpperCase() + "%");
            }
            if (!StringUtils.isNullOrEmpty(searchAncillaryCode.getDescription())) {
                stmt.setString(index++, "%" + searchAncillaryCode.getDescription().toUpperCase() + "%");
            }

            LOGGER.info(searchAncillaryCode.toString());

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneAncillaryCode = new TFOneAncillaryCode();
                    tfOneAncillaryCode.setAncillaryCode(resultSet.getString(ANCILLARY_CODE));
                    tfOneAncillaryCode.setDescription(resultSet.getString("DESCRIPTION"));
                    ancillaryCodes.add(tfOneAncillaryCode);
                }
                LOGGER.info("Search Results are " + ancillaryCodes);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return ancillaryCodes;
    }

    @Override
    public TFOneGeneralResponse updateAncillaryCode(TracfoneOneAncillaryCode ancillaryCode, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(ancillaryCode.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_ANCILLARY_CODE);) {
            stmt.setString(1, ancillaryCode.getDescription());
            stmt.setString(2, ancillaryCode.getAncillaryCode());
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Ancillary Code Description", "Updated Ancillary Code Object " + ancillaryCode, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, ancillaryCode.getAncillaryCode());
    }

    @Override
    public TFOneGeneralResponse insertAncillaryCode(TracfoneOneAncillaryCode ancillaryCode, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(ancillaryCode.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_ANCILLARY_CODE);) {
            stmt.setString(1, ancillaryCode.getAncillaryCode());
            stmt.setString(2, ancillaryCode.getDescription());
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Ancillary code", "Inserted Ancillary Code " + ancillaryCode, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, ancillaryCode.getAncillaryCode());
    }

    private String getSearchAncillaryCodeQuery(TracfoneOneAncillaryCode searchAncillaryCode) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_VIEW_ANCILLARY_CODE);
        if (!StringUtils.isNullOrEmpty(searchAncillaryCode.getAncillaryCode())) {
            builder.append("UPPER(ANCILLARY_CODE) LIKE ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(searchAncillaryCode.getDescription())) {
            builder.append("UPPER(DESCRIPTION) LIKE ?");
            builder.append(AND);
        }

        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
            searchQuery = searchQuery + " order by ANCILLARY_CODE";
        }
        LOGGER.info("Search Ancillary Code Query " + searchQuery);
        return searchQuery;
    }

    @Override
    public List<TFOneRatePlanExtension> searchRpExtensions(TracfoneOneRatePlanExtension searchRpExtension) throws TracfoneOneException {
        List<TFOneRatePlanExtension> rpExtensions = new ArrayList<>();
        TFOneRatePlanExtension tfOneRatePlanExtension;
        String query = getSearchRpExtensionQuery(searchRpExtension);
        try (Connection con = dbControllerEJB.getDataSource(searchRpExtension.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(query);) {
            int index = 1;
            if (!StringUtils.isNullOrEmpty(searchRpExtension.getObjId())) {
                stmt.setString(index++, "%" + searchRpExtension.getObjId() + "%");
            }
            if (!StringUtils.isNullOrEmpty(searchRpExtension.getLineStatusCode())) {
                stmt.setString(index++, "%" + searchRpExtension.getLineStatusCode().toUpperCase() + "%");
            }
            if (!StringUtils.isNullOrEmpty(searchRpExtension.getThrottleStatusCode())) {
                stmt.setString(index++, "%" + searchRpExtension.getThrottleStatusCode().toUpperCase() + "%");
            }
            if (!StringUtils.isNullOrEmpty(searchRpExtension.getAncillaryCode())) {
                stmt.setString(index++, "%" + searchRpExtension.getAncillaryCode().toUpperCase() + "%");
            }

            LOGGER.info(searchRpExtension.toString());

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneRatePlanExtension = new TFOneRatePlanExtension();
                    tfOneRatePlanExtension.setAncillaryCode(resultSet.getString(ANCILLARY_CODE));
                    tfOneRatePlanExtension.setObjId(resultSet.getString(OBJID));
                    tfOneRatePlanExtension.setThrottleStatusCode(resultSet.getString("THROTTLE_STATUS_CODE"));
                    tfOneRatePlanExtension.setLineStatusCode(resultSet.getString("LINE_STATUS_CODE"));
                    rpExtensions.add(tfOneRatePlanExtension);
                }
                LOGGER.info("Search Results are " + rpExtensions);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return rpExtensions;
    }

    @Override
    public boolean checkRpExtensionDependencies(TracfoneOneRatePlanExtension tfRpExtension) throws TracfoneOneException {
        boolean dependencyExists = false;
        try (Connection con = dbControllerEJB.getDataSource(tfRpExtension.getDbEnv()).getConnection();) {
            dependencyExists = checkRpExtensionDependency(con, TRACFONE_COUNT_RP_EXTENSION_LINKS, tfRpExtension);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return dependencyExists;
    }

    private boolean checkRpExtensionDependency(Connection con, String query, TracfoneOneRatePlanExtension tfRpExtension) throws SQLException {
        boolean dependencyExists = false;
        int count = 0;
        try (PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setLong(1, Long.valueOf(tfRpExtension.getObjId()));
            try (ResultSet resultSet = stmt.executeQuery();) {
                LOGGER.info("What am I searching for? +", tfRpExtension);
                while (resultSet.next()) {
                    count = resultSet.getInt(1);
                    LOGGER.info("How many RP extension links have been found? " + count);
                }
            }
        }
        if (count > 0) {
            dependencyExists = true;
        }
        return dependencyExists;
    }

    @Override
    public TFOneGeneralResponse deleteRpExtension(TracfoneOneRatePlanExtension tfRpExtension, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfRpExtension.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_RP_EXTENSION);) {
            stmt.setString(1, tfRpExtension.getObjId());
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Rp Extension", "Deleted Rp Extension Object " + tfRpExtension, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfRpExtension.getObjId());
    }

    @Override
    public TFOneGeneralResponse insertRpExtension(TracfoneOneRatePlanExtension tfRpExtension, int userId) throws TracfoneOneException {
        String objid = "";
        try (Connection con = dbControllerEJB.getDataSource(tfRpExtension.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_RP_EXTENSION);) {
            objid = getNextSequence(con, TRACFONE_EXTENSION_ID_SEQ_STMT, "EXTENSION_ID_SEQ");
            tfRpExtension.setObjId(objid);
            stmt.setString(1, tfRpExtension.getObjId());
            stmt.setString(2, tfRpExtension.getLineStatusCode());
            stmt.setString(3, tfRpExtension.getThrottleStatusCode());
            stmt.setString(4, tfRpExtension.getAncillaryCode());
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Rp Extension", "Inserted Rp Extension " + tfRpExtension, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, objid);
    }

    private String getSearchRpExtensionQuery(TracfoneOneRatePlanExtension searchRpExtension) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_VIEW_RP_EXTENSION);
        if (!StringUtils.isNullOrEmpty(searchRpExtension.getObjId())) {
            builder.append("OBJID LIKE ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(searchRpExtension.getLineStatusCode())) {
            builder.append("UPPER(LINE_STATUS_CODE) LIKE ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(searchRpExtension.getThrottleStatusCode())) {
            builder.append("UPPER(THROTTLE_STATUS_CODE) LIKE ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(searchRpExtension.getAncillaryCode())) {
            builder.append("UPPER(ANCILLARY_CODE) LIKE ?");
            builder.append(AND);
        }

        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
            searchQuery = searchQuery + " order by objid";
        }
        LOGGER.info("Search RP Extension Query " + searchQuery);
        return searchQuery;
    }

    @Override
    public TFOneGeneralResponse insertRpExtensionLink(TracfoneOneRatePlanExtensionLink tfRpExtensionLink, int userId) throws TracfoneOneException {
        String objid = "";
        try (Connection con = dbControllerEJB.getDataSource(tfRpExtensionLink.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_RP_EXTENSION_LINK);) {
            objid = getNextSequence(con, TRACFONE_EXTENSION_LINK_ID_SEQ_STMT, "EXTENSION_LINKID_SEQ");
            tfRpExtensionLink.setObjId(objid);
            setInsertQueryParameters(stmt, tfRpExtensionLink);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Rp Extension Link", "Inserted Rp Extension Link" + tfRpExtensionLink, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, objid);
    }

    @Override
    public TFOneGeneralResponse deleteRpExtensionLink(TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink, int userId) throws TracfoneOneException {
        String deletedId = "";
        try (Connection con = dbControllerEJB.getDataSource(tfOneRpExtensionLink.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(setQueryToDeleteExtensionLink(tfOneRpExtensionLink));) {

            if (!StringUtils.isNullOrEmpty(tfOneRpExtensionLink.getObjId())) {
                deletedId = tfOneRpExtensionLink.getObjId();
                stmt.setString(1, deletedId);
            } else if (!StringUtils.isNullOrEmpty(tfOneRpExtensionLink.getCarrierFeatureId())) {
                deletedId = tfOneRpExtensionLink.getCarrierFeatureId();
                stmt.setString(1, deletedId);
            }

            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete RP Extension Link", "Deleted RP Extension Object " + tfOneRpExtensionLink, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, deletedId);
    }

    private String setQueryToDeleteExtensionLink(TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink) {
        StringBuilder builder = new StringBuilder(TRACFONE_DELETE_RP_EXTENSION_LINK);
        if (!StringUtils.isNullOrEmpty(tfOneRpExtensionLink.getObjId())) {
            builder = builder.append("OBJID = ? ");
        } else if (!StringUtils.isNullOrEmpty(tfOneRpExtensionLink.getCarrierFeatureId())) {
            builder = builder.append("CARRIER_FEATURE_OBJID = ? ");
        }
        LOGGER.info("Delete Query is " + builder);
        return builder.toString();
    }

    @Override
    public TFOneGeneralResponse updateRpExtensionLink(TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneRpExtensionLink.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_RP_EXTENSION_LINK);) {
            setRpExtensionLink(stmt, tfOneRpExtensionLink);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update RP Extension Link", "Updated RP Extension Link Object " + tfOneRpExtensionLink, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneRpExtensionLink.getObjId());
    }

    @Override
    public List<TFOneCarrierServicePlan> getProfileServicePlans(String dbEnv, String profileId) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan servicePlan;
        LOGGER.info("Service plans for profile id " + profileId);
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_PROFILE_SERVICE_PLANS);) {
            stmt.setLong(1, Long.valueOf(profileId));

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    servicePlan = new TFOneCarrierServicePlan();
                    servicePlan.setServicePlanId(resultSet.getString(OBJID));
                    servicePlan.setDescription(resultSet.getString("mkt_name"));
                    carrierServicePlans.add(servicePlan);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        LOGGER.info("Service plans for profile id " + profileId + " is " + carrierServicePlans);
        return carrierServicePlans;
    }

    @Override
    public List<TFOneCarrierServicePlan> getRatePlanServicePlans(String dbEnv, String ratePlan) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan servicePlan;
        LOGGER.info("Service plans for rate plan " + ratePlan);
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_RP_SERVICE_PLANS);) {
            stmt.setString(1, ratePlan);

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    servicePlan = new TFOneCarrierServicePlan();
                    servicePlan.setServicePlanId(resultSet.getString(OBJID));
                    servicePlan.setDescription(resultSet.getString("mkt_name"));
                    carrierServicePlans.add(servicePlan);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        LOGGER.info("Service plans for rate plan " + ratePlan + " is " + carrierServicePlans);
        return carrierServicePlans;
    }

    private void setRpExtensionLink(PreparedStatement stmt, TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink) throws SQLException {
        int index = 1;
        stmt.setString(index++, tfOneRpExtensionLink.getRatePlanExtensionId());
        stmt.setString(index++, tfOneRpExtensionLink.getProfileId());
        stmt.setString(index++, tfOneRpExtensionLink.getChildPlanId());
        stmt.setString(index, tfOneRpExtensionLink.getObjId());
    }

    @Override
    public TFOneGeneralResponse insertAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfAncillaryCodeConfig.getDbEnv()).getConnection();) {
            boolean hasDuplicate = hasDuplicateFeatureValue(con, tfAncillaryCodeConfig);

            if (hasDuplicate) {
                throw new TracfoneOneException(TRACFONE_DUPLICATE_CODE_CONFIG_ERROR, TRACFONE_DUPLICATE_CODE_CONFIG_ERROR_MESSAGE + tfAncillaryCodeConfig.getFeatureValue());
            } else {
                try (PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_ANCILLARY_CODE_CONFIG);) {
                    setAncillaryCodeConfigQuery(stmt, tfAncillaryCodeConfig, false);
                    stmt.executeUpdate();
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_ADD_ANCILLARY_CODE_CONFIG_ERROR,
                    TRACFONE_ADD_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Ancillary Code Config", "Inserted Ancillary Code Config object " + tfAncillaryCodeConfig, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfAncillaryCodeConfig.getExtensionObjId());
    }

    @Override
    public TFOneGeneralResponse updateAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfAncillaryCodeConfig.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_ANCILLARY_CODE_CONFIG);) {
            setAncillaryCodeConfigQuery(stmt, tfAncillaryCodeConfig, true);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_UPDATE_ANCILLARY_CODE_CONFIG_ERROR,
                    TRACFONE_UPDATE_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Ancillary Code Config", "Updated Ancillary Code Config Object " + tfAncillaryCodeConfig, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfAncillaryCodeConfig.getExtensionObjId());
    }

    private void setAncillaryCodeConfigQuery(PreparedStatement stmt, TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig, boolean isUpdate) throws SQLException {
        int index = 1;
        stmt.setString(index++, tfAncillaryCodeConfig.getFeatureName());
        stmt.setString(index++, tfAncillaryCodeConfig.getFeatureRequirement());
        stmt.setString(index++, tfAncillaryCodeConfig.getToggleFlag());
        stmt.setString(index++, tfAncillaryCodeConfig.getNotes());
        stmt.setString(index++, tfAncillaryCodeConfig.getRestrictSUIFlag());
        stmt.setString(index++, tfAncillaryCodeConfig.getDisplaySUIFlag());
        stmt.setString(index++, tfAncillaryCodeConfig.getExtensionObjId());
        stmt.setString(index++, tfAncillaryCodeConfig.getProfileId());
        stmt.setString(index, tfAncillaryCodeConfig.getFeatureValue());
    }

    @Override
    public TFOneGeneralResponse deleteAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfAncillaryCodeConfig.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_ANCILLARY_CODE_CONFIG);) {
            stmt.setString(1, tfAncillaryCodeConfig.getExtensionObjId());
            stmt.setString(2, tfAncillaryCodeConfig.getProfileId());
            stmt.setString(3, tfAncillaryCodeConfig.getFeatureValue());
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Ancillary Code Config", "Deleted Ancillary Code Config Object " + tfAncillaryCodeConfig, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfAncillaryCodeConfig.getExtensionObjId());
    }

    @Override
    public List<TFOneAncillaryCodeConfig> getAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig) throws TracfoneOneException {
        List<TFOneAncillaryCodeConfig> tfOneAncillaryCodeConfigs = new ArrayList<>();
        TFOneAncillaryCodeConfig tfOneAncillaryCodeConfig;
        try (Connection con = dbControllerEJB.getDataSource(tfAncillaryCodeConfig.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ANCILLARY_CODE_CONFIG);) {
            stmt.setString(1, tfAncillaryCodeConfig.getExtensionObjId());
            stmt.setString(2, tfAncillaryCodeConfig.getProfileId());

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneAncillaryCodeConfig = new TFOneAncillaryCodeConfig();
                    tfOneAncillaryCodeConfig.setExtensionObjId(resultSet.getString("EXTENSION_OBJID"));
                    tfOneAncillaryCodeConfig.setProfileId(resultSet.getString(PROFILE_ID));
                    tfOneAncillaryCodeConfig.setFeatureName(resultSet.getString("FEATURE_NAME"));
                    tfOneAncillaryCodeConfig.setFeatureValue(resultSet.getString("FEATURE_VALUE"));
                    tfOneAncillaryCodeConfig.setFeatureRequirement(resultSet.getString("FEATURE_REQUIREMENT"));
                    tfOneAncillaryCodeConfig.setToggleFlag(resultSet.getString("TOGGLE_FLAG"));
                    tfOneAncillaryCodeConfig.setNotes(resultSet.getString("NOTES"));
                    tfOneAncillaryCodeConfig.setRestrictSUIFlag(resultSet.getString("RESTRICT_SUI_FLAG"));
                    tfOneAncillaryCodeConfig.setDisplaySUIFlag(resultSet.getString("DISPLAY_SUI_FLAG"));
                    tfOneAncillaryCodeConfigs.add(tfOneAncillaryCodeConfig);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneAncillaryCodeConfigs;
    }

    @Override
    public TFOneGeneralResponse insertAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfAncillaryCodeDiscount.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_ANCILLARY_CODE_DISCOUNT);) {

            setAncillaryCodeDiscountQuery(stmt, tfAncillaryCodeDiscount);
            stmt.executeUpdate();

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Ancillary Code Discount", "Inserted Ancillary Code Discount object " + tfAncillaryCodeDiscount, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfAncillaryCodeDiscount.getAncillaryCode());
    }

    private void setAncillaryCodeDiscountQuery(PreparedStatement stmt, TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount) throws SQLException {
        stmt.setString(1, tfAncillaryCodeDiscount.getNewBrmEquivalent());
        stmt.setString(2, tfAncillaryCodeDiscount.getAncillaryCode());
    }

    @Override
    public TFOneGeneralResponse deleteAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfAncillaryCodeDiscount.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_ANCILLARY_CODE_DISCOUNT);) {

            setAncillaryCodeDiscountQuery(stmt, tfAncillaryCodeDiscount);
            stmt.executeUpdate();

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Ancillary Code Discount", "Deleted Ancillary Code Discount object " + tfAncillaryCodeDiscount, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfAncillaryCodeDiscount.getAncillaryCode());
    }

    @Override
    public TFOneGeneralResponse updateAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfAncillaryCodeDiscount.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_ANCILLARY_CODE_DISCOUNT);) {

            setAncillaryCodeDiscountQuery(stmt, tfAncillaryCodeDiscount);
            stmt.setString(3, tfAncillaryCodeDiscount.getOldBrmEquivalent());
            stmt.executeUpdate();

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Ancillary Code Discount", "Updated Ancillary Code Discount Object " + tfAncillaryCodeDiscount, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfAncillaryCodeDiscount.getAncillaryCode());
    }

    @Override
    public List<TFOneAncillaryCodeDiscount> searchAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount) throws TracfoneOneException {
        List<TFOneAncillaryCodeDiscount> tfOneAncillaryCodeDiscounts = new ArrayList<>();
        TFOneAncillaryCodeDiscount tfOneAncillaryCodeDiscount;
        try (Connection con = dbControllerEJB.getDataSource(tfAncillaryCodeDiscount.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchDiscountStatement(tfAncillaryCodeDiscount));) {
            int index = 1;
            if (!StringUtils.isNullOrEmpty(tfAncillaryCodeDiscount.getAncillaryCode())) {
                stmt.setString(index++, tfAncillaryCodeDiscount.getAncillaryCode());
            }
            if (!StringUtils.isNullOrEmpty(tfAncillaryCodeDiscount.getNewBrmEquivalent())) {
                stmt.setString(index++, "%" + tfAncillaryCodeDiscount.getNewBrmEquivalent().toUpperCase() + "%");
            }

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneAncillaryCodeDiscount = new TFOneAncillaryCodeDiscount();
                    tfOneAncillaryCodeDiscount.setAncillaryCode(resultSet.getString(ANCILLARY_CODE));
                    tfOneAncillaryCodeDiscount.setBrmEquivalent(resultSet.getString("BRM_EQUIVALENT"));
                    tfOneAncillaryCodeDiscounts.add(tfOneAncillaryCodeDiscount);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneAncillaryCodeDiscounts;
    }

    private String getSearchDiscountStatement(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_ANCILLARY_CODE_DISCOUNT);
        if (!StringUtils.isNullOrEmpty(tfAncillaryCodeDiscount.getAncillaryCode())) {
            builder.append("ANCILLARY_CODE = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfAncillaryCodeDiscount.getNewBrmEquivalent())) {
            builder.append("UPPER(BRM_EQUIVALENT) LIKE ?");
            builder.append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        return searchQuery;
    }

    @Override
    public TFOneGeneralResponse deleteLineStatusCode(TracfoneOneLineStatusCode tfOneLineStatus, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneLineStatus.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_LINE_STATUS_CODE);) {
            stmt.setString(1, tfOneLineStatus.getLineStatusCode());
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Line Status Code", "Deleted Line Status code " + tfOneLineStatus.getLineStatusCode(), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneLineStatus.getLineStatusCode());
    }

    @Override
    public long checkAncillaryCodeDiscountDependencies(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount) throws TracfoneOneException {
        long count = 0;
        try (Connection con = dbControllerEJB.getDataSource(tfAncillaryCodeDiscount.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_COUNT_ANCILLARY_CODE_DISCOUNT_DEPENDENCIES);) {
            stmt.setString(1, tfAncillaryCodeDiscount.getAncillaryCode());
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    count = resultSet.getLong(1);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        LOGGER.info("Total number of Profiles that are associated to this Ancillary code : " + count);
        return count;
    }

    @Override
    public TFOneGeneralResponse deleteThrottleStatusCode(TracfoneOneThrottleStatusCode tfOneThrottleStatusCode, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneThrottleStatusCode.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_THROTTLE_STATUS_CODE);) {
            stmt.setString(1, tfOneThrottleStatusCode.getThrottleStatusCode());
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Throttle Status Code", "Deleted Throttle Status code " + tfOneThrottleStatusCode.getThrottleStatusCode(), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneThrottleStatusCode.getThrottleStatusCode());
    }

    private String getDuplicateFeatureValueQuery() {
        String duplicateQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_GET_ANCILLARY_CODE_CONFIG);
        builder.append(" and feature_value = ?");
        duplicateQuery = builder.toString();
        LOGGER.info("Feature Value duplicate check : " + duplicateQuery);
        return duplicateQuery;
        }

    private boolean hasDuplicateFeatureValue(Connection con, TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig) throws SQLException {
        String featureValue = null;
        try (PreparedStatement duplicateStmt = con.prepareStatement(getDuplicateFeatureValueQuery());) {
            int index = 1;
            duplicateStmt.setString(index++, tfAncillaryCodeConfig.getExtensionObjId());
            duplicateStmt.setString(index++, tfAncillaryCodeConfig.getProfileId());
            duplicateStmt.setString(index++, tfAncillaryCodeConfig.getFeatureValue());
            try (ResultSet resultSet = duplicateStmt.executeQuery()) {
                while (resultSet.next()) {
                    featureValue = resultSet.getString("FEATURE_VALUE");
                    break;
                }
            }
        }
        return !StringUtils.isNullOrEmpty(featureValue);
    }

    @Override
    public TFOneGeneralResponse insertMultiRatePlanEsn(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn, int userId, String unique) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneMultiRatePlanEsn.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_MULTI_RATE_PLAN_ESNS);) {
            setMultiRatePlanEsnsQueryParameters(stmt, tracfoneOneMultiRatePlanEsn);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit;
            // Added this logic to track bulk insert of Multi Rate Plan Esns
            if (StringUtils.isNullOrEmpty(unique)) {
                audit = new TracfoneAudit(userId, "Insert Multi Rate Plan Esns",
                        "Inserted Multi Rate Plan Esns Object " + tracfoneOneMultiRatePlanEsn, null);
            } else {
                audit = new TracfoneAudit(userId, "Bulk Multi Rate Plan ESN Insert",
                        "Inserted Multi Rate Plan Esns Object " + tracfoneOneMultiRatePlanEsn, "CARRIER ID_" + unique);
            }
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneMultiRatePlanEsn.getxServicePlanId());
    }

    @Override
    public TFOneGeneralResponse updateMultiRatePlanEsn(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneMultiRatePlanEsn.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_MULTI_RATE_PLAN_ESNS);) {
            setMultiRatePlanEsnsQueryParameters(stmt, tracfoneOneMultiRatePlanEsn);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Multi Rate Plan Esns", "Updated Multi Rate Plan Esns Object " + tracfoneOneMultiRatePlanEsn, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneMultiRatePlanEsn.getxServicePlanId());
    }


    private void setMultiRatePlanEsnsQueryParameters(PreparedStatement stmt, TracfoneOneMultiRatePlanEsn tfMultiRatePlanEsn) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tfMultiRatePlanEsn.getxPriority())) {
            stmt.setLong(index++, Long.valueOf(tfMultiRatePlanEsn.getxPriority()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfMultiRatePlanEsn.getxReason())) {
            stmt.setString(index++, tfMultiRatePlanEsn.getxReason());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfMultiRatePlanEsn.getxProductId())) {
            stmt.setString(index++, tfMultiRatePlanEsn.getxProductId());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfMultiRatePlanEsn.getDelFlag())) {
            stmt.setString(index++, tfMultiRatePlanEsn.getDelFlag());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        stmt.setString(index++, tfMultiRatePlanEsn.getxEsn());
        stmt.setLong(index, Long.valueOf(tfMultiRatePlanEsn.getxServicePlanId()));
    }

    @Override
    public TFOneGeneralResponse deleteMultiRatePlanEsn(List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsns, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneMultiRatePlanEsns.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_MULTI_RATE_PLAN_ESNS);) {
            for (TracfoneOneMultiRatePlanEsn multiRatePlanEsn : tracfoneOneMultiRatePlanEsns) {
                stmt.setString(1, multiRatePlanEsn.getxEsn());
                stmt.setString(2, multiRatePlanEsn.getxServicePlanId());
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Multi Rate Plan Esns", "Deleted Multi Rate Plan Esns Object " + tracfoneOneMultiRatePlanEsns, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneMultiRatePlanEsns.get(0).getxServicePlanId());
    }

    @Override
    public List<TFOneMultiRatePlanEsn> searchMultiRatePlanEsns(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn) throws TracfoneOneException {
        List<TFOneMultiRatePlanEsn> tfOneMultiRatePlanEsnss = new ArrayList<>();
        TFOneMultiRatePlanEsn tfOneMultiRatePlanEsns;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneMultiRatePlanEsn.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchMultiRatePlanEsnQuery(tracfoneOneMultiRatePlanEsn));) {
            setMultiRatePlanEsnsSearchParams(stmt, tracfoneOneMultiRatePlanEsn);

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneMultiRatePlanEsns = new TFOneMultiRatePlanEsn();
                    tfOneMultiRatePlanEsns.setDelFlag(resultSet.getString("DEL_FLAG"));
                    tfOneMultiRatePlanEsns.setxEsn(resultSet.getString("X_ESN"));
                    tfOneMultiRatePlanEsns.setxProductId(resultSet.getString("X_PRODUCT_ID"));
                    tfOneMultiRatePlanEsns.setxPriority(resultSet.getString("X_PRIORITY"));
                    tfOneMultiRatePlanEsns.setxServicePlanId(resultSet.getString("X_SERVICE_PLAN_ID"));
                    tfOneMultiRatePlanEsns.setxReason(resultSet.getString("X_REASON"));
                    tfOneMultiRatePlanEsnss.add(tfOneMultiRatePlanEsns);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneMultiRatePlanEsnss;
    }

    @Override
    public List<String> searchProfilesByDesc(List<TracfoneOneRatePlanProfile> tfRatePlanProfiles) throws TracfoneOneException {
        List<String> profilesFound = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(tfRatePlanProfiles.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(buildInClause(TRACFONE_SEARCH_PROFILE + "PROFILE_DESC IN (?",
                     tfRatePlanProfiles.size()));) {
            int index = 1;
            for (TracfoneOneRatePlanProfile tfOneRatePlanProfile : tfRatePlanProfiles) {
                stmt.setString(index++, tfOneRatePlanProfile.getProfileDescription());
            }

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    profilesFound.add(resultSet.getString(PROFILE_DESC));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        LOGGER.info("Profiles matching the description are " + profilesFound);
        return profilesFound;
    }

    private void setMultiRatePlanEsnsSearchParams(PreparedStatement stmt, TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneMultiRatePlanEsn.getxPriority())) {
            stmt.setString(index++, tracfoneOneMultiRatePlanEsn.getxPriority());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneMultiRatePlanEsn.getxReason())) {
            stmt.setString(index++, "%" + tracfoneOneMultiRatePlanEsn.getxReason().toUpperCase() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneMultiRatePlanEsn.getxProductId())) {
            stmt.setString(index++, tracfoneOneMultiRatePlanEsn.getxProductId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneMultiRatePlanEsn.getDelFlag())) {
            stmt.setString(index++, tracfoneOneMultiRatePlanEsn.getDelFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneMultiRatePlanEsn.getxEsn())) {
            stmt.setString(index++, tracfoneOneMultiRatePlanEsn.getxEsn());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneMultiRatePlanEsn.getxServicePlanId())) {
            stmt.setString(index, tracfoneOneMultiRatePlanEsn.getxServicePlanId());
        }
    }

    private String getSearchMultiRatePlanEsnQuery(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_MULTI_RATE_PLAN_ESNS);
        if (!StringUtils.isNullOrEmpty(tracfoneOneMultiRatePlanEsn.getxPriority())) {
            builder.append("X_PRIORITY = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneMultiRatePlanEsn.getxReason())) {
            builder.append("UPPER(X_REASON) LIKE ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneMultiRatePlanEsn.getxProductId())) {
            builder.append("X_PRODUCT_ID = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneMultiRatePlanEsn.getDelFlag())) {
            builder.append("DEL_FLAG = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneMultiRatePlanEsn.getxEsn())) {
            builder.append("X_ESN = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneMultiRatePlanEsn.getxServicePlanId())) {
            builder.append("X_SERVICE_PLAN_ID = ?");
            builder.append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search query for Multi Rate Plan Esns is : " + searchQuery);
        return searchQuery;
    }

    @Override
    public TFOneGeneralResponse bulkDeleteMultiRatePlanEsn(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsns, int userId) throws TracfoneOneException {
         try (Connection con = dbControllerEJB.getDataSource(tracfoneOneMultiRatePlanEsns.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_MULTI_RATE_PLAN_ESNS);) {
                stmt.setString(1, tracfoneOneMultiRatePlanEsns.getxEsn());
                stmt.setString(2, tracfoneOneMultiRatePlanEsns.getxServicePlanId());

            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Multi Rate Plan Esns", "Deleted Multi Rate Plan Esns Object " + tracfoneOneMultiRatePlanEsns, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneMultiRatePlanEsns.getxEsn());
    }
}