package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneSearchCarrierFeatureModel;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchServicePlanModel;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneRatePlan;
import com.tracfone.service.model.response.TFOneRatePlanExtensionConfig;

import javax.ejb.Local;
import java.util.List;
import java.util.Map;

@Local
public interface TracfoneServicePlanControllerLocal {
    List<TFOneCarrierServicePlan> searchServicePlans(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException;

    List<TFOneCarrierFeature> viewServicePlanCarrierFeatures(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException;

    List<TFOneCarrierServicePlan> getServicePlansForCarrier(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException;

    List<TFOneRatePlan> getCarrierRatePlans(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException;

    List<TFOneCarrierFeature> getCarrierFeatureLinks(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException;

    List<TFOneRatePlanExtensionConfig> getAllProfileFeatures(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException;

    List<TFOneCarrierProfileBucket> searchCarrierProfileBuckets(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException;

    List<TFOneCarrierProfileChildBucket> searchCarrierProfileChildBuckets(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException;

    Map<String, Integer> mirrorServicePlan(TracfoneOneSearchPlanModel tfSearchModel, int userId) throws TracfoneOneException;

    List<String> getAllServicePlanCarrierNames(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException;

    List<TFOneCarrierServicePlan> getServicePlansForCopy(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException;

    TFOneGeneralResponse getCarrierFeatureCount(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws TracfoneOneException;

    List<TFOneCarrierFeature> getCarrierFeatureOrderings(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws TracfoneOneException;

    Map<String, Integer> mirrorServicePlanMap(TracfoneOneSearchPlanModel searchPlanModel, int userId) throws TracfoneOneException;
}
