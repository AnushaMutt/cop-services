package com.tracfone.service.model.request;

import javax.validation.constraints.Size;

/**
 * TABLE: mapinfo.EG_BPTECH
 */
public class TracfoneOneBPTech {
    private String dbEnv;
    @Size(max = 20, message = "Techkey cannot have more than 20 characters")
    private String techkey;
    @Size(max = 20, message = "Service cannot have more than 20 characters")
    private String service;
    @Size(max = 20, message = "BPCode cannot have more than 20 characters")
    private String bpCode;
    @Size(max = 150, message = "Product Key cannot have more than 150 characters")
    private String productKey;

    private String oldTechkey;
    private String oldService;
    private String oldBpCode;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getTechkey() {
        return techkey;
    }

    public void setTechkey(String techkey) {
        this.techkey = techkey;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getBpCode() {
        return bpCode;
    }

    public void setBpCode(String bpCode) {
        this.bpCode = bpCode;
    }

    public String getProductKey() {
        return productKey;
    }

    public void setProductKey(String productKey) {
        this.productKey = productKey;
    }

    public String getOldTechkey() {
        return oldTechkey;
    }

    public void setOldTechkey(String oldTechkey) {
        this.oldTechkey = oldTechkey;
    }

    public String getOldService() {
        return oldService;
    }

    public void setOldService(String oldService) {
        this.oldService = oldService;
    }

    public String getOldBpCode() {
        return oldBpCode;
    }

    public void setOldBpCode(String oldBpCode) {
        this.oldBpCode = oldBpCode;
    }

    @Override
    public String toString() {
        return "TracfoneOneBPTech{" +
                "dbEnv='" + dbEnv + '\'' +
                ", techkey='" + techkey + '\'' +
                ", service='" + service + '\'' +
                ", bpCode='" + bpCode + '\'' +
                ", productKey='" + productKey + '\'' +
                ", oldTechkey='" + oldTechkey + '\'' +
                ", oldService='" + oldService + '\'' +
                ", oldBpCode='" + oldBpCode + '\'' +
                '}';
    }
}
