package com.tracfone.service.event.processors;

import com.tracfone.ejb.entity.TFOneReport;
import com.tracfone.ejb.entity.session.TFOneReportFacadeLocal;
import com.tracfone.service.model.event.TracfoneOneReportRequest;
import java.util.Date;
import javax.ejb.Asynchronous;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.enterprise.event.Observes;
import javax.inject.Named;

@Named
@Singleton
public class ReportEventProcessor {

    @EJB
    TFOneReportFacadeLocal reportEJB;
    
    @Asynchronous 
    public void observeItemEvent(@Observes TracfoneOneReportRequest tracfoneOneReportRequest) {
            TFOneReport tfoneEjbReport = new TFOneReport();
            tfoneEjbReport.setCreateddate(new Date());
            tfoneEjbReport.setJsonResponse(tracfoneOneReportRequest.getJsonResponse());
            tfoneEjbReport.setReportName(tracfoneOneReportRequest.getReportName());
            reportEJB.create(tfoneEjbReport);
    }
}