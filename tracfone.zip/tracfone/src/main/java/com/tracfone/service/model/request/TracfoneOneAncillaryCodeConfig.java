package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * x_rp_ancillary_code_config
 *
 * @author Pritesh Singh
 */
public class TracfoneOneAncillaryCodeConfig {
    private String dbEnv;
    @NotNull(message = "Extension Obj Id cannot be null")
    @Size(min = 1, message = "Extension Obj Id cannot be blank")
    @Digits(integer = 38, fraction = 0, message = "Extension Obj Id must be a number")
    private String extensionObjId;
    @NotNull(message = "Profile Id cannot be null")
    @Size(min = 1, message = "Profile Id cannot be blank")
    @Digits(integer = 38, fraction = 0, message = "Profile Id must be a number")
    private String profileId;
    @NotNull(message = "Feature  Name cannot be null")
    @Size(min = 1, message = "Feature Name cannot be blank")
    @Size(max = 200, message = "Feature Name cannot have more than 200 characters")
    private String featureName;
    @NotNull(message = "Feature Value cannot be null")
    @Size(min = 1, message = "Feature Value cannot be blank")
    @Size(max = 200, message = "Feature Value cannot have more than 200 characters")
    private String featureValue;
    @NotNull(message = "Feature Requirement cannot be null")
    @Size(min = 1, message = "Feature Requirement cannot be blank")
    @Size(max = 500, message = "Feature Requirement cannot have more than 500 characters")
    private String featureRequirement;
    @NotNull(message = "Toggle Flag  cannot be null")
    @Size(min = 1, message = "Toggle Flag cannot be blank")
    @Size(max = 1, message = "Toggle Flag cannot have more than 1 characters")
    private String toggleFlag;
    @Size(max = 500, message = "Notes cannot have more than 500 characters")
    private String notes;
    @NotNull(message = "Restrict SUI Flag  cannot be null")
    @Size(min = 1, message = "Restrict SUI Flag cannot be blank")
    @Size(max = 1, message = "Restrict SUI Flag cannot have more than 1 characters")
    private String restrictSUIFlag;
    @NotNull(message = "Display SUI Flag cannot be null")
    @Size(min = 1, message = "Display SUI Flag cannot be blank")
    @Size(max = 1, message = "Display SUI Flag cannot have more than 1 characters")
    private String displaySUIFlag;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getExtensionObjId() {
        return extensionObjId;
    }

    public void setExtensionObjId(String extensionObjId) {
        this.extensionObjId = extensionObjId;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public String getFeatureValue() {
        return featureValue;
    }

    public void setFeatureValue(String featureValue) {
        this.featureValue = featureValue;
    }

    public String getFeatureRequirement() {
        return featureRequirement;
    }

    public void setFeatureRequirement(String featureRequirement) {
        this.featureRequirement = featureRequirement;
    }

    public String getToggleFlag() {
        return toggleFlag;
    }

    public void setToggleFlag(String toggleFlag) {
        this.toggleFlag = toggleFlag;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getRestrictSUIFlag() {
        return restrictSUIFlag;
    }

    public void setRestrictSUIFlag(String restrictSUIFlag) {
        this.restrictSUIFlag = restrictSUIFlag;
    }

    public String getDisplaySUIFlag() {
        return displaySUIFlag;
    }

    public void setDisplaySUIFlag(String displaySUIFlag) {
        this.displaySUIFlag = displaySUIFlag;
    }

    @Override
    public String toString() {
        return "TracfoneOneAncillaryCodeConfig{" +
                "dbEnv='" + dbEnv + '\'' +
                ", extensionObjId='" + extensionObjId + '\'' +
                ", profileId='" + profileId + '\'' +
                ", featureName='" + featureName + '\'' +
                ", featureValue='" + featureValue + '\'' +
                ", featureRequirement='" + featureRequirement + '\'' +
                ", toggleFlag='" + toggleFlag + '\'' +
                ", notes='" + notes + '\'' +
                ", restrictSUIFlag='" + restrictSUIFlag + '\'' +
                ", displaySUIFlag='" + displaySUIFlag + '\'' +
                '}';
    }
}
