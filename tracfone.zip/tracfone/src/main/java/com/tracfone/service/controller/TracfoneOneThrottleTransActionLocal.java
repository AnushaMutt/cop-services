package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneThrottleRework;
import com.tracfone.service.model.request.TracfoneOneThrottleTrans;
import com.tracfone.service.model.request.TracfoneOneThrottleTransaction;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneThrottlePolicy;
import com.tracfone.service.model.response.TFOneThrottleTransSearchResult;

import javax.ejb.Local;
import java.util.List;

/**
 * @author Gaurav.Sharma
 */
@Local
public interface TracfoneOneThrottleTransActionLocal {

    TFOneThrottleTransSearchResult viewThrottleTransaction(TracfoneOneThrottleTransaction throttleTransactions) throws TracfoneOneException;

    TFOneGeneralResponse reworkRequeue(TracfoneOneThrottleRework tfThrottleTransaction, String type, int userId) throws TracfoneOneException;

    TFOneGeneralResponse reworkRequeueAll(TracfoneOneThrottleRework tfThrottleTransaction, String type, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertThrottleTransaction(TracfoneOneThrottleTrans tfThrottleTrans, int userId) throws TracfoneOneException;

    List<TFOneThrottlePolicy> getPolicyName(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse insertTTONThrottleTrans(TracfoneOneThrottleTrans tfThrottleTrans, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertTTOFFThrottleTrans(TracfoneOneThrottleTrans tfThrottleTrans, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertHSBONThrottleTrans(TracfoneOneThrottleTrans tfThrottleTrans, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertHSBOFThrottleTrans(TracfoneOneThrottleTrans tfThrottleTrans, int userId) throws TracfoneOneException;

    List<String> getUsageTierId(String dbEnv) throws TracfoneOneException;

    List<String> getCos(String dbEnv) throws TracfoneOneException;

    List<String> getPriority(String dbEnv, String cos) throws TracfoneOneException;

    List<String> getThresholdEntitlement(String dbEnv, String columnName) throws TracfoneOneException;

    List<String> getRuleId(String dbEnv, String objId) throws TracfoneOneException;
    
    List<String> getAllObjIdsFromSearch(TracfoneOneThrottleRework tfThrottleTransaction) throws TracfoneOneException;

}
