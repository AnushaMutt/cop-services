/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.report.workers;

import com.tracfone.service.model.report.TFOneReportGraphMonitor;
import com.tracfone.service.util.TracfoneOneConstantReport;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.annotation.Resource;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Stateless;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author druiz
 */
@Stateless
public class MonitorGraphWorkerBean {

    @Resource(lookup = "jndi/cop_report")
    private DataSource dataSourceReports;

    private AtomicBoolean busy = new AtomicBoolean(false);

    private static final Logger LOGGER = LogManager.getLogger(MonitorGraphWorkerBean.class);

    @Lock(LockType.READ)
    public List<TFOneReportGraphMonitor> runMonitorGraphReport() {
        List<TFOneReportGraphMonitor> monitorGraphReport = new ArrayList<>();
        if (!busy.compareAndSet(false, true)) {
            return monitorGraphReport;
        }

        try (Connection con = dataSourceReports.getConnection();
             PreparedStatement stmt = con.prepareStatement(TracfoneOneConstantReport.REPORT_SQL_MONITOR_GRAPH_VIEW);
             ResultSet resultSet = stmt.executeQuery();) {
            while (resultSet.next()) {
                TFOneReportGraphMonitor tfOneReportGraphMonitor = new TFOneReportGraphMonitor();
                tfOneReportGraphMonitor.setTemplate(resultSet.getString("TEMPLATE"));
                tfOneReportGraphMonitor.setTransType(resultSet.getString("TRANS_TYPE"));
                tfOneReportGraphMonitor.setOrderType(resultSet.getString("ORDER_TYPE"));
                tfOneReportGraphMonitor.setStatus(resultSet.getString("STATUS"));
                tfOneReportGraphMonitor.setCount(resultSet.getString("COUNT"));
                monitorGraphReport.add(tfOneReportGraphMonitor);
            }
        } catch (Exception e) {
            LOGGER.error("Monitor Graph report retrival error. EX: ", e);
        } finally {
            busy.set(false);
        }
        return monitorGraphReport;
    }

}
