/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.util;

/**
 * @author user
 */
public interface TracfoneOneConstantCarrier {

    String TRACFONE_BALANCE_INQUIRY_ERROR = "TFE601";
    String TRACFONE_BALANCE_INQUIRY_ERROR_MESSAGE = "Exception occurred when performing Inquiry.";

    String TRACFONE_BALANCE_INQUIRY_RESPONSE_ERROR = "TFE602";
    String TRACFONE_BALANCE_INQUIRY_RESPONSE_ERROR_MESSAGE = "Inquiry did not return a status 200.";

    String TRACFONE_BALANCE_INQUIRY_CANCELED = "CANCELED";
    String TRACFONE_BALANCE_INQUIRY_DEACTIVE = "DEACTIVE";
}
