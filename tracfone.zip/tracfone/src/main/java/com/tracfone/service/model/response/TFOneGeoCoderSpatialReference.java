package com.tracfone.service.model.response;

public class TFOneGeoCoderSpatialReference {
    private String wkid;
    private String latestWkid;

    public String getWkid() {
        return wkid;
    }

    public void setWkid(String wkid) {
        this.wkid = wkid;
    }

    public String getLatestWkid() {
        return latestWkid;
    }

    public void setLatestWkid(String latestWkid) {
        this.latestWkid = latestWkid;
    }

    @Override
    public String toString() {
        return "TFOneGeoCoderSpatialReference{" +
                "wkid='" + wkid + '\'' +
                ", latestWkid='" + latestWkid + '\'' +
                '}';
    }
}
