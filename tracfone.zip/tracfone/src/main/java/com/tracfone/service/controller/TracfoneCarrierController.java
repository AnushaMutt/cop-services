
package com.tracfone.service.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneCarrierSubscriber;
import com.tracfone.service.model.response.TFOneCarrierSubscriber;
import com.tracfone.service.model.response.TFOneFeatures;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import com.tracfone.service.util.TracfoneOneConstantCarrier;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Stateless
public class TracfoneCarrierController implements TracfoneCarrierControllerLocal, TracfoneOneConstantCarrier {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneCarrierController.class);

    @EJB
    private TracfoneTransactionWizardControllerLocal tracfoneOneTransactionWizardController;

    @Override
    public TFOneCarrierSubscriber inquireSubscriber(int userId, final TracfoneOneCarrierSubscriber subscriberInfo) throws TracfoneOneException {
        if (StringUtils.isNullOrEmpty(subscriberInfo.getMin()) && StringUtils.isNullOrEmpty(subscriberInfo.getSim()) && StringUtils.isNullOrEmpty(subscriberInfo.getAccountNumber()))
            throw new TracfoneOneException("INVALID_SEARCH_PARAM", "No valid MIN or SIM or Account Number found.");

        if (!StringUtils.isNullOrEmpty(subscriberInfo.getAccountNumber())) {
            Map<String, String> accountNumberMap = new HashMap<>();
            accountNumberMap.put("accountNumber", subscriberInfo.getAccountNumber());

            List<Map<String, String>> additionalFields = new ArrayList<>();
            additionalFields.add(accountNumberMap);
            subscriberInfo.setAdditionalFields(additionalFields);
        } else if (subscriberInfo.isQuerySimV2()) {
            Map<String, String> sim2 = new HashMap<>();
            sim2.put("sim2", subscriberInfo.getSim());

            List<Map<String, String>> additionalFields = new ArrayList<>();
            additionalFields.add(sim2);
            subscriberInfo.setAdditionalFields(additionalFields);
        }

        TFOneCarrierSubscriber tfOneCarrierSubscriber = balanceInquiryService(subscriberInfo);

        LOGGER.error("tfOneCarrierSubscriber right before addFeatureNamesToSubscriberProfile " , tfOneCarrierSubscriber);
        // Check added for SIM validation. Additional fields will be null for balance inquiry

        if(tfOneCarrierSubscriber != null) {
            if (tfOneCarrierSubscriber.getAdditionalFields() == null) {
                if (!StringUtils.isNullOrEmpty(tfOneCarrierSubscriber.getCarrierErrorMessage()) || tfOneCarrierSubscriber.getRateplanProfile() == null) {
                    if(!subscriberInfo.isBulkInquiry()) {
                        throw new TracfoneOneException("Error Response from service", tfOneCarrierSubscriber.getCarrierErrorMessage());
                    } else {
                        tfOneCarrierSubscriber.setCarrierErrorMessage("Error Response from service "+ tfOneCarrierSubscriber.getCarrierErrorMessage());
                        tfOneCarrierSubscriber.setMin(subscriberInfo.getMin());
                        tfOneCarrierSubscriber.setSim(subscriberInfo.getSim());
                    }
                }

                try {
                    if (!TRACFONE_BALANCE_INQUIRY_CANCELED.equalsIgnoreCase(tfOneCarrierSubscriber.getLineStatus()) &&
                            !TRACFONE_BALANCE_INQUIRY_DEACTIVE.equalsIgnoreCase(tfOneCarrierSubscriber.getLineStatus())) {
                        addFeatureNamesToSubscriberProfile(tfOneCarrierSubscriber);
                        sortSubcribersByFeatureValue(tfOneCarrierSubscriber.getRateplanProfile().getRatePlanProfile().get(0));
                    }
                } catch (Exception e) {
                    if(!subscriberInfo.isBulkInquiry()) {
                        LOGGER.error(TRACFONE_BALANCE_INQUIRY_ERROR_MESSAGE + tfOneCarrierSubscriber, e);
                        throw new TracfoneOneException(TRACFONE_BALANCE_INQUIRY_ERROR, TRACFONE_BALANCE_INQUIRY_ERROR_MESSAGE, e);
                    } else {
                        tfOneCarrierSubscriber.setCarrierErrorMessage(TRACFONE_BALANCE_INQUIRY_ERROR + " " + TRACFONE_BALANCE_INQUIRY_ERROR_MESSAGE);
                        tfOneCarrierSubscriber.setSim(subscriberInfo.getSim());
                        tfOneCarrierSubscriber.setMin(subscriberInfo.getMin());
                    }
                }
            }
        }
        return tfOneCarrierSubscriber;
    }


    @Override
    public List<TFOneCarrierSubscriber> bulkInquiry(int userId, TracfoneOneCarrierSubscriber subscriberInfo) throws TracfoneOneException {
        List<TFOneCarrierSubscriber> subscribers = new ArrayList<>();
        TFOneCarrierSubscriber tfOneCarrierSubscriber = null;
        String simNum = subscriberInfo.getSim();
        String minValues = subscriberInfo.getMin();
        subscriberInfo.setBulkInquiry(true);
        if(!StringUtils.isNullOrEmpty(simNum)) {
            for (String sim : simNum.split(",")) {
                tfOneCarrierSubscriber = new TFOneCarrierSubscriber();
                subscriberInfo.setSim(sim);
                subscriberInfo.setMin("");
                tfOneCarrierSubscriber = inquireSubscriber(userId, subscriberInfo);
                subscribers.add(tfOneCarrierSubscriber);
            }
        }
        if(!StringUtils.isNullOrEmpty(minValues)){
            for (String min : minValues.split(",")) {
                tfOneCarrierSubscriber = new TFOneCarrierSubscriber();
                subscriberInfo.setMin(min);
                subscriberInfo.setSim("");
                tfOneCarrierSubscriber = inquireSubscriber(userId, subscriberInfo);
                subscribers.add(tfOneCarrierSubscriber);
            }
        }

        return subscribers;
    }

    /*
     *  Adds feature Names to the TFOneCarrier Subscriber, based on Subscribers current features
     */
    public void addFeatureNamesToSubscriberProfile(TFOneCarrierSubscriber subscriber) throws TracfoneOneException {
        List<TFOneFeatures> featureValues = subscriber.getRateplanProfile().getRatePlanProfile().get(0).getFeatures();
        String featureValueString = "";
        for (TFOneFeatures feature : featureValues) {
            featureValueString += String.format("'%s',", feature.getFeatureValue());
        }

        if (featureValueString.length() > 0) {
            featureValueString = featureValueString.substring(0, featureValueString.length() - 1);
        }

        HashMap<String, String> featuresMap = tracfoneOneTransactionWizardController.getMatchingFeaturesNames(featureValueString);
        TFOneRatePlanProfile tfOneSubscriberProfile = subscriber.getRateplanProfile().getRatePlanProfile().get(0);

        for (TFOneFeatures feature : tfOneSubscriberProfile.getFeatures()) {
            if (featuresMap.containsKey(feature.getFeatureValue())) {
                feature.setFeatureName(featuresMap.get(feature.getFeatureValue()));
            }
        }

    }

    /*
     *  Sorts TFOneCarrierSubriber's TFOneRatePlanProfile by FeatureValue
     */
    public void sortSubcribersByFeatureValue(TFOneRatePlanProfile subscriber) {
        Comparator<TFOneFeatures> compareByFeatureValue = new Comparator<TFOneFeatures>() {
            @Override
            public int compare(TFOneFeatures o1, TFOneFeatures o2) {
                return o1.getFeatureValue().compareTo(o2.getFeatureValue());
            }
        };

        Collections.sort(subscriber.getFeatures(), compareByFeatureValue);
    }

    /**
     * This method makes a call to the balance inquiry wrapper microservice for TMO carrier.
     *
     * @param requestSubscriber
     * @return
     * @throws TracfoneOneException
     */
    public TFOneCarrierSubscriber balanceInquiryService(TracfoneOneCarrierSubscriber requestSubscriber) throws TracfoneOneException {
        TFOneCarrierSubscriber responseSubscriber = null;
        Gson gson = new GsonBuilder().serializeNulls().create();

        try {
            CloseableHttpClient client = HttpClients.createDefault();
            HttpPost httpPost = new HttpPost(requestSubscriber.getCarrierUrl());
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");
            httpPost.setEntity(new StringEntity(gson.toJson(requestSubscriber)));

            CloseableHttpResponse response = client.execute(httpPost);
            String payload = getPayload(response);
            LOGGER.debug("Payload from balance inquiry call is " , payload);
            LOGGER.info("Response from balance inquiry call is " , response);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                responseSubscriber = gson.fromJson(payload, TFOneCarrierSubscriber.class);
                LOGGER.debug("ResponseSubscriber " , responseSubscriber);
            } else {
                if(!requestSubscriber.isBulkInquiry()) {
                    LOGGER.error(TRACFONE_BALANCE_INQUIRY_RESPONSE_ERROR, payload);
                    throw new TracfoneOneException(TRACFONE_BALANCE_INQUIRY_RESPONSE_ERROR, TRACFONE_BALANCE_INQUIRY_RESPONSE_ERROR_MESSAGE);
                } else {
                    responseSubscriber = gson.fromJson(payload, TFOneCarrierSubscriber.class);
                }
            }
            client.close();
        } catch (Exception e) {
            if(!requestSubscriber.isBulkInquiry()) {
                LOGGER.error(TRACFONE_BALANCE_INQUIRY_ERROR, TRACFONE_BALANCE_INQUIRY_ERROR_MESSAGE, e);
                throw new TracfoneOneException(TRACFONE_BALANCE_INQUIRY_ERROR, TRACFONE_BALANCE_INQUIRY_ERROR_MESSAGE, e);
            } else {
                responseSubscriber.setCarrierErrorMessage(TRACFONE_BALANCE_INQUIRY_ERROR + " " + TRACFONE_BALANCE_INQUIRY_ERROR_MESSAGE);
                responseSubscriber.setMin(requestSubscriber.getMin());
                responseSubscriber.setSim(requestSubscriber.getSim());
            }
        }
        if(requestSubscriber != null) {
            setLineFoundBy(requestSubscriber.getMin(), responseSubscriber);
        }
        return responseSubscriber;
    }

    private void setLineFoundBy(String min, TFOneCarrierSubscriber responseSubscriber) {
        if (StringUtils.isNullOrEmpty(min)) {
            responseSubscriber.setLineFoundBy("SIM");
        } else {
            responseSubscriber.setLineFoundBy("MIN");
        }
    }

    private String getPayload(HttpResponse response) throws IOException {
        String payload = "";
        String line = "";
        InputStreamReader inputStreamReader = new InputStreamReader((response.getEntity().getContent()));
        BufferedReader buff = new BufferedReader(inputStreamReader);
        try {
            while ((line = buff.readLine()) != null) {
                payload += line;
            }
        } finally {
            buff.close();
            inputStreamReader.close();
        }
        return payload;
    }

}