
package com.tracfone.service.controller;

import com.tracfone.ejb.entity.Group;
import com.tracfone.ejb.entity.GroupActions;
import com.tracfone.ejb.entity.Tracfoneoneuser;
import com.tracfone.ejb.entity.Usergroups;
import com.tracfone.service.model.request.TracfoneOneAction;
import com.tracfone.service.model.request.TracfoneOneGroup;
import com.tracfone.service.model.request.TracfoneOneUserProfile;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;

/**
 *
 * @author druiz
 */
@Stateless
public class TracfoneEJBAdminUtil implements TracfoneEJBAdminUtilLocal {
  
    @Override
    public Tracfoneoneuser buildUserEntity(TracfoneOneUserProfile userProfileRequestModel, Tracfoneoneuser tracfoneUser) {
        tracfoneUser.setDescription(userProfileRequestModel.getTfUser().getDescription());
        tracfoneUser.setEmail(userProfileRequestModel.getTfUser().getEmail());
        tracfoneUser.setId(userProfileRequestModel.getTfUser().getUserId());
        tracfoneUser.setRoleId(userProfileRequestModel.getTfRole().getRoleId());
        tracfoneUser.setUsername(userProfileRequestModel.getTfUser().getUserName());
        return tracfoneUser;
    }

    @Override
    public Group buildGroupEntity(TracfoneOneGroup groupRequestModel, Group tracfoneGroup) {
        
        tracfoneGroup.setId(groupRequestModel.getGroupId());
        tracfoneGroup.setGroupname(groupRequestModel.getGroupName());
        tracfoneGroup.setDescription(groupRequestModel.getGroupDescription());
        tracfoneGroup.setEnabled(TracfoneOneGroup.ENABLED);               
        return tracfoneGroup;
    }
    
    @Override
    public Group buildNewGroupEntity(TracfoneOneGroup groupRequestModel) {
        
        Group tracfoneGroup = new Group();
        tracfoneGroup.setId(groupRequestModel.getGroupId());
        tracfoneGroup.setGroupname(groupRequestModel.getGroupName());
        tracfoneGroup.setDescription(groupRequestModel.getGroupDescription());
        tracfoneGroup.setEnabled(TracfoneOneGroup.ENABLED);               
        return tracfoneGroup;
    }
    
    /**
     * 
     * @param userId
     * @param existingGroups
     * @param groupsInRequest
     * @return 
     */
    @Override
    public List<Usergroups> getUserGroupsToAdd(Integer userId, List<Usergroups> existingGroups, List<TracfoneOneGroup> groupsInRequest) {
        List<Usergroups> groupsToAdd = new ArrayList<>();
        List<Integer> existingGroupIDs = new ArrayList<>();
        
        // Get List of IDs of existing Actions.
        for(Usergroups existingGroup: existingGroups){
            existingGroupIDs.add(existingGroup.getGroupid());
        }
                
        for(TracfoneOneGroup requestedgroup: groupsInRequest){
            
            // Requested group not in existing, add it.
            if(!existingGroupIDs.contains(requestedgroup.getGroupId())){         
                Usergroups userGroup = new Usergroups();
                userGroup.setGroupid(requestedgroup.getGroupId());
                userGroup.setUserid(userId);
                
                groupsToAdd.add(userGroup);
            }
        }
        
        return groupsToAdd;
    }

    @Override
    public List<Usergroups> getUserGroupsToDelete(List<Usergroups> existingGroups, List<TracfoneOneGroup> groupsInRequest) {
        List<Usergroups> groupsToDelete = new ArrayList<>();
        List<Integer> groupsIdsInRequest = new ArrayList<>();
        
        // Get Action IDs of requested actions.
        for(TracfoneOneGroup group: groupsInRequest){
            groupsIdsInRequest.add(group.getGroupId());
        }
        
        for(Usergroups existingGroup: existingGroups){
      
            // If the requested action id does not exist for that group, add it.
            if(!groupsIdsInRequest.contains(existingGroup.getGroupid())){
                //System.out.println("Group ID to DELETE: " + existingGroup.getGroupid());
                groupsToDelete.add(existingGroup);
            }
        }
        
        return groupsToDelete;
    }
    
    /**
     * 
     * @param groupId
     * @param existingActions
     * @param actionsInRequest
     * @return 
     */
    @Override
    public List<GroupActions> getGroupActionsIdToAdd(Integer groupId, List<GroupActions> existingActions, List<TracfoneOneAction> actionsInRequest) {
        List<GroupActions> actionsToAdd = new ArrayList<>();
        List<Integer> existingActionsIDs = new ArrayList<>();
        
        // Get List of IDs of existing Actions.
        for(GroupActions existingAction: existingActions){
            existingActionsIDs.add(existingAction.getActionId());
        }        
        
        for(TracfoneOneAction requestedAction: actionsInRequest){
            
            if(!existingActionsIDs.contains(requestedAction.getActionId())){              
                GroupActions groupActions = new GroupActions();
                groupActions.setActionId(requestedAction.getActionId());
                groupActions.setGroupId(groupId);
                
                actionsToAdd.add(groupActions);
            }
        }
        
        return actionsToAdd;
    }

    @Override
    public List<GroupActions> getGroupActionsIdToDelete(List<GroupActions> existingActionIDs, List<TracfoneOneAction> actionsInRequest) {
        List<GroupActions> actionsToDelete = new ArrayList<>();
        List<Integer> actionsIdInRequest = new ArrayList<>();
        
        // Get Action IDs of requested actions.
        for(TracfoneOneAction action: actionsInRequest){
            actionsIdInRequest.add(action.getActionId());
        }
        
        for(GroupActions existingAction: existingActionIDs){
      
            // If the requested action id does not exist for that group, add it.
            if(!actionsIdInRequest.contains(existingAction.getActionId())){
                actionsToDelete.add(existingAction);
            }
        }
        
        return actionsToDelete;
    }
}
