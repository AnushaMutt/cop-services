
package com.tracfone.service.model.report;


/**
 * @author spulavarthy
 */
public class TracfoneAdhocReportRequest {
    
    private String transactionType;
    private String fromDate;
    private String toDate;

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }
    
}
