package com.tracfone.service.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Srinivas Murthy Pulavarthy
 */
public interface TracfoneOneConstantInsertWizard {

    /**
     * Pattern for Carrier Name
     */
    public final String CARRIER_NAME_PATTERN = "^[a-zA-Z]+$";
    public final String PROFILE_ID_PATTERN = "^[0-9]+$";

    /**
     * Parameters values for SQL's
     */
    public final String AVAILABLE_CARRIERS_SQL_PARAMETER = "CARRIER_NAME";
    public final String PARAM_RATE_PLAN_SQL_PARAMETER = "RATE_PLAN";

    public final String TRACFONE_CARRIER_NAMES_ERROR = "TFE701";
    public final String TRACFONE_CARRIER_NAMES_ERROR_MESSAGE = "Unable to retrieve carrier names";

    public final String TRACFONE_INVALID_CARRIER_NAME_ERROR = "TFE702";
    public final String TRACFONE_INVALID_CARRIER_NAME_ERROR_MESSAGE = "Invalid Carrier Name";

    public final String TRACFONE_RATE_PLAN_ERROR = "TFE703";
    public final String TRACFONE_RATE_PLAN_ERROR_MESSAGE = "Unable to retrieve carrier rate plans";

    public final String TRACFONE_FEATURES_ERROR = "TFE704";
    public final String TRACFONE_FEATURES_ERROR_MESSAGE = "Unable to retrieve features rate plans";

    public final String TRACFONE_BUCKETS_ERROR = "TFE705";
    public final String TRACFONE_BUCKETS_ERROR_MESSAGE = "Unable to retrieve buckets for the selected rate plan";

    public final String TRACFONE_EXTENDDEACTDATE_ERROR = "TFE706";
    public final String TRACFONE_EXTENDDEACTDATE_ERROR_MESSAGE = "Failed to update deactivation date for transaction";
    
    public final String TRACFONE_INSERT_WIZARD_TRANSACTION_ERROR = "TFE707";
    public final String TRACFONE_INSERT_WIZARD_TRANSACTION_ERROR_MESSAGE = "Unable to insert the Transaction for the selected rate plan";
    
    public final String TRACFONE_CARRIER_ADDIONAL_FIELDS_ERROR = "TFE708";
    public final String TRACFONE_CARRIER_ADDIONAL_FIELDS_MESSAGE = "Failed to get additional details for carrier";
    
    public final String TRACFONE_PROFILE_ID_SERVICE_PLANS_ERROR = "TFE709";
    public final String TRACFONE_PROFILE_ID_SERVICE_PLANS_MESSAGE = "Failed to get service plans for the profile";
    
    public final String TRACFONE_CARRIER_SERVICE_PLANS_ERROR = "TFE710";
    public final String TRACFONE_CARRIER_SERVICE_PLANS_MESSAGE = "Failed to get service plans for the carrier";
        
    public final String TRACFONE_CARRIER_CHILD_PLAN_ERROR = "TFE711";
    public final String TRACFONE_CARRIER_CHILD_PLAN_MESSAGE = "Failed to get child plans for the carrier";

    public final String TRACFONE_RATE_PLAN_DEFAULT_PROFILE_ERROR = "TFE712";
    public final String TRACFONE_RATE_PLAN_DEFAULT_PROFILE_ERROR_MESSAGE = "Unable to retrieve rate plans default profile";

    public final String TRACFONE_MASTER_FEATURES_ERROR = "TFE713";
    public final String TRACFONE_MASTER_FEATURES_ERROR_MESSAGE = "Unable to retrieve features";

    public final String TRACFONE_RATE_PLAN_FOR_PROFILE_ERROR = "TFE714";
    public final String TRACFONE_RATE_PLAN_FOR_PROFILE_ERROR_MESSAGE = "Unable to retrieve rate plan for profile";

    public final String TRACFONE_PROFILE_FOR_FEATURE_ERROR = "TFE715";
    public final String TRACFONE_PROFILE_FOR_FEATURE_ERROR_MESSAGE = "Unable to retrieve profiles for feature";

    /**
     * SQL queries
     */
    public final String AVAILABLE_CARRIERS_SQL = "select distinct\n"
            + " exc.feature_value as feature_value\n"
            + " from   sa.x_rp_extension_config exc\n"
            + " where  1=1\n"
            + " and exc.feature_name = #param_carrierName";

    public final String RATE_PLAN_PROFILES_SQL_listagg = "select \n"
            + "       exc2.feature_value,\n"
            + "       listagg (exc2.profile_id ||'-'||rp.profile_desc , ',') \n"
            + "WITHIN GROUP \n"
            + "(ORDER BY exc2.profile_id) profile_ids\n"
            + "from   sa.x_rp_extension_config exc join\n"
            + "       sa.x_rp_extension_config exc2 on (exc.profile_id = exc2.profile_id) join\n"
            + "       sa.x_rp_profile rp on (rp.profile_id = exc.profile_id)\n"
            + "where  1=1\n"
            + "and exc.feature_name= #param_carrierName\n"
            + "and exc.feature_value = #param_carrier\n"
            + "and exc2.feature_name = #param_featureValue\n"
            + "group by exc2.feature_value";

    public final String RATE_PLAN_PROFILES_SQL = "select \n"
            + "       exc2.feature_value,\n"
            + "       rtrim(xmlagg(XMLELEMENT(e,exc2.profile_id ||'-'||rp.profile_desc,',').EXTRACT('//text()')).GetClobVal(), ',') as profile_ids\n"
            + "from   sa.x_rp_extension_config exc join\n"
            + "       sa.x_rp_extension_config exc2 on (exc.profile_id = exc2.profile_id) join\n"
            + "       sa.x_rp_profile rp on (rp.profile_id = exc.profile_id)\n"
            + "where  1=1\n"
            + "and exc.feature_name= #param_carrierName\n"
            + "and exc.feature_value = UPPER(#param_carrier)\n"
            + "and exc2.feature_name = #param_featureValue\n"
            + "group by exc2.feature_value";

    public final String RATE_PLAN_DEFAULT_PROFILE_SQL = "select profile_id, profile_desc from sa.x_rp_profile " +
            "where profile_desc like #param_default_profile";
    
//    public final String RATE_PLAN_PROFILES_SQL_GENESIS = "select \n"
//            + "       exc2.feature_value,\n"
//            + "       rtrim(xmlagg(XMLELEMENT(e,exc2.profile_id ||'-'||rp.profile_desc,',').EXTRACT('//text()')).GetClobVal(), ',') as profile_ids\n"
//            + "from   sa.x_rp_extension_config exc join\n"
//            + "       sa.x_rp_extension_config exc2 on (exc.profile_id = exc2.profile_id) join\n"
//            + "       sa.x_rp_profile rp on (rp.profile_id = exc.profile_id) join\n"
//            + "       sa.x_rp_extension_link el on (el.profile_id = exc.profile_id) \n"
//            + "where  1=1\n"
//            + "and exc.feature_name= #param_carrierName\n"
//            + "and exc.feature_value = UPPER(#param_carrier)\n"
//            + "and exc2.feature_name = #param_featureValue\n"
//            + "group by exc2.feature_value";

    public final String CARRIER_FEATURES_SQL_OLD = "select distinct\n"
            + "       exc.feature_name,\n"
            + "       exc.feature_value,\n"
            + "       exc2.feature_name,\n"
            + "       exc2.feature_value,\n"
            + "       RP.PROFILE_DESC\n"
            + "from   sa.x_rp_extension_config exc\n"
            + "where  1=1\n"
            + "and     exc.profile_id = #param_profileId ";

    public final String CARRIER_FEATURES_SQL = "select exc.OBJID, exc.PROFILE_ID, exc.RESTRICT_SUI_FLAG, exc.DISPLAY_SUI_FLAG, exc.FEATURE_NAME, exc.FEATURE_VALUE, exc.FEATURE_REQUIREMENT, exc.TOGGLE_FLAG, rp.profile_desc \n"
            + " from sa.x_rp_extension_config exc\n"
            + " left outer join sa.x_rp_profile rp on (rp.profile_id = exc.profile_id)\n"            
            + " where  exc.profile_id = #param_profileId \n"
            + " and feature_name not in ('RATE_PLAN', 'CARRIER_NAME')";
    
    public final String CARRIER_FEATURES_WITH_DESC_SQL = "select exc.OBJID, exc.PROFILE_ID, exc.RESTRICT_SUI_FLAG, exc.DISPLAY_SUI_FLAG, exc.FEATURE_NAME, exc.FEATURE_VALUE, exc.FEATURE_REQUIREMENT, exc.TOGGLE_FLAG, rp.profile_desc \n"
        + " from sa.x_rp_extension_config exc\n"
        + " left outer join sa.x_rp_profile rp on (rp.profile_id = exc.profile_id)\n"            
        + " where  exc.profile_id = #param_profileId \n"
        + " and feature_name not in ('RATE_PLAN', 'CARRIER_NAME')";
    
    public final String SERVICE_PLANS_FOR_PROFILE_ID = "select distinct mtv.service_plan_objid ,sp.customer_price ,mtv.description \n"
        + "from  sa.SERVICE_PLAN_FEAT_PIVOT_MV mtv \n"
        + "      join sa.x_service_plan sp           on (sp.objid = mtv.service_plan_objid) \n"
        + "      join sa.mtm_sp_carrierfeatures m    on(m.x_service_plan_id = mtv.service_plan_objid) \n"
        + "      join sa.x_rp_extension_link el      on (el.CARRIER_FEATURE_OBJID = m.X_CARRIER_FEATURES_ID) \n"
        + "where 1=1 \n"
        + "     and   mtv.service_plan_group != 'ADD_ON_DATA' \n"
        + "     and   m.priority = 1 \n"
        + "     and   profile_id = #param_profile_id \n";
            
    
    public final String CARRIER_SERVICE_PLANS = "select distinct \n"
        + "       mtm.x_service_plan_id,  \n"
        + "       (select mkt_name from sa.service_plan_feat_pivot_mv where service_plan_objid = mtm.x_service_plan_id) service_plan_mkt_name, \n"
        + "       el.profile_id, \n"
        + "       rp.profile_desc \n"
        + "from   table_x_carrier_group cg,  \n"
        + "       sa.table_x_carrier tc, \n"
        + "       sa.table_x_carrier_features cf, \n"
        + "       sa.mtm_sp_carrierfeatures mtm, \n"
        + "       sa.x_rp_extension_link el, \n"
        + "       sa.x_rp_profile rp \n"
        + "where  cg.x_carrier_group2x_parent in ( select objid from table_x_parent where parent_short_name = #param_carrier_name and x_status = 'ACTIVE') \n"
        + "and    cg.objid = tc.carrier2carrier_group \n"
        + "and    tc.objid = cf.x_feature2x_carrier \n"
        + "and    cf.objid = mtm.x_carrier_features_id \n"
        + "and    cf.objid = el.carrier_feature_objid \n"
        + "and    el.profile_id = rp.profile_id";
    
    public final String CHILD_PLAN_PROFILE_FROM_CARRIER = "select distinct \n"
        + "        el.child_plan_id, \n"
        + "        ci.child_description, \n"
        + "        el.profile_id, \n"
        + "        rp.profile_desc \n"
        + " from   sa.x_rp_extension_config exc  \n"
        + " join   sa.x_rp_profile rp on (rp.profile_id = exc.profile_id) \n"
        + " join   sa.x_rp_extension_link el on (rp.profile_id = el.profile_id) \n"
        + " join   sa.child_identifier_list ci on (el.child_plan_id = ci.child_id)  \n"
        + " where  1=1 \n"
        + " and exc.feature_value = UPPER(#param_carrier_name) \n"
        + " and el.child_plan_id is not null ";
    
    public final String BUCKETS_WITH_TIERS_FOR_PROFILE_AND_SERVICE_PLAN = "select DISTINCT pb.bucket_id,pb.bucket_type, bl.description, bt.tier_value, bt.tier_behavior, bt.usage_tier_id \n"
        + "from carrier_profile_buckets pb, carrier_profile_bucket_tier bt, SA.bucket_list bl \n"
        + "WHERE 1=1 \n"
        + "and BT.CARRIER_PROFILE_BUCKETS_OBJID (+)= PB.OBJID \n"
        + "and bl.BUCKET_ID = pb.BUCKET_ID \n"
        + "and pb.profile_id = #profile_id \n"
        + "and SERVICE_PLAN_ID = #service_plan_id \n"
        + "and BUCKET_REQUIREMENT = 'ADD' \n";   
        
    public final String BUCKETS_SQL = "SELECT BUCKET_ID, BUCKET_DESC, BUCKET_TYPE FROM IG_BUCKETS WHERE RATE_PLAN = #param_ratePlan AND ACTIVE_FLAG = 'Y'";

    // TODO move this to configuration.
    public final List<String> INSERT_WIZARD_ORDERTYPES = Arrays.asList("A - Activation", "AP - Activation Payment", "CR - Credit", "CRU - Credit Unlimited", "D - Deactivation", "E - Reactivation", "MINC - Number Change","PFR - PFR", "R - Rate Plan Change", "S - Suspension", "SIMC - SIM Exchange", "SI - SIM Inquiry", "EC - Equipment Change", "UI - Unique Inquiry", "EPIR - External PIR", "IPI - Internal Port In", "PIR - Internal Port In");

    public final List<String> attTemplates = Arrays.asList("CSI_TLG");
    public final List<String> vzwTemplates = Arrays.asList("RSS", "SUREPAY");
    public final List<String> tmoTemplates = Arrays.asList("TMOBILE", "TMOUN", "TMOSM", "TMOWFM");
    
    public final String GET_CARRIER_FEATURES_VALUES = "select FEATURE_VALUE, FEATURE_NAME \n" +
        "from sa.x_rp_extension_config exc\n" +
        "WHERE EXC.feature_name not in ('RATE_PLAN', 'CARRIER_NAME')\n" +
        "AND FEATURE_VALUE IN ( "  ;
      public final String GET_CARRIER_FEATURES_VALUES_2 =   " ) GROUP BY FEATURE_VALUE, FEATURE_NAME";

    public  final  String GET_PROFILES_BY_FEATURE_REQUIREMENT= "SELECT distinct p.profile_id , p.profile_desc FROM sa.x_rp_extension_config c, sa.x_rp_profile p " +
            "where p.profile_id = c.profile_id  AND c.feature_name = ? AND c.feature_requirement = ? and " +
            "(c.PROFILE_ID in (select PROFILE_ID from sa.X_RP_EXTENSION_CONFIG where  " +
            "FEATURE_VALUE = ? and UPPER(FEATURE_NAME) = 'CARRIER_NAME'))";

    public  final  String GET_PROFILES_BY_FEATURE= "SELECT distinct p.profile_id , p.profile_desc FROM sa.x_rp_extension_config c, sa.x_rp_profile p " +
            "where p.profile_id = c.profile_id  AND c.feature_name = ? and " +
            "(c.PROFILE_ID in (select PROFILE_ID from sa.X_RP_EXTENSION_CONFIG where  " +
            "FEATURE_VALUE = ? and UPPER(FEATURE_NAME) = 'CARRIER_NAME'))";

    public  final String GET_RATEPLAN_BY_PROFILE = "SELECT  C.FEATURE_VALUE FROM sa.x_rp_extension_config c, sa.x_rp_profile p " +
            "where p.profile_id = c.profile_id  AND c.PROFILE_ID = ? and  UPPER(c.FEATURE_NAME) = 'RATE_PLAN'";

    String TRACFONE_GET_ALL_MASTER_FEATURES = "select FEATURE_NAME from sa.x_rp_feature_name_list";
          
}
