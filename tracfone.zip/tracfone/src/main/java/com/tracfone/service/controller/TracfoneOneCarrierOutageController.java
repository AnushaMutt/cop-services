package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneCarrierOutage;
import com.tracfone.service.model.request.TracfoneOneServiceType;
import com.tracfone.service.model.response.TFOneCarrierOutage;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneServiceType;
import com.tracfone.service.util.TracfoneOneConstantCarrierOutage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Stateless
public class TracfoneOneCarrierOutageController implements TracfoneOneCarrierOutageControllerLocal, TracfoneOneConstantCarrierOutage {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneCarrierOutageController.class);

    @EJB
    TracfoneOneCarrierOutageLocalAction tracfoneOneCarrierOutageAction;

    @Override
    public List<TFOneCarrierOutage> searchCarrierOutage(TracfoneOneCarrierOutage tracfoneOneCarrierOutage) throws TracfoneOneException {
        List<TFOneCarrierOutage> carrierOutages = null;
        try {
            carrierOutages = tracfoneOneCarrierOutageAction.searchCarrierOutage(tracfoneOneCarrierOutage);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_CARRIER_OUTAGES_ERROR, TRACFONE_SEARCH_CARRIER_OUTAGES_ERROR_MESSAGE, ex);
        }
        return carrierOutages;
    }

    @Override
    public TFOneGeneralResponse insertCarrierOutage(TracfoneOneCarrierOutage tracfoneOneCarrierOutage, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            TFOneGeneralResponse validateResponse = validateForZipCodeAll(tracfoneOneCarrierOutage);
            if (validateResponse != null) return validateResponse;

            List<String> duplicateZipCodes = tracfoneOneCarrierOutageAction.findDuplicateCarrierOutageZips(tracfoneOneCarrierOutage);

            List<String> zipCodesToBeInserted = new ArrayList<>(Arrays.asList(tracfoneOneCarrierOutage.getZipCode().split(",")));
            // Remove all the duplicate ones before inserting the data
            zipCodesToBeInserted.removeAll(duplicateZipCodes);

            if (!zipCodesToBeInserted.isEmpty()) {
                LOGGER.info("New Zip Code : " + zipCodesToBeInserted);
                tracfoneOneCarrierOutage.setZipCode(String.join(",", zipCodesToBeInserted));
                tracfoneOneCarrierOutageAction.insertCarrierOutage(tracfoneOneCarrierOutage, userId);
            }
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, duplicateZipCodes.toString());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_INSERT_CARRIER_OUTAGE_ERROR, TRACFONE_INSERT_CARRIER_OUTAGE_ERROR_MESSAGE, ex);
        }
        return response;
    }

    private TFOneGeneralResponse validateForZipCodeAll(TracfoneOneCarrierOutage tracfoneOneCarrierOutage) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        String zipCodesFromUI = tracfoneOneCarrierOutage.getZipCode();
        LOGGER.info("Zip Codes from UI " + tracfoneOneCarrierOutage.getZipCode());
        if (!tracfoneOneCarrierOutage.isValidate()) {
            tracfoneOneCarrierOutage.setZipCode(null);
            LOGGER.info("Going to validate for ALL and zip codes " + tracfoneOneCarrierOutage);
            List<String> searchZipCodes = tracfoneOneCarrierOutageAction.findDuplicateCarrierOutageZips(tracfoneOneCarrierOutage);
            tracfoneOneCarrierOutage.setZipCode(zipCodesFromUI);
            if (searchZipCodes.contains("ALL")) {
                LOGGER.info("Carrier Outage already exist with ALL Zip Code");
                response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "ALL exists");
            } else if (tracfoneOneCarrierOutage.getZipCode().contains("ALL") && !searchZipCodes.isEmpty()) {
                LOGGER.info("A similar Carrier Outage already exists for zip code " + searchZipCodes);
                response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, searchZipCodes.toString());
            }
        }
        LOGGER.info("Completed validation " + tracfoneOneCarrierOutage);
        return response;
    }

    @Override
    public TFOneGeneralResponse updateCarrierOutage(TracfoneOneCarrierOutage tracfoneOneCarrierOutage, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneOneCarrierOutageAction.updateCarrierOutage(tracfoneOneCarrierOutage, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_CARRIER_OUTAGE_ERROR, TRACFONE_UPDATE_CARRIER_OUTAGE_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse bulkUpdateOutages(TracfoneOneCarrierOutage tracfoneOneCarrierOutage, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneOneCarrierOutageAction.bulkUpdateOutages(tracfoneOneCarrierOutage, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_BULK_UPDATE_ERROR, TRACFONE_BULK_UPDATE_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<TFOneServiceType> viewAllServiceTypes(TracfoneOneServiceType tracfoneOneServiceType) throws TracfoneOneException {
        List<TFOneServiceType> allServiceTypes = new ArrayList<>();
        try {
            allServiceTypes = tracfoneOneCarrierOutageAction.viewAllServiceTypes(tracfoneOneServiceType);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_ALL_SERVICE_TYPES_ERROR, TRACFONE_GET_ALL_SERVICE_TYPES_ERROR_MESSAGE, ex);
        }
        return allServiceTypes;
    }

    @Override
    public TFOneGeneralResponse insertServiceType(TracfoneOneServiceType tracfoneOneServiceType, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        validateServiceTypeAlreadyExists(tracfoneOneServiceType);
        try {
            response = tracfoneOneCarrierOutageAction.insertServiceType(tracfoneOneServiceType, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_INSERT_SERVICE_TYPES_ERROR, TRACFONE_INSERT_SERVICE_TYPES_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse updateServiceType(TracfoneOneServiceType tracfoneOneServiceType, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneOneCarrierOutageAction.updateServiceType(tracfoneOneServiceType, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_SERVICE_TYPES_ERROR, TRACFONE_UPDATE_SERVICE_TYPES_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse deleteServiceType(TracfoneOneServiceType tracfoneOneServiceType, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        if (tracfoneOneCarrierOutageAction.checkServiceTypeDependencies(tracfoneOneServiceType)) {
            throw new TracfoneOneException(TRACFONE_SERVICE_TYPE_DEPENDENCY_ERROR, TRACFONE_SERVICE_TYPE_DEPENDENCY_ERROR_MESSAGE);
        }
        try {
            response = tracfoneOneCarrierOutageAction.deleteServiceType(tracfoneOneServiceType, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_SERVICE_TYPES_ERROR, TRACFONE_DELETE_SERVICE_TYPES_ERROR_MESSAGE, ex);
        }
        return response;
    }

    /**
     * @param tracfoneOneServiceType
     * @throws TracfoneOneException
     */
    private void validateServiceTypeAlreadyExists(TracfoneOneServiceType tracfoneOneServiceType) throws TracfoneOneException {
        TracfoneOneServiceType searchServiceType = new TracfoneOneServiceType();
        searchServiceType.setDbEnv(tracfoneOneServiceType.getDbEnv());
        searchServiceType.setServiceType(tracfoneOneServiceType.getServiceType().trim());
        List<TFOneServiceType> serviceTypes = tracfoneOneCarrierOutageAction.viewAllServiceTypes(searchServiceType);
        for (TFOneServiceType serviceType : serviceTypes) {
            if (null != serviceType && !StringUtils.isNullOrEmpty(serviceType.getServiceType())) {
                throw new TracfoneOneException(TRACFONE_DUPLICATE_SERVICE_TYPES_ERROR, TRACFONE_DUPLICATE_SERVICE_TYPES_ERROR_MESSAGE);
            }
        }
    }

}
