package com.tracfone.service.filter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.response.TFOneAdminUser;
import java.io.IOException;
import javax.annotation.Priority;
import javax.ejb.EJB;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

/**
 *
 * @author Srinivas Murthy P
 */
@Provider
@Secured
@Priority(Priorities.AUTHENTICATION)
public class AuthenticationFilter implements ContainerRequestFilter {

    private static final String HTTP_HEADER_AUTHTOKEN = "coptoken";
    private static final String REALM = "example";
    private static final String AUTHENTICATION_SCHEME = "header-coptoken";
    private static final String AUTHENTICATION_MESSAGE_CODE = "AE01";
    private static final String AUTHENTICATION_MESSAGE_ERROR = "Your session has changed. Please log in.";

    @EJB
    private TracfoneControllerLocal tracfoneController;

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {

        // Get the Authorization header from the request
        String authorizationHeaderToken = requestContext.getHeaderString(HTTP_HEADER_AUTHTOKEN);

        try {
            // Validate the token
            TFOneAdminUser tfUser = validateToken(authorizationHeaderToken);            
            requestContext.setSecurityContext(new TracfoneOneSecurityContext(tfUser, true));
        } catch (TracfoneOneException e) {
            abortWithUnauthorized(requestContext, e);
        }
    }

    /**
     * Abort the filter chain with a 401 status code response
     * The WWW-Authenticate header is sent along with the response
     * @param requestContext
     * @param tex 
     */
    private void abortWithUnauthorized(ContainerRequestContext requestContext, TracfoneOneException tex) {

        Gson gson = new GsonBuilder().serializeNulls().create();
        requestContext.abortWith(
                Response.status(Response.Status.UNAUTHORIZED)
                        .header(HttpHeaders.WWW_AUTHENTICATE,
                                AUTHENTICATION_SCHEME + " realm=\"" + REALM + "\"")
                        .entity(gson.toJson(new CopUIErrorResponse(AUTHENTICATION_MESSAGE_CODE, AUTHENTICATION_MESSAGE_ERROR, Response.Status.UNAUTHORIZED.getStatusCode())))
                        .build());
    }

    private TFOneAdminUser validateToken(String token) throws TracfoneOneException {
        return tracfoneController.validateToken(token);
    }
}