package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneBucketControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneProfileControllerLocal;
import com.tracfone.service.controller.TracfoneRatePlanControllerLocal;
import com.tracfone.service.controller.TracfoneServicePlanControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtension;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.request.TracfoneOneSearchCarrierFeatureModel;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneBusinessOrganization;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneDatabaseEnvironment;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneRatePlanExtension;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.validation.Valid;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * This resource file is going to be used for all services in the Mirror Service Plan
 *
 * @author Pritesh Singh
 */
@Path("mirrorserviceplan")
public class TracfoneOneMirrorServicePlanResource {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneMirrorServicePlanResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @Context
    private SecurityContext securityContext;

    @EJB
    private TracfoneControllerLocal tracfoneController;

    @EJB
    private TracfoneServicePlanControllerLocal tracfoneServicePlanController;

    @EJB
    private TracfoneRatePlanControllerLocal tracfoneRatePlanController;

    @EJB
    private TracfoneProfileControllerLocal tracfoneProfileController;

    @EJB
    private TracfoneBucketControllerLocal tracfoneBucketController;

    @GET
    @Path("serviceplanwizard/dbenvs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    public Response getDatabaseEnvironments() {
        List<TFOneDatabaseEnvironment> tfOneDatabaseEnvironment = null;
        Response response = null;
        try {
            tfOneDatabaseEnvironment = tracfoneController.getDatabaseEnvironments(getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        response = Response.ok(gson.toJson(tfOneDatabaseEnvironment), MediaType.APPLICATION_JSON).build();
        return response;
    }

    /**
     * This method is used to retrieve all service plans based on the selected
     * carrier
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("serviceplanwizard/viewserviceplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getServicePlansForCarrier(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        try {
            carrierServicePlans = tracfoneServicePlanController.getServicePlansForCarrier(tracfoneOneSearchPlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierServicePlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for carrier features
     *
     * @param tfCarrierFeatureModel
     * @return
     */
    @POST
    @Path("serviceplanwizard/searchcarrierfeatures")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierFeatures(final TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) {
        List<TFOneCarrierFeature> carrierFeatures = null;
        try {
            carrierFeatures = tracfoneRatePlanController.searchCarrierFeatures(tfCarrierFeatureModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierFeatures), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for carrier features
     *
     * @param tfCarrierFeatureModel
     * @return
     */
    @POST
    @Path("serviceplanwizard/getcarrierfeaturecount")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierFeatureCount(final TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneServicePlanController.getCarrierFeatureCount(tfCarrierFeatureModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for carrier features with ordering
     *
     * @param tfCarrierFeatureModel
     * @return
     */
    @POST
    @Path("serviceplanwizard/getcarrierfeatureorderings")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierFeatureOrderings(final TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) {
        List<TFOneCarrierFeature> carrierFeatureOrderings = null;
        try {
            carrierFeatureOrderings = tracfoneServicePlanController.getCarrierFeatureOrderings(tfCarrierFeatureModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierFeatureOrderings), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all business orgs for a drop down
     * required when adding carrier features
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("serviceplanwizard/viewbusorgs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllBusinessOrgs(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneBusinessOrganization> allBusOrgs = new ArrayList<>();
        try {
            allBusOrgs = tracfoneRatePlanController.getAllBusinessOrgs(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(allBusOrgs), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all the child plans from master table
     * child_identifier_list
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("serviceplanwizard/viewchildplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllChildPlans(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneChildPlan> childPlans = new ArrayList<>();
        try {
            childPlans = tracfoneProfileController.getAllChildPlans(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(childPlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to wild card search for profiles that match any
     * profile id or profile description entered by the user
     *
     * @param tfRatePlanProfile
     * @return
     */
    @POST
    @Path("serviceplanwizard/searchprofile")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchProfile(final TracfoneOneSearchProfileModel tfRatePlanProfile) {
        List<TFOneRatePlanProfile> tfOneRatePlanProfiles = null;
        try {
            tfOneRatePlanProfiles = tracfoneProfileController.searchProfile(tfRatePlanProfile);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneRatePlanProfiles), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to wild card search for X_RP_EXTENSION that match any
     * column entered by the user
     *
     * @param tfRatePlanExtension
     * @return
     */
    @POST
    @Path("serviceplanwizard/searchrpextensions")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchRpExtensions(final TracfoneOneRatePlanExtension tfRatePlanExtension) {
        List<TFOneRatePlanExtension> tfRatePlanExtensions = null;
        try {
            tfRatePlanExtensions = tracfoneProfileController.searchRpExtensions(tfRatePlanExtension);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfRatePlanExtensions), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieve the list of RP Extension Links on basis of Carrier Feature ObjId
     *
     * @param selectedCarrierFeatures
     * @return
     */
    @POST
    @Path("serviceplanwizard/viewcarrierfeaturelinks")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierFeatureLinks(final List<TracfoneOneCarrierFeature> selectedCarrierFeatures) {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        try {
            carrierFeatures = tracfoneRatePlanController.getCarrierFeatureLinks(selectedCarrierFeatures);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierFeatures), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for Carrier_Profile_Buckets based on service plan and profile
     *
     * @param tfOneSearchBucketModel
     * @return
     */
    @POST
    @Path("serviceplanwizard/searchcpbuckets")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierProfileBuckets(final TracfoneOneSearchBucketModel tfOneSearchBucketModel) {
        List<TFOneCarrierProfileBucket> tfOneBuckets = new ArrayList<>();
        try {
            tfOneBuckets = tracfoneBucketController.searchCarrierProfileBuckets(tfOneSearchBucketModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneBuckets), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for Carrier_Profile_Child_Buckets based on
     * service plan, profile and child plan
     *
     * @param tfOneSearchBucketModel
     * @return
     */
    @POST
    @Path("serviceplanwizard/searchcpchildbuckets")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierProfileChildBuckets(final TracfoneOneSearchBucketModel tfOneSearchBucketModel) {
        List<TFOneCarrierProfileChildBucket> tfOneBuckets = new ArrayList<>();
        try {
            tfOneBuckets = tracfoneBucketController.searchCarrierProfileChildBuckets(tfOneSearchBucketModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneBuckets), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all carriers available in
     * table_x_carrier_group based on service plan id
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("serviceplanwizard/viewcarriers")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllServicePlanCarrierNames(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<String> carrierNames = new ArrayList<>();
        try {
            carrierNames = tracfoneServicePlanController.getAllServicePlanCarrierNames(tracfoneOneSearchPlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierNames), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve service plan ids available in
     * x_service_plan that are not used in mtm_sp_carrierfeatures
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("serviceplanwizard/serviceplansforcopy")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getServicePlansForCopy(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        try {
            carrierServicePlans = tracfoneServicePlanController.getServicePlansForCopy(tracfoneOneSearchPlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierServicePlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve service plan ids available in
     * x_service_plan that are not used in mtm_sp_carrierfeatures
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("serviceplanwizard/mirrorserviceplan")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response mirrorServicePlan(@Valid final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        Map<String, Integer> copiedObjectMap;
        try {
            copiedObjectMap = tracfoneServicePlanController.mirrorServicePlan(tracfoneOneSearchPlanModel,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(copiedObjectMap), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to mirror service plan id available in
     * x_service_plan that are not used in mtm_sp_carrierfeatures
     *
     * @param searchPlanModel
     * @return
     */
    @POST
    @Path("serviceplanwizard/mirrorserviceplanmap")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response mirrorServicePlanMap(final TracfoneOneSearchPlanModel searchPlanModel) {
        Map<String, Integer> copiedObjectMap;
        try {
            copiedObjectMap = tracfoneServicePlanController.mirrorServicePlanMap(searchPlanModel,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(copiedObjectMap), MediaType.APPLICATION_JSON).build();
    }

    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }
}
