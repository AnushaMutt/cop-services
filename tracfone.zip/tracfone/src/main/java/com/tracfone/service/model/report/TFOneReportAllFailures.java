package com.tracfone.service.model.report;

/**
 *
 * @author druiz
 */
public class TFOneReportAllFailures {

    private String transType;
    private String xCarrier;
    private String xTimesegment;
    private String orderTypeGroup;
    private String totalTranscount;
    private String percentFailure;
    private String failureCount;
    private String sumF;

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public String getxCarrier() {
        return xCarrier;
    }

    public void setxCarrier(String xCarrier) {
        this.xCarrier = xCarrier;
    }

    public String getxTimesegment() {
        return xTimesegment;
    }

    public void setxTimesegment(String xTimesegment) {
        this.xTimesegment = xTimesegment;
    }
    
    public String getOrderTypeGroup() {
        return orderTypeGroup;
    }

    public void setOrderTypeGroup(String orderTypeGroup) {
        this.orderTypeGroup = orderTypeGroup;
    }

    public String getTotalTranscount() {
        return totalTranscount;
    }

    public void setTotalTranscount(String totalTranscount) {
        this.totalTranscount = totalTranscount;
    }

    public String getPercentFailure() {
        return percentFailure;
    }

    public void setPercentFailure(String percentFailure) {
        this.percentFailure = percentFailure;
    }

    public String getFailureCount() {
        return failureCount;
    }

    public void setFailureCount(String failureCount) {
        this.failureCount = failureCount;
    }

    public String getSumF() {
        return sumF;
    }

    public void setSumF(String sumF) {
        this.sumF = sumF;
    }

}
