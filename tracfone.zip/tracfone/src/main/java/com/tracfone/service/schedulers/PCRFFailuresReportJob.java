package com.tracfone.service.schedulers;

import com.google.gson.Gson;
import com.tracfone.service.model.event.TracfoneOneReportRequest;
import com.tracfone.service.model.report.TFOneReportAllPCRFFailures;
import com.tracfone.service.report.workers.pcrf.AllPCRFFailuresWorkerBean;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Singleton
public class PCRFFailuresReportJob {

    @EJB
    AllPCRFFailuresWorkerBean pcrfFailuresWorkerBean;

    @Inject
    private Event<TracfoneOneReportRequest> tracfoneOneConstantReportEvent;

    private static final Logger LOGGER = LogManager.getLogger(PCRFFailuresReportJob.class);

//    @Schedule(second = "*/55", minute = "*", hour = "*", persistent = false)
    public void runAllPCRFFailuresReport() {
        try {
//            List<TFOneReportAllPCRFFailures> pcrfFailures = pcrfFailuresWorkerBean.runAllPCRFFailuresReport();
            List<TFOneReportAllPCRFFailures> pcrfFailures = new ArrayList<>();
            if (!pcrfFailures.isEmpty()) {
                Gson gson = new Gson();
                TracfoneOneReportRequest reportRequest = new TracfoneOneReportRequest();
                reportRequest.setJsonResponse(gson.toJson(pcrfFailures));
                reportRequest.setReportName(TracfoneOneConstantReport.TRACFONE_REPORTNAME_ALL_PCRF_FAILURES);
                tracfoneOneConstantReportEvent.fire(reportRequest);
            } else {
                LOGGER.info("AllPCRFFailuresWorkerBean returned an empty response.");
            }
        } catch (Exception ex) {
            LOGGER.error("PCRF Failures report could not be retrieved because of an exception", ex);
        }
    }
}
