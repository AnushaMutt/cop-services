package com.tracfone.service.model.request;

import javax.validation.constraints.Size;

/**
 * x_rp_throttle_status
 *
 * @author Pritesh Singh
 */
public class TracfoneOneThrottleStatusCode {
    private String dbEnv;
    @Size(min = 1, message = "Throttle Status Code cannot be blank")
    @Size(max = 2, message = "Throttle Status Code cannot have more than 2 characters")
    private String throttleStatusCode;
    @Size(min = 1, message = "Description cannot be blank")
    @Size(max = 50, message = "Description cannot have more than 50 characters")
    private String description;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getThrottleStatusCode() {
        return throttleStatusCode;
    }

    public void setThrottleStatusCode(String throttleStatusCode) {
        this.throttleStatusCode = throttleStatusCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "TracfoneOneThrottleStatus{" +
                "dbEnv='" + dbEnv + '\'' +
                ", throttleStatusCode='" + throttleStatusCode + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}

