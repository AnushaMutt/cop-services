package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * TABLE: table_x_carrier_group
 *
 * @author Pritesh Singh
 */
public class TracfoneOneCarrierGroup {
    private String dbEnv;
    @Digits(integer = 38, fraction = 0, message = "ObjId must be a number")
    private String objId;
    @Digits(integer = 38, fraction = 0, message = "Carrier Group Id must be a number")
    private String carrierGroupId;
    @Size(min = 1, message = "Carrier Name cannot be null")
    @Size(max = 30, message = "Carrier Name cannot have more than 30 characters")
    private String carrierName;
    @Digits(integer = 38, fraction = 0, message = "Group2Address must be a number")
    private String group2Address;
    @Size(min = 1, message = "Status cannot be null")
    @Size(max = 20, message = "Status cannot have more than 20 characters")
    private String status;
    @Digits(integer = 38, fraction = 0, message = "CarrierGroup2Parent must be a number")
    private String carrierGroup2Parent;
    @Digits(integer = 38, fraction = 0, message = "No Auto Part must be a number")
    private String noAutoPart;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getCarrierGroupId() {
        return carrierGroupId;
    }

    public void setCarrierGroupId(String carrierGroupId) {
        this.carrierGroupId = carrierGroupId;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getGroup2Address() {
        return group2Address;
    }

    public void setGroup2Address(String group2Address) {
        this.group2Address = group2Address;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCarrierGroup2Parent() {
        return carrierGroup2Parent;
    }

    public void setCarrierGroup2Parent(String carrierGroup2Parent) {
        this.carrierGroup2Parent = carrierGroup2Parent;
    }

    public String getNoAutoPart() {
        return noAutoPart;
    }

    public void setNoAutoPart(String noAutoPart) {
        this.noAutoPart = noAutoPart;
    }

    @Override
    public String toString() {
        return "TracfoneOneCarrierGroup{" +
                "dbEnv='" + dbEnv + '\'' +
                ", objId='" + objId + '\'' +
                ", carrierGroupId='" + carrierGroupId + '\'' +
                ", carrierName='" + carrierName + '\'' +
                ", group2Address='" + group2Address + '\'' +
                ", status='" + status + '\'' +
                ", carrierGroup2Parent='" + carrierGroup2Parent + '\'' +
                ", noAutoPart='" + noAutoPart + '\'' +
                '}';
    }
}
