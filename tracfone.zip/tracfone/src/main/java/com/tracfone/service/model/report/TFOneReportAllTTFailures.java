package com.tracfone.service.model.report;

public class TFOneReportAllTTFailures {
    private String parent;
    private String carrier;
    private String timeSegment;
    private String orderTypeGroup;
    private String totalTransCount;
    private String failureCount;
    private String parentShort;

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getTimeSegment() {
        return timeSegment;
    }

    public void setTimeSegment(String timeSegment) {
        this.timeSegment = timeSegment;
    }

    public String getOrderTypeGroup() {
        return orderTypeGroup;
    }

    public void setOrderTypeGroup(String orderTypeGroup) {
        this.orderTypeGroup = orderTypeGroup;
    }

    public String getTotalTransCount() {
        return totalTransCount;
    }

    public void setTotalTransCount(String totalTransCount) {
        this.totalTransCount = totalTransCount;
    }

    public String getFailureCount() {
        return failureCount;
    }

    public void setFailureCount(String failureCount) {
        this.failureCount = failureCount;
    }

    public String getParentShort() {
        return parentShort;
    }

    public void setParentShort(String parentShort) {
        this.parentShort = parentShort;
    }

    @Override
    public String toString() {
        return "TFOneReportAllTTFailures{" +
                "parent='" + parent + '\'' +
                ", carrier='" + carrier + '\'' +
                ", timeSegment='" + timeSegment + '\'' +
                ", orderTypeGroup='" + orderTypeGroup + '\'' +
                ", totalTransCount='" + totalTransCount + '\'' +
                ", failureCount='" + failureCount + '\'' +
                ", parentShort='" + parentShort + '\'' +
                '}';
    }
}