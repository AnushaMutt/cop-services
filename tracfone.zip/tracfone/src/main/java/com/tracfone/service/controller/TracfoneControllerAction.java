package com.tracfone.service.controller;

import com.google.gson.Gson;
import com.mysql.jdbc.StringUtils;
import com.tracfone.ejb.entity.UserTask;
import com.tracfone.ejb.entity.UserTaskDetail;
import com.tracfone.ejb.entity.session.UserTaskFacadeLocal;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TFTransactionArchive;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneActionItemId;
import com.tracfone.service.model.request.TracfoneOneBucketDetail;
import com.tracfone.service.model.request.TracfoneOneBulkIdentifier;
import com.tracfone.service.model.request.TracfoneOneBulkTransaction;
import com.tracfone.service.model.request.TracfoneOneColumnDesc;
import com.tracfone.service.model.request.TracfoneOneNewTransaction;
import com.tracfone.service.model.request.TracfoneOneRework;
import com.tracfone.service.model.request.TracfoneOneSearchAdditionalModel;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.request.TracfoneOneUserTask;
import com.tracfone.service.model.request.TracfoneOneUserTaskDetail;
import com.tracfone.service.model.request.TracfoneonePaginationSearch;
import com.tracfone.service.model.response.TFOneActionItemBucket;
import com.tracfone.service.model.response.TFOneActionItemBucketTier;
import com.tracfone.service.model.response.TFOneAdminActionItem;
import com.tracfone.service.model.response.TFOneBulkInsertReport;
import com.tracfone.service.model.response.TFOneCarrierTransactionResponse;
import com.tracfone.service.model.response.TFOneColumnDesc;
import com.tracfone.service.model.response.TFOneFeatures;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGFailLogs;
import com.tracfone.service.model.response.TFOneUserHistory;
import com.tracfone.service.model.response.TFOneUserHistoryDetail;
import com.tracfone.service.model.response.TFOneUserTask;
import com.tracfone.service.model.response.TFOneUserTaskDetail;
import com.tracfone.service.model.response.TracfoneOneViewActionItems;
import com.tracfone.service.util.ControllerUtil;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantAction;
import jersey.repackaged.com.google.common.collect.Lists;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.util.IOUtils;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.security.SecureRandom;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;


/**
 * @author user
 */
@Stateless
public class TracfoneControllerAction implements TracfoneControllerLocalAction, TracfoneOneConstantAction, TracfoneOneConstant {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneControllerAction.class);
    //Flag Values for TMO-NEXT-GEN_FLAG
    private final List<String> TMO_NEXT_GEN_FLAGS = Arrays.asList("Y", "R");
    @EJB
    DataBaseController dbControllerEJB;

    @EJB
    UserTaskFacadeLocal userTaskFacade;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @Inject
    private Event<TFTransactionArchive> tracfoneTransactionArchiveEvent;

    @Override
    public TracfoneOneViewActionItems viewActionitemId(TracfoneOneActionItemId tracfoneOneActionItemId, Integer userId) throws TracfoneOneException {
        TracfoneOneViewActionItems tracfoneOneViewActionItems = null;
        if (tracfoneOneActionItemId.isFromUserHistory()) {
            tracfoneOneViewActionItems = viewAidFromHistory(tracfoneOneActionItemId, userId);
        } else {
            tracfoneOneViewActionItems = viewAidDirectly(tracfoneOneActionItemId, userId);
        }
        return tracfoneOneViewActionItems;
    }

    private TracfoneOneViewActionItems viewAidFromHistory(TracfoneOneActionItemId tracfoneOneActionItemId, Integer userId) throws TracfoneOneException {
        String dbColumns ="";
        String formattedDbColumns ="";
        List<String> missedDbColumns = new ArrayList<>();
        TracfoneOneViewActionItems tracfoneOneViewActionItems = new TracfoneOneViewActionItems();
        List<TFOneAdminActionItem> transactionsProcessed = new ArrayList<>();
        List<String> ids = null;
        boolean aidPresent = checkIfNullOrEmpty(tracfoneOneActionItemId.getActionItemId());

        if (aidPresent) {
            ids = tracfoneOneActionItemId.getActionItemId();
        } else {
            ids = tracfoneOneActionItemId.getTransactionId();
        }

        // Get the query constructed
        StringBuilder builder = new StringBuilder(ACTION_SQL_SEARCHTRANSACTION_PART_1);
        //Dynamic Column logic
        try{
            StringBuilder igColumnList = new StringBuilder();
            TracfoneOneColumnDesc tfColumnDesc = new TracfoneOneColumnDesc();
            tfColumnDesc.setDbEnv(tracfoneOneActionItemId.getDbenv());
            tfColumnDesc.setOwner(IG_OWNER_NAME);
            tfColumnDesc.setTableName(IG_TABLE_NAME);
            List<TFOneColumnDesc> tableDetails= new ArrayList<>();
            tableDetails= getTableDesc(tfColumnDesc);

            List<String> cols = new ArrayList<>();
            Field[] fields = TFOneAdminActionItem.class.getDeclaredFields();
            for (int i = 0; i < fields.length; i++) {
                cols.add(fields[i].getName().toUpperCase());
            }
            for(TFOneColumnDesc test : tableDetails){
                if(!test.getColumnName().equalsIgnoreCase("CREATION_DATE")) {
                    igColumnList.append("ig.").append(test.getColumnName()).append(",\n");
                }
                dbColumns = test.getColumnName();
                formattedDbColumns = dbColumns.replace("_","");
                if(!cols.contains(formattedDbColumns)){
                    missedDbColumns.add(dbColumns);
                }
            }
            LOGGER.info("Column List - " + igColumnList);
            builder.append(ACTION_SQL_SEARCHTRANSACTION_PART_2_DYNAMIC_PART_1);
            builder.append(igColumnList);
            builder.append(ACTION_SQL_SEARCHTRANSACTION_PART_2_DYNAMIC_PART_2);
        }catch(Exception e){
            LOGGER.error("Dynamic column logic failed with - ", e);
            builder.append(ACTION_SQL_SEARCHTRANSACTION_PART_2);
        }
        if (tracfoneOneActionItemId.isShowFailLogs()) {
            builder.append("(SELECT count(1) FROM gw1.ig_failed_log igf WHERE igf.action_item_id = ig.action_item_id) IGFAIL_LOGS_COUNT, \n");
        }

        builder.append(ACTION_SQL_SEARCHTRANSACTION_PART_OF_PART2);
        int startIndex = 0;
        int endIndex = 200;
        int batchSize = 0;
        if (tracfoneOneActionItemId.getPaginationSearch() != null) {
            startIndex = tracfoneOneActionItemId.getPaginationSearch().getStartIndex();
            endIndex = tracfoneOneActionItemId.getPaginationSearch().getEndIndex();
            batchSize = endIndex - startIndex;
        }
        // if the number of transactions is less than the batch size
        if (endIndex > ids.size()) {
            batchSize = ids.size() - startIndex;
        }
        if (aidPresent) {
            builder = buildQueryParamString(batchSize, builder, IG_ACTION_ITEM_ID);
        } else {
            builder = buildQueryParamString(batchSize, builder, IG_TRANSACTION_ID);
        }

        builder.append(A
                + "      where ROWNUM < \n"
                + "      1000 ) \n"
                + "where rnum  >= 0");
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneActionItemId.getDbenv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(builder.toString());) {

            Collections.sort(ids);
            int index = 1;
            for (int i = startIndex; i < (startIndex + batchSize); i++) {
                stmt.setString(index++, ids.get(i));
            }

            try (ResultSet rs = stmt.executeQuery()) {
                TFOneAdminActionItem tfOneAdminActionItem = null;
                while (rs.next()) {
                    tfOneAdminActionItem = new TFOneAdminActionItem();
                    setIgTransaction(tracfoneOneActionItemId.getDbenv(), tfOneAdminActionItem, rs, tracfoneOneActionItemId,missedDbColumns);
                    transactionsProcessed.add(tfOneAdminActionItem);
                }
            }

            tracfoneOneViewActionItems.setActionItems(transactionsProcessed);
            TracfoneonePaginationSearch tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
            tracfoneonePaginationSearch.setStartIndex(startIndex);
            tracfoneonePaginationSearch.setEndIndex(endIndex);
            tracfoneonePaginationSearch.setTotal(ids.size());
            tracfoneOneViewActionItems.setPaginationSearch(tracfoneonePaginationSearch);
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "ViewActionItemId", new Gson().toJson(tracfoneOneActionItemId), CARRIER_ID);
            tracfoneAuditEvent.fire(audit);
        }
        return tracfoneOneViewActionItems;
    }

    private TracfoneOneViewActionItems viewAidDirectly(TracfoneOneActionItemId tracfoneOneActionItemId, Integer userId) throws TracfoneOneException {
        String dbColumns ="";
        String formattedDbColumns ="";
        List<String> missedDbColumns = new ArrayList<>();
        TFOneAdminActionItem tfOneResponseActionItem = null;
        List<TFOneAdminActionItem> transactionsProcessed = new ArrayList<>();
        TracfoneOneViewActionItems tracfoneOneViewActionItems = new TracfoneOneViewActionItems();
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet resultSet = null;
        ResultSet resultSetCount = null;
        Gson gson = new Gson();
        int count = 0;
        int preparedStmtCnt = 1;
        boolean useInvisibleIndexes = false;
        boolean existingTransaction = false;
        boolean aidPresent = checkIfNullOrEmpty(tracfoneOneActionItemId.getActionItemId());
        boolean esnPresent = checkIfNullOrEmpty(tracfoneOneActionItemId.getEsn());
        boolean orderTypePresent = checkIfNullOrEmpty(tracfoneOneActionItemId.getOrderType());
        boolean statusPresent = checkIfNullOrEmpty(tracfoneOneActionItemId.getStatus());
        boolean tidPresent = checkIfNullOrEmpty(tracfoneOneActionItemId.getTransactionId());
        boolean statusMsgPresentExactMatch = checkIfNullOrEmpty(tracfoneOneActionItemId.getStatusMessage()) && tracfoneOneActionItemId.isIsExactMatch();
        boolean statusMsgPresentWildCard = checkIfNullOrEmpty(tracfoneOneActionItemId.getStatusMessage()) && !tracfoneOneActionItemId.isIsExactMatch();
        boolean statusMsgNotIn = checkIfNullOrEmpty(tracfoneOneActionItemId.getStatusMessage()) && tracfoneOneActionItemId.isNotInStatusMessage();
        boolean aidPresentExactMatch = checkIfNullOrEmpty(tracfoneOneActionItemId.getActionItemId()) && tracfoneOneActionItemId.isExactMatchForActionItemId();
        boolean aidPresentWildCard = checkIfNullOrEmpty(tracfoneOneActionItemId.getActionItemId()) && !tracfoneOneActionItemId.isExactMatchForActionItemId();
        boolean aidNotIn = checkIfNullOrEmpty(tracfoneOneActionItemId.getActionItemId()) && tracfoneOneActionItemId.isNotInActionItemId();
        boolean creationDatePresent = checkIfNotNullOrEmpty(tracfoneOneActionItemId.getCreationFromDate());
        boolean udpateDatePresent = checkIfNotNullOrEmpty(tracfoneOneActionItemId.getUpdateFromDate());
        boolean statusMsgRegx = checkIfNullOrEmpty(tracfoneOneActionItemId.getStatusMessage()) && tracfoneOneActionItemId.isRegexExp();
        boolean additionalFields = (tracfoneOneActionItemId.getAdditionalColumns() != null && !tracfoneOneActionItemId.getAdditionalColumns().isEmpty());
        boolean pagination = false;
        boolean primaryFieldPresent = aidPresent || esnPresent || orderTypePresent || statusPresent || tidPresent
                || statusMsgPresentExactMatch || statusMsgPresentWildCard || creationDatePresent
                || udpateDatePresent || aidPresentExactMatch || aidPresentWildCard;
        //Not INS
        boolean notInStatus = tracfoneOneActionItemId.isNotInStatus();
        boolean notInOrderType = tracfoneOneActionItemId.isNotInOrderType();

        int startIndex = 0;
        int endIndex = 0;
        if (tracfoneOneActionItemId.getPaginationSearch() != null) {
            startIndex = tracfoneOneActionItemId.getPaginationSearch().getStartIndex();
            endIndex = tracfoneOneActionItemId.getPaginationSearch().getEndIndex();
            pagination = (endIndex - startIndex) <= FETCH_SIZE;
        }

        if (!primaryFieldPresent && additionalFields) {
            throw new TracfoneOneException(TRACFONE_VIEWTRANSACTION_PRIMARYMISSING_CODE, TRACFONE_VIEWTRANSACTION_PRIMARYMISSING_MESSAGE);
        }

        //check for to use Invisible Indexes
        if (primaryFieldPresent && esnPresent && !aidPresent && !orderTypePresent && !statusPresent && !tidPresent &&
                !statusMsgPresentExactMatch && !statusMsgPresentWildCard && !creationDatePresent &&
                !udpateDatePresent && !aidPresentExactMatch && !aidPresentWildCard) {
            useInvisibleIndexes = true;
        }

        try {

            con = dbControllerEJB.getDataSource(tracfoneOneActionItemId.getDbenv()).getConnection();

            // APPEND THE WHERE CONDITION for the fields in tracfoneOneActionItemId
            StringBuilder sbuilder = new StringBuilder(ACTION_SQL_SEARCHTRANSACTION_PART_1);
            if (useInvisibleIndexes) {
                sbuilder.append(TracfoneOneConstantAction.INVISIBLE_INDEX);
            }
            //Dynamic Column logic
            try{
                StringBuilder igColumnList = new StringBuilder();
                TracfoneOneColumnDesc tfColumnDesc = new TracfoneOneColumnDesc();
                tfColumnDesc.setDbEnv(tracfoneOneActionItemId.getDbenv());
                tfColumnDesc.setOwner(IG_OWNER_NAME);
                tfColumnDesc.setTableName(IG_TABLE_NAME);
                List<TFOneColumnDesc> tableDetails= new ArrayList<>();
                tableDetails = getTableDesc(tfColumnDesc);
                tableDetails = getTableColumns(tfColumnDesc, con);

                List<String> cols = new ArrayList<>();
                Field[] fields = TFOneAdminActionItem.class.getDeclaredFields();
                for (int i = 0; i < fields.length; i++) {
                    cols.add(fields[i].getName().toUpperCase());
                }
                for(TFOneColumnDesc test : tableDetails){
                    if(!test.getColumnName().equalsIgnoreCase("CREATION_DATE")) {
                        igColumnList.append("ig.").append(test.getColumnName()).append(",\n");
                    }
                    dbColumns = test.getColumnName();
                    formattedDbColumns = dbColumns.replace("_","");
                    if(!cols.contains(formattedDbColumns)){
                        missedDbColumns.add(dbColumns);
                    }
                }
                LOGGER.info("Column List - " + igColumnList);
                sbuilder.append(ACTION_SQL_SEARCHTRANSACTION_PART_2_DYNAMIC_PART_1);
                sbuilder.append(igColumnList);
                sbuilder.append(ACTION_SQL_SEARCHTRANSACTION_PART_2_DYNAMIC_PART_2);
            }catch(Exception e){
                LOGGER.error("Dynamic column logic failed with - ", e);
                sbuilder.append(ACTION_SQL_SEARCHTRANSACTION_PART_2);
            }

            if (tracfoneOneActionItemId.isShowFailLogs()) {
                sbuilder.append("       (SELECT count(1) FROM gw1.ig_failed_log igf WHERE igf.action_item_id = ig.action_item_id) IGFAIL_LOGS_COUNT, \n");
            }

            sbuilder.append(ACTION_SQL_SEARCHTRANSACTION_PART_OF_PART2);

            //set the  String builder for count
            StringBuilder sBuilderCount = new StringBuilder(VIEW_ACTION_ITEMID_SQL_COUNT);

            if (aidNotIn) {
                sbuilder = buildQueryParamStringForNotINs(tracfoneOneActionItemId.getActionItemId().size(), sbuilder, IG_ACTION_ITEM_ID, false);
                sBuilderCount = buildQueryParamStringForNotINs(tracfoneOneActionItemId.getActionItemId().size(), sBuilderCount, IG_ACTION_ITEM_ID, false);
            } else if (aidPresentWildCard) {
                sbuilder.append(AND_IG_ACTION_ITEM_ID_LIKE);
                sBuilderCount.append(AND_IG_ACTION_ITEM_ID_LIKE);
            } else if (aidPresentExactMatch) {
                sbuilder = buildQueryParamString(tracfoneOneActionItemId.getActionItemId().size(), sbuilder, IG_ACTION_ITEM_ID);
                sBuilderCount = buildQueryParamString(tracfoneOneActionItemId.getActionItemId().size(), sBuilderCount, IG_ACTION_ITEM_ID);
            }
            if (esnPresent) {
                sbuilder = buildQueryParamString(tracfoneOneActionItemId.getEsn().size(), sbuilder, IG_ESN);
                sBuilderCount = buildQueryParamString(tracfoneOneActionItemId.getEsn().size(), sBuilderCount, IG_ESN);
            }
            if (orderTypePresent) {
                if (notInOrderType) {
                    sbuilder = buildQueryParamStringForNotINs(tracfoneOneActionItemId.getOrderType().size(), sbuilder, IG_ORDER_TYPE, false);
                    sBuilderCount = buildQueryParamStringForNotINs(tracfoneOneActionItemId.getOrderType().size(), sBuilderCount, IG_ORDER_TYPE, false);
                } else {
                    sbuilder = buildQueryParamString(tracfoneOneActionItemId.getOrderType().size(), sbuilder, IG_ORDER_TYPE);
                    sBuilderCount = buildQueryParamString(tracfoneOneActionItemId.getOrderType().size(), sBuilderCount, IG_ORDER_TYPE);
                }
            }
            if (statusPresent) {
                if (notInStatus) {
                    sbuilder = buildQueryParamStringForNotINs(tracfoneOneActionItemId.getStatus().size(), sbuilder, IG_STATUS, false);
                    sBuilderCount = buildQueryParamStringForNotINs(tracfoneOneActionItemId.getStatus().size(), sBuilderCount, IG_STATUS, false);
                } else {
                    sbuilder = buildQueryParamString(tracfoneOneActionItemId.getStatus().size(), sbuilder, IG_STATUS);
                    sBuilderCount = buildQueryParamString(tracfoneOneActionItemId.getStatus().size(), sBuilderCount, IG_STATUS);
                }
            }
            if (tidPresent) {
                sbuilder = buildQueryParamString(tracfoneOneActionItemId.getTransactionId().size(), sbuilder, IG_TRANSACTION_ID);
                sBuilderCount = buildQueryParamString(tracfoneOneActionItemId.getTransactionId().size(), sBuilderCount, IG_TRANSACTION_ID);
            }

            if (statusMsgNotIn) {
                sbuilder = buildQueryParamStringForNotINs(tracfoneOneActionItemId.getStatusMessage().size(), sbuilder, IG_STATUS_MESSAGE, false);
                sBuilderCount = buildQueryParamStringForNotINs(tracfoneOneActionItemId.getStatusMessage().size(), sBuilderCount, IG_STATUS_MESSAGE, false);
            } else if (statusMsgRegx) {
                sbuilder = createRegexQuery(sbuilder, tracfoneOneActionItemId);
                sBuilderCount = createRegexQuery(sBuilderCount, tracfoneOneActionItemId);
            } else if (statusMsgPresentWildCard) {
                sbuilder.append(AND_IG_STATUS_MESSAGE_LIKE);
                sBuilderCount.append(AND_IG_STATUS_MESSAGE_LIKE);
            } else if (statusMsgPresentExactMatch) {
                sbuilder = buildQueryParamString(tracfoneOneActionItemId.getStatusMessage().size(), sbuilder, IG_STATUS_MESSAGE);
                sBuilderCount = buildQueryParamString(tracfoneOneActionItemId.getStatusMessage().size(), sBuilderCount, IG_STATUS_MESSAGE);
            }

            if (creationDatePresent) {
                sbuilder.append(" AND ig.CREATION_DATE >= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ig.CREATION_DATE <= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') ");
                sBuilderCount.append(" AND ig.CREATION_DATE >= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ig.CREATION_DATE <= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') ");
            }
            if (udpateDatePresent) {
                sbuilder.append(AND_UPDATE_DATE);
                sBuilderCount.append(AND_UPDATE_DATE);
            }

            //Additional Fields are present, add them.
            if (additionalFields) {
                Iterator<TracfoneOneSearchAdditionalModel> itr = tracfoneOneActionItemId.getAdditionalColumns().iterator();
                while (itr.hasNext()) {
                    TracfoneOneSearchAdditionalModel additionalColumn = itr.next();
                    boolean validOptionalVals = false;

                    for (String optionalFieldVals : additionalColumn.getSearchValues()) {
                        if (!StringUtils.isNullOrEmpty(optionalFieldVals)) {
                            validOptionalVals = true;
                            break;
                        }
                    }
                    String optionalFieldVal = ControllerUtil.getDBColumnName(additionalColumn.getSearchColumnName());
                    if (validOptionalVals && !StringUtils.isNullOrEmpty(optionalFieldVal)) {
                        if (NULL.equalsIgnoreCase(additionalColumn.getSearchValues().get(0))) {
                            sbuilder = buildNullClause(sbuilder, optionalFieldVal, AND);
                            sBuilderCount = buildNullClause(sBuilderCount, optionalFieldVal, AND);
                        } else if (additionalColumn.isSearchIsColumnNotIn()) {
                            sbuilder = buildNullOrNotInClause(additionalColumn.getSearchValues().size(), sbuilder, optionalFieldVal);
                            sBuilderCount = buildNullOrNotInClause(additionalColumn.getSearchValues().size(), sBuilderCount, optionalFieldVal);
                        } else if (additionalColumn.isSearchIsColumnLike()) {
                            sbuilder = buildQueryParamStringForLike(additionalColumn.getSearchValues().size(), sbuilder, optionalFieldVal);
                            sBuilderCount = buildQueryParamStringForLike(additionalColumn.getSearchValues().size(), sBuilderCount, optionalFieldVal);
                        } else {
                            sbuilder = buildQueryParamString(additionalColumn.getSearchValues().size(), sbuilder, optionalFieldVal);
                            sBuilderCount = buildQueryParamString(additionalColumn.getSearchValues().size(), sBuilderCount, optionalFieldVal);
                        }
                    } else {
                        itr.remove();
                    }
                }
            }

            // Pagination check for large result queries.
            if (pagination) {
                // Adding 1 to each of these since a ROWNUM of 0 never exists and it is being sent this way from the UI
                startIndex++;
                endIndex++;
                sbuilder.append(A
                        + "      where ROWNUM < \n "
                        + endIndex + ") \n"
                        + "where rnum  >= " + startIndex);
            } else {
                TracfoneonePaginationSearch defaultPagination = new TracfoneonePaginationSearch();
                defaultPagination.setStartIndex(1);
                defaultPagination.setEndIndex(1000);
                tracfoneOneActionItemId.setPaginationSearch(defaultPagination);
                sbuilder.append(A
                        + "      where ROWNUM < \n"
                        + "      1000 ) \n"
                        + "where rnum  >= 0");
            }

            // Prepare statement with new created SQL String.
            LOGGER.info("The search query is " + sbuilder.toString());
            stmt = con.prepareStatement(sbuilder.toString());
            PreparedStatement stmtCount = con.prepareStatement(sBuilderCount.toString());

            //AID
            if (aidPresentExactMatch || aidNotIn) {
                for (String aid : tracfoneOneActionItemId.getActionItemId()) {
                    stmt.setString(preparedStmtCnt, aid.trim());
                    stmtCount.setString(preparedStmtCnt++, aid.trim());
                }
            } else if (aidPresentWildCard) {
                stmt.setString(preparedStmtCnt, tracfoneOneActionItemId.getActionItemId().get(0).trim() + "%");
                stmtCount.setString(preparedStmtCnt++, tracfoneOneActionItemId.getActionItemId().get(0).trim() + "%");
            }
            if (esnPresent) {
                for (String esn : tracfoneOneActionItemId.getEsn()) {
                    stmt.setString(preparedStmtCnt, esn.trim());
                    stmtCount.setString(preparedStmtCnt++, esn.trim());
                }
            }
            if (orderTypePresent) {
                for (String orderType : tracfoneOneActionItemId.getOrderType()) {
                    stmt.setString(preparedStmtCnt, orderType.trim());
                    stmtCount.setString(preparedStmtCnt++, orderType.trim());
                }
            }
            if (statusPresent) {
                for (String status : tracfoneOneActionItemId.getStatus()) {
                    stmt.setString(preparedStmtCnt, status.trim());
                    stmtCount.setString(preparedStmtCnt++, status.trim());
                }
            }
            if (tidPresent) {
                for (String tid : tracfoneOneActionItemId.getTransactionId()) {
                    stmt.setString(preparedStmtCnt, tid.trim());
                    stmtCount.setString(preparedStmtCnt++, tid.trim());
                }
            }
            if (statusMsgPresentExactMatch || statusMsgNotIn) {
                for (String statusMessage : tracfoneOneActionItemId.getStatusMessage()) {
                    stmt.setString(preparedStmtCnt, statusMessage.trim());
                    stmtCount.setString(preparedStmtCnt++, statusMessage.trim());
                }
            } else if (statusMsgRegx) {
                stmt.setString(preparedStmtCnt, tracfoneOneActionItemId.getStatusMessage().get(0).trim());
                stmtCount.setString(preparedStmtCnt++, tracfoneOneActionItemId.getStatusMessage().get(0).trim());
            } else if (statusMsgPresentWildCard) {
                stmt.setString(preparedStmtCnt, "%" + tracfoneOneActionItemId.getStatusMessage().get(0).trim() + "%");
                stmtCount.setString(preparedStmtCnt++, "%" + tracfoneOneActionItemId.getStatusMessage().get(0).trim() + "%");
            }
            if (creationDatePresent) {
                stmt.setString(preparedStmtCnt, tracfoneOneActionItemId.getCreationFromDate().trim());
                stmtCount.setString(preparedStmtCnt++, tracfoneOneActionItemId.getCreationFromDate().trim());
                //to date
                if (tracfoneOneActionItemId.getCreationToDate() != null && !tracfoneOneActionItemId.getCreationToDate().isEmpty()) {
                    stmt.setString(preparedStmtCnt, tracfoneOneActionItemId.getCreationToDate().trim());
                    stmtCount.setString(preparedStmtCnt++, tracfoneOneActionItemId.getCreationToDate().trim());
                } else {
                    stmt.setString(preparedStmtCnt, getDefaultTodayDate().trim());
                    stmtCount.setString(preparedStmtCnt++, getDefaultTodayDate().trim());
                }
            }
            if (udpateDatePresent) {
                stmt.setString(preparedStmtCnt, tracfoneOneActionItemId.getUpdateFromDate().trim());
                stmtCount.setString(preparedStmtCnt++, tracfoneOneActionItemId.getUpdateFromDate().trim());
                //to date
                if (tracfoneOneActionItemId.getUpdateToDate() != null && !tracfoneOneActionItemId.getUpdateToDate().isEmpty()) {
                    stmt.setString(preparedStmtCnt, tracfoneOneActionItemId.getUpdateToDate().trim());
                    stmtCount.setString(preparedStmtCnt++, tracfoneOneActionItemId.getUpdateToDate().trim());
                } else {
                    stmt.setString(preparedStmtCnt, getDefaultTodayDate().trim());
                    stmtCount.setString(preparedStmtCnt++, getDefaultTodayDate().trim());
                }
            }

            //Additional Fields
            if (additionalFields) {
                for (TracfoneOneSearchAdditionalModel additionalColumn : tracfoneOneActionItemId.getAdditionalColumns()) {
                    for (String additionalFieldValue : additionalColumn.getSearchValues()) {
                        if (NULL.equalsIgnoreCase(additionalFieldValue)) {
                            break;
                        }
                        if (additionalColumn.isSearchIsColumnLike()) {
                            stmt.setString(preparedStmtCnt, additionalFieldValue.trim() + "%");
                            stmtCount.setString(preparedStmtCnt++, additionalFieldValue.trim() + "%");
                        } else {
                            stmt.setString(preparedStmtCnt, additionalFieldValue.trim());
                            stmtCount.setString(preparedStmtCnt++, additionalFieldValue.trim());
                        }
                    }
                }
            }

            try {
                resultSetCount = stmtCount.executeQuery();

                while (resultSetCount.next()) {
                    count = resultSetCount.getInt(1);
                }

            } catch (Exception e) {
                LOGGER.error(e);
            } finally {
                try {
                    if (resultSetCount != null) {
                        resultSetCount.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }
                try {
                    if (stmtCount != null) {
                        stmtCount.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }
            }

            resultSet = stmt.executeQuery();

            // Retrieve all transactions found for search criteria.
            while (resultSet.next()) {
                tfOneResponseActionItem = new TFOneAdminActionItem();
                existingTransaction = false;

                // Check if transaction id already exists. If it does, do not send it in response.
                for (ListIterator<TFOneAdminActionItem> itr = transactionsProcessed.listIterator(); itr.hasNext(); ) {
                    TFOneAdminActionItem actionItem = itr.next();

                    if (actionItem.getTransactionId().equals(resultSet.getString(TRANSACTION_ID))) {
                        existingTransaction = true;
                        break;
                    }
                }

                // Transactions are returned repeated when they have buckets.
                // Do not add transaction to response if already present.
                if (existingTransaction) {
                    continue;
                }

                // Set regular IG Transaction fields.
                setIgTransaction(tracfoneOneActionItemId.getDbenv(), tfOneResponseActionItem, resultSet, tracfoneOneActionItemId,missedDbColumns);
                transactionsProcessed.add(tfOneResponseActionItem);
            }
            //Set the response and pagination
            tracfoneOneViewActionItems.setActionItems(transactionsProcessed);
            TracfoneonePaginationSearch tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
            tracfoneonePaginationSearch.setStartIndex(tracfoneOneActionItemId.getPaginationSearch().getStartIndex());
            tracfoneonePaginationSearch.setEndIndex(tracfoneOneActionItemId.getPaginationSearch().getEndIndex());
            tracfoneonePaginationSearch.setTotal(count);
            tracfoneOneViewActionItems.setPaginationSearch(tracfoneonePaginationSearch);
        } catch (SQLException ex) {
            LOGGER.error(ex);
            if (ex.getErrorCode() == 01013)
                throw new TracfoneOneException(TRACFONE_DATASOURCE_QUERY_TIMEOUT_ERROR_CODE, TRACFONE_DATASOURCE_QUERY_TIMEOUT_ERROR_MESSAGE, ex);

            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, ex);
        } catch (NamingException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, ex);
        } finally {
            //this should be handled with Java 1.8 try with resources, //TODO
            try {

                try {
                    if (resultSet != null) {
                        resultSet.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }
                try {
                    if (stmt != null) {
                        stmt.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }
                try {
                    if (con != null) {
                        con.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }
                TracfoneAudit audit = new TracfoneAudit(userId, "ViewActionItemId", gson.toJson(tracfoneOneActionItemId), CARRIER_ID);
                tracfoneAuditEvent.fire(audit);

            } catch (Exception ex) {
                LOGGER.error(ex);
            }
        }
        return tracfoneOneViewActionItems;
    }

    private void setIgTransaction(String dbEnv, TFOneAdminActionItem tfOneResponseActionItem, ResultSet resultSet, TracfoneOneActionItemId tracfoneOneActionItemId, List<String> missedDbColumns) throws SQLException {
        Map<String, String> additionalDbColMap = new HashMap<>();
        tfOneResponseActionItem.setEnv(dbEnv);
        tfOneResponseActionItem.setCallTransActionType(resultSet.getString("CALL_TRANS_ACTION_TYPE"));
        tfOneResponseActionItem.setActionItemId(resultSet.getString("ACTION_ITEM_ID"));
        tfOneResponseActionItem.setCarrierId(resultSet.getString("CARRIER_ID"));
        tfOneResponseActionItem.setOrderType(resultSet.getString("ORDER_TYPE"));
        tfOneResponseActionItem.setMin(resultSet.getString("MIN"));
        tfOneResponseActionItem.setEsn(resultSet.getString("ESN"));
        tfOneResponseActionItem.setEsnPartClassModel(resultSet.getString("ESN_PART_CLASS_MODEL"));
        tfOneResponseActionItem.setEsnHex(resultSet.getString("ESN_HEX"));
        tfOneResponseActionItem.setOldEsn(resultSet.getString("OLD_ESN"));
        tfOneResponseActionItem.setOldEsnHex(resultSet.getString("OLD_ESN_HEX"));
        tfOneResponseActionItem.setCarrierAccountId(resultSet.getString("CARRIER_ACCOUNT_ID"));
        tfOneResponseActionItem.setTmoNextGenFlag(resultSet.getString("TMO_NEXT_GEN_FLAG"));
        tfOneResponseActionItem.setPin(resultSet.getString("PIN"));
        tfOneResponseActionItem.setPhoneManf(resultSet.getString("PHONE_MANF"));
        tfOneResponseActionItem.setEndUser(resultSet.getString("END_USER"));
        tfOneResponseActionItem.setAccountNum(resultSet.getString("ACCOUNT_NUM"));
        tfOneResponseActionItem.setMarketCode(resultSet.getString("MARKET_CODE"));
        tfOneResponseActionItem.setRatePlan(resultSet.getString("RATE_PLAN"));
        tfOneResponseActionItem.setLdProvider(resultSet.getString("LD_PROVIDER"));
        tfOneResponseActionItem.setSequenceNum(resultSet.getString("SEQUENCE_NUM"));
        tfOneResponseActionItem.setDealerCode(resultSet.getString("DEALER_CODE"));
        tfOneResponseActionItem.setTransmissionMethod(resultSet.getString("TRANSMISSION_METHOD"));
        tfOneResponseActionItem.setFaxNum(resultSet.getString("FAX_NUM"));
        tfOneResponseActionItem.setOnlineNum(resultSet.getString("ONLINE_NUM"));
        tfOneResponseActionItem.setEmail(resultSet.getString("EMAIL"));
        tfOneResponseActionItem.setNetworkLogin(resultSet.getString("NETWORK_LOGIN"));
        tfOneResponseActionItem.setNetworkPassword(resultSet.getString("NETWORK_PASSWORD"));
        tfOneResponseActionItem.setSystemLogin(resultSet.getString("SYSTEM_LOGIN"));
        tfOneResponseActionItem.setSystemPassword(resultSet.getString("SYSTEM_PASSWORD"));
        tfOneResponseActionItem.setTemplate(resultSet.getString("TEMPLATE"));
        tfOneResponseActionItem.setExeName(resultSet.getString("EXE_NAME"));
        tfOneResponseActionItem.setComPort(resultSet.getString("COM_PORT"));
        tfOneResponseActionItem.setStatus(resultSet.getString("STATUS"));
        tfOneResponseActionItem.setStatusMessage(resultSet.getString("STATUS_MESSAGE"));
        tfOneResponseActionItem.setFaxBatchSize(resultSet.getString("FAX_BATCH_SIZE"));
        tfOneResponseActionItem.setFaxBatchQtime(resultSet.getString("FAX_BATCH_Q_TIME"));
        tfOneResponseActionItem.setExpidite(resultSet.getString("EXPIDITE"));
        tfOneResponseActionItem.setTransProfKey(resultSet.getString("TRANS_PROF_KEY"));
        tfOneResponseActionItem.setqTransaction(resultSet.getString("Q_TRANSACTION"));
        tfOneResponseActionItem.setOnlineNum2(resultSet.getString("ONLINE_NUM2"));
        tfOneResponseActionItem.setFaxNum2(resultSet.getString("FAX_NUM2"));
        tfOneResponseActionItem.setCreationDate(resultSet.getString(CREATION_DATE));
        tfOneResponseActionItem.setUpdateDate(resultSet.getString("UPDATE_DATE"));
        tfOneResponseActionItem.setIgDbSecsToComp(resultSet.getString("IGDB_SECS_TO_COMP"));
        tfOneResponseActionItem.setBlackoutWait(resultSet.getString("BLACKOUT_WAIT"));
        tfOneResponseActionItem.setTuxItiServer(resultSet.getString("TUX_ITI_SERVER"));
        tfOneResponseActionItem.setTransactionId(resultSet.getString(TRANSACTION_ID));
        tfOneResponseActionItem.setTechnologyFlag(resultSet.getString("TECHNOLOGY_FLAG"));
        tfOneResponseActionItem.setVoiceMail(resultSet.getString("VOICE_MAIL"));
        tfOneResponseActionItem.setVoiceMailPackage(resultSet.getString("VOICE_MAIL_PACKAGE"));
        tfOneResponseActionItem.setCallerId(resultSet.getString("CALLER_ID"));
        tfOneResponseActionItem.setCallerIdPackage(resultSet.getString("CALLER_ID_PACKAGE"));
        tfOneResponseActionItem.setCallWaiting(resultSet.getString("CALL_WAITING"));
        tfOneResponseActionItem.setCallWaitingPackage(resultSet.getString("CALL_WAITING_PACKAGE"));
        tfOneResponseActionItem.setRtpServer(resultSet.getString("RTP_SERVER"));
        tfOneResponseActionItem.setDigitalFeatureCode(resultSet.getString("DIGITAL_FEATURE_CODE"));
        tfOneResponseActionItem.setStateField(resultSet.getString("STATE_FIELD"));
        tfOneResponseActionItem.setZipCode(resultSet.getString("ZIP_CODE"));
        tfOneResponseActionItem.setMsid(resultSet.getString("MSID"));
        tfOneResponseActionItem.setNewMsidFlag(resultSet.getString("NEW_MSID_FLAG"));
        tfOneResponseActionItem.setSms(resultSet.getString("SMS"));
        tfOneResponseActionItem.setSmsPackage(resultSet.getString("SMS_PACKAGE"));
        tfOneResponseActionItem.setIccid(resultSet.getString(ICCID));
        tfOneResponseActionItem.setOldMin(resultSet.getString("OLD_MIN"));
        tfOneResponseActionItem.setDigitalFeature(resultSet.getString("DIGITAL_FEATURE"));
        tfOneResponseActionItem.setOtaType(resultSet.getString("OTA_TYPE"));
        tfOneResponseActionItem.setRateCenterNo(resultSet.getString("RATE_CENTER_NO"));
        tfOneResponseActionItem.setApplicationSystem(resultSet.getString("APPLICATION_SYSTEM"));
        tfOneResponseActionItem.setSubscriberUpdate(resultSet.getString("SUBSCRIBER_UPDATE"));
        tfOneResponseActionItem.setDownloadDate(resultSet.getString("DOWNLOAD_DATE"));
        tfOneResponseActionItem.setPrlNumber(resultSet.getString("PRL_NUMBER"));
        tfOneResponseActionItem.setAmount(resultSet.getString("AMOUNT"));
        tfOneResponseActionItem.setBalance(resultSet.getString("BALANCE"));
        tfOneResponseActionItem.setLanguage(resultSet.getString("LANGUAGE"));
        tfOneResponseActionItem.setExpDate(resultSet.getString("EXP_DATE"));
        tfOneResponseActionItem.setxMpn(resultSet.getString("X_MPN"));
        tfOneResponseActionItem.setxMpnCode(resultSet.getString("X_MPN_CODE"));
        tfOneResponseActionItem.setxPoolName(resultSet.getString("X_POOL_NAME"));
        tfOneResponseActionItem.setImsi(resultSet.getString("IMSI"));
        tfOneResponseActionItem.setNewImsiFlag(resultSet.getString("NEW_IMSI_FLAG"));
        tfOneResponseActionItem.setxMake(resultSet.getString("X_MAKE"));
        tfOneResponseActionItem.setxModel(resultSet.getString("X_MODEL"));
        tfOneResponseActionItem.setxMode(resultSet.getString("X_MODE"));
        tfOneResponseActionItem.setCarrierInitialTransTime(resultSet.getString("CARRIER_INITIAL_TRANS_TIME"));
        tfOneResponseActionItem.setCarrierEndTransTime(resultSet.getString("CARRIER_END_TRANS_TIME"));
        tfOneResponseActionItem.setIgCarrSecsToComp(resultSet.getString("IGCARR_SECS_TO_COMP"));
        tfOneResponseActionItem.setCfExtensionCount(resultSet.getString("CF_EXTENSION_COUNT"));
        tfOneResponseActionItem.setDataSaver(resultSet.getString("DATA_SAVER"));
        tfOneResponseActionItem.setDataSaverCode(resultSet.getString("DATA_SAVER_CODE"));
        tfOneResponseActionItem.setxCampaignName(resultSet.getString("X_CAMPAIGN_NAME"));
        tfOneResponseActionItem.setCarrierFeatureObjid(resultSet.getString("CARRIER_FEATURE_OBJID"));
        tfOneResponseActionItem.setCfProfileId(resultSet.getString("CF_PROFILE_ID"));
        tfOneResponseActionItem.setRpExtObjid(resultSet.getString("RP_EXT_OBJID"));
        tfOneResponseActionItem.setFirstName(resultSet.getString("FIRST_NAME"));
        tfOneResponseActionItem.setMiddleInitial(resultSet.getString("MIDDLE_INITIAL"));
        tfOneResponseActionItem.setLastName(resultSet.getString("LAST_NAME"));
        tfOneResponseActionItem.setSuffix(resultSet.getString("SUFFIX"));
        tfOneResponseActionItem.setPrefix(resultSet.getString("PREFIX"));
        tfOneResponseActionItem.setSsnLast4(resultSet.getString("SSN_LAST_4"));
        tfOneResponseActionItem.setAddress1(resultSet.getString("ADDRESS_1"));
        tfOneResponseActionItem.setAddress2(resultSet.getString("ADDRESS_2"));
        tfOneResponseActionItem.setCity(resultSet.getString("CITY"));
        tfOneResponseActionItem.setState(resultSet.getString("STATE"));
        tfOneResponseActionItem.setZipCode1(resultSet.getString("ZIP_CODE_ADDL"));
        tfOneResponseActionItem.setCountry(resultSet.getString("COUNTRY"));
        tfOneResponseActionItem.setOspAccount(resultSet.getString("OSP_ACCOUNT"));
        tfOneResponseActionItem.setCurrAddrHouseNumber(resultSet.getString("CURR_ADDR_HOUSE_NUMBER"));
        tfOneResponseActionItem.setCurrAddrDirection(resultSet.getString("CURR_ADDR_DIRECTION"));
        tfOneResponseActionItem.setCurrAddrStreetName(resultSet.getString("CURR_ADDR_STREET_NAME"));
        tfOneResponseActionItem.setCurrAddrStreetType(resultSet.getString("CURR_ADDR_STREET_TYPE"));
        tfOneResponseActionItem.setCurrAddrUnit(resultSet.getString("CURR_ADDR_UNIT"));
        tfOneResponseActionItem.setServicePlanId(resultSet.getString("SERVICE_PLAN_ID"));
        tfOneResponseActionItem.seteSimFlag(resultSet.getString("E_SIM_FLAG"));
        //Set if the Transaction has buckets
        tfOneResponseActionItem.setHasBuckets(!resultSet.getString("BUCKET_COUNT").equals("0"));
        tfOneResponseActionItem.setIgTransInProgress(resultSet.getString("IGTRANSIP_COUNT"));
        if (tracfoneOneActionItemId.isShowFailLogs()) {
            tfOneResponseActionItem.setIgFailLogs(resultSet.getString("IGFAIL_LOGS_COUNT"));
        }
        if (!missedDbColumns.isEmpty()){
            for (String columns : missedDbColumns) {
                additionalDbColMap.put(columns, resultSet.getString(columns));
            }
        tfOneResponseActionItem.setAdditionalDbColumns(additionalDbColMap);
    }
    }

    private StringBuilder buildNullOrNotInClause(int size, StringBuilder sbuilder, String optionalFieldName) {
        sbuilder = buildQueryParamStringForNotINs(size, sbuilder, optionalFieldName, true);
        sbuilder = buildNullClause(sbuilder, optionalFieldName, OR);
        return sbuilder.append(")");
    }

    private StringBuilder buildNullClause(StringBuilder sbuilder, String optionalFieldName, String connector) {
        return sbuilder.append(connector).append(optionalFieldName).append(" IS NULL ");
    }

    /**
     * @param tracfoneOneRework
     * @param userId
     * @return
     * @throws TracfoneOneException
     */
    @Override
    public TFOneGeneralResponse reworkBatchTransaction(TracfoneOneRework tracfoneOneRework, boolean isRework, Integer userId)
            throws TracfoneOneException {
        if (!StringUtils.isNullOrEmpty(tracfoneOneRework.getChunkSize())) {
            List<String> transactionIds = getAllTransactionIdsFromSearch(tracfoneOneRework, userId);
            tracfoneOneRework.getSearchCriteria().setTransactionId(transactionIds);
        }
        LOGGER.info("Request for rework is " + tracfoneOneRework);
        Connection con = null;
        PreparedStatement stmt = null;
        Gson gson = new Gson();
        int preparedStmtCnt = 1;
        int rowsUpdated = 0;

        // Get the object for the search criteria.
        TracfoneOneActionItemId tracfoneOneActionItemId = tracfoneOneRework.getSearchCriteria();

        boolean esnPresent = checkIfNullOrEmpty(tracfoneOneActionItemId.getEsn());
        boolean orderTypePresent = checkIfNullOrEmpty(tracfoneOneActionItemId.getOrderType());
        boolean statusPresent = checkIfNullOrEmpty(tracfoneOneActionItemId.getStatus());
        boolean tidPresent = checkIfNullOrEmpty(tracfoneOneActionItemId.getTransactionId());
        boolean statusMsgPresentExactMatch = checkIfNullOrEmpty(tracfoneOneActionItemId.getStatusMessage()) && tracfoneOneActionItemId.isIsExactMatch();
        boolean statusMsgPresentWildCard = checkIfNullOrEmpty(tracfoneOneActionItemId.getStatusMessage()) && !tracfoneOneActionItemId.isIsExactMatch();
        boolean statusMsgNotIn = checkIfNullOrEmpty(tracfoneOneActionItemId.getStatusMessage()) && tracfoneOneActionItemId.isNotInStatusMessage();
        boolean aidNotIn = checkIfNullOrEmpty(tracfoneOneActionItemId.getActionItemId()) && tracfoneOneActionItemId.isNotInActionItemId();
        boolean aidPresentExactMatch = checkIfNullOrEmpty(tracfoneOneActionItemId.getActionItemId()) && tracfoneOneActionItemId.isExactMatchForActionItemId();
        boolean aidPresentWildCard = checkIfNullOrEmpty(tracfoneOneActionItemId.getActionItemId()) && !tracfoneOneActionItemId.isExactMatchForActionItemId();
        boolean creationDatePresent = checkIfNotNullOrEmpty(tracfoneOneActionItemId.getCreationFromDate());
        boolean udpateDatePresent = checkIfNotNullOrEmpty(tracfoneOneActionItemId.getUpdateFromDate());
        boolean additionalFields = (tracfoneOneActionItemId.getAdditionalColumns() != null && !tracfoneOneActionItemId.getAdditionalColumns().isEmpty());
        boolean primaryFieldPresent = esnPresent || orderTypePresent || statusPresent || tidPresent
                || statusMsgPresentExactMatch || statusMsgPresentWildCard || creationDatePresent
                || udpateDatePresent || aidPresentExactMatch || aidPresentWildCard;

        if (!primaryFieldPresent && additionalFields) {
            throw new TracfoneOneException(TRACFONE_VIEWTRANSACTION_PRIMARYMISSING_CODE, TRACFONE_VIEWTRANSACTION_PRIMARYMISSING_MESSAGE);
        }

        //Not INS
        boolean notInStatus = tracfoneOneActionItemId.isNotInStatus();
        boolean notInOrderType = tracfoneOneActionItemId.isNotInOrderType();

        try {
            con = dbControllerEJB.getDataSource(tracfoneOneActionItemId.getDbenv()).getConnection();

            // 1. BUILD THE WHERE CONDITION for the search section of the BLOCK.
            StringBuilder sbuilder = new StringBuilder(TracfoneOneConstantAction.ACTION_SQL_REWORKTRANSACTION_SEARCH);

            if (aidNotIn) {
                sbuilder = buildQueryParamStringForNotINs(tracfoneOneActionItemId.getActionItemId().size(), sbuilder, IG_ACTION_ITEM_ID, false);
            } else if (aidPresentWildCard) {
                sbuilder.append(AND_IG_ACTION_ITEM_ID_LIKE);
            } else if (aidPresentExactMatch) {
                sbuilder = buildQueryParamString(tracfoneOneActionItemId.getActionItemId().size(), sbuilder, IG_ACTION_ITEM_ID);
            }

            if (esnPresent)
                sbuilder = buildQueryParamString(tracfoneOneActionItemId.getEsn().size(), sbuilder, IG_ESN);
            if (orderTypePresent) {
                if (notInOrderType) {
                    sbuilder = buildQueryParamStringForNotINs(tracfoneOneActionItemId.getOrderType().size(), sbuilder, IG_ORDER_TYPE, false);
                } else {
                    sbuilder = buildQueryParamString(tracfoneOneActionItemId.getOrderType().size(), sbuilder, IG_ORDER_TYPE);
                }
            }
            if (statusPresent) {
                if (notInStatus) {
                    sbuilder = buildQueryParamStringForNotINs(tracfoneOneActionItemId.getStatus().size(), sbuilder, IG_STATUS, false);
                } else {
                    sbuilder = buildQueryParamString(tracfoneOneActionItemId.getStatus().size(), sbuilder, IG_STATUS);
                }
            }
            if (tidPresent) {
                if (tracfoneOneActionItemId.getTransactionId().size() < 1000) {
                    sbuilder = buildQueryParamString(tracfoneOneActionItemId.getTransactionId().size(), sbuilder, IG_TRANSACTION_ID);
                } else {
                    List<List<String>> splitIds = Lists.partition(tracfoneOneActionItemId.getTransactionId(), 1000);
                    sbuilder.append(AND).append("(");
                    StringBuilder transBuilder = new StringBuilder();
                    for (List<String> transactionIds : splitIds) {
                        StringBuilder tempBuilder = new StringBuilder();
                        tempBuilder = buildQueryParamString(transactionIds.size(), tempBuilder, IG_TRANSACTION_ID);
                        transBuilder.append(tempBuilder.substring(4));
                        transBuilder.append(OR);
                        LOGGER.info("transactions ids query " + transBuilder);
                    }
                    sbuilder = sbuilder.append(transBuilder.substring(0, transBuilder.lastIndexOf(OR))).append(")");
                    LOGGER.info("sbuilder query " + sbuilder);
                }
            }

            if (statusMsgNotIn) {
                sbuilder = buildQueryParamStringForNotINs(tracfoneOneActionItemId.getStatusMessage().size(), sbuilder, IG_STATUS_MESSAGE, false);
            } else if (statusMsgPresentWildCard) {
                sbuilder.append(AND_IG_STATUS_MESSAGE_LIKE);
            } else if (statusMsgPresentExactMatch) {
                sbuilder = buildQueryParamString(tracfoneOneActionItemId.getStatusMessage().size(), sbuilder, IG_STATUS_MESSAGE);
            }
            if (creationDatePresent)
                sbuilder.append(" AND ig.CREATION_DATE >= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ig.CREATION_DATE <= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS')");
            if (udpateDatePresent)
                sbuilder.append(AND_UPDATE_DATE);

            //Additional Fields are present, add them.
            if (additionalFields) {
                Iterator<TracfoneOneSearchAdditionalModel> itr = tracfoneOneActionItemId.getAdditionalColumns().iterator();

                while (itr.hasNext()) {
                    TracfoneOneSearchAdditionalModel additionalColumn = itr.next();

                    String optionalFieldVal = ControllerUtil.getDBColumnName(additionalColumn.getSearchColumnName());
                    boolean validOptionalVals = false;

                    for (String optionalFieldVals : additionalColumn.getSearchValues()) {
                        if (!StringUtils.isNullOrEmpty(optionalFieldVals)) {
                            validOptionalVals = true;
                            break;
                        }
                    }

                    // Append optional field query param.
                    if (validOptionalVals && !StringUtils.isNullOrEmpty(optionalFieldVal)) {
                        if (NULL.equalsIgnoreCase(additionalColumn.getSearchValues().get(0))) {
                            sbuilder = buildNullClause(sbuilder, optionalFieldVal, AND);
                        } else if (additionalColumn.isSearchIsColumnNotIn()) {
                            sbuilder = buildNullOrNotInClause(additionalColumn.getSearchValues().size(), sbuilder, optionalFieldVal);
                        } else if (additionalColumn.isSearchIsColumnLike()) {
                            sbuilder = buildQueryParamStringForLike(additionalColumn.getSearchValues().size(), sbuilder, optionalFieldVal);
                        } else {
                            sbuilder = buildQueryParamString(additionalColumn.getSearchValues().size(), sbuilder, optionalFieldVal);
                        }
                    } else {
                        itr.remove();
                    }
                }
            }

            // append semicolon to close where clause.
            sbuilder.append(";");
            //append the collision part of the anonymous SQL block.
            sbuilder.append(TracfoneOneConstantAction.ACTION_SQL_REWORKTRANSACTION_COLLISIONCHECK);

            // Get all fields to be reworked.
            TFOneAdminActionItem transactionReworkFields = tracfoneOneRework.getReworkCriteria();

            try {
                // Append the bucket tab block to the SQL if needed.
                sbuilder = buildBucketTableSQL(sbuilder, transactionReworkFields);

            } catch (ParseException ex) {
                throw new TracfoneOneException(TracfoneOneConstantAction.TRACFONE_BUCKET_DATE_PARSE_ERROR, TracfoneOneConstantAction.TRACFONE_BUCKET_DATE_PARSE_ERROR_MESSAGE);
            } catch (TracfoneOneException tOneEx) {
                throw tOneEx;
            } catch (Exception e) {
                throw new TracfoneOneException(TracfoneOneConstantAction.TRACFONE_BUCKET_DATE_UNKNOWN_ERROR, TracfoneOneConstantAction.TRACFONE_BUCKET_DATE_UNKNOWN_ERROR_MESSAGE);
            }
            // 2. BUILD THE UPDATE CONDITION of the SQL BLOCK.
            sbuilder = buildUpdateStatement(sbuilder, transactionReworkFields);
            LOGGER.info("REWORK RELATED SQL " + sbuilder);
            // 4. Prepare statement SEARCH section of SQL block.
            stmt = con.prepareStatement(sbuilder.toString());
            stmt.setInt(preparedStmtCnt++, userId);
            if (isRework) {
                stmt.setString(preparedStmtCnt++, "REWORK");
            } else {
                stmt.setString(preparedStmtCnt++, "RE-QUEUE");
            }
            if (aidPresentExactMatch || aidNotIn) {
                for (String aid : tracfoneOneActionItemId.getActionItemId()) {
                    stmt.setString(preparedStmtCnt++, aid);
                }
            } else if (aidPresentWildCard) {
                stmt.setString(preparedStmtCnt++, tracfoneOneActionItemId.getActionItemId().get(0) + "%");
            }
            if (esnPresent) {
                for (String esn : tracfoneOneActionItemId.getEsn()) {
                    stmt.setString(preparedStmtCnt++, esn);
                }
            }
            if (orderTypePresent) {
                for (String orderType : tracfoneOneActionItemId.getOrderType()) {
                    stmt.setString(preparedStmtCnt++, orderType);
                }
            }
            if (statusPresent) {
                for (String status : tracfoneOneActionItemId.getStatus()) {
                    stmt.setString(preparedStmtCnt++, status);
                }
            }
            if (tidPresent) {
                for (String tid : tracfoneOneActionItemId.getTransactionId()) {
                    stmt.setString(preparedStmtCnt++, tid);
                }
            }
            if (statusMsgPresentExactMatch || statusMsgNotIn) {
                for (String statusMessage : tracfoneOneActionItemId.getStatusMessage()) {
                    stmt.setString(preparedStmtCnt++, statusMessage);
                }
            } else if (statusMsgPresentWildCard) {
                stmt.setString(preparedStmtCnt++, "%" + tracfoneOneActionItemId.getStatusMessage().get(0).trim() + "%");
            }
            if (creationDatePresent) {
                stmt.setString(preparedStmtCnt++, tracfoneOneActionItemId.getCreationFromDate());
                //to date
                if (tracfoneOneActionItemId.getCreationToDate() != null && !tracfoneOneActionItemId.getCreationToDate().isEmpty()) {
                    stmt.setString(preparedStmtCnt++, tracfoneOneActionItemId.getCreationToDate());
                } else {
                    stmt.setString(preparedStmtCnt++, getDefaultTodayDate());
                }
            }
            if (udpateDatePresent) {
                stmt.setString(preparedStmtCnt++, tracfoneOneActionItemId.getUpdateFromDate());
                //to date
                if (tracfoneOneActionItemId.getUpdateToDate() != null && !tracfoneOneActionItemId.getUpdateToDate().isEmpty()) {
                    stmt.setString(preparedStmtCnt++, tracfoneOneActionItemId.getUpdateToDate());
                } else {
                    stmt.setString(preparedStmtCnt++, getDefaultTodayDate());
                }
            }
            // Additional Fileds
            if (additionalFields) {
                for (TracfoneOneSearchAdditionalModel additionalColumn : tracfoneOneActionItemId.getAdditionalColumns()) {
                    for (String additionalFieldValue : additionalColumn.getSearchValues()) {
                        if (NULL.equalsIgnoreCase(additionalFieldValue)) {
                            break;
                        }
                        if (additionalColumn.isSearchIsColumnLike()) {
                            stmt.setString(preparedStmtCnt++, additionalFieldValue.trim() + "%");
                        } else {
                            stmt.setString(preparedStmtCnt++, additionalFieldValue);
                        }
                    }
                }
            }
            // 4. Prepare statement UPDATE section of SQL Block.
            if (null != (transactionReworkFields.getActionItemId()) && !transactionReworkFields.getActionItemId().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getActionItemId());
            }
            if (null != (transactionReworkFields.getCarrierId()) && !transactionReworkFields.getCarrierId().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCarrierId());
            }
            if (null != (transactionReworkFields.getOrderType()) && !transactionReworkFields.getOrderType().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getOrderType());
            }
            if (null != (transactionReworkFields.getMin()) && !transactionReworkFields.getMin().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getMin());
            }
            if (null != (transactionReworkFields.getEsn()) && !transactionReworkFields.getEsn().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getEsn());
            }
            if (null != (transactionReworkFields.getEsnHex()) && !transactionReworkFields.getEsnHex().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getEsnHex());
            }
            if (null != (transactionReworkFields.getOldEsn()) && !transactionReworkFields.getOldEsn().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getOldEsn());
            }
            if (null != (transactionReworkFields.getOldEsnHex()) && !transactionReworkFields.getOldEsnHex().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getOldEsnHex());
            }
            if (null != (transactionReworkFields.getPin()) && !transactionReworkFields.getPin().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getPin());
            }
            if (null != (transactionReworkFields.getPhoneManf()) && !transactionReworkFields.getPhoneManf().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getPhoneManf());
            }
            if (null != (transactionReworkFields.getEndUser()) && !transactionReworkFields.getEndUser().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getEndUser());
            }
            if (null != (transactionReworkFields.getAccountNum()) && !transactionReworkFields.getAccountNum().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getAccountNum());
            }
            if (null != (transactionReworkFields.getMarketCode()) && !transactionReworkFields.getMarketCode().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getMarketCode());
            }
            if (null != (transactionReworkFields.getRatePlan()) && !transactionReworkFields.getRatePlan().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getRatePlan());
            }
            if (null != (transactionReworkFields.getLdProvider()) && !transactionReworkFields.getLdProvider().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getLdProvider());
            }
            if (null != (transactionReworkFields.getDealerCode()) && !transactionReworkFields.getDealerCode().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getDealerCode());
            }
            if (null != (transactionReworkFields.getTransmissionMethod()) && !transactionReworkFields.getTransmissionMethod().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getTransmissionMethod());
            }
            if (null != (transactionReworkFields.getFaxNum()) && !transactionReworkFields.getFaxNum().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getFaxNum());
            }
            if (null != (transactionReworkFields.getOnlineNum()) && !transactionReworkFields.getOnlineNum().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getOnlineNum());
            }
            if (null != (transactionReworkFields.getEmail()) && !transactionReworkFields.getEmail().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getEmail());
            }
            if (null != (transactionReworkFields.getTemplate()) && !transactionReworkFields.getTemplate().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getTemplate());
            }
            if (null != (transactionReworkFields.getExeName()) && !transactionReworkFields.getExeName().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getExeName());
            }
            if (null != (transactionReworkFields.getComPort()) && !transactionReworkFields.getComPort().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getComPort());
            }
            if (null != (transactionReworkFields.getStatus()) && !transactionReworkFields.getStatus().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getStatus());
            }
            if (null != (transactionReworkFields.getStatusMessage()) && !transactionReworkFields.getStatusMessage().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getStatusMessage());
            }
            if (null != (transactionReworkFields.getFaxBatchSize()) && !transactionReworkFields.getFaxBatchSize().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getFaxBatchSize());
            }
            if (null != (transactionReworkFields.getFaxBatchQtime()) && !transactionReworkFields.getFaxBatchQtime().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getFaxBatchQtime());
            }
            if (null != (transactionReworkFields.getExpidite()) && !transactionReworkFields.getExpidite().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getExpidite());
            }
            if (null != (transactionReworkFields.getqTransaction()) && !transactionReworkFields.getqTransaction().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getqTransaction());
            }
            if (null != (transactionReworkFields.getOnlineNum2()) && !transactionReworkFields.getOnlineNum2().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getOnlineNum2());
            }
            if (null != (transactionReworkFields.getFaxNum2()) && !transactionReworkFields.getFaxNum2().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getFaxNum2());
            }
            if (null != (transactionReworkFields.getCreationDate()) && !transactionReworkFields.getCreationDate().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCreationDate());
            }
            if (null != (transactionReworkFields.getTuxItiServer()) && !transactionReworkFields.getTuxItiServer().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getTuxItiServer());
            }
            if (null != (transactionReworkFields.getTechnologyFlag()) && !transactionReworkFields.getTechnologyFlag().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getTechnologyFlag());
            }
            if (null != (transactionReworkFields.getVoiceMail()) && !transactionReworkFields.getVoiceMail().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getVoiceMail());
            }
            if (null != (transactionReworkFields.getVoiceMailPackage()) && !transactionReworkFields.getVoiceMailPackage().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getVoiceMailPackage());
            }
            if (null != (transactionReworkFields.getCallerId()) && !transactionReworkFields.getCallerId().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCallerId());
            }
            if (null != (transactionReworkFields.getCallerIdPackage()) && !transactionReworkFields.getCallerIdPackage().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCallerIdPackage());
            }
            if (null != (transactionReworkFields.getCallWaiting()) && !transactionReworkFields.getCallWaiting().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCallWaiting());
            }
            if (null != (transactionReworkFields.getCallWaitingPackage()) && !transactionReworkFields.getCallWaitingPackage().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCallWaitingPackage());
            }
            if (null != (transactionReworkFields.getRtpServer()) && !transactionReworkFields.getRtpServer().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getRtpServer());
            }
            if (null != (transactionReworkFields.getDigitalFeatureCode()) && !transactionReworkFields.getDigitalFeatureCode().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getDigitalFeatureCode());
            }
            if (null != (transactionReworkFields.getStateField()) && !transactionReworkFields.getStateField().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getStateField());
            }
            if (null != (transactionReworkFields.getZipCode()) && !transactionReworkFields.getZipCode().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getZipCode());
            }
            if (null != (transactionReworkFields.getMsid()) && !transactionReworkFields.getMsid().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getMsid());
            }
            if (null != (transactionReworkFields.getNewMsidFlag()) && !transactionReworkFields.getNewMsidFlag().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getNewMsidFlag());
            }
            if (null != (transactionReworkFields.getSms()) && !transactionReworkFields.getSms().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getSms());
            }
            if (null != (transactionReworkFields.getSmsPackage()) && !transactionReworkFields.getSmsPackage().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getSmsPackage());
            }
            if (null != (transactionReworkFields.getIccid()) && !transactionReworkFields.getIccid().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getIccid());
            }
            if (null != (transactionReworkFields.getOldMin()) && !transactionReworkFields.getOldMin().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getOldMin());
            }
            if (null != (transactionReworkFields.getDigitalFeature()) && !transactionReworkFields.getDigitalFeature().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getDigitalFeature());
            }
            if (null != (transactionReworkFields.getOtaType()) && !transactionReworkFields.getOtaType().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getOtaType());
            }
            if (null != (transactionReworkFields.getRateCenterNo()) && !transactionReworkFields.getRateCenterNo().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getRateCenterNo());
            }
            if (null != (transactionReworkFields.getApplicationSystem()) && !transactionReworkFields.getApplicationSystem().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getApplicationSystem());
            }
            if (null != (transactionReworkFields.getSubscriberUpdate()) && !transactionReworkFields.getSubscriberUpdate().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getSubscriberUpdate());
            }
            if (null != (transactionReworkFields.getDownloadDate()) && !transactionReworkFields.getDownloadDate().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getDownloadDate());
            }
            if (null != (transactionReworkFields.getPrlNumber()) && !transactionReworkFields.getPrlNumber().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getPrlNumber());
            }
            if (null != (transactionReworkFields.getAmount()) && !transactionReworkFields.getAmount().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getAmount());
            }
            if (null != (transactionReworkFields.getBalance()) && !transactionReworkFields.getBalance().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getBalance());
            }
            if (null != (transactionReworkFields.getLanguage()) && !transactionReworkFields.getLanguage().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getLanguage());
            }
            if (null != (transactionReworkFields.getExpDate()) && !transactionReworkFields.getExpDate().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getExpDate());
            }
            if (null != (transactionReworkFields.getxMpn()) && !transactionReworkFields.getxMpn().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getxMpn());
            }
            if (null != (transactionReworkFields.getxMpnCode()) && !transactionReworkFields.getxMpnCode().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getxMpnCode());
            }
            if (null != (transactionReworkFields.getxPoolName()) && !transactionReworkFields.getxPoolName().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getxPoolName());
            }
            if (null != (transactionReworkFields.getNewImsiFlag()) && !transactionReworkFields.getNewImsiFlag().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getNewImsiFlag());
            }
            if (null != (transactionReworkFields.getxMake()) && !transactionReworkFields.getxMake().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getxMake());
            }
            if (null != (transactionReworkFields.getxModel()) && !transactionReworkFields.getxModel().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getxModel());
            }
            if (null != (transactionReworkFields.getxMode()) && !transactionReworkFields.getxMode().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getxMode());
            }
            if (null != (transactionReworkFields.getDataSaver()) && !transactionReworkFields.getDataSaver().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getDataSaver());
            }
            if (null != (transactionReworkFields.getDataSaverCode()) && !transactionReworkFields.getDataSaverCode().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getDataSaverCode());
            }
            if (null != (transactionReworkFields.getxCampaignName()) && !transactionReworkFields.getxCampaignName().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getxCampaignName());
            }
            if (null != (transactionReworkFields.getCarrierFeatureObjid()) && !transactionReworkFields.getCarrierFeatureObjid().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCarrierFeatureObjid());
            }
            if (null != (transactionReworkFields.getCfProfileId()) && !transactionReworkFields.getCfProfileId().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCfProfileId());
            }
            if (null != (transactionReworkFields.getRpExtObjid()) && !transactionReworkFields.getRpExtObjid().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getRpExtObjid());
            }
            if (null != (transactionReworkFields.getCarrierAccountId()) && !transactionReworkFields.getCarrierAccountId().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCarrierAccountId());
            }
            if (null != (transactionReworkFields.getTmoNextGenFlag()) && !transactionReworkFields.getTmoNextGenFlag().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getTmoNextGenFlag());
            }
            if (null != (transactionReworkFields.getServicePlanId()) && !transactionReworkFields.getServicePlanId().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getServicePlanId());
            }
            if (null != (transactionReworkFields.geteSimFlag()) && !transactionReworkFields.geteSimFlag().contains("CLM_")) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.geteSimFlag());
            }

            //additional address fields

            if (null != (transactionReworkFields.getFirstName())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getFirstName());
            }
            if (null != (transactionReworkFields.getMiddleInitial())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getMiddleInitial());
            }
            if (null != (transactionReworkFields.getLastName())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getLastName());
            }
            if (null != (transactionReworkFields.getSuffix())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getSuffix());
            }
            if (null != (transactionReworkFields.getPrefix())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getPrefix());
            }
            if (null != (transactionReworkFields.getSsnLast4())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getSsnLast4());
            }
            if (null != (transactionReworkFields.getAddress1())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getAddress1());
            }
            if (null != (transactionReworkFields.getAddress2())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getAddress2());
            }
            if (null != (transactionReworkFields.getCity())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCity());
            }
            if (null != (transactionReworkFields.getState())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getState());
            }
            if (null != (transactionReworkFields.getZipCode1())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getZipCode1());
            }
            if (null != (transactionReworkFields.getCountry())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCountry());
            }
            if (null != (transactionReworkFields.getOspAccount())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getOspAccount());
            }
            if (null != (transactionReworkFields.getCurrAddrHouseNumber())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCurrAddrHouseNumber());
            }
            if (null != (transactionReworkFields.getCurrAddrDirection())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCurrAddrDirection());
            }
            if (null != (transactionReworkFields.getCurrAddrStreetName())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCurrAddrStreetName());
            }
            if (null != (transactionReworkFields.getCurrAddrStreetType())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCurrAddrStreetType());
            }
            if (null != (transactionReworkFields.getCurrAddrUnit())) {
                stmt.setString(preparedStmtCnt++, transactionReworkFields.getCurrAddrUnit());
            }

            rowsUpdated = stmt.executeUpdate();

            boolean isNextGenFlag = TMO_NEXT_GEN_FLAGS.contains(transactionReworkFields.getTmoNextGenFlag());

            if (transactionReworkFields.getTmoNextGenFlag() != null && isNextGenFlag) {
                for (String transactionId : tracfoneOneActionItemId.getTransactionId()) {
                    updateBucketTiers(con, transactionReworkFields, transactionId);
                }
            }

        } catch (SQLException | NamingException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, ex);
        } finally {
            try {
                try {
                    if (stmt != null) {
                        stmt.close();
                    }
                } catch (Exception ex) {
                }
                try {
                    if (con != null) {
                        con.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }

                TracfoneAudit audit = new TracfoneAudit(userId, "Rework", gson.toJson(tracfoneOneActionItemId), CARRIER_ID);
                tracfoneAuditEvent.fire(audit);
            } catch (Exception ex) {
                LOGGER.error(ex);
            }
        }
        return new TFOneGeneralResponse("Success", "Total Transactions reworked: " + rowsUpdated);
    }

    private List<String> getAllTransactionIdsFromSearch(TracfoneOneRework tracfoneOneRework, int userId) {
        List<String> transactionIds = new ArrayList<>();
        TracfoneOneActionItemId searchCriteria = tracfoneOneRework.getSearchCriteria();
        searchCriteria.getPaginationSearch().setEndIndex(Integer.valueOf(tracfoneOneRework.getChunkSize()));

        try {
            TracfoneOneViewActionItems searchResults = viewAidDirectly(searchCriteria, userId);
            if (!searchResults.getActionItems().isEmpty()) {
                transactionIds = searchResults.getActionItems()
                        .stream()
                        .map(a -> a.getTransactionId())
                        .collect(Collectors.toList());
                LOGGER.debug("Transaction ids retrieved are " + transactionIds);
            }
        } catch (TracfoneOneException e) {
            LOGGER.error("Error when searching with chunk size ", e);
        }
        return transactionIds;
    }

    private void updateBucketTiers(Connection con, TFOneAdminActionItem transactionReworkFields, String transactionId) throws TracfoneOneException {
        LOGGER.debug("Transaction id being deleted is " + transactionId);
        for (TFOneActionItemBucket bucket : transactionReworkFields.getBuckets()) {
            String bucketId = bucket.getBucketId();
            LOGGER.debug("Bucket id being deleted is " + bucketId);
            try (PreparedStatement stmt = con.prepareStatement(TracfoneOneConstantAction.ACTION_DELETE_BUCKET_TIERS)) {
                stmt.setString(1, transactionId);
                stmt.setString(2, bucketId);
                stmt.executeUpdate();
            } catch (SQLException ex) {
                LOGGER.error(ex);
                throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, ex);
            }
        }
        insertBucketTiers(con, transactionReworkFields.getBuckets(), transactionId);
    }

    @Override
    public TFOneGeneralResponse insertTransaction(TracfoneOneNewTransaction tfOneNewTransaction, int userId, String userInitials) throws TracfoneOneException {
        return insertTransaction(tfOneNewTransaction, userId, userInitials, false, userInitials);
    }

    public TFOneGeneralResponse insertTransaction(TracfoneOneNewTransaction tfOneNewTransaction, int userId, String userInitials, boolean fireArchiveEvent, String bulkInsertIdentifier) throws TracfoneOneException {

        String actionItemId = "";
        Connection con = null;
        PreparedStatement stmt = null;
        String sqlBuilder = TRACFONE_INSERT_TRANSACTION;
        Gson gson = new Gson();

        try {
            con = dbControllerEJB.getDataSource(tfOneNewTransaction.getDbenv()).getConnection();
            if (tfOneNewTransaction.isTestEnv()) {
                addTestOtaEsn(con, tfOneNewTransaction);
                addTestIgateEsn(con, tfOneNewTransaction);
            }
            List<TFOneFeatures> tfFeatures = tfOneNewTransaction.getFeatures();
            //Check for Features if/not Present
            sqlBuilder = getFeaturesSQL(tfFeatures, sqlBuilder);

            int index = 1;
            LOGGER.info("INSERT SQL " + sqlBuilder);
            stmt = con.prepareStatement(sqlBuilder);
            stmt.setString(index++, tfOneNewTransaction.getAppSys());

            if (tfOneNewTransaction.getRatePlanProfileId() == null)
                stmt.setNull(index++, java.sql.Types.INTEGER);
            else
                stmt.setInt(index++, tfOneNewTransaction.getRatePlanProfileId());

            if (tfOneNewTransaction.getCarrFeat() == null)
                stmt.setNull(index++, java.sql.Types.INTEGER);
            else
                stmt.setInt(index++, tfOneNewTransaction.getCarrFeat());

            // If no AID was passed, build one with user signature and date.
            actionItemId = userInitials != null && !userInitials.isEmpty() ? userInitials + getNextAIDSeq(con) : getNextAIDSeq(con);
            stmt.setString(index++, tfOneNewTransaction.getTemplate());
            stmt.setString(index++, actionItemId);
            stmt.setString(index++, tfOneNewTransaction.getCarrierId());
            stmt.setString(index++, tfOneNewTransaction.getOrderType());
            stmt.setString(index++, tfOneNewTransaction.getEsn());
            stmt.setString(index++, tfOneNewTransaction.getEsnHex());
            stmt.setString(index++, tfOneNewTransaction.getIccid());
            stmt.setString(index++, tfOneNewTransaction.getMin());
            stmt.setString(index++, tfOneNewTransaction.getMsid());
            stmt.setString(index++, tfOneNewTransaction.getRatePlan());
            stmt.setString(index++, tfOneNewTransaction.getNetworkLogin());
            stmt.setString(index++, tfOneNewTransaction.getNetworkPassword());
            stmt.setString(index++, tfOneNewTransaction.getAccountNum());
            stmt.setString(index++, tfOneNewTransaction.getDealerCode());
            stmt.setString(index++, tfOneNewTransaction.getMarketCode());
            stmt.setString(index++, tfOneNewTransaction.getComPort());
            stmt.setString(index++, tfOneNewTransaction.getRateCenterNo());
            stmt.setString(index++, tfOneNewTransaction.getZipCode());
            stmt.setString(index++, tfOneNewTransaction.getStatus());
            stmt.setString(index++, tfOneNewTransaction.getqTransaction());
            stmt.setString(index++, tfOneNewTransaction.getLdProvider());
            stmt.setString(index++, tfOneNewTransaction.getTechFlag());
            stmt.setString(index++, tfOneNewTransaction.getTransMethod());
            stmt.setString(index++, tfOneNewTransaction.getBalance());
            stmt.setString(index++, tfOneNewTransaction.getOldMin());
            stmt.setString(index++, tfOneNewTransaction.getDigitalFeature());
            stmt.setString(index++, tfOneNewTransaction.getDigitalFeatureCode());
            stmt.setString(index++, tfOneNewTransaction.getVoiceMail());
            stmt.setString(index++, tfOneNewTransaction.getVoiceMailPackage());
            stmt.setString(index++, tfOneNewTransaction.getCallerId());
            stmt.setString(index++, tfOneNewTransaction.getCallerIdPackage());
            stmt.setString(index++, tfOneNewTransaction.getCallWaiting());
            stmt.setString(index++, tfOneNewTransaction.getCallWaitingPackage());
            stmt.setString(index++, tfOneNewTransaction.getSms());
            stmt.setString(index++, tfOneNewTransaction.getSmsPackage());
            stmt.setString(index++, tfOneNewTransaction.getMpn());
            stmt.setString(index++, tfOneNewTransaction.getMpnCode());
            stmt.setString(index++, tfOneNewTransaction.getIpPool());
            stmt.setString(index++, tfOneNewTransaction.getLanguage());
            stmt.setString(index++, tfOneNewTransaction.getDataSaver());
            stmt.setString(index++, tfOneNewTransaction.getDataSaverCode());
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);

            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);


            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);
            stmt.setNull(index++, java.sql.Types.VARCHAR);

            stmt.setString(index++, tfOneNewTransaction.getPhoneManf());
            if (tfOneNewTransaction.getExpireDate() != null && !tfOneNewTransaction.getExpireDate().isEmpty()) {
                stmt.setDate(index++, java.sql.Date.valueOf(tfOneNewTransaction.getExpireDate()));
            } else {
                stmt.setNull(index++, java.sql.Types.DATE);
            }
            if (tfOneNewTransaction.getDownloadDt() != null && !tfOneNewTransaction.getDownloadDt().isEmpty()) {
                stmt.setDate(index++, java.sql.Date.valueOf(tfOneNewTransaction.getDownloadDt()));
            } else {
                stmt.setNull(index++, java.sql.Types.DATE);
            }
            if (tfOneNewTransaction.getExpDt() != null && !tfOneNewTransaction.getExpDt().isEmpty()) {
                stmt.setDate(index++, java.sql.Date.valueOf(tfOneNewTransaction.getExpDt()));
            } else {
                stmt.setNull(index++, java.sql.Types.DATE);
            }
            stmt.setString(index++, tfOneNewTransaction.getFirstName());
            stmt.setString(index++, tfOneNewTransaction.getLastName());
            stmt.setString(index++, tfOneNewTransaction.getAddress1());
            stmt.setString(index++, tfOneNewTransaction.getAddress2());
            stmt.setString(index++, tfOneNewTransaction.getCity());
            stmt.setString(index++, tfOneNewTransaction.getState());
            stmt.setString(index++, tfOneNewTransaction.getZipCode1());
            stmt.setString(index++, tfOneNewTransaction.getPrlNumber());
            stmt.setString(index++, tfOneNewTransaction.getMake());
            stmt.setString(index++, tfOneNewTransaction.getModel());
            stmt.setString(index++, tfOneNewTransaction.getMiddleInitial());
            stmt.setString(index++, tfOneNewTransaction.getSuffix());
            stmt.setString(index++, tfOneNewTransaction.getPrefix());
            stmt.setString(index++, tfOneNewTransaction.getSsnLast4());
            stmt.setString(index++, tfOneNewTransaction.getCountry());
            stmt.setString(index++, tfOneNewTransaction.getOspAccount());
            stmt.setString(index++, tfOneNewTransaction.getCurrAddrHouseNumber());
            stmt.setString(index++, tfOneNewTransaction.getCurrAddrDirection());
            stmt.setString(index++, tfOneNewTransaction.getCurrAddrStreetName());
            stmt.setString(index++, tfOneNewTransaction.getCurrAddrStreetType());
            stmt.setString(index++, tfOneNewTransaction.getCurrAddrUnit());

            //new fields for remaining IG_Transaction columns
            stmt.setString(index++, tfOneNewTransaction.getOldEsn());
            stmt.setString(index++, tfOneNewTransaction.getOldEsnHex());
            stmt.setString(index++, tfOneNewTransaction.getSubscriberUpdate());
            stmt.setString(index++, tfOneNewTransaction.getSystemLogin());
            stmt.setString(index++, tfOneNewTransaction.getSystemPassword());
            stmt.setString(index++, tfOneNewTransaction.getImsi());
            stmt.setString(index++, tfOneNewTransaction.getNewImsiFlag());
            stmt.setString(index++, tfOneNewTransaction.getPin());
            stmt.setString(index++, tfOneNewTransaction.getCfExtensionCount());
            stmt.setString(index++, tfOneNewTransaction.getxCampaignName());
            stmt.setString(index++, tfOneNewTransaction.getAmount());
            stmt.setString(index++, tfOneNewTransaction.getFaxBatchSize());
            stmt.setString(index++, tfOneNewTransaction.getFaxNum2());
            stmt.setString(index++, tfOneNewTransaction.getFaxNum());
            stmt.setString(index++, tfOneNewTransaction.getFaxBatchQtime());
            stmt.setString(index++, tfOneNewTransaction.getOnlineNum());
            stmt.setString(index++, tfOneNewTransaction.getOnlineNum2());
            stmt.setString(index++, tfOneNewTransaction.getEmail());
            stmt.setString(index++, tfOneNewTransaction.getSequenceNum());
            stmt.setString(index++, tfOneNewTransaction.getOtaType());
            stmt.setString(index++, tfOneNewTransaction.getRtpServer());
            stmt.setString(index++, tfOneNewTransaction.getStateField());
            stmt.setString(index++, tfOneNewTransaction.getExeName());
            stmt.setString(index++, tfOneNewTransaction.getExpidite());
            stmt.setString(index++, tfOneNewTransaction.getBlackoutWait());
            stmt.setString(index++, tfOneNewTransaction.getTuxItiServer());
            stmt.setString(index++, tfOneNewTransaction.getTransProfKey());
            //set the rp_ext_objid

            if (tfOneNewTransaction.getRatePlanExtensionObjId() == null) {
                stmt.setNull(index++, java.sql.Types.INTEGER);
            } else {
                stmt.setInt(index++, tfOneNewTransaction.getRatePlanExtensionObjId());
            }

            if (tfOneNewTransaction.getCarrierAccountId() == null) {
                stmt.setNull(index++, java.sql.Types.INTEGER);
            } else {
                stmt.setInt(index++, tfOneNewTransaction.getCarrierAccountId());
            }

            if (tfOneNewTransaction.getServicePlanId() == null) {
                stmt.setNull(index++, java.sql.Types.INTEGER);
            } else {
                stmt.setInt(index++, tfOneNewTransaction.getServicePlanId());
            }

            // user id required for adding user history
            stmt.setInt(index++, userId);

            if (tfOneNewTransaction.getTmoNextGenFlag() == null) {
                stmt.setNull(index++, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(index++, tfOneNewTransaction.getTmoNextGenFlag());
            }

            if (tfOneNewTransaction.getEndUser() == null) {
                stmt.setNull(index++, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(index++, tfOneNewTransaction.getEndUser());
            }

            if (tfOneNewTransaction.getxMode() == null) {
                stmt.setNull(index++, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(index++, tfOneNewTransaction.getxMode());
            }

            if (tfOneNewTransaction.getNewMsidFlag() == null) {
                stmt.setNull(index++, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(index++, tfOneNewTransaction.getNewMsidFlag());
            }

            if (tfOneNewTransaction.geteSimFlag() == null) {
                stmt.setNull(index++, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(index++, tfOneNewTransaction.geteSimFlag());
            }

            List<TFOneActionItemBucket> buckets = tfOneNewTransaction.getBuckets();
            int bucketStmtPosition = 45;
            if (buckets != null && !buckets.isEmpty()) {

                for (TFOneActionItemBucket bucket : buckets) {

                    // Validate each bucket ID. Cannot be empty.
                    if (bucket.getBucketId().trim().isEmpty()) {
                        throw new TracfoneOneException(TracfoneOneConstantAction.TRACFONE_BUCKET_INVALID_ID_ERROR,
                                TracfoneOneConstantAction.TRACFONE_BUCKET_INVALID_ID_ERROR_MESSAGE);
                    }

                    stmt.setString(bucketStmtPosition++, bucket.getBucketId());
                    stmt.setString(bucketStmtPosition++, bucket.getBucketBalance());
                    stmt.setString(bucketStmtPosition++, bucket.getBucketValue());
                    stmt.setString(bucketStmtPosition++, bucket.getBenefitType());
                    stmt.setString(bucketStmtPosition++, bucket.getBucketType());
                    stmt.setString(bucketStmtPosition++, bucket.getBucketUsage());
                    stmt.setString(bucketStmtPosition++, bucket.getUnitOfMeasurement());
                    stmt.setString(bucketStmtPosition++, bucket.getBucketGroup());
                    stmt.setString(bucketStmtPosition++, bucket.getBucketRequirement());
                    stmt.setString(bucketStmtPosition++, bucket.getAutoRenewFlag());
                    stmt.setString(bucketStmtPosition++, bucket.getAutoRenewFrequency());
                    stmt.setString(bucketStmtPosition++, bucket.getAutoRenewValue());
                    stmt.setString(bucketStmtPosition++, bucket.getAutoRenewDay());
                    //This is added for Tracfone Unlimited
                    stmt.setString(bucketStmtPosition++, bucket.getBucketAction());

                    if (bucket.getExpirationDate() != null && !bucket.getExpirationDate().isEmpty()) {
                        stmt.setDate(bucketStmtPosition++, java.sql.Date.valueOf(bucket.getExpirationDate()));
                    } else {
                        stmt.setNull(bucketStmtPosition++, java.sql.Types.DATE);
                    }
                    if (bucket.getRechargeDate() != null && !bucket.getRechargeDate().isEmpty()) {
                        stmt.setDate(bucketStmtPosition++, java.sql.Date.valueOf(bucket.getRechargeDate()));
                    } else {
                        stmt.setNull(bucketStmtPosition++, java.sql.Types.DATE);
                    }
                    if (bucket.getDataExpirationDate() != null && !bucket.getDataExpirationDate().isEmpty()) {
                        stmt.setDate(bucketStmtPosition++, java.sql.Date.valueOf(bucket.getDataExpirationDate()));
                    } else {
                        stmt.setNull(bucketStmtPosition++, java.sql.Types.DATE);
                    }
                }
            }

            // Update transactions.
            stmt.executeUpdate();

            if (tfOneNewTransaction.getTemplate().contains("TMO") && (null != tfOneNewTransaction.getRatePlan() && tfOneNewTransaction.getRatePlan().contains("|"))) {
                String transactionItemId = getTransactionIdFromActionItemId(con, actionItemId);
                insertBucketTiers(con, buckets, transactionItemId);
            }

        } catch (SQLException | NamingException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, ex);
        } finally {
            try {
                try {
                    if (stmt != null) {
                        stmt.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }
                try {
                    if (con != null) {
                        con.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }

                TracfoneAudit audit;
                if (StringUtils.isNullOrEmpty(bulkInsertIdentifier)) {
                    audit = new TracfoneAudit(userId, "Insert", "Response Action Item ID: " + actionItemId + "\n" + gson.toJson(tfOneNewTransaction), CARRIER_ID);
                } else {
                    audit = new TracfoneAudit(userId, BULK_IG_INSERT, "Response Action Item ID: " + actionItemId + "\n" + gson.toJson(tfOneNewTransaction), CARRIER_ID1 + bulkInsertIdentifier);
                }
                tracfoneAuditEvent.fire(audit);

                //Insert int TransactionArchive
                TFTransactionArchive tracfoneTransactionArchive = new TFTransactionArchive(String.valueOf(userId), actionItemId, "Q", tfOneNewTransaction.getDbenv());

                if (fireArchiveEvent) {
                    tracfoneTransactionArchiveEvent.fire(tracfoneTransactionArchive);
                }

            } catch (Exception ex) {
                LOGGER.error(ex); // print to nohup.
            }
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, actionItemId);
    }

    private void insertUserHistory(String dbEnv, int userId, List<String> actionItemIds, String unique) {
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement userHistoryStmt = con.prepareStatement(TRACFONE_INSERT_USER_HISTORY);
             PreparedStatement userHistoryDetailsStmt = con.prepareStatement(TRACFONE_INSERT_USER_HISTORY_DETAIL);) {
            String userHistoryId = getNextSequence(con, TRACFONE_USER_HISTORY_SEQ_STMT, "USER_HISTORY_ID_SEQ");

            userHistoryStmt.setString(1, userHistoryId);
            userHistoryStmt.setInt(2, userId);
            userHistoryStmt.executeQuery();

            userHistoryDetailsStmt.setString(1, userHistoryId);
            userHistoryDetailsStmt.setString(2, unique);
            userHistoryDetailsStmt.setString(3, String.join(",", actionItemIds));
            userHistoryDetailsStmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
    }

    private String getNextSequence(Connection con, String queryString, String seqId) throws SQLException {
        String sequenceId = null;
        try (PreparedStatement stmt = con.prepareStatement(queryString);
             ResultSet resultSet = stmt.executeQuery();) {
            while (resultSet.next()) {
                sequenceId = resultSet.getString(seqId);
            }
        }
        return sequenceId;
    }

    /**
     * @param bucketDetail
     * @param userId
     * @return
     * @throws TracfoneOneException
     */
    @Override
    public List<TFOneActionItemBucket> bucketsDetailTransaction(TracfoneOneBucketDetail bucketDetail, int userId) throws TracfoneOneException {

        if (bucketDetail.getTransactionId() == null)
            throw new TracfoneOneException(TRACFONE_DATASOURCE_INALIDTID_ERROR_CODE, TRACFONE_DATASOURCE_INALIDTID_ERROR_MESSAGE);

        if (bucketDetail.getEnv() == null)
            throw new TracfoneOneException(TRACFONE_DATASOURCE_ENV_ERROR_CODE, TRACFONE_DATASOURCE_ENV_ERROR_MESSAGE);

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet resultSet = null;
        Gson gson = new Gson();
        List<TFOneActionItemBucket> tfOneActionItemBuckets = new ArrayList<>();
        List<TFOneActionItemBucket> tfOneActionItemOutboundBuckets = new ArrayList<>();
        try {
            con = dbControllerEJB.getDataSource(bucketDetail.getEnv()).getConnection();
            stmt = con.prepareStatement(TRACFONE_BUCKET_DETAIL_SELECT_QUERY);
            stmt.setString(1, bucketDetail.getTransactionId());
            resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                TFOneActionItemBucket bucket = new TFOneActionItemBucket();
                bucket.setBucketId(resultSet.getString("BUCKET_ID"));
                bucket.setBenefitType(resultSet.getString("BENEFIT_TYPE"));
                bucket.setBucketAction(resultSet.getString("BUCKET_ACTION"));
                bucket.setBucketBalance(resultSet.getString("BUCKET_BALANCE"));
                bucket.setBucketType(resultSet.getString("BUCKET_TYPE"));
                bucket.setBucketUsage(resultSet.getString("BUCKET_USAGE"));
                bucket.setBucketValue(resultSet.getString("BUCKET_VALUE"));
                bucket.setDirection(resultSet.getString("DIRECTION"));
                bucket.setExpirationDate(resultSet.getString("EXPIRATION_DATE"));
                bucket.setDataExpirationDate(resultSet.getString("DATA_EXPIRATION_DATE"));
                bucket.setUnitOfMeasurement(resultSet.getString("UNIT_OF_MEASURE"));
                bucket.setBucketGroup(resultSet.getString("BUCKET_GROUP"));
                bucket.setBucketRequirement(resultSet.getString("BUCKET_REQUIREMENT"));
                bucket.setAutoRenewFlag(resultSet.getString("AUTO_RENEW_FLAG"));
                bucket.setAutoRenewFrequency(resultSet.getString("AUTO_RENEW_FREQUENCY"));
                bucket.setAutoRenewValue(resultSet.getString("AUTO_RENEW_VALUE"));
                bucket.setAutoRenewDay(resultSet.getString("AUTO_RENEW_DAY"));
                bucket.setRechargeDate(resultSet.getString("RECHARGE_DATE"));
                bucket.setBucketDescription(resultSet.getString("BUCKET_DESC"));

                List<TFOneActionItemBucketTier> tiers = getBucketTiers(con, bucketDetail.getTransactionId(), resultSet.getString("BUCKET_ID"));
                bucket.setBucketTiers(tiers);

                if (bucket.getDirection().equals("OUTBOUND"))
                    tfOneActionItemOutboundBuckets.add(bucket);
                else
                    tfOneActionItemBuckets.add(bucket);
            }

            // Append Outbound buckets at the end.
            for (TFOneActionItemBucket bucket : tfOneActionItemOutboundBuckets) {
                tfOneActionItemBuckets.add(bucket);
            }

        } catch (SQLException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, ex);
        } catch (NamingException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE_NAME, TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, ex);
        } finally {
            try {
                try {
                    if (resultSet != null) {
                        resultSet.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }
                try {
                    if (stmt != null) {
                        stmt.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }
                try {
                    if (con != null) {
                        con.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }
                TracfoneAudit audit = new TracfoneAudit(userId, "BucketDetail", gson.toJson(bucketDetail.getTransactionId()), CARRIER_ID);
                tracfoneAuditEvent.fire(audit);
            } catch (Exception ex) {
                LOGGER.error(ex);
            }
        }
        return tfOneActionItemBuckets;
    }

    /**
     * @param tracfoneOneActionItemId
     * @param userId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    @Override
    public TracfoneOneViewActionItems viewFailedTransaction(TracfoneOneActionItemId tracfoneOneActionItemId, Integer userId) throws TracfoneOneAuthorizationException, TracfoneOneException {
        int expectedOptionalFields = 2;

        List<TFOneAdminActionItem> transactionsProcessed = new ArrayList<>();
        TracfoneOneViewActionItems tracfoneOneViewActionItems = new TracfoneOneViewActionItems();
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet resultSet = null;
        Gson gson = new Gson();

        boolean orderTypePresent = checkIfNullOrEmpty(tracfoneOneActionItemId.getOrderType());
        boolean creationDatePresent = checkIfNotNullOrEmpty(tracfoneOneActionItemId.getCreationFromDate());
        boolean additionalFields = (tracfoneOneActionItemId.getAdditionalColumns() != null && tracfoneOneActionItemId.getAdditionalColumns().size() >= expectedOptionalFields);

        // Validate all fields required.
        if (!orderTypePresent || !creationDatePresent || !additionalFields)
            throw new TracfoneOneException(TRACFONE_VIEWTRANSACTION_PRIMARYMISSING_CODE, TRACFONE_VIEWTRANSACTION_PRIMARYMISSING_MESSAGE);

        TracfoneOneSearchAdditionalModel templateColumn = tracfoneOneActionItemId.getAdditionalColumns().get(0);
        TracfoneOneSearchAdditionalModel transTypeColumn = tracfoneOneActionItemId.getAdditionalColumns().get(1);

        // Values for template and transaction type needed.
        if (!templateColumn.getSearchColumnName().equalsIgnoreCase("template"))
            throw new TracfoneOneException(TracfoneOneConstantAction.TRACFONE_FAILEDTRANSCTION_FIELDMISSING, TracfoneOneConstantAction.TRACFONE_FAILEDTRANSCTION_FIELDMISSING_MESSAGE);
        if (!transTypeColumn.getSearchColumnName().equalsIgnoreCase("transtype"))
            throw new TracfoneOneException(TracfoneOneConstantAction.TRACFONE_FAILEDTRANSCTION_FIELDMISSING, TracfoneOneConstantAction.TRACFONE_FAILEDTRANSCTION_FIELDMISSING_MESSAGE);

        try {
            con = dbControllerEJB.getDataSource(tracfoneOneActionItemId.getDbenv()).getConnection();
            stmt = con.prepareStatement(TracfoneOneConstantAction.ACTION_SQL_SEARCHFAILEDTRANSACTION);

            stmt.setString(1, tracfoneOneActionItemId.getOrderType().get(0));
            stmt.setString(2, tracfoneOneActionItemId.getCreationFromDate());
            stmt.setString(3, templateColumn.getSearchValues().get(0));
            stmt.setString(4, transTypeColumn.getSearchValues().get(0));
            resultSet = stmt.executeQuery();

            // Retrieve all transactions found for search criteria.
            while (resultSet.next()) {
                TFOneAdminActionItem tfOneResponseActionItem = new TFOneAdminActionItem();
                tfOneResponseActionItem.setEnv(tracfoneOneActionItemId.getDbenv());
                tfOneResponseActionItem.setTransactionId(resultSet.getString(TRANSACTION_ID));
                transactionsProcessed.add(tfOneResponseActionItem);
            }
            //Set the response and pagination
            tracfoneOneViewActionItems.setActionItems(transactionsProcessed);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE, TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, ex);
        } finally {
            try {
                try {
                    if (resultSet != null) {
                        resultSet.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }
                try {
                    if (stmt != null) {
                        stmt.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }
                try {
                    if (con != null) {
                        con.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }

                TracfoneAudit audit = new TracfoneAudit(userId, "ViewFailedTransaction", gson.toJson(tracfoneOneActionItemId), CARRIER_ID);
                tracfoneAuditEvent.fire(audit);
            } catch (Exception ex) {
                LOGGER.error(ex);
            }
        }
        return tracfoneOneViewActionItems;
    }

    /**
     * @param con
     * @return
     * @throws TracfoneOneException
     */
    private String getNextAIDSeq(Connection con) throws TracfoneOneException {

        String sequenceId = null;
        String seqStmt = TracfoneOneConstantAction.TRACFONE_AID_SEQ_STMT;
        PreparedStatement stmt = null;
        ResultSet resultSet = null;
        try {
            stmt = con.prepareStatement(seqStmt);
            resultSet = stmt.executeQuery();
            while (resultSet.next()) {
                sequenceId = resultSet.getString("AID_SEQ");
            }
        } catch (SQLException ex) {
            throw new TracfoneOneException(TRACFONE_DATASOURCE_AID_SEQ_ERROR_CODE, TRACFONE_DATASOURCE_AID_SEQ_ERROR_MESSAGE, ex);
        } finally {
            try {
                try {
                    if (resultSet != null) {
                        resultSet.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }
                try {
                    if (stmt != null) {
                        stmt.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }
            } catch (Exception ex) {
                LOGGER.error(ex);
            }
        }
        return sequenceId;
    }

    /**
     * Retrieve Transaction Id from Action Item Id
     *
     * @throws TracfoneOneException
     * @params Connection con, List<TFOneActionItemBucket> buckets, String actionItemId
     * @void
     */
    private String getTransactionIdFromActionItemId(Connection con, String actionItemId) throws TracfoneOneException {
        String transactionId = null;
        try (PreparedStatement stmt = con.prepareStatement(TracfoneOneConstantAction.GET_TRANSACTION_ID_VIA_ACTION_ITEM)) {
            stmt.setString(1, actionItemId);
            try (ResultSet result = stmt.executeQuery();) {
                if (result.next()) {
                    transactionId = result.getString(1);
                }
            }
        } catch (SQLException ex) {
            throw new TracfoneOneException(TRACFONE_DATASOURCE_AID_SEQ_ERROR_CODE, TRACFONE_DATASOURCE_AID_SEQ_ERROR_MESSAGE, ex);
        }
        return transactionId;
    }

    /**
     * Retrieves Bucket Tiers from the Database
     *
     * @throws TracfoneOneException
     * @params Connection con, List<TFOneActionItemBucket> buckets , String transactionId
     * @void
     */
    private List<TFOneActionItemBucketTier> getBucketTiers(Connection con, String transactionId, String bucketId) throws TracfoneOneException {
        List<TFOneActionItemBucketTier> tierList = new ArrayList<>();
        try {
            try (PreparedStatement tierStatement = con.prepareStatement(TracfoneOneConstantAction.ACTION_GET_BUCKET_TIERS);) {
                tierStatement.setString(1, transactionId);
                tierStatement.setString(2, bucketId);
                try (ResultSet tierResultSet = tierStatement.executeQuery();) {
                    while (tierResultSet.next()) {
                        TFOneActionItemBucketTier tier = new TFOneActionItemBucketTier();
                        tier.setUsageTierId(tierResultSet.getString("USAGE_TIER_ID"));
                        tier.setTierValue(tierResultSet.getString("TIER_VALUE"));
                        tier.setTierBehavior(tierResultSet.getString("TIER_BEHAVIOR"));
                        tierList.add(tier);
                    }
                }
            }
        } catch (SQLException ex) {
            throw new TracfoneOneException(TRACFONE_DATASOURCE_AID_SEQ_ERROR_CODE, TRACFONE_DATASOURCE_AID_SEQ_ERROR_MESSAGE, ex);
        }
        return tierList;
    }

    /**
     * Inserts Bucket Tiers into the Database
     *
     * @throws TracfoneOneException
     * @params Connection con, List<TFOneActionItemBucket> buckets, String transactionId
     * @void
     */
    private void insertBucketTiers(Connection con, List<TFOneActionItemBucket> buckets, String transactionId) throws TracfoneOneException {
        LOGGER.debug("Transaction id being inserted in tiers is " + transactionId);
        for (TFOneActionItemBucket bucket : buckets) {
            for (TFOneActionItemBucketTier tier : bucket.getBucketTiers()) {
                try (PreparedStatement stmt = con.prepareStatement(TracfoneOneConstantAction.ACTION_INSERT_BUCKET_TIERS)) {
                    stmt.setString(1, transactionId);
                    LOGGER.debug("bucket id being inserted in tiers is " + bucket.getBucketId());
                    stmt.setString(2, bucket.getBucketId());
                    LOGGER.debug("Tier id being inserted in tiers is " + tier.getUsageTierId());
                    stmt.setString(3, tier.getUsageTierId());
                    stmt.setString(4, tier.getTierValue());
                    stmt.setString(5, tier.getTierBehavior());
                    stmt.executeUpdate();
                } catch (SQLException ex) {
                    throw new TracfoneOneException(TRACFONE_DATASOURCE_AID_SEQ_ERROR_CODE, TRACFONE_DATASOURCE_AID_SEQ_ERROR_MESSAGE, ex);
                }
            }
        }
    }

    /**
     * Builds the update statement section of query for the prepared statement.
     *
     * @param sqlReworkBuilder
     * @param transaction
     * @return
     */
    private StringBuilder buildUpdateStatement(StringBuilder sqlReworkBuilder, TFOneAdminActionItem transaction) {

        StringBuilder sqlUpdateBuilder = new StringBuilder();
        boolean updateStmtAppended = false;

        StringBuilder sqlUpdateAddInfoBuilder = new StringBuilder();
        boolean updateAddInfoStmtAppended = false;

        if (null != (transaction.getActionItemId())) {
            if(transaction.getActionItemId().contains("CLM_")){
                sqlUpdateBuilder.append("ACTION_ITEM_ID = "+ removeCLM(transaction.getActionItemId()));
            } else {
                sqlUpdateBuilder.append("ACTION_ITEM_ID = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getCarrierId())) {
            if(transaction.getCarrierId().contains("CLM_")){
                sqlUpdateBuilder.append("CARRIER_ID = "+ removeCLM(transaction.getCarrierId()));
            } else {
                sqlUpdateBuilder.append("CARRIER_ID = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getOrderType())) {
            if(transaction.getOrderType().contains("CLM_")){
                sqlUpdateBuilder.append("ORDER_TYPE = "+ removeCLM(transaction.getOrderType()));
            } else {
                sqlUpdateBuilder.append("ORDER_TYPE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getMin())) {
            if(transaction.getMin().contains("CLM_")){
                sqlUpdateBuilder.append("MIN = "+ removeCLM(transaction.getMin()));
            } else {
                sqlUpdateBuilder.append("MIN = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getEsn())) {
            if(transaction.getEsn().contains("CLM_")){
                sqlUpdateBuilder.append("ESN = "+ removeCLM(transaction.getEsn()));
            } else {
                sqlUpdateBuilder.append("ESN = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getEsnHex())) {
            if(transaction.getEsnHex().contains("CLM_")){
                sqlUpdateBuilder.append("ESN_HEX = "+ removeCLM(transaction.getEsnHex()));
            } else {
                sqlUpdateBuilder.append("ESN_HEX = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getOldEsn())) {
            if(transaction.getOldEsn().contains("CLM_")){
                sqlUpdateBuilder.append("OLD_ESN = "+ removeCLM(transaction.getOldEsn()));
            } else {
                sqlUpdateBuilder.append("OLD_ESN = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getOldEsnHex())) {
            if(transaction.getOldEsnHex().contains("CLM_")){
                sqlUpdateBuilder.append("OLD_ESN_HEX = "+ removeCLM(transaction.getOldEsnHex()));
            } else {
                sqlUpdateBuilder.append("OLD_ESN_HEX = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getPin())) {
            if(transaction.getPin().contains("CLM_")){
                sqlUpdateBuilder.append("PIN = "+ removeCLM(transaction.getPin()));
            } else {
                sqlUpdateBuilder.append("PIN = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getPhoneManf())) {
            if(transaction.getPhoneManf().contains("CLM_")){
                sqlUpdateBuilder.append("PHONE_MANF = "+ removeCLM(transaction.getPhoneManf()));
            } else {
                sqlUpdateBuilder.append("PHONE_MANF = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getEndUser())) {
            if(transaction.getEndUser().contains("CLM_")){
                sqlUpdateBuilder.append("END_USER = "+ removeCLM(transaction.getEndUser()));
            } else {
                sqlUpdateBuilder.append("END_USER = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getAccountNum())) {
            if(transaction.getAccountNum().contains("CLM_")){
                sqlUpdateBuilder.append("ACCOUNT_NUM = "+ removeCLM(transaction.getAccountNum()));
            } else {
                sqlUpdateBuilder.append("ACCOUNT_NUM = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getMarketCode())) {
            if(transaction.getMarketCode().contains("CLM_")){
                sqlUpdateBuilder.append("MARKET_CODE = "+ removeCLM(transaction.getMarketCode()));
            } else {
                sqlUpdateBuilder.append("MARKET_CODE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getRatePlan())) {
            if(transaction.getRatePlan().contains("CLM_")){
                sqlUpdateBuilder.append("RATE_PLAN = "+ removeCLM(transaction.getRatePlan()));
            } else {
                sqlUpdateBuilder.append("RATE_PLAN = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getLdProvider())) {
            if(transaction.getLdProvider().contains("CLM_")){
                sqlUpdateBuilder.append("LD_PROVIDER = "+ removeCLM(transaction.getLdProvider()));
            } else {
                sqlUpdateBuilder.append("LD_PROVIDER = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getDealerCode())) {
            if(transaction.getDealerCode().contains("CLM_")){
                sqlUpdateBuilder.append("DEALER_CODE = "+ removeCLM(transaction.getDealerCode()));
            } else {
                sqlUpdateBuilder.append("DEALER_CODE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getTransmissionMethod())) {
            if(transaction.getTransmissionMethod().contains("CLM_")){
                sqlUpdateBuilder.append("TRANSMISSION_METHOD = "+ removeCLM(transaction.getTransmissionMethod()));
            } else {
                sqlUpdateBuilder.append("TRANSMISSION_METHOD = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getFaxNum())) {
            if(transaction.getFaxNum().contains("CLM_")){
                sqlUpdateBuilder.append("FAX_NUM = "+ removeCLM(transaction.getFaxNum()));
            } else {
                sqlUpdateBuilder.append("FAX_NUM = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getOnlineNum())) {
            if(transaction.getOnlineNum().contains("CLM_")){
                sqlUpdateBuilder.append("ONLINE_NUM = "+ removeCLM(transaction.getOnlineNum()));
            } else {
                sqlUpdateBuilder.append("ONLINE_NUM = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getEmail())) {
            if(transaction.getEmail().contains("CLM_")){
                sqlUpdateBuilder.append("EMAIL = "+ removeCLM(transaction.getEmail()));
            } else {
                sqlUpdateBuilder.append("EMAIL = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getTemplate())) {
            if(transaction.getTemplate().contains("CLM_")){
                sqlUpdateBuilder.append("TEMPLATE = "+ removeCLM(transaction.getTemplate()));
            } else {
                sqlUpdateBuilder.append("TEMPLATE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getExeName())) {
            if(transaction.getExeName().contains("CLM_")){
                sqlUpdateBuilder.append("EXE_NAME = "+ removeCLM(transaction.getExeName()));
            } else {
                sqlUpdateBuilder.append("EXE_NAME = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getComPort())) {
            if(transaction.getComPort().contains("CLM_")){
                sqlUpdateBuilder.append("COM_PORT = "+ removeCLM(transaction.getComPort()));
            } else {
                sqlUpdateBuilder.append("COM_PORT = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getStatus())) {
            if(transaction.getStatus().contains("CLM_")){
                sqlUpdateBuilder.append("STATUS = "+ removeCLM(transaction.getStatus()));
            } else {
                sqlUpdateBuilder.append("STATUS = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getStatusMessage())) {
            if(transaction.getStatusMessage().contains("CLM_")){
                sqlUpdateBuilder.append("STATUS_MESSAGE = "+ removeCLM(transaction.getStatusMessage()));
            } else {
                sqlUpdateBuilder.append("STATUS_MESSAGE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getFaxBatchSize())) {
            if(transaction.getFaxBatchSize().contains("CLM_")){
                sqlUpdateBuilder.append("FAX_BATCH_SIZE = "+ removeCLM(transaction.getFaxBatchSize()));
            } else {
                sqlUpdateBuilder.append("FAX_BATCH_SIZE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getFaxBatchQtime())) {
            if(transaction.getFaxBatchQtime().contains("CLM_")){
                sqlUpdateBuilder.append("FAX_BATCH_Q_TIME = "+ removeCLM(transaction.getFaxBatchQtime()));
            } else {
                sqlUpdateBuilder.append("FAX_BATCH_Q_TIME = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getExpidite())) {
            if(transaction.getExpidite().contains("CLM_")){
                sqlUpdateBuilder.append("EXPIDITE = "+ removeCLM(transaction.getExpidite()));
            } else {
                sqlUpdateBuilder.append("EXPIDITE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getqTransaction())) {
            if(transaction.getqTransaction().contains("CLM_")){
                sqlUpdateBuilder.append("Q_TRANSACTION = "+ removeCLM(transaction.getqTransaction()));
            } else {
                sqlUpdateBuilder.append("Q_TRANSACTION = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getOnlineNum2())) {
            if(transaction.getOnlineNum2().contains("CLM_")){
                sqlUpdateBuilder.append("ONLINE_NUM2 = "+ removeCLM(transaction.getOnlineNum2()));
            } else {
                sqlUpdateBuilder.append("ONLINE_NUM2 = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getFaxNum2())) {
            if(transaction.getFaxNum2().contains("CLM_")){
                sqlUpdateBuilder.append("FAX_NUM2 = "+ removeCLM(transaction.getFaxNum2()));
            } else {
                sqlUpdateBuilder.append("FAX_NUM2 = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getCreationDate())) {
            if(transaction.getCreationDate().contains("CLM_")){
                sqlUpdateBuilder.append("CREATION_DATE = "+ removeCLM(transaction.getCreationDate()));
            } else {
                sqlUpdateBuilder.append("CREATION_DATE =  to_date(?,'YYYY-MM-DD hh24:MI:SS'), ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getTuxItiServer())) {
            if(transaction.getTuxItiServer().contains("CLM_")){
                sqlUpdateBuilder.append("TUX_ITI_SERVER = "+ removeCLM(transaction.getTuxItiServer()));
            } else {
                sqlUpdateBuilder.append("TUX_ITI_SERVER = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getTechnologyFlag())) {
            if(transaction.getTechnologyFlag().contains("CLM_")){
                sqlUpdateBuilder.append("TECHNOLOGY_FLAG = "+ removeCLM(transaction.getTechnologyFlag()));
            } else {
                sqlUpdateBuilder.append("TECHNOLOGY_FLAG = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getVoiceMail())) {
            if(transaction.getVoiceMail().contains("CLM_")){
                sqlUpdateBuilder.append("VOICE_MAIL = "+ removeCLM(transaction.getVoiceMail()));
            } else {
                sqlUpdateBuilder.append("VOICE_MAIL = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getVoiceMailPackage())) {
            if(transaction.getVoiceMailPackage().contains("CLM_")){
                sqlUpdateBuilder.append("VOICE_MAIL_PACKAGE = "+ removeCLM(transaction.getVoiceMailPackage()));
            } else {
                sqlUpdateBuilder.append("VOICE_MAIL_PACKAGE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getCallerId())) {
            if(transaction.getCallerId().contains("CLM_")){
                sqlUpdateBuilder.append("CALLER_ID = "+ removeCLM(transaction.getCallerId()));
            } else {
                sqlUpdateBuilder.append("CALLER_ID = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getCallerIdPackage())) {
            if(transaction.getCallerIdPackage().contains("CLM_")){
                sqlUpdateBuilder.append("CALLER_ID_PACKAGE = "+ removeCLM(transaction.getCallerIdPackage()));
            } else {
                sqlUpdateBuilder.append("CALLER_ID_PACKAGE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getCallWaiting())) {
            if(transaction.getCallWaiting().contains("CLM_")){
                sqlUpdateBuilder.append("CALL_WAITING = "+ removeCLM(transaction.getCallWaiting()));
            } else {
                sqlUpdateBuilder.append("CALL_WAITING = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getCallWaitingPackage())) {
            if(transaction.getCallWaitingPackage().contains("CLM_")){
                sqlUpdateBuilder.append("CALL_WAITING_PACKAGE = "+ removeCLM(transaction.getCallWaitingPackage()));
            } else {
                sqlUpdateBuilder.append("CALL_WAITING_PACKAGE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getRtpServer())) {
            if(transaction.getRtpServer().contains("CLM_")){
                sqlUpdateBuilder.append("RTP_SERVER = "+ removeCLM(transaction.getRtpServer()));
            } else {
                sqlUpdateBuilder.append("RTP_SERVER = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getDigitalFeatureCode())) {
            if(transaction.getDigitalFeatureCode().contains("CLM_")){
                sqlUpdateBuilder.append("DIGITAL_FEATURE_CODE = "+ removeCLM(transaction.getDigitalFeatureCode()));
            } else {
                sqlUpdateBuilder.append("DIGITAL_FEATURE_CODE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getStateField())) {
            if(transaction.getStateField().contains("CLM_")){
                sqlUpdateBuilder.append("STATE_FIELD = "+ removeCLM(transaction.getStateField()));
            } else {
                sqlUpdateBuilder.append("STATE_FIELD = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getZipCode())) {
            if(transaction.getZipCode().contains("CLM_")){
                sqlUpdateBuilder.append("ZIP_CODE = "+ removeCLM(transaction.getZipCode()));
            } else {
                sqlUpdateBuilder.append("ZIP_CODE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getMsid())) {
            if(transaction.getMsid().contains("CLM_")){
                sqlUpdateBuilder.append("MSID = "+ removeCLM(transaction.getMsid()));
            } else {
                sqlUpdateBuilder.append("MSID = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getNewMsidFlag())) {
            if(transaction.getNewMsidFlag().contains("CLM_")){
                sqlUpdateBuilder.append("NEW_MSID_FLAG = "+ removeCLM(transaction.getNewMsidFlag()));
            } else {
                sqlUpdateBuilder.append("NEW_MSID_FLAG = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getSms())) {
            if(transaction.getSms().contains("CLM_")){
                sqlUpdateBuilder.append("SMS = "+ removeCLM(transaction.getSms()));
            } else {
                sqlUpdateBuilder.append("SMS = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getSmsPackage())) {
            if(transaction.getSmsPackage().contains("CLM_")){
                sqlUpdateBuilder.append("SMS_PACKAGE = "+ removeCLM(transaction.getSmsPackage()));
            } else {
                sqlUpdateBuilder.append("SMS_PACKAGE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getIccid())) {
            if(transaction.getIccid().contains("CLM_")){
                sqlUpdateBuilder.append("ICCID = "+ removeCLM(transaction.getIccid()));
            } else {
                sqlUpdateBuilder.append("ICCID = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getOldMin())) {
            if(transaction.getOldMin().contains("CLM_")){
                sqlUpdateBuilder.append("OLD_MIN = "+ removeCLM(transaction.getOldMin()));
            } else {
                sqlUpdateBuilder.append("OLD_MIN = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getDigitalFeature())) {
            if(transaction.getDigitalFeature().contains("CLM_")){
                sqlUpdateBuilder.append("DIGITAL_FEATURE = "+ removeCLM(transaction.getDigitalFeature()));
            } else {
                sqlUpdateBuilder.append("DIGITAL_FEATURE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getOtaType())) {
            if(transaction.getOtaType().contains("CLM_")){
                sqlUpdateBuilder.append("OTA_TYPE = "+ removeCLM(transaction.getOtaType()));
            } else {
                sqlUpdateBuilder.append("OTA_TYPE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getRateCenterNo())) {
            if(transaction.getRateCenterNo().contains("CLM_")){
                sqlUpdateBuilder.append("RATE_CENTER_NO = "+ removeCLM(transaction.getRateCenterNo()));
            } else {
                sqlUpdateBuilder.append("RATE_CENTER_NO = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getApplicationSystem())) {
            if(transaction.getApplicationSystem().contains("CLM_")){
                sqlUpdateBuilder.append("APPLICATION_SYSTEM = "+ removeCLM(transaction.getApplicationSystem()));
            } else {
                sqlUpdateBuilder.append("APPLICATION_SYSTEM = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getSubscriberUpdate())) {
            if(transaction.getSubscriberUpdate().contains("CLM_")){
                sqlUpdateBuilder.append("SUBSCRIBER_UPDATE = "+ removeCLM(transaction.getSubscriberUpdate()));
            } else {
                sqlUpdateBuilder.append("SUBSCRIBER_UPDATE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getDownloadDate())) {
            if(transaction.getDownloadDate().contains("CLM_")){
                sqlUpdateBuilder.append("DOWNLOAD_DATE = "+ removeCLM(transaction.getDownloadDate()));
            } else {
                sqlUpdateBuilder.append("DOWNLOAD_DATE = to_date(?,'YYYY-MM-DD hh24:MI:SS'), ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getPrlNumber())) {
            if(transaction.getPrlNumber().contains("CLM_")){
                sqlUpdateBuilder.append("PRL_NUMBER = "+ removeCLM(transaction.getPrlNumber()));
            } else {
                sqlUpdateBuilder.append("PRL_NUMBER = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getAmount())) {
            if(transaction.getAmount().contains("CLM_")){
                sqlUpdateBuilder.append("AMOUNT = "+ removeCLM(transaction.getAmount()));
            } else {
                sqlUpdateBuilder.append("AMOUNT = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getBalance())) {
            if(transaction.getBalance().contains("CLM_")){
                sqlUpdateBuilder.append("BALANCE = "+ removeCLM(transaction.getBalance()));
            } else {
                sqlUpdateBuilder.append("BALANCE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getLanguage())) {
            if(transaction.getLanguage().contains("CLM_")){
                sqlUpdateBuilder.append("LANGUAGE = "+ removeCLM(transaction.getLanguage()));
            } else {
                sqlUpdateBuilder.append("LANGUAGE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getExpDate())) {
            if(transaction.getExpDate().contains("CLM_")){
                sqlUpdateBuilder.append("EXP_DATE = "+ removeCLM(transaction.getExpDate()));
            } else {
                sqlUpdateBuilder.append("EXP_DATE = to_date(?,'YYYY-MM-DD hh24:MI:SS'), ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getxMpn())) {
            if(transaction.getxMpn().contains("CLM_")){
                sqlUpdateBuilder.append("X_MPN = "+ removeCLM(transaction.getxMpn()));
            } else {
                sqlUpdateBuilder.append("X_MPN = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getxMpnCode())) {
            if(transaction.getxMpnCode().contains("CLM_")){
                sqlUpdateBuilder.append("X_MPN_CODE = "+ removeCLM(transaction.getxMpnCode()));
            } else {
                sqlUpdateBuilder.append("X_MPN_CODE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getxPoolName())) {
            if(transaction.getxPoolName().contains("CLM_")){
                sqlUpdateBuilder.append("X_POOL_NAME = "+ removeCLM(transaction.getxPoolName()));
            } else {
                sqlUpdateBuilder.append("X_POOL_NAME = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getNewImsiFlag())) {
            if(transaction.getNewImsiFlag().contains("CLM_")){
                sqlUpdateBuilder.append("NEW_IMSI_FLAG = "+ removeCLM(transaction.getNewImsiFlag()));
            } else {
                sqlUpdateBuilder.append("NEW_IMSI_FLAG = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getxMake())) {
            if(transaction.getxMake().contains("CLM_")){
                sqlUpdateBuilder.append("X_MAKE = "+ removeCLM(transaction.getxMake()));
            } else {
                sqlUpdateBuilder.append("X_MAKE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getxModel())) {
            if(transaction.getxModel().contains("CLM_")){
                sqlUpdateBuilder.append("X_MODEL = "+ removeCLM(transaction.getxModel()));
            } else {
                sqlUpdateBuilder.append("X_MODEL = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getxMode())) {
            if(transaction.getxMode().contains("CLM_")){
                sqlUpdateBuilder.append("X_MODE = "+ removeCLM(transaction.getxMode()));
            } else {
                sqlUpdateBuilder.append("X_MODE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getDataSaver())) {
            if(transaction.getDataSaver().contains("CLM_")){
                sqlUpdateBuilder.append("DATA_SAVER = "+ removeCLM(transaction.getDataSaver()));
            } else {
                sqlUpdateBuilder.append("DATA_SAVER = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getDataSaverCode())) {
            if(transaction.getDataSaverCode().contains("CLM_")){
                sqlUpdateBuilder.append("DATA_SAVER_CODE = "+ removeCLM(transaction.getDataSaverCode()));
            } else {
                sqlUpdateBuilder.append("DATA_SAVER_CODE = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getxCampaignName())) {
            if(transaction.getxCampaignName().contains("CLM_")){
                sqlUpdateBuilder.append("X_CAMPAIGN_NAME = "+ removeCLM(transaction.getxCampaignName()));
            } else {
                sqlUpdateBuilder.append("X_CAMPAIGN_NAME = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getCarrierFeatureObjid())) {
            if(transaction.getCarrierFeatureObjid().contains("CLM_")){
                sqlUpdateBuilder.append("CARRIER_FEATURE_OBJID = "+ removeCLM(transaction.getCarrierFeatureObjid()));
            } else {
                sqlUpdateBuilder.append("CARRIER_FEATURE_OBJID = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getCfProfileId())) {
            if(transaction.getCfProfileId().contains("CLM_")){
                sqlUpdateBuilder.append("CF_PROFILE_ID = "+ removeCLM(transaction.getCfProfileId()));
            } else {
                sqlUpdateBuilder.append("CF_PROFILE_ID = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getRpExtObjid())) {
            if(transaction.getRpExtObjid().contains("CLM_")){
                sqlUpdateBuilder.append("RP_EXT_OBJID = "+ removeCLM(transaction.getRpExtObjid()));
            } else {
                sqlUpdateBuilder.append("RP_EXT_OBJID = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getCarrierAccountId())) {
            if(transaction.getCarrierAccountId().contains("CLM_")){
                sqlUpdateBuilder.append("CARRIER_ACCOUNT_ID = "+ removeCLM(transaction.getCarrierAccountId()));
            } else {
                sqlUpdateBuilder.append("CARRIER_ACCOUNT_ID = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getTmoNextGenFlag())) {
            if(transaction.getTmoNextGenFlag().contains("CLM_")){
                sqlUpdateBuilder.append("TMO_NEXT_GEN_FLAG = "+ removeCLM(transaction.getTmoNextGenFlag()));
            } else {
                sqlUpdateBuilder.append("TMO_NEXT_GEN_FLAG = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.getServicePlanId())) {
            if(transaction.getServicePlanId().contains("CLM_")){
                sqlUpdateBuilder.append("SERVICE_PLAN_ID = "+ removeCLM(transaction.getServicePlanId()));
            } else {
                sqlUpdateBuilder.append("SERVICE_PLAN_ID = ?, ");
            }
            updateStmtAppended = true;
        }
        if (null != (transaction.geteSimFlag())) {
            if(transaction.geteSimFlag().contains("CLM_")){
                sqlUpdateBuilder.append("E_SIM_FLAG = "+ removeCLM(transaction.geteSimFlag()));
            } else {
                sqlUpdateBuilder.append("E_SIM_FLAG = ?, ");
            }
            updateStmtAppended = true;
        }

        sqlReworkBuilder.append(TracfoneOneConstantAction.ACTION_SQL_REWORKTRANSACTION_NEWTANSACTIONCHECK);

        // If there was an update, build the SQL block to update IG transaction.
        if (updateStmtAppended) {

            // Remove the coma from the last update field appended.
            String sql = sqlUpdateBuilder.toString();
            if (updateStmtAppended && sql.lastIndexOf(',') > 0) {
                sqlUpdateBuilder = new StringBuilder(sql.substring(0, sql.lastIndexOf(',')));
            }

            sqlReworkBuilder.append(TracfoneOneConstantAction.ACTION_SQL_REWORKTRANSACTION_UPDATE);
            sqlReworkBuilder.append(sqlUpdateBuilder.toString());
            sqlReworkBuilder.append(TracfoneOneConstantAction.ACTION_SQL_REWORKTRANSACTION_END);
        }

        //Update ig_transaction_add_info table
        if (null != (transaction.getFirstName())) {
            sqlUpdateAddInfoBuilder.append("FIRST_NAME = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getMiddleInitial())) {
            sqlUpdateAddInfoBuilder.append("MIDDLE_INITIAL = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getLastName())) {
            sqlUpdateAddInfoBuilder.append("LAST_NAME = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getSuffix())) {
            sqlUpdateAddInfoBuilder.append("SUFFIX = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getPrefix())) {
            sqlUpdateAddInfoBuilder.append("PREFIX = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getSsnLast4())) {
            sqlUpdateAddInfoBuilder.append("SSN_LAST_4 = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getAddress1())) {
            sqlUpdateAddInfoBuilder.append("ADDRESS_1 = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getAddress2())) {
            sqlUpdateAddInfoBuilder.append("ADDRESS_2 = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getCity())) {
            sqlUpdateAddInfoBuilder.append("CITY = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getState())) {
            sqlUpdateAddInfoBuilder.append("STATE = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getZipCode1())) {
            sqlUpdateAddInfoBuilder.append("ZIP_CODE = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getCountry())) {
            sqlUpdateAddInfoBuilder.append("COUNTRY = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getOspAccount())) {
            sqlUpdateAddInfoBuilder.append("OSP_ACCOUNT = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getCurrAddrHouseNumber())) {
            sqlUpdateAddInfoBuilder.append("CURR_ADDR_HOUSE_NUMBER = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getCurrAddrDirection())) {
            sqlUpdateAddInfoBuilder.append("CURR_ADDR_DIRECTION = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getCurrAddrStreetName())) {
            sqlUpdateAddInfoBuilder.append("CURR_ADDR_STREET_NAME = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getCurrAddrStreetType())) {
            sqlUpdateAddInfoBuilder.append("CURR_ADDR_STREET_TYPE = ?, ");
            updateAddInfoStmtAppended = true;
        }
        if (null != (transaction.getCurrAddrUnit())) {
            sqlUpdateAddInfoBuilder.append("CURR_ADDR_UNIT = ?, ");
            updateAddInfoStmtAppended = true;
        }

        // If there was an update, build the SQL block to update IG transaction Additional Info.
        if (updateAddInfoStmtAppended) {

            // Remove the coma from the last update field appended.
            String sql = sqlUpdateAddInfoBuilder.toString();
            if (updateAddInfoStmtAppended && sql.lastIndexOf(',') > 0) {
                sqlUpdateAddInfoBuilder = new StringBuilder(sql.substring(0, sql.lastIndexOf(',')));
            }

            sqlReworkBuilder.append(TracfoneOneConstantAction.ACTION_SQL_REWORKTRANSACTION__ADDL_UPDATE);
            sqlReworkBuilder.append(sqlUpdateAddInfoBuilder.toString());
            sqlReworkBuilder.append(TracfoneOneConstantAction.ACTION_SQL_REWORKTRANSACTION_ADDL_END);

        }

        //CR62493 - WIZARD FIX
        sqlReworkBuilder.append(TracfoneOneConstantAction.ACTION_SQL_REWORKTRANSACTION_UPDATEBUCKETS_NEW);
        sqlReworkBuilder.append(TracfoneOneConstantAction.ACTION_SQL_REWORKTRANSACTION_BLOCKEND);
        LOGGER.info("Rework Query" +sqlReworkBuilder.toString());
        System.out.print("qqqqqqqq  "+ sqlReworkBuilder);
        return sqlReworkBuilder;
    }

    @Override
    public TFOneCarrierTransactionResponse getTransactionCarrierResponse(TracfoneOneActionItemId tracfoneOneActionItemId, int userId) throws TracfoneOneException {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet resultSet = null;
        TFOneCarrierTransactionResponse response = new TFOneCarrierTransactionResponse();
        try {
            con = dbControllerEJB.getDataSource(tracfoneOneActionItemId.getDbenv()).getConnection();
            if (StringUtils.isNullOrEmpty(tracfoneOneActionItemId.getTransactionId().get(0)))
                throw new TracfoneOneException("", "No valid transaction ID found.");

            // Prepare statement with new created SQL String.
            stmt = con.prepareStatement(TracfoneOneConstantAction.ACTION_SQL_CARRIERRESPONSE);
            stmt.setString(1, tracfoneOneActionItemId.getTransactionId().get(0).trim());

            resultSet = stmt.executeQuery();
            while (resultSet.next()) {
                Clob clob = resultSet.getClob("XML_RESPONSE");

                String xmlResponse = clob.getSubString(1, (int) clob.length());
                String insertDate = resultSet.getString("INSERT_TIMESTAMP");
                String updateDate = resultSet.getString("UPDATE_TIMESTAMP");

                response.setXmlResponse(xmlResponse);
                response.setCreationDate(insertDate);
                response.setUpdateDate(updateDate);
            }
        } catch (NamingException | SQLException ex) {
            LOGGER.error(ex);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
            } catch (Exception ex) {
                LOGGER.error(ex);
            }
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (Exception ex) {
                LOGGER.error(ex);
            }
            try {
                if (con != null) {
                    con.close();
                }
            } catch (Exception ex) {
                LOGGER.error(ex);
            }
        }
        return response;
    }

    private StringBuilder buildQueryParamString(int amountQueryParam, StringBuilder sBuilder, String queryParamName) {
        if (amountQueryParam <= 0) {
            return sBuilder;
        }

        // Construct the insert param with the first value.
        sBuilder.append(AND).append(queryParamName).append(" in ( ").append("?");
        amountQueryParam -= 1;

        for (int i = 0; i < amountQueryParam; i++) {
            sBuilder.append(",?");
        }
        sBuilder.append(" )");
        return sBuilder;
    }

    private StringBuilder buildQueryParamStringForNotINs(int amountQueryParam, StringBuilder sBuilder, String queryParamName, boolean includeNullCheck) {
        if (amountQueryParam <= 0) {
            return sBuilder;
        }

        // Construct the insert param with the first value.
        sBuilder.append(AND);
        if (includeNullCheck) {
            sBuilder.append("(");
        }
        sBuilder.append(queryParamName).append(" not in ( ").append("?");
        amountQueryParam -= 1;

        for (int i = 0; i < amountQueryParam; i++) {
            sBuilder.append(",?");
        }
        sBuilder.append(" )");
        return sBuilder;
    }

    private boolean checkIfNullOrEmpty(List<String> fieldValues) {
        return null != fieldValues && !fieldValues.isEmpty();
    }

    private boolean checkIfNotNullOrEmpty(String fieldValue) {
        return null != fieldValue && !fieldValue.trim().isEmpty();
    }

    /**
     * Build the bucket tab for the query.
     *
     * @param sbuilder
     * @param transactionReworkFields
     * @return
     */
    private StringBuilder buildBucketTableSQL(StringBuilder sbuilder, TFOneAdminActionItem transactionReworkFields) throws ParseException, TracfoneOneException {

        List<TFOneActionItemBucket> reworkBuckets = transactionReworkFields.getBuckets();

        if (reworkBuckets.isEmpty())
            return sbuilder;

        int bucketCnt = 1;

        for (TFOneActionItemBucket bucket : reworkBuckets) {

            if (!checkIfNotNullOrEmpty(bucket.getBucketId())) {
                throw new TracfoneOneException(TracfoneOneConstantAction.TRACFONE_BUCKET_INVALID_ID_ERROR,
                        TracfoneOneConstantAction.TRACFONE_BUCKET_INVALID_ID_ERROR_MESSAGE);
            }

            // If fields are null or empty, pass string value 'NULL' for PLSQL Block.
            String bucketId = "'" + bucket.getBucketId() + "'";
            String bucketValue = (!checkIfNotNullOrEmpty(bucket.getBucketValue())) ? "NULL" : "'" + bucket.getBucketValue() + "'";
            String bucketBalance = (!checkIfNotNullOrEmpty(bucket.getBucketBalance())) ? "NULL" : "'" + bucket.getBucketBalance() + "'";
            String bucketType = (!checkIfNotNullOrEmpty(bucket.getBucketType())) ? "NULL" : "'" + bucket.getBucketType() + "'";
            String benefitType = (!checkIfNotNullOrEmpty(bucket.getBenefitType())) ? "NULL" : "'" + bucket.getBenefitType() + "'";
            String expirationDate = (!checkIfNotNullOrEmpty(bucket.getExpirationDate())) ? "NULL" : "'" + convertDateFormat(bucket.getExpirationDate()) + "'";
            String rechargeDate = (!checkIfNotNullOrEmpty(bucket.getRechargeDate())) ? "NULL" : "'" + convertDateFormat(bucket.getRechargeDate()) + "'";
            String direction = (!checkIfNotNullOrEmpty(bucket.getDirection()) ? "'OUTBOUND'" : "'" + bucket.getDirection()) + "'";
            String bucketUsage = (!checkIfNotNullOrEmpty(bucket.getBucketUsage())) ? "NULL" : "'" + bucket.getBucketUsage() + "'";
            String unitOfMeasure = (!checkIfNotNullOrEmpty(bucket.getUnitOfMeasurement())) ? "NULL" : "'" + bucket.getUnitOfMeasurement() + "'";
            String bucketGroup = (!checkIfNotNullOrEmpty(bucket.getBucketGroup())) ? "NULL" : "'" + bucket.getBucketGroup() + "'";
            String bucketRequirement = (!checkIfNotNullOrEmpty(bucket.getBucketRequirement())) ? "NULL" : "'" + bucket.getBucketRequirement() + "'";
            String autoRenewFlag = (!checkIfNotNullOrEmpty(bucket.getAutoRenewFlag())) ? "NULL" : "'" + bucket.getAutoRenewFlag() + "'";
            String autoRenewFreq = (!checkIfNotNullOrEmpty(bucket.getAutoRenewFrequency())) ? "NULL" : "'" + bucket.getAutoRenewFrequency() + "'";
            String autoRenewValue = (!checkIfNotNullOrEmpty(bucket.getAutoRenewValue())) ? "NULL" : "'" + bucket.getAutoRenewValue() + "'";
            String autoRenewDay = (!checkIfNotNullOrEmpty(bucket.getAutoRenewDay())) ? "NULL" : "'" + bucket.getAutoRenewDay() + "'";
            String dataExpirationDate = (!checkIfNotNullOrEmpty(bucket.getDataExpirationDate())) ? "NULL" : "'" + convertDateFormat(bucket.getDataExpirationDate()) + "'";
            //Checking Original BucketID & Direction values

            String orgbucketId = (!checkIfNotNullOrEmpty(bucket.getOrgBucketId())) ? "NULL" : "'" + bucket.getOrgBucketId() + "'";
            String orgbucketDirection = (!checkIfNotNullOrEmpty(bucket.getOrgBucketDirection())) ? "NULL" : "'" + bucket.getOrgBucketDirection() + "'";

            // Transaction ID (null here, will be set in the merge block).
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").transaction_id := ").append("NULL;\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").bucket_id := ").append(bucketId).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").recharge_date := ").append(rechargeDate).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").bucket_balance := ").append(bucketBalance).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").bucket_value := ").append(bucketValue).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").expiration_date := ").append(expirationDate).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").direction := ").append(direction).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").benefit_type := ").append(benefitType).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").bucket_type := ").append(bucketType).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").bucket_usage := ").append(bucketUsage).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").unit_of_measure := ").append(unitOfMeasure).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").bucket_group := ").append(bucketGroup).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").bucket_requirement := ").append(bucketRequirement).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").auto_renew_flag := ").append(autoRenewFlag).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").auto_renew_frequency := ").append(autoRenewFreq).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").auto_renew_value := ").append(autoRenewValue).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").auto_renew_day := ").append(autoRenewDay).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").data_expiration_date := ").append(dataExpirationDate).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").original_bucket_id := ").append(orgbucketId).append(";\n");
            sbuilder.append(BUCKETS_TAB).append(bucketCnt).append(").original_bucket_direction := ").append(orgbucketDirection).append(";\n");
            bucketCnt++;
        }
        return sbuilder;
    }

    private String convertDateFormat(String date) throws ParseException {
        return convertDateFormat(date, TracfoneOneConstantAction.OLD_FORMAT, TracfoneOneConstantAction.NEW_FORMAT);
    }

    private String convertDateFormat(String date, String oldFormat, String newFormat) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(oldFormat);
        Date d = sdf.parse(date);
        sdf.applyPattern(newFormat);
        return sdf.format(d);
    }

    /**
     * Java awesome dateMethod
     *
     * @return todayDate
     */
    private String getDefaultTodayDate() {

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy:MM:dd");
        return sdFormat.format(cal.getTime());
    }

    private String getFeaturesSQL(List<TFOneFeatures> features, String sqlStringBuilder) {

        StringBuilder sql = new StringBuilder(sqlStringBuilder);
        StringBuilder featureSQLBuilder = new StringBuilder();
        int i = 0;
        if (features == null || features.isEmpty()) {
            sql.append(TRACFONE_INSERT_TRANSACTION_FINAL_BLOCK);
        } else {
            //Add the features
            featureSQLBuilder.append("v_featureTyps.extend(").append(features.size()).append(");").append("\n");
            for (TFOneFeatures feature : features) {
                featureSQLBuilder.append("v_featureTyps(").append(++i).append(") := sa.ig_transaction_features_type("); //++i since Oracle Arrays start at position 1
                featureSQLBuilder.append("null").append(",");
                featureSQLBuilder.append("trans_hold,");    //Varible defined in TracfoneOneConstant
                featureSQLBuilder.append("'").append(feature.getFeatureName()).append("'").append(",");
                featureSQLBuilder.append("'").append(feature.getFeatureValue()).append("'").append(",");
                featureSQLBuilder.append("'").append(feature.getFeatureRequirement()).append("'").append(",");
                featureSQLBuilder.append("'").append("NT").append("'").append(", ");
                featureSQLBuilder.append("'").append(feature.getToggleFlag()).append("'").append(", ");
                featureSQLBuilder.append("'").append(feature.getDisplaySUIFlag()).append("'").append(", ");
                featureSQLBuilder.append("'").append(feature.getRestrictSUIFlag()).append("'").append(", ");
                featureSQLBuilder.append("'").append(feature.getProfileId()).append("'").append(");\n");

            }
            sql.append(featureSQLBuilder.toString()).append("\n");
            sql.append(TRACFONE_INSERT_FEATURES_BLOCK);
            sql.append(TRACFONE_INSERT_TRANSACTION_FINAL_BLOCK);
            sql.append("\n");
        }
        return sql.toString();
    }

    private StringBuilder buildQueryParamStringForLike(int amountQueryParam, StringBuilder sBuilder, String queryParamName) {
        if (amountQueryParam <= 0) {
            return sBuilder;
        }

        // Construct the insert param with the first value.
        sBuilder.append(AND).append(queryParamName).append(" like ? ");
        return sBuilder;
    }

    @Override
    public List<TFOneUserHistory> getUserHistoryByUserId(TracfoneOneUserHistory tfOneUserHistory) throws TracfoneOneException {
        List<TFOneUserHistory> userHistories = new ArrayList<>();
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_ALL_USER_HISTORY);
        if (!StringUtils.isNullOrEmpty(tfOneUserHistory.getType())) {
            builder.append(" and UPPER(TYPE) LIKE ? ");
        } else {
            builder.append(" and type in ('INSERT', 'REWORK', 'RE-QUEUE') ");
        }
        builder.append("order by CREATION_DATE DESC");
        LOGGER.info("Search User History query is : " + builder);

        try (Connection con = dbControllerEJB.getDataSource(tfOneUserHistory.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(builder.toString());) {
            stmt.setLong(1, Long.valueOf(tfOneUserHistory.getUserId()));
            stmt.setString(2, tfOneUserHistory.getFromCreationDate());
            stmt.setString(3, tfOneUserHistory.getToCreationDate());
            if (!StringUtils.isNullOrEmpty(tfOneUserHistory.getType())) {
                stmt.setString(4, "%" + tfOneUserHistory.getType().toUpperCase() + "%");
            }
            try (ResultSet rs = stmt.executeQuery();) {
                TFOneUserHistory userHistory;
                while (rs.next()) {
                    userHistory = setUserHistory(rs);
                    userHistory.setTfUserHistoryDetail(getAllUserHistoryDetails(con, userHistory.getId()));
                    userHistories.add(userHistory);
                }
            }
        } catch (NamingException | SQLException | IOException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return userHistories;
    }

    @Override
    public TFOneGeneralResponse insertUserTask(TracfoneOneUserTask tfOneUserTask, int userId) throws TracfoneOneException {
        List<String> transactionIds = new ArrayList<>();
        Gson gson = new Gson();
        UserTask userTask = new UserTask();
        userTask.setAssignedUserId(Integer.valueOf(tfOneUserTask.getAssignedUserId()));
        userTask.setUserId(Integer.valueOf(tfOneUserTask.getUserId()));
        userTask.setDescription(tfOneUserTask.getDescription());
        userTask.setStatus(tfOneUserTask.getStatus().get(0));
        userTask.setTaskName(tfOneUserTask.getTaskName());
        userTask.setType(tfOneUserTask.getType());
        userTask.setCreationDate(new Date());
        userTask.setUpdateDate(new Date());
        StringBuilder builder = new StringBuilder("");
        String uniqueIds = "";
        boolean reassign = false;
        for (TracfoneOneUserTaskDetail detail : tfOneUserTask.getTfOneUserTaskDetails()) {


            if (tfOneUserTask.isValidateTransactions()) {
                transactionIds = validateTransaction();
                if(transactionIds.size()<25){
                    reassign = true;
                List<String> finalTransactionIds = new ArrayList<>(1);
                transactionIds.parallelStream().forEach(e -> {
                    finalTransactionIds.addAll(Arrays.asList(e.split(",")));
                });
                StringBuilder finalUniqueIds = builder;
                Arrays.stream(detail.getTaskDetails().split(",")).
                        filter(x -> finalTransactionIds.indexOf(x) == -1).forEach(e ->
                        finalUniqueIds.append(",").append(e)
                );
                uniqueIds = finalUniqueIds.toString();
                uniqueIds = uniqueIds.replaceFirst(",", "");
                detail.setTaskDetails(uniqueIds);
            }
            }
            UserTaskDetail taskDetail = new UserTaskDetail();
            taskDetail.setTaskDetails(detail.getTaskDetails());
            taskDetail.setUserComments(detail.getUserComments());
            taskDetail.setCreationDate(new Date());
            taskDetail.setUpdateDate(new Date());
            userTask.addUserTaskDetail(taskDetail);
        }
        try {
            if (tfOneUserTask.isValidateTransactions() && uniqueIds.length() > 0 && reassign) {
                userTaskFacade.create(userTask);
            } else if (!tfOneUserTask.isValidateTransactions()) {
                userTaskFacade.create(userTask);
            } else if (tfOneUserTask.isValidateTransactions() && !reassign) {
                userTaskFacade.create(userTask);
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert User Task", gson.toJson(tfOneUserTask), CARRIER_ID);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_USER_TASK_CREATE_SUCCESS);
    }

    @Override
    public TFOneUserTask updateUserTask(TracfoneOneUserTask tfOneUserTask, int userId) throws TracfoneOneException {
        TFOneUserTask tfUserTask = new TFOneUserTask();
        Gson gson = new Gson();
        try {
            if (tfOneUserTask == null || tfOneUserTask.getId() == null) {
                throw new TracfoneOneException(TRACFONE_USER_TASK_CREATE_ERROR_CODE, TRACFONE_USER_TASK_CREATE_ERROR_MESSAGE);
            }
            Integer id = Integer.valueOf(tfOneUserTask.getId());
            UserTask userTask = userTaskFacade.find(id);
            userTask.getUserTaskDetails();

            buildUserTaskEntity(tfOneUserTask, userTask);
            List<TracfoneOneUserTaskDetail> tfOneUserTaskDetails = tfOneUserTask.getTfOneUserTaskDetails();
            List<UserTaskDetail> userTaskDetails = userTask.getUserTaskDetails();

            for (TracfoneOneUserTaskDetail tfOneUserTaskDetail : tfOneUserTaskDetails) {
                for (UserTaskDetail userTaskDetail : userTaskDetails) {
                    if (tfOneUserTaskDetail.getId().equalsIgnoreCase(userTaskDetail.getId().toString())) {
                        buildUserTaskDetailEntity(tfOneUserTaskDetail, userTaskDetail);
                        break;
                    }
                }
            }

            userTaskFacade.edit(userTask);
            tfUserTask = setResponseTFOneUserTask(userTask);

        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_USER_TASK_UPDATE_ERROR_CODE, TRACFONE_USER_TASK_UPDATE_ERROR_MESSAGE, ex);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update User Task", gson.toJson(tfOneUserTask), CARRIER_ID);
            tracfoneAuditEvent.fire(audit);
        }
        return tfUserTask;
    }

    private TFOneUserTask setResponseTFOneUserTask(UserTask userTask) {
        TFOneUserTask tfUserTask = new TFOneUserTask();
        tfUserTask.setUserId(userTask.getUserId().toString());
        tfUserTask.setTaskName(userTask.getTaskName());
        tfUserTask.setType(userTask.getType());
        tfUserTask.setStatus(Collections.singletonList(userTask.getStatus()));
        tfUserTask.setDescription(userTask.getDescription());
        tfUserTask.setId(userTask.getId().toString());
        tfUserTask.setCreationDate(userTask.getCreationDate().toString());
        tfUserTask.setAssignedUserId(userTask.getAssignedUserId().toString());
        for (UserTaskDetail userTaskDetail : userTask.getUserTaskDetails()) {
            tfUserTask.getTfOneUserTaskDetail().add(setResponseTFOneUserTaskDetail(userTaskDetail, tfUserTask.getId()));
        }
        return tfUserTask;
    }

    private TFOneUserTaskDetail setResponseTFOneUserTaskDetail(UserTaskDetail userTaskDetail, String id) {
        TFOneUserTaskDetail tfUserTaskDetail = new TFOneUserTaskDetail();
        tfUserTaskDetail.setUserTaskId(id);
        tfUserTaskDetail.setUserComments(userTaskDetail.getUserComments());
        tfUserTaskDetail.setTaskDetails(userTaskDetail.getTaskDetails());
        tfUserTaskDetail.setId(userTaskDetail.getId().toString());
        return tfUserTaskDetail;
    }

    private void buildUserTaskDetailEntity(TracfoneOneUserTaskDetail tfOneUserTaskDetail, UserTaskDetail userTaskDetail) {
        userTaskDetail.setUserComments(tfOneUserTaskDetail.getUserComments());
        userTaskDetail.setUpdateDate(new Date());
    }

    @Override
    public List<TFOneUserTask> getUserTaskByUserId(TracfoneOneUserTask tfOneUserTask) throws TracfoneOneException {
        List<TFOneUserTask> userTasks = new ArrayList<>();
        try {
            List<UserTask> userTaskLists = userTaskFacade.findAllUserTask(Integer.valueOf(tfOneUserTask.getAssignedUserId()), tfOneUserTask.getStatus(),
                    tfOneUserTask.getFromCreationDate(), tfOneUserTask.getToCreationDate(), tfOneUserTask.getType());
            String userTaskId;
            for (UserTask userTask : userTaskLists) {
                userTaskId = String.valueOf(userTask.getId());
                TFOneUserTask tfUserTask = new TFOneUserTask();
                tfUserTask.setId(userTaskId);
                tfUserTask.setAssignedUserId(String.valueOf(userTask.getAssignedUserId()));
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss");
                tfUserTask.setCreationDate(formatter.format(userTask.getCreationDate()));
                tfUserTask.setDescription(userTask.getDescription());
                tfUserTask.setStatus(Collections.singletonList(userTask.getStatus()));
                tfUserTask.setType(userTask.getType());
                tfUserTask.setTaskName(userTask.getTaskName());
                tfUserTask.setUserId(String.valueOf(userTask.getUserId()));
                tfUserTask.setTfOneUserTaskDetail(getAllUserTaskDetails(userTask.getUserTaskDetails(), userTaskId));
                userTasks.add(tfUserTask);
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_USER_TASK_RETRIEVAL_ERROR_CODE, TRACFONE_USER_TASK_RETRIEVAL_ERROR_MESSAGE, e);
        }
        return userTasks;
    }

    @Override
    public void insertBulkTransactions(TracfoneOneBulkTransaction tfOneBulkTransaction, int userId, String description) throws TracfoneOneException {
        Gson gson = new Gson();
        List<TracfoneOneBulkIdentifier> identifiers = tfOneBulkTransaction.getIdentifierList();
        TracfoneOneNewTransaction tfOneNewTransaction = tfOneBulkTransaction.getTracfoneOneNewTransaction();
        String unique = description + (new SecureRandom().nextInt((99999 - 10000) + 1) + 10000);
        try {
            TracfoneAudit audit = new TracfoneAudit(userId, BULK_IG_INSERT,
                    "Requested a bulk insert of IG Transactions-" + identifiers.size(),
                    String.valueOf(identifiers.size()) + "_" + unique);
            tracfoneAuditEvent.fire(audit);
            List<String> actionItemIds = new ArrayList<>();
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (TracfoneOneBulkIdentifier identifier : identifiers) {
                    tfOneNewTransaction.setMin(identifier.getMin());
                    tfOneNewTransaction.setEsn(identifier.getEsn());
                    tfOneNewTransaction.setIccid(identifier.getIccid());
                    tfOneNewTransaction.setRatePlan(identifier.getRatePlan());
                    tfOneNewTransaction.setEsnHex(identifier.getEsnHex());
                    tfOneNewTransaction.setCarrFeat(identifier.getCarrFeat());
                    tfOneNewTransaction.setZipCode(identifier.getZipCode());
                    tfOneNewTransaction.setRatePlanProfileId(identifier.getRatePlanProfileId());
                    tfOneNewTransaction.setServicePlanId(identifier.getServicePlanId());
                    tfOneNewTransaction.seteSimFlag(identifier.geteSimFlag());
                    try {
                        TFOneGeneralResponse response = insertTransaction(tfOneNewTransaction, userId, unique, false, unique);
                        actionItemIds.add(response.getMessage());
                        LOGGER.info("IG Transaction inserted ");
                    } catch (Exception e) {
                        LOGGER.error("Insertion of this transaction failed " + tfOneNewTransaction);
                        TracfoneAudit errorAudit = new TracfoneAudit(userId, BULK_IG_INSERT,
                                "Bulk Insert Failed for Transaction " + gson.toJson(tfOneNewTransaction),
                                ERROR + unique);
                        tracfoneAuditEvent.fire(errorAudit);
                    }
                }
                insertUserHistory(tfOneNewTransaction.getDbenv(), userId, actionItemIds, unique);
            });
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_BULK_INSERT_ERROR_CODE, TRACFONE_BULK_INSERT_ERROR_MESSAGE, e);
        }
    }

    @Override
    public List<TFOneBulkInsertReport> getBulkInsertSummary(String dbEnv, String action, int userId) throws TracfoneOneException {
        List<TFOneBulkInsertReport> finalReports = new ArrayList<>();
        LOGGER.debug("Inside Get bulk insert Summary");
        LOGGER.debug("User Id : " + userId);
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_BULK_INSERTED_SUMMARY_RECORDS);
             PreparedStatement successErrorCountStmt = con.prepareStatement(TRACFONE_GET_RECORD_COUNT_AND_CARRERID);) {
            stmt.setLong(1, userId);
            stmt.setString(2, action);
            successErrorCountStmt.setLong(1, userId);
            List<TFOneBulkInsertReport> summaryRecords = new ArrayList<>(1);
            try (ResultSet rs = stmt.executeQuery();) {
                while (rs.next()) {
                    TFOneBulkInsertReport report = new TFOneBulkInsertReport();
                    report.setId(rs.getString("ID"));
                    report.setCreateDate(rs.getString("CREATEDATE"));
                    report.setUniqueIdentifier(rs.getString(CARRIERID));
                    summaryRecords.add(report);
                }
                LOGGER.debug("Summary Record : " + summaryRecords);
            }
            for (TFOneBulkInsertReport actions : summaryRecords) {
                TFOneBulkInsertReport report = new TFOneBulkInsertReport();
                report.setId(actions.getId());
                report.setCreateDate(actions.getCreateDate());
                String carrierId = actions.getUniqueIdentifier();
                String totalInsertedRecords = carrierId.split("_", 2)[0];
                LOGGER.debug("Total number of inserted record is : " + totalInsertedRecords);

                String uniqueIdentifier = carrierId.split("_", 2)[1];
                LOGGER.debug("Unique Identifier is : " + uniqueIdentifier);
                try {

                    successErrorCountStmt.setString(2, CARRIER_ID1.concat(uniqueIdentifier));
                    successErrorCountStmt.setString(3, ERROR.concat(uniqueIdentifier));
                    try (ResultSet resultSet = successErrorCountStmt.executeQuery();) {
                        while (resultSet.next()) {
                            report.setUniqueIdentifier(resultSet.getString(CARRIERID));
                            if (resultSet.getString(CARRIERID).contains(CARRIER_ID1)) {
                                report.setSuccessCount(resultSet.getString("COUNT"));
                            } else if (resultSet.getString(CARRIERID).contains(ERROR)) {
                                report.setErrorCount(resultSet.getString("COUNT"));
                            }
                        }
                    }

                    LOGGER.debug("Total error record is : " + report.getErrorCount());
                    LOGGER.debug("Total Success record is  : " + report.getSuccessCount());

                    if (report.getSuccessCount() == null) {
                        report.setSuccessCount("0");
                    }
                    if (report.getErrorCount() == null) {
                        report.setErrorCount("0");
                    }
                    int statusCount = 0;
                    statusCount = Integer.parseInt(report.getSuccessCount()) + Integer.parseInt(report.getErrorCount());
                    report.setStatus(statusCount == Integer.parseInt(totalInsertedRecords) ? "COMPLETE" : "IN PROGRESS");
                    report.setTotalRecord(totalInsertedRecords);
                    report.setUniqueIdentifier(uniqueIdentifier);
                    finalReports.add(report);
                } catch (SQLException e) {
                    LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
                }
            }
        } catch (Exception e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return finalReports;
    }

    @Override
    public List<TFOneBulkInsertReport> getErrorRecordDetails(TracfoneOneUserHistory tracfoneOneUserHistory) throws TracfoneOneException {
        List<TFOneBulkInsertReport> errorDetails = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneUserHistory.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_CARRIER_ID_BY_ID);
             PreparedStatement errorRecordStmt = con.prepareStatement(TRACFONE_GET_ERROR_DETAILS);) {
            stmt.setString(1, tracfoneOneUserHistory.getId());

            try (ResultSet rs = stmt.executeQuery();) {
                while (rs.next()) {
                    TFOneBulkInsertReport errorDetail = new TFOneBulkInsertReport();
                    String carrierId = rs.getString(CARRIERID);
                    LOGGER.info("Carrier id for id " + tracfoneOneUserHistory.getId() + " is " + carrierId);

                    errorRecordStmt.setString(1, ERROR.concat(carrierId.split("_", 2)[1]));
                    try (ResultSet resultSet = errorRecordStmt.executeQuery();) {
                        while (resultSet.next()) {
                            errorDetail = new TFOneBulkInsertReport();
                            errorDetail.setCreateDate(resultSet.getString("CREATEDATE"));
                            errorDetail.setId(resultSet.getString("ID"));
                            errorDetail.setDetails(resultSet.getString("DETAILS"));
                            errorDetails.add(errorDetail);
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return errorDetails;
    }

    @Override
    public List<TFOneAdminActionItem> getIgTransactionsInProgress(TracfoneOneNewTransaction tracfoneOneNewTransaction) throws TracfoneOneException {
        List<TFOneAdminActionItem> tfOneAdminActionItems = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNewTransaction.getDbenv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getIgTransStatement(tracfoneOneNewTransaction));) {
            setIgTransParams(tracfoneOneNewTransaction, stmt);

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    TFOneAdminActionItem tfOneAdminActionItem = new TFOneAdminActionItem();
                    tfOneAdminActionItem.setTransactionId(resultSet.getString(TRANSACTION_ID));
                    tfOneAdminActionItem.setMsid(resultSet.getString("MSID"));
                    tfOneAdminActionItem.setEsn(resultSet.getString("ESN"));
                    tfOneAdminActionItem.setIccid(resultSet.getString(ICCID));
                    tfOneAdminActionItem.setCreationDate(resultSet.getString(CREATION_DATE));
                    tfOneAdminActionItems.add(tfOneAdminActionItem);
                }
            }
        } catch (Exception e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneAdminActionItems;
    }

    private void setIgTransParams(TracfoneOneNewTransaction tracfoneOneNewTransaction, PreparedStatement stmt) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneNewTransaction.getMsid())) {
            stmt.setString(index++, tracfoneOneNewTransaction.getMsid());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNewTransaction.getEsn())) {
            stmt.setString(index++, tracfoneOneNewTransaction.getEsn());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneNewTransaction.getIccid())) {
            stmt.setString(index, tracfoneOneNewTransaction.getIccid());
        }
    }

    private String getIgTransStatement(TracfoneOneNewTransaction tracfoneOneNewTransaction) {
        String searchQuery = TRACFONE_GET_IG_TRANSACTION_IN_PROGRESS;

        StringBuilder builder = new StringBuilder(searchQuery);
        if (tracfoneOneNewTransaction.getMsid() != null) {
            builder.append("MSID = ? ").append(AND);
        } else {
            builder.append("MSID is NULL ").append(AND);
        }
        if (tracfoneOneNewTransaction.getEsn() != null) {
            builder.append("ESN = ? ").append(AND);
        } else {
            builder.append("ESN is NULL ").append(AND);
        }
        if (tracfoneOneNewTransaction.getIccid() != null) {
            builder.append("ICCID = ? ").append(AND);
        } else {
            builder.append("ICCID is NULL ").append(AND);
        }

        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info(searchQuery);
        return searchQuery;
    }

    @Override
    public TFOneGeneralResponse deleteIgTransactionInProgress(TracfoneOneNewTransaction tracfoneOneNewTransaction, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNewTransaction.getDbenv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(buildDeleteIgInProgressQuery(tracfoneOneNewTransaction));) {
            int index = 1;
            stmt.setString(index++, tracfoneOneNewTransaction.getTransactionId());
            stmt.setString(index++, tracfoneOneNewTransaction.getCreationDate());
            if (!StringUtils.isNullOrEmpty(tracfoneOneNewTransaction.getMsid())) {
                stmt.setString(index++, tracfoneOneNewTransaction.getMsid());
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneNewTransaction.getEsn())) {
                stmt.setString(index++, tracfoneOneNewTransaction.getEsn());
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneNewTransaction.getIccid())) {
                stmt.setString(index, tracfoneOneNewTransaction.getIccid());
            }

            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId,
                    "Delete Ig Transaction In Progress", "Deleted Ig Transaction In Progress " + tracfoneOneNewTransaction.getTransactionId(),
                    null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneNewTransaction.getTransactionId());
    }

    private String buildDeleteIgInProgressQuery(TracfoneOneNewTransaction tracfoneOneNewTransaction) {
        StringBuilder builder = new StringBuilder(TRACFONE_DELETE_IG_TRANSACTION_IN_PROGRESS);
        if (StringUtils.isNullOrEmpty(tracfoneOneNewTransaction.getMsid())) {
            builder.append("MSID is NULL").append(AND);
        } else {
            builder.append("MSID = ?").append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneNewTransaction.getEsn())) {
            builder.append("ESN is NULL").append(AND);
        } else {
            builder.append("ESN = ?").append(AND);
        }
        if (StringUtils.isNullOrEmpty(tracfoneOneNewTransaction.getIccid())) {
            builder.append("ICCID is NULL").append(AND);
        } else {
            builder.append("ICCID = ?").append(AND);
        }
        LOGGER.info("query to delete IG Trans in progress is " + builder.toString());
        return builder.substring(0, builder.lastIndexOf(AND));
    }

    private List<TFOneUserTaskDetail> getAllUserTaskDetails(List<UserTaskDetail> userTaskDetailLists, String userTaskId) {
        List<TFOneUserTaskDetail> userTaskDetails = new ArrayList<>();
        for (UserTaskDetail userTaskDetail : userTaskDetailLists) {
            TFOneUserTaskDetail tfUserTaskDetail = new TFOneUserTaskDetail();
            tfUserTaskDetail.setId(String.valueOf(userTaskDetail.getId()));
            tfUserTaskDetail.setTaskDetails(userTaskDetail.getTaskDetails());
            tfUserTaskDetail.setUserComments(userTaskDetail.getUserComments());
            tfUserTaskDetail.setUserTaskId(userTaskId);
            userTaskDetails.add(tfUserTaskDetail);
        }
        return userTaskDetails;
    }

    private void buildUserTaskEntity(TracfoneOneUserTask tfOneUserTask, UserTask userTask) {
        userTask.setStatus(tfOneUserTask.getStatus().get(0));
        userTask.setUpdateDate(new Date());
    }

    private TFOneUserHistory setUserHistory(ResultSet rs) throws SQLException {
        TFOneUserHistory tfOneUserHistory = new TFOneUserHistory();
        tfOneUserHistory.setId(rs.getString("ID"));
        tfOneUserHistory.setUserId(rs.getString("USER_ID"));
        tfOneUserHistory.setType(rs.getString("TYPE"));
        tfOneUserHistory.setCreationDate(rs.getString(CREATION_DATE));
        return tfOneUserHistory;
    }

    private List<TFOneUserHistoryDetail> getAllUserHistoryDetails(Connection con, String id) throws SQLException, IOException {
        List<TFOneUserHistoryDetail> userHistoryDetails = new ArrayList<>();
        try (PreparedStatement stmt = con.prepareStatement(TRACFONE_SEARCH_ALL_USER_HISTORY_DETAILS);) {
            stmt.setLong(1, Long.valueOf(id));
            try (ResultSet rs = stmt.executeQuery();) {
                TFOneUserHistoryDetail tfOneUserHistoryDetail;
                while (rs.next()) {
                    tfOneUserHistoryDetail = setUserHistoryDetail(rs);
                    userHistoryDetails.add(tfOneUserHistoryDetail);
                }
            }
        }
        return userHistoryDetails;
    }

    private TFOneUserHistoryDetail setUserHistoryDetail(ResultSet rs) throws SQLException, IOException {
        TFOneUserHistoryDetail tfOneUserHistoryDetail = new TFOneUserHistoryDetail();
        tfOneUserHistoryDetail.setUserHistoryDetailId(rs.getString("ID"));
        tfOneUserHistoryDetail.setUserHistoryId(rs.getString("HISTORY_ID"));
        tfOneUserHistoryDetail.setIdDetail(convertClobToString(rs.getClob("ID_DETAIL")));
        tfOneUserHistoryDetail.setIdType(rs.getString("ID_TYPE"));
        return tfOneUserHistoryDetail;
    }

    private String convertClobToString(Clob clob) throws SQLException, IOException {
        String transactionIds = null;
        if (null != clob) {
            Reader reader = clob.getCharacterStream();
            StringWriter writer = new StringWriter();
            IOUtils.copy(reader, writer);
            String convertedClob = writer.toString();
            transactionIds = removeDuplicates(convertedClob);
        }
        return transactionIds;
    }

    private String removeDuplicates(String convertedClob) {
        return String.join(",",
                Arrays.asList(convertedClob.split(","))
                        .stream()
                        .distinct()
                        .collect(Collectors.toList()));
    }

    /**
     * @param dbEnv
     * @param uniqueKey
     * @param userId
     * @return
     * @throws TracfoneOneException
     */
    @Override
    public TFOneGeneralResponse getUserHistoryDetailByIdType(String dbEnv, String uniqueKey, int userId) throws TracfoneOneException {
        String idDetails = null;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_USER_HISTORY_DETAIL);) {
            stmt.setString(1, uniqueKey);
            stmt.setLong(2, userId);
            try (ResultSet rs = stmt.executeQuery();) {
                while (rs.next()) {
                    idDetails = convertClobToString(rs.getClob("ID_DETAIL"));
                }
            }
        } catch (NamingException | SQLException | IOException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, idDetails);
    }

    private void addTestOtaEsn(Connection con, TracfoneOneNewTransaction tfOneNewTransaction) {
        boolean esnAlredyExist = validateEsnAlreadyExist(con, tfOneNewTransaction, "OTA");
        if (!esnAlredyExist) {
            try (PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_TEST_OTA_ESN);) {
                if (!StringUtils.isNullOrEmpty(tfOneNewTransaction.getEsn())) {
                    stmt.setString(1, tfOneNewTransaction.getEsn());
                    stmt.executeUpdate();
                }
            } catch (Exception e) {
                LOGGER.error(e);
            }
        }
    }

    private void addTestIgateEsn(Connection con, TracfoneOneNewTransaction tfOneNewTransaction) {
        boolean esnAlredyExist = validateEsnAlreadyExist(con, tfOneNewTransaction, "IGATE");
        if (!esnAlredyExist) {
            try (PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_TEST_IGATE_ESN);) {
                if (!StringUtils.isNullOrEmpty(tfOneNewTransaction.getEsn()) && !StringUtils.isNullOrEmpty(tfOneNewTransaction.getEsnType())) {
                    stmt.setString(1, tfOneNewTransaction.getEsn());
                    stmt.setString(2, tfOneNewTransaction.getEsnType());
                    stmt.executeUpdate();
                }
            } catch (Exception e) {
                LOGGER.error(e);
            }
        }
    }

    private boolean validateEsnAlreadyExist(Connection con, TracfoneOneNewTransaction tfOneNewTransaction, String type) {
        boolean alreadyExist = false;
        int count = 0;
        try (PreparedStatement otaStmt = con.prepareStatement(TRACFONE_CHECK_ESN_TEST_OTA_ESN);
             PreparedStatement igateStmt = con.prepareStatement(TRACFONE_CHECK_ESN_TEST_IGATE_ESN);) {
            if ("OTA".equalsIgnoreCase(type)) {
                if (!StringUtils.isNullOrEmpty(tfOneNewTransaction.getEsn())) {
                    otaStmt.setString(1, tfOneNewTransaction.getEsn());
                    try (ResultSet result = otaStmt.executeQuery()) {
                        while (result.next()) {
                            count = result.getInt(1);
                        }
                    }
                    if (count > 0)
                        alreadyExist = true;
                }
            } else {
                if (!StringUtils.isNullOrEmpty(tfOneNewTransaction.getEsn())) {
                    igateStmt.setString(1, tfOneNewTransaction.getEsn());
                    try (ResultSet result = igateStmt.executeQuery()) {
                        while (result.next()) {
                            count = result.getInt(1);
                        }
                    }
                    if (count > 0)
                        alreadyExist = true;
                }
            }
        } catch (Exception e) {
            LOGGER.error(e);
        }
        return alreadyExist;
    }

    private StringBuilder createRegexQuery(StringBuilder sbuilder, TracfoneOneActionItemId actionItemId) {
        if (StringUtils.isNullOrEmpty(actionItemId.getMatchParam())) {
            sbuilder.append(" AND REGEXP_LIKE(ig.STATUS_MESSAGE, ?) ");
        } else {
            sbuilder.append(" AND REGEXP_LIKE(ig.STATUS_MESSAGE, ?, ").append("'").append(actionItemId.getMatchParam()).append("'").append(") ");
        }
        return sbuilder;
    }

    @Override
    public List<TFOneIGFailLogs> getIgFailLogs(TracfoneOneNewTransaction tracfoneOneNewTransaction) throws TracfoneOneException {
        List<TFOneIGFailLogs> tfOneAdminActionItems = new ArrayList<>();
        int index = 1;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneNewTransaction.getDbenv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_IG_FAIL_LOGS);) {
            stmt.setString(index, tracfoneOneNewTransaction.getActionItemId());

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneAdminActionItems.add(setIgFailLogs(resultSet));
                }
            }
        } catch (Exception e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneAdminActionItems;
    }

    private TFOneIGFailLogs setIgFailLogs(ResultSet resultSet) throws SQLException {
        TFOneIGFailLogs tfOneAdminActionItem = new TFOneIGFailLogs();

        tfOneAdminActionItem.setActionItemId(resultSet.getString("ACTION_ITEM_ID"));
        tfOneAdminActionItem.setCarrierId(resultSet.getString("CARRIER_ID"));
        tfOneAdminActionItem.setOrderType(resultSet.getString("ORDER_TYPE"));
        tfOneAdminActionItem.setMin(resultSet.getString("MIN"));
        tfOneAdminActionItem.setEsn(resultSet.getString("ESN"));

        tfOneAdminActionItem.setEsnHex(resultSet.getString("ESN_HEX"));
        tfOneAdminActionItem.setOldEsn(resultSet.getString("OLD_ESN"));
        tfOneAdminActionItem.setOldEsnHex(resultSet.getString("OLD_ESN_HEX"));
        tfOneAdminActionItem.setPin(resultSet.getString("PIN"));
        tfOneAdminActionItem.setPhoneManf(resultSet.getString("PHONE_MANF"));

        tfOneAdminActionItem.setEndUser(resultSet.getString("END_USER"));
        tfOneAdminActionItem.setAccountNum(resultSet.getString("ACCOUNT_NUM"));
        tfOneAdminActionItem.setMarketCode(resultSet.getString("MARKET_CODE"));
        tfOneAdminActionItem.setRatePlan(resultSet.getString("RATE_PLAN"));
        tfOneAdminActionItem.setLdProvider(resultSet.getString("LD_PROVIDER"));

        tfOneAdminActionItem.setSequenceNum(resultSet.getString("SEQUENCE_NUM"));
        tfOneAdminActionItem.setDealerCode(resultSet.getString("DEALER_CODE"));
        tfOneAdminActionItem.setTransmissionMethod(resultSet.getString("TRANSMISSION_METHOD"));
        tfOneAdminActionItem.setFaxNum(resultSet.getString("FAX_NUM"));
        tfOneAdminActionItem.setOnlineNum(resultSet.getString("ONLINE_NUM"));

        tfOneAdminActionItem.setEmail(resultSet.getString("EMAIL"));
        tfOneAdminActionItem.setNetworkLogin(resultSet.getString("NETWORK_LOGIN"));
        tfOneAdminActionItem.setNetworkPassword(resultSet.getString("NETWORK_PASSWORD"));
        tfOneAdminActionItem.setSystemLogin(resultSet.getString("SYSTEM_LOGIN"));
        tfOneAdminActionItem.setSystemPassword(resultSet.getString("SYSTEM_PASSWORD"));

        tfOneAdminActionItem.setTemplate(resultSet.getString("TEMPLATE"));
        tfOneAdminActionItem.setComPort(resultSet.getString("COM_PORT"));
        tfOneAdminActionItem.setStatus(resultSet.getString("STATUS"));
        tfOneAdminActionItem.setStatusMessage(resultSet.getString("STATUS_MESSAGE"));
        tfOneAdminActionItem.setTransProfKey(resultSet.getString("TRANS_PROF_KEY"));

        tfOneAdminActionItem.setqTransaction(resultSet.getString("Q_TRANSACTION"));
        tfOneAdminActionItem.setFaxNum2(resultSet.getString("FAX_NUM2"));
        tfOneAdminActionItem.setCreationDate(resultSet.getString(CREATION_DATE));
        tfOneAdminActionItem.setUpdateDate(resultSet.getString("UPDATE_DATE"));
        tfOneAdminActionItem.setBlackoutWait(resultSet.getString("BLACKOUT_WAIT"));

        tfOneAdminActionItem.setTransactionId(resultSet.getString("TRANSACTION_ID"));
        tfOneAdminActionItem.setTechnologyFlag(resultSet.getString("TECHNOLOGY_FLAG"));
        tfOneAdminActionItem.setVoiceMail(resultSet.getString("VOICE_MAIL"));
        tfOneAdminActionItem.setVoiceMailPackage(resultSet.getString("VOICE_MAIL_PACKAGE"));
        tfOneAdminActionItem.setCallerId(resultSet.getString("CALLER_ID"));

        tfOneAdminActionItem.setCallerIdPackage(resultSet.getString("CALLER_ID_PACKAGE"));
        tfOneAdminActionItem.setCallWaiting(resultSet.getString("CALL_WAITING"));
        tfOneAdminActionItem.setCallWaitingPackage(resultSet.getString("CALL_WAITING_PACKAGE"));
        tfOneAdminActionItem.setDigitalFeatureCode(resultSet.getString("DIGITAL_FEATURE_CODE"));
        tfOneAdminActionItem.setStateField(resultSet.getString("STATE_FIELD"));

        tfOneAdminActionItem.setZipCode(resultSet.getString("ZIP_CODE"));
        tfOneAdminActionItem.setMsid(resultSet.getString("MSID"));
        tfOneAdminActionItem.setNewMsidFlag(resultSet.getString("NEW_MSID_FLAG"));
        tfOneAdminActionItem.setSms(resultSet.getString("SMS"));
        tfOneAdminActionItem.setSmsPackage(resultSet.getString("SMS_PACKAGE"));

        tfOneAdminActionItem.setIccid(resultSet.getString("ICCID"));
        tfOneAdminActionItem.setOldMin(resultSet.getString("OLD_MIN"));
        tfOneAdminActionItem.setDigitalFeature(resultSet.getString("DIGITAL_FEATURE"));
        tfOneAdminActionItem.setOtaType(resultSet.getString("OTA_TYPE"));
        tfOneAdminActionItem.setRateCenterNo(resultSet.getString("RATE_CENTER_NO"));

        tfOneAdminActionItem.setApplicationSystem(resultSet.getString("APPLICATION_SYSTEM"));
        tfOneAdminActionItem.setSubscriberUpdate(resultSet.getString("SUBSCRIBER_UPDATE"));
        tfOneAdminActionItem.setDownloadDate(resultSet.getString("PRL_NUMBER"));
        tfOneAdminActionItem.setAmount(resultSet.getString("AMOUNT"));
        tfOneAdminActionItem.setBalance(resultSet.getString("BALANCE"));

        tfOneAdminActionItem.setLanguage(resultSet.getString("LANGUAGE"));
        tfOneAdminActionItem.setExpDate(resultSet.getString("EXP_DATE"));
        tfOneAdminActionItem.setxMpn(resultSet.getString("X_MPN"));
        tfOneAdminActionItem.setxMpnCode(resultSet.getString("X_MPN_CODE"));
        tfOneAdminActionItem.setxPoolName(resultSet.getString("X_POOL_NAME"));

        tfOneAdminActionItem.setxMake(resultSet.getString("X_MAKE"));
        tfOneAdminActionItem.setxModel(resultSet.getString("X_MODEL"));
        tfOneAdminActionItem.setxMode(resultSet.getString("X_MODE"));
        tfOneAdminActionItem.setCarrierInitialTransTime(resultSet.getString("CARRIER_INITIAL_TRANS_TIME"));
        tfOneAdminActionItem.setCarrierEndTransTime(resultSet.getString("CARRIER_END_TRANS_TIME"));

        tfOneAdminActionItem.setLoggedDate(resultSet.getString("LOGGED_DATE"));
        tfOneAdminActionItem.setLoggedBy(resultSet.getString("LOGGED_BY"));

        return tfOneAdminActionItem;
    }

    @Override
    public List<TFOneColumnDesc> getTableDesc(TracfoneOneColumnDesc tfColumnDesc) throws TracfoneOneException {
        List<TFOneColumnDesc> columnDescList = new ArrayList<>(1);
        try (Connection con = dbControllerEJB.getDataSource(tfColumnDesc.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_COLUMN_DESC);) {
            stmt.setString(1, tfColumnDesc.getTableName());
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    columnDescList.add(setColumnDesc(resultSet));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return columnDescList;
    }
    
    public List<TFOneColumnDesc> getTableColumns(TracfoneOneColumnDesc tfColumnDesc, Connection con) throws TracfoneOneException {
        List<TFOneColumnDesc> columnDescList = new ArrayList<>(1);
        try (PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_COLUMN_DESC);) {
            stmt.setString(1, tfColumnDesc.getTableName());
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    columnDescList.add(setColumnDesc(resultSet));
                }
            }
        } catch (SQLException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return columnDescList;
    }
    
    private TFOneColumnDesc setColumnDesc(ResultSet resultSet) throws SQLException{
        TFOneColumnDesc columnDesc = new TFOneColumnDesc();
        columnDesc.setColumnName(resultSet.getString("COLUMN_NAME"));
        columnDesc.setDataLength(resultSet.getString("DATA_LENGTH"));
        columnDesc.setDataPrecision(resultSet.getString("DATA_PRECISION"));
        columnDesc.setDataScale(resultSet.getString("DATA_SCALE"));
        columnDesc.setDataType(resultSet.getString("DATA_TYPE"));
        return columnDesc;
    }

    public List<String> validateTransaction() throws TracfoneOneException{
        List<String> dbLists = new ArrayList<>();
        try {
            dbLists = userTaskFacade.getEntityManager().
                    createNativeQuery(TRACFONE_VALIDATE_TRANSACTION_IN_PROGRESS).getResultList();
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return dbLists;
    }

    private String removeCLM(String column){
        return  column.replace("CLM_","")+ " , ";
    }

}