package com.tracfone.service.controller.retail;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.retail.request.TracfoneOneRetailLocation;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTpAdminSearchModel;
import com.tracfone.service.util.TracfoneOneConstantRetailStore;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Stateless
public class TracfoneOneRetailStoreController implements TracfoneOneRetailStoreControllerLocal, TracfoneOneConstantRetailStore {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneRetailStoreController.class);

    @EJB
    TracfoneOneRetailTraitActionLocal tracfoneOneRetailTraitAction;

    @EJB
    TracfoneOneRetailAdminActionLocal tracfoneOneRetailAdminAction;

    @Override
    public TFOneGeneralResponse insertTpNorms(TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel, int userId) throws TracfoneOneException {
        try {
            TracfoneOneRetailTpAdminSearchModel tpNorm = new TracfoneOneRetailTpAdminSearchModel();
            tpNorm.setCoverage(retailTpAdminSearchModel.getCoverage());
            tpNorm.setCoverageNotes(retailTpAdminSearchModel.getCoverageNotes());

            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (String carrierDetailId : retailTpAdminSearchModel.getCarrierDetails().split(",")) {
                    for (String zip : retailTpAdminSearchModel.getZipCodes().split(",")) {
                        LOGGER.info("carrier detail id " + carrierDetailId + " zip code " + zip);
                        tpNorm.setCarrierDetails(carrierDetailId);
                        tpNorm.setZipCodes(zip);
                        LOGGER.info("INSERT TP NORM " + tpNorm);
                        tracfoneOneRetailAdminAction.insertTpNorm(tpNorm, userId);
                        LOGGER.info("DONE INSERT TP NORM " + tpNorm);
                    }
                }
            });
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_INSERT_TP_NORM, TRACFONE_INSERT_TP_NORM, e);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_TP_NORMS_CREATE_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse updateRetailLocationRadius(List<TracfoneOneRetailLocation> tracfoneOneRetailLocations, int userId) throws TracfoneOneException {
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (TracfoneOneRetailLocation tracfoneOneRetailLocation : tracfoneOneRetailLocations) {
                    int beforeTraits = tracfoneOneRetailTraitAction.getTraitCountForLocation(tracfoneOneRetailLocation.getObjIds());
                    LOGGER.info("Calling SP C_RTL_STORE_SP_N" + tracfoneOneRetailLocation);
                    boolean success = tracfoneOneRetailTraitAction.addUpdateRetailStore(tracfoneOneRetailLocation, userId);
                    LOGGER.info("Done with SP C_RTL_STORE_SP_N  for updating retail location radius" + success);
                    // If I have successfully called the stored proc, then go approve this change
                    if (success) {
                        // only approve once the SP has created a new row in trait table.
                        int afterTraits = tracfoneOneRetailTraitAction.getTraitCountForLocation(tracfoneOneRetailLocation.getObjIds());
                        while (beforeTraits == afterTraits) {
                            afterTraits = tracfoneOneRetailTraitAction.getTraitCountForLocation(tracfoneOneRetailLocation.getObjIds());
                        }
                        LOGGER.info("APPROVING THE CHANGE" + tracfoneOneRetailLocation);
                        tracfoneOneRetailTraitAction.approveTraits(tracfoneOneRetailLocation.getObjIds(), userId);
                        LOGGER.info("Done with APPROVAL" + tracfoneOneRetailLocation);
                    }
                }
            });
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_UPDATE_RETAIL_LOCATIONS, TRACFONE_UPDATE_RETAIL_LOCATIONS_MESSAGE, e);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_UPDATE_RETAIL_LOCATION_SUCCESS);
    }

    @Override
    public TFOneGeneralResponse openStores(List<TracfoneOneRetailLocation> tracfoneOneRetailLocations, int userId) throws TracfoneOneException {
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (TracfoneOneRetailLocation tracfoneOneRetailLocation : tracfoneOneRetailLocations) {
                    LOGGER.info("Calling SP C_RTL_STORE_SP_N" + tracfoneOneRetailLocation);
                    tracfoneOneRetailTraitAction.addUpdateRetailStore(tracfoneOneRetailLocation, userId);
                    LOGGER.info("Done with SP C_RTL_STORE_SP_N  for opening store " + tracfoneOneRetailLocation);
                }
            });
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_ADD_STORE, TRACFONE_ADD_STORE_MESSAGE, e);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_STORE_OPEN_SUCCESS);
    }
}
