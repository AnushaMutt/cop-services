package com.tracfone.service.model.response;

public class TFOneDataConfigMapping {
    private String parentId;
    private String partClassObjId;
    private String ratePlan;
    private String dataConfigObjId;

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getPartClassObjId() {
        return partClassObjId;
    }

    public void setPartClassObjId(String partClassObjId) {
        this.partClassObjId = partClassObjId;
    }

    public String getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(String ratePlan) {
        this.ratePlan = ratePlan;
    }

    public String getDataConfigObjId() {
        return dataConfigObjId;
    }

    public void setDataConfigObjId(String dataConfigObjId) {
        this.dataConfigObjId = dataConfigObjId;
    }

    @Override
    public String toString() {
        return "TFOneDataConfigMapping{" +
                "parentId='" + parentId + '\'' +
                ", partClassObjId='" + partClassObjId + '\'' +
                ", ratePlan='" + ratePlan + '\'' +
                ", dataConfigObjId='" + dataConfigObjId + '\'' +
                '}';
    }
}
