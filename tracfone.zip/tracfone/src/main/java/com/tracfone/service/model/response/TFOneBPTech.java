package com.tracfone.service.model.response;

public class TFOneBPTech {
    private String techkey;
    private String service;
    private String bpCode;
    private String productKey;

    public String getTechkey() {
        return techkey;
    }

    public void setTechkey(String techkey) {
        this.techkey = techkey;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getBpCode() {
        return bpCode;
    }

    public void setBpCode(String bpCode) {
        this.bpCode = bpCode;
    }

    public String getProductKey() {
        return productKey;
    }

    public void setProductKey(String productKey) {
        this.productKey = productKey;
    }

    @Override
    public String toString() {
        return "TFOneBPTech{" +
                "techkey='" + techkey + '\'' +
                ", service='" + service + '\'' +
                ", bpCode='" + bpCode + '\'' +
                ", productKey='" + productKey + '\'' +
                '}';
    }
}
