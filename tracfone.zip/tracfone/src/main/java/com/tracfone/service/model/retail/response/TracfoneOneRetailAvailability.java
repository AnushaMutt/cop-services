package com.tracfone.service.model.retail.response;

import java.util.HashMap;
import java.util.Map;

public class TracfoneOneRetailAvailability {
    private String retailer;
    private String storeName;
    private String storeNum;
    private String zip;
    private String state;
    private String brand;
    private String radius;
    private Map<String, String> carrierTechs;

    public TracfoneOneRetailAvailability() {
        carrierTechs = new HashMap<>();
    }

    public String getRetailer() {
        return retailer;
    }

    public void setRetailer(String retailer) {
        this.retailer = retailer;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getStoreNum() {
        return storeNum;
    }

    public void setStoreNum(String storeNum) {
        this.storeNum = storeNum;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getRadius() {
        return radius;
    }

    public void setRadius(String radius) {
        this.radius = radius;
    }

    public Map<String, String> getCarrierTechs() {
        return carrierTechs;
    }

    public void setCarrierTechs(Map<String, String> carrierTechs) {
        this.carrierTechs = carrierTechs;
    }

    @Override
    public String toString() {
        return "TracfoneOneRetailAvailability{" +
                "retailer='" + retailer + '\'' +
                ", storeName='" + storeName + '\'' +
                ", storeNum='" + storeNum + '\'' +
                ", zip='" + zip + '\'' +
                ", state='" + state + '\'' +
                ", brand='" + brand + '\'' +
                ", radius='" + radius + '\'' +
                ", carrierTechs=" + carrierTechs +
                '}';
    }
}
