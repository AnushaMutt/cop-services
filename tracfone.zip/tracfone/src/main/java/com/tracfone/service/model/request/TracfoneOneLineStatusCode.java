package com.tracfone.service.model.request;

import javax.validation.constraints.Size;

/**
 * x_rp_line_status
 *
 * @author Pritesh Singh
 */
public class TracfoneOneLineStatusCode {
    private String dbEnv;
    @Size(min = 1, message = "Line Status Code cannot be blank")
    @Size(max = 2, message = "Line Status Code cannot have more than 2 characters")
    private String lineStatusCode;
    @Size(min = 1, message = "Description cannot be blank")
    @Size(max = 20, message = "Description cannot have more than 20 characters")
    private String description;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getLineStatusCode() {
        return lineStatusCode;
    }

    public void setLineStatusCode(String lineStatusCode) {
        this.lineStatusCode = lineStatusCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "TracfoneOneLineStatusCode{" +
                "dbEnv='" + dbEnv + '\'' +
                ", lineStatusCode='" + lineStatusCode + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
