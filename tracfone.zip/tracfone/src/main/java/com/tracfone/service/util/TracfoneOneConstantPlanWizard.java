/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.util;

/**
 * This is a constant file that will be used for the rate plan wizard
 *
 * @author Shireen Fathima
 */
public interface TracfoneOneConstantPlanWizard {

    String BULK_INSERT_FAILED = "Bulk Insertion failed ";
    String CARRIERID = "CARRIER ID_";
    String BULK_INSERT_FAILED_FOR = "Bulk Insert Failed for ";
    String ERROR = "ERROR_";
    String INSERTION = "Going to insert this ";
    String BULK_CARRIERSIMPREF_INSERT = "Bulk Carrier sim pref Insert";
    String ANCILLARY_CODE = "ANCILLARY_CODE";
    String PROFILE_ID = "PROFILE_ID";
    String SEARCH_OBJECT = "What am I searching for? ";
    String PROFILE_DESC = "PROFILE_DESC";
    String OBJID = "OBJID";
    String MULTI_RATEPLAN_ESN_BULK_INSERT = "Bulk Multi Rate Plan ESN Insert";
    String SELECT_X_RP_PROFILE_TABLE = "select PROFILE_ID, PROFILE_DESC from sa.X_RP_PROFILE where ";
    String SELECT_SERVICE_PLAN = "select objid, mkt_name from sa.x_service_plan ";
    String BULK_PF_INSERT = "Bulk PF Insert";
    String BULK_VERIZON_ZIP_NPANXX_INSERT = "Bulk Verizon ZIP NPANXX Insert";
    String BULK_TMO_ZIP_NGP_INSERT = "Bulk TMO ZIP NGP Insert";
    String BULK_CINGULAR_MKT_INFO_INSERT = "Bulk Cingular Mrkt Info Insert";
    String BULK_NOT_CERTIFY_MODEL_INSERT = "Bulk Not Certify Model Insert";
    String UPPER_STATUS = "UPPER(X_STATUS) = ?";
    String PARENT_ID_VALUE = "X_PARENT_ID = ?";
    String X_PART_CLASS_OBJID_VALUE = "X_PART_CLASS_OBJID = ?";
    String OBJID_VALUE = "OBJID = ?";
    String FEATURE_NAME = "FEATURE_NAME";
    String FEATURE_REQUIREMENT = "FEATURE_REQUIREMENT";
    String DESCRIPTION = "DESCRIPTION";
    String FEATURE_VALUE = "FEATURE_VALUE";
    String BULK_NPANXX2CARRIERZONES_INSERT = "Bulk Npanxx 2 Carrierzones Insert";
    String BULK_AR_USA_POSTAL_ZIPS_INSERT = "Bulk AR USA Postal Zips Insert";
    String BULK_AR_USA_MARKET_INSERT = "Bulk AR_USA_MARKET Insert";
    String BULK_GEO_LOC_INSERT = "Bulk Geo Loc Insert";
    String BULK_CARRIERZONES_INSERT = "Bulk  Carrierzones Insert";
    String BULK_CARRIERPREF_INSERT = "Bulk  Carrierpref Insert";
    String BUCKET_ID = "BUCKET_ID";
    String BUCKET_TYPE = "BUCKET_TYPE";
    String ACTIVE_FLAG = "ACTIVE_FLAG";
    String BUCKET_GROUP = "BUCKET_GROUP";
    String BENEFIT_TYPE = "BENEFIT_TYPE";
    String CARRIER_ID_VALUE = "CARRIER_ID = ?";
    String COUNTY = "COUNTY";
    String ZONE_VALUE = "ZONE = ?";
    String CARRIER_ID_IS_NULL = "CARRIER_ID is null";
    String CARRIER_RANK_IS_NULL =  "CARRIER_RANK is null";
    String NEW_RANK_IS_NULL = "NEW_RANK is null";
    String CARRIER_NAME_IS_NULL = "CARRIER_NAME is null";
    String NEW_RANK_VALUE = "NEW_RANK = ?";
    String COUNTY_IS_NULL = "COUNTY is null";
    String ST_IS_NULL = "ST is null";
    String CARRIER_RANK_VALUE = "CARRIER_RANK = ?";
    String COUNTY_VALUE = "COUNTY = ?";
    String UPDATED = "Updated";
    String ST_VALUE = "ST = ?";
    String BTA_MKT_NAME_VALUE = "BTA_MKT_NAME = ?";
    String NXX_VALUE = "NXX = ?";
    String CARRIER_ID = "CARRIER_ID";
    String CARRIER_NAME_VALUE = "CARRIER_NAME = ?";
    String CONTROLLER_ERROR = "Controller error";
    String ERROR_VALUE = "ERROR";
    String X_RATE_PLAN = "X_RATE_PLAN";
    String X_FEATURE2X_CARRIER = "X_FEATURE2X_CARRIER";
    String X_DATA = "X_DATA";
    String PRIORITY = "PRIORITY";
    String X_FEATURES2BUS_ORG = "X_FEATURES2BUS_ORG";
    String EXCEPTION = " Exception ";
    String NUMBER_MAP_IS = "Number Map is ";


    // ERROR MESSAGES
    String TRACFONE_GET_SERVICE_PLAN_ERROR = "TFE1201";
    String TRACFONE_GET_SERVICE_PLAN_ERROR_MESSAGE = "Unable to get Service Plans for a Carrier";

    String TRACFONE_ADD_RATE_PLAN_ERROR = "TFE801";
    String TRACFONE_ADD_RATE_PLAN_ERROR_MESSAGE = "Unable to add a Rate Plan";

    String TRACFONE_VIEW_RATE_PLAN_ERROR = "TFE802";
    String TRACFONE_VIEW_RATE_PLAN_ERROR_MESSAGE = "Unable to retrieve a Rate Plan";

    String TRACFONE_UPDATE_RATE_PLAN_ERROR = "TFE803";
    String TRACFONE_UPDATE_RATE_PLAN_ERROR_MESSAGE = "Unable to update a Rate Plan";

    String TRACFONE_DELETE_RATE_PLAN_ERROR = "TFE804";
    String TRACFONE_DELETE_RATE_PLAN_ERROR_MESSAGE = "Unable to delete a Rate Plan";

    String TRACFONE_GET_ALL_BUS_ORGS_ERROR = "TFE807";
    String TRACFONE_GET_ALL_BUS_ORGS_ERROR_MESSAGE = "Unable to get all Business Organizations";

    String TRACFONE_DUPLICATE_RATE_PLAN_ERROR = "TFE812";
    String TRACFONE_DUPLICATE_RATE_PLAN_ERROR_MESSAGE = "Duplicate Rate Plan found";

    String TRACFONE_GET_MASTER_RATE_PLANS_ERROR = "TFE814";
    String TRACFONE_GET_MASTER_RATE_PLANS_ERROR_MESSAGE = "Unable to get Master Rate Plans";

    String TRACFONE_SEARCH_CARRIER_FEATURES_ERROR = "TFE819";
    String TRACFONE_SEARCH_CARRIER_FEATURES_ERROR_MESSAGE = "Unable to search for Carrier Features";

    String TRACFONE_GET_ALL_CARRIERS_ERROR = "TFE820";
    String TRACFONE_GET_ALL_CARRIERS_ERROR_MESSAGE = "Unable to get all Carriers";

    String TRACFONE_ADD_APN_ERROR = "TFE821";
    String TRACFONE_ADD_APN_ERROR_MESSAGE = "Unable to add an APN";

    String TRACFONE_UPDATE_APN_ERROR = "TFE822";
    String TRACFONE_UPDATE_APN_ERROR_MESSAGE = "Unable to update an APN";

    String TRACFONE_DELETE_APN_ERROR = "TFE823";
    String TRACFONE_DELETE_APN_ERROR_MESSAGE = "Unable to delete an APN";

    String TRACFONE_GET_ALL_PARENT_NAMES_ERROR = "TFE824";
    String TRACFONE_GET_ALL_PARENT_NAMES_ERROR_MESSAGE = "Unable to get all Parent Names";

    String TRACFONE_SEARCH_UNLINKED_RP_ERROR = "TFE825";
    String TRACFONE_SEARCH_UNLINKED_RP_ERROR_MESSAGE = "Unable to search for unlinked Rate Plans";

    String TRACFONE_GET_RATEPLAN_APNS_ERROR = "TFE826";
    String TRACFONE_GET_RATEPLAN_APNS_ERROR_MESSAGE = "Unable to get Rate Plan APNs";

    String TRACFONE_DUPLICATE_APN_ERROR = "TFE827";
    String TRACFONE_DUPLICATE_APN_ERROR_MESSAGE = "Duplicate APN found";

    String TRACFONE_UPDATE_CF_ERROR = "TFE828";
    String TRACFONE_UPDATE_CF_ERROR_MESSAGE = "Unable to update a Carrier Feature";

    String TRACFONE_INSERT_RP_ASSOCIATION_ERROR = "TFE829";
    String TRACFONE_INSERT_RP_ASSOCIATION_ERROR_MESSAGE = "Unable to insert a Rate Plan Association";

    String TRACFONE_GET_CF_LINKS_ERROR = "TFE830";
    String TRACFONE_GET_CF_LINKS_ERROR_MESSAGE = "Unable to get RP Extension Links associated with Carrier Feature";

    String TRACFONE_GET_CARRIER_IDS_ERROR = "TFE831";
    String TRACFONE_GET_CARRIER_IDS_ERROR_MESSAGE = "Unable to get Carrier Ids for Carrier and Parent";

    String TRACFONE_GET_CARRIER_FEATURES_ERROR = "TFE832";
    String TRACFONE_GET_CARRIER_FEATURES_ERROR_MESSAGE = "Unable to get Carrier Features for a Service Plan";

    String TRACFONE_SEARCH_SERVICE_PLANS_ERROR = "TFE833";
    String TRACFONE_SEARCH_SERVICE_PLANS_ERROR_MESSAGE = "Unable to search for Service Plans";

    String TRACFONE_GET_CF_RATE_PLANS_ERROR = "TFE834";
    String TRACFONE_GET_CF_RATE_PLANS_ERROR_MESSAGE = "Unable to get all Rate Plans for Carrier Feature Search";

    String TRACFONE_DUPLICATE_CARRIER_FEATURE_ERROR = "TFE835";
    String TRACFONE_DUPLICATE_CARRIER_FEATURE_ERROR_MESSAGE = "Duplicate Carrier Feature found";

    String TRACFONE_ADD_PROFILE_ERROR = "TFE901";
    String TRACFONE_ADD_PROFILE_ERROR_MESSAGE = "Unable to add a Rate Plan Profile";

    String TRACFONE_VIEW_PROFILE_ERROR = "TFE902";
    String TRACFONE_VIEW_PROFILE_ERROR_MESSAGE = "Unable to retrieve a Rate Plan Profile";

    String TRACFONE_UPDATE_PROFILE_ERROR = "TFE903";
    String TRACFONE_UPDATE_PROFILE_ERROR_MESSAGE = "Unable to update a Rate Plan Profile";

    String TRACFONE_DELETE_PROFILE_ERROR = "TFE904";
    String TRACFONE_DELETE_PROFILE_ERROR_MESSAGE = "Unable to delete a Rate Plan Profile";

    String TRACFONE_ADD_PROFILE_EXTENSION_LINK_ERROR = "TFE905";
    String TRACFONE_ADD_PROFILE_EXTENSION_LINK_ERROR_MESSAGE = "Unable to add Rate Plan Extension Links";

    String TRACFONE_VIEW_ALL_ANCILLARY_CODES_ERROR = "TFE907";
    String TRACFONE_VIEW_ALL_ANCILLARY_CODES_ERROR_MESSAGE = "Unable to view all Ancillary Codes";

    String TRACFONE_DUPLICATE_PROFILE_ERROR = "TFE908";
    String TRACFONE_DUPLICATE_PROFILE_ERROR_MESSAGE = "Duplicate Rate Plan Profile found";

    String TRACFONE_VIEW_ALL_CHILD_PLANS_ERROR = "TFE909";
    String TRACFONE_VIEW_ALL_CHILD_PLANS_ERROR_MESSAGE = "Unable to view all Child Plans";

    String TRACFONE_SEARCH_PROFILE_ERROR = "TFE914";
    String TRACFONE_SEARCH_PROFILE_ERROR_MESSAGE = "Unable to filter Rate Plan Profiles";

    String TRACFONE_SEARCH_PROFILE_FOR_UPDATE_ERROR = "TFE915";
    String TRACFONE_SEARCH_PROFILE_FOR_UPDATE_ERROR_MESSAGE = "Unable to search for Rate Plan Profiles for update";

    String TRACFONE_INSERT_CHILD_PLAN_ERROR = "TFE916";
    String TRACFONE_INSERT_CHILD_PLAN_ERROR_MESSAGE = "Unable to insert Child Plan";

    String TRACFONE_UPDATE_CHILD_PLAN_ERROR = "TFE917";
    String TRACFONE_UPDATE_CHILD_PLAN_ERROR_MESSAGE = "Unable to update Child Plan";

    String TRACFONE_DELETE_CHILD_PLAN_ERROR = "TFE918";
    String TRACFONE_DELETE_CHILD_PLAN_ERROR_MESSAGE = "Unable to delete Child Plan";

    String TRACFONE_DUPLICATE_CHILD_PLAN_ERROR = "TFE919";
    String TRACFONE_DUPLICATE_CHILD_PLAN_ERROR_MESSAGE = "Duplicate Child Plan found";

    String TRACFONE_CHILD_PLAN_DEPENDENCY_ERROR = "TFE920";
    String TRACFONE_CHILD_PLAN_DEPENDENCY_ERROR_MESSAGE = "This Child Plan cannot be deleted since it has dependencies";

    String TRACFONE_DELETE_ANCILLARY_CODE_ERROR = "TFE921";
    String TRACFONE_DELETE_ANCILLARY_CODE_ERROR_MESSAGE = "Unable to delete Ancillary Code";

    String TRACFONE_ANCILLARY_CODE_DEPENDENCY_ERROR = "TFE922";
    String TRACFONE_ANCILLARY_CODE_DEPENDENCY_ERROR_MESSAGE = "This Code cannot be deleted since it has dependencies in RP Extensions";

    String TRACFONE_ADD_ANCILLARY_CODE_ERROR = "TFE923";
    String TRACFONE_ADD_ANCILLARY_CODE_ERROR_MESSAGE = "Unable to add Ancillary Code";

    String TRACFONE_DUPLICATE_ANCILLARY_CODE_ERROR = "TFE924";
    String TRACFONE_DUPLICATE_ANCILLARY_CODE_ERROR_MESSAGE = "Duplicate Ancillary Code found";

    String TRACFONE_SEARCH_ANCILLARY_CODE_ERROR = "TFE925";
    String TRACFONE_SEARCH_ANCILLARY_CODE_ERROR_MESSAGE = "Unable to search Ancillary Codes";

    String TRACFONE_DELETE_RP_EXTENSION_ERROR = "TFE926";
    String TRACFONE_DELETE_RP_EXTENSION_ERROR_MESSAGE = "Unable to delete RP Extension";

    String TRACFONE_RP_EXTENSION_DEPENDENCY_ERROR = "TFE927";
    String TRACFONE_RP_EXTENSION_DEPENDENCY_ERROR_MESSAGE = "This RP Extension cannot be deleted since it has dependencies";

    String TRACFONE_ADD_RP_EXTENSION_ERROR = "TFE928";
    String TRACFONE_ADD_RP_EXTENSION_ERROR_MESSAGE = "Unable to add RP Extension";

    String TRACFONE_DUPLICATE_RP_EXTENSION_ERROR = "TFE929";
    String TRACFONE_DUPLICATE_RP_EXTENSION_ERROR_MESSAGE = "Duplicate RP Extension found";

    String TRACFONE_SEARCH_RP_EXTENSION_ERROR = "TFE930";
    String TRACFONE_SEARCH_RP_EXTENSION_ERROR_MESSAGE = "Unable to search RP Extensions";

    String TRACFONE_DELETE_RP_EXTENSION_LINK_ERROR = "TFE931";
    String TRACFONE_DELETE_RP_EXTENSION_LINK_ERROR_MESSAGE = "Unable to delete RP Extension Link";

    String TRACFONE_UPDATE_RP_EXTENSION_LINK_ERROR = "TFE932";
    String TRACFONE_UPDATE_RP_EXTENSION_LINK_ERROR_MESSAGE = "Unable to update RP Extension Link";

    String TRACFONE_VIEW_ALL_LINE_STATUS_CODES_ERROR = "TFE933";
    String TRACFONE_VIEW_ALL_LINE_STATUS_CODES_ERROR_MESSAGE = "Unable to get all Line Status Codes";

    String TRACFONE_VIEW_ALL_THROTTLE_STATUS_CODES_ERROR = "TFE934";
    String TRACFONE_VIEW_ALL_THROTTLE_STATUS_CODES_ERROR_MESSAGE = "Unable to get all Throttle Status Codes";

    String TRACFONE_UPDATE_ANCILLARY_DESC_ERROR = "TFE935";
    String TRACFONE_UPDATE_ANCILLARY_DESC_ERROR_MESSAGE = "Unable to update Ancillary Code Description";

    String TRACFONE_ADD_LINE_STATUS_CODE_ERROR = "TFE936";
    String TRACFONE_ADD_LINE_STATUS_CODE_ERROR_MESSAGE = "Unable to add a Line Status Code";

    String TRACFONE_UPDATE_LINE_STATUS_CODE_ERROR = "TFE937";
    String TRACFONE_UPDATE_LINE_STATUS_CODE_ERROR_MESSAGE = "Unable to update Line Status Code";

    String TRACFONE_ADD_THROTTLE_STATUS_CODE_ERROR = "TFE938";
    String TRACFONE_ADD_THROTTLE_STATUS_CODE_ERROR_MESSAGE = "Unable to add a Throttle Status Code";

    String TRACFONE_UPDATE_THROTTLE_STATUS_CODE_ERROR = "TFE939";
    String TRACFONE_UPDATE_THROTTLE_STATUS_CODE_ERROR_MESSAGE = "Unable to update Throttle Status Code";

    String TRACFONE_ADD_FEATURE_REQUIREMENT_ERROR = "TFE940";
    String TRACFONE_ADD_FEATURE_REQUIREMENT_ERROR_MESSAGE = "Unable to add a Feature Requirement";

    String TRACFONE_UPDATE_FEATURE_REQUIREMENT_ERROR = "TFE941";
    String TRACFONE_UPDATE_FEATURE_REQUIREMENT_ERROR_MESSAGE = "Unable to update Feature Requirement";

    String TRACFONE_DELETE_THROTTLE_STATUS_CODE_ERROR = "TFE942";
    String TRACFONE_DELETE_THROTTLE_STATUS_CODE_ERROR_MESSAGE = "Unable to delete Throttle Status Code";

    String TRACFONE_DELETE_FEATURE_REQUIREMENT_ERROR = "TFE943";
    String TRACFONE_DELETE_FEATURE_REQUIREMENT_ERROR_MESSAGE = "Unable to delete Feature Requirement";

    String TRACFONE_DELETE_LINE_STATUS_CODE_ERROR = "TFE944";
    String TRACFONE_DELETE_LINE_STATUS_CODE_ERROR_MESSAGE = "Unable to delete Line Status Code";

    String TRACFONE_VIEW_FEATURE_REQUIREMENT_ERROR = "TFE945";
    String TRACFONE_VIEW_FEATURE_REQUIREMENT_ERROR_MESSAGE = "Unable to view all Feature Requirements";

    String TRACFONE_FEATURE_REQUIREMENT_DEPENDENCY_ERROR = "TFE946";
    String TRACFONE_FEATURE_REQUIREMENT_DEPENDENCY_ERROR_MESSAGE = "This Feature Requirement cannot be deleted since it has dependencies";

    String TRACFONE_GET_ALL_MASTER_FEATURE_ERROR = "TFE1005";
    String TRACFONE_GET_ALL_MASTER_FEATURE_ERROR_MESSAGE = " Unable to retrieve all Master Features";

    String TRACFONE_INSERT_RP_EXTENSION_CONFIG_ERROR = "TFE1006";
    String TRACFONE_INSERT_RP_EXTENSION_CONFIG_ERROR_MESSAGE = "Unable to add RP Extension Config";

    String TRACFONE_DUPLICATE_RP_EXTENSION_CONFIG_ERROR = "TFE1007";
    String TRACFONE_DUPLICATE_RP_EXTENSION_CONFIG_ERROR_MESSAGE = "Duplicate RP Extension Config with same Feature Value Found - ";

    String TRACFONE_GET_PROFILE_FEATURE_ERROR = "TFE1008";
    String TRACFONE_GET_PROFILE_FEATURE_ERROR_MESSAGE = "Unable to retrieve Features for a Profile";

    String TRACFONE_UPDATE_RP_EXTENSION_CONFIG_ERROR = "TFE1010";
    String TRACFONE_UPDATE_RP_EXTENSION_CONFIG_ERROR_MESSAGE = "Unable to update RP Extension Config";

    String TRACFONE_DELETE_RP_EXTENSION_CONFIG_ERROR = "TFE1011";
    String TRACFONE_DELETE_RP_EXTENSION_CONFIG_ERROR_MESSAGE = "Unable to delete RP Extension Config";

    String TRACFONE_INSERT_MASTER_FEATURE_ERROR = "TFE1012";
    String TRACFONE_INSERT_MASTER_FEATURE_ERROR_MESSAGE = "Unable to insert Master Feature";

    String TRACFONE_FEATURE_FILE_UPLOAD_ERROR = "TFE1013";
    String TRACFONE_FEATURE_FILE_UPLOAD_ERROR_MESSAGE = "Unable to upload profile features using file upload";

    String TRACFONE_GET_PROFILE_SERVICE_PLANS_ERROR = "TFE1014";
    String TRACFONE_GET_PROFILE_SERVICE_PLANS_ERROR_MESSAGE = "Unable to retrieve Service Plans for the Profile";

    String TRACFONE_GET_RP_SERVICE_PLANS_ERROR = "TFE1015";
    String TRACFONE_GET_RP_SERVICE_PLANS_ERROR_MESSAGE = "Unable to retrieve Service Plans for the Rate Plan";

    String TRACFONE_GET_ALL_SERVICE_PLAN_CARRIERS_ERROR = "TFE1016";
    String TRACFONE_GET_ALL_SERVICE_PLAN_CARRIERS_ERROR_MESSAGE = "Unable to get all Carriers for this Service Plan";

    String TRACFONE_ADD_ANCILLARY_CODE_CONFIG_ERROR = "TFE1017";
    String TRACFONE_ADD_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE = "Unable to add an Ancillary Code Config";

    String TRACFONE_UPDATE_ANCILLARY_CODE_CONFIG_ERROR = "TFE1018";
    String TRACFONE_UPDATE_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE = "Unable to update an Ancillary Code Config";

    String TRACFONE_DELETE_ANCILLARY_CODE_CONFIG_ERROR = "TFE1019";
    String TRACFONE_DELETE_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE = "Unable to delete an Ancillary Code Config";

    String TRACFONE_GET_ANCILLARY_CODE_CONFIG_ERROR = "TFE1020";
    String TRACFONE_GET_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE = "Unable to get Ancillary Code Config";

    String TRACFONE_ADD_ANCILLARY_CODE_DISCOUNT_ERROR = "TFE1021";
    String TRACFONE_ADD_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE = "Unable to add an Ancillary Code Discount";

    String TRACFONE_DELETE_ANCILLARY_CODE_DISCOUNT_ERROR = "TFE1022";
    String TRACFONE_DELETE_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE = "Unable to delete an Ancillary Code Discount";

    String TRACFONE_UPDATE_ANCILLARY_CODE_DISCOUNT_ERROR = "TFE1023";
    String TRACFONE_UPDATE_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE = "Unable to update an Ancillary Code Discount";

    String TRACFONE_SEARCH_ANCILLARY_CODE_DISCOUNT_ERROR = "TFE1024";
    String TRACFONE_SEARCH_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE = "Unable to search Ancillary Code Discount";

    String TRACFONE_DUPLICATE_CODE_CONFIG_ERROR = "TFE1024";
    String TRACFONE_DUPLICATE_CODE_CONFIG_ERROR_MESSAGE = "Duplicate Ancillary Code Config with same Feature Value Found - ";

    String TRACFONE_SEARCH_PROFILE_FEATURES_ERROR = "TFE1025";
    String TRACFONE_SEARCH_PROFILE_FEATURES_ERROR_MESSAGE = "Unable to Search for Profile Features";

    String TRACFONE_VIEW_FEATURE_VALUE_ERROR = "TFE1026";
    String TRACFONE_VIEW_FEATURE_VALUE_ERROR_MESSAGE = "Unable to get all Feature Values";

    String TRACFONE_BULK_UPDATE_PROFILE_FEATURES_CODE_ERROR = "TFE1027";
    String TRACFONE_BULK_UPDATE_PROFILE_FEATURES_ERROR_MESSAGE = "Unable to bulk update Profile Features";

    String TRACFONE_VIEW_BUCKET_ERROR = "TFE1102";
    String TRACFONE_VIEW_BUCKET_ERROR_MESSAGE = "Unable to retrieve a Bucket";

    String TRACFONE_GET_BUCKETS_ERROR = "TFE1105";
    String TRACFONE_GET_BUCKETS_ERROR_MESSAGE = "Unable to get all Bucket Lists";

    String TRACFONE_ADD_IG_BUCKET_ERROR = "TFE1106";
    String TRACFONE_ADD_IG_BUCKET_ERROR_MESSAGE = "Unable to add an IG Bucket";

    String TRACFONE_UPDATE_IG_BUCKET_ERROR = "TFE1109";
    String TRACFONE_UPDATE_IG_BUCKET_ERROR_MESSAGE = "Unable to update an IG Bucket";

    String TRACFONE_UPDATE_CP_BUCKET_ERROR = "TFE1110";
    String TRACFONE_UPDATE_CP_BUCKET_ERROR_MESSAGE = "Unable to update a Carrier Profile Bucket";

    String TRACFONE_UPDATE_CP_BUCKET_TIER_ERROR = "TFE1111";
    String TRACFONE_UPDATE_CP_BUCKET_TIER_ERROR_MESSAGE = "Unable to update a Carrier Profile Bucket tier";

    String TRACFONE_SEARCH_IG_BUCKETS_ERROR = "TFE1112";
    String TRACFONE_SEARCH_IG_BUCKETS_ERROR_MESSAGE = "Unable to search for IG Buckets";

    String TRACFONE_SEARCH_CP_BUCKETS_ERROR = "TFE1113";
    String TRACFONE_SEARCH_CP_BUCKETS_ERROR_MESSAGE = "Unable to search for Carrier Profile Buckets";

    String TRACFONE_DELETE_IG_BUCKET_ERROR = "TFE1114";
    String TRACFONE_DELETE_IG_BUCKET_ERROR_MESSAGE = "Unable to delete IG Bucket";

    String TRACFONE_DELETE_CP_BUCKET_ERROR = "TFE1115";
    String TRACFONE_DELETE_CP_BUCKET_ERROR_MESSAGE = "Unable to delete Carrier Profile Bucket";

    String TRACFONE_DELETE_CP_BUCKET_TIER_ERROR = "TFE1116";
    String TRACFONE_DELETE_CP_BUCKET_TIER_ERROR_MESSAGE = "Unable to delete Carrier Profile Bucket tier";

    String TRACFONE_DUPLICATE_IG_BUCKET_ERROR = "TFE1117";
    String TRACFONE_DUPLICATE_IG_BUCKET_ERROR_MESSAGE = "Duplicate IG Bucket found";

    String TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR = "TFE1118";
    String TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR_MESSAGE = "Unable to search for Carrier Profile Child Buckets";

    String TRACFONE_UPDATE_CP_CHILD_BUCKET_ERROR = "TFE1119";
    String TRACFONE_UPDATE_CP_CHILD_BUCKET_ERROR_MESSAGE = "Unable to update a carrier profile child bucket";

    String TRACFONE_DELETE_CP_CHILD_BUCKET_ERROR = "TFE1120";
    String TRACFONE_DELETE_CP_CHILD_BUCKET_ERROR_MESSAGE = "Unable to delete carrier profile child bucket";

    String TRACFONE_ADD_CP_CHILD_BUCKET_ERROR = "TFE1121";
    String TRACFONE_ADD_CP_CHILD_BUCKET_ERROR_MESSAGE = "Unable to add a carrier profile child bucket";

    String TRACFONE_ADD_CP_BUCKET_ERROR = "TFE1122";
    String TRACFONE_ADD_CP_BUCKET_ERROR_MESSAGE = "Unable to add a carrier profile bucket";

    String TRACFONE_UPDATE_CP_CHILD_BUCKET_TIER_ERROR = "TFE1123";
    String TRACFONE_UPDATE_CP_CHILD_BUCKET_TIER_ERROR_MESSAGE = "Unable to update a Carrier Profile Child Bucket tier";

    String TRACFONE_DELETE_CP_CHILD_BUCKET_TIER_ERROR = "TFE1124";
    String TRACFONE_DELETE_CP_CHILD_BUCKET_TIER_ERROR_MESSAGE = "Unable to delete a Carrier Profile Child Bucket tier";

    String TRACFONE_COPY_BUCKETS_ERROR = "TFE1125";
    String TRACFONE_COPY_BUCKETS_ERROR_MESSAGE = "Unable to copy Buckets and Child Buckets from one profile to another";

    String TRACFONE_UPDATE_PROFILE_ON_BUCKETS_ERROR = "TFE1126";
    String TRACFONE_UPDATE_PROFILE_ON_BUCKETS_ERROR_MESSAGE = "Unable to update Buckets and Child Buckets to another profile";

    String TRACFONE_DELETE_ALL_BUCKETS_ERROR = "TFE1127";
    String TRACFONE_DELETE_ALL_BUCKETS_ERROR_MESSAGE = "Unable to delete all Buckets and Child Buckets";

    String TRACFONE_MIRROR_SERVICE_PLAN_ERROR = "TFE1201";
    String TRACFONE_MIRROR_SERVICE_PLAN_ERROR_MESSAGE = "Unable to copy Service Plan";

    String TRACFONE_ADD_BUCKET_LIST_ERROR = "TFE1202";
    String TRACFONE_ADD_BUCKET_LIST_ERROR_MESSAGE = "Unable to add a Bucket List";

    String TRACFONE_UPDATE_BUCKET_LIST_ERROR = "TFE1203";
    String TRACFONE_UPDATE_BUCKET_LIST_ERROR_MESSAGE = "Unable to update a Bucket List";

    String TRACFONE_SEARCH_BUCKET_LIST_ERROR = "TFE1204";
    String TRACFONE_SEARCH_BUCKET_LIST_ERROR_MESSAGE = "Unable to search for Bucket Lists";

    String TRACFONE_DELETE_BUCKET_LIST_ERROR = "TFE1205";
    String TRACFONE_DELETE_BUCKET_LIST_ERROR_MESSAGE = "Unable to delete a Bucket List";

    String TRACFONE_ADD_MULTI_RATE_PLAN_ESNS_ERROR = "TFE1206";
    String TRACFONE_ADD_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE = "Unable to add a Multi Rate Plan Esn";

    String TRACFONE_UPDATE_MULTI_RATE_PLAN_ESNS_ERROR = "TFE1207";
    String TRACFONE_UPDATE_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE = "Unable to update a Multi Rate Plan Esn";

    String TRACFONE_DELETE_MULTI_RATE_PLAN_ESNS_ERROR = "TFE1208";
    String TRACFONE_DELETE_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE = "Unable to delete a Multi Rate Plan Esn";

    String TRACFONE_SEARCH_MULTI_RATE_PLAN_ESNS_ERROR = "TFE1209";
    String TRACFONE_SEARCH_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE = "Unable to search Multi Rate Plan Esns";

    String TRACFONE_DUPLICATE_BUCKET_ID_ERROR = "TFE1210";
    String TRACFONE_DUPLICATE_BUCKET_ID_ERROR_MESSAGE = "Duplicate Bucket Id found";

    String TRACFONE_GET_CARRIER_GROUP_ERROR = "TFE1300";
    String TRACFONE_GET_CARRIER_GROUP_ERROR_MESSAGE = "Unable to search for Carrier Groups";

    String TRACFONE_GET_ORDER_TYPES_ERROR = "TFE1301";
    String TRACFONE_GET_ORDER_TYPES_ERROR_MESSAGE = "Unable to get Order Types for this Carrier";

    String TRACFONE_SEARCH_PARENT_ERROR = "TFE1302";
    String TRACFONE_SEARCH_PARENT_ERROR_MESSAGE = "Unable to Search for Parents";

    String TRACFONE_SEARCH_CARRIER_ERROR = "TFE1303";
    String TRACFONE_SEARCH_CARRIER_ERROR_MESSAGE = "Unable to Search for Carriers";

    String TRACFONE_SEARCH_DATA_CONFIG_MAPPING_ERROR = "TFE1304";
    String TRACFONE_SEARCH_DATA_CONFIG_MAPPING_ERROR_MESSAGE = "Unable to Search for Data Config Mappings";

    String TRACFONE_ADD_DATA_CONFIG_MAPPING_ERROR = "TFE1305";
    String TRACFONE_ADD_DATA_CONFIG_MAPPING_ERROR_MESSAGE = "Unable to add a Data Config Mapping";

    String TRACFONE_DUPLICATE_DATA_CONFIG_MAPPING_ERROR = "TFE1306";
    String TRACFONE_DUPLICATE_DATA_CONFIG_MAPPING_ERROR_MESSAGE = "Duplicate Data Config Mapping found";

    String TRACFONE_DELETE_DATA_CONFIG_MAPPING_ERROR = "TFE1307";
    String TRACFONE_DELETE_DATA_CONFIG_MAPPING_ERROR_MESSAGE = "Unable to delete a Data Config Mapping";

    String TRACFONE_UPDATE_DATA_CONFIG_MAPPING_ERROR = "TFE1308";
    String TRACFONE_UPDATE_DATA_CONFIG_MAPPING_ERROR_MESSAGE = "Unable to update a Data Config Mapping";

    String TRACFONE_UPDATE_PARENT_ERROR = "TFE1309";
    String TRACFONE_UPDATE_PARENT_ERROR_MESSAGE = "Unable to update Parent";

    String TRACFONE_UPDATE_CARRIER_GROUP_ERROR = "TFE1310";
    String TRACFONE_UPDATE_CARRIER_GROUP_ERROR_MESSAGE = "Unable to update Carrier Group";

    String TRACFONE_UPDATE_CARRIER_ERROR = "TFE1311";
    String TRACFONE_UPDATE_CARRIER_ERROR_MESSAGE = "Unable to update Carrier";

    String TRACFONE_UPDATE_CARRIER_RULE_ERROR = "TFE1312";
    String TRACFONE_UPDATE_CARRIER_RULE_ERROR_MESSAGE = "Unable to update Carrier Rule";

    String TRACFONE_UPDATE_ORDER_TYPE_ERROR = "TFE1313";
    String TRACFONE_UPDATE_ORDER_TYPE_ERROR_MESSAGE = "Unable to update Order Type";

    String TRACFONE_INSERT_PARENT_ERROR = "TFE1314";
    String TRACFONE_INSERT_PARENT_ERROR_MESSAGE = "Unable to add Parent";

    String TRACFONE_INSERT_CARRIER_GROUP_ERROR = "TFE1315";
    String TRACFONE_INSERT_CARRIER_GROUP_ERROR_MESSAGE = "Unable to add Carrier Groups";

    String TRACFONE_INSERT_CARRIER_ERROR = "TFE1316";
    String TRACFONE_INSERT_CARRIER_ERROR_MESSAGE = "Unable to add Carriers";

    String TRACFONE_INSERT_CARRIER_RULE_ERROR = "TFE1317";
    String TRACFONE_INSERT_CARRIER_RULE_ERROR_MESSAGE = "Unable to add Carrier Rule";

    String TRACFONE_INSERT_ORDER_TYPE_ERROR = "TFE1318";
    String TRACFONE_INSERT_ORDER_TYPE_ERROR_MESSAGE = "Unable to add Order Type";

    String TRACFONE_DUPLICATE_CARRIER_GROUP_ID_ERROR = "TFE1319";
    String TRACFONE_DUPLICATE_CARRIER_GROUP_ID_ERROR_MESSAGE = "Duplicate Carrier Group Ids found - ";

    String TRACFONE_DUPLICATE_CARRIER_ID_ERROR = "TFE1320";
    String TRACFONE_DUPLICATE_CARRIER_ID_ERROR_MESSAGE = "Duplicate Carrier Ids found - ";

    String TRACFONE_SEARCH_CARRIER_RULE_ERROR = "TFE1321";
    String TRACFONE_SEARCH_CARRIER_RULE_ERROR_MESSAGE = "Unable to Search Carrier Rules";

    String TRACFONE_GET_ALL_PART_CLASS_ERROR = "TFE1322";
    String TRACFONE_GET_ALL_PART_CLASS_ERROR_MESSAGE = "Unable to get Part Class Obj Id";

    String TRACFONE_SEARCH_DATA_CONFIG_ERROR = "TFE1323";
    String TRACFONE_SEARCH_DATA_CONFIG_ERROR_MESSAGE = "Unable to get Data Config";

    String TRACFONE_DELETE_ORDER_TYPE_ERROR = "TFE1324";
    String TRACFONE_DELETE_ORDER_TYPE_ERROR_MESSAGE = "Unable to delete Order Type";

    String TRACFONE_INSERT_IG_ORDER_TYPES_ERROR = "TFE1325";
    String TRACFONE_INSERT_IG_ORDER_TYPES_ERROR_MESSAGE = "Unable to add IG Order Types";

    String TRACFONE_DUPLICATE_IG_ORDER_TYPES_ERROR = "TFE1326";
    String TRACFONE_DUPLICATE_IG_ORDER_TYPES_ERROR_MESSAGE = "Duplicate IG Order Type found";

    String TRACFONE_UPDATE_IG_ORDER_TYPES_ERROR = "TFE1327";
    String TRACFONE_UPDATE_IG_ORDER_TYPES_ERROR_MESSAGE = "Unable to update an IG Order Type";

    String TRACFONE_SEARCH_IG_ORDER_TYPES_ERROR = "TFE1328";
    String TRACFONE_SEARCH_IG_ORDER_TYPES_ERROR_MESSAGE = "Unable to Search for IG Order Types";

    String TRACFONE_INSERT_THROTTLE_POLICY_ERROR = "TFE1329";
    String TRACFONE_INSERT_THROTTLE_POLICY_ERROR_MESSAGE = "Unable to add Throttle Policy";

    String TRACFONE_DUPLICATE_THROTTLE_POLICY_ERROR = "TFE1330";
    String TRACFONE_DUPLICATE_THROTTLE_POLICY_ERROR_MESSAGE = "Duplicate Throttle Policy found";

    String TRACFONE_INSERT_THROTTLE_RULE_ERROR = "TFE1331";
    String TRACFONE_INSERT_THROTTLE_RULE_ERROR_MESSAGE = "Unable to add Throttle Rule";

    String TRACFONE_DUPLICATE_THROTTLE_RULE_ERROR = "TFE1332";
    String TRACFONE_DUPLICATE_THROTTLE_RULE_ERROR_MESSAGE = "Duplicate Throttle Rule found";

    String TRACFONE_INSERT_THROTTLE_FEATURE_ERROR = "TFE1333";
    String TRACFONE_INSERT_THROTTLE_FEATURE_ERROR_MESSAGE = "Unable to add Throttle Feature";

    String TRACFONE_DUPLICATE_THROTTLE_FEATURE_ERROR = "TFE1334";
    String TRACFONE_DUPLICATE_THROTTLE_FEATURE_ERROR_MESSAGE = "Duplicate Throttle Feature found";

    String TRACFONE_SEARCH_THROTTLE_POLICY_ERROR = "TFE1335";
    String TRACFONE_SEARCH_THROTTLE_POLICY_ERROR_MESSAGE = "Unable to Search for Throttle Policy";

    String TRACFONE_SEARCH_THROTTLE_RULE_ERROR = "TFE1336";
    String TRACFONE_SEARCH_THROTTLE_RULE_ERROR_MESSAGE = "Unable to Search for Throttle Rule";

    String TRACFONE_SEARCH_THROTTLE_FEATURES_ERROR = "TFE1337";
    String TRACFONE_SEARCH_THROTTLE_FEATURES_ERROR_MESSAGE = "Unable to Search for Throttle Feature";

    String TRACFONE_UPDATE_THROTTLE_POLICY_ERROR = "TFE1338";
    String TRACFONE_UPDATE_THROTTLE_POLICY_ERROR_MESSAGE = "Unable to update Throttle Policy";

    String TRACFONE_UPDATE_THROTTLE_RULE_ERROR = "TFE1339";
    String TRACFONE_UPDATE_THROTTLE_RULE_ERROR_MESSAGE = "Unable to update Throttle Rule";

    String TRACFONE_UPDATE_THROTTLE_FEATURES_ERROR = "TFE1340";
    String TRACFONE_UPDATE_THROTTLE_FEATURES_ERROR_MESSAGE = "Unable to update Throttle Feature";

    String TRACFONE_SEARCH_VERIZON_ZIP_NPANXX_ERROR = "TFE1341";
    String TRACFONE_SEARCH_VERIZON_ZIP_NPANXX_ERROR_MESSAGE = "Unable to Search for Verizon ZIP NPANXX";

    String TRACFONE_UPDATE_VERIZON_ZIP_NPANXX_ERROR = "TFE1342";
    String TRACFONE_UPDATE_VERIZON_ZIP_NPANXX_ERROR_MESSAGE = "Unable to update Verizon ZIP NPANXX";

    String TRACFONE_ADD_VERIZON_ZIP_NPANXX_ERROR = "TFE1343";
    String TRACFONE_ADD_VERIZON_ZIP_NPANXX_ERROR_MESSAGE = "Unable to add a Verizon ZIP NPANXX";

    String TRACFONE_DELETE_VERIZON_ZIP_NPANXX_ERROR = "TFE1344";
    String TRACFONE_DELETE_VERIZON_ZIP_NPANXX_ERROR_MESSAGE = "Unable to delete a Verizon ZIP NPANXX";

    String TRACFONE_DUPLICATE_VERIZON_ZIP_NPANXX_ERROR = "TFE1345";
    String TRACFONE_DUPLICATE_VERIZON_ZIP_NPANXX_ERROR_MESSAGE = "Duplicate Verizon ZIP NPANXX found";

    String TRACFONE_SEARCH_TMO_ZIP_NGP_ERROR = "TFE1346";
    String TRACFONE_SEARCH_TMO_ZIP_NGP_ERROR_MESSAGE = "Unable to search for TMO ZIP NGP";

    String TRACFONE_ADD_TMO_ZIP_NGP_ERROR = "TFE1347";
    String TRACFONE_ADD_TMO_ZIP_NGP_ERROR_MESSAGE = "Unable to add TMO ZIP NGP";

    String TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR = "TFE1348";
    String TRACFONE_UPDATE_TMO_ZIP_NGP_ERROR_MESSAGE = "Unable to update TMO ZIP NGP";

    String TRACFONE_DELETE_TMO_ZIP_NGP_ERROR = "TFE1349";
    String TRACFONE_DELETE_TMO_ZIP_NGP_ERROR_MESSAGE = "Unable to delete TMO ZIP NGP";

    String TRACFONE_DUPLICATE_TMO_ZIP_NGP_ERROR = "TFE1350";
    String TRACFONE_DUPLICATE_TMO_ZIP_NGP_ERROR_MESSAGE = "Duplicate TMO ZIP NGP found";

    String TRACFONE_SEARCH_CINGULAR_MRKT_INFO_ERROR = "TFE1351";
    String TRACFONE_SEARCH_CINGULAR_MRKT_INFO_ERROR_MESSAGE = "Unable to search for Cingulat Mrkt Info";

    String TRACFONE_ADD_CINGULAR_MRKT_INFO_ERROR = "TFE1352";
    String TRACFONE_ADD_CINGULAR_MRKT_INFO_ERROR_MESSAGE = "Unable to add Cingulat Mrkt Info";

    String TRACFONE_UPDATE_CINGULAR_MRKT_INFO_ERROR = "TFE1353";
    String TRACFONE_UPDATE_CINGULAR_MRKT_INFO_ERROR_MESSAGE = "Unable to update Cingulat Mrkt Info";

    String TRACFONE_DELETE_CINGULAR_MRKT_INFO_ERROR = "TFE1354";
    String TRACFONE_DELETE_CINGULAR_MRKT_INFO_ERROR_MESSAGE = "Unable to delete Cingulat Mrkt Info";

    String TRACFONE_DUPLICATE_CINGULAR_MRKT_INFO_ERROR = "TFE1355";
    String TRACFONE_DUPLICATE_CINGULAR_MRKT_INFO_ERROR_MESSAGE = "Duplicate Cingulat Mrkt Info found";

    String TRACFONE_SEARCH_NOT_CERTIFY_MODEL_ERROR = "TFE1356";
    String TRACFONE_SEARCH_NOT_CERTIFY_MODEL_ERROR_MESSAGE = "Unable to search Not Certify Model";

    String TRACFONE_ADD_NOT_CERTIFY_MODEL_ERROR = "TFE1357";
    String TRACFONE_ADD_NOT_CERTIFY_MODEL_ERROR_MESSAGE = "Unable to add Not Certify Model";

    String TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR = "TFE1358";
    String TRACFONE_UPDATE_NOT_CERTIFY_MODEL_ERROR_MESSAGE = "Unable to update Not Certify Model";

    String TRACFONE_DELETE_NOT_CERTIFY_MODEL_ERROR = "TFE1359";
    String TRACFONE_DELETE_NOT_CERTIFY_MODEL_ERROR_MESSAGE = "Unable to delete Not Certify Model";

    String TRACFONE_DUPLICATE_NOT_CERTIFY_MODEL_ERROR = "TFE1360";
    String TRACFONE_DUPLICATE_NOT_CERTIFY_MODEL_ERROR_MESSAGE = "Duplicate Not Certify Model found";

    String TRACFONE_SEARCH_CARRIERSIMPREF_ERROR = "TFE1361";
    String TRACFONE_SEARCH_CARRIERSIMPREF_ERROR_MESSAGE = "Unable to search Carrier SIM Preference";

    String TRACFONE_ADD_CARRIERSIMPREF_ERROR = "TFE1362";
    String TRACFONE_ADD_CARRIERSIMPREF_ERROR_MESSAGE = "Unable to add Carrier SIM Preference";

    String TRACFONE_UPDATE_CARRIERSIMPREF_ERROR = "TFE1363";
    String TRACFONE_UPDATE_CARRIERSIMPREF_ERROR_MESSAGE = "Unable to update Carrier SIM Preference";

    String TRACFONE_DELETE_CARRIERSIMPREF_ERROR = "TFE1364";
    String TRACFONE_DELETE_CARRIERSIMPREF_ERROR_MESSAGE = "Unable to delete Carrier SIM Preference";

    String TRACFONE_DUPLICATE_CARRIERSIMPREF_ERROR = "TFE1365";
    String TRACFONE_DUPLICATE_CARRIERSIMPREF_ERROR_MESSAGE = "Duplicate Carrier SIM Preference found";

    String TRACFONE_GET_BUCKET_DETAILS_ERROR = "TFE1371";
    String TRACFONE_GET_BUCKET_DETAILS_ERROR_MESSAGE = "Unable to get Bucket Details";

    String TRACFONE_ADD_NPANXX_2_CARRIERZONES_ERROR = "TFE1366";
    String TRACFONE_ADD_NPANXX_2_CARRIERZONES_ERROR_MESSAGE = "Unable to insert to NPANXX2CARRIERZONES";

    String TRACFONE_NPANXX_2_CARRIERZONES_ERROR = "TFE1367";
    String TRACFONE_NPANXX_2_CARRIERZONES_ERROR_MESSAGE = "Unable to search npanxx2carrierzones";

    String TRACFONE_DELETE_NPANXX_2_CARRIERZONES_ERROR = "TFE1368";
    String TRACFONE_DELETE_NPANXX_2_CARRIERZONES_ERROR_MESSAGE = "Unable to delete npanxx2carrierzones";

    String TRACFONE_UPDATE_NPANXX2CARRIERZONES_ERROR = "TFE1369";
    String TRACFONE_UPDATE_NPANXX2CARRIERZONES_ERROR_MESSAGE = "Unable to update npanxx2carrierzones";

    String TRACFONE_DUPLICATE_NPANXX2CARRIERZONES_ERROR = "TFE1370";
    String TRACFONE_DUPLICATE_NPANXX2CARRIERZONES_ERROR_MESSAGE = "Duplicate npanxx2carrierzones found";

    String TRACFONE_GET_AR_USA_POSTAL_ZIPS_ERROR = "TFE1371";
    String TRACFONE_GET_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE = "Unable to get Ar Usa Postal Zip Details";

    String TRACFONE_ADD_AR_USA_POSTAL_ZIPS_ERROR = "TFE1372";
    String TRACFONE_ADD_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE = "Unable to insert to Ar Usa Postal Zip";

    String TRACFONE_DUPLICATE_AR_USA_POSTAL_ZIPS_ERROR = "TFE1373";
    String TRACFONE_DUPLICATE_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE = "Duplicate Ar Usa Postal Zip record found";

    String TRACFONE_DELETE_AR_USA_POSTAL_ZIPS_ERROR = "TFE1374";
    String TRACFONE_DELETE_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE = "Unable to delete Ar Usa Postal Zip record found";

    String TRACFONE_UPDATE_AR_USA_POSTAL_ZIPS_ERROR = "TFE1375";
    String TRACFONE_UPDATE_AR_USA_POSTAL_ZIPS_ERROR_MESSAGE = "Unable to update Ar Usa Postal Zip record found";

    String TRACFONE_GET_AR_USA_MARKET_DETAILS_ERROR = "TFE1445";
    String TRACFONE_GET_AR_USA_MARKET_DETAILS_ERROR_MESSAGE = "Unable to get Ar Usa Market Detail";

    String TRACFONE_ADD_AR_USA_MARKET_DETAILS_ERROR = "TFE1446";
    String TRACFONE_ADD_AR_USA_MARKET_DETAILS_ERROR_MESSAGE = "Unable to insert to Ar Usa Market";

    String TRACFONE_REPLACED_AR_USA_MARKET_DETAILS = "Ar Usa Market details Record Updated";

    String TRACFONE_DUPLICATE_AR_USA_MARKET_DETAILS_ERROR = "TFE1447";
    String TRACFONE_DUPLICATE_AR_USA_MARKET_DETAILS_ERROR_MESSAGE = "Duplicate Ar Usa Market record found";

    String TRACFONE_DELETE_AR_USA_MARKET_DETAILS_ERROR = "TFE1448";
    String TRACFONE_DELETE_AR_USA_MARKET_DETAILS_ERROR_MESSAGE = "Unable to delete Ar Usa Market record found";

    String TRACFONE_UPDATE_AR_USA_MARKET_DETAILS_ERROR = "TFE1449";
    String TRACFONE_UPDATE_AR_USA_MARKET_DETAILS_ERROR_MESSAGE = "Unable to update Ar Usa Market record found";

    String TRACFONE_ADD_GEO_LOC_ERROR = "TFE1450";
    String TRACFONE_ADD_GEO_LOC_ERROR_MESSAGE = "Unable to add a Geo Loc";

    String TRACFONE_DELETE_GEO_LOC_ERROR = "TFE1451";
    String TRACFONE_DELETE_GEO_LOC_ERROR_MESSAGE = "Unable to delete Geo Loc";

    String TRACFONE_GET_USER_ERROR = "TFE1452";
    String TRACFONE_GET_USER_ERROR_MESSAGE = "Unable to get User";

    String TRACFONE_GET_GEO_LOC_ERROR = "TFE1453";
    String TRACFONE_GET_GEO_LOC_ERROR_MESSAGE = "Unable to search Geo Loc";

    String TRACFONE_DUPLICATE_GEO_LOC_ERROR = "TFE1454";
    String TRACFONE_DUPLICATE_GEO_LOC_ERROR_MESSAGE = "Duplicate Geo Loc found";

    String TRACFONE_UPDATE_GEO_LOC_ERROR = "TFE1455";
    String TRACFONE_UPDATE_GEO_LOC_ERROR_MESSAGE = "Unable to update Geo Loc";

    String TRACFONE_CARRIERZONES_ERROR = "TFE1456";
    String TRACFONE_CARRIERZONES_ERROR_MESSAGE = "Unable to search carrierzones";

    String  TRACFONE_ADD_CARRIERZONES_ERROR = "TFE1457";
    String TRACFONE_ADD_CARRIERZONES_ERROR_MESSAGE = "Unable to insert to CARRIERZONES";

    String TRACFONE_DUPLICATE_CARRIERZONES_ERROR = "TFE1458";
    String TRACFONE_DUPLICATE_CARRIERZONES_ERROR_MESSAGE = "Duplicate carrierzones found";

    String TRACFONE_DELETE_CARRIERZONES_ERROR = "TFE1459";
    String TRACFONE_DELETE_CARRIERZONES_ERROR_MESSAGE = "Unable to delete carrierzones";

    String TRACFONE_UPDATE_CARRIERZONES_ERROR = "TFE1460";
    String TRACFONE_UPDATE_CARRIERZONES_ERROR_MESSAGE = "Unable to update carrierzones";

    String TRACFONE_CARRIERPREF_ERROR = "TFE1461";
    String TRACFONE_CARRIERPREF_ERROR_MESSAGE = "Unable to search carrierpref";

    String  TRACFONE_ADD_CARRIERPREF_ERROR = "TFE1462";
    String TRACFONE_ADD_CARRIERPREF_ERROR_MESSAGE = "Unable to insert to carrierpref";

    String TRACFONE_DUPLICATE_CARRIERPREF_ERROR = "TFE1463";
    String TRACFONE_DUPLICATE_CARRIERPREF_ERROR_MESSAGE = "Duplicate carrierpref found";

    String TRACFONE_DELETE_CARRIERPREF_ERROR = "TFE1464";
    String TRACFONE_DELETE_CARRIERPREF_ERROR_MESSAGE = "Unable to delete carrierpref";

    String TRACFONE_UPDATE_CARRIERPREF_ERROR = "TFE1465";
    String TRACFONE_UPDATE_CARRIERPREF_ERROR_MESSAGE = "Unable to update carrierpref";

    String TRACFONE_REPLACED_NPANXX_2_CARRIERZONES_DETAILS = "NPANXX2CarrierZones Record Updated";

    // Rate Plan Profile
    String TRACFONE_RATEPLAN_PROFILE_SEQ_STMT = "SELECT sa.SEQ_RP_PROFILE.nextval AS RATEPLAN_PROFILEID_SEQ FROM DUAL";

    String TRACFONE_INSERT_RATEPLAN_PROFILE = "insert into sa.x_rp_profile "
            + "(profile_id, profile_desc, INSERT_TIMESTAMP, UPDATE_TIMESTAMP) values (?, ?, sysdate, sysdate)";

    String TRACFONE_UPDATE_RATEPLAN_PROFILE = "update sa.x_rp_profile set UPDATE_TIMESTAMP = sysdate, ";

    String TRACFONE_DELETE_PROFILE_LINKS = "delete from sa.x_rp_extension_link where profile_id in (?";

    String TRACFONE_DELETE_PROFILE_CONFIGS = "delete from sa.x_rp_extension_config where profile_id in (?";

    String TRACFONE_DELETE_RATEPLAN_PROFILE = "delete from sa.x_rp_profile where profile_id in (?";

    String TRACFONE_SEARCH_PROFILE = SELECT_X_RP_PROFILE_TABLE;

    String TRACFONE_SEARCH_PROFILES_WITHOUT_FEATURES = SELECT_X_RP_PROFILE_TABLE +
            "profile_id not in (select profile_id from sa.x_rp_extension_config) AND ";

    String TRACFONE_SEARCH_UNLINKED_PROFILES = "select DISTINCT p.* "
            + "from X_RP_PROFILE p, sa.X_RP_EXTENSION_CONFIG ec where ec.PROFILE_ID (+) = p.PROFILE_ID AND ";

    String TRACFONE_SEARCH_BUCKET_PROFILE = SELECT_X_RP_PROFILE_TABLE +
            "PROFILE_ID IN (SELECT DISTINCT PROFILE_ID FROM SA.CARRIER_PROFILE_BUCKETS WHERE SERVICE_PLAN_ID = ?)";

    String TRACFONE_SEARCH_CHILD_BUCKET_PROFILE = SELECT_X_RP_PROFILE_TABLE +
            "PROFILE_ID IN (SELECT DISTINCT PROFILE_ID FROM SA.CARRIER_PROFILE_CHILD_BUCKETS WHERE SERVICE_PLAN_ID = ?)";

    String TRACFONE_MAX_RATEPLAN_PROFILE_ID = "select max(profile_id) as objid from sa.x_rp_profile";

    // Rate Plan
    String TRACFONE_INSERT_RATEPLAN = "insert into sa.x_rate_plan "
            + "(OBJID, X_RATE_PLAN, X_PRIVATE_NETWORK, X_ESPID_UPDATE, X_ESPID_NUM, "
            + "ALLOW_MFORM_APN_RQST_FLAG, PROPAGATE_FLAG_VALUE, CALCULATE_DATA_UNITS_FLAG, "
            + "THRESHOLDS_TO_TMO, HOTSPOT_BUCKETS_FLAG) "
            + "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    String TRACFONE_VIEW_RATEPLAN = "select OBJID, X_RATE_PLAN, X_PRIVATE_NETWORK, "
            + "X_ESPID_UPDATE, X_ESPID_NUM, ALLOW_MFORM_APN_RQST_FLAG, PROPAGATE_FLAG_VALUE, "
            + "CALCULATE_DATA_UNITS_FLAG, THRESHOLDS_TO_TMO, HOTSPOT_BUCKETS_FLAG from sa.x_rate_plan "
            + "where ";

    String TRACFONE_VIEW_ALL_RATEPLAN = "select OBJID, X_RATE_PLAN, X_PRIVATE_NETWORK, "
            + "X_ESPID_UPDATE, X_ESPID_NUM, ALLOW_MFORM_APN_RQST_FLAG, PROPAGATE_FLAG_VALUE, "
            + "CALCULATE_DATA_UNITS_FLAG, THRESHOLDS_TO_TMO, HOTSPOT_BUCKETS_FLAG from sa.x_rate_plan "
            + "order by X_RATE_PLAN";

    String TRACFONE_VIEW_ALL_CF_RATEPLAN = "select rp.OBJID, rp.X_RATE_PLAN from sa.x_rate_plan rp where rp.X_RATE_PLAN in " +
            "(select cf.X_RATE_PLAN from sa.table_x_carrier_features cf, sa.table_x_carrier c, sa.table_x_carrier_group cg " +
            "where cf.x_feature2x_carrier = c.objid and " +
            "c.carrier2carrier_group = cg.objid and cg.x_carrier_name = ?) order by rp.X_RATE_PLAN";

    String TRACFONE_UPDATE_RATEPLAN_IG_BUCKETS = "update gw1.ig_buckets set RATE_PLAN = ? where RATE_PLAN = ?";

    String TRACFONE_UPDATE_RATEPLAN_CF = "update sa.table_x_carrier_features set X_RATE_PLAN = ? where X_RATE_PLAN = ?";

    String TRACFONE_UPDATE_RATEPLAN_APN = "update sa.x_apn set RATE_PLAN = ? where RATE_PLAN = ?";

    String TRACFONE_UPDATE_RATEPLAN = "update sa.x_rate_plan set X_RATE_PLAN = ?,"
            + "X_PRIVATE_NETWORK = ?,X_ESPID_UPDATE = ?,X_ESPID_NUM = ?,"
            + "ALLOW_MFORM_APN_RQST_FLAG = ?,PROPAGATE_FLAG_VALUE = ?,"
            + "CALCULATE_DATA_UNITS_FLAG = ?,THRESHOLDS_TO_TMO = ?,HOTSPOT_BUCKETS_FLAG = ? "
            + "where objid = ?";

    String TRACFONE_DELETE_RATEPLAN_IG_BUCKETS = "delete from gw1.ig_buckets where rate_plan in (?";

    String TRACFONE_DELETE_RATEPLAN_APN = "delete from sa.x_apn where rate_plan in (?";

    String TRACFONE_DELETE_RATEPLAN = "delete from sa.x_rate_plan where x_rate_plan in (?";

    String TRACFONE_SEARCH_UNLINKED_RP = "select distinct rp.* from sa.x_rate_plan rp where ";

    String TRACFONE_MAX_RATEPLAN_OBJID = "select max(objid) as objid from sa.x_rate_plan";

    // GW1.IG_BUCKETS
    String TRACFONE_INSERT_IG_BUCKETS = "insert into GW1.IG_BUCKETS (BUCKET_ID, MEASURE_UNIT, "
            + "BUCKET_DESC, BUCKET_TYPE, RATE_PLAN, ACTIVE_FLAG, SUI_DISPLAY_TYPE, BUCKET_GROUP, PRIORITY_GROUP) values (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    String TRACFONE_VIEW_IG_BUCKETS = "select BUCKET_ID, MEASURE_UNIT, "
            + "BUCKET_DESC, BUCKET_TYPE, RATE_PLAN, ACTIVE_FLAG, SUI_DISPLAY_TYPE, BUCKET_GROUP, "
            + "PRIORITY_GROUP from GW1.IG_BUCKETS where BUCKET_ID = ? and RATE_PLAN = ?";

    String TRACFONE_UPDATE_IG_BUCKETS = "update GW1.IG_BUCKETS set BUCKET_ID = ?, "
            + "MEASURE_UNIT = ?, BUCKET_DESC = ?, BUCKET_TYPE = ?, RATE_PLAN = ?, ACTIVE_FLAG = ?, "
            + "SUI_DISPLAY_TYPE = ?, BUCKET_GROUP = ?, PRIORITY_GROUP = ? "
            + "where bucket_id = ? and rate_plan = ?";

    String TRACFONE_DELETE_IG_BUCKETS = "delete from GW1.IG_BUCKETS where rate_plan = ? and BUCKET_ID in (?";

    String TRACFONE_SEARCH_IG_BUCKETS = "select BUCKET_ID, MEASURE_UNIT, "
            + "BUCKET_DESC, BUCKET_TYPE, RATE_PLAN, ACTIVE_FLAG, SUI_DISPLAY_TYPE, BUCKET_GROUP, PRIORITY_GROUP from GW1.IG_BUCKETS where RATE_PLAN in (?";

    //BUCKET_LIST
    String TRACFONE_VIEW_BUCKET_LIST = "select BUCKET_ID, DESCRIPTION, ACTIVE_FLAG, "
            + "PARENT_SHORT_NAME from sa.BUCKET_LIST where ACTIVE_FLAG = 'Y'";

    //CARRIER_PROFILE_BUCKETS - NEW NEXTGEN BUCKET TABLE
    String TRACFONE_CARRIER_PROFILE_BUCKET_SEQ_STMT = "SELECT sa.SEQU_CARRIER_PROFILE_BUCKETS.nextval AS CARRIER_PROFILE_BUCKETID_SEQ FROM DUAL";

    String TRACFONE_INSERT_CARRIER_PROFILE_BUCKET = "insert into sa.carrier_profile_buckets (OBJID, PROFILE_ID, "
            + "SERVICE_PLAN_ID, BUCKET_ID, BUCKET_VALUE, UNIT_OF_MEASURE, BUCKET_TYPE,"
            + "BUCKET_GROUP, BUCKET_REQUIREMENT, ACTIVE_FLAG, AUTO_RENEW_FLAG, AUTO_RENEW_FREQUENCY, "
            + "AUTO_RENEW_VALUE, AUTO_RENEW_DAY, BENEFIT_TYPE, SUI_DISPLAY_TYPE, PRIORITY, HIDE_UBI_FLAG, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)"
            + "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE, SYSDATE)";

    String TRACFONE_UPDATE_CARRIER_PROFILE_BUCKET = "update sa.carrier_profile_buckets set BUCKET_ID = ?, " +
            "UNIT_OF_MEASURE = ?, BUCKET_TYPE = ?, BUCKET_GROUP = ?, ACTIVE_FLAG = ?, BUCKET_REQUIREMENT = ?, " +
            "AUTO_RENEW_FLAG = ?, AUTO_RENEW_FREQUENCY = ?, AUTO_RENEW_VALUE = ?, AUTO_RENEW_DAY = ?, " +
            "BENEFIT_TYPE = ?, BUCKET_VALUE = ?, SUI_DISPLAY_TYPE = ?, PRIORITY = ?, HIDE_UBI_FLAG = ?, UPDATE_TIMESTAMP = SYSDATE " +
            "where OBJID = ?";

    String TRACFONE_DELETE_CARRIER_PROFILE_BUCKET = "delete from sa.carrier_profile_buckets where objid in (?";

    String TRACFONE_SEARCH_CP_BUCKETS = "select OBJID, PROFILE_ID, SERVICE_PLAN_ID, BUCKET_ID, "
            + "BUCKET_VALUE, UNIT_OF_MEASURE, BUCKET_TYPE, BUCKET_GROUP, BUCKET_REQUIREMENT, "
            + "ACTIVE_FLAG, AUTO_RENEW_FLAG, AUTO_RENEW_FREQUENCY, AUTO_RENEW_VALUE, AUTO_RENEW_DAY, "
            + "BENEFIT_TYPE, SUI_DISPLAY_TYPE, PRIORITY, HIDE_UBI_FLAG from sa.CARRIER_PROFILE_BUCKETS "
            + "WHERE ";

    String TRACFONE_DUPLICATE_BUCKET_CHECK = "select count(1) from sa.CARRIER_PROFILE_BUCKETS where PROFILE_ID = ? and " +
            "SERVICE_PLAN_ID = ? and BUCKET_ID = ?";

    //CARRIER_PROFILE_BUCKET_TIER - NEW NEXTGEN BUCKET TABLE
    String TRACFONE_BUCKET_TIER_SEQ_STMT = "SELECT sa.SEQ_CARRIER_PROFILE_BUCKETTIER.nextval AS BUCKET_TIERID_SEQ FROM DUAL";

    String TRACFONE_INSERT_BUCKET_TIER = "insert into sa.CARRIER_PROFILE_BUCKET_TIER (OBJID, "
            + "CARRIER_PROFILE_BUCKETS_OBJID, USAGE_TIER_ID, TIER_DESCRIPTION, TIER_VALUE, TIER_BEHAVIOR, INSERT_TIMESTAMP, UPDATE_TIMESTAMP) "
            + "values (?, ?, ?, ?, ?, ?, SYSDATE, SYSDATE)";

    String TRACFONE_UPDATE_BUCKET_TIER = "update sa.CARRIER_PROFILE_BUCKET_TIER set USAGE_TIER_ID = ?, " +
            "TIER_DESCRIPTION = ?, TIER_VALUE = ?, TIER_BEHAVIOR = ?, UPDATE_TIMESTAMP = SYSDATE " +
            "where OBJID = ?";

    String TRACFONE_DELETE_BUCKET_TIER = "delete from sa.CARRIER_PROFILE_BUCKET_TIER where "
            + "CARRIER_PROFILE_BUCKETS_OBJID in (?";

    String TRACFONE_DELETE_BUCKET_TIER_BY_OBJID = "delete from sa.CARRIER_PROFILE_BUCKET_TIER where "
            + "OBJID = ?";

    String TRACFONE_GET_ALL_TIERS_FOR_BUCKET = "select OBJID, CARRIER_PROFILE_BUCKETS_OBJID, "
            + "USAGE_TIER_ID, TIER_DESCRIPTION, TIER_VALUE, TIER_BEHAVIOR "
            + "from sa.CARRIER_PROFILE_BUCKET_TIER where CARRIER_PROFILE_BUCKETS_OBJID = ?";

    //CARRIER_PROFILE_CHILD_BUCKETS - NEW NEXTGEN BUCKET TABLE
    String TRACFONE_CHILD_BUCKET_SEQ_STMT = "SELECT sa.SEQ_CARRIER_PROFILE_CHILD_BKT.nextval AS CHILD_BUCKETID_SEQ FROM DUAL";

    String TRACFONE_INSERT_CHILD_BUCKET = "insert into sa.CARRIER_PROFILE_CHILD_BUCKETS (OBJID, PROFILE_ID, "
            + "SERVICE_PLAN_ID, CHILD_PLAN_ID, BUCKET_ID, BUCKET_VALUE, UNIT_OF_MEASURE, BUCKET_TYPE,"
            + "BUCKET_GROUP, BUCKET_REQUIREMENT, ACTIVE_FLAG, AUTO_RENEW_FLAG, AUTO_RENEW_FREQUENCY, "
            + "AUTO_RENEW_VALUE, AUTO_RENEW_DAY, BENEFIT_TYPE, HIDE_UBI_FLAG, PRIORITY, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)"
            + "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE, SYSDATE)";

    String TRACFONE_UPDATE_CHILD_BUCKET = "update sa.CARRIER_PROFILE_CHILD_BUCKETS set CHILD_PLAN_ID = ?, " +
            "BUCKET_ID = ?, UNIT_OF_MEASURE = ?, BUCKET_TYPE = ?, BUCKET_GROUP =?, ACTIVE_FLAG = ?, BUCKET_REQUIREMENT = ?," +
            " AUTO_RENEW_FLAG = ?, AUTO_RENEW_FREQUENCY = ?, AUTO_RENEW_VALUE = ?, AUTO_RENEW_DAY = ?, PRIORITY = ?, " +
            "BUCKET_VALUE = ?, BENEFIT_TYPE = ?, HIDE_UBI_FLAG = ?, UPDATE_TIMESTAMP = SYSDATE" +
            " where OBJID = ? ";

    String TRACFONE_DELETE_CHILD_BUCKET = "delete from sa.CARRIER_PROFILE_CHILD_BUCKETS where objid in (?";

    String TRACFONE_SEARCH_CHILD_BUCKET = "select OBJID, PROFILE_ID, SERVICE_PLAN_ID, CHILD_PLAN_ID, "
            + "BUCKET_ID, BUCKET_VALUE, UNIT_OF_MEASURE, BUCKET_TYPE, BUCKET_GROUP, BUCKET_REQUIREMENT, "
            + "ACTIVE_FLAG, AUTO_RENEW_FLAG, AUTO_RENEW_FREQUENCY, AUTO_RENEW_VALUE, AUTO_RENEW_DAY, "
            + "BENEFIT_TYPE, HIDE_UBI_FLAG, PRIORITY from sa.CARRIER_PROFILE_CHILD_BUCKETS where ";

    String TRACFONE_DUPLICATE_CHILD_BUCKET_CHECK = "select count(1) from sa.CARRIER_PROFILE_CHILD_BUCKETS where PROFILE_ID = ? and " +
            "SERVICE_PLAN_ID = ? and BUCKET_ID = ? and CHILD_PLAN_ID = ?";

    //CARRIER_PROFILE_CHILD_TIER - NEW NEXTGEN BUCKET TABLE
    String TRACFONE_CHILD_BUCKET_TIER_SEQ_STMT = "SELECT sa.SEQ_CARRIER_PROFILE_CHILD_TIER.nextval AS CHILD_BUCKET_TIERID_SEQ FROM DUAL";

    String TRACFONE_INSERT_CHILD_BUCKET_TIER = "insert into sa.CARRIER_PROFILE_CHILD_TIER (OBJID, "
            + "CARRIER_PROFILE_CHILD_OBJID, USAGE_TIER_ID, TIER_DESCRIPTION, TIER_VALUE, TIER_BEHAVIOR, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)"
            + "values (?, ?, ?, ?, ?, ?, SYSDATE, SYSDATE)";

    String TRACFONE_UPDATE_CHILD_BUCKET_TIER = "update sa.CARRIER_PROFILE_CHILD_TIER set USAGE_TIER_ID = ?, " +
            "TIER_DESCRIPTION = ?, TIER_VALUE = ?, TIER_BEHAVIOR = ?, UPDATE_TIMESTAMP = SYSDATE where OBJID = ?";

    String TRACFONE_DELETE_CHILD_BUCKET_TIER_BY_OBJID = "delete from sa.CARRIER_PROFILE_CHILD_TIER where "
            + "OBJID = ? ";

    String TRACFONE_DELETE_CHILD_BUCKET_TIER = "delete from sa.CARRIER_PROFILE_CHILD_TIER where "
            + "CARRIER_PROFILE_CHILD_OBJID in (?";

    String TRACFONE_GET_ALL_TIERS_FOR_CHILD_BUCKET = "select OBJID, CARRIER_PROFILE_CHILD_OBJID, "
            + "USAGE_TIER_ID, TIER_DESCRIPTION, TIER_VALUE, TIER_BEHAVIOR from "
            + "sa.CARRIER_PROFILE_CHILD_TIER where CARRIER_PROFILE_CHILD_OBJID = ?";

    String TRACFONE_DELETE_ALL_BUCKET_TIERS = "delete from sa.CARRIER_PROFILE_BUCKET_TIER where CARRIER_PROFILE_BUCKETS_OBJID in " +
            "(select OBJID from sa.CARRIER_PROFILE_BUCKETS where SERVICE_PLAN_ID = ? and PROFILE_ID = ?)";

    String TRACFONE_DELETE_ALL_BUCKETS = "delete from sa.CARRIER_PROFILE_BUCKETS where SERVICE_PLAN_ID = ? and PROFILE_ID = ? ";

    String TRACFONE_DELETE_ALL_CHILD_BUCKET_TIERS = "delete from sa.CARRIER_PROFILE_CHILD_TIER where CARRIER_PROFILE_CHILD_OBJID in " +
            "(select OBJID from sa.CARRIER_PROFILE_CHILD_BUCKETS where SERVICE_PLAN_ID = ? and PROFILE_ID = ?)";

    String TRACFONE_DELETE_ALL_CHILD_BUCKETS = "delete from sa.CARRIER_PROFILE_CHILD_BUCKETS where SERVICE_PLAN_ID = ? and PROFILE_ID = ? ";

    String TRACFONE_UPDATE_ALL_BUCKET = "update sa.CARRIER_PROFILE_BUCKETS set PROFILE_ID = ? " +
            "where SERVICE_PLAN_ID = ? and PROFILE_ID = ? ";

    String TRACFONE_UPDATE_ALL_CHILD_BUCKET = "update sa.CARRIER_PROFILE_CHILD_BUCKETS set PROFILE_ID = ? " +
            "where SERVICE_PLAN_ID = ? and PROFILE_ID = ? ";

    //Carrier Feature
    String TRACFONE_INSERT_CARRIER_FEATURE = "insert into sa.table_x_carrier_features "
            + "(objid, dev, X_TECHNOLOGY, X_RATE_PLAN, X_VOICEMAIL, X_VM_CODE, X_VM_PACKAGE, X_CALLER_ID, "
            + "X_ID_CODE, X_ID_PACKAGE, X_SMS, X_SMS_CODE, X_SMS_PACKAGE, X_CALL_WAITING, X_CW_CODE, "
            + "X_CW_PACKAGE, X_DIGITAL_FEATURE, X_DIG_FEATURE, X_FEATURE2X_CARRIER, X_SMSC_NUMBER, "
            + "X_DATA, X_RESTRICTED_USE, X_SWITCH_BASE_RATE, X_FEATURES2BUS_ORG, X_IS_SWB_CARRIER, "
            + "X_MPN, X_MPN_CODE, X_POOL_NAME, CREATE_MFORM_IG_FLAG, USE_CF_EXTENSION_FLAG, "
            + "DATA_SAVER, DATA_SAVER_CODE, USE_RP_EXTENSION_FLAG, TMO_NEXT_GEN_FLAG, INSERT_TIMESTAMP) values "
            + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate)";

    String TRACFONE_UPDATE_CARRIER_FEATURE = "update sa.table_x_carrier_features cf set "
            + "cf.dev = ?,cf.X_TECHNOLOGY = ?,cf.X_RATE_PLAN = ?,cf.X_VOICEMAIL = ?,cf.X_VM_CODE = ?,cf.X_VM_PACKAGE = ?,"
            + "cf.X_CALLER_ID = ?,cf.X_ID_CODE=?,cf.X_ID_PACKAGE = ?,cf.X_SMS = ?,cf.X_SMS_CODE=?,"
            + "cf.X_SMS_PACKAGE = ?,cf.X_CALL_WAITING = ?,cf.X_CW_CODE=?,cf.X_CW_PACKAGE=?, "
            + "cf.X_DIGITAL_FEATURE=?, cf.X_DIG_FEATURE=?,cf.X_FEATURE2X_CARRIER = ?,cf.X_SMSC_NUMBER=?,"
            + "cf.X_DATA = ?,cf.X_RESTRICTED_USE = ?,cf.X_SWITCH_BASE_RATE = ?,cf.X_FEATURES2BUS_ORG = ?,"
            + "cf.X_IS_SWB_CARRIER = ?,cf.X_MPN = ?,cf.X_MPN_CODE = ?, cf.X_POOL_NAME = ?, "
            + "cf.CREATE_MFORM_IG_FLAG = ?, cf.USE_CF_EXTENSION_FLAG = ?,cf.DATA_SAVER = ?,"
            + "cf.DATA_SAVER_CODE = ?, cf.USE_RP_EXTENSION_FLAG = ?, cf.TMO_NEXT_GEN_FLAG = ?, cf.UPDATE_TIMESTAMP = sysdate "
            + "where objid = ?";

    String TRACFONE_DELETE_CARRIER_FEATURE = "delete from sa.table_x_carrier_features where objid in (?";

    String TRACFONE_SEARCH_CARRIER_FEATURE = "select DISTINCT cf.*, mtm.*, (select x_carrier_id from sa.table_x_carrier where objid = cf.x_feature2x_carrier) X_CARRIER_ID from "
            + "sa.table_x_carrier_features cf, sa.mtm_sp_carrierfeatures mtm, sa.table_x_carrier c, sa.table_x_carrier_group cg "
            + "where mtm.x_carrier_features_id = cf.objid and cf.x_feature2x_carrier = c.objid and c.carrier2carrier_group = cg.objid and cg.x_carrier_name = ? and mtm.x_service_plan_id = ? AND ";

    String TRACFONE_SEARCH_CARRIER_FEATURE_MAP = " from sa.table_x_carrier_features cf, sa.mtm_sp_carrierfeatures mtm, sa.table_x_carrier c, sa.table_x_carrier_group cg "
            + "where mtm.x_carrier_features_id = cf.objid and cf.x_feature2x_carrier = c.objid and c.carrier2carrier_group = cg.objid and cg.x_carrier_name = ? and mtm.x_service_plan_id = ? order by ";

    String TRACFONE_SEARCH_LEGACY_CARRIER_FEATURE = "select DISTINCT cf.*, mtm.*, (select x_carrier_id from sa.table_x_carrier where objid = cf.x_feature2x_carrier) X_CARRIER_ID from "
            + "sa.table_x_carrier_features cf, sa.mtm_sp_carrierfeatures_dflt mtm, sa.table_x_carrier c, sa.table_x_carrier_group cg "
            + "where mtm.x_carrier_features_id = cf.objid and cf.x_feature2x_carrier = c.objid and c.carrier2carrier_group = cg.objid and cg.x_carrier_name = ? and "
            + "mtm.x_service_plan_id = ? AND ";

    String TRACFONE_SEARCH_LEGACY_CARRIER_FEATURE_MAP = " from sa.table_x_carrier_features cf, sa.mtm_sp_carrierfeatures_dflt mtm, sa.table_x_carrier c, sa.table_x_carrier_group cg "
            + "where mtm.x_carrier_features_id = cf.objid and cf.x_feature2x_carrier = c.objid and c.carrier2carrier_group = cg.objid and cg.x_carrier_name = ? and mtm.x_service_plan_id = ? order by ";

    String TRACFONE_COUNT_CARRIER_FEATURE = "select count(cf.objid) from "
            + "sa.table_x_carrier_features cf, sa.mtm_sp_carrierfeatures mtm, sa.table_x_carrier c, sa.table_x_carrier_group cg "
            + "where mtm.x_carrier_features_id = cf.objid and cf.x_feature2x_carrier = c.objid and "
            + "c.carrier2carrier_group = cg.objid and cg.x_carrier_name = ? and mtm.x_service_plan_id = ?";

    String TRACFONE_COUNT_LEGACY_CARRIER_FEATURE = "select count(cf.objid) from "
            + "sa.table_x_carrier_features cf, sa.mtm_sp_carrierfeatures_dflt mtm, sa.table_x_carrier c, sa.table_x_carrier_group cg "
            + "where mtm.x_carrier_features_id = cf.objid and cf.x_feature2x_carrier = c.objid and c.carrier2carrier_group = cg.objid and cg.x_carrier_name = ? and mtm.x_service_plan_id = ?";

    String TRACFONE_CARRIER_FEATURE_ID_SEQ_STMT = "SELECT sa.SEQU_X_CARRIER_FEATURES.nextval AS CARRIER_FEATUREID_SEQ FROM DUAL";

    String TRACFONE_DUPLICATE_CARRIER_FEATURE = "select DISTINCT cf.objid from "
            + "sa.table_x_carrier_features cf, sa.mtm_sp_carrierfeatures mtm where mtm.x_carrier_features_id = cf.objid and ";

    String TRACFONE_DUPLICATE_LEGACY_CARRIER_FEATURE = "select DISTINCT cf.objid from "
            + "sa.table_x_carrier_features cf, sa.mtm_sp_carrierfeatures_dflt mtm where mtm.x_carrier_features_id = cf.objid and ";

    // MTM SP Carrier Feature
    String TRACFONE_INSERT_MTM_SP_CARRIER_FEATURE = "INSERT INTO sa.mtm_sp_carrierfeatures"
            + "(PRIORITY, X_SERVICE_PLAN_ID, X_CARRIER_FEATURES_ID) values (?, ?, ?)";

    String TRACFONE_INSERT_MTM_SP_CARRIER_FEATURE_DFLT = "INSERT INTO sa.mtm_sp_carrierfeatures_dflt"
            + "(PRIORITY, X_SERVICE_PLAN_ID, X_CARRIER_FEATURES_ID) values (?, ?, ?)";

    String TRACFONE_VIEW_MTM_SP_CARRIER_FEATURE = "SELECT * FROM sa.mtm_sp_carrierfeatures "
            + "where X_SERVICE_PLAN_ID = ? and X_CARRIER_FEATURES_ID = ?";

    String TRACFONE_DELETE_MTM_SP_CARRIER_FEATURE = "delete from sa.mtm_sp_carrierfeatures where "
            + "X_SERVICE_PLAN_ID = ? and X_CARRIER_FEATURES_ID in (?";

    String TRACFONE_UPDATE_MTM_SP_CARRIER_FEATURE = "update sa.mtm_sp_carrierfeatures set priority = ? where "
            + "X_SERVICE_PLAN_ID = ? and X_CARRIER_FEATURES_ID = ?";

    String TRACFONE_UPDATE_MTM_SP_CARRIER_FEATURE_DFLT = "update sa.mtm_sp_carrierfeatures_dflt set priority = ? where "
            + "X_SERVICE_PLAN_ID = ? and X_CARRIER_FEATURES_ID = ?";

    // Rate Plan Extension
    String TRACFONE_EXTENSION_ID_SEQ_STMT = "SELECT sa.SEQ_RP_EXTENSION.nextval AS EXTENSION_ID_SEQ FROM DUAL";

    String TRACFONE_INSERT_RP_EXTENSION = "insert into sa.X_RP_EXTENSION "
            + "(OBJID, LINE_STATUS_CODE, THROTTLE_STATUS_CODE, ANCILLARY_CODE, INSERT_TIMESTAMP, UPDATE_TIMESTAMP) "
            + "values (?, ?, ?, ?, sysdate, sysdate)";

    String TRACFONE_DELETE_RP_EXTENSION = "delete from sa.X_RP_EXTENSION WHERE OBJID = ?";

    String TRACFONE_VIEW_RP_EXTENSION = "select OBJID, LINE_STATUS_CODE, "
            + "THROTTLE_STATUS_CODE, ANCILLARY_CODE from SA.X_RP_EXTENSION where 1 = 1 AND ";

    String TRACFONE_COUNT_RP_EXTENSION_LINKS = "select COUNT(1) from SA.X_RP_EXTENSION_LINK WHERE RP_EXTENSION_OBJID = ?";

    // Rate Plan Extention Link
    String TRACFONE_INSERT_RP_EXTENSION_LINK = "INSERT INTO sa.x_rp_extension_link "
            + "(OBJID, CARRIER_FEATURE_OBJID, RP_EXTENSION_OBJID, PROFILE_ID, CHILD_PLAN_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP) "
            + "values (?, ?, ?, ?, ?, sysdate, sysdate)";

    String TRACFONE_UPDATE_RP_EXTENSION_LINK = "update sa.x_rp_extension_link "
            + "set RP_EXTENSION_OBJID = ?, PROFILE_ID = ?, CHILD_PLAN_ID = ?, UPDATE_TIMESTAMP = sysdate where OBJID = ?";

    String TRACFONE_DELETE_RP_EXTENSION_LINK = "delete from sa.x_rp_extension_link where ";

    String TRACFONE_VIEW_RP_EXTENSION_LINK_FOR_CF = "select el.OBJID, "
            + "el.RP_EXTENSION_OBJID, e.line_status_code, e.throttle_status_code, e.ancillary_code, "
            + "el.PROFILE_ID, p.profile_desc, "
            + "el.CHILD_PLAN_ID, c.child_description from "
            + "sa.x_rp_extension_link el, sa.x_rp_extension e, sa.x_rp_profile p, sa.child_identifier_list c "
            + "where el.RP_EXTENSION_OBJID = e.objid and "
            + "el.profile_id = p.profile_id and "
            + "el.child_plan_id = c.child_id (+) and "
            + "el.CARRIER_FEATURE_OBJID = ?";

    // Rate Plan Extension
    String TRACFONE_EXTENSION_LINK_ID_SEQ_STMT = "SELECT sa.SEQ_RP_EXTENSION_LINK.nextval AS EXTENSION_LINKID_SEQ FROM DUAL";

    String TRACFONE_GET_SERVICEPLANS = SELECT_SERVICE_PLAN
            + "where objid in (select distinct mtm.x_service_plan_id from "
            + "sa.mtm_sp_carrierfeatures mtm, sa.table_x_carrier_features cf, sa.table_x_carrier c, sa.table_x_carrier_group cg "
            + "where mtm.x_carrier_features_id = cf.objid and cf.x_feature2x_carrier = c.objid and "
            + "c.carrier2carrier_group = cg.objid and cg.x_carrier_name = ?) order by objid";

    String TRACFONE_GET_ALL_SERVICEPLANS = SELECT_SERVICE_PLAN
            + "where objid in (select distinct mtm.x_service_plan_id from "
            + "sa.mtm_sp_carrierfeatures mtm) order by objid";

    String TRACFONE_GET_ALL_LEGACY_PAYGO_PLANS = "SELECT DISTINCT X_SERVICE_PLAN_ID FROM SA.MTM_SP_CARRIERFEATURES_DFLT where x_carrier_features_id is not null";

    String TRACFONE_GET_LEGACY_PLANS_BY_CARRIER = "select DISTINCT mtm.X_SERVICE_PLAN_ID from " +
            "sa.MTM_SP_CARRIERFEATURES_DFLT mtm, sa.table_x_carrier_features cf, sa.table_x_carrier c, sa.table_x_carrier_group cg " +
            "where mtm.x_carrier_features_id = cf.objid and cf.x_feature2x_carrier = c.objid and c.carrier2carrier_group = cg.objid and " +
            "cg.x_carrier_name = ? and mtm.x_carrier_features_id is not null order by mtm.X_SERVICE_PLAN_ID desc";

    String TRACFONE_GET_BUCKET_SERVICEPLANS = SELECT_SERVICE_PLAN
            + "where objid in (select distinct service_plan_id from SA.CARRIER_PROFILE_BUCKETS)";

    String TRACFONE_GET_CHILD_BUCKET_SERVICEPLANS = SELECT_SERVICE_PLAN
            + "where objid in (select distinct service_plan_id from SA.CARRIER_PROFILE_CHILD_BUCKETS)";

    String TRACFONE_GET_PROFILE_SERVICE_PLANS = "select distinct objid, mkt_name from sa.x_service_plan " +
            "where objid in (select x_service_plan_id from sa.mtm_sp_carrierfeatures mtm, sa.table_x_carrier_features cf, " +
            "sa.x_rp_extension_link el where mtm.x_carrier_features_id = cf.objid and cf.objid = el.CARRIER_FEATURE_OBJID and el.profile_id = ?) order by objid";

    String TRACFONE_GET_RP_SERVICE_PLANS = "select distinct objid, mkt_name from sa.x_service_plan " +
            "where objid in (select x_service_plan_id from sa.mtm_sp_carrierfeatures mtm, sa.table_x_carrier_features cf " +
            "where mtm.x_carrier_features_id = cf.objid and " +
            "cf.x_rate_plan = ?) order by objid";

    String TRACFONE_GET_ALL_BUS_ORGS = "select objId, org_id from sa.table_bus_org where W3CI_ACRONYM is not null";

    String TRACFONE_GET_ALL_LINE_STATUS_CODES = "select LINE_STATUS_CODE, DESCRIPTION from sa.x_rp_line_status";

    String TRACFONE_INSERT_LINE_STATUS_CODE = "insert into sa.x_rp_line_status "
            + "(DESCRIPTION, LINE_STATUS_CODE, INSERT_TIMESTAMP, UPDATE_TIMESTAMP) values (?, ?, sysdate, sysdate)";

    String TRACFONE_UPDATE_LINE_STATUS_CODE = "update sa.x_rp_line_status set UPDATE_TIMESTAMP = sysdate, DESCRIPTION = ? where LINE_STATUS_CODE = ?";

    String TRACFONE_DELETE_LINE_STATUS_CODE = "delete from SA.x_rp_line_status where LINE_STATUS_CODE = ?";

    String TRACFONE_GET_ALL_THROTTLE_STATUS_CODES = "select THROTTLE_STATUS_CODE, DESCRIPTION from sa.x_rp_throttle_status";

    String TRACFONE_INSERT_THROTTLE_STATUS_CODE = "insert into sa.x_rp_throttle_status "
            + "(DESCRIPTION, THROTTLE_STATUS_CODE, INSERT_TIMESTAMP, UPDATE_TIMESTAMP) values (?, ?, sysdate, sysdate)";

    String TRACFONE_UPDATE_THROTTLE_STATUS_CODE = "update sa.x_rp_throttle_status set DESCRIPTION = ?, UPDATE_TIMESTAMP = sysdate where THROTTLE_STATUS_CODE = ?";

    String TRACFONE_DELETE_THROTTLE_STATUS_CODE = "delete from SA.x_rp_throttle_status where THROTTLE_STATUS_CODE = ?";

    String TRACFONE_DELETE_FEATURE_REQUIREMENT = "delete from SA.X_RP_FEATURE_REQUIREMENT where FEATURE_REQUIREMENT = ?";

    String TRACFONE_INSERT_FEATURE_REQUIREMENT = "insert into sa.X_RP_FEATURE_REQUIREMENT "
            + "(DESCRIPTION, FEATURE_REQUIREMENT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP) values (?, ?, sysdate, sysdate)";

    String TRACFONE_UPDATE_FEATURE_REQUIREMENT = "update sa.X_RP_FEATURE_REQUIREMENT set DESCRIPTION = ?, UPDATE_TIMESTAMP = sysdate where FEATURE_REQUIREMENT = ?";

    String TRACFONE_GET_ALL_FEATURE_REQUIREMENT = " select FEATURE_REQUIREMENT, DESCRIPTION from sa.X_RP_FEATURE_REQUIREMENT";

    String TRACFONE_COUNT_FEATURE_REQUIREMENT_DEPENDENCY = "select COUNT(1) from SA.X_RP_extension_config WHERE FEATURE_REQUIREMENT = ?";

    String TRACFONE_GET_ALL_ANCILLARY_CODES = "select ANCILLARY_CODE, DESCRIPTION from sa.x_rp_ancillary_code";

    String TRACFONE_DELETE_ANCILLARY_CODE = "delete from SA.x_rp_ancillary_code "
            + " where ANCILLARY_CODE = ?";

    String TRACFONE_COUNT_ANCILLARY_CODE_EXTENSIONS = "select COUNT(1) from SA.X_RP_EXTENSION WHERE ";

    String TRACFONE_VIEW_ANCILLARY_CODE = "select ANCILLARY_CODE, DESCRIPTION from SA.X_RP_ANCILLARY_CODE where ";

    String TRACFONE_INSERT_ANCILLARY_CODE = "insert into SA.x_rp_ancillary_code "
            + "(ANCILLARY_CODE, DESCRIPTION, INSERT_TIMESTAMP, UPDATE_TIMESTAMP) values (?, ?, SYSDATE, SYSDATE)";

    String TRACFONE_UPDATE_ANCILLARY_CODE = "update SA.x_rp_ancillary_code set DESCRIPTION = ? "
            + "where ANCILLARY_CODE = ?";

    String TRACFONE_GET_ALL_CHILD_PLANS = "select CHILD_ID, CHILD_DESCRIPTION from sa.CHILD_IDENTIFIER_LIST order by CHILD_ID";

    String TRACFONE_GET_BUCKET_CHILD_PLANS = "select CHILD_ID, CHILD_DESCRIPTION from sa.CHILD_IDENTIFIER_LIST " +
            "where CHILD_ID IN (SELECT DISTINCT CHILD_PLAN_ID FROM SA.CARRIER_PROFILE_CHILD_BUCKETS " +
            "where profile_id = ? AND SERVICE_PLAN_ID = ?)";

    String TRACFONE_UPDATE_CHILD_PLAN = "UPDATE sa.CHILD_IDENTIFIER_LIST "
            + "SET CHILD_DESCRIPTION = ? WHERE CHILD_ID = ?";

    String TRACFONE_INSERT_CHILD_PLAN = "insert into sa.CHILD_IDENTIFIER_LIST(CHILD_ID, CHILD_DESCRIPTION)"
            + " values (?, ?)";

    String TRACFONE_DELETE_CHILD_PLAN = "delete from sa.CHILD_IDENTIFIER_LIST WHERE CHILD_ID = ?";

    String TRACFONE_VIEW_CHILD_PLAN = "select * from sa.CHILD_IDENTIFIER_LIST WHERE CHILD_ID = ?";

    String TRACFONE_COUNT_LINKS_BY_SP = "select distinct profile_id from sa.x_rp_extension_link where carrier_feature_objid in " +
            "(select cf.objid from sa.table_x_carrier_features cf, sa.mtm_sp_carrierfeatures mtm, sa.table_x_carrier c, sa.table_x_carrier_group cg " +
            "where mtm.x_carrier_features_id = cf.objid and cf.x_feature2x_carrier = c.objid and c.carrier2carrier_group = cg.objid and " +
            "cg.x_carrier_name = ? and mtm.x_service_plan_id = ?";

    String TRACFONE_COUNT_CHILD_PLAN_LINKS = "select COUNT(1) from sa.x_rp_extension_link WHERE CHILD_PLAN_ID = ?";

    String TRACFONE_COUNT_CHILD_PLAN_BUCKETS = "select COUNT(1) from sa.CARRIER_PROFILE_CHILD_BUCKETS WHERE CHILD_PLAN_ID = ?";

    String TRACFONE_GET_ALL_MASTER_FEATURES = "select FEATURE_NAME from sa.x_rp_feature_name_list";

    String TRACFONE_VIEW_MASTER_FEATURE = "select FEATURE_NAME "
            + "from sa.x_rp_feature_name_list where FEATURE_NAME in (?";

    String TRACFONE_INSERT_MASTER_FEATURE = "insert into "
            + "sa.x_rp_feature_name_list(FEATURE_NAME, CREATE_TIMESTAMP, UPDATE_TIMESTAMP) "
            + "values (?, SYSDATE, SYSDATE)";

    String TRACFONE_GET_ALL_RP_EXTENSION_CONFIGS = "select * from sa.x_rp_extension_config where ";

    String TRACFONE_GET_FEATURE_VALUES_RP_EXTENSION_CONFIGS = "select FEATURE_VALUE from sa.x_rp_extension_config where PROFILE_ID = ?";

    String TRACFONE_GET_ALL_FEATURE_VALUES = "select distinct FEATURE_VALUE from sa.x_rp_extension_config order by FEATURE_VALUE";

    String TRACFONE_INSERT_RP_EXTENSION_CONFIG = "insert into sa.X_RP_EXTENSION_CONFIG(OBJID, PROFILE_ID, "
            + "FEATURE_NAME, FEATURE_VALUE, FEATURE_REQUIREMENT, TOGGLE_FLAG, NOTES, DISPLAY_SUI_FLAG, "
            + "RESTRICT_SUI_FLAG, INSERT_TIMESTAMP, UPDATE_TIMESTAMP) values (?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate, sysdate)";

    String TRACFONE_DELETE_RP_EXTENSION_CONFIG = "delete from sa.X_RP_EXTENSION_CONFIG where objid in (?";

    String TRACFONE_UPDATE_RP_EXTENSION_CONFIG = "update sa.X_RP_EXTENSION_CONFIG "
            + "set UPDATE_TIMESTAMP = sysdate, PROFILE_ID = ?, FEATURE_NAME = ?, FEATURE_VALUE = ?, FEATURE_REQUIREMENT = ?, "
            + "TOGGLE_FLAG = ?, NOTES = ?, DISPLAY_SUI_FLAG = ?, RESTRICT_SUI_FLAG = ? where objid = ?";

    String TRACFONE_BULK_UPDATE_RP_EXTENSION_CONFIG = "update sa.x_rp_extension_config set UPDATE_TIMESTAMP = sysdate, ";

    String TRACFONE_VIEW_RP_EXTENSION_CONFIG = "select objid, FEATURE_NAME, FEATURE_VALUE "
            + "from sa.X_RP_EXTENSION_CONFIG where profile_id = ?";

    String TRACFONE_SEARCH_RP_EXTENSION_CONFIG = "SELECT c.*, p.profile_desc FROM sa.x_rp_extension_config c, sa.x_rp_profile p " +
            "where p.profile_id = c.profile_id and c.FEATURE_VALUE in (? ";

    String TRACFONE_EXTENSION_CONFIG_ID_SEQ_STMT = "SELECT sa.SEQ_RP_EXTENSION_CONFIG.nextval AS EXTENSION_LINKID_SEQ FROM DUAL";

    String TRACFONE_GET_ALL_CARRIERS = "select distinct cg.x_carrier_name from "
            + "sa.table_x_carrier_features cf, sa.table_x_carrier c, sa.table_x_carrier_group cg "
            + "where cf.x_feature2x_carrier = c.objid and "
            + "UPPER(c.x_status) = 'ACTIVE' and "
            + "UPPER(cg.x_status) = 'ACTIVE' and "
            + "c.carrier2carrier_group = cg.objid";

    //APN
    String TRACFONE_INSERT_APN = "insert into sa.x_apn "
            + "(X_PARENT_NAME, RATE_PLAN, ORG_ID, APN, USERNAME, PASSWORD, AUTH_TYPE, "
            + "PROXY_ADDRESS, PROXY_PORT, CONNECTION_TYPE, MMS_APN, MMS_USERNAME, MMS_PASSWORD,"
            + "MMS_AUTH_TYPE, MMSC, MMS_PROXY_ADDRESS, MMS_PROXY_PORT, MMS_APN_TYPE,"
            + "RTSP_PROXY_ADDR, RTSP_PROXY_PORT) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    String TRACFONE_UPDATE_APN = "update sa.x_apn set X_PARENT_NAME = ?,RATE_PLAN = ?,ORG_ID = ?,"
            + "APN = ?,USERNAME = ?,PASSWORD = ?,AUTH_TYPE = ?,PROXY_ADDRESS = ?,PROXY_PORT = ?,"
            + "CONNECTION_TYPE = ?,MMS_APN = ?,MMS_USERNAME = ?,MMS_PASSWORD = ?,"
            + "MMS_AUTH_TYPE = ?,MMSC = ?,MMS_PROXY_ADDRESS = ?,MMS_PROXY_PORT = ?,"
            + "MMS_APN_TYPE = ?,RTSP_PROXY_ADDR = ?,RTSP_PROXY_PORT = ? "
            + "where RATE_PLAN = ? and upper(APN) = ? and upper(ORG_ID) = ? and upper(X_PARENT_NAME) = ?";

    String TRACFONE_DELETE_APN = "delete from sa.X_APN where "
            + "RATE_PLAN = ? and upper(APN) = ? and upper(ORG_ID) = ? and upper(X_PARENT_NAME) = ?";

    String TRACFONE_VIEW_APN = "select APN from sa.X_APN where "
            + "RATE_PLAN = ? and upper(APN) = ? and upper(ORG_ID) = ? and upper(X_PARENT_NAME) = ?";

    String TRACFONE_GET_RATEPLAN_APNS = "select X_PARENT_NAME,RATE_PLAN,"
            + " ORG_ID,APN,USERNAME,PASSWORD,AUTH_TYPE,PROXY_ADDRESS,"
            + "PROXY_PORT,CONNECTION_TYPE,MMS_APN,MMS_USERNAME,"
            + "MMS_PASSWORD,MMS_AUTH_TYPE,MMSC,MMS_PROXY_ADDRESS,"
            + "MMS_PROXY_PORT,MMS_APN_TYPE,RTSP_PROXY_ADDR,RTSP_PROXY_PORT "
            + "from sa.x_apn where RATE_PLAN = ?";

    // parent name in APN
    String TRACFONE_GET_ALL_PARENT_NAMES = "select distinct p.objid, p.x_parent_name, p.PARENT_SHORT_NAME, P.X_PARENT_ID "
            + "from sa.table_x_parent p, sa.table_x_carrier c, sa.table_x_carrier_group cg where c.carrier2carrier_group = cg.objid and "
            + "cg.X_CARRIER_GROUP2X_PARENT = p.objid and cg.x_carrier_name = ? and UPPER(p.x_status) = 'ACTIVE' order by p.X_PARENT_ID";

    String TRACFONE_GET_ALL_PARENT_SHORTNAMES = "select distinct p.objid, p.x_parent_name, p.PARENT_SHORT_NAME, P.X_PARENT_ID " +
            "from sa.table_x_parent p where UPPER(p.x_status) = 'ACTIVE' and p.parent_short_name is not null order by p.X_PARENT_ID";

    String TRACFONE_GET_ALL_CARRIER_IDS = "select DISTINCT C.OBJID, C.X_CARRIER_ID, C.X_MKT_SUBMKT_NAME " +
            "from sa.table_x_carrier_group cg, SA.TABLE_X_PARENT P, SA.TABLE_X_CARRIER C, sa.table_x_carrier_features cf " +
            "where UPPER(cg.x_status) = 'ACTIVE' AND " +
            "CG.X_CARRIER_GROUP2X_PARENT = P.OBJID AND " +
            "UPPER(P.X_STATUS) = 'ACTIVE' AND " +
            "C.CARRIER2CARRIER_GROUP = CG.OBJID AND " +
            "UPPER(C.X_STATUS) = 'ACTIVE' AND " +
            "cf.x_feature2x_carrier = c.objid AND " +
            "CG.X_CARRIER_NAME = ? AND " +
            "P.OBJID = ? order by C.X_CARRIER_ID";

    String TRACFONE_SEARCH_CARRIER_FEATURE_FOR_UPDATE = "select DISTINCT cf.*, mtm.*, " +
            "(select org_id from sa.table_bus_org bo where bo.objid = cf.X_FEATURES2BUS_ORG) BRAND " +
            "from sa.table_x_carrier_features cf, sa.mtm_sp_carrierfeatures mtm, sa.table_x_carrier c, sa.table_x_carrier_group cg " +
            "where cf.objid = mtm.x_carrier_features_id and cf.x_feature2x_carrier = c.objid and c.carrier2carrier_group = cg.objid and " +
            "cg.x_carrier_name = ? and ";

    String TRACFONE_SEARCH_LEGACY_CARRIER_FEATURE_FOR_UPDATE = "select DISTINCT cf.*, mtm.*, " +
            "(select org_id from sa.table_bus_org bo where bo.objid = cf.X_FEATURES2BUS_ORG) BRAND from sa.table_x_carrier_features cf, sa.mtm_sp_carrierfeatures_dflt mtm, " +
            "sa.table_x_carrier c, sa.table_x_carrier_group cg where cf.objid = mtm.x_carrier_features_id and " +
            "cf.x_feature2x_carrier = c.objid and c.carrier2carrier_group = cg.objid and cg.x_carrier_name = ? and ";

    //get all carrier feature obj id associated to profile id , profile desc & bucket id
    String TRACFONE_GET_ALL_ASSOCIATED_CARRIER_FEATURE_OBJID = " cf.objid in (select distinct el.carrier_feature_objid " +
            "from sa.x_rp_extension_link el, sa.x_rp_profile p, " +
            "sa.carrier_profile_buckets b, sa.carrier_profile_child_buckets cb " +
            "where el.profile_id = p.profile_id and " +
            "p.profile_id = b.profile_id (+) and " +
            "p.profile_id = cb.profile_id (+) and ";

    String TRACFONE_GET_CARRIER_FEATURE_OBJID_FOR_SERVICE_PLAN = " cf.objid in (select distinct el.carrier_feature_objid " +
            "from sa.x_rp_extension_link el, sa.x_rp_profile p, sa.x_rp_extension_config ec " +
            "where el.profile_id = p.profile_id and " +
            "p.profile_id = ec.profile_id (+) and ";

    String TRACFONE_SEARCH_SERVICE_PLANS = "select distinct spmv.service_plan_objid as objid, spmv.mkt_name as description, " +
            "spmv.service_plan_purchase, cg.x_carrier_name, p.x_parent_name " +
            "from sa.service_plan_feat_pivot_mv spmv, sa.table_x_carrier_group cg, " +
            "sa.table_x_carrier tc, sa.table_x_parent p, sa.table_x_carrier_features cf, sa.mtm_sp_carrierfeatures mtm " +
            "where spmv.service_plan_objid = mtm.x_service_plan_id and " +
            "mtm.x_carrier_features_id = cf.objid and " +
            "cf.x_feature2x_carrier = tc.objid and " +
            "tc.carrier2carrier_group = cg.objid and " +
            "cg.X_CARRIER_GROUP2X_PARENT = p.objid AND ";

    String TRACFONE_SEARCH_LEGACY_SERVICE_PLANS = "select distinct mtm.X_SERVICE_PLAN_ID as objid, mtm.X_SERVICE_PLAN_ID as description, cg.x_carrier_name, p.x_parent_name " +
            "from sa.table_x_carrier_group cg, sa.table_x_carrier tc, sa.table_x_parent p, sa.table_x_carrier_features cf, " +
            "sa.mtm_sp_carrierfeatures_dflt mtm where " +
            "mtm.x_carrier_features_id = cf.objid and " +
            "cf.x_feature2x_carrier = tc.objid and " +
            "tc.carrier2carrier_group = cg.objid and " +
            "cg.X_CARRIER_GROUP2X_PARENT = p.objid and ";

    String TRACFONE_GET_ALL_SERVICE_PLAN_CARRIERS = "select distinct cg.x_carrier_name from sa.table_x_carrier_features cf, " +
            "sa.table_x_carrier c, sa.table_x_carrier_group cg, sa.mtm_sp_carrierfeatures mtm where " +
            "mtm.X_SERVICE_PLAN_ID = ? and cf.x_feature2x_carrier = c.objid and UPPER(c.x_status) = 'ACTIVE' " +
            "and UPPER(cg.x_status) = 'ACTIVE' and c.carrier2carrier_group = cg.objid and cf.objid = mtm.X_CARRIER_FEATURES_ID";

    String TRACFONE_GET_ALL_LEGACY_SERVICE_PLAN_CARRIERS = "select distinct cg.x_carrier_name from sa.table_x_carrier_features cf, " +
            "sa.table_x_carrier c, sa.table_x_carrier_group cg, sa.mtm_sp_carrierfeatures_dflt mtm where " +
            "mtm.X_SERVICE_PLAN_ID = ? and cf.x_feature2x_carrier = c.objid and UPPER(c.x_status) = 'ACTIVE' " +
            "and UPPER(cg.x_status) = 'ACTIVE' and c.carrier2carrier_group = cg.objid and cf.objid = mtm.X_CARRIER_FEATURES_ID";

    String TRACFONE_GET_ALL_SERVICE_PLANS_FOR_COPY = "SELECT OBJID, mkt_name from sa.x_service_plan where OBJID not in " +
            "(select distinct mtm.X_SERVICE_PLAN_ID from sa.mtm_sp_carrierfeatures mtm, " +
            "sa.table_x_carrier_features cf, sa.table_x_carrier c, sa.table_x_carrier_group cg " +
            "where mtm.x_carrier_features_id = cf.objid and " +
            "cf.x_feature2x_carrier = c.objid and " +
            "c.carrier2carrier_group = cg.objid and cg.x_carrier_name = ?) order by objid";

    String TRACFONE_GET_ALL_LEGACY_SERVICE_PLANS_FOR_COPY = "select distinct x_service_plan_id as objid, x_service_plan_id as mkt_name " +
            "from sa.mtm_sp_carrierfeatures_dflt mtm " +
            "where x_carrier_features_id is null or x_service_plan_id not in " +
            "(select distinct mtm.X_SERVICE_PLAN_ID from sa.mtm_sp_carrierfeatures_dflt mtm, sa.table_x_carrier_features cf, sa.table_x_carrier c, sa.table_x_carrier_group cg " +
            "where mtm.x_carrier_features_id = cf.objid and cf.x_feature2x_carrier = c.objid and c.carrier2carrier_group = cg.objid and cg.x_carrier_name = ?) order by x_service_plan_id desc";

    String TRACFONE_DUMMY_LEGACY_PLANS_FROM_MTM = "DELETE FROM sa.mtm_sp_carrierfeatures_dflt mtm " +
            "WHERE MTM.x_service_plan_id = ? AND MTM.x_carrier_features_id IS NULL";

    String TRACFONE_INSERT_ANCILLARY_CODE_CONFIG = "insert into sa.x_rp_ancillary_code_config "
            + "(FEATURE_NAME, FEATURE_REQUIREMENT, TOGGLE_FLAG, NOTES, RESTRICT_SUI_FLAG, DISPLAY_SUI_FLAG, EXTENSION_OBJID, PROFILE_ID, FEATURE_VALUE) " +
            "values (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    String TRACFONE_UPDATE_ANCILLARY_CODE_CONFIG = "UPDATE sa.x_rp_ancillary_code_config "
            + "SET FEATURE_NAME = ?, FEATURE_REQUIREMENT = ?, TOGGLE_FLAG = ?, NOTES = ?, RESTRICT_SUI_FLAG = ?, DISPLAY_SUI_FLAG = ? " +
            "WHERE EXTENSION_OBJID = ? and PROFILE_ID = ? and FEATURE_VALUE = ?";

    String TRACFONE_DELETE_ANCILLARY_CODE_CONFIG = "DELETE sa.x_rp_ancillary_code_config where " +
            "EXTENSION_OBJID = ? and PROFILE_ID = ? and FEATURE_VALUE = ?";

    String TRACFONE_GET_ANCILLARY_CODE_CONFIG = "select EXTENSION_OBJID, PROFILE_ID, FEATURE_NAME, FEATURE_VALUE, FEATURE_REQUIREMENT," +
            " TOGGLE_FLAG, NOTES, RESTRICT_SUI_FLAG, DISPLAY_SUI_FLAG from sa.x_rp_ancillary_code_config where " +
            "EXTENSION_OBJID = ? and PROFILE_ID = ?";

    String TRACFONE_COUNT_BUCKETS_BY_LINK_OBJID = "select count(1) from sa.carrier_profile_buckets where service_plan_id = ? and profile_id in " +
            "(select profile_id from sa.x_rp_extension_link where objid in (?";

    String TRACFONE_COUNT_CHILD_BUCKETS_BY_LINK_OBJID = "select count(1) from sa.carrier_profile_child_buckets where service_plan_id = ? and profile_id in " +
            "(select profile_id from sa.x_rp_extension_link where objid in (?";

    String TRACFONE_COUNT_BUCKETS_BY_SP = "select count(1) from sa.carrier_profile_buckets where service_plan_id = ? and profile_id in (";

    String TRACFONE_COUNT_CHILD_BUCKETS_BY_SP = "select count(1) from sa.carrier_profile_child_buckets where service_plan_id = ? and profile_id in (";

    String TRACFONE_INSERT_ANCILLARY_CODE_DISCOUNT = "insert into sa.x_rp_ancillary_code_discount "
            + "(BRM_EQUIVALENT, ANCILLARY_CODE, INSERT_TIMESTAMP, UPDATE_TIMESTAMP) values (?, ?, sysdate, sysdate)";

    String TRACFONE_DELETE_ANCILLARY_CODE_DISCOUNT = "delete from sa.x_rp_ancillary_code_discount where " +
            "BRM_EQUIVALENT = ? and ANCILLARY_CODE = ?";

    String TRACFONE_UPDATE_ANCILLARY_CODE_DISCOUNT = "update sa.x_rp_ancillary_code_discount set UPDATE_TIMESTAMP = sysdate, BRM_EQUIVALENT = ? " +
            "where ANCILLARY_CODE = ? and BRM_EQUIVALENT = ?";

    String TRACFONE_SEARCH_ANCILLARY_CODE_DISCOUNT = "select ANCILLARY_CODE, BRM_EQUIVALENT from sa.x_rp_ancillary_code_discount where ";

    String TRACFONE_COUNT_ANCILLARY_CODE_DISCOUNT_DEPENDENCIES = "select count(distinct PROFILE_ID) from X_RP_EXTENSION_LINK where RP_EXTENSION_OBJID in " +
            "(select objid from X_RP_extension where ANCILLARY_CODE = ?)";

    String TRACFONE_GET_IG_BUCKET_RATE_PLANS = "select OBJID, X_RATE_PLAN from SA.X_RATE_PLAN WHERE X_RATE_PLAN IN " +
            "(SELECT RATE_PLAN FROM GW1.IG_BUCKETS) ORDER BY X_RATE_PLAN";

    String TRACFONE_GET_BUCKET_LIST_BY_BUCKET_IDS = "select BUCKET_ID from sa.BUCKET_LIST where BUCKET_ID in (? ";

    String TRACFONE_INSERT_BUCKET_LIST = "insert into sa.BUCKET_LIST "
            + "(BUCKET_ID, DESCRIPTION, ACTIVE_FLAG, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, PARENT_SHORT_NAME) values (?, ?, ?, sysdate, sysdate, ?)";

    String TRACFONE_UPDATE_BUCKET_LIST = "update sa.BUCKET_LIST set DESCRIPTION = ?, ACTIVE_FLAG = ?, " +
            "PARENT_SHORT_NAME = ?, UPDATE_TIMESTAMP = sysdate where BUCKET_ID = ? ";

    String TRACFONE_SEARCH_BUCKET_LIST = "select DESCRIPTION, ACTIVE_FLAG, PARENT_SHORT_NAME, BUCKET_ID from sa.bucket_list where ";

    String TRACFONE_COUNT_BUCKET_LIST_DEPENDENCIES = "SELECT COUNT(1) FROM gw1.ig_buckets where bucket_id = ? " +
            "UNION ALL SELECT  COUNT(1) FROM sa.carrier_profile_buckets where bucket_id = ? " +
            "UNION ALL SELECT COUNT(1) FROM sa.CARRIER_PROFILE_CHILD_BUCKETS where bucket_id = ?";

    String TRACFONE_DELETE_BUCKET_LIST = "delete from sa.BUCKET_LIST where BUCKET_ID = ? ";

    String TRACFONE_INSERT_MULTI_RATE_PLAN_ESNS = "insert into sa.X_MULTI_RATE_PLAN_ESNS(X_PRIORITY, X_DATE_ADDED, X_REASON, X_PRODUCT_ID, DEL_FLAG, X_ESN, X_SERVICE_PLAN_ID)"
            + " values (?, sysdate, ?, ?, ?, ?, ?)";

    String TRACFONE_UPDATE_MULTI_RATE_PLAN_ESNS = "update sa.X_MULTI_RATE_PLAN_ESNS set X_PRIORITY = ?, " +
            "X_REASON = ?, X_PRODUCT_ID = ?, DEL_FLAG = ? where X_ESN = ? and X_SERVICE_PLAN_ID = ?";

    String TRACFONE_DELETE_MULTI_RATE_PLAN_ESNS = "delete from sa.X_MULTI_RATE_PLAN_ESNS where X_ESN = ? and X_SERVICE_PLAN_ID = ?";

    String TRACFONE_SEARCH_MULTI_RATE_PLAN_ESNS = "select X_ESN, X_PRIORITY, X_SERVICE_PLAN_ID, X_REASON, DEL_FLAG, X_PRODUCT_ID from sa.X_MULTI_RATE_PLAN_ESNS where ";

    String TRACFONE_DUPLICATE_BUCKET_ID_CHECK = "select COUNT(1) from sa.bucket_list WHERE BUCKET_ID = ?";

    // Carrier Maintenance
    String TRACFONE_SEARCH_CARRIER_GROUPS = "SELECT OBJID, X_CARRIER_GROUP_ID, X_CARRIER_NAME, " +
            "X_GROUP2ADDRESS, X_STATUS, X_CARRIER_GROUP2X_PARENT, X_NO_AUTO_PORT FROM sa.table_x_carrier_group " +
            "WHERE ";

    String TRACFONE_SEARCH_DUPLICATE_CARRIER_GROUPS = "SELECT X_CARRIER_GROUP_ID FROM sa.table_x_carrier_group " +
            "WHERE X_CARRIER_GROUP_ID in (?";

    String TRACFONE_SEARCH_ORDER_TYPES = "SELECT OBJID, X_ORDER_TYPE, X_NPA, X_NXX, X_BILL_CYCLE, X_DEALER_CODE, X_LD_ACCOUNT_NUM, " +
            "X_MARKET_CODE, X_ORDER_TYPE2X_TRANS_PROFILE, X_ORDER_TYPE2X_CARRIER FROM sa.TABLE_X_ORDER_TYPE WHERE ";

    String TRACFONE_SEARCH_CARRIER_RULES = "SELECT OBJID, X_COOLING_PERIOD, X_ESN_CHANGE_FLAG, X_LINE_EXPIRE_DAYS, X_NPA_NXX_FLAG, " +
            "X_LINE_RETURN_DAYS, X_COOLING_AFTER_INSERT, X_NPA_NXX_FLAG, X_USED_LINE_EXPIRE_DAYS, X_GSM_GRACE_PERIOD, " +
            "X_TECHNOLOGY, X_RESERVE_ON_SUSPEND, X_RESERVE_PERIOD, X_DEAC_AFTER_GRACE, X_CANCEL_SUSPEND_DAYS, X_CANCEL_SUSPEND, " +
            "X_BLOCK_CREATE_ACT_ITEM, X_ALLOW_2G_ACT, X_ALLOW_2G_REACT, ALLOW_NON_HD_ACTS, ALLOW_NON_HD_REACTS FROM sa.TABLE_X_CARRIER_RULES WHERE ";

    String TRACFONE_SEARCH_PARENT = "select OBJID, X_PARENT_NAME, X_PARENT_ID, X_STATUS, X_HOLD_ANALOG_DEAC, X_HOLD_DIGITAL_DEAC, " +
            "X_PARENT2TEMP_QUEUE, X_NO_INVENTORY, X_VM_ACCESS_NUM, X_AUTO_PORT_IN, X_AUTO_PORT_OUT, X_NO_MSID, X_OTA_CARRIER, " +
            "X_OTA_END_DATE, X_OTA_PSMS_ADDRESS, X_OTA_START_DATE, X_NEXT_AVAILABLE, X_QUEUE_NAME, X_BLOCK_PORT_IN, " +
            "X_MEID_CARRIER, X_OTA_REACT, X_AGG_CARR_CODE, SUI_RULE_OBJID, DEACT_SIM_EXP_DAYS, OVERRIDE_SMS_ADDRESS, " +
            "TRIGGER_ID, PARENT_SHORT_NAME from sa.table_x_parent where ";

    String TRACFONE_SEARCH_CARRIER = "select OBJID, X_CARRIER_ID, X_MKT_SUBMKT_NAME, X_SUBMKT_OF, X_CITY, X_STATE, " +
            "X_TAPERETURN_CHARGE, X_COUNTRY_CODE, X_ACTIVELINE_PERCENT, X_STATUS, X_LD_PROVIDER, X_LD_ACCOUNT, X_LD_PIC_CODE, " +
            "X_RATE_PLAN, X_DUMMY_ESN, X_BILL_DATE, X_VOICEMAIL, X_VM_CODE, X_VM_PACKAGE, X_CALLER_ID, X_ID_CODE, X_ID_PACKAGE, " +
            "X_CALL_WAITING, X_CW_CODE, X_CW_PACKAGE, X_REACT_TECHNOLOGY, X_REACT_ANALOG, X_ACT_TECHNOLOGY, X_ACT_ANALOG, " +
            "X_DIGITAL_RATE_PLAN, X_DIGITAL_FEATURE, X_PRL_PRELOADED, CARRIER2CARRIER_GROUP, TAPERETURN_ADDR2ADDRESS, " +
            "CARRIER2PROVIDER, X_CARRIER2ADDRESS, CARRIER2PERSONALITY, CARRIER2RULES, CARRIER2X_CARR_SCRIPT, X_SPECIAL_MKT, " +
            "X_NEW_ANALOG_PLAN, X_NEW_DIGITAL_PLAN, X_SMS, X_SMS_CODE, X_SMS_PACKAGE, X_VM_SETUP_LAND_LINE, CARRIER2RULES_CDMA, " +
            "CARRIER2RULES_GSM, CARRIER2RULES_TDMA, X_DATA_SERVICE, X_AUTOMATED from sa.table_x_carrier where ";

    String TRACFONE_SEARCH_DUPLICATE_CARRIERS = "select X_CARRIER_ID from sa.table_x_carrier where X_CARRIER_ID in (?";

    // Data Config Mapping
    String TRACFONE_SEARCH_DATA_CONFIG_MAPPING = "select X_PARENT_ID, X_PART_CLASS_OBJID, X_RATE_PLAN, X_DATA_CONFIG_OBJID " +
            "from sa.data_config_mapping where ";

    String TRACFONE_INSERT_DATA_CONFIG_MAPPING = "insert into sa.data_config_mapping "
            + "(X_PARENT_ID, X_PART_CLASS_OBJID, X_RATE_PLAN, X_DATA_CONFIG_OBJID) values (?, ?, ?, ?)";

    String TRACFONE_DUPLICATE_DATA_CONFIG_MAPPING_CHECK = "select COUNT(1) from sa.data_config_mapping WHERE X_PARENT_ID = ? " +
            "and X_PART_CLASS_OBJID = ? and X_RATE_PLAN = ? and X_DATA_CONFIG_OBJID = ?";

    String TRACFONE_DELETE_DATA_CONFIG_MAPPING = "delete from sa.data_config_mapping where X_PARENT_ID = ? " +
            "and X_PART_CLASS_OBJID = ? and X_RATE_PLAN = ? and X_DATA_CONFIG_OBJID = ?";

    String TRACFONE_UPDATE_DATA_CONFIG_MAPPING = "update sa.data_config_mapping set X_PARENT_ID = ? " +
            ", X_PART_CLASS_OBJID = ? , X_RATE_PLAN = ? , X_DATA_CONFIG_OBJID = ? where " +
            "X_PARENT_ID = ? and X_PART_CLASS_OBJID = ? and X_RATE_PLAN = ? and X_DATA_CONFIG_OBJID = ?";

    String TRACFONE_UPDATE_PARENT = "update sa.table_x_parent set X_PARENT_NAME = ?, X_PARENT_ID = ?, X_STATUS = ?, X_HOLD_ANALOG_DEAC = ?, X_HOLD_DIGITAL_DEAC = ?, " +
            "X_PARENT2TEMP_QUEUE = ?, X_NO_INVENTORY = ?, X_VM_ACCESS_NUM = ?, X_AUTO_PORT_IN = ?, X_AUTO_PORT_OUT = ?, X_NO_MSID = ?, X_OTA_CARRIER = ?, " +
            "X_OTA_PSMS_ADDRESS = ?, X_NEXT_AVAILABLE = ?, X_QUEUE_NAME = ?, X_BLOCK_PORT_IN = ?, " +
            "X_MEID_CARRIER = ?, X_OTA_REACT = ?, X_AGG_CARR_CODE = ?, SUI_RULE_OBJID = ?, DEACT_SIM_EXP_DAYS = ?, OVERRIDE_SMS_ADDRESS = ?, " +
            "TRIGGER_ID = ?, PARENT_SHORT_NAME = ?, X_OTA_START_DATE = ?, X_OTA_END_DATE = ? where objid = ?";

    String TRACFONE_UPDATE_CARRIER_GROUP = "update sa.table_x_carrier_group set X_CARRIER_GROUP_ID = ?, X_CARRIER_NAME = ?, " +
            "X_GROUP2ADDRESS = ?, X_STATUS = ?, X_CARRIER_GROUP2X_PARENT = ?, X_NO_AUTO_PORT = ? where objid = ? ";

    String TRACFONE_UPDATE_CARRIER = "update sa.table_x_carrier set X_CARRIER_ID = ?, X_MKT_SUBMKT_NAME = ?, X_SUBMKT_OF = ?, " +
            "X_CITY = ?, X_STATE = ?, X_TAPERETURN_CHARGE = ?, X_COUNTRY_CODE = ?, X_ACTIVELINE_PERCENT = ?, X_STATUS = ?, " +
            "X_LD_PROVIDER = ?, X_LD_ACCOUNT = ?, X_LD_PIC_CODE = ?, X_RATE_PLAN = ?, X_DUMMY_ESN = ?, X_VOICEMAIL = ?, " +
            "X_VM_CODE = ?, X_VM_PACKAGE = ?, X_CALLER_ID = ?, X_ID_CODE = ?, X_ID_PACKAGE = ?, X_CALL_WAITING = ?, " +
            "X_CW_CODE = ?, X_CW_PACKAGE = ?, X_REACT_TECHNOLOGY = ?, X_REACT_ANALOG = ?, X_ACT_TECHNOLOGY = ?, " +
            "X_ACT_ANALOG = ?, X_DIGITAL_RATE_PLAN = ?, X_DIGITAL_FEATURE = ?, X_PRL_PRELOADED = ?, CARRIER2CARRIER_GROUP = ?, " +
            "TAPERETURN_ADDR2ADDRESS = ?, CARRIER2PROVIDER = ?, X_CARRIER2ADDRESS = ?, CARRIER2PERSONALITY = ?, CARRIER2RULES = ?," +
            " CARRIER2X_CARR_SCRIPT = ?, X_SPECIAL_MKT = ?, X_NEW_ANALOG_PLAN = ?, X_NEW_DIGITAL_PLAN = ?, X_SMS = ?, " +
            "X_SMS_CODE = ?, X_SMS_PACKAGE = ?, X_VM_SETUP_LAND_LINE = ?, CARRIER2RULES_CDMA = ?, CARRIER2RULES_GSM = ?, " +
            "CARRIER2RULES_TDMA = ?, X_DATA_SERVICE = ?, X_AUTOMATED = ?, X_BILL_DATE = ? where OBJID = ? ";

    String TRACFONE_UPDATE_CARRIER_RULE = "update sa.TABLE_X_CARRIER_RULES set X_COOLING_PERIOD = ?, X_ESN_CHANGE_FLAG = ?, " +
            "X_LINE_EXPIRE_DAYS = ?, X_LINE_RETURN_DAYS = ?, X_COOLING_AFTER_INSERT = ?, X_NPA_NXX_FLAG = ?, " +
            "X_USED_LINE_EXPIRE_DAYS = ?, X_GSM_GRACE_PERIOD = ?, X_TECHNOLOGY = ?, X_RESERVE_ON_SUSPEND = ?, " +
            "X_RESERVE_PERIOD = ?, X_DEAC_AFTER_GRACE = ?, X_CANCEL_SUSPEND_DAYS = ?, X_CANCEL_SUSPEND = ?, " +
            "X_BLOCK_CREATE_ACT_ITEM = ?, X_ALLOW_2G_ACT = ?, X_ALLOW_2G_REACT = ?, ALLOW_NON_HD_ACTS = ?," +
            " ALLOW_NON_HD_REACTS = ? where objid = ?";

    String TRACFONE_UPDATE_ORDER_TYPE = "update sa.TABLE_X_ORDER_TYPE set X_ORDER_TYPE = ?, X_NPA = ?, X_NXX = ?, " +
            "X_BILL_CYCLE = ?, X_DEALER_CODE = ?, X_LD_ACCOUNT_NUM = ?, X_MARKET_CODE = ?, X_ORDER_TYPE2X_TRANS_PROFILE = ?, " +
            "X_ORDER_TYPE2X_CARRIER = ? where objid = ?";

    String TRACFONE_DELETE_ORDER_TYPE = "delete from sa.TABLE_X_ORDER_TYPE where objid = ?";

    String TRACFONE_PARENT_SEQ_STMT = "SELECT sa.SEQU_X_PARENT.nextval AS TABLE_X_PARENT_OBJID_SEQ FROM DUAL";

    String TRACFONE_CARRIER_GROUP_SEQ_STMT = "SELECT sa.SEQU_CARRIER_GROUP_ID.nextval AS CARRIER_GROUP_OBJID_SEQ FROM DUAL";

    String TRACFONE_CARRIER_SEQ_STMT = "SELECT sa.SEQU_X_CARRIER.nextval AS CARRIER_OBJID_SEQ FROM DUAL";

    String TRACFONE_CARRIER_RULE_SEQ_STMT = "SELECT sa.SEQU_X_CARRIER_RULES.nextval AS CARRIER_RULE_OBJID_SEQ FROM DUAL";

    String TRACFONE_ORDER_TYPE_SEQ_STMT = "SELECT sa.SEQU_X_ORDER_TYPE.nextval AS ORDER_TYPE_OBJID_SEQ FROM DUAL";

    String TRACFONE_INSERT_PARENT = "insert into sa.table_x_parent (X_PARENT_NAME, X_PARENT_ID , X_STATUS, X_HOLD_ANALOG_DEAC, X_HOLD_DIGITAL_DEAC, " +
            "X_PARENT2TEMP_QUEUE, X_NO_INVENTORY, X_VM_ACCESS_NUM, X_AUTO_PORT_IN, X_AUTO_PORT_OUT, X_NO_MSID, X_OTA_CARRIER, " +
            "X_OTA_PSMS_ADDRESS, X_NEXT_AVAILABLE, X_QUEUE_NAME, X_BLOCK_PORT_IN, " +
            "X_MEID_CARRIER, X_OTA_REACT, X_AGG_CARR_CODE, SUI_RULE_OBJID, DEACT_SIM_EXP_DAYS, OVERRIDE_SMS_ADDRESS, " +
            "TRIGGER_ID, PARENT_SHORT_NAME, X_OTA_START_DATE, X_OTA_END_DATE, OBJID) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    String TRACFONE_INSERT_CARRIER = "insert into  sa.table_x_carrier (X_CARRIER_ID, X_MKT_SUBMKT_NAME, X_SUBMKT_OF, " +
            "X_CITY, X_STATE, X_TAPERETURN_CHARGE, X_COUNTRY_CODE, X_ACTIVELINE_PERCENT, X_STATUS, " +
            "X_LD_PROVIDER, X_LD_ACCOUNT, X_LD_PIC_CODE, X_RATE_PLAN, X_DUMMY_ESN, X_VOICEMAIL, " +
            "X_VM_CODE, X_VM_PACKAGE, X_CALLER_ID, X_ID_CODE, X_ID_PACKAGE, X_CALL_WAITING, " +
            "X_CW_CODE, X_CW_PACKAGE, X_REACT_TECHNOLOGY, X_REACT_ANALOG, X_ACT_TECHNOLOGY, " +
            "X_ACT_ANALOG, X_DIGITAL_RATE_PLAN, X_DIGITAL_FEATURE, X_PRL_PRELOADED, CARRIER2CARRIER_GROUP, " +
            "TAPERETURN_ADDR2ADDRESS, CARRIER2PROVIDER, X_CARRIER2ADDRESS, CARRIER2PERSONALITY, CARRIER2RULES," +
            " CARRIER2X_CARR_SCRIPT, X_SPECIAL_MKT, X_NEW_ANALOG_PLAN, X_NEW_DIGITAL_PLAN, X_SMS, " +
            "X_SMS_CODE, X_SMS_PACKAGE, X_VM_SETUP_LAND_LINE, CARRIER2RULES_CDMA, CARRIER2RULES_GSM, " +
            "CARRIER2RULES_TDMA, X_DATA_SERVICE, X_AUTOMATED, X_BILL_DATE, OBJID) " +
            "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, " +
            "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";

    String TRACFONE_INSERT_CARRIER_RULE = "insert into sa.TABLE_X_CARRIER_RULES (X_COOLING_PERIOD, X_ESN_CHANGE_FLAG, " +
            "X_LINE_EXPIRE_DAYS, X_LINE_RETURN_DAYS, X_COOLING_AFTER_INSERT, X_NPA_NXX_FLAG, " +
            "X_USED_LINE_EXPIRE_DAYS, X_GSM_GRACE_PERIOD, X_TECHNOLOGY, X_RESERVE_ON_SUSPEND, " +
            "X_RESERVE_PERIOD, X_DEAC_AFTER_GRACE, X_CANCEL_SUSPEND_DAYS, X_CANCEL_SUSPEND, " +
            "X_BLOCK_CREATE_ACT_ITEM, X_ALLOW_2G_ACT, X_ALLOW_2G_REACT, ALLOW_NON_HD_ACTS," +
            " ALLOW_NON_HD_REACTS, objid) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    String TRACFONE_INSERT_CARRIER_GROUP = "insert into sa.table_x_carrier_group (X_CARRIER_GROUP_ID, X_CARRIER_NAME, " +
            "X_GROUP2ADDRESS, X_STATUS, X_CARRIER_GROUP2X_PARENT, X_NO_AUTO_PORT, objid) values ( ?, ?, ?, ?, ?, ?, ?)";

    String TRACFONE_INSERT_ORDER_TYPE = "insert into sa.TABLE_X_ORDER_TYPE (X_ORDER_TYPE, X_NPA, X_NXX, " +
            "X_BILL_CYCLE, X_DEALER_CODE, X_LD_ACCOUNT_NUM, X_MARKET_CODE, X_ORDER_TYPE2X_TRANS_PROFILE, " +
            "X_ORDER_TYPE2X_CARRIER, objid) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    String TRACFONE_SEARCH_DATA_CONFIGS = "SELECT OBJID, DEV, X_PARENT_ID, X_PART_CLASS_OBJID, X_DEFAULT, X_IP_ADDRESS, X_APN, " +
            "X_HOMEPAGE, X_MMSC, CMD_148_CARRIER_DATA_SWITCH, X_DATA_SWITCH, CMD_71_GPRS_APN, CMD_150_CLEAR_PROXY, " +
            "CMD_121_GATEWAY_PORT_UPDATE, CMD_121_GATEWAY_IP_UPDATE, CMD_71_MMSC_UPDATE, CMD_71_GATEWAY_HOME, " +
            "CMD_121_GATEWAY_IP_PORT_UPDATE FROM sa.TABLE_X_DATA_CONFIG where ";

    String TRACFONE_GET_ALL_PART_CLASSES = "select OBJID, NAME from sa.TABLE_PART_CLASS";

    // X_IG_ORDER_TYPE
    String TRACFONE_INSERT_IG_ORDER_TYPES = "insert into sa.X_IG_ORDER_TYPE (X_ACTUAL_ORDER_TYPE , X_SQL_TEXT, " +
            "CREATE_SO_GENCODE_FLAG, CREATE_MFORM_IG_FLAG, CREATE_MFORM_PORT_FLAG, SKIP_MIN_VALIDATION_FLAG, " +
            "SKIP_ESN_VALIDATION_FLAG, CREATE_IG_APN_FLAG, INSERT_ILD_TRANS_FLAG, " +
            "X_BOGO_CONFIG_FLAG, SUI_ACTION_TYPE, UPDATE_MSID_FLAG, ADDON_CASH_CARD_FLAG, CONTACT_PIN_UPDATE_FLAG, " +
            "BRM_NOTIFICATION_FLAG, NEWER_TRANS_FLAG, SKIP_MIN_UPDATE_FLAG, SAFELINK_BATCH_FLAG, CREATE_BUCKETS_FLAG, " +
            "PROCESS_IGATE_IN3_FLAG, PROCESS_IGATE_IN3_LITE_FLAG, UPDATE_X_CASE2TASK_FLAG, DEP_IG_TRANS_FLAG, " +
            "GENERATE_ACCOUNT_FLAG, CREATE_IG_ACM_FLAG, X_PROGRAMME_NAME, X_IG_ORDER_TYPE, X_PRIORITY)" +
            " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    String TRACFONE_SEARCH_IG_ORDER_TYPES = "select * from sa.X_IG_ORDER_TYPE where ";

    String TRACFONE_SEARCH_ALL_IG_ORDER_TYPES = "select DISTINCT X_IG_ORDER_TYPE from X_IG_ORDER_TYPE ORDER BY X_IG_ORDER_TYPE";

    String TRACFONE_VIEW_IG_ORDER_TYPES = "select x_programme_name from sa.X_IG_ORDER_TYPE where "
            + "upper(x_programme_name) = ? and upper(x_ig_order_type) = ? and x_priority = ?";

    String TRACFONE_UPDATE_IG_ORDER_TYPES = "update sa.X_IG_ORDER_TYPE set X_ACTUAL_ORDER_TYPE = ?, X_SQL_TEXT = ?, " +
            "CREATE_SO_GENCODE_FLAG = ?, CREATE_MFORM_IG_FLAG = ?, CREATE_MFORM_PORT_FLAG = ?, SKIP_MIN_VALIDATION_FLAG = ?, " +
            "SKIP_ESN_VALIDATION_FLAG = ?, CREATE_IG_APN_FLAG = ?, INSERT_ILD_TRANS_FLAG = ?," +
            " X_BOGO_CONFIG_FLAG = ?, SUI_ACTION_TYPE = ?, UPDATE_MSID_FLAG = ?, ADDON_CASH_CARD_FLAG = ?, " +
            "CONTACT_PIN_UPDATE_FLAG = ?, BRM_NOTIFICATION_FLAG = ?, NEWER_TRANS_FLAG = ?, SKIP_MIN_UPDATE_FLAG = ?, " +
            "SAFELINK_BATCH_FLAG = ?, CREATE_BUCKETS_FLAG = ?, PROCESS_IGATE_IN3_FLAG = ?, PROCESS_IGATE_IN3_LITE_FLAG = ?, " +
            "UPDATE_X_CASE2TASK_FLAG = ?, DEP_IG_TRANS_FLAG = ?, GENERATE_ACCOUNT_FLAG = ?, CREATE_IG_ACM_FLAG = ?" +
            " where X_PROGRAMME_NAME = ? and X_IG_ORDER_TYPE = ? and X_PRIORITY = ?";

    // THROTTLE POLICY, RULES and FEATURES
    String TRACFONE_INSERT_THROTTLE_POLICY = "insert into W3CI.TABLE_X_THROTTLING_POLICY"
            + "(X_POLICY_NAME, X_POLICY_DESCRIPTION, X_BYPASS_TRANS_QUEUE, DATA_SUSPENDED_FLAG, OBJID) "
            + "values (?, ?, ?, ?, ?)";

    String THROTTLE_POLICY_ID_SEQ_STMT = "SELECT W3CI.SEQU_X_THROTTLING_POLICY.nextval AS THROTTLE_POLICY_ID_SEQ FROM DUAL";

    String TRACFONE_INSERT_THROTTLE_RULE = "insert into W3CI.TABLE_X_THROTTLING_RULE"
            + "(X_PARENT_ID, X_POLICY_ID, X_RULE_DESCRIPTION, X_STATUS, X_CREATION_DATE, OBJID) "
            + "values (?, ?, ?, ?, sysdate, ?)";

    String THROTTLE_RULE_ID_SEQ_STMT = "SELECT W3CI.SEQU_X_THROTTLING_RULE.nextval AS THROTTLE_RULE_ID_SEQ FROM DUAL";

    String TRACFONE_INSERT_THROTTLE_FEATURE = "insert into W3CI.TABLE_X_THROTTLING_FEATURES"
            + "(X_RULE_ID, X_FEATURE_FLAG_NAME, X_FEATURE_FLAG_VALUE, X_FEATURE_NAME, X_FEATURE_VALUE, X_STATUS, OBJID) "
            + "values (?, ?, ?, ?, ?, ?, ?)";

    String THROTTLE_FEATURE_ID_SEQ_STMT = "SELECT W3CI.SEQU_X_THROTTLING_FEATURES.nextval AS THROTTLE_FEATURE_ID_SEQ FROM DUAL";

    String TRACFONE_SEARCH_THROTTLE_POLICY = "select * from W3CI.TABLE_X_THROTTLING_POLICY where ";

    String TRACFONE_SEARCH_THROTTLE_RULE = "select tr.* from W3CI.TABLE_X_THROTTLING_RULE tr";

    String TRACFONE_SEARCH_THROTTLE_FEATURES = "select * from W3CI.TABLE_X_THROTTLING_FEATURES where ";

    String TRACFONE_UPDATE_THROTTLE_POLICY = "update W3CI.TABLE_X_THROTTLING_POLICY set X_POLICY_NAME = ?, X_POLICY_DESCRIPTION = ?, " +
            "X_BYPASS_TRANS_QUEUE = ?, DATA_SUSPENDED_FLAG = ? where OBJID = ? ";

    String TRACFONE_UPDATE_THROTTLE_RULE = "update W3CI.TABLE_X_THROTTLING_RULE set X_PARENT_ID = ?, " +
            "X_POLICY_ID = ?, X_RULE_DESCRIPTION = ?, X_STATUS = ? where OBJID = ? ";

    String TRACFONE_UPDATE_THROTTLE_FEATURE = "update W3CI.TABLE_X_THROTTLING_FEATURES set X_RULE_ID = ?,  X_FEATURE_FLAG_NAME = ?, " +
            "X_FEATURE_FLAG_VALUE = ?, X_FEATURE_NAME = ?, X_FEATURE_VALUE = ?, X_STATUS = ? where OBJID = ? ";

    String TRACFONE_SEARCH_VERIZON_ZIP_NPANXX = "select ZIP, NPA, NXX, NPANXX, ACCOUNT_NUM, TEMPLATE from sa.X_VERIZON_ZIP_NPANXX where ";

    String TRACFONE_UPDATE_VERIZON_ZIP_NPANXX = "update sa.X_VERIZON_ZIP_NPANXX set ZIP = ?,  NPA = ?, " +
            "NXX = ?, NPANXX = ?, ACCOUNT_NUM = ?, TEMPLATE = ? where ZIP = ? and NPANXX = ? and ACCOUNT_NUM = ? ";

    String TRACFONE_INSERT_VERIZON_ZIP_NPANXX = "insert into sa.X_VERIZON_ZIP_NPANXX(ZIP, NPA, NXX, NPANXX, ACCOUNT_NUM, TEMPLATE)"
            + " values (?, ?, ?, ?, ?, ?)";

    String TRACFONE_DELETE_VERIZON_ZIP_NPANXX = "delete from sa.X_VERIZON_ZIP_NPANXX where ZIP = ? " +
            "and NPANXX = ? and ACCOUNT_NUM = ?";

    String TRACFONE_SEARCH_TMO_ZIP_NGP = "select X_ZIP, X_NGP, X_NGP_NAME, X_PRIORITY from sa.x_tmo_zip_ngp where ";

    String TRACFONE_INSERT_TMO_ZIP_NGP = "insert into sa.x_tmo_zip_ngp(X_ZIP, X_NGP, X_NGP_NAME, X_PRIORITY)"
            + " values (?, ?, ?, ?)";

    String TRACFONE_UPDATE_TMO_ZIP_NGP = "update sa.x_tmo_zip_ngp set X_ZIP = ?,  X_NGP = ?, " +
            "X_NGP_NAME = ?, X_PRIORITY = ? where X_ZIP = ? and X_PRIORITY = ? ";

    String TRACFONE_DELETE_TMO_ZIP_NGP = "delete from sa.x_tmo_zip_ngp where X_ZIP = ? " +
            "and X_PRIORITY = ? ";

    String TRACFONE_SEARCH_CINGULAR_MRKT_INFO = "select * from sa.X_CINGULAR_MRKT_INFO where ";

    String TRACFONE_INSERT_CINGULAR_MRKT_INFO = "insert into sa.X_CINGULAR_MRKT_INFO(MKT, NPA, NXX, NPANXX, RC_NUMBER, RC_NAME, RC_STATE, ZIP, MKT_TYPE, ACCOUNT_NUM, " +
            "MARKET_CODE, DEALER_CODE, SUBMARKETID, TEMPLATE) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    String TRACFONE_UPDATE_CINGULAR_MRKT_INFO = "update sa.X_CINGULAR_MRKT_INFO set MKT = ?, RC_NUMBER = ?, RC_NAME = ?, RC_STATE = ?, " +
            "ZIP = ?, MKT_TYPE = ?, ACCOUNT_NUM = ?, MARKET_CODE = ?, DEALER_CODE = ?, SUBMARKETID = ?, TEMPLATE = ? where ZIP = ?";

    String TRACFONE_DELETE_CINGULAR_MRKT_INFO = "delete from sa.X_CINGULAR_MRKT_INFO where ZIP = ? ";

    String TRACFONE_SEARCH_NOT_CERTIFY_MODEL = "select OBJID,DEV,X_PARENT_ID,X_PART_CLASS_OBJID from sa.TABLE_X_NOT_CERTIFY_MODELS where ";

    String TRACFONE_INSERT_NOT_CERTIFY_MODEL = "insert into sa.TABLE_X_NOT_CERTIFY_MODELS(OBJID, DEV, X_PARENT_ID, X_PART_CLASS_OBJID) values (?, ?, ?, ?)";

    String TRACFONE_UPDATE_NOT_CERTIFY_MODEL = "update sa.TABLE_X_NOT_CERTIFY_MODELS set DEV = ?, X_PARENT_ID = ?, X_PART_CLASS_OBJID = ? where OBJID = ?";

    String TRACFONE_DELETE_NOT_CERTIFY_MODEL = "delete from sa.TABLE_X_NOT_CERTIFY_MODELS where OBJID = ? ";

    String SEQU_X_NOT_CERTIFY_MODELS_STMT = "SELECT SA.SEQU_X_NOT_CERTIFY_MODELS.nextval AS SEQU_X_NOT_CERTIFY_MODELS_SEQ FROM DUAL";

    String TRACFONE_SEARCH_CARRIERSIMPREF = "select CARRIER_NAME,RANK,SIM_PROFILE,MIN_DLL_EXCH,MAX_DLL_EXCH from sa.CARRIERSIMPREF where ";

    String TRACFONE_INSERT_CARRIERSIMPREF = "insert into sa.CARRIERSIMPREF(CARRIER_NAME, RANK, SIM_PROFILE, MIN_DLL_EXCH, MAX_DLL_EXCH) values (?, ?, ?, ?, ?)";

    String TRACFONE_UPDATE_CARRIERSIMPREF = "update sa.CARRIERSIMPREF set CARRIER_NAME = ?, RANK = ?, SIM_PROFILE = ?, MIN_DLL_EXCH = ?,  MAX_DLL_EXCH = ?"
            + " where CARRIER_NAME = ? and SIM_PROFILE = ? and MIN_DLL_EXCH = ? and MAX_DLL_EXCH = ? ";

    String TRACFONE_DELETE_CARRIERSIMPREF = "delete from sa.CARRIERSIMPREF where CARRIER_NAME = ? and RANK = ?  and SIM_PROFILE = ? and MIN_DLL_EXCH = ? and MAX_DLL_EXCH = ? ";

    String TRACFONE_UPDATE_CARRIERSIMPREF_RANK = "update sa.CARRIERSIMPREF set RANK = ? where CARRIER_NAME = ? and SIM_PROFILE = ? and MIN_DLL_EXCH = ? and MAX_DLL_EXCH = ? ";

    String TRACFONE_GET_BUCKET_DETAILS = "select pb.bucket_id, pb.bucket_type, pb.bucket_group, pb.benefit_type from sa.carrier_profile_buckets pb,sa.bucket_list bl"
            + " where pb.bucket_id=bl.bucket_id and pb.bucket_id = ? and bl.PARENT_SHORT_NAME = ? and pb.profile_id = ? and pb.service_plan_id = ? group by pb.bucket_id, pb.bucket_type, pb.bucket_group, pb.benefit_type";

    String TRACFONE_INSERT_NPANXX_2_CARRIERZONES = "insert into sa.NPANXX2CARRIERZONES "
            + "(NPA,NXX,CARRIER_ID,CARRIER_NAME,LEAD_TIME,TARGET_LEVEL,RATECENTER,STATE,CARRIER_ID_DESCRIPTION,ZONE,COUNTY,MARKETID,MRKT_AREA,SID,TECHNOLOGY, "
            + "FREQUENCY1,FREQUENCY2,BTA_MKT_NUMBER,BTA_MKT_NAME,GSM_TECH,CDMA_TECH,TDMA_TECH,MNC)"
            + " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    String TRACFONE_SEARCH_NPANXX_2_CARRIERZONES = "select * from sa.NPANXX2CARRIERZONES where ";

    String NPANXX_2_CARRIERZONES_START = "select * from ( " +
            "select /*+ FIRST_ROWS(n) */ a.*, ROWNUM rnum from (";

    String GET_NPANXX_2_CARRIERZONES_COUNT = "SELECT count(1) AS totalRecords FROM sa.NPANXX2CARRIERZONES  where ";

    String TRACFONE_DELETE_NPANXX_2_CARRIERZONES = "delete from sa.NPANXX2CARRIERZONES where NPA=? and NXX=? and CARRIER_ID=? and STATE=? and SID=? and ZONE=? and RATECENTER=?";

    String TRACFONE_UPDATE_NPANXX_2_CARRIERZONES = "update sa.NPANXX2CARRIERZONES set CARRIER_NAME = ?,NXX = ?,NPA = ?,ZONE = ?,SID = ?,STATE = ?,RATECENTER = ?,CARRIER_ID = ?,BTA_MKT_NAME = ?,BTA_MKT_NUMBER = ?,"
            + "CARRIER_ID_DESCRIPTION = ?,CDMA_TECH = ?,COUNTY = ?,GSM_TECH = ?,MNC = ?,TDMA_TECH = ?,MRKT_AREA = ?,TECHNOLOGY = ?,FREQUENCY1 = ?,FREQUENCY2 = ?,LEAD_TIME = ?,MARKETID = ?,TARGET_LEVEL = ? "
            + "where ";

    String TRACFONE_SEARCH_AR_USA_POSTAL_ZIPS = "select * from cop.AR_USA_POSTAL_ZIPS where  ";

    String TRACFONE_INSERT_AR_USA_POSTAL_ZIPS = "insert into cop.AR_USA_POSTAL_ZIPS (POSTAL_CODE,KEY_CODE,STATE,CITY) " +
            "values ( ?,?,?,?)";

    String TRACFONE_DELETE_AR_USA_POSTAL_ZIPS = "delete from cop.AR_USA_POSTAL_ZIPS where POSTAL_CODE =? ";

    String TRACFONE_UPDATE_AR_USA_POSTAL_ZIPS = "update cop.AR_USA_POSTAL_ZIPS set POSTAL_CODE =?, KEY_CODE =? ,STATE = ?, CITY = ? where POSTAL_CODE =? ";


    String TRACFONE_SEARCH_AR_USA_MARKET = "select * from cop.AR_USA_MARKET where  ";

    String AR_USA_MARKET_START = "select * from ( " +
            "select /*+ FIRST_ROWS(n) */ a.*, ROWNUM rnum from (";

    String GET_AR_USA_MARKET_COUNT = "SELECT count(1) AS totalRecords FROM cop.AR_USA_MARKET  where ";


    String TRACFONE_INSERT_AR_USA_MARKET = "insert into cop.AR_USA_MARKET (KEY_CODE ,NATION ,STATE  ,COUNTY ,CARRIER_ENTITY ,MARKETING_NAME ,MHZ_TOTAL ,SPECTRUM_BLOCKS ,CMA_MKT_CODE," +
            "CMA_MKT_STATE,CMA_MKT_NAME ,CMA_MKT_NAME_ALTERNATE,CMA_MKT_MULTI_STATE,BTA_MKT_CODE,BTA_MKT_STATE,BTA_MKT_NAME,BTA_MKT_NAME_ALTERNATE," +
            "BTA_MKT_MULTI_STATE,BEA_MKT_CODE,BEA_MKT_STATE,BEA_MKT_NAME,BEA_MKT_NAME_ALTERNATE,BEA_MKT_MULTI_STATE,PROTOCOL,EXTENDED_SERVICES,BID1,BID1_NAME,BID1_BSID1,BID1_BSID2 ," +
            "BID1_BSID3,BID1_MNC,BID2,BID2_NAME,BID2_BSID1,BID2_BSID2,BID2_BSID3,BID2_MNC,BID3,BID3_NAME,BID3_BSID1,BID3_BSID2,BID3_BSID3,BID3_MNC,BID4,BID4_NAME,BID4_BSID1," +
            "BID4_BSID2,BID4_BSID3,BID4_MNC) " +
            "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?)";

    String TRACFONE_REPLACE_AR_USA_MARKET = "update cop.AR_USA_MARKET set NATION = ?,STATE = ? ,COUNTY = ?,MARKETING_NAME = ?,MHZ_TOTAL =?,SPECTRUM_BLOCKS =?,CMA_MKT_CODE=?," +
            "CMA_MKT_STATE=?,CMA_MKT_NAME =?,CMA_MKT_NAME_ALTERNATE=?,CMA_MKT_MULTI_STATE=?,BTA_MKT_CODE=?,BTA_MKT_STATE=?,BTA_MKT_NAME=?,BTA_MKT_NAME_ALTERNATE=?," +
            "BTA_MKT_MULTI_STATE =?,BEA_MKT_CODE=?,BEA_MKT_STATE=?,BEA_MKT_NAME=?,BEA_MKT_NAME_ALTERNATE=?,BEA_MKT_MULTI_STATE=?,PROTOCOL=?,EXTENDED_SERVICES=?,BID1=?,BID1_NAME=?,BID1_BSID1=?,BID1_BSID2=?," +
            "BID1_BSID3=?,BID1_MNC=?,BID2=?,BID2_NAME=?,BID2_BSID1=?,BID2_BSID2=?,BID2_BSID3=?,BID2_MNC=?,BID3=?,BID3_NAME=?,BID3_BSID1=?,BID3_BSID2=?,BID3_BSID3=?,BID3_MNC=?,BID4=?,BID4_NAME=?,BID4_BSID1=?," +
            "BID4_BSID2 = ?,BID4_BSID3=?,BID4_MNC=? where KEY_CODE =? and CARRIER_ENTITY =? ";

    String TRACFONE_DELETE_AR_USA_MARKET = "delete from cop.AR_USA_MARKET where KEY_CODE =? and CARRIER_ENTITY =? ";

    String TRACFONE_UPDATE_AR_USA_MARKET = "update cop.AR_USA_MARKET set KEY_CODE =? ,NATION = ?,STATE = ? ,COUNTY = ?,CARRIER_ENTITY =?,MARKETING_NAME = ?,MHZ_TOTAL =?,SPECTRUM_BLOCKS =?,CMA_MKT_CODE=?," +
            "CMA_MKT_STATE=?,CMA_MKT_NAME =?,CMA_MKT_NAME_ALTERNATE=?,CMA_MKT_MULTI_STATE=?,BTA_MKT_CODE=?,BTA_MKT_STATE=?,BTA_MKT_NAME=?,BTA_MKT_NAME_ALTERNATE=?," +
            "BTA_MKT_MULTI_STATE =?,BEA_MKT_CODE=?,BEA_MKT_STATE=?,BEA_MKT_NAME=?,BEA_MKT_NAME_ALTERNATE=?,BEA_MKT_MULTI_STATE=?,PROTOCOL=?,EXTENDED_SERVICES=?,BID1=?,BID1_NAME=?,BID1_BSID1=?,BID1_BSID2=?," +
            "BID1_BSID3=?,BID1_MNC=?,BID2=?,BID2_NAME=?,BID2_BSID1=?,BID2_BSID2=?,BID2_BSID3=?,BID2_MNC=?,BID3=?,BID3_NAME=?,BID3_BSID1=?,BID3_BSID2=?,BID3_BSID3=?,BID3_MNC=?,BID4=?,BID4_NAME=?,BID4_BSID1=?," +
            "BID4_BSID2 = ?,BID4_BSID3=?,BID4_MNC=? where KEY_CODE =? and CARRIER_ENTITY =? ";

    String TRACFONE_INSERT_GEO_LOC = "insert into COP.C_RTL_ZIP_GEOLOC (ZIP, STATE, POPCY, POP05, LATITUDE, LONGITUDE, RLATITUDE, " +
            "RLONGITUDE, SRLATITUDE, CRLATITUDE, RZG2USER, INSERT_DATE) " +
            "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE)";

    String TRACFONE_DELETE_GEO_LOC = "delete from COP.C_RTL_ZIP_GEOLOC where ZIP = ?";

    String TRACFONE_GET_SEC_USER_ID = "SELECT OBJID FROM COP.C_SEC_USER";

    String TRACFONE_SEARCH_GEO_LOC = "SELECT ZIP, STATE, POPCY, POP05, LATITUDE, LONGITUDE, RLATITUDE, RLONGITUDE, " +
            "SRLATITUDE, CRLATITUDE, RZG2USER, INSERT_DATE, UPDATE_DATE FROM COP.C_RTL_ZIP_GEOLOC where zip in(? ";

    String TRACFONE_UPDATE_GEO_LOC = "update COP.C_RTL_ZIP_GEOLOC set ZIP = ?, STATE = ?, POPCY = ?, POP05 = ?, " +
            "LATITUDE = ?, LONGITUDE = ?, RLATITUDE = ?, RLONGITUDE = ?, SRLATITUDE = ?, " +
            "CRLATITUDE  = ?, UPDATE_DATE = sysdate where zip = ?";

    String TRACFONE_SEARCH_CARRIERZONES = "select * from carrierzones where ";

    String TRACFONE_INSERT_CARRIERZONES = "insert into carrierzones "
            + "(ZIP,ST,COUNTY,ZONE,RATE_CENTE,MARKETID,MRKT_AREA,CITY,BTA_MKT_NUMBER,BTA_MKT_NAME,CARRIER_ID,CARRIER_NAME,ZIP_STATUS,SIM_PROFILE,SIM_PROFILE_2,PLANTYPE)"
            + " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    String TRACFONE_DELETE_CARRIERZONES  = "delete from carrierzones where ZIP=? and ST=? and COUNTY=? and ZONE=? and CARRIER_NAME=?";

    String TRACFONE_UPDATE_CARRIERZONES = "update carrierzones set ZIP = ? , "
            + "ST = ?,COUNTY = ?,ZONE = ?,RATE_CENTE = ?,MARKETID = ?,MRKT_AREA = ?,CITY = ?,BTA_MKT_NUMBER = ?,BTA_MKT_NAME = ?,CARRIER_ID = ?,CARRIER_NAME = ?,ZIP_STATUS = ?,SIM_PROFILE = ?,SIM_PROFILE_2 = ?,PLANTYPE = ? "
            + "where ZIP=? and ST=? and COUNTY=? and ZONE=? and CARRIER_NAME=? ";

    String TRACFONE_SEARCH_CARRIERPREF = "select ST,COUNTY,CARRIER_ID,CARRIER_NAME,CARRIER_RANK,NEW_RANK from sa.CARRIERPREF where ";

    String TRACFONE_INSERT_CARRIERPREF = "insert into CARRIERPREF "
            + "(ST,COUNTY,CARRIER_ID,CARRIER_NAME,CARRIER_RANK,NEW_RANK)"
            + " values (?, ?, ?, ?, ?, ?)";

    String TRACFONE_DELETE_CARRIERPREF  = "delete from CARRIERPREF where ";

    String TRACFONE_UPDATE_CARRIERPREF = "update CARRIERPREF set ST = ?, "
            + "COUNTY = ? ,CARRIER_ID = ?,CARRIER_NAME = ? , CARRIER_RANK = ? , NEW_RANK = ?"
            + "where ";

    String TRACFONE_REPLACE_NPANXX_2_CARRIERZONES = "update sa.NPANXX2CARRIERZONES set CARRIER_NAME = ?,NXX = ?,NPA = ?,ZONE = ?,SID = ?,STATE = ?,RATECENTER = ?,CARRIER_ID = ?,BTA_MKT_NAME = ?,BTA_MKT_NUMBER = ?,"
            + "CARRIER_ID_DESCRIPTION = ?,CDMA_TECH = ?,COUNTY = ?,GSM_TECH = ?,MNC = ?,TDMA_TECH = ?,MRKT_AREA = ?,TECHNOLOGY = ?,FREQUENCY1 = ?,FREQUENCY2 = ?,LEAD_TIME = ?,MARKETID = ?,TARGET_LEVEL = ? "
            + "where NPA = ? and NXX = ? and CARRIER_ID = ? and ZONE = ? and SID = ? and STATE = ? and RATECENTER = ?";
}

