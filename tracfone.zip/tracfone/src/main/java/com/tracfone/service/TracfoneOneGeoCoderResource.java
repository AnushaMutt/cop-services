package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneOneGeoCoderControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneGeoCoderAddress;
import com.tracfone.service.model.request.TracfoneOneGeoCoderToken;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeoCodeAddress;
import com.tracfone.service.model.response.TFOneGeoCoder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

/**
 * @author Thejaswini
 */
 @Path("geolocators")
public class TracfoneOneGeoCoderResource {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneGeoCoderResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @EJB
    private TracfoneOneGeoCoderControllerLocal tracfoneGeoCoderController;

    @Context
    private SecurityContext securityContext;


    /**
     * This method is used to generate token
     *
     * @param tracfoneOneGeoCoderToken
     * @return
     */
    @POST
    @Path("geocode/accessgeo")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response generateToken(final TracfoneOneGeoCoderToken tracfoneOneGeoCoderToken) {
        TFOneGeoCoder tfOneGeoCoder;
        try {
            tfOneGeoCoder = tracfoneGeoCoderController.generateToken(getUserFromPrincipal().getUserId(), tracfoneOneGeoCoderToken);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneGeoCoder), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to find candidate address
     *
     * @param tracfoneOneGeoCoderAddress
     * @return
     */
    @POST
    @Path("geocode/findaddress")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response findGeoAddressLocation(final TracfoneOneGeoCoderAddress tracfoneOneGeoCoderAddress) {
        TFOneGeoCodeAddress tfOneGeoCodeAddress = null;
        try {
            tfOneGeoCodeAddress = tracfoneGeoCoderController.findGeoAddressLocation(getUserFromPrincipal().getUserId(), tracfoneOneGeoCoderAddress);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneGeoCodeAddress), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves the user object making request from the principal.
     *
     * @return
     */
    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }
}
