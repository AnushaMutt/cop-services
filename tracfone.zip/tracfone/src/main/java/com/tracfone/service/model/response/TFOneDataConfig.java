package com.tracfone.service.model.response;

public class TFOneDataConfig {
    private String objId;
    private String dev;
    private String parentId;
    private String partClassObjId;
    private String xDefault;
    private String ipAddress;
    private String apn;
    private String homePage;
    private String mmsc;
    private String cmd148CarrierDataSwitch;
    private String dataSwitch;
    private String cmd71GprsApn;
    private String cmd150ClearProxy;
    private String cmd121GatewayPortUpdate;
    private String cmd121GatewayIpUpdate;
    private String cmd71MmscUpdate;
    private String cmd71GatewayHome;
    private String cmd121GatewayIpPortUpdate;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getDev() {
        return dev;
    }

    public void setDev(String dev) {
        this.dev = dev;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getPartClassObjId() {
        return partClassObjId;
    }

    public void setPartClassObjId(String partClassObjId) {
        this.partClassObjId = partClassObjId;
    }

    public String getxDefault() {
        return xDefault;
    }

    public void setxDefault(String xDefault) {
        this.xDefault = xDefault;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getApn() {
        return apn;
    }

    public void setApn(String apn) {
        this.apn = apn;
    }

    public String getHomePage() {
        return homePage;
    }

    public void setHomePage(String homePage) {
        this.homePage = homePage;
    }

    public String getMmsc() {
        return mmsc;
    }

    public void setMmsc(String mmsc) {
        this.mmsc = mmsc;
    }

    public String getCmd148CarrierDataSwitch() {
        return cmd148CarrierDataSwitch;
    }

    public void setCmd148CarrierDataSwitch(String cmd148CarrierDataSwitch) {
        this.cmd148CarrierDataSwitch = cmd148CarrierDataSwitch;
    }

    public String getDataSwitch() {
        return dataSwitch;
    }

    public void setDataSwitch(String dataSwitch) {
        this.dataSwitch = dataSwitch;
    }

    public String getCmd71GprsApn() {
        return cmd71GprsApn;
    }

    public void setCmd71GprsApn(String cmd71GprsApn) {
        this.cmd71GprsApn = cmd71GprsApn;
    }

    public String getCmd150ClearProxy() {
        return cmd150ClearProxy;
    }

    public void setCmd150ClearProxy(String cmd150ClearProxy) {
        this.cmd150ClearProxy = cmd150ClearProxy;
    }

    public String getCmd121GatewayPortUpdate() {
        return cmd121GatewayPortUpdate;
    }

    public void setCmd121GatewayPortUpdate(String cmd121GatewayPortUpdate) {
        this.cmd121GatewayPortUpdate = cmd121GatewayPortUpdate;
    }

    public String getCmd121GatewayIpUpdate() {
        return cmd121GatewayIpUpdate;
    }

    public void setCmd121GatewayIpUpdate(String cmd121GatewayIpUpdate) {
        this.cmd121GatewayIpUpdate = cmd121GatewayIpUpdate;
    }

    public String getCmd71MmscUpdate() {
        return cmd71MmscUpdate;
    }

    public void setCmd71MmscUpdate(String cmd71MmscUpdate) {
        this.cmd71MmscUpdate = cmd71MmscUpdate;
    }

    public String getCmd71GatewayHome() {
        return cmd71GatewayHome;
    }

    public void setCmd71GatewayHome(String cmd71GatewayHome) {
        this.cmd71GatewayHome = cmd71GatewayHome;
    }

    public String getCmd121GatewayIpPortUpdate() {
        return cmd121GatewayIpPortUpdate;
    }

    public void setCmd121GatewayIpPortUpdate(String cmd121GatewayIpPortUpdate) {
        this.cmd121GatewayIpPortUpdate = cmd121GatewayIpPortUpdate;
    }

    @Override
    public String toString() {
        return "TracfoneOneDataConfig{" +
                ", objId='" + objId + '\'' +
                ", dev='" + dev + '\'' +
                ", parentId='" + parentId + '\'' +
                ", partClassObjId='" + partClassObjId + '\'' +
                ", xDefault='" + xDefault + '\'' +
                ", ipAddress='" + ipAddress + '\'' +
                ", apn='" + apn + '\'' +
                ", homePage='" + homePage + '\'' +
                ", mmsc='" + mmsc + '\'' +
                ", cmd148CarrierDataSwitch='" + cmd148CarrierDataSwitch + '\'' +
                ", dataSwitch='" + dataSwitch + '\'' +
                ", cmd71GprsApn='" + cmd71GprsApn + '\'' +
                ", cmd150ClearProxy='" + cmd150ClearProxy + '\'' +
                ", cmd121GatewayPortUpdate='" + cmd121GatewayPortUpdate + '\'' +
                ", cmd121GatewayIpUpdate='" + cmd121GatewayIpUpdate + '\'' +
                ", cmd71MmscUpdate='" + cmd71MmscUpdate + '\'' +
                ", cmd71GatewayHome='" + cmd71GatewayHome + '\'' +
                ", cmd121GatewayIpPortUpdate='" + cmd121GatewayIpPortUpdate + '\'' +
                '}';
    }
}

