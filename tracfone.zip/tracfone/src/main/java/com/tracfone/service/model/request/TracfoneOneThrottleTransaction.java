/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Gaurav.Sharma
 */
public class TracfoneOneThrottleTransaction {

    private String dbEnv;
    private String creationFromDate;
    private String creationToDate;
    private String updateFromDate;
    private String updateToDate;
    private TracfoneonePaginationSearch paginationSearch;
    private List<TracfoneOneSearchAdditionalModel> searchColumns;

    public TracfoneOneThrottleTransaction() {
        searchColumns = new ArrayList<>();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getCreationFromDate() {
        return creationFromDate;
    }

    public void setCreationFromDate(String creationFromDate) {
        this.creationFromDate = creationFromDate;
    }

    public String getCreationToDate() {
        return creationToDate;
    }

    public void setCreationToDate(String creationToDate) {
        this.creationToDate = creationToDate;
    }

    public String getUpdateFromDate() {
        return updateFromDate;
    }

    public void setUpdateFromDate(String updateFromDate) {
        this.updateFromDate = updateFromDate;
    }

    public String getUpdateToDate() {
        return updateToDate;
    }

    public void setUpdateToDate(String updateToDate) {
        this.updateToDate = updateToDate;
    }

    public TracfoneonePaginationSearch getPaginationSearch() {
        return paginationSearch;
    }

    public void setPaginationSearch(TracfoneonePaginationSearch paginationSearch) {
        this.paginationSearch = paginationSearch;
    }

    public List<TracfoneOneSearchAdditionalModel> getSearchColumns() {
        return searchColumns;
    }

    public void setSearchColumns(List<TracfoneOneSearchAdditionalModel> searchColumns) {
        this.searchColumns = searchColumns;
    }

    @Override
    public String toString() {
        return "TracfoneOneThrottleTransaction{" +
                "dbEnv='" + dbEnv + '\'' +
                ", creationFromDate='" + creationFromDate + '\'' +
                ", creationToDate='" + creationToDate + '\'' +
                ", updateFromDate='" + updateFromDate + '\'' +
                ", updateToDate='" + updateToDate + '\'' +
                ", paginationSearch=" + paginationSearch +
                ", searchColumns=" + searchColumns +
                '}';
    }
}
