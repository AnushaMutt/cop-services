/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

import java.util.List;

/**
 * @author Raul Martinez
 */
public class TFOneCarrierServicePlan {

    private String carrierName;
    private String servicePlanId;
    private String mktName;
    private String description;
    private String servicePlanPurchase;
    private String parentName;
    private List<TFOneServicePlan> servicePlans;

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public List<TFOneServicePlan> getServicePlans() {
        return servicePlans;
    }

    public void setServicePlans(List<TFOneServicePlan> servicePlans) {
        this.servicePlans = servicePlans;
    }

    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public String getMktName() {
        return mktName;
    }

    public void setMktName(String mktName) {
        this.mktName = mktName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getServicePlanPurchase() {
        return servicePlanPurchase;
    }

    public void setServicePlanPurchase(String servicePlanPurchase) {
        this.servicePlanPurchase = servicePlanPurchase;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    @Override
    public String toString() {
        return "TFOneCarrierServicePlan{" +
                "carrierName='" + carrierName + '\'' +
                ", servicePlanId='" + servicePlanId + '\'' +
                ", mktName='" + mktName + '\'' +
                ", description='" + description + '\'' +
                ", servicePlanPurchase='" + servicePlanPurchase + '\'' +
                ", parentName='" + parentName + '\'' +
                ", servicePlans=" + servicePlans +
                '}';
    }
}
