package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.controller.TracfoneOneZip2TechControllerLocal;
import com.tracfone.service.controller.TracfoneRatePlanControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneBPTech;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.request.TracfoneOneZip2Tech;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneBPTech;
import com.tracfone.service.model.response.TFOneBulkInsertReport;
import com.tracfone.service.model.response.TFOneDatabaseEnvironment;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOneZip2Tech;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Path("zip2tech")
public class TracfoneOneZip2TechResource {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneZip2TechResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @Context
    private SecurityContext securityContext;

    @EJB
    private TracfoneControllerLocal tracfoneController;

    @EJB
    private TracfoneOneZip2TechControllerLocal tracfoneOneZip2TechController;

    @EJB
    private TracfoneRatePlanControllerLocal tracfoneRatePlanController;

    @EJB
    private TracfoneControllerLocalAction tracfoneControllerAction;

    @GET
    @Path("zip2techmaintenance/dbenvs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    public Response getDatabaseEnvironments() {
        List<TFOneDatabaseEnvironment> tfOneDatabaseEnvironment = null;
        try {
            tfOneDatabaseEnvironment = tracfoneController.getDatabaseEnvironments(getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneDatabaseEnvironment), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search eg_zip2tech
     *
     * @param tfZip2Tech
     * @return
     */
    @POST
    @Path("zip2techmaintenance/searchzip2tech")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchZip2Tech(TracfoneOneZip2Tech tfZip2Tech) {
        List<TFOneZip2Tech> zip2Techs = new ArrayList<>();
        try {
            zip2Techs = tracfoneOneZip2TechController.searchZip2Tech(tfZip2Tech);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(zip2Techs), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update records based on
     * zip,state,county,service,language,techkey,x_pref_parent
     * mapinfo.eg_zip2tech table
     *
     * @return
     */
    @POST
    @Path("zip2techmaintenance/updatezip2techs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateZip2Techs(List<TracfoneOneZip2Tech> tfZip2Techs) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneZip2TechController.updateZip2Techs(tfZip2Techs, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get column values from mapinfo.eg_zip2tech table
     *
     * @return
     */
    @POST
    @Path("zip2techmaintenance/getcolumn/{columnname}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getColumn(TracfoneOneZip2Tech tfZip2Tech,
                              @PathParam("columnname") String columnName) {
        List<String> columnValue = new ArrayList<>();
        try {
            columnValue = tracfoneOneZip2TechController.getZip2TechColumnValues(columnName, tfZip2Tech.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(columnValue), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add records into mapinfo.eg_zip2tech table
     *
     * @return
     */
    @POST
    @Path("zip2techmaintenance/addzip2tech")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertZip2Tech(TracfoneOneZip2Tech tfZip2Tech) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneZip2TechController.insertZip2Tech(tfZip2Tech, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all parent names for the drop down in add
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("zip2techmaintenance/viewparentnames")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllParentNames(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneParent> allParents = new ArrayList<>();
        try {
            allParents = tracfoneRatePlanController.getAllParentNames(tracfoneOneSearchPlanModel.getDbEnv(),
                    tracfoneOneSearchPlanModel.getCarrierName());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(allParents), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search EG_BPTECH
     *
     * @param tfBPTech
     * @return
     */
    @POST
    @Path("zip2techmaintenance/searchbptech")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchBPTech(TracfoneOneBPTech tfBPTech) {
        List<TFOneBPTech> bpTechs = new ArrayList<>();
        try {
            bpTechs = tracfoneOneZip2TechController.searchBPTech(tfBPTech);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(bpTechs), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get column values from mapinfo.EG_BPTECH table
     *
     * @return
     */
    @POST
    @Path("zip2techmaintenance/getbptechcolumn/{columnname}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBPTechColumn(TracfoneOneBPTech tfBPTech,
                                    @PathParam("columnname") String columnName) {
        List<String> columnValue = new ArrayList<>();
        try {
            columnValue = tracfoneOneZip2TechController.getBPTechColumn(columnName, tfBPTech.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(columnValue), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update records
     * mapinfo.EG_BPTECH table
     *
     * @return
     */
    @POST
    @Path("zip2techmaintenance/updatebptechs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateBPTechs(List<TracfoneOneBPTech> tfBPTechs) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneZip2TechController.updateBPTechs(tfBPTechs, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete records into mapinfo.eg_zip2tech table based on zip,service,language,techkey
     *
     * @return
     */
    @POST
    @Path("zip2techmaintenance/deletezip2tech")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteZip2Techs(TracfoneOneZip2Tech tfZip2Tech) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneZip2TechController.deleteZip2Techs(tfZip2Tech, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add records into mapinfo.eg_zip2tech table
     *
     * @return
     */
    @POST
    @Path("zip2techmaintenance/bulkinsertzip2tech")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertZip2Tech(List<TracfoneOneZip2Tech> tfZip2Techs) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneOneZip2TechController.bulkInsertZip2Tech(tfZip2Techs,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("zip2techmaintenance/getbulkinserterrorrecorddetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        try {
            tracfoneOneUserHistory.setType("Bulk Zip2Tech Insert");
            summary = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(summary), MediaType.APPLICATION_JSON).build();
    }


    @POST
    @Path("zip2techmaintenance/bulkinsertzip2techsummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertZip2TechSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(),
                    "Bulk Zip2Tech Insert",
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete records from mapinfo.eg_zip2tech table
     *
     * @return
     */
    @POST
    @Path("zip2techmaintenance/bulkdeletezip2tech")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkDeleteZip2Tech(List<TracfoneOneZip2Tech> tfZip2Techs) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneOneZip2TechController.bulkDeleteZip2Tech(tfZip2Techs,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add record into mapinfo.eg_bptech table
     *
     * @return
     */
    @POST
    @Path("zip2techmaintenance/addbptech")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertBpTech(TracfoneOneBPTech tfBPTech) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneZip2TechController.insertBpTech(tfBPTech, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add records into mapinfo.eg_bptech table
     *
     * @return
     */
    @POST
    @Path("zip2techmaintenance/bulkinsertbptech")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertBPTech(List<TracfoneOneBPTech> tfBPTechs) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneOneZip2TechController.bulkInsertBPTech(tfBPTechs,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete records into mapinfo.eg_bptech table based on techkey,service,bp_code
     *
     * @return
     */
    @POST
    @Path("zip2techmaintenance/deletebptech")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteBpTech(TracfoneOneBPTech tfBPTech) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneOneZip2TechController.deleteBpTech(tfBPTech, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete records from mapinfo.eg_bptech table
     *
     * @return
     */
    @POST
    @Path("zip2techmaintenance/bulkdeletebptech")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkDeleteBpTech(List<TracfoneOneBPTech> tfBPTechs) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneOneZip2TechController.bulkDeleteBpTech(tfBPTechs,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("zip2techmaintenance/getbulkbptechinserterrorrecorddetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertBpTechErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        try {
            tracfoneOneUserHistory.setType("Bulk BPTech Insert");
            summary = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(summary), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("zip2techmaintenance/bulkinsertbptechsummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertBpTechSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(),
                    "Bulk BPTech Insert",
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }

    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }
}
