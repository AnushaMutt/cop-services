
package com.tracfone.service.model.response;

/**
 *
 * @author druiz
 * This POJO maps to the table "IG_TRANS_CARRIER_RESPONSE".
 */
public class TFOneCarrierTransactionResponse {
    
    private String transactionId;
    private String xmlResponse;
    private String updateDate;
    private String creationDate;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getXmlResponse() {
        return xmlResponse;
    }

    public void setXmlResponse(String xmlResponse) {
        this.xmlResponse = xmlResponse;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }
}
