package com.tracfone.service.util;

/**
 * @author Pritesh.Singh
 */
public interface TracfoneOneConstantThrottleTransNotes {
    String TRACFONE_ADD_TT_NOTES_ERROR = "TFE4000";
    String TRACFONE_ADD_TT_NOTES_ERROR_MESSAGE = "Unable to add Throttle Transactions notes";

    String TRACFONE_POSTGRES_DATASOURCE_CONNECTION_ERROR_CODE = "TFE4001";
    String TRACFONE_POSTGRES_DATASOURCE_CONNECTION_ERROR_CODE_MESSAGE = "Unable to get response from Postgres DB.";

    String TRACFONE_INSERT_TT_NOTES = "INSERT INTO cop.throttling_transaction_note(\"user\",throttling_transaction_id,notes,insert_timestamp) VALUES ( ?, ?, ?, CURRENT_DATE)";
}
