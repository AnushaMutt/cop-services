package com.tracfone.service.model.request;

import java.util.List;

/**
 *
 * @author Gaurav.Sharma
 */
public class TracfoneOneCarrierZonesDeployment {
    
    private List<String> zipcodes;
    private String dbEnv;
    private String carrierName;

    public List<String> getZipcodes() {
        return zipcodes;
    }

    public void setZipcodes(List<String> zipcodes) {
        this.zipcodes = zipcodes;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    @Override
    public String toString() {
        return "TracfoneOneCarrierZonesDeployment{" + "zipcodes=" + zipcodes + ", dbEnv=" + dbEnv + ", carrierName=" + carrierName + '}';
    } 
}
