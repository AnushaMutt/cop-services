package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneDB2Intergate;
import com.tracfone.service.model.response.TFOneDB2Intergate;
import com.tracfone.service.model.response.TFOneGeneralResponse;

import javax.ejb.Local;
import java.util.List;

/**
 * @author Gaurav.Sharma
 */
@Local
public interface TracfoneOneDB2IntergateActionLocal {

    List<TFOneDB2Intergate> viewDB2Intergate(TracfoneOneDB2Intergate searchCriteria) throws TracfoneOneException;

    TFOneGeneralResponse updateDB2Intergate(TracfoneOneDB2Intergate tracfoneOneDB2Intergate, int userId) throws TracfoneOneException;

}
