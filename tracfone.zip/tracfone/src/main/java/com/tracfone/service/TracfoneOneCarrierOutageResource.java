package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneOneCarrierOutageControllerLocal;
import com.tracfone.service.controller.TracfoneRatePlanControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneCarrierOutage;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneServiceType;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneBusinessOrganization;
import com.tracfone.service.model.response.TFOneCarrierOutage;
import com.tracfone.service.model.response.TFOneDatabaseEnvironment;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOneServiceType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.validation.Valid;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Path("carrieroutagemanagement")
public class TracfoneOneCarrierOutageResource {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneCarrierOutageResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @Context
    private SecurityContext securityContext;

    @EJB
    private TracfoneOneCarrierOutageControllerLocal tracfoneOneCarrierOutageController;

    @EJB
    private TracfoneControllerLocal tracfoneController;

    @EJB
    private TracfoneRatePlanControllerLocal tracfoneRatePlanController;

    @GET
    @Path("carrieroutage/dbenvs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    public Response getDatabaseEnvironments() {
        List<TFOneDatabaseEnvironment> tfOneDatabaseEnvironment = null;
        Response response = null;
        try {
            tfOneDatabaseEnvironment = tracfoneController.getDatabaseEnvironments(getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        response = Response.ok(gson.toJson(tfOneDatabaseEnvironment), MediaType.APPLICATION_JSON).build();
        return response;
    }

    /**
     * This method is used to retrieve all business orgs for a drop down
     * required when adding carrier features
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("carrieroutage/viewbusorgs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllBusinessOrgs(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneBusinessOrganization> allBusOrgs = new ArrayList<>();
        try {
            allBusOrgs = tracfoneRatePlanController.getAllBusinessOrgs(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(allBusOrgs), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all parent names for the drop down
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("carrieroutage/viewparentnames")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllParentNames(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneParent> allParents = new ArrayList<>();
        try {
            allParents = tracfoneRatePlanController.getAllParentNames(tracfoneOneSearchPlanModel.getDbEnv(),
                    tracfoneOneSearchPlanModel.getCarrierName());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(allParents), MediaType.APPLICATION_JSON).build();
    }


    /**
     * This method is used to search for table_carrier_outage and table_carrier_outage_archive
     * based on PARENT_SHORT_NAME, BRAND,
     * CREATED_BY, START_TIME, END_TIME
     *
     * @param tracfoneOneCarrierOutage
     * @return
     */
    @POST
    @Path("carrieroutage/searchcarrieroutage")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierOutage(final TracfoneOneCarrierOutage tracfoneOneCarrierOutage) {
        List<TFOneCarrierOutage> carrierOutages = new ArrayList<>();
        try {
            carrierOutages = tracfoneOneCarrierOutageController.searchCarrierOutage(tracfoneOneCarrierOutage);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierOutages), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert table_carrier_outage
     *
     * @param tracfoneOneCarrierOutage
     * @return
     */
    @POST
    @Path("carrieroutage/addcarrieroutage")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarrierOutage(@Valid final TracfoneOneCarrierOutage tracfoneOneCarrierOutage) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneOneCarrierOutageController.insertCarrierOutage(tracfoneOneCarrierOutage,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }


    /**
     * This method is used to update table_carrier_outage
     *
     * @param tracfoneOneCarrierOutage
     * @return
     */
    @POST
    @Path("carrieroutage/updatecarrieroutage")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrierOutage(@Valid final TracfoneOneCarrierOutage tracfoneOneCarrierOutage) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneOneCarrierOutageController.updateCarrierOutage(tracfoneOneCarrierOutage,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update table_carrier_outage
     *
     * @param tracfoneOneCarrierOutage
     * @return
     */
    @POST
    @Path("carrieroutage/bulkupdate")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkUpdateOutages(@Valid final TracfoneOneCarrierOutage tracfoneOneCarrierOutage) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneOneCarrierOutageController.bulkUpdateOutages(tracfoneOneCarrierOutage,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all Service Types from TABLE_OUTAGE_SERVICE_TYPE
     *
     * @param tracfoneOneServiceType
     * @return
     */
    @POST
    @Path("carrieroutage/viewservicetypes")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response viewServiceTypes(final TracfoneOneServiceType tracfoneOneServiceType) {
        List<TFOneServiceType> serviceTypes = new ArrayList<>();
        try {
            serviceTypes = tracfoneOneCarrierOutageController.viewAllServiceTypes(tracfoneOneServiceType);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(serviceTypes), MediaType.APPLICATION_JSON).build();
    }
    /**
     * This method is used to insert Service Types in TABLE_OUTAGE_SERVICE_TYPE
     *
     * @param tracfoneOneServiceType
     * @return
     */
    @POST
    @Path("carrieroutage/insertservicetype")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertServiceType(@Valid final TracfoneOneServiceType tracfoneOneServiceType) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneOneCarrierOutageController.insertServiceType(tracfoneOneServiceType,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update Service Types in TABLE_OUTAGE_SERVICE_TYPE
     *
     * @param tracfoneOneServiceType
     * @return
     */
    @POST
    @Path("carrieroutage/updateservicetype")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateServiceType(final TracfoneOneServiceType tracfoneOneServiceType) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneOneCarrierOutageController.updateServiceType(tracfoneOneServiceType,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete Service Types in TABLE_OUTAGE_SERVICE_TYPE
     *
     * @param tracfoneOneServiceType
     * @return
     */
    @POST
    @Path("carrieroutage/deleteservicetype")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteServiceType(final TracfoneOneServiceType tracfoneOneServiceType) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneOneCarrierOutageController.deleteServiceType(tracfoneOneServiceType,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves the user object making request from the principal.
     *
     * @return
     */
    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }

}
