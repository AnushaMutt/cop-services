/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneFeatureRequirement;
import com.tracfone.service.model.request.TracfoneOneLineStatusCode;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionConfig;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneThrottleStatusCode;
import com.tracfone.service.model.request.TracfoneOneUploadProfileFeatures;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneFeatureRequirement;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneLineStatusCode;
import com.tracfone.service.model.response.TFOneRPFeatureNameList;
import com.tracfone.service.model.response.TFOneRatePlanExtensionConfig;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import com.tracfone.service.model.response.TFOneThrottleStatusCode;
import com.tracfone.service.model.response.TFOneUploadProfileFeatures;

import javax.ejb.Local;
import java.util.List;

/**
 * @author Nidhi Mantri
 */
@Local
public interface TracfoneFeatureControllerLocal {

    List<TFOneRPFeatureNameList> getAllMasterFeatures(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse insertRpExtensionConfig(List<TracfoneOneRatePlanExtensionConfig> tfOneRpExtensionConfigs, int userId) throws TracfoneOneException;

    List<TFOneRatePlanProfile> getAllProfileFeatures(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) throws TracfoneOneException;

    TFOneGeneralResponse updateRpExtensionConfig(TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteRpExtensionConfig(TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig, int userId) throws TracfoneOneException;

    TFOneUploadProfileFeatures validateAndAddProfileFeatures(TracfoneOneUploadProfileFeatures tfOneUploadProfileFeatures, int userId) throws TracfoneOneException;

    List<TFOneRatePlanProfile> searchBucketProfile(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException;

    List<TFOneRatePlanProfile> searchChildBucketProfile(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException;

    List<TFOneCarrierServicePlan> getChildBucketServicePlansForCopy(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException;

    List<TFOneCarrierServicePlan> getBucketServicePlansForCopy(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException;

    List<TFOneChildPlan> getBucketChildPlans(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException;

    List<TFOneLineStatusCode> getAllLineStatusCodes(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse insertLineStatusCode(TracfoneOneLineStatusCode tfOneLineStatus, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateLineStatusCode(TracfoneOneLineStatusCode tfOneLineStatus, int userId) throws TracfoneOneException;

    List<TFOneThrottleStatusCode> getAllThrottleStatusCodes(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse insertThrottleStatusCode(TracfoneOneThrottleStatusCode tfThrottleStatusCode, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateThrottleStatusCode(TracfoneOneThrottleStatusCode tfThrottleStatusCode, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertFeatureRequirement(TracfoneOneFeatureRequirement tfFeatureRequirement, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateFeatureRequirement(TracfoneOneFeatureRequirement tfFeatureRequirement, int userId) throws TracfoneOneException;

    List<TFOneFeatureRequirement> getAllFeatureRequirements(String dbEnv) throws TracfoneOneException;

    List<TFOneCarrier> getAllCarrierIds(String dbEnv, String carrierName, String parent) throws TracfoneOneException;

    TFOneGeneralResponse deleteFeatureRequirement(TracfoneOneFeatureRequirement tfOneFeatureRequirement, int userId) throws TracfoneOneException;

    List<TFOneRatePlanExtensionConfig> searchProfileFeatures(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) throws TracfoneOneException;

    List<String> getAllFeatureValues(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse bulkUpdateProfileFeatures(TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig, int userId) throws TracfoneOneException;

    void bulkInsertProfileFeatures(List<TracfoneOneRatePlanExtensionConfig> tfOneRpExtensionConfigs, int userId) throws TracfoneOneException;
}
