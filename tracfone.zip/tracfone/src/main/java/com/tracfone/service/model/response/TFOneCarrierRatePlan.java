/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

import java.util.List;

/**
 *
 * @author user
 */
public class TFOneCarrierRatePlan {
    
    String carrierName;
    List<TFOneRatePlan> ratePlans;

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public List<TFOneRatePlan> getRatePlans() {
        return ratePlans;
    }

    public void setRatePlans(List<TFOneRatePlan> ratePlans) {
        this.ratePlans = ratePlans;
    }
    
}
