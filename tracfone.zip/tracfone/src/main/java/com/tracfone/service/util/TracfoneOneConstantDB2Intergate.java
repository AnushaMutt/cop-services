package com.tracfone.service.util;

/**
 * @author Gaurav.Sharma
 */
public interface TracfoneOneConstantDB2Intergate {

    // ERROR MESSAGES
    String TRACFONE_GET_DB2_INTERGATE_ERROR = "TFE3000";
    String TRACFONE_GET_DB2_INTERGATE_ERROR_MESSAGE = "Unable to search for DB2Intergate records";

    String TRACFONE_UPDATE_DB2_INTERGATE_ERROR = "TFE3001";
    String TRACFONE_UPDATE_DB2_INTERGATE_ERROR_MESSAGE = "Unable to update DB2Intergate record";

    String TRACFONE_SEARCH_DB2_INTERGATE = "select QUERY_ID, QUERY_NAME, ACTIVE_FLAG, USE_NEW_SQL, INTERVAL_TIME, SELECT_QUERY_CLOB, NUMBER_OF_RECORDS, "
            + "UPDATE_QUERY, REMARKS, TEMPLATES, ORDER_TYPES, EXTRA_WHERE_CLAUSE_CONDITIONS, APP_NAME, STARTING_RECORD from GW1.DB2INTERGATE where ";

    String TRACFONE_UPDATE_DB2_INTERGATE = "update GW1.DB2INTERGATE set ";

}
