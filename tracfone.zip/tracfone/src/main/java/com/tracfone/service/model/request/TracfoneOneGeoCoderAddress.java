package com.tracfone.service.model.request;

/**
 * @author Thejaswini
 */
public class TracfoneOneGeoCoderAddress {
    private String token;
    private String address;
    private String address2;
    private String address3;
    private String neighborhood;
    private String city;
    private String subregion;
    private String region;
    private String postal;
    private String postalExt;
    private String countryCode;
    private String singleLine;
    private String outFields;
    private String maxLocations;
    private String matchOutOfRange;
    private String langCode;
    private String locationType;
    private String sourceCountry;
    private String category;
    private String location;
    private String distance;
    private String searchExtent;
    private String outSR;
    private String magicKey;
    private String f;
    private  String url;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getAddress3() {
        return address3;
    }

    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    public String getNeighborhood() {
        return neighborhood;
    }

    public void setNeighborhood(String neighborhood) {
        this.neighborhood = neighborhood;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getSubregion() {
        return subregion;
    }

    public void setSubregion(String subregion) {
        this.subregion = subregion;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getPostal() {
        return postal;
    }

    public void setPostal(String postal) {
        this.postal = postal;
    }

    public String getPostalExt() {
        return postalExt;
    }

    public void setPostalExt(String postalExt) {
        this.postalExt = postalExt;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getSingleLine() {
        return singleLine;
    }

    public void setSingleLine(String singleLine) {
        this.singleLine = singleLine;
    }

    public String getOutFields() {
        return outFields;
    }

    public void setOutFields(String outFields) {
        this.outFields = outFields;
    }

    public String getMaxLocations() {
        return maxLocations;
    }

    public void setMaxLocations(String maxLocations) {
        this.maxLocations = maxLocations;
    }

    public String getMatchOutOfRange() {
        return matchOutOfRange;
    }

    public void setMatchOutOfRange(String matchOutOfRange) {
        this.matchOutOfRange = matchOutOfRange;
    }

    public String getLangCode() {
        return langCode;
    }

    public void setLangCode(String langCode) {
        this.langCode = langCode;
    }

    public String getLocationType() {
        return locationType;
    }

    public void setLocationType(String locationType) {
        this.locationType = locationType;
    }

    public String getSourceCountry() {
        return sourceCountry;
    }

    public void setSourceCountry(String sourceCountry) {
        this.sourceCountry = sourceCountry;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getSearchExtent() {
        return searchExtent;
    }

    public void setSearchExtent(String searchExtent) {
        this.searchExtent = searchExtent;
    }

    public String getOutSR() {
        return outSR;
    }

    public void setOutSR(String outSR) {
        this.outSR = outSR;
    }

    public String getMagicKey() {
        return magicKey;
    }

    public void setMagicKey(String magicKey) {
        this.magicKey = magicKey;
    }

    public String getF() {
        return f;
    }

    public void setF(String f) {
        this.f = f;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public String toString() {
        return "TracfoneOneGeoCoderAddress{" +
                "token='" + token + '\'' +
                ", address='" + address + '\'' +
                ", address2='" + address2 + '\'' +
                ", address3='" + address3 + '\'' +
                ", neighborhood='" + neighborhood + '\'' +
                ", city='" + city + '\'' +
                ", subregion='" + subregion + '\'' +
                ", region='" + region + '\'' +
                ", postal='" + postal + '\'' +
                ", postalExt='" + postalExt + '\'' +
                ", countryCode='" + countryCode + '\'' +
                ", singleLine='" + singleLine + '\'' +
                ", outFields='" + outFields + '\'' +
                ", maxLocations='" + maxLocations + '\'' +
                ", matchOutOfRange='" + matchOutOfRange + '\'' +
                ", langCode='" + langCode + '\'' +
                ", locationType='" + locationType + '\'' +
                ", sourceCountry='" + sourceCountry + '\'' +
                ", category='" + category + '\'' +
                ", location='" + location + '\'' +
                ", distance='" + distance + '\'' +
                ", searchExtent='" + searchExtent + '\'' +
                ", outSR='" + outSR + '\'' +
                ", magicKey='" + magicKey + '\'' +
                ", f='" + f + '\'' +
                ", url='" + url + '\'' +
                '}';
    }
}
