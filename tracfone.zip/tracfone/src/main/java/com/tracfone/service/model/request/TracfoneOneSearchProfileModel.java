/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

/**
 * @author Shireen Fathima
 */
public class TracfoneOneSearchProfileModel {

    private String dbEnv;
    private String profileId;
    private String profileDesc;
    private String featureName;
    private String featureValue;
    private String ratePlan;
    private boolean profileWithoutFeatures;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getProfileDesc() {
        return profileDesc;
    }

    public void setProfileDesc(String profileDesc) {
        this.profileDesc = profileDesc;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public String getFeatureValue() {
        return featureValue;
    }

    public void setFeatureValue(String featureValue) {
        this.featureValue = featureValue;
    }

    public String getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(String ratePlan) {
        this.ratePlan = ratePlan;
    }

    public boolean isProfileWithoutFeatures() {
        return profileWithoutFeatures;
    }

    public void setProfileWithoutFeatures(boolean profileWithoutFeatures) {
        this.profileWithoutFeatures = profileWithoutFeatures;
    }

    @Override
    public String toString() {
        return "TracfoneOneSearchProfileModel{" + "dbEnv=" + dbEnv + ", "
                + "profileId=" + profileId + ", "
                + "profileDesc=" + profileDesc + ", "
                + "featureName=" + featureName + ", "
                + "ratePlan=" + ratePlan + ", "
                + "profileWithoutFeatures=" + profileWithoutFeatures + ", "
                + "featureValue=" + featureValue + '}';
    }

}
