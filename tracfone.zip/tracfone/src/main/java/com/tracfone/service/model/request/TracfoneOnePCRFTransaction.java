package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Gaurav.Sharma
 */
public class TracfoneOnePCRFTransaction {
    private String dbEnv;
    private String dateField1;
    private String blackoutWaitDate;
    private String ttl;
    private String futureTtl;
    private String redemptionDate;
    private String installDate;
    private String toInsertTimestamp;
    private String fromInsertTimestamp;
    private String toUpdateTimestamp;
    private String fromUpdateTimestamp;
    private TracfoneonePaginationSearch paginationSearch;
    private List<TracfoneOneSearchAdditionalModel> searchColumns;

    public TracfoneOnePCRFTransaction() {
        searchColumns = new ArrayList<>();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public TracfoneonePaginationSearch getPaginationSearch() {
        return paginationSearch;
    }

    public void setPaginationSearch(TracfoneonePaginationSearch paginationSearch) {
        this.paginationSearch = paginationSearch;
    }

    public List<TracfoneOneSearchAdditionalModel> getSearchColumns() {
        return searchColumns;
    }

    public void setSearchColumns(List<TracfoneOneSearchAdditionalModel> searchColumns) {
        this.searchColumns = searchColumns;
    }

    public String getDateField1() {
        return dateField1;
    }

    public void setDateField1(String dateField1) {
        this.dateField1 = dateField1;
    }

    public String getBlackoutWaitDate() {
        return blackoutWaitDate;
    }

    public void setBlackoutWaitDate(String blackoutWaitDate) {
        this.blackoutWaitDate = blackoutWaitDate;
    }

    public String getTtl() {
        return ttl;
    }

    public void setTtl(String ttl) {
        this.ttl = ttl;
    }

    public String getFutureTtl() {
        return futureTtl;
    }

    public void setFutureTtl(String futureTtl) {
        this.futureTtl = futureTtl;
    }

    public String getRedemptionDate() {
        return redemptionDate;
    }

    public void setRedemptionDate(String redemptionDate) {
        this.redemptionDate = redemptionDate;
    }

    public String getInstallDate() {
        return installDate;
    }

    public void setInstallDate(String installDate) {
        this.installDate = installDate;
    }

    public String getToInsertTimestamp() {
        return toInsertTimestamp;
    }

    public void setToInsertTimestamp(String toInsertTimestamp) {
        this.toInsertTimestamp = toInsertTimestamp;
    }

    public String getFromInsertTimestamp() {
        return fromInsertTimestamp;
    }

    public void setFromInsertTimestamp(String fromInsertTimestamp) {
        this.fromInsertTimestamp = fromInsertTimestamp;
    }

    public String getToUpdateTimestamp() {
        return toUpdateTimestamp;
    }

    public void setToUpdateTimestamp(String toUpdateTimestamp) {
        this.toUpdateTimestamp = toUpdateTimestamp;
    }

    public String getFromUpdateTimestamp() {
        return fromUpdateTimestamp;
    }

    public void setFromUpdateTimestamp(String fromUpdateTimestamp) {
        this.fromUpdateTimestamp = fromUpdateTimestamp;
    }

    @Override
    public String toString() {
        return "TracfoneOnePCRFTransaction{" +
                "dbEnv='" + dbEnv + '\'' +
                ", dateField1='" + dateField1 + '\'' +
                ", blackoutWaitDate='" + blackoutWaitDate + '\'' +
                ", ttl='" + ttl + '\'' +
                ", futureTtl='" + futureTtl + '\'' +
                ", redemptionDate='" + redemptionDate + '\'' +
                ", installDate='" + installDate + '\'' +
                ", toInsertTimestamp='" + toInsertTimestamp + '\'' +
                ", fromInsertTimestamp='" + fromInsertTimestamp + '\'' +
                ", toUpdateTimestamp='" + toUpdateTimestamp + '\'' +
                ", fromUpdateTimestamp='" + fromUpdateTimestamp + '\'' +
                ", paginationSearch=" + paginationSearch +
                ", searchColumns=" + searchColumns +
                '}';
    }
}
