/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Srinivas Murthy Pulavarthy
 */
public class TFOneRatePlan {
    
    private String objId;
    private String ratePlanName;
    private String privateNetwork;
    private String espidUpdate;
    private String espidNum;
    private String propagateFlagValue;
    private String allowMformApnRequestFlag;
    private String calculateDataUnitsFlag;
    private String thresholdsToTmo;
    private String hotspotBucketsFlag; 
    private String tmoNextGenFlag;
    private List<TFOneRatePlanProfile> ratePlanProfile;
    private List<TFOneCarrierFeature> carrierFeatures;

    public TFOneRatePlan() {
        ratePlanProfile = new ArrayList<>();
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getPrivateNetwork() {
        return privateNetwork;
    }

    public void setPrivateNetwork(String privateNetwork) {
        this.privateNetwork = privateNetwork;
    }

    public String getEspidUpdate() {
        return espidUpdate;
    }

    public void setEspidUpdate(String espidUpdate) {
        this.espidUpdate = espidUpdate;
    }

    public String getEspidNum() {
        return espidNum;
    }

    public void setEspidNum(String espidNum) {
        this.espidNum = espidNum;
    }

    public String getPropagateFlagValue() {
        return propagateFlagValue;
    }

    public void setPropagateFlagValue(String propagateFlagValue) {
        this.propagateFlagValue = propagateFlagValue;
    }

    public String getAllowMformApnRequestFlag() {
        return allowMformApnRequestFlag;
    }

    public void setAllowMformApnRequestFlag(String allowMformApnRequestFlag) {
        this.allowMformApnRequestFlag = allowMformApnRequestFlag;
    }

    public String getCalculateDataUnitsFlag() {
        return calculateDataUnitsFlag;
    }

    public void setCalculateDataUnitsFlag(String calculateDataUnitsFlag) {
        this.calculateDataUnitsFlag = calculateDataUnitsFlag;
    }

    public String getThresholdsToTmo() {
        return thresholdsToTmo;
    }

    public void setThresholdsToTmo(String thresholdsToTmo) {
        this.thresholdsToTmo = thresholdsToTmo;
    }

    public String getHotspotBucketsFlag() {
        return hotspotBucketsFlag;
    }

    public void setHotspotBucketsFlag(String hotspotBucketsFlag) {
        this.hotspotBucketsFlag = hotspotBucketsFlag;
    }

    public String getRatePlanName() {
        return ratePlanName;
    }

    public void setRatePlanName(String ratePlan) {
        this.ratePlanName = ratePlan;
    }

    public List<TFOneRatePlanProfile> getRatePlanProfile() {
        return ratePlanProfile;
    }

    public void setRatePlanProfile(List<TFOneRatePlanProfile> ratePlanProfile) {
        this.ratePlanProfile = ratePlanProfile;
    }

    public List<TFOneCarrierFeature> getCarrierFeatures() {
        return carrierFeatures;
    }

    public void setCarrierFeatures(List<TFOneCarrierFeature> carrierFeatures) {
        this.carrierFeatures = carrierFeatures;
    }

    public String getTmoNextGenFlag() {
        return tmoNextGenFlag;
    }

    public void setTmoNextGenFlag(String tmoNextGenFlag) {
        this.tmoNextGenFlag = tmoNextGenFlag;
    }

    @Override
    public String toString() {
        return "TFOneRatePlan{" + "objId=" + objId + ", "
                + "ratePlanName=" + ratePlanName + ", "
                + "privateNetwork=" + privateNetwork + ", "
                + "espidUpdate=" + espidUpdate + ", "
                + "espidNum=" + espidNum + ", "
                + "propagateFlagValue=" + propagateFlagValue + ", "
                + "allowMformApnRequestFlag=" + allowMformApnRequestFlag + ", "
                + "calculateDataUnitsFlag=" + calculateDataUnitsFlag + ", "
                + "thresholdsToTmo=" + thresholdsToTmo + ", "
                + "hotspotBucketsFlag=" + hotspotBucketsFlag + ", "
                + "tmoNextGenFlag=" + tmoNextGenFlag + ", "
                + "ratePlanProfile=" + ratePlanProfile + ", "
                + "carrierFeatures=" + carrierFeatures + '}';
    }
    
    
    
}
