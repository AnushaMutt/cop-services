package com.tracfone.service.model.request;


import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * TABLE: table_x_parent
 *
 * @author Pritesh Singh
 */
public class TracfoneOneParent {
    private String dbEnv;
    @Digits(integer = 38, fraction = 0, message = "ObjId must be a number")
    private String objId;
    @Size(min = 1, message = "Parent Name cannot be null")
    @Size(max = 40, message = "Parent Name cannot have more than 40 characters")
    private String parentName;
    @Size(max = 30, message = "Parent Id cannot have more than 30 characters")
    private String parentId;
    @Size(min = 1, message = "Status cannot be null")
    @Size(max = 30, message = "Status cannot have more than 30 characters")
    private String status;
    @Digits(integer = 38, fraction = 0, message = "Hold Analog Deac must be a number")
    private String holdAnalogDeac;
    @Digits(integer = 38, fraction = 0, message = "Hold Digital Deac must be a number")
    private String holdDigitalDeac;
    @Digits(integer = 38, fraction = 0, message = "Parent 2 Temp Queue must be a number")
    private String parent2TempQueue;
    @Digits(integer = 38, fraction = 0, message = "No Inventory must be a number")
    private String noInventory;
    @Size(max = 20, message = "VM Access Num cannot have more than 20 characters")
    private String vmAccessNum;
    @Digits(integer = 38, fraction = 0, message = "Auto Port In must be a number")
    private String autoPortIn;
    @Digits(integer = 38, fraction = 0, message = "Auto Port Out must be a number")
    private String autoPortOut;
    @Digits(integer = 38, fraction = 0, message = "No MSID must be a number")
    private String noMsid;
    @Size(max = 30, message = "OTA Carrier cannot have more than 30 characters")
    private String otaCarrier;
    private String otaEndDate;
    @Size(max = 30, message = "Ota PSMS Address cannot have more than 30 characters")
    private String otaPsmsAddress;
    private String otaStartDate;
    @Digits(integer = 38, fraction = 0, message = "Next Available must be a number")
    private String nextAvailable;
    @Size(max = 50, message = "Queue Name cannot have more than 50 characters")
    private String queueName;
    @Digits(integer = 38, fraction = 0, message = "Block Port In must be a number")
    private String blockPortIn;
    @Digits(integer = 38, fraction = 0, message = "MEID Carrier must be a number")
    private String meidCarrier;
    @Digits(integer = 38, fraction = 0, message = "OTA React must be a number")
    private String otaReact;
    @Digits(integer = 38, fraction = 0, message = "Agg Carr Code must be a number")
    private String aggCarrCode;
    @Digits(integer = 22, fraction = 0, message = "SUI Rule ObjId must be a number")
    private String suiRuleObjId;
    @Size(max = 100, message = "Deact Sim Ep Days cannot have more than 100 characters")
    private String deactSimExpDays;
    @Size(max = 30, message = "Override Sms Address cannot have more than 30 characters")
    private String overrideSmsAddress;
    @Size(max = 30, message = "Trigger Id cannot have more than 30 characters")
    private String triggerId;
    @Size(max = 6, message = "Parent Short Name cannot have more than 6 characters")
    private String parentShortName;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String ParentName) {
        this.parentName = ParentName;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getHoldAnalogDeac() {
        return holdAnalogDeac;
    }

    public void setHoldAnalogDeac(String holdAnalogDeac) {
        this.holdAnalogDeac = holdAnalogDeac;
    }

    public String getHoldDigitalDeac() {
        return holdDigitalDeac;
    }

    public void setHoldDigitalDeac(String holdDigitalDeac) {
        this.holdDigitalDeac = holdDigitalDeac;
    }

    public String getParent2TempQueue() {
        return parent2TempQueue;
    }

    public void setParent2TempQueue(String parent2TempQueue) {
        this.parent2TempQueue = parent2TempQueue;
    }

    public String getNoInventory() {
        return noInventory;
    }

    public void setNoInventory(String noInventory) {
        this.noInventory = noInventory;
    }

    public String getVmAccessNum() {
        return vmAccessNum;
    }

    public void setVmAccessNum(String vmAccessNum) {
        this.vmAccessNum = vmAccessNum;
    }

    public String getAutoPortIn() {
        return autoPortIn;
    }

    public void setAutoPortIn(String autoPortIn) {
        this.autoPortIn = autoPortIn;
    }

    public String getAutoPortOut() {
        return autoPortOut;
    }

    public void setAutoPortOut(String autoPortOut) {
        this.autoPortOut = autoPortOut;
    }

    public String getNoMsid() {
        return noMsid;
    }

    public void setNoMsid(String noMsid) {
        this.noMsid = noMsid;
    }

    public String getOtaCarrier() {
        return otaCarrier;
    }

    public void setOtaCarrier(String otaCarrier) {
        this.otaCarrier = otaCarrier;
    }

    public String getOtaEndDate() {
        return otaEndDate;
    }

    public void setOtaEndDate(String otaEndDate) {
        this.otaEndDate = otaEndDate;
    }

    public String getOtaPsmsAddress() {
        return otaPsmsAddress;
    }

    public void setOtaPsmsAddress(String otaPsmsAddress) {
        this.otaPsmsAddress = otaPsmsAddress;
    }

    public String getOtaStartDate() {
        return otaStartDate;
    }

    public void setOtaStartDate(String otaStartDate) {
        this.otaStartDate = otaStartDate;
    }

    public String getNextAvailable() {
        return nextAvailable;
    }

    public void setNextAvailable(String nextAvailable) {
        this.nextAvailable = nextAvailable;
    }

    public String getQueueName() {
        return queueName;
    }

    public void setQueueName(String queueName) {
        this.queueName = queueName;
    }

    public String getBlockPortIn() {
        return blockPortIn;
    }

    public void setBlockPortIn(String blockPortIn) {
        this.blockPortIn = blockPortIn;
    }

    public String getMeidCarrier() {
        return meidCarrier;
    }

    public void setMeidCarrier(String meidCarrier) {
        this.meidCarrier = meidCarrier;
    }

    public String getOtaReact() {
        return otaReact;
    }

    public void setOtaReact(String otaReact) {
        this.otaReact = otaReact;
    }

    public String getAggCarrCode() {
        return aggCarrCode;
    }

    public void setAggCarrCode(String aggCarrCode) {
        this.aggCarrCode = aggCarrCode;
    }

    public String getSuiRuleObjId() {
        return suiRuleObjId;
    }

    public void setSuiRuleObjId(String suiRuleObjId) {
        this.suiRuleObjId = suiRuleObjId;
    }

    public String getDeactSimExpDays() {
        return deactSimExpDays;
    }

    public void setDeactSimExpDays(String deactSimExpDays) {
        this.deactSimExpDays = deactSimExpDays;
    }

    public String getOverrideSmsAddress() {
        return overrideSmsAddress;
    }

    public void setOverrideSmsAddress(String overrideSmsAddress) {
        this.overrideSmsAddress = overrideSmsAddress;
    }

    public String getTriggerId() {
        return triggerId;
    }

    public void setTriggerId(String triggerId) {
        this.triggerId = triggerId;
    }

    public String getParentShortName() {
        return parentShortName;
    }

    public void setParentShortName(String parentShortName) {
        this.parentShortName = parentShortName;
    }

    @Override
    public String toString() {
        return "TracfoneOneParent{" +
                "dbEnv='" + dbEnv + '\'' +
                ", objId='" + objId + '\'' +
                ", parentName='" + parentName + '\'' +
                ", parentId='" + parentId + '\'' +
                ", status='" + status + '\'' +
                ", holdAnalogDeac='" + holdAnalogDeac + '\'' +
                ", holdDigitalDeac='" + holdDigitalDeac + '\'' +
                ", parent2TempQueue='" + parent2TempQueue + '\'' +
                ", noInventory='" + noInventory + '\'' +
                ", vmAccessNum='" + vmAccessNum + '\'' +
                ", autoPortIn='" + autoPortIn + '\'' +
                ", autoPortOut='" + autoPortOut + '\'' +
                ", noMsid='" + noMsid + '\'' +
                ", otaCarrier='" + otaCarrier + '\'' +
                ", otaEndDate='" + otaEndDate + '\'' +
                ", otaPsmsAddress='" + otaPsmsAddress + '\'' +
                ", otaStartDate='" + otaStartDate + '\'' +
                ", nextAvailable='" + nextAvailable + '\'' +
                ", queueName='" + queueName + '\'' +
                ", blockPortIn='" + blockPortIn + '\'' +
                ", meidCarrier='" + meidCarrier + '\'' +
                ", otaReact='" + otaReact + '\'' +
                ", aggCarrCode='" + aggCarrCode + '\'' +
                ", suiRuleObjId='" + suiRuleObjId + '\'' +
                ", deactSimEpDays='" + deactSimExpDays + '\'' +
                ", overrideSmsAddress='" + overrideSmsAddress + '\'' +
                ", triggerId='" + triggerId + '\'' +
                ", parentShortName='" + parentShortName + '\'' +
                '}';
    }
}
