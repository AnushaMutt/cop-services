package com.tracfone.service.model.response;

/**
 * @author Thejaswini
 */
public class TFOneVerizonZipNPANXX {
    private String zip;
    private String nPA;
    private String nXX;
    private String nPANXX;
    private String accountNum;
    private String template;

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getnPA() {
        return nPA;
    }

    public void setnPA(String nPA) {
        this.nPA = nPA;
    }

    public String getnXX() {
        return nXX;
    }

    public void setnXX(String nXX) {
        this.nXX = nXX;
    }

    public String getnPANXX() {
        return nPANXX;
    }

    public void setnPANXX(String nPANXX) {
        this.nPANXX = nPANXX;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    @Override
    public String toString() {
        return "TFOneVerizonZipNPANXX{" +
                "zip='" + zip + '\'' +
                ", NPA='" + nPA + '\'' +
                ", NXX='" + nXX + '\'' +
                ", NPANXX='" + nPANXX + '\'' +
                ", AccountNum='" + accountNum + '\'' +
                ", template='" + template + '\'' +
                '}';
    }
}
