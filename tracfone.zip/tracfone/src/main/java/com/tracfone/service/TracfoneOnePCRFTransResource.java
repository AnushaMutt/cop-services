package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.controller.TracfoneOnePCRFTransControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOnePCRFTransaction;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.request.TracfoneOneUserTask;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOnePCRFTransSearchResult;
import com.tracfone.service.model.response.TFOneUserHistory;
import com.tracfone.service.model.response.TFOneUserTask;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

import com.tracfone.service.util.TracfoneOneConstantReport;
import javax.ws.rs.PathParam;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author Gaurav.Sharma
 */
@Path("pcrf")
public class TracfoneOnePCRFTransResource implements TracfoneOneConstantReport {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOnePCRFTransResource.class);

    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @EJB
    private TracfoneOnePCRFTransControllerLocal pcrfTransController;

    @EJB
    private TracfoneControllerLocalAction tracfoneControllerAction;

    @EJB
    private TracfoneControllerLocal tracfoneController;

    @Context
    private SecurityContext securityContext;

    @POST
    @Path("pcrftransactions/allusertasks")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getUserTaskByUserId(final TracfoneOneUserTask tfOneUserTask) {
        tfOneUserTask.setType("PCRF_TRANSACTION");
        List<TFOneUserTask> userTasks;
        try {
            userTasks = tracfoneControllerAction.getUserTaskByUserId(tfOneUserTask);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(userTasks), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("pcrftransactions/updateusertask")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateUserTask(final TracfoneOneUserTask tfOneUserTask) {
        TFOneUserTask tfUserTask;
        try {
            tfUserTask = tracfoneControllerAction.updateUserTask(tfOneUserTask, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfUserTask), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for User Histories based on UserId
     *
     * @param tfOneUserHistory
     * @return
     */
    @POST
    @Path("pcrftransactions/userhistory")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getUserHistoryByUserId(final TracfoneOneUserHistory tfOneUserHistory) {
        List<TFOneUserHistory> userHistories = new ArrayList<>();
        try {
            tfOneUserHistory.setType("PCRF_");
            userHistories = tracfoneControllerAction.getUserHistoryByUserId(tfOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(userHistories), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("pcrftransactions/assignusertask")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertUserTask(final TracfoneOneUserTask tfOneUserTask) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneControllerAction.insertUserTask(tfOneUserTask, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @GET
    @Path("pcrftransactions/userlist")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllUsers() {
        List<TFOneAdminUser> tfOneAdminUsers = null;
        try {
            tfOneAdminUsers = tracfoneController.getAllUsers(getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            LOGGER.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneAdminUsers), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for PCRF Transaction based on all columns
     *
     * @param pcrfTransaction
     * @return
     */
    @POST
    @Path("pcrftransactions/viewpcrftransaction")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response viewPcrfTransactions(final TracfoneOnePCRFTransaction pcrfTransaction) {
        TFOnePCRFTransSearchResult pcrfTransactions;
        try {
            pcrfTransactions = pcrfTransController.viewPcrfTransaction(pcrfTransaction);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(pcrfTransactions), MediaType.APPLICATION_JSON).build();
    }

    @GET
    @Path("pcrftransactions/allfailures/{flag}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllFailuresForPCRF(@PathParam("flag") boolean flag) {
        String jsonResponse = null;
        try {
            jsonResponse = tracfoneController.getAllFailures(TRACFONE_REPORTNAME_ALL_PCRF_FAILURES, flag);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(jsonResponse, MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves the user object making request from the principal.
     *
     * @return
     */
    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }
}
