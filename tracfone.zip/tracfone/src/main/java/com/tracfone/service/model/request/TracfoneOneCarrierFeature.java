/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * TABLE SA.TABLE_X_CARRIER_FEATURES
 *
 * @author Nidhi Mantri
 */
public class TracfoneOneCarrierFeature {

    private String dbEnv;
    private String objId;
    @Digits(integer = 38, fraction = 0, message = "Dev must be a number")
    private String dev;
    @Size(max = 30, message = "xTechnology cannot have more than 30 characters")
    private String xTechnology;
    @Size(max = 60, message = "Rate Plan Name cannot have more than 60 characters")
    private String xRatePlan;
    @Digits(integer = 38, fraction = 0, message = "xVoicemail must be a number")
    private String xVoicemail;
    @Size(max = 30, message = "xVM Code cannot have more than 30 characters")
    private String xVmCode;
    @Digits(integer = 38, fraction = 0, message = "xVM Package must be a number")
    private String xVmPackage;
    @Digits(integer = 38, fraction = 0, message = "xCaller ID must be a number")
    private String xCallerId;
    @Size(max = 30, message = "xID Code cannot have more than 30 characters")
    private String xIdCode;
    @Digits(integer = 38, fraction = 0, message = "xID Package must be a number")
    private String xIdPackage;
    @Digits(integer = 38, fraction = 0, message = "xSMS must be a number")
    private String xSms;
    @Size(max = 30, message = "xSMS Code cannot have more than 30 characters")
    private String xSmsCode;
    @Digits(integer = 38, fraction = 0, message = "xSMS Package must be a number")
    private String xSmsPackage;
    @Digits(integer = 38, fraction = 0, message = "xCall Waiting must be a number")
    private String xCallWaiting;
    @Size(max = 30, message = "xCW Code cannot have more than 30 characters")
    private String xCwCode;
    @Digits(integer = 38, fraction = 0, message = "xCW Package must be a number")
    private String xCwPackage;
    @Size(max = 30, message = "XDigital Feature cannot have more than 30 characters")
    private String xDigitalFeature;
    @Digits(integer = 38, fraction = 0, message = "xDig Feature must be a number")
    private String xDigFeature;
    private String xFeature2xCarrier;
    @Size(max = 30, message = "xSMSC Number cannot have more than 30 characters")
    private String xSmscNumber;
    @Digits(integer = 38, fraction = 0, message = "xData must be a number")
    private String xData;
    @Digits(integer = 38, fraction = 0, message = "xRestricted Use must be a number")
    private String xRestrictedUse;
    @Size(max = 10, message = "xSwitch Base Rate cannot have more than 10 characters")
    private String xSwitchBaseRate;
    private String xFeatures2BusOrg;
    @Digits(integer = 1, fraction = 0, message = "x Is SWB Carrier must be a number not greater than 9")
    private String xIsSwbCarrier;
    @Digits(integer = 38, fraction = 0, message = "xMpn must be a number")
    private String xMpn;
    @Size(max = 30, message = "xMPN Code cannot have more than 30 characters")
    private String xMpnCode;
    @Size(max = 60, message = "xPool Name cannot have more than 60 characters")
    private String xPoolName;
    @Size(max = 1, message = "Create MForm IG Flag cannot have more than one character")
    private String createMformIgFlag;
    @Size(max = 1, message = "Use CF Extension Flag cannot have more than one character")
    private String useCfExtensionFlag;
    @Digits(integer = 38, fraction = 0, message = "Data Saver must be a number")
    private String dataSaver;
    @Size(max = 30, message = "Data Saver Code cannot have more than 30 characters")
    private String dataSaverCode;
    @Size(max = 1, message = "Use RP Extension Flag cannot have more than one character")
    private String useRpExtensionFlag;
    @Size(max = 1, message = "TMO NextGen Flag cannot have more than one character")
    private String tmoNextGenFlag;
    private boolean edited;
    private boolean legacy;
    @Valid
    private TracfoneOneServicePlanCarrierFeature servicePlanCarrierFeature;
    @Valid
    private List<TracfoneOneRatePlanExtensionLink> ratePlanExtensionLinks;

    public TracfoneOneCarrierFeature() {
        servicePlanCarrierFeature = new TracfoneOneServicePlanCarrierFeature();
        ratePlanExtensionLinks = new ArrayList<>();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public TracfoneOneServicePlanCarrierFeature getServicePlanCarrierFeature() {
        return servicePlanCarrierFeature;
    }

    public void setServicePlanCarrierFeature(TracfoneOneServicePlanCarrierFeature servicePlanCarrierFeature) {
        this.servicePlanCarrierFeature = servicePlanCarrierFeature;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getDev() {
        return dev;
    }

    public void setDev(String dev) {
        this.dev = dev;
    }

    public String getxTechnology() {
        return xTechnology;
    }

    public void setxTechnology(String xTechnology) {
        this.xTechnology = xTechnology;
    }

    public String getxRatePlan() {
        return xRatePlan;
    }

    public void setxRatePlan(String xRatePlan) {
        this.xRatePlan = xRatePlan;
    }

    public String getxVoicemail() {
        return xVoicemail;
    }

    public void setxVoicemail(String xVoicemail) {
        this.xVoicemail = xVoicemail;
    }

    public String getxVmCode() {
        return xVmCode;
    }

    public void setxVmCode(String xVmCode) {
        this.xVmCode = xVmCode;
    }

    public String getxVmPackage() {
        return xVmPackage;
    }

    public void setxVmPackage(String xVmPackage) {
        this.xVmPackage = xVmPackage;
    }

    public String getxCallerId() {
        return xCallerId;
    }

    public void setxCallerId(String xCallerId) {
        this.xCallerId = xCallerId;
    }

    public String getxIdCode() {
        return xIdCode;
    }

    public void setxIdCode(String xIdCode) {
        this.xIdCode = xIdCode;
    }

    public String getxIdPackage() {
        return xIdPackage;
    }

    public void setxIdPackage(String xIdPackage) {
        this.xIdPackage = xIdPackage;
    }

    public String getxSms() {
        return xSms;
    }

    public void setxSms(String xSms) {
        this.xSms = xSms;
    }

    public String getxSmsCode() {
        return xSmsCode;
    }

    public void setxSmsCode(String xSmsCode) {
        this.xSmsCode = xSmsCode;
    }

    public String getxSmsPackage() {
        return xSmsPackage;
    }

    public void setxSmsPackage(String xSmsPackage) {
        this.xSmsPackage = xSmsPackage;
    }

    public String getxCallWaiting() {
        return xCallWaiting;
    }

    public void setxCallWaiting(String xCallWaiting) {
        this.xCallWaiting = xCallWaiting;
    }

    public String getxCwCode() {
        return xCwCode;
    }

    public void setxCwCode(String xCwCode) {
        this.xCwCode = xCwCode;
    }

    public String getxCwPackage() {
        return xCwPackage;
    }

    public void setxCwPackage(String xCwPackage) {
        this.xCwPackage = xCwPackage;
    }

    public String getxDigitalFeature() {
        return xDigitalFeature;
    }

    public void setxDigitalFeature(String xDigitalFeature) {
        this.xDigitalFeature = xDigitalFeature;
    }

    public String getxDigFeature() {
        return xDigFeature;
    }

    public void setxDigFeature(String xDigFeature) {
        this.xDigFeature = xDigFeature;
    }

    public String getxFeature2xCarrier() {
        return xFeature2xCarrier;
    }

    public void setxFeature2xCarrier(String xFeature2xCarrier) {
        this.xFeature2xCarrier = xFeature2xCarrier;
    }

    public String getxSmscNumber() {
        return xSmscNumber;
    }

    public void setxSmscNumber(String xSmscNumber) {
        this.xSmscNumber = xSmscNumber;
    }

    public String getxData() {
        return xData;
    }

    public void setxData(String xData) {
        this.xData = xData;
    }

    public String getxRestrictedUse() {
        return xRestrictedUse;
    }

    public void setxRestrictedUse(String xRestrictedUse) {
        this.xRestrictedUse = xRestrictedUse;
    }

    public String getxSwitchBaseRate() {
        return xSwitchBaseRate;
    }

    public void setxSwitchBaseRate(String xSwitchBaseRate) {
        this.xSwitchBaseRate = xSwitchBaseRate;
    }

    public String getxIsSwbCarrier() {
        return xIsSwbCarrier;
    }

    public void setxIsSwbCarrier(String xIsSwbCarrier) {
        this.xIsSwbCarrier = xIsSwbCarrier;
    }

    public String getxMpn() {
        return xMpn;
    }

    public void setxMpn(String xMpn) {
        this.xMpn = xMpn;
    }

    public String getxPoolName() {
        return xPoolName;
    }

    public void setxPoolName(String xPoolName) {
        this.xPoolName = xPoolName;
    }

    public String getCreateMformIgFlag() {
        return createMformIgFlag;
    }

    public void setCreateMformIgFlag(String createMformIgFlag) {
        this.createMformIgFlag = createMformIgFlag;
    }

    public String getUseCfExtensionFlag() {
        return useCfExtensionFlag;
    }

    public void setUseCfExtensionFlag(String useCfExtensionFlag) {
        this.useCfExtensionFlag = useCfExtensionFlag;
    }

    public String getDataSaver() {
        return dataSaver;
    }

    public void setDataSaver(String dataSaver) {
        this.dataSaver = dataSaver;
    }

    public String getDataSaverCode() {
        return dataSaverCode;
    }

    public void setDataSaverCode(String dataSaverCode) {
        this.dataSaverCode = dataSaverCode;
    }

    public String getUseRpExtensionFlag() {
        return useRpExtensionFlag;
    }

    public void setUseRpExtensionFlag(String useRpExtensionFlag) {
        this.useRpExtensionFlag = useRpExtensionFlag;
    }

    public String getTmoNextGenFlag() {
        return tmoNextGenFlag;
    }

    public void setTmoNextGenFlag(String tmoNextGenFlag) {
        this.tmoNextGenFlag = tmoNextGenFlag;
    }

    public String getxFeatures2BusOrg() {
        return xFeatures2BusOrg;
    }

    public void setxFeatures2BusOrg(String xFeatures2BusOrg) {
        this.xFeatures2BusOrg = xFeatures2BusOrg;
    }

    public String getxMpnCode() {
        return xMpnCode;
    }

    public void setxMpnCode(String xMpnCode) {
        this.xMpnCode = xMpnCode;
    }
    
    public List<TracfoneOneRatePlanExtensionLink> getRatePlanExtensionLinks() {
        return ratePlanExtensionLinks;
    }

    public void setRatePlanExtensionLinks(List<TracfoneOneRatePlanExtensionLink> ratePlanExtensionLinks) {
        this.ratePlanExtensionLinks = ratePlanExtensionLinks;
    }

    public boolean isEdited() {
        return edited;
    }

    public void setEdited(boolean edited) {
        this.edited = edited;
    }

    public boolean isLegacy() { return legacy; }

    public void setLegacy(boolean legacy) { this.legacy = legacy; }

    @Override
    public String toString() {
        return "TracfoneOneCarrierFeature{" + "dbEnv=" + dbEnv + ", "
                + "objId=" + objId + ", "
                + "dev=" + dev + ", "
                + "xTechnology=" + xTechnology + ", "
                + "xRatePlan=" + xRatePlan + ", "
                + "xVoicemail=" + xVoicemail + ", "
                + "xVmCode=" + xVmCode + ", "
                + "xVmPackage=" + xVmPackage + ", "
                + "xCallerId=" + xCallerId + ", "
                + "xIdCode=" + xIdCode + ", "
                + "xIdPackage=" + xIdPackage + ", "
                + "xSms=" + xSms + ", "
                + "xSmsCode=" + xSmsCode + ", "
                + "xSmsPackage=" + xSmsPackage + ", "
                + "xCallWaiting=" + xCallWaiting + ", "
                + "xCwCode=" + xCwCode + ", "
                + "xCwPackage=" + xCwPackage + ", "
                + "xDigitalFeature=" + xDigitalFeature + ", "
                + "xDigFeature=" + xDigFeature + ", "
                + "xFeature2xCarrier=" + xFeature2xCarrier + ", "
                + "xSmscNumber=" + xSmscNumber + ", "
                + "xData=" + xData + ", "
                + "xRestrictedUse=" + xRestrictedUse + ", "
                + "xSwitchBaseRate=" + xSwitchBaseRate + ", "
                + "xFeatures2BusOrg=" + xFeatures2BusOrg + ", "
                + "xIsSwbCarrier=" + xIsSwbCarrier + ", "
                + "xMpn=" + xMpn + ", "
                + "xMpnCode=" + xMpnCode + ", "
                + "xPoolName=" + xPoolName + ", "
                + "createMformIgFlag=" + createMformIgFlag + ", "
                + "useCfExtensionFlag=" + useCfExtensionFlag + ", "
                + "dataSaver=" + dataSaver + ", "
                + "dataSaverCode=" + dataSaverCode + ", "
                + "useRpExtensionFlag=" + useRpExtensionFlag + ", "
                + "tmoNextGenFlag=" + tmoNextGenFlag + ", "
                + "edited=" + edited + ", "
                + "legacy=" + legacy + ", "
                + "ratePlanExtensionLinks=" + ratePlanExtensionLinks + ", "
                + "servicePlanCarrierFeature=" + servicePlanCarrierFeature + '}';
    }

 
}
