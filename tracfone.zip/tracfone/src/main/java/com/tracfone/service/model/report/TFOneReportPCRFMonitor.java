package com.tracfone.service.model.report;

public class TFOneReportPCRFMonitor {
    private String xDate;
    private String pcrfParentName;
    private String orderType;
    private String sumQ;
    private String sumL;
    private String sumW;
    private String sumS;
    private String sumC;
    private String sumF;
    private String sumE;
    private String sumOthers;

    public String getxDate() {
        return xDate;
    }

    public void setxDate(String xDate) {
        this.xDate = xDate;
    }

    public String getPcrfParentName() {
        return pcrfParentName;
    }

    public void setPcrfParentName(String pcrfParentName) {
        this.pcrfParentName = pcrfParentName;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getSumQ() {
        return sumQ;
    }

    public void setSumQ(String sumQ) {
        this.sumQ = sumQ;
    }

    public String getSumL() {
        return sumL;
    }

    public void setSumL(String sumL) {
        this.sumL = sumL;
    }

    public String getSumW() {
        return sumW;
    }

    public void setSumW(String sumW) {
        this.sumW = sumW;
    }

    public String getSumS() {
        return sumS;
    }

    public void setSumS(String sumS) {
        this.sumS = sumS;
    }

    public String getSumC() {
        return sumC;
    }

    public void setSumC(String sumC) {
        this.sumC = sumC;
    }

    public String getSumF() {
        return sumF;
    }

    public void setSumF(String sumF) {
        this.sumF = sumF;
    }

    public String getSumE() {
        return sumE;
    }

    public void setSumE(String sumE) {
        this.sumE = sumE;
    }

    public String getSumOthers() {
        return sumOthers;
    }

    public void setSumOthers(String sumOthers) {
        this.sumOthers = sumOthers;
    }

    @Override
    public String toString() {
        return "TFOneReportPCRFMonitor{" +
                "xDate='" + xDate + '\'' +
                ", pcrfParentName='" + pcrfParentName + '\'' +
                ", orderType='" + orderType + '\'' +
                ", sumQ='" + sumQ + '\'' +
                ", sumL='" + sumL + '\'' +
                ", sumW='" + sumW + '\'' +
                ", sumS='" + sumS + '\'' +
                ", sumC='" + sumC + '\'' +
                ", sumF='" + sumF + '\'' +
                ", sumE='" + sumE + '\'' +
                ", sumOthers='" + sumOthers + '\'' +
                '}';
    }
}
