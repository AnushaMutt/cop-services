/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.util;

/**
 * @author user
 */
public interface TracfoneOneConstantReport {

    String TRACFONE_TRANSACTIONTYPE_TT = "tt";
    String TRACFONE_TRANSACTIONTYPE_PCRF = "pcrf";

    String TRACFONE_REPORTNAME_MONITOR = "monitor";
    String TRACFONE_REPORTNAME_MONITOR_GRAPH = "monitorGraph";
    String TRACFONE_REPORTNAME_ALLFAILURES = "allfailures";

    String REPORT_SQL_ALLFAILURES =
            " with ig_tab as (\n" +
                    "                SELECT ACTION_ITEM_ID,\n" +
                    "                       TRANSACTION_ID,\n" +
                    "                       CASE WHEN EXISTS (SELECT 1 FROM TABLE_TASK TT WHERE TT.TASK_ID = IG.ACTION_ITEM_ID) THEN 'SYSTEM' ELSE 'BACKEND' END TRANS_TYPE, \n" +
                    "                       APPLICATION_SYSTEM,\n" +
                    "                       DECODE(template,'RSS','VZW','SUREPAY','VZW','TMOUN','TMOBILE',TEMPLATE) X_CARRIER,\n" +
                    "                       ORDER_TYPE,\n" +
                    "                       CASE WHEN ORDER_TYPE IN('A','AP','E','PAP') THEN 'ACT/REACT'\n" +
                    "                            WHEN ORDER_TYPE IN('CR','R','CRU','PCR') THEN 'CREDITS'\n" +
                    "                            WHEN ORDER_TYPE IN('MINC','SIMC','EC') THEN 'EQUIP_CHNG'\n" +
                    "                            WHEN ORDER_TYPE IN('D','S') THEN 'DEACTS' \n" +
                    "                            WHEN ORDER_TYPE IN('UI','PFR') THEN 'SUI' \n" +
                    "                            WHEN ORDER_TYPE IN ('EPIR','PIR','IPI') THEN 'PORTS' ELSE 'OTHER' END ORDER_TYPE_GROUP,\n" +
                    "                       ESN,\n" +
                    "                       ESN_HEX,\n" +
                    "                       ICCID,\n" +
                    "                       MIN,\n" +
                    "                       MSID,\n" +
                    "                       STATUS,\n" +
                    "                       NVL((SELECT SUM(1) FROM GW1.IG_FAILED_LOG IGF WHERE IGF.ACTION_ITEM_ID = IG.ACTION_ITEM_ID),0) FAILED_COUNT,\n" +
                    "                       TRUNC(CREATION_DATE,'hh24') + (TRUNC(TO_CHAR(CREATION_DATE,'mi')/30)*30)/24/60 X_TIME_SEGMENT,\n" +
                    "                       CREATION_DATE,\n" +
                    "                       UPDATE_DATE,\n" +
                    "                       ROUND((SYSDATE-UPDATE_DATE)*1440,0) MINUTES_WAITING,\n" +
                    "                       ROUND((UPDATE_DATE-CREATION_DATE)*1440,0) MINUTES_TO_COMP_DB,\n" +
                    "                       ROUND((CARRIER_END_TRANS_TIME-CARRIER_INITIAL_TRANS_TIME)*1440,0) MINUTES_TO_COMP_CARR,\n" +
                    "                       REGEXP_REPLACE(STATUS_MESSAGE,'(\\.\\sFailed on.*)|(\\s\\d{10,20})|(:\\d{10}\\swas)|(:\\s.*\\spending)|(:cvc-pattern-valid.*)',' *') REGEXP_STATUS_MESSAGE,\n" +
                    "                       STATUS_MESSAGE ORIGINAL_ERROR_MESSAGE\n" +
                    "                FROM   IG_TRANSACTION IG\n" +
                    "                WHERE  1=1\n" +
                    "                AND    ORDER_TYPE NOT IN ('APN','IPRL','BI','VD','VP','POC','SI','E911')\n" +
                    "                AND    STATUS IN('F', 'FF')\n" +
                    "               )\n" +
                    "SELECT DISTINCT\n" +
                    "       TRANS_TYPE,\n" +
                    "       X_CARRIER,\n" +
                    "       TO_CHAR(X_TIME_SEGMENT, 'YYYY:MM:DD HH24:MI:SS') X_TIME_SEGMENT," +
                    "       ORDER_TYPE_GROUP,\n" +
                    "                  COUNT(TRANSACTION_ID)OVER(PARTITION BY TRANS_TYPE,X_CARRIER,X_TIME_SEGMENT,ORDER_TYPE_GROUP) TOTAL_TRANS_COUNT,\n" +
                    "                  ROUND(SUM(CASE WHEN STATUS IN('E','F','FF') THEN 1 ELSE 0 END)OVER(PARTITION BY TRANS_TYPE,X_CARRIER,X_TIME_SEGMENT,ORDER_TYPE_GROUP) /\n" +
                    "                   COUNT(TRANSACTION_ID)OVER(PARTITION BY TRANS_TYPE,X_CARRIER,X_TIME_SEGMENT,ORDER_TYPE_GROUP),2) PERCENT_FAILURE,\n" +
                    "       SUM(FAILED_COUNT)OVER(PARTITION BY TRANS_TYPE,X_CARRIER,X_TIME_SEGMENT,ORDER_TYPE_GROUP) FAILURE_COUNT,\n" +
                    "       SUM(CASE WHEN STATUS IN('E','F','FF') THEN 1 ELSE 0 END)OVER(PARTITION BY TRANS_TYPE,X_CARRIER,X_TIME_SEGMENT,ORDER_TYPE_GROUP) SUM_F   \n" +
                    "FROM   IG_TAB\n" +
                    "ORDER BY 1,2,3,4 ";

    public final String REPORT_SQL_MONITOR = "select distinct\n" +
            //"       --sysdate time_ran,\n" +
            "       x_time_segment AS x_date,\n" +
            "       trans_type,\n" +
            "       template,\n" +
            "       order_type_group AS order_Type,\n" +
            "       to_char(sum(case when status = 'Q' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_q,\n" +
            "       to_char(sum(case when status = 'L' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_l,\n" +
            "       to_char(sum(case when status = 'CP' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_cp,\n" +
            "       to_char(sum(case when status = 'WP' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_wp,\n" +
            "       to_char(sum(case when status = 'W' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_w,\n" +
            "       to_char(sum(case when status in('S','SS') then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_s,\n" +
            "       to_char(sum(case when status = 'E' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_e,\n" +
            "       to_char(sum(case when status in('F','FF') then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_f,\n" +
            "       to_char(sum(case when status ='TF' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_tf,\n" +
            "       to_char(sum(case when status ='HW' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_hw,\n" +
            "       TO_CHAR(count(action_item_Id)over(partition by trans_type,x_time_segment,order_type_group,template),'999G999G999') total_trans_count \n" +
            "  from (\n" +
            " select /*+ index(ig, IG_TRANSACTION_CREATION_DATE) */ decode(template,'TMOSM','TMO_SIMPLE','TMOUN','TMOBILE','RSS','VZW','SUREPAY','VZW',template) template,\n" +
            "       action_item_id,\n" +
            "       transaction_id,\n" +
            "       order_type,\n" +
            "       case when order_type in('A','AP','E','PAP') then 'ACT/REACT'\n" +
            "            when order_type in('CR','R','CRU','PCR') then 'CREDITS'\n" +
            "            when order_type in('MINC','SIMC') then 'EQUIP_CHNG'\n" +
            "            when order_type in('D','S') then 'DEACTS'\n" +
            "            when order_type in('PFR','UI') then 'SUI'\n" +
            "            when order_type ='UPO' then 'PORT_OUT'\n" +
            "            when order_Type = 'SLB' then 'SL_BENEFIT' else 'OTHER' end order_type_group,\n" +
            "       trunc(creation_date,'hh24') + (trunc(to_char(creation_date,'mi')/15)*15)/24/60 x_time_segment,\n" +
            "       round((update_date-ig.creation_date)*86400,0) db_secs_to_complete,\n" +
            "       round((CARRIER_END_TRANS_TIME-CARRIER_INITIAL_TRANS_TIME)*86400,0) carrier_secs_to_complete,\n" +
            "       round((sysdate-ig.update_date)*86400,0) secs_waiting,\n" +
            "       status,\n" +
            "       case when exists (select 1 from table_task tt where tt.task_id = ig.action_item_id) then 'SYSTEM_AI' else 'BACKEND_AI' end trans_type\n" +
            "from   ig_transaction ig\n" +
            "where  1=1\n" +
            "and    creation_date>=sysdate-2/24\n" +
            ") WHERE 1=1";


    public final String REPORT_SQL_MONITOR_GRAPH_VIEW = "SELECT template,\n" +
            "       trans_type,\n" +
            "       order_type_group AS order_Type,\n" +
            "       status,\n" +
            "       count(*) as count\n" +
            "FROM   (SELECT Decode(template, 'TMOSM', 'TMO_SIMPLE',\n" +
            "                                'TMOUN', 'TMOBILE',\n" +
            "                                'RSS', 'VZW',\n" +
            "                                'SUREPAY', 'VZW',\n" +
            "                                template)                           template,\n" +
            "               action_item_id,\n" +
            "               transaction_id,\n" +
            "               order_type,\n" +
            "               CASE\n" +
            "                 WHEN order_type IN( 'A', 'AP', 'E', 'PAP' ) THEN 'ACT/REACT'\n" +
            "                 WHEN order_type IN( 'CR', 'R', 'CRU', 'PCR' ) THEN 'CREDITS'\n" +
            "                 WHEN order_type IN( 'MINC', 'SIMC' ) THEN 'EQUIP_CHNG'\n" +
            "                 WHEN order_type IN( 'D', 'S' ) THEN 'DEACTS'\n" +
            "                 WHEN order_type IN( 'PFR', 'UI' ) THEN 'SUI'\n" +
            "                 WHEN order_type = 'UPO' THEN 'PORT_OUT'\n" +
            "                 WHEN order_type = 'SLB' THEN 'SL_BENEFIT'\n" +
            "                 ELSE 'OTHER'\n" +
            "               END\n" +
            "               order_type_group,\n" +
            "               Trunc(creation_date, 'hh24') + ( Trunc(To_char(creation_date, 'mi') / 15) * 15 )/ 24 / 60 x_time_segment,\n" +
            "               Round(( update_date - ig.creation_date ) * 86400, 0) db_secs_to_complete,\n" +
            "               Round(( carrier_end_trans_time - carrier_initial_trans_time ) * 86400, 0) carrier_secs_to_complete,\n" +
            "               Round(( SYSDATE - ig.update_date ) * 86400, 0)       secs_waiting,\n" +
            "               status,\n" +
            "               CASE\n" +
            "                 WHEN EXISTS (SELECT 1\n" +
            "                              FROM   table_task tt\n" +
            "                              WHERE  tt.task_id = ig.action_item_id) \n" +
            "                 THEN 'SYSTEM_AI'\n" +
            "                 ELSE 'BACKEND_AI' END                                                  trans_type\n" +
            "        FROM   ig_transaction ig\n" +
            "        WHERE  1 = 1\n" +
            "               AND creation_date >= SYSDATE - 2 / 24)\n" +
            " WHERE  1 = 1\n" +
            " group by template,trans_type,order_type_group,status";


    public final String REPORT_SQL_MONITOR_ADHOC = "select distinct\n" +
            //"       --sysdate time_ran,\n" +
            "       x_time_segment AS x_date,\n" +
            "       trans_type,\n" +
            "       template,\n" +
            "       order_type_group AS order_Type,\n" +
            "       to_char(sum(case when status = 'Q' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_q,\n" +
            "       to_char(sum(case when status = 'L' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_l,\n" +
            "       to_char(sum(case when status = 'CP' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_cp,\n" +
            "       to_char(sum(case when status = 'WP' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_wp,\n" +
            "       to_char(sum(case when status = 'W' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_w,\n" +
            "       to_char(sum(case when status in('S','SS') then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_s,\n" +
            "       to_char(sum(case when status = 'E' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_e,\n" +
            "       to_char(sum(case when status in('F','FF') then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_f,\n" +
            "       to_char(sum(case when status ='TF' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_tf,\n" +
            "       to_char(sum(case when status ='HW' then 1 else 0 end)over(partition by trans_type,x_time_segment,order_type_group,template),'999,999,999') sum_all_hw,\n" +
            "       TO_CHAR(count(action_item_Id)over(partition by trans_type,x_time_segment,order_type_group,template),'999G999G999') total_trans_count \n" +
            "  from (\n" +
            "select decode(template,'TMOSM','TMO_SIMPLE','TMOUN','TMOBILE','RSS','VZW','SUREPAY','VZW',template) template,\n" +
            "       action_item_id,\n" +
            "       transaction_id,\n" +
            "       order_type,\n" +
            "       case when order_type in('A','AP','E','PAP') then 'ACT/REACT'\n" +
            "            when order_type in('CR','R','CRU','PCR') then 'CREDITS'\n" +
            "            when order_type in('MINC','SIMC') then 'EQUIP_CHNG'\n" +
            "            when order_type in('D','S') then 'DEACTS'\n" +
            "            when order_type in('PFR','UI') then 'SUI'\n" +
            "            when order_type ='UPO' then 'PORT_OUT'\n" +
            "            when order_Type = 'SLB' then 'SL_BENEFIT' else 'OTHER' end order_type_group,\n" +
            "       trunc(creation_date,'hh24') + (trunc(to_char(creation_date,'mi')/15)*15)/24/60 x_time_segment,\n" +
            "       round((update_date-ig.creation_date)*86400,0) db_secs_to_complete,\n" +
            "       round((CARRIER_END_TRANS_TIME-CARRIER_INITIAL_TRANS_TIME)*86400,0) carrier_secs_to_complete,\n" +
            "       round((sysdate-ig.update_date)*86400,0) secs_waiting,\n" +
            "       status,\n" +
            "       case when exists (select 1 from table_task tt where tt.task_id = ig.action_item_id) then 'SYSTEM_AI' else 'BACKEND_AI' end trans_type\n" +
            "from   ig_transaction ig\n" +
            "where  1=1\n" +
            " and    creation_date>=  to_date(?,'yyyy/mm/dd HH24:MI:SS')" +
            " and    creation_date<= to_date(?,'yyyy/mm/dd HH24:MI:SS') " +
            " ) WHERE 1=1";

    // throttle reports
    String TRACFONE_REPORTNAME_ALL_TT_FAILURES = "allttfailures";

    String REPORT_SQL_ALLTTFAILURES = "with tt_tab as (\n" +
            "      SELECT  DISTINCT\n" +
            "      tig.PARENT_NAME parentShort,\n" +
            "      cg.x_Carrier_name parent,\n" +
            "      (TRUNC(tig.x_creation_Date,'hh24') +  (TRUNC(TO_CHAR(tig.x_creation_Date,'mi')/30)*30)/24/60)      X_TIME_SEGMENT,\n" +
            "      tig.x_transact_type orderTypeGroup,\n" +
            "      tig.x_creation_date,\n" +
            "      tig.objid ttobjid,\n" +
            "      tig.x_status status,\n" +
            "      NVL((SELECT SUM(1) FROM w3ci.X_THROTTLING_ERROR_LOG TEG WHERE TEG.THROTTLING_TRANSACTION_OBJID = tig.objid),0) FAILED_COUNT\n" +
            "      FROM W3CI.TABLE_X_THROTTLING_TRANSACTION tig\n" +
            "          left outer join W3CI.TABLE_X_THROTTLING_RULE ttr on ttr.objid = tig.x_rule_id\n" +
            "          left outer join table_X_parent p on p.objid  = ttr.x_parent_id\n" +
            "          left outer join table_x_carrier_group cg on p.objid  = cg.x_carrier_group2x_parent\n" +
            "          left outer join W3CI.TABLE_X_THROTTLING_POLICY ttp on ttp.objid = ttr.x_policy_id\n" +
            "          left outer join W3CI.TABLE_X_THROTTLING_FEATURES ttf on ttf.x_rule_id = tig.x_rule_id\n" +
            "      WHERE 1=1\n" +
            "      AND TIG.X_Creation_Date >= trunc(sysdate)-7\n" +
            "      AND TIG.X_Status = 'E')\n" +
            "      SELECT DISTINCT\n" +
            "       orderTypeGroup,\n" +
            "       parent, parentShort,\n" +
            "       TO_CHAR(X_TIME_SEGMENT, 'YYYY:MM:DD HH24:MI:SS') X_TIME_SEGMENT,\n" +
            "      COUNT(ttobjid)OVER(PARTITION BY orderTypeGroup,parent,X_TIME_SEGMENT) TOTAL_TRANS_COUNT,\n" +
            "      SUM(FAILED_COUNT)OVER(PARTITION BY orderTypeGroup,parent,X_TIME_SEGMENT) FAILURE_COUNT\n" +
            "      FROM TT_TAB";

    String TRACFONE_REPORTNAME_TT_MONITOR = "ttmonitor";

    String REPORT_SQL_TT_MONITOR = "select distinct\n" +
            "       x_carrier,\n" +
            "       x_transaction_num,\n" +
            "       x_time_segment AS x_date,\n" +
            "       x_transact_type,\n" +
            "       to_char(sum(case when x_status = 'Q' then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_q,\n" +
            "       to_char(sum(case when x_status = 'L' then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_l,\n" +
            "       to_char(sum(case when x_status = 'CP' then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_cp,\n" +
            "       to_char(sum(case when x_status in('W','S','SS') then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_s,\n" +
            "       to_char(sum(case when x_status = 'NT' then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_nt,\n" +
            "       to_char(sum(case when x_status = 'E' then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_e,\n" +
            "       to_char(sum(case when x_status = 'C' then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_c,\n" +
            "       to_char(sum(case when x_status ='TF' then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_tf,\n" +
            "       to_char(sum(case when x_status not in('Q','L','CP','W','S','SS','NT','E','C') then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_other,\n" +
            "       TO_CHAR(count(objid)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999G999G999') total_trans_count,\n" +
            "       TO_CHAR(count(objid)over(partition by x_carrier,x_time_segment),'999G999G999') total_trans_by_segment,\n" +
            "       to_char(sum(case when failed_cnt>0 then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') failure_count,\n" +
            "       to_char(sum(case when x_status in('W','S','SS') AND (time_to_complete>0 AND time_to_complete<=11) then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') comp_11_min,\n" +
            "       to_char(sum(case when x_status in('W','S','SS') AND (time_to_complete>11 AND time_to_complete<=15) then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') comp_15_min,\n" +
            "       to_char(sum(case when x_status in('W','S','SS') AND (time_to_complete>15 AND time_to_complete<=30) then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') comp_30_min,\n" +
            "       to_char(sum(case when x_status in('W','S','SS') AND (time_to_complete>30) then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') comp_GT30_min\n" +
            "       FROM (SELECT tt.objid,\n" +
            "       case when tt.x_rule_id = 0 then 'PAGE' else\n" +
            "       (SELECT DISTINCT\n" +
            "      case when cg.x_carrier_name like 'T%MOBILE%' then 'TMO'\n" +
            "       when cg.x_carrier_name like 'VERIZON%' then 'VZW'\n" +
            "        when cg.x_carrier_name like 'AT%T%' then 'ATT' else cg.x_carrier_name end\n" +
            "       FROM table_x_parent tp, table_x_carrier_group cg\n" +
            "       WHERE cg.X_CARRIER_GROUP2X_PARENT = tp.objid\n" +
            "       AND tp.objid = tr.X_PARENT_ID) end x_carrier,\n" +
            "       tt.x_transaction_num,\n" +
            "       tt.x_rule_id,\n" +
            "       tr.X_RULE_DESCRIPTION,\n" +
            "       tt.x_min,\n" +
            "       tt.x_esn,\n" +
            "       tt.x_creation_date,\n" +
            "       tt.x_last_update,\n" +
            "       round((tt.x_last_update-tt.x_creation_date)*1440,0) time_to_complete,\n" +
            "       round((sysdate-tt.x_last_update)*1440,0) time_waitiing,\n" +
            "       TRUNC(tt.x_creation_date,'hh24') + (TRUNC(TO_CHAR(tt.x_creation_date,'mi')/15)*15)/24/60 X_TIME_SEGMENT,\n" +
            "       tt.x_transact_type,\n" +
            "       tt.x_status,\n" +
            "       tt.x_api_message,\n" +
            "       nvl((SELECT sum(1) FROM w3ci.X_THROTTLING_ERROR_LOG te WHERE te.throttling_transaction_objid = tt.objid),0) failed_cnt\n" +
            "       FROM w3ci.table_x_throttling_transaction tt left outer join\n" +
            "       w3ci.table_x_throttling_rule tr on (tt.x_rule_id = tr.objid)\n" +
            "       WHERE 1=1\n" +
            "       AND tt.x_creation_date >=sysdate-2/24\n" +
            "       AND tt.x_transact_type in ('TTOFF','TTON'))\n" +
            "       WHERE 1=1\n" +
            "       order by x_carrier,X_TIME_SEGMENT,x_transact_type,x_transaction_num";

    String REPORT_SQL_TT_MONITOR_ADHOC = "select distinct\n" +
            "       x_carrier,\n" +
            "       x_transaction_num,\n" +
            "       x_time_segment AS x_date,\n" +
            "       x_transact_type,\n" +
            "       to_char(sum(case when x_status = 'Q' then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_q,\n" +
            "       to_char(sum(case when x_status = 'L' then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_l,\n" +
            "       to_char(sum(case when x_status = 'CP' then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_cp,\n" +
            "       to_char(sum(case when x_status in('W','S','SS') then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_s,\n" +
            "       to_char(sum(case when x_status = 'NT' then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_nt,\n" +
            "       to_char(sum(case when x_status = 'E' then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_e,\n" +
            "       to_char(sum(case when x_status = 'C' then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_c,\n" +
            "       to_char(sum(case when x_status ='TF' then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_all_tf,\n" +
            "       to_char(sum(case when x_status not in('Q','L','CP','W','S','SS','NT','E','C') then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') sum_other,\n" +
            "       TO_CHAR(count(objid)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999G999G999') total_trans_count,\n" +
            "       TO_CHAR(count(objid)over(partition by x_carrier,x_time_segment),'999G999G999') total_trans_by_segment,\n" +
            "       to_char(sum(case when failed_cnt>0 then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') failure_count,\n" +
            "       to_char(sum(case when x_status in('W','S','SS') AND (time_to_complete>0 AND time_to_complete<=11) then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') comp_11_min,\n" +
            "       to_char(sum(case when x_status in('W','S','SS') AND (time_to_complete>11 AND time_to_complete<=15) then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') comp_15_min,\n" +
            "       to_char(sum(case when x_status in('W','S','SS') AND (time_to_complete>15 AND time_to_complete<=30) then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') comp_30_min,\n" +
            "       to_char(sum(case when x_status in('W','S','SS') AND (time_to_complete>30) then 1 else 0 end)over(partition by x_carrier,x_time_segment,x_transact_type,x_transaction_num),'999,999,999') comp_GT30_min\n" +
            "       FROM (SELECT tt.objid,\n" +
            "       case when tt.x_rule_id = 0 then 'PAGE' else\n" +
            "       (SELECT DISTINCT\n" +
            "      case when cg.x_carrier_name like 'T%MOBILE%' then 'TMO'\n" +
            "       when cg.x_carrier_name like 'VERIZON%' then 'VZW'\n" +
            "        when cg.x_carrier_name like 'AT%T%' then 'ATT' else cg.x_carrier_name end\n" +
            "       FROM table_x_parent tp, table_x_carrier_group cg\n" +
            "       WHERE cg.X_CARRIER_GROUP2X_PARENT = tp.objid\n" +
            "       AND tp.objid = tr.X_PARENT_ID) end x_carrier,\n" +
            "       tt.x_transaction_num,\n" +
            "       tt.x_rule_id,\n" +
            "       tr.X_RULE_DESCRIPTION,\n" +
            "       tt.x_min,\n" +
            "       tt.x_esn,\n" +
            "       tt.x_creation_date,\n" +
            "       tt.x_last_update,\n" +
            "       round((tt.x_last_update-tt.x_creation_date)*1440,0) time_to_complete,\n" +
            "       round((sysdate-tt.x_last_update)*1440,0) time_waitiing,\n" +
            "       TRUNC(tt.x_creation_date,'hh24') + (TRUNC(TO_CHAR(tt.x_creation_date,'mi')/15)*15)/24/60 X_TIME_SEGMENT,\n" +
            "       tt.x_transact_type,\n" +
            "       tt.x_status,\n" +
            "       tt.x_api_message,\n" +
            "       nvl((SELECT sum(1) FROM w3ci.X_THROTTLING_ERROR_LOG te WHERE te.throttling_transaction_objid = tt.objid),0) failed_cnt\n" +
            "       FROM w3ci.table_x_throttling_transaction tt left outer join\n" +
            "       w3ci.table_x_throttling_rule tr on (tt.x_rule_id = tr.objid)\n" +
            "       WHERE 1=1\n" +
            "       and    tt.x_creation_date>=  to_date(?,'yyyy/mm/dd HH24:MI:SS')" +
            "       and    tt.x_creation_date<= to_date(?,'yyyy/mm/dd HH24:MI:SS') " +
            "       AND tt.x_transact_type in ('TTOFF','TTON'))\n" +
            "       WHERE 1=1\n" +
            "       order by x_carrier,X_TIME_SEGMENT,x_transact_type,x_transaction_num";

    String TRACFONE_REPORTNAME_TT_MONITOR_GRAPH = "ttMonitorGraph";

    String REPORT_SQL_TT_MONITOR_GRAPH_VIEW = " SELECT x_carrier,\n" +
            "                   x_transact_type,\n" +
            "                   x_status,\n" +
            "                   count(*) as count\n" +
            "            FROM   (SELECT tt.objid,\n" +
            "                   case when tt.x_rule_id = 0 then 'PAGE' else\n" +
            "                   (SELECT DISTINCT\n" +
            "                  case when cg.x_carrier_name like 'T%MOBILE%' then 'TMO'\n" +
            "                   when cg.x_carrier_name like 'VERIZON%' then 'VZW'\n" +
            "                    when cg.x_carrier_name like 'AT%T%' then 'ATT' else cg.x_carrier_name end\n" +
            "                   FROM table_x_parent tp, table_x_carrier_group cg\n" +
            "                   WHERE cg.X_CARRIER_GROUP2X_PARENT = tp.objid\n" +
            "                  AND tp.objid = tr.X_PARENT_ID) end x_carrier,\n" +
            "                           Trunc(tt.x_creation_Date, 'hh24') + ( Trunc(To_char(tt.x_creation_Date, 'mi') / 15) * 15 )/ 24 / 60 x_time_segment,\n" +
            "                           Round(( tt.x_last_update - tt.x_creation_Date ) * 86400, 0) db_secs_to_complete,\n" +
            "                           Round(( SYSDATE - tt.x_last_update ) * 86400, 0)       secs_waiting,\n" +
            "                           tt.x_status,\n" +
            "                           tt.x_transact_type\n" +
            "                    FROM   w3ci.table_x_throttling_transaction tt\n" +
            "                    left outer join w3ci.table_x_throttling_rule tr on (tt.x_rule_id = tr.objid)\n" +
            "                    WHERE  1 = 1\n" +
            "                           AND tt.x_creation_Date >= SYSDATE - 2/24)\n" +
            "             WHERE  1 = 1\n" +
            "             group by x_carrier,x_transact_type,x_status";

    //    PCRF
    String TRACFONE_REPORTNAME_PCRF_MONITOR = "pcrfmonitor";

    String REPORT_SQL_PCRF_MONITOR = "select \n" +
            "       insert_timestamp,\n" +
            "       pcrf_parent_name,\n" +
            "       order_type,\n" +
            "       to_char(sum(case when pcrf_status_code = 'Q' then row_count else 0 end),'999,999,999') sum_Q,\n" +
            "       to_char(sum(case when pcrf_status_code = 'L' then row_count else 0 end),'999,999,999') sum_L,\n" +
            "       to_char(sum(case when pcrf_status_code = 'W' then row_count else 0 end),'999,999,999') sum_W,\n" +
            "       to_char(sum(case when pcrf_status_code = 'S' then row_count else 0 end),'999,999,999') sum_S,\n" +
            "       to_char(sum(case when pcrf_status_code = 'C' then row_count else 0 end),'999,999,999') sum_C,\n" +
            "       to_char(sum(case when pcrf_status_code = 'F' then row_count else 0 end),'999,999,999')sum_F,\n" +
            "       to_char(sum(case when pcrf_status_code = 'E' then row_count else 0 end),'999,999,999') sum_E,\n" +
            "       to_char(sum(case when pcrf_status_code not in ('W','F','L','Q','E','C', 'S') then row_count else 0 end),'999,999,999') sum_others\n" +
            "       from (\n" +
            "SELECT TO_CHAR (insert_timestamp,\n" +
            "                'YYYY-MM-DD HH24:MI:SS')\n" +
            "           insert_timestamp,\n" +
            "       brand,\n" +
            "       pcrf_parent_name,\n" +
            "       order_type,\n" +
            "       pcrf_status_code,\n" +
            "       COUNT (*) row_count\n" +
            "FROM sa.x_pcrf_transaction pt\n" +
            "WHERE     1 = 1\n" +
            "      AND pt.insert_timestamp >= ROUND (SYSDATE - 2 / 24, 'HH')\n" +
            "GROUP BY insert_timestamp,\n" +
            "         brand,\n" +
            "         pcrf_parent_name,\n" +
            "         service_plan_id,\n" +
            "         service_plan_type,\n" +
            "         order_type,\n" +
            "         pcrf_status_code\n" +
            "         )group by \n" +
            "         insert_timestamp,\n" +
            "       pcrf_parent_name,\n" +
            "       order_type";

    String REPORT_SQL_PCRF_MONITOR_ADHOC = "select \n" +
            "       insert_timestamp,\n" +
            "       pcrf_parent_name,\n" +
            "       order_type,\n" +
            "       to_char(sum(case when pcrf_status_code = 'Q' then row_count else 0 end),'999,999,999') sum_Q,\n" +
            "       to_char(sum(case when pcrf_status_code = 'L' then row_count else 0 end),'999,999,999') sum_L,\n" +
            "       to_char(sum(case when pcrf_status_code = 'W' then row_count else 0 end),'999,999,999') sum_W,\n" +
            "       to_char(sum(case when pcrf_status_code = 'S' then row_count else 0 end),'999,999,999') sum_S,\n" +
            "       to_char(sum(case when pcrf_status_code = 'C' then row_count else 0 end),'999,999,999') sum_C,\n" +
            "       to_char(sum(case when pcrf_status_code = 'F' then row_count else 0 end),'999,999,999')sum_F,\n" +
            "       to_char(sum(case when pcrf_status_code = 'E' then row_count else 0 end),'999,999,999') sum_E,\n" +
            "       to_char(sum(case when pcrf_status_code not in ('W','F','L','Q','E','C', 'S') then row_count else 0 end),'999,999,999') sum_others\n" +
            "       from (\n" +
            "SELECT TO_CHAR (insert_timestamp,\n" +
            "                'YYYY-MM-DD HH24:MI:SS')\n" +
            "           insert_timestamp,\n" +
            "       brand,\n" +
            "       pcrf_parent_name,\n" +
            "       order_type,\n" +
            "       pcrf_status_code,\n" +
            "       COUNT (*) row_count\n" +
            "FROM sa.x_pcrf_transaction pt\n" +
            "WHERE     1 = 1\n" +
            "      AND pt.insert_timestamp >= to_date(?,'yyyy/mm/dd HH24:MI:SS')\n" +
            "      AND pt.insert_timestamp <= to_date(?,'yyyy/mm/dd HH24:MI:SS')\n" +
            "GROUP BY insert_timestamp,\n" +
            "         brand,\n" +
            "         pcrf_parent_name,\n" +
            "         service_plan_id,\n" +
            "         service_plan_type,\n" +
            "         order_type,\n" +
            "         pcrf_status_code\n" +
            "         )group by \n" +
            "         insert_timestamp,\n" +
            "       pcrf_parent_name,\n" +
            "       order_type";

    String TRACFONE_REPORTNAME_ALL_PCRF_FAILURES = "allpcrffailures";

    String REPORT_SQL_ALLPCRFFAILURES = "with pcrf_tab as (\n" +
            "                                    SELECT PCRF_PARENT_NAME, PT.PCRF_STATUS_CODE status, PT.OBJID objid,\n" +
            "                                           ORDER_TYPE, SOURCESYSTEM, \n" +
            "                                           NVL((SELECT SUM(1) FROM sa.X_PCRF_FAILED_TRANS_LOG PFT  WHERE PFT.pcrf_transaction_id = PT.OBJID),0) FAILED_COUNT,\n" +
            "                                           TRUNC(INSERT_TIMESTAMP,'hh24') + (TRUNC(TO_CHAR(INSERT_TIMESTAMP,'mi')/30)*30)/24/60 X_TIME_SEGMENT,\n" +
            "                                           INSERT_TIMESTAMP,\n" +
            "                                           UPDATE_TIMESTAMP\n" +
            "                                    FROM   sa.x_pcrf_transaction PT\n" +
            "                                    WHERE  1=1 \n" +
            "                                    AND PT.INSERT_TIMESTAMP >= trunc(sysdate)-7\n" +
            "                                    AND PT.PCRF_STATUS_CODE IN('F','E')\n" +
            "                                   )\n" +
            "                    SELECT DISTINCT\n" +
            "                           PCRF_PARENT_NAME, ORDER_TYPE, SOURCESYSTEM,\n" +
            "                           TO_CHAR(X_TIME_SEGMENT, 'YYYY:MM:DD HH24:MI:SS') X_TIME_SEGMENT, \n" +
            "                           COUNT(objid)OVER(PARTITION BY PCRF_PARENT_NAME,X_TIME_SEGMENT,ORDER_TYPE, SOURCESYSTEM) TOTAL_TRANS_COUNT,\n" +
            "                           ROUND(SUM(CASE WHEN STATUS IN('F','E') THEN 1 ELSE 0 END)OVER(PARTITION BY PCRF_PARENT_NAME,X_TIME_SEGMENT,ORDER_TYPE, SOURCESYSTEM) /\n" +
            "                           COUNT(objid)OVER(PARTITION BY PCRF_PARENT_NAME,X_TIME_SEGMENT,ORDER_TYPE, SOURCESYSTEM),2) PERCENT_FAILURE,\n" +
            "                           SUM(FAILED_COUNT)OVER(PARTITION BY PCRF_PARENT_NAME,X_TIME_SEGMENT,ORDER_TYPE, SOURCESYSTEM) FAILURE_COUNT,\n" +
            "                           SUM(CASE WHEN STATUS IN('F','E') THEN 1 ELSE 0 END)OVER(PARTITION BY PCRF_PARENT_NAME,X_TIME_SEGMENT,ORDER_TYPE, SOURCESYSTEM) SUM_F   \n" +
            "                    FROM   PCRF_TAB\n" +
            "                    ORDER BY 1,2,3,4";

    String TRACFONE_REPORTNAME_PCRF_MONITOR_GRAPH = "pcrfMonitorGraph";

    String REPORT_SQL_PCRF_MONITOR_GRAPH_VIEW = "SELECT PCRF_PARENT_NAME,\n" +
            "       ORDER_TYPE,\n" +
            "       PCRF_STATUS_CODE,\n" +
            "       count(*) as count\n" +
            "FROM   (SELECT pt.objid,\n" +
            "               Trunc(pt.INSERT_TIMESTAMP, 'hh24') + ( Trunc(To_char(pt.INSERT_TIMESTAMP, 'mi') / 15) * 15 )/ 24 / 60 x_time_segment,\n" +
            "               Round(( pt.UPDATE_TIMESTAMP - pt.INSERT_TIMESTAMP ) * 86400, 0) db_secs_to_complete,\n" +
            "               Round(( SYSDATE - pt.UPDATE_TIMESTAMP ) * 86400, 0)       secs_waiting,\n" +
            "               pt.PCRF_STATUS_CODE,\n" +
            "               pt.ORDER_TYPE,\n" +
            "               pt.PCRF_PARENT_NAME\n" +
            "        FROM   X_PCRF_TRANSACTION pt\n" +
            "        WHERE  1 = 1\n" +
            "               AND pt.INSERT_TIMESTAMP >= SYSDATE - 2/24)\n" +
            " WHERE  1 = 1\n" +
            " group by PCRF_PARENT_NAME,ORDER_TYPE,PCRF_STATUS_CODE";

}
