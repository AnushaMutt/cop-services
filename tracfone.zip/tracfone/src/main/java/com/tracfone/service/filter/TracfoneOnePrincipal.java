/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.filter;

import com.tracfone.service.model.response.TFOneAdminUser;
import java.security.Principal;

/**
 *
 * @author druiz
 */
public class TracfoneOnePrincipal implements Principal{
    private TFOneAdminUser tfUser;
    
    TracfoneOnePrincipal(TFOneAdminUser tfUser){
        this.tfUser = tfUser;
    }

    @Override
    public String getName() {
        return String.valueOf(this.tfUser.getUserId());
    }
    
    public TFOneAdminUser getTFUser(){
        return tfUser;
    }
    
    public void setTFUser(TFOneAdminUser tfUser){
        this.tfUser = tfUser;
    }
    
}
