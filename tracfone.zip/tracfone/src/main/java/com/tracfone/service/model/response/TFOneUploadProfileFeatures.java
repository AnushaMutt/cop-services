/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.response;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Shireen Fathima
 */
public class TFOneUploadProfileFeatures {
    
    private List<TFOneRatePlanExtensionConfig> successRpExtensionConfigs;
    private List<TFOneRatePlanExtensionConfig> errorRpExtensionConfigs;

    public TFOneUploadProfileFeatures() {
        successRpExtensionConfigs = new ArrayList<>();
        errorRpExtensionConfigs = new ArrayList<>();
    }

    public List<TFOneRatePlanExtensionConfig> getSuccessRpExtensionConfigs() {
        return successRpExtensionConfigs;
    }

    public void setSuccessRpExtensionConfigs(List<TFOneRatePlanExtensionConfig> successRpExtensionConfigs) {
        this.successRpExtensionConfigs = successRpExtensionConfigs;
    }

    public List<TFOneRatePlanExtensionConfig> getErrorRpExtensionConfigs() {
        return errorRpExtensionConfigs;
    }

    public void setErrorRpExtensionConfigs(List<TFOneRatePlanExtensionConfig> errorRpExtensionConfigs) {
        this.errorRpExtensionConfigs = errorRpExtensionConfigs;
    }

    @Override
    public String toString() {
        return "TFOneUploadProfileFeatures{" + "successRpExtensionConfigs=" + successRpExtensionConfigs + ", "
                + "errorRpExtensionConfigs=" + errorRpExtensionConfigs + '}';
    }
    
    
}
