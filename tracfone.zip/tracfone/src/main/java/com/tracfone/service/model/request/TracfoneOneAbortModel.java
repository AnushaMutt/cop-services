/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Shireen Fathima
 */
public class TracfoneOneAbortModel {
    
    private String dbEnv;    
    private String step;
    private String carrierName;
    private String servicePlanId;
    private List<String> addedRatePlanIds;
    private List<String> addedCarrierFeatureIds;
    private List<String> addedProfileIds;
    private List<String> addedRpExtensionLinkIds;
    private List<String> addedProfileFeatureIds;
    private List<String> addedRpExtensionConfigIds;
    private List<String> addedBucketIds;
    private List<String> addedCarrierProfileBucketIds;
    private List<String> addedCarrierProfileChildBucketIds;

    public TracfoneOneAbortModel() {
        this.addedRatePlanIds = new ArrayList<>();
        this.addedCarrierFeatureIds = new ArrayList<>();
        this.addedProfileIds = new ArrayList<>();
        this.addedRpExtensionLinkIds = new ArrayList<>();
        this.addedProfileFeatureIds = new ArrayList<>();
        this.addedRpExtensionConfigIds = new ArrayList<>();
        this.addedBucketIds = new ArrayList<>();
        this.addedCarrierProfileBucketIds = new ArrayList<>();
        this.addedCarrierProfileChildBucketIds = new ArrayList<>();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }
    
    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public List<String> getAddedRatePlanIds() {
        return addedRatePlanIds;
    }

    public void setAddedRatePlanIds(List<String> addedRatePlanIds) {
        this.addedRatePlanIds = addedRatePlanIds;
    }

    public List<String> getAddedCarrierFeatureIds() {
        return addedCarrierFeatureIds;
    }

    public void setAddedCarrierFeatureIds(List<String> addedCarrierFeatureIds) {
        this.addedCarrierFeatureIds = addedCarrierFeatureIds;
    }

    public List<String> getAddedProfileIds() {
        return addedProfileIds;
    }

    public void setAddedProfileIds(List<String> addedProfileIds) {
        this.addedProfileIds = addedProfileIds;
    }

    public List<String> getAddedRpExtensionLinkIds() {
        return addedRpExtensionLinkIds;
    }

    public void setAddedRpExtensionLinkIds(List<String> addedRpExtensionLinkIds) {
        this.addedRpExtensionLinkIds = addedRpExtensionLinkIds;
    }

    public List<String> getAddedProfileFeatureIds() {
        return addedProfileFeatureIds;
    }

    public void setAddedProfileFeatureIds(List<String> addedProfileFeatureIds) {
        this.addedProfileFeatureIds = addedProfileFeatureIds;
    }

    public List<String> getAddedRpExtensionConfigIds() {
        return addedRpExtensionConfigIds;
    }

    public void setAddedRpExtensionConfigIds(List<String> addedRpExtensionConfigIds) {
        this.addedRpExtensionConfigIds = addedRpExtensionConfigIds;
    }

    public List<String> getAddedBucketIds() {
        return addedBucketIds;
    }

    public void setAddedBucketIds(List<String> addedBucketIds) {
        this.addedBucketIds = addedBucketIds;
    }

    public List<String> getAddedCarrierProfileBucketIds() {
        return addedCarrierProfileBucketIds;
    }

    public void setAddedCarrierProfileBucketIds(List<String> addedCarrierProfileBucketIds) {
        this.addedCarrierProfileBucketIds = addedCarrierProfileBucketIds;
    }

    public List<String> getAddedCarrierProfileChildBucketIds() {
        return addedCarrierProfileChildBucketIds;
    }

    public void setAddedCarrierProfileChildBucketIds(List<String> addedCarrierProfileChildBucketIds) {
        this.addedCarrierProfileChildBucketIds = addedCarrierProfileChildBucketIds;
    }

    @Override
    public String toString() {
        return "TracfoneOneAbortModel{" + "dbEnv=" + dbEnv + ", "
                + "step=" + step + ", "
                + "carrierName=" + carrierName + ", "
                + "servicePlanId=" + servicePlanId + ", "
                + "addedRatePlanIds=" + addedRatePlanIds + ", "
                + "addedCarrierFeatureIds=" + addedCarrierFeatureIds + ", "
                + "addedProfileIds=" + addedProfileIds + ", "
                + "addedRpExtensionLinkIds=" + addedRpExtensionLinkIds + ", "
                + "addedProfileFeatureIds=" + addedProfileFeatureIds + ", "
                + "addedRpExtensionConfigIds=" + addedRpExtensionConfigIds + ", "
                + "addedBucketIds=" + addedBucketIds + ", "
                + "addedCarrierProfileBucketIds=" + addedCarrierProfileBucketIds + ", "
                + "addedCarrierProfileChildBucketIds=" + addedCarrierProfileChildBucketIds + '}';
    }
}
