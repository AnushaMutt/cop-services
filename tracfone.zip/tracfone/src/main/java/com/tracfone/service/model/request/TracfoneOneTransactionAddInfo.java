/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.request;

/**
 *
 * @author user
 */
public class TracfoneOneTransactionAddInfo {
    
    private String     firstName;
    private String     middleInitial;           
    private String     lastName;          
    private String     suffix;
    private String     prefix;
    private String     ssnLast4;
    private String     address1;             
    private String     address2;
    private String     city;                  
    private String     state;
    private String     zipCode;            
    private String     country;
    private String     ospAccount;
    private String     currAddrHouseNumber;
    private String     currAddrDirection;
    private String     currAddrStreetName;
    private String     currAddrStreetType;
    private String     currAddrUnit;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleInitial() {
        return middleInitial;
    }

    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getSsnLast4() {
        return ssnLast4;
    }

    public void setSsnLast4(String ssnLast4) {
        this.ssnLast4 = ssnLast4;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getOspAccount() {
        return ospAccount;
    }

    public void setOspAccount(String ospAccount) {
        this.ospAccount = ospAccount;
    }

    public String getCurrAddrHouseNumber() {
        return currAddrHouseNumber;
    }

    public void setCurrAddrHouseNumber(String currAddrHouseNumber) {
        this.currAddrHouseNumber = currAddrHouseNumber;
    }

    public String getCurrAddrDirection() {
        return currAddrDirection;
    }

    public void setCurrAddrDirection(String currAddrDirection) {
        this.currAddrDirection = currAddrDirection;
    }

    public String getCurrAddrStreetName() {
        return currAddrStreetName;
    }

    public void setCurrAddrStreetName(String currAddrStreetName) {
        this.currAddrStreetName = currAddrStreetName;
    }

    public String getCurrAddrStreetType() {
        return currAddrStreetType;
    }

    public void setCurrAddrStreetType(String currAddrStreetType) {
        this.currAddrStreetType = currAddrStreetType;
    }

    public String getCurrAddrUnit() {
        return currAddrUnit;
    }

    public void setCurrAddrUnit(String currAddrUnit) {
        this.currAddrUnit = currAddrUnit;
    }
    
    
    
    
}
