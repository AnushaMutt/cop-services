/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * TABLE SA.X_RP_EXTENSION_LINK
 * @author Shireen Fathima
 */
public class TracfoneOneRatePlanExtensionLink {
    
    private String dbEnv;
    private String objId;
    @Size(max=100, message = "Child Plan Id cannot have more than 100 characters")
    private String childPlanId;
    @Digits(integer=38, fraction=0, message = "Carrier Feature Id must be a number")
    private String carrierFeatureId;
    @NotNull(message = "Profile Id cannot be null")
    @NotBlank (message = "Profile Id cannot be blank")
    @Digits(integer=38, fraction=0, message = "Profile Id must be a number")
    private String profileId;
    @NotNull(message = "Rate Plan Extension Id cannot be null")
    @NotBlank (message = "Rate Plan Extension Id cannot be blank")
    @Digits(integer=38, fraction=0, message = "Rate Plan Extension Id must be a number")
    private String ratePlanExtensionId;
    private boolean edited;
    @Valid
    private List<TracfoneOneCarrierProfileBucket> tracfoneOneCarrierProfileBuckets;
    @Valid
    private List<TracfoneOneCarrierProfileChildBucket> tracfoneOneCarrierProfileChildBuckets;

    public TracfoneOneRatePlanExtensionLink() {
        tracfoneOneCarrierProfileBuckets = new ArrayList<>();
        tracfoneOneCarrierProfileChildBuckets = new ArrayList<>();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getChildPlanId() {
        return childPlanId;
    }

    public void setChildPlanId(String childPlanId) {
        this.childPlanId = childPlanId;
    }

    public String getCarrierFeatureId() {
        return carrierFeatureId;
    }

    public void setCarrierFeatureId(String carrierFeatureId) {
        this.carrierFeatureId = carrierFeatureId;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getRatePlanExtensionId() {
        return ratePlanExtensionId;
    }

    public void setRatePlanExtensionId(String ratePlanExtensionId) {
        this.ratePlanExtensionId = ratePlanExtensionId;
    } 

    public List<TracfoneOneCarrierProfileBucket> getTracfoneOneCarrierProfileBuckets() {
        return tracfoneOneCarrierProfileBuckets;
    }

    public void setTracfoneOneCarrierProfileBuckets(List<TracfoneOneCarrierProfileBucket> tracfoneOneCarrierProfileBuckets) {
        this.tracfoneOneCarrierProfileBuckets = tracfoneOneCarrierProfileBuckets;
    }

    public List<TracfoneOneCarrierProfileChildBucket> getTracfoneOneCarrierProfileChildBuckets() {
        return tracfoneOneCarrierProfileChildBuckets;
    }

    public void setTracfoneOneCarrierProfileChildBuckets(List<TracfoneOneCarrierProfileChildBucket> tracfoneOneCarrierProfileChildBuckets) {
        this.tracfoneOneCarrierProfileChildBuckets = tracfoneOneCarrierProfileChildBuckets;
    }

    public boolean isEdited() { return edited; }

    public void setEdited(boolean edited) { this.edited = edited; }

    @Override
    public String toString() {
        return "TracfoneOneRatePlanExtensionLink{" +
                "dbEnv='" + dbEnv + '\'' +
                ", objId='" + objId + '\'' +
                ", childPlanId='" + childPlanId + '\'' +
                ", carrierFeatureId='" + carrierFeatureId + '\'' +
                ", profileId='" + profileId + '\'' +
                ", ratePlanExtensionId='" + ratePlanExtensionId + '\'' +
                ", edited='" + edited + '\'' +
                ", tracfoneOneCarrierProfileBuckets=" + tracfoneOneCarrierProfileBuckets +
                ", tracfoneOneCarrierProfileChildBuckets=" + tracfoneOneCarrierProfileChildBuckets +
                '}';
    }
}
