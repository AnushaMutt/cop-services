package com.tracfone.service.model.response;

public class TFOneAncillaryCodeDiscount {
    private String ancillaryCode;
    private String brmEquivalent;

    public String getAncillaryCode() {
        return ancillaryCode;
    }

    public void setAncillaryCode(String ancillaryCode) {
        this.ancillaryCode = ancillaryCode;
    }

    public String getBrmEquivalent() {
        return brmEquivalent;
    }

    public void setBrmEquivalent(String brmEquivalent) {
        this.brmEquivalent = brmEquivalent;
    }

    @Override
    public String toString() {
        return "TFOneAncillaryCodeDiscount{" +
                "ancillaryCode='" + ancillaryCode + '\'' +
                ", brmEquivalent='" + brmEquivalent + '\'' +
                '}';
    }
}
