package com.tracfone.service.model.response;

import com.tracfone.service.model.request.TracfoneonePaginationSearch;

import java.util.ArrayList;
import java.util.List;

public class TFOneThrottleTransSearchResult {
    private TracfoneonePaginationSearch paginationSearch;
    private List<TFOneThrottleTransaction> throttleTransactions;

    public TFOneThrottleTransSearchResult() {
        throttleTransactions = new ArrayList<>();
    }

    public TracfoneonePaginationSearch getPaginationSearch() {
        return paginationSearch;
    }

    public void setPaginationSearch(TracfoneonePaginationSearch paginationSearch) {
        this.paginationSearch = paginationSearch;
    }

    public List<TFOneThrottleTransaction> getThrottleTransactions() {
        return throttleTransactions;
    }

    public void setThrottleTransactions(List<TFOneThrottleTransaction> throttleTransactions) {
        this.throttleTransactions = throttleTransactions;
    }

    @Override
    public String toString() {
        return "TFOneThrottleTransSearchResult{" +
                "paginationSearch=" + paginationSearch +
                ", throttleTransactions=" + throttleTransactions +
                '}';
    }
}
