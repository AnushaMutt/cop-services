
package com.tracfone.service.model.request;

import javax.validation.constraints.Size;
import java.util.List;

/**
 *
 * @author Gaurav.Sharma
 */
public class TracfoneOneIGCarrierConfigDetails {

    private String configId;
    @Size(max = 100, message = "Prop Key cannot have more than 100 characters")
    private String propKey;
    @Size(max = 10, message = "Prop Value Type cannot have more than 10 characters")
    private String propValueType;
    @Size(max = 100, message = "Prop Value Key cannot have more than 100 characters")
    private String propValueKey;
    @Size(max = 100, message = "Prop Value Key Key cannot have more than 100 characters")
    private String propValueKeyKey;
    @Size(max = 2000, message = "Prop Value cannot have more than 2000 characters")
    private String propValue;
    @Size(max = 10, message = "Prop Value Key Type cannot have more than 10 characters")
    private String propValueKeyType;
    @Size(max = 256, message = "Remarks cannot have more than 256 characters")
    private String remarks;
    private String oldPropValue;
    private String oldPropKey;
    private String oldPropValueType;
    private String oldPropValueKey;
    private String oldPropValueKeyKey;
    private String oldPropValueKeyType;
    private String oldRemark;
    private String dbEnv;
    private List<String> propValues;

    public String getConfigId() {
        return configId;
    }

    public void setConfigId(String configId) {
        this.configId = configId;
    }

    public String getPropKey() {
        return propKey;
    }

    public void setPropKey(String propKey) {
        this.propKey = propKey;
    }

    public String getPropValueType() {
        return propValueType;
    }

    public void setPropValueType(String propValueType) {
        this.propValueType = propValueType;
    }

    public String getPropValueKey() {
        return propValueKey;
    }

    public void setPropValueKey(String propValueKey) {
        this.propValueKey = propValueKey;
    }

    public String getPropValueKeyKey() {
        return propValueKeyKey;
    }

    public void setPropValueKeyKey(String propValueKeyKey) {
        this.propValueKeyKey = propValueKeyKey;
    }

    public String getPropValue() {
        return propValue;
    }

    public void setPropValue(String propValue) {
        this.propValue = propValue;
    }

    public String getPropValueKeyType() {
        return propValueKeyType;
    }

    public void setPropValueKeyType(String propValueKeyType) {
        this.propValueKeyType = propValueKeyType;
    }

    public String getOldPropValue() {
        return oldPropValue;
    }

    public void setOldPropValue(String oldPropValue) {
        this.oldPropValue = oldPropValue;
    }

    public String getOldPropKey() {
        return oldPropKey;
    }

    public void setOldPropKey(String oldPropKey) {
        this.oldPropKey = oldPropKey;
    }

    public String getOldPropValueType() {
        return oldPropValueType;
    }

    public void setOldPropValueType(String oldPropValueType) {
        this.oldPropValueType = oldPropValueType;
    }

    public String getOldPropValueKey() {
        return oldPropValueKey;
    }

    public void setOldPropValueKey(String oldPropValueKey) {
        this.oldPropValueKey = oldPropValueKey;
    }

    public String getOldPropValueKeyKey() {
        return oldPropValueKeyKey;
    }

    public void setOldPropValueKeyKey(String oldPropValueKeyKey) {
        this.oldPropValueKeyKey = oldPropValueKeyKey;
    }

    public String getOldPropValueKeyType() {
        return oldPropValueKeyType;
    }

    public void setOldPropValueKeyType(String oldPropValueKeyType) {
        this.oldPropValueKeyType = oldPropValueKeyType;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getOldRemark() {
        return oldRemark;
    }

    public void setOldRemark(String oldRemark) {
        this.oldRemark = oldRemark;
    }

    public List<String> getPropValues() {
        return propValues;
    }

    public void setPropValues(List<String> propValues) {
        this.propValues = propValues;
    }

    @Override
    public String toString() {
        return "TracfoneOneIGCarrierDetails{" + "configId=" + configId + ", propKey=" + propKey + ", propValueType=" + propValueType + ", propValueKey=" + propValueKey + ", propValueKeyKey=" + propValueKeyKey + ", propValue=" + propValue + ", propValueKeyType=" + propValueKeyType + ", oldPropValue=" + oldPropValue + ", oldPropKey=" + oldPropKey + ", oldPropValueType=" + oldPropValueType + ", oldPropValueKey=" + oldPropValueKey + ", oldPropValueKeyKey=" + oldPropValueKeyKey + ", oldPropValueKeyType=" + oldPropValueKeyType + ", remarks=" + remarks + ", oldRemark=" + oldRemark + ", dbEnv=" + dbEnv + '}';
    }

}
