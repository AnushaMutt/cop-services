package com.tracfone.service.model.response;

import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Gaurav.Sharma
 */
public class TFOneCPrefResponse {

    private List<TracfoneOneCarrierZones> successRecords;
    private List<TracfoneOneCarrierZones> failedRecords;

    public TFOneCPrefResponse() {
        this.successRecords = new ArrayList<>();
        this.failedRecords = new ArrayList<>();
    }
    
    public List<TracfoneOneCarrierZones> getSuccessRecords() {
        return successRecords;
    }

    public void setSuccessRecords(List<TracfoneOneCarrierZones> successRecords) {
        this.successRecords = successRecords;
    }

    public List<TracfoneOneCarrierZones> getFailedRecords() {
        return failedRecords;
    }

    public void setFailedRecords(List<TracfoneOneCarrierZones> failedRecords) {
        this.failedRecords = failedRecords;
    }

    @Override
    public String toString() {
        return "TFOneCPrefResponse{" + "successRecords=" + successRecords + ", failedRecords=" + failedRecords + '}';
    }
}
