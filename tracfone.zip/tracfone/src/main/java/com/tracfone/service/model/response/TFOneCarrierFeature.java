/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Nidhi Mantri
 */
public class TFOneCarrierFeature {

    private String objId;
    private String dev;
    private String xTechnology;
    private String xRatePlan;
    private String xVoicemail;
    private String xVmCode;
    private String xVmPackage;
    private String xCallerId;
    private String xIdCode;
    private String xIdPackage;
    private String xSms;
    private String xSmsCode;
    private String xSmsPackage;
    private String xCallWaiting;
    private String xCwCode;
    private String xCwPackage;
    private String xDigitalFeature;
    private String xDigFeature;
    private String xFeature2xCarrier;
    private String xSmscNumber;
    private String xData;
    private String xRestrictedUse;
    private String xSwitchBaseRate;
    private String xFeatures2BusOrg;
    private String xIsSwbCarrier;
    private String xMpn;
    private String xMpnCode;
    private String xPoolName;
    private String createMformIgFlag;
    private String useCfExtensionFlag;
    private String dataSaver;
    private String dataSaverCode;
    private String useRpExtensionFlag;
    private String tmoNextGenFlag;
    private String servicePlanId;
    private String brand;
    private TFOneServicePlanCarrierFeature servicePlanCarrierFeature;
    private List<TFOneRatePlanExtensionLink> rpExtensionLinks;
    private String xCarrierId;

    public TFOneCarrierFeature() {
        rpExtensionLinks = new ArrayList<>();
    }

    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getDev() {
        return dev;
    }

    public void setDev(String dev) {
        this.dev = dev;
    }

    public String getxTechnology() {
        return xTechnology;
    }

    public void setxTechnology(String xTechnology) {
        this.xTechnology = xTechnology;
    }

    public String getxRatePlan() {
        return xRatePlan;
    }

    public void setxRatePlan(String xRatePlan) {
        this.xRatePlan = xRatePlan;
    }

    public String getxVoicemail() {
        return xVoicemail;
    }

    public void setxVoicemail(String xVoicemail) {
        this.xVoicemail = xVoicemail;
    }

    public String getxVmCode() {
        return xVmCode;
    }

    public void setxVmCode(String xVmCode) {
        this.xVmCode = xVmCode;
    }

    public String getxVmPackage() {
        return xVmPackage;
    }

    public void setxVmPackage(String xVmPackage) {
        this.xVmPackage = xVmPackage;
    }

    public String getxCallerId() {
        return xCallerId;
    }

    public void setxCallerId(String xCallerId) {
        this.xCallerId = xCallerId;
    }

    public String getxIdCode() {
        return xIdCode;
    }

    public void setxIdCode(String xIdCode) {
        this.xIdCode = xIdCode;
    }

    public String getxIdPackage() {
        return xIdPackage;
    }

    public void setxIdPackage(String xIdPackage) {
        this.xIdPackage = xIdPackage;
    }

    public String getxSms() {
        return xSms;
    }

    public void setxSms(String xSms) {
        this.xSms = xSms;
    }

    public String getxSmsCode() {
        return xSmsCode;
    }

    public void setxSmsCode(String xSmsCode) {
        this.xSmsCode = xSmsCode;
    }

    public String getxSmsPackage() {
        return xSmsPackage;
    }

    public void setxSmsPackage(String xSmsPackage) {
        this.xSmsPackage = xSmsPackage;
    }

    public String getxCallWaiting() {
        return xCallWaiting;
    }

    public void setxCallWaiting(String xCallWaiting) {
        this.xCallWaiting = xCallWaiting;
    }

    public String getxCwCode() {
        return xCwCode;
    }

    public void setxCwCode(String xCwCode) {
        this.xCwCode = xCwCode;
    }

    public String getxCwPackage() {
        return xCwPackage;
    }

    public void setxCwPackage(String xCwPackage) {
        this.xCwPackage = xCwPackage;
    }

    public String getxDigitalFeature() {
        return xDigitalFeature;
    }

    public void setxDigitalFeature(String xDigitalFeature) {
        this.xDigitalFeature = xDigitalFeature;
    }

    public String getxDigFeature() {
        return xDigFeature;
    }

    public void setxDigFeature(String xDigFeature) {
        this.xDigFeature = xDigFeature;
    }

    public String getxFeature2xCarrier() {
        return xFeature2xCarrier;
    }

    public void setxFeature2xCarrier(String xFeature2xCarrier) {
        this.xFeature2xCarrier = xFeature2xCarrier;
    }

    public String getxSmscNumber() {
        return xSmscNumber;
    }

    public void setxSmscNumber(String xSmscNumber) {
        this.xSmscNumber = xSmscNumber;
    }

    public String getxData() {
        return xData;
    }

    public void setxData(String xData) {
        this.xData = xData;
    }

    public String getxRestrictedUse() {
        return xRestrictedUse;
    }

    public void setxRestrictedUse(String xRestrictedUse) {
        this.xRestrictedUse = xRestrictedUse;
    }

    public String getxSwitchBaseRate() {
        return xSwitchBaseRate;
    }

    public void setxSwitchBaseRate(String xSwitchBaseRate) {
        this.xSwitchBaseRate = xSwitchBaseRate;
    }

    public String getxFeatures2BusOrg() {
        return xFeatures2BusOrg;
    }

    public void setxFeatures2BusOrg(String xFeatures2BusOrg) {
        this.xFeatures2BusOrg = xFeatures2BusOrg;
    }

    public String getxIsSwbCarrier() {
        return xIsSwbCarrier;
    }

    public void setxIsSwbCarrier(String xIsSwbCarrier) {
        this.xIsSwbCarrier = xIsSwbCarrier;
    }

    public String getxMpn() {
        return xMpn;
    }

    public void setxMpn(String xMpn) {
        this.xMpn = xMpn;
    }

    public String getxMpnCode() {
        return xMpnCode;
    }

    public void setxMpnCode(String xMpnCode) {
        this.xMpnCode = xMpnCode;
    }

    public String getxPoolName() {
        return xPoolName;
    }

    public void setxPoolName(String xPoolName) {
        this.xPoolName = xPoolName;
    }

    public String getCreateMformIgFlag() {
        return createMformIgFlag;
    }

    public void setCreateMformIgFlag(String createMformIgFlag) {
        this.createMformIgFlag = createMformIgFlag;
    }

    public String getUseCfExtensionFlag() {
        return useCfExtensionFlag;
    }

    public void setUseCfExtensionFlag(String useCfExtensionFlag) {
        this.useCfExtensionFlag = useCfExtensionFlag;
    }

    public String getDataSaver() {
        return dataSaver;
    }

    public void setDataSaver(String dataSaver) {
        this.dataSaver = dataSaver;
    }

    public String getDataSaverCode() {
        return dataSaverCode;
    }

    public void setDataSaverCode(String dataSaverCode) {
        this.dataSaverCode = dataSaverCode;
    }

    public String getUseRpExtensionFlag() {
        return useRpExtensionFlag;
    }

    public void setUseRpExtensionFlag(String useRpExtensionFlag) {
        this.useRpExtensionFlag = useRpExtensionFlag;
    }

    public String getTmoNextGenFlag() {
        return tmoNextGenFlag;
    }

    public void setTmoNextGenFlag(String tmoNextGenFlag) {
        this.tmoNextGenFlag = tmoNextGenFlag;
    }

    public TFOneServicePlanCarrierFeature getServicePlanCarrierFeature() {
        return servicePlanCarrierFeature;
    }

    public void setServicePlanCarrierFeature(TFOneServicePlanCarrierFeature servicePlanCarrierFeature) {
        this.servicePlanCarrierFeature = servicePlanCarrierFeature;
    }

    public List<TFOneRatePlanExtensionLink> getRpExtensionLinks() {
        return rpExtensionLinks;
    }

    public void setRpExtensionLinks(List<TFOneRatePlanExtensionLink> rpExtensionLinks) {
        this.rpExtensionLinks = rpExtensionLinks;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getxCarrierId() {
        return xCarrierId;
    }

    public void setxCarrierId(String xCarrierId) {
        this.xCarrierId = xCarrierId;
    }

    @Override
    public String toString() {
        return "TFOneCarrierFeature{" +
                "objId='" + objId + '\'' +
                ", dev='" + dev + '\'' +
                ", xTechnology='" + xTechnology + '\'' +
                ", xRatePlan='" + xRatePlan + '\'' +
                ", xVoicemail='" + xVoicemail + '\'' +
                ", xVmCode='" + xVmCode + '\'' +
                ", xVmPackage='" + xVmPackage + '\'' +
                ", xCallerId='" + xCallerId + '\'' +
                ", xIdCode='" + xIdCode + '\'' +
                ", xIdPackage='" + xIdPackage + '\'' +
                ", xSms='" + xSms + '\'' +
                ", xSmsCode='" + xSmsCode + '\'' +
                ", xSmsPackage='" + xSmsPackage + '\'' +
                ", xCallWaiting='" + xCallWaiting + '\'' +
                ", xCwCode='" + xCwCode + '\'' +
                ", xCwPackage='" + xCwPackage + '\'' +
                ", xDigitalFeature='" + xDigitalFeature + '\'' +
                ", xDigFeature='" + xDigFeature + '\'' +
                ", xFeature2xCarrier='" + xFeature2xCarrier + '\'' +
                ", xSmscNumber='" + xSmscNumber + '\'' +
                ", xData='" + xData + '\'' +
                ", xRestrictedUse='" + xRestrictedUse + '\'' +
                ", xSwitchBaseRate='" + xSwitchBaseRate + '\'' +
                ", xFeatures2BusOrg='" + xFeatures2BusOrg + '\'' +
                ", xIsSwbCarrier='" + xIsSwbCarrier + '\'' +
                ", xMpn='" + xMpn + '\'' +
                ", xMpnCode='" + xMpnCode + '\'' +
                ", xPoolName='" + xPoolName + '\'' +
                ", createMformIgFlag='" + createMformIgFlag + '\'' +
                ", useCfExtensionFlag='" + useCfExtensionFlag + '\'' +
                ", dataSaver='" + dataSaver + '\'' +
                ", dataSaverCode='" + dataSaverCode + '\'' +
                ", useRpExtensionFlag='" + useRpExtensionFlag + '\'' +
                ", tmoNextGenFlag='" + tmoNextGenFlag + '\'' +
                ", servicePlanId='" + servicePlanId + '\'' +
                ", brand='" + brand + '\'' +
                ", xCarrierId='" + xCarrierId + '\'' +
                ", servicePlanCarrierFeature=" + servicePlanCarrierFeature +
                ", rpExtensionLinks=" + rpExtensionLinks +
                '}';
    }
}
