/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import java.util.List;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * TABLE SA.X_RP_PROFILE
 * @author Shireen Fathima
 */
public class TracfoneOneRatePlanProfile {
    
    private String dbEnv;
    private String profileId;
    @NotNull(message = "Profile Description cannot be null")
    @Size(min=1, message = "Profile Description cannot be blank")
    @Size(max=100, message = "Profile Description cannot have more than 100 characters")
    private String profileDescription;
    private List<TracfoneOneRatePlanExtensionLink> ratePlanExtensionLink;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public List<TracfoneOneRatePlanExtensionLink> getRatePlanExtensionLink() {
        return ratePlanExtensionLink;
    }

    public void setRatePlanExtensionLink(List<TracfoneOneRatePlanExtensionLink> ratePlanExtensionLink) {
        this.ratePlanExtensionLink = ratePlanExtensionLink;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getProfileDescription() {
        return profileDescription;
    }

    public void setProfileDescription(String profileDescription) {
        this.profileDescription = profileDescription;
    }

    @Override
    public String toString() {
        return "TracfoneOneRatePlanProfile{" + "dbEnv=" + dbEnv + ", "
                + "profileId=" + profileId + ", "
                + "profileDescription=" + profileDescription + ", "
                + "ratePlanExtensionLink=" + ratePlanExtensionLink + '}';
    }
    
    
}
