package com.tracfone.service.model.response;

import java.util.List;

public class TFOneGeoCodeAddress {
    private TFOneGeoCoderSpatialReference spatialReference;
    private List<TFOneGeoCoderCandidates> candidates;

    public TFOneGeoCoderSpatialReference getSpatialReference() {
        return spatialReference;
    }

    public void setSpatialReference(TFOneGeoCoderSpatialReference spatialReference) {
        this.spatialReference = spatialReference;
    }

    public List<TFOneGeoCoderCandidates> getCandidates() {
        return candidates;
    }

    public void setCandidates(List<TFOneGeoCoderCandidates> candidates) {
        this.candidates = candidates;
    }
}
