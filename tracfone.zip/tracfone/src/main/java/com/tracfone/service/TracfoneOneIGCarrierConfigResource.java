package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneOneIGCarrierConfigControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfig;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfigDetails;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGCarrierConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author Gaurav.Sharma
 */
@Path("igcarrierconfigupdate")
public class TracfoneOneIGCarrierConfigResource {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneIGCarrierConfigResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @EJB
    private TracfoneOneIGCarrierConfigControllerLocal configControllerLocal;

    @Context
    private SecurityContext securityContext;

    /**
     * This method is used to get all carriers
     *
     * @param carrierConfig
     * @return
     */
    @POST
    @Path("igconfigmaintenance/getcarriers")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarriers(final TracfoneOneIGCarrierConfig carrierConfig) {
        List<String> carrierData = new ArrayList<>();
        try {
            carrierData = configControllerLocal.getCarriers(carrierConfig.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(carrierData), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get Carriers Configs and Carrier Details based on
     * the search criteria
     *
     * @param carrierConfig
     * @return
     */
    @POST
    @Path("igconfigmaintenance/getcarrierconfig")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierConfig(final TracfoneOneIGCarrierConfig carrierConfig) {
        List<TFOneIGCarrierConfig> carrierConfigs = new ArrayList<>();
        try {
            carrierConfigs = configControllerLocal.getCarrierConfig(carrierConfig);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(carrierConfigs), MediaType.APPLICATION_JSON).build();
    }
    
     /**
     * This method is used to update Carrier Details
     *
     * @param carrierDetails
     * @return
     */
    @POST
    @Path("igconfigmaintenance/updateconfigdetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrierConfigDetails(final TracfoneOneIGCarrierConfig carrierDetails) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = configControllerLocal.updateCarrierConfigDetails(carrierDetails, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete Carrier Details
     *
     * @param carrierDetails
     * @return
     */
    @POST
    @Path("igconfigmaintenance/deleteconfigdetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteCarrierConfigDetails(final TracfoneOneIGCarrierConfigDetails carrierDetails) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = configControllerLocal.deleteCarrierConfigDetails(carrierDetails, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to Insert Carrier Details
     *
     * @param carrierDetails
     * @return
     */
    @POST
    @Path("igconfigmaintenance/insertconfigdetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarrierConfigDetails(TracfoneOneIGCarrierConfig carrierDetails) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = configControllerLocal.insertCarrierConfigDetails(carrierDetails,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to Insert Carrier Config and Details
     *
     * @param carrierDetails
     * @return
     */
    @POST
    @Path("igconfigmaintenance/insertconfig")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarrierConfig(TracfoneOneIGCarrierConfig carrierDetails) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = configControllerLocal.insertCarrierConfig(carrierDetails,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all prop names
     *
     * @param carrierConfig
     * @return
     */
    @POST
    @Path("igconfigmaintenance/getpropname")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getPropNameForRef(final TracfoneOneIGCarrierConfig carrierConfig) {
        List<String> carrierData = new ArrayList<>();
        try {
            carrierData = configControllerLocal.getPropNameForRef(carrierConfig);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(carrierData), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all prop names
     *
     * @param carrierConfig
     * @return
     */
    @POST
    @Path("igconfigmaintenance/getpropnamelist")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getPropNameForRefList(final TracfoneOneIGCarrierConfig carrierConfig) {
        List<String> carrierData = new ArrayList<>();
        try {
            carrierData = configControllerLocal.getPropNameForRefList(carrierConfig);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(carrierData), MediaType.APPLICATION_JSON).build();
    }


    /**
     * Retrieves the user object making request from the principal.
     *
     * @return
     */
    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }
}
