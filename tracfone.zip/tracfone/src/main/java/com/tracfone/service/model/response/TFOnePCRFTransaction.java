package com.tracfone.service.model.response;

/**
 * @author Gaurav.Sharma
 */
public class TFOnePCRFTransaction {

    private String objId;
    private String min;
    private String esn;
    private String subscriberId;
    private String groupId;
    private String orderType;
    private String phoneManufacturer;
    private String actionType;
    private String sim;
    private String zipCode;
    private String servicePlanId;
    private String caseId;
    private String pcrfStatusCode;
    private String statusMessage;
    private String webObjId;
    private String brand;
    private String sourceSystem;
    private String template;
    private String ratePlan;
    private String blackoutWaitDate;
    private String retryCount;
    private String dataUsage;
    private String hiSpeedDataUsage;
    private String conversionFactor;
    private String dealerId;
    private String denomination;
    private String pcrfParentName;
    private String propagateFlag;
    private String servicePlanType;
    private String partInstStatus;
    private String phoneModel;
    private String contentDeliveryFormat;
    private String language;
    private String wfMacId;
    private String insertTimestamp;
    private String updateTimestamp;
    private String mdn;
    private String pcrfCos;
    private String ttl;
    private String futureTtl;
    private String redemptionDate;
    private String contactObjId;
    private String imsi;
    private String lifeLineId;
    private String installDate;
    private String programParameterId;
    private String vmbcCertificationFlag;
    private String charField1;
    private String charField2;
    private String charField3;
    private String dateField1;
    private String addonsFlag;
    private String rcsEnableFlag;
    private String posaFlag;
    private String unlockStatus;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getEsn() {
        return esn;
    }

    public void setEsn(String esn) {
        this.esn = esn;
    }

    public String getSubscriberId() {
        return subscriberId;
    }

    public void setSubscriberId(String subscriberId) {
        this.subscriberId = subscriberId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getPhoneManufacturer() {
        return phoneManufacturer;
    }

    public void setPhoneManufacturer(String phoneManufacturer) {
        this.phoneManufacturer = phoneManufacturer;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getSim() {
        return sim;
    }

    public void setSim(String sim) {
        this.sim = sim;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getPcrfStatusCode() {
        return pcrfStatusCode;
    }

    public void setPcrfStatusCode(String pcrfStatusCode) {
        this.pcrfStatusCode = pcrfStatusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getWebObjId() {
        return webObjId;
    }

    public void setWebObjId(String webObjId) {
        this.webObjId = webObjId;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(String ratePlan) {
        this.ratePlan = ratePlan;
    }

    public String getBlackoutWaitDate() {
        return blackoutWaitDate;
    }

    public void setBlackoutWaitDate(String blackoutWaitDate) {
        this.blackoutWaitDate = blackoutWaitDate;
    }

    public String getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(String retryCount) {
        this.retryCount = retryCount;
    }

    public String getDataUsage() {
        return dataUsage;
    }

    public void setDataUsage(String dataUsage) {
        this.dataUsage = dataUsage;
    }

    public String getHiSpeedDataUsage() {
        return hiSpeedDataUsage;
    }

    public void setHiSpeedDataUsage(String hiSpeedDataUsage) {
        this.hiSpeedDataUsage = hiSpeedDataUsage;
    }

    public String getConversionFactor() {
        return conversionFactor;
    }

    public void setConversionFactor(String conversionFactor) {
        this.conversionFactor = conversionFactor;
    }

    public String getDealerId() {
        return dealerId;
    }

    public void setDealerId(String dealerId) {
        this.dealerId = dealerId;
    }

    public String getDenomination() {
        return denomination;
    }

    public void setDenomination(String denomination) {
        this.denomination = denomination;
    }

    public String getPcrfParentName() {
        return pcrfParentName;
    }

    public void setPcrfParentName(String pcrfParentName) {
        this.pcrfParentName = pcrfParentName;
    }

    public String getPropagateFlag() {
        return propagateFlag;
    }

    public void setPropagateFlag(String propagateFlag) {
        this.propagateFlag = propagateFlag;
    }

    public String getServicePlanType() {
        return servicePlanType;
    }

    public void setServicePlanType(String servicePlanType) {
        this.servicePlanType = servicePlanType;
    }

    public String getPartInstStatus() {
        return partInstStatus;
    }

    public void setPartInstStatus(String partInstStatus) {
        this.partInstStatus = partInstStatus;
    }

    public String getPhoneModel() {
        return phoneModel;
    }

    public void setPhoneModel(String phoneModel) {
        this.phoneModel = phoneModel;
    }

    public String getContentDeliveryFormat() {
        return contentDeliveryFormat;
    }

    public void setContentDeliveryFormat(String contentDeliveryFormat) {
        this.contentDeliveryFormat = contentDeliveryFormat;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getWfMacId() {
        return wfMacId;
    }

    public void setWfMacId(String wfMacId) {
        this.wfMacId = wfMacId;
    }

    public String getInsertTimestamp() {
        return insertTimestamp;
    }

    public void setInsertTimestamp(String insertTimestamp) {
        this.insertTimestamp = insertTimestamp;
    }

    public String getUpdateTimestamp() {
        return updateTimestamp;
    }

    public void setUpdateTimestamp(String updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    public String getMdn() {
        return mdn;
    }

    public void setMdn(String mdn) {
        this.mdn = mdn;
    }

    public String getPcrfCos() {
        return pcrfCos;
    }

    public void setPcrfCos(String pcrfCos) {
        this.pcrfCos = pcrfCos;
    }

    public String getTtl() {
        return ttl;
    }

    public void setTtl(String ttl) {
        this.ttl = ttl;
    }

    public String getFutureTtl() {
        return futureTtl;
    }

    public void setFutureTtl(String futureTtl) {
        this.futureTtl = futureTtl;
    }

    public String getRedemptionDate() {
        return redemptionDate;
    }

    public void setRedemptionDate(String redemptionDate) {
        this.redemptionDate = redemptionDate;
    }

    public String getContactObjId() {
        return contactObjId;
    }

    public void setContactObjId(String contactObjId) {
        this.contactObjId = contactObjId;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getLifeLineId() {
        return lifeLineId;
    }

    public void setLifeLineId(String lifeLineId) {
        this.lifeLineId = lifeLineId;
    }

    public String getInstallDate() {
        return installDate;
    }

    public void setInstallDate(String installDate) {
        this.installDate = installDate;
    }

    public String getProgramParameterId() {
        return programParameterId;
    }

    public void setProgramParameterId(String programParameterId) {
        this.programParameterId = programParameterId;
    }

    public String getVmbcCertificationFlag() {
        return vmbcCertificationFlag;
    }

    public void setVmbcCertificationFlag(String vmbcCertificationFlag) {
        this.vmbcCertificationFlag = vmbcCertificationFlag;
    }

    public String getCharField1() {
        return charField1;
    }

    public void setCharField1(String charField1) {
        this.charField1 = charField1;
    }

    public String getCharField2() {
        return charField2;
    }

    public void setCharField2(String charField2) {
        this.charField2 = charField2;
    }

    public String getCharField3() {
        return charField3;
    }

    public void setCharField3(String charField3) {
        this.charField3 = charField3;
    }

    public String getDateField1() {
        return dateField1;
    }

    public void setDateField1(String dateField1) {
        this.dateField1 = dateField1;
    }

    public String getAddonsFlag() {
        return addonsFlag;
    }

    public void setAddonsFlag(String addonsFlag) {
        this.addonsFlag = addonsFlag;
    }

    public String getRcsEnableFlag() {
        return rcsEnableFlag;
    }

    public void setRcsEnableFlag(String rcsEnableFlag) {
        this.rcsEnableFlag = rcsEnableFlag;
    }

    public String getPosaFlag() {
        return posaFlag;
    }

    public void setPosaFlag(String posaFlag) {
        this.posaFlag = posaFlag;
    }

    public String getUnlockStatus() {
        return unlockStatus;
    }

    public void setUnlockStatus(String unlockStatus) {
        this.unlockStatus = unlockStatus;
    }

    @Override
    public String toString() {
        return "TFOnePCRFTransaction{" +
                "objId='" + objId + '\'' +
                ", min='" + min + '\'' +
                ", esn='" + esn + '\'' +
                ", subscriberId='" + subscriberId + '\'' +
                ", groupId='" + groupId + '\'' +
                ", orderType='" + orderType + '\'' +
                ", phoneManufacturer='" + phoneManufacturer + '\'' +
                ", actionType='" + actionType + '\'' +
                ", sim='" + sim + '\'' +
                ", zipCode='" + zipCode + '\'' +
                ", servicePlanId='" + servicePlanId + '\'' +
                ", caseId='" + caseId + '\'' +
                ", pcrfStatusCode='" + pcrfStatusCode + '\'' +
                ", statusMessage='" + statusMessage + '\'' +
                ", webObjId='" + webObjId + '\'' +
                ", brand='" + brand + '\'' +
                ", sourceSystem='" + sourceSystem + '\'' +
                ", template='" + template + '\'' +
                ", ratePlan='" + ratePlan + '\'' +
                ", blackoutWaitDate='" + blackoutWaitDate + '\'' +
                ", retryCount='" + retryCount + '\'' +
                ", dataUsage='" + dataUsage + '\'' +
                ", hiSpeedDataUsage='" + hiSpeedDataUsage + '\'' +
                ", conversionFactor='" + conversionFactor + '\'' +
                ", dealerId='" + dealerId + '\'' +
                ", denomination='" + denomination + '\'' +
                ", pcrfParentName='" + pcrfParentName + '\'' +
                ", propagateFlag='" + propagateFlag + '\'' +
                ", servicePlanType='" + servicePlanType + '\'' +
                ", partInstStatus='" + partInstStatus + '\'' +
                ", phoneModel='" + phoneModel + '\'' +
                ", contentDeliveryFormat='" + contentDeliveryFormat + '\'' +
                ", language='" + language + '\'' +
                ", wfMacId='" + wfMacId + '\'' +
                ", insertTimestamp='" + insertTimestamp + '\'' +
                ", updateTimestamp='" + updateTimestamp + '\'' +
                ", mdn='" + mdn + '\'' +
                ", pcrfCos='" + pcrfCos + '\'' +
                ", ttl='" + ttl + '\'' +
                ", futureTtl='" + futureTtl + '\'' +
                ", redemptionDate='" + redemptionDate + '\'' +
                ", contactObjId='" + contactObjId + '\'' +
                ", imsi='" + imsi + '\'' +
                ", lifeLineId='" + lifeLineId + '\'' +
                ", installDate='" + installDate + '\'' +
                ", programParameterId='" + programParameterId + '\'' +
                ", vmbcCertificationFlag='" + vmbcCertificationFlag + '\'' +
                ", charField1='" + charField1 + '\'' +
                ", charField2='" + charField2 + '\'' +
                ", charField3='" + charField3 + '\'' +
                ", dateField1='" + dateField1 + '\'' +
                ", addonsFlag='" + addonsFlag + '\'' +
                ", rcsEnableFlag='" + rcsEnableFlag + '\'' +
                ", posaFlag='" + posaFlag + '\'' +
                ", unlockStatus='" + unlockStatus + '\'' +
                '}';
    }
}
