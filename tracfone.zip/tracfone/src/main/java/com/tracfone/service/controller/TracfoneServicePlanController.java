package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeConfig;
import com.tracfone.service.model.request.TracfoneOneCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucketTier;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildTier;
import com.tracfone.service.model.request.TracfoneOneRatePlan;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionLink;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.request.TracfoneOneSearchCarrierFeatureModel;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneSearchServicePlanModel;
import com.tracfone.service.model.request.TracfoneOneServicePlanCarrierFeature;
import com.tracfone.service.model.response.TFOneAncillaryCodeConfig;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileBucketTier;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildTier;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneRatePlan;
import com.tracfone.service.model.response.TFOneRatePlanExtensionConfig;
import com.tracfone.service.model.response.TFOneRatePlanExtensionLink;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.EXCEPTION;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.NUMBER_MAP_IS;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_COUNT_BUCKETS_BY_SP;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_COUNT_CHILD_BUCKETS_BY_SP;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ALL_SERVICE_PLAN_CARRIERS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_ALL_SERVICE_PLAN_CARRIERS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CARRIER_FEATURES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CARRIER_FEATURES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CF_LINKS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CF_LINKS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CF_RATE_PLANS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_CF_RATE_PLANS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_PROFILE_FEATURE_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_PROFILE_FEATURE_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_SERVICE_PLAN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_GET_SERVICE_PLAN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_MIRROR_SERVICE_PLAN_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_MIRROR_SERVICE_PLAN_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CARRIER_FEATURES_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CARRIER_FEATURES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CP_BUCKETS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CP_BUCKETS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_SERVICE_PLANS_ERROR;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.TRACFONE_SEARCH_SERVICE_PLANS_ERROR_MESSAGE;

@Stateless
public class TracfoneServicePlanController implements TracfoneServicePlanControllerLocal {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneServicePlanController.class);

    @EJB
    TracfoneServicePlanLocalAction tracfoneServicePlanAction;
    @EJB
    TracfoneRatePlanLocalAction tracfoneRatePlanAction;
    @EJB
    TracfoneProfileLocalAction tracfoneProfileAction;
    @EJB
    TracfoneFeatureLocalAction tracfoneFeatureAction;
    @EJB
    TracfoneBucketLocalAction tracfoneBucketAction;

    @Override
    public List<TFOneCarrierServicePlan> searchServicePlans(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> servicePlans = new ArrayList<>();
        try {
            servicePlans = tracfoneServicePlanAction.searchServicePlans(tfServicePlanModel);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_SERVICE_PLANS_ERROR, TRACFONE_SEARCH_SERVICE_PLANS_ERROR_MESSAGE, ex);
        }
        return servicePlans;
    }

    @Override
    public List<TFOneCarrierFeature> viewServicePlanCarrierFeatures(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        try {
            carrierFeatures = tracfoneServicePlanAction.viewServicePlanCarrierFeatures(tfServicePlanModel);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_CARRIER_FEATURES_ERROR, TRACFONE_GET_CARRIER_FEATURES_ERROR_MESSAGE, ex);
        }

        return carrierFeatures;
    }

    @Override
    public List<TFOneCarrierServicePlan> getServicePlansForCarrier(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        try {
            if (StringUtils.isNullOrEmpty(tracfoneOneSearchPlanModel.getCarrierName())) {
                if (tracfoneOneSearchPlanModel.isLegacy()) {
                    carrierServicePlans = tracfoneServicePlanAction.getAllLegacyPaygoPlans(tracfoneOneSearchPlanModel.getDbEnv(), null);
                } else {
                    carrierServicePlans = tracfoneServicePlanAction.getAllServicePlans(tracfoneOneSearchPlanModel.getDbEnv());
                }
            } else {
                if (tracfoneOneSearchPlanModel.isLegacy()) {
                    carrierServicePlans = tracfoneServicePlanAction.getAllLegacyPaygoPlans(tracfoneOneSearchPlanModel.getDbEnv(),
                            tracfoneOneSearchPlanModel.getCarrierName());
                } else {
                    carrierServicePlans = tracfoneRatePlanAction.getServicePlansForCarrier(tracfoneOneSearchPlanModel.getCarrierName(),
                            tracfoneOneSearchPlanModel.getDbEnv());
                }
            }
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_SERVICE_PLAN_ERROR, TRACFONE_GET_SERVICE_PLAN_ERROR_MESSAGE, ex);
        }

        return carrierServicePlans;
    }

    @Override
    public List<TFOneRatePlan> getCarrierRatePlans(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException {
        List<TFOneRatePlan> ratePlans = new ArrayList<>();
        try {
            if (StringUtils.isNullOrEmpty(tracfoneOneSearchPlanModel.getCarrierName())) {
                ratePlans = tracfoneRatePlanAction.getMasterRatePlans(tracfoneOneSearchPlanModel.getDbEnv());
            } else {
                ratePlans = tracfoneRatePlanAction.getCarrierRatePlans(tracfoneOneSearchPlanModel.getDbEnv(),
                        tracfoneOneSearchPlanModel.getCarrierName());
            }
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_CF_RATE_PLANS_ERROR, TRACFONE_GET_CF_RATE_PLANS_ERROR_MESSAGE, ex);
        }

        return ratePlans;
    }

    @Override
    public List<TFOneCarrierFeature> getCarrierFeatureLinks(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        try {
            if (!hasBucketFilter(tfServicePlanModel) && !hasFeaturesFilter(tfServicePlanModel) && !hasProfileFilter(tfServicePlanModel)) {
                tfServicePlanModel.getSelectedCarrierFeatures().get(0).setDbEnv(tfServicePlanModel.getDbEnv());
                carrierFeatures = tracfoneRatePlanAction.getCarrierFeatureLinks(tfServicePlanModel.getSelectedCarrierFeatures());
            } else {
                carrierFeatures = tracfoneServicePlanAction.getCarrierFeatureLinks(tfServicePlanModel);
            }
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_CF_LINKS_ERROR, TRACFONE_GET_CF_LINKS_ERROR_MESSAGE, ex);
        }

        return carrierFeatures;
    }

    @Override
    public List<TFOneRatePlanExtensionConfig> getAllProfileFeatures(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException {
        List<TFOneRatePlanExtensionConfig> filteredFeatures = new ArrayList<>();
        try {
            // first check in x_rp_ancillary_code_config table.
            TracfoneOneAncillaryCodeConfig config = new TracfoneOneAncillaryCodeConfig();
            config.setDbEnv(tfServicePlanModel.getDbEnv());
            config.setProfileId(tfServicePlanModel.getProfileId());
            config.setExtensionObjId(tfServicePlanModel.getRpExtensionId());
            List<TFOneAncillaryCodeConfig> ancillaryCodeFeatures = tracfoneProfileAction.getAncillaryCodeConfig(config);
            LOGGER.info("Full ancillaryCodeFeatures - " + ancillaryCodeFeatures);
            List<TFOneRatePlanExtensionConfig> profileFeatures = mapFeatures(ancillaryCodeFeatures);
            // If no features found there then show x_rp_extension_config
            if (ancillaryCodeFeatures.isEmpty()) {
                TracfoneOneSearchProfileModel profile = new TracfoneOneSearchProfileModel();
                profile.setDbEnv(tfServicePlanModel.getDbEnv());
                profile.setProfileId(tfServicePlanModel.getProfileId());
                profileFeatures = tracfoneFeatureAction.getAllProfileFeatures(profile);
                LOGGER.info("Full profileFeatures - " + profileFeatures);
            }
            if (hasFeaturesFilter(tfServicePlanModel)) {
                LOGGER.info("Has filters");
                for (TFOneRatePlanExtensionConfig feature : profileFeatures) {
                    TFOneRatePlanExtensionConfig filtered = filterFeatures(tfServicePlanModel, feature);
                    if (filtered != null) {
                        filteredFeatures.add(filtered);
                    }
                }
            } else {
                LOGGER.info("No filters");
                filteredFeatures.addAll(profileFeatures);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_PROFILE_FEATURE_ERROR, TRACFONE_GET_PROFILE_FEATURE_ERROR_MESSAGE, ex);
        }
        LOGGER.info("filtered list - " + filteredFeatures);
        return filteredFeatures;
    }

    private List<TFOneRatePlanExtensionConfig> mapFeatures(List<TFOneAncillaryCodeConfig> ancillaryCodeFeatures) {
        List<TFOneRatePlanExtensionConfig> features = new ArrayList<>();
        TFOneRatePlanExtensionConfig feature = null;
        for (TFOneAncillaryCodeConfig ancillaryCodeConfig : ancillaryCodeFeatures) {
            feature = new TFOneRatePlanExtensionConfig();
            feature.setProfileId(ancillaryCodeConfig.getProfileId());
            feature.setFeatureName(ancillaryCodeConfig.getFeatureName());
            feature.setFeatureValue(ancillaryCodeConfig.getFeatureValue());
            feature.setFeatureRequirement(ancillaryCodeConfig.getFeatureRequirement());
            feature.setDisplaySUIFlag(ancillaryCodeConfig.getDisplaySUIFlag());
            feature.setRestrictSUIFlag(ancillaryCodeConfig.getRestrictSUIFlag());
            feature.setToggleFlag(ancillaryCodeConfig.getToggleFlag());
            feature.setNotes(ancillaryCodeConfig.getNotes());
            features.add(feature);
        }
        return features;
    }

    private TFOneRatePlanExtensionConfig filterFeatures(TracfoneOneSearchServicePlanModel tfServicePlanModel, TFOneRatePlanExtensionConfig feature) {
        TFOneRatePlanExtensionConfig filteredFeature = null;
        // if only feature name matches the search criteria
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureName())) {
            if (feature.getFeatureName().equalsIgnoreCase(tfServicePlanModel.getFeatureName())) {
                LOGGER.info("Match for Feature Name found ");
                // check if feature requirement was also specified to match
                if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureRequirement())) {
                    LOGGER.info("Going to check for Feature Requirement ");
                    if (tfServicePlanModel.getFeatureRequirement().equalsIgnoreCase(feature.getFeatureRequirement())) {
                        LOGGER.info("Match for Feature Requirement found ");
                        filteredFeature = feature;
                    }
                } else {
                    LOGGER.info("Match for Feature Requirement not required");
                    filteredFeature = feature;
                }
            }
            // if only feature requirement matches the search criteria
        } else if (feature.getFeatureRequirement().equalsIgnoreCase(tfServicePlanModel.getFeatureRequirement())) {
            LOGGER.info(" ONLY Match for Feature Requirement required");
            filteredFeature = feature;
        }

        LOGGER.info("filtered feature for Feature Name " + tfServicePlanModel.getFeatureName() +
                " and Feature Requirement " + tfServicePlanModel.getFeatureRequirement() + " is " + filteredFeature);
        return filteredFeature;
    }

    @Override
    public List<TFOneCarrierProfileBucket> searchCarrierProfileBuckets(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException {
        List<TFOneCarrierProfileBucket> filteredBuckets = new ArrayList<>();
        try {
            TracfoneOneSearchBucketModel tfOneSearchBucketModel = getTracfoneOneSearchBucketModel(tfServicePlanModel);
            List<TFOneCarrierProfileBucket> tracfoneOneCarrierProfileBuckets = tracfoneBucketAction.searchCarrierProfileBuckets(tfOneSearchBucketModel);
            LOGGER.info("Full list - " + tracfoneOneCarrierProfileBuckets);
            if (hasBucketFilter(tfServicePlanModel)) {
                for (TFOneCarrierProfileBucket bucket : tracfoneOneCarrierProfileBuckets) {
                    TFOneCarrierProfileBucket filtered = filterBuckets(tfServicePlanModel, bucket);
                    if (filtered != null) {
                        filteredBuckets.add(filtered);
                    }
                }
            } else {
                filteredBuckets.addAll(tracfoneOneCarrierProfileBuckets);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_CP_BUCKETS_ERROR, TRACFONE_SEARCH_CP_BUCKETS_ERROR_MESSAGE, ex);
        }
        LOGGER.info("filtered list for buckets - " + filteredBuckets);
        return filteredBuckets;
    }

    private TFOneCarrierProfileBucket filterBuckets(TracfoneOneSearchServicePlanModel tfServicePlanModel, TFOneCarrierProfileBucket bucket) {
        TFOneCarrierProfileBucket filteredBucket = null;
        // if only bucket id matches the search criteria
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId())) {
            if (bucket.getBucketId().equalsIgnoreCase(tfServicePlanModel.getBucketId())) {
                // check if bucket requirement was also specified to match
                if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
                    if (tfServicePlanModel.getBucketRequirement().equalsIgnoreCase(bucket.getBucketRequirement())) {
                        filteredBucket = bucket;
                    }
                } else {
                    filteredBucket = bucket;
                }
            }
            // if only bucket requirement matches the search criteria
        } else if (bucket.getBucketRequirement().equalsIgnoreCase(tfServicePlanModel.getBucketRequirement())) {
            filteredBucket = bucket;
        }
        LOGGER.info("filtered feature for Bucket ID " + tfServicePlanModel.getBucketId() +
                " and Bucket Requirement " + tfServicePlanModel.getBucketRequirement() + " is " + filteredBucket);
        return filteredBucket;
    }

    @Override
    public List<TFOneCarrierProfileChildBucket> searchCarrierProfileChildBuckets(TracfoneOneSearchServicePlanModel tfServicePlanModel) throws TracfoneOneException {
        List<TFOneCarrierProfileChildBucket> filteredBuckets = new ArrayList<>();
        try {
            TracfoneOneSearchBucketModel tfOneSearchBucketModel = getTracfoneOneSearchBucketModel(tfServicePlanModel);
            List<TFOneCarrierProfileChildBucket> tracfoneOneCarrierProfileChildBuckets = tracfoneBucketAction.searchCarrierProfileChildBuckets(tfOneSearchBucketModel);
            LOGGER.info("Full list - " + tracfoneOneCarrierProfileChildBuckets);
            if (hasBucketFilter(tfServicePlanModel)) {
                for (TFOneCarrierProfileChildBucket childBucket : tracfoneOneCarrierProfileChildBuckets) {
                    TFOneCarrierProfileChildBucket filtered = filterChildBuckets(tfServicePlanModel, childBucket);
                    if (filtered != null) {
                        filteredBuckets.add(filtered);
                    }
                }
            } else {
                filteredBuckets.addAll(tracfoneOneCarrierProfileChildBuckets);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR, TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR_MESSAGE, ex);
        }
        LOGGER.info("filtered list for child buckets - " + filteredBuckets);
        return filteredBuckets;
    }

    @Override
    public Map<String, Integer> mirrorServicePlan(TracfoneOneSearchPlanModel tfSearchModel, int userId) throws TracfoneOneException {
        Map<String, Integer> numberMap = new HashMap<>();
        LOGGER.info("mirror service plans for " + tfSearchModel);
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        // Get the carrier features and mtms associated to the service plan
        try {
            numberMap.put("carrierFeatures", tfSearchModel.getCarrierFeatures().size());
            // TODO if it is a legacy service plan, i need to find the row in mtm that has null CF column and delete it first
            if (tfSearchModel.isLegacy()) {
                tracfoneServicePlanAction.deleteDummyCarrierFeature(tfSearchModel.getDbEnv(), tfSearchModel.getToServicePlanId(), userId);
            }
            TracfoneOneSearchCarrierFeatureModel tracfoneOneSearchCFModel = new TracfoneOneSearchCarrierFeatureModel();
            tracfoneOneSearchCFModel.setDbEnv(tfSearchModel.getDbEnv());
            tracfoneOneSearchCFModel.setCarrierName(tfSearchModel.getCarrierName());
            tracfoneOneSearchCFModel.setServicePlanId(tfSearchModel.getServicePlanId());
            tracfoneOneSearchCFModel.setLegacy(tfSearchModel.isLegacy());
            List<TFOneCarrierFeature> carrierFeatures = tracfoneRatePlanAction.searchCarrierFeatures(tracfoneOneSearchCFModel);
            LOGGER.info("Carrier Features on the From Service Plan " + carrierFeatures);
            Map<String, TFOneCarrierFeature> carrierFeatureMap = createNewCFMapping(carrierFeatures);
            LOGGER.info("Carrier Features Map is ready " + carrierFeatureMap);

            List<TracfoneOneCarrierFeature> selectedCarrierFeatures = tfSearchModel.getCarrierFeatures();
            // if profiles need to be copied, get list of all links
            if (tfSearchModel.isCopyProfiles()) {
                executorService.execute(() -> {
                    for (TracfoneOneCarrierFeature carrierFeature : selectedCarrierFeatures) {
                        TracfoneOneCarrierFeature carrierFeatureForInsert = carrierFeature;
                        LOGGER.info(Thread.currentThread().getName() + " Carrier Feature from UI is " + carrierFeatureForInsert);
                        if (!carrierFeature.isEdited()) {
                            carrierFeatureForInsert = copyCarrierFeature(carrierFeatureMap.get(carrierFeature.getObjId()),
                                    tfSearchModel.getToServicePlanId());
                            LOGGER.info(Thread.currentThread().getName() + " Carrier Feature from UI is edited " + carrierFeatureForInsert);
                        } else {
                            if (carrierFeatureForInsert.getServicePlanCarrierFeature() != null) {
                                carrierFeatureForInsert.getServicePlanCarrierFeature().setServicePlanId(tfSearchModel.getToServicePlanId());
                            }
                        }
                        LOGGER.info(Thread.currentThread().getName() + " Carrier Feature - set profiles and buckets " + carrierFeatureForInsert);
                        try {
                            // if buckets and child buckets need to be copied get those also
                            carrierFeatureForInsert.setRatePlanExtensionLinks(copyProfilesAndBuckets(carrierFeature, tfSearchModel));
                            carrierFeatureForInsert.setDbEnv(tfSearchModel.getDbEnv());
                            carrierFeatureForInsert.setObjId(null);
                            carrierFeatureForInsert.setLegacy(tfSearchModel.isLegacy());
                            LOGGER.info(Thread.currentThread().getName() + " Carrier Feature - COPIED THE profiles and buckets " + carrierFeatureForInsert);
                            tracfoneRatePlanAction.insertRatePlanAssociation(carrierFeatureForInsert, userId);
                        } catch (Exception e) {
                            LOGGER.error(Thread.currentThread().getName() + EXCEPTION, e);
                        }
                        LOGGER.info(Thread.currentThread().getName() + " RPA Insertion DONE ");
                    }
                });
                setProfileAndBucketCounts(numberMap, tfSearchModel);
            } else {
                executorService.execute(() -> {
                    // Insert Carrier Features only
                    TracfoneOneRatePlan tfRatePlan = new TracfoneOneRatePlan();
                    tfRatePlan.setDbEnv(tfSearchModel.getDbEnv());
                    tfRatePlan.setCarrierFeatures(copyCarrierFeatures(selectedCarrierFeatures, carrierFeatureMap, tfSearchModel.getToServicePlanId(), tfSearchModel.isLegacy()));
                    LOGGER.info(Thread.currentThread().getName() + " Carrier Features - All getting inserted " + tfRatePlan);
                    try {
                        tracfoneRatePlanAction.insertCarrierFeatures(tfRatePlan, tfSearchModel.getCarrierName(), userId);
                    } catch (TracfoneOneException e) {
                        LOGGER.error(Thread.currentThread().getName() + EXCEPTION + e);
                    }
                    LOGGER.info(Thread.currentThread().getName() + " Carrier Features - All getting inserted DONE ");
                });
            }
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_MIRROR_SERVICE_PLAN_ERROR, TRACFONE_MIRROR_SERVICE_PLAN_ERROR_MESSAGE, ex);
        } finally {
            executorService.shutdown();
        }
        LOGGER.info(NUMBER_MAP_IS + numberMap);
        return numberMap;
    }

    private void setProfileAndBucketCounts(Map<String, Integer> numberMap, TracfoneOneSearchPlanModel tfSearchModel) {
        Set<String> linkIds = getAllLinkObjIds(tfSearchModel.getCarrierFeatures());
        numberMap.put("profiles", linkIds.size());
        try {
            if (tfSearchModel.isCopyBuckets()) {
                int bucketCount = tracfoneServicePlanAction.countBucketsByLinkObjId(tfSearchModel.getDbEnv(), linkIds, tfSearchModel.getServicePlanId());
                numberMap.put("buckets", bucketCount);
            }
            if (tfSearchModel.isCopyChildBuckets()) {
                int childBucketCount = tracfoneServicePlanAction.countChildBucketsByLinkObjId(tfSearchModel.getDbEnv(), linkIds, tfSearchModel.getServicePlanId());
                numberMap.put("childBuckets", childBucketCount);
            }
        } catch (Exception e) {
            LOGGER.error(e);
            // This just will not return the bucket count. Should not cause the application to break
        }
        LOGGER.info(NUMBER_MAP_IS + numberMap);
    }

    private Set<String> getAllLinkObjIds(List<TracfoneOneCarrierFeature> carrierFeatures) {
        Set<String> linkIds = new HashSet<>();
        for (TracfoneOneCarrierFeature carrierFeature : carrierFeatures) {
            List<TracfoneOneRatePlanExtensionLink> links = carrierFeature.getRatePlanExtensionLinks();
            if (links != null && !links.isEmpty()) {
                links.stream().forEach(link -> linkIds.add(link.getObjId()));
            }
        }
        LOGGER.info("all profile ids that are identified for mirror service plan request " + linkIds);
        return linkIds;
    }

    private List<TracfoneOneCarrierFeature> copyCarrierFeatures(List<TracfoneOneCarrierFeature> selectedCarrierFeatures, Map<String,
            TFOneCarrierFeature> carrierFeatureMap, String toServicePlanId, boolean isLegacy) {
        List<TracfoneOneCarrierFeature> carrierFeaturesForCopy = new ArrayList<>();
        for (TracfoneOneCarrierFeature carrierFeature : selectedCarrierFeatures) {
            if (!carrierFeature.isEdited()) {
                carrierFeature = copyCarrierFeature(carrierFeatureMap.get(carrierFeature.getObjId()), toServicePlanId);
            } else {
                if (carrierFeature.getServicePlanCarrierFeature() != null) {
                    carrierFeature.getServicePlanCarrierFeature().setServicePlanId(toServicePlanId);
                }
            }
            carrierFeature.setLegacy(isLegacy);
            carrierFeaturesForCopy.add(carrierFeature);
        }
        return carrierFeaturesForCopy;
    }

    private Map<String, TFOneCarrierFeature> createNewCFMapping(List<TFOneCarrierFeature> carrierFeatures) {
        Map<String, TFOneCarrierFeature> carrierFeatureMap = new HashMap<>();
        for (TFOneCarrierFeature carrierFeature : carrierFeatures) {
            carrierFeatureMap.put(carrierFeature.getObjId(), carrierFeature);
        }
        return carrierFeatureMap;
    }

    private Map<String, TFOneRatePlanExtensionLink> createNewLinksMapping(List<TFOneRatePlanExtensionLink> links) {
        Map<String, TFOneRatePlanExtensionLink> linksMap = new HashMap<>();
        for (TFOneRatePlanExtensionLink link : links) {
            linksMap.put(link.getObjId(), link);
        }
        return linksMap;
    }

    private Map<String, TFOneCarrierProfileBucket> createNewBucketMapping(List<TFOneCarrierProfileBucket> buckets) {
        Map<String, TFOneCarrierProfileBucket> bucketsMap = new HashMap<>();
        for (TFOneCarrierProfileBucket bucket : buckets) {
            bucketsMap.put(bucket.getObjid(), bucket);
        }
        return bucketsMap;
    }

    private Map<String, TFOneCarrierProfileChildBucket> createNewChildBucketMapping(List<TFOneCarrierProfileChildBucket> childBuckets) {
        Map<String, TFOneCarrierProfileChildBucket> childBucketsMap = new HashMap<>();
        for (TFOneCarrierProfileChildBucket bucket : childBuckets) {
            childBucketsMap.put(bucket.getObjId(), bucket);
        }
        return childBucketsMap;
    }

    @Override
    public List<String> getAllServicePlanCarrierNames(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException {
        List<String> carrierNames = new ArrayList<>();
        try {
            carrierNames = tracfoneServicePlanAction.getAllServicePlanCarrierNames(tracfoneOneSearchPlanModel.getDbEnv(),
                    tracfoneOneSearchPlanModel.getServicePlanId(),
                    tracfoneOneSearchPlanModel.isLegacy());
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_ALL_SERVICE_PLAN_CARRIERS_ERROR, TRACFONE_GET_ALL_SERVICE_PLAN_CARRIERS_ERROR_MESSAGE, ex);
        }
        return carrierNames;
    }

    @Override
    public List<TFOneCarrierServicePlan> getServicePlansForCopy(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> servicePlans = new ArrayList<>();
        try {
            servicePlans = tracfoneServicePlanAction.getServicePlansForCopy(tracfoneOneSearchPlanModel);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_SERVICE_PLAN_ERROR, TRACFONE_GET_SERVICE_PLAN_ERROR_MESSAGE, ex);
        }
        return servicePlans;
    }

    @Override
    public TFOneGeneralResponse getCarrierFeatureCount(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws TracfoneOneException {
        TFOneGeneralResponse response;
        try {
            int count = tracfoneServicePlanAction.countCarrierFeatures(tfCarrierFeatureModel);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, String.valueOf(count));
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_CARRIER_FEATURES_ERROR, TRACFONE_SEARCH_CARRIER_FEATURES_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public List<TFOneCarrierFeature> getCarrierFeatureOrderings(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeaturesOrderings = new ArrayList<>();
        try {
            carrierFeaturesOrderings = tracfoneRatePlanAction.getCarrierFeatureMap(tfCarrierFeatureModel);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_CARRIER_FEATURES_ERROR, TRACFONE_SEARCH_CARRIER_FEATURES_ERROR_MESSAGE, ex);
        }
        return carrierFeaturesOrderings;
    }

    @Override
    public Map<String, Integer> mirrorServicePlanMap(TracfoneOneSearchPlanModel searchPlanModel, int userId) throws TracfoneOneException {
        Map<String, Integer> numberMap = new HashMap<>();
        LOGGER.info("mirror service plans for " + searchPlanModel);
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        // Get the carrier features and mtms associated to the service plan
        try {
            // TODO if it is a legacy service plan, i need to find the row in mtm that has null CF column and delete it first
            if (searchPlanModel.isLegacy()) {
                tracfoneServicePlanAction.deleteDummyCarrierFeature(searchPlanModel.getDbEnv(), searchPlanModel.getToServicePlanId(), userId);
            }

            Map<String, TFOneCarrierFeature> carrierFeatureMap = createCarrierFeatureMap(searchPlanModel);
            LOGGER.info("Carrier Features Map is ready " + carrierFeatureMap);

            // Remove all the carrier features that have been removed by the user
            List<String> removedCarrierFeatures = searchPlanModel.getRemovedCarrierFeatures();
            LOGGER.info("Carrier Features that need to be removed " + removedCarrierFeatures);
            for (String objId : removedCarrierFeatures) {
                carrierFeatureMap.remove(objId);
            }
            LOGGER.info("Carrier Features Map is READY " + carrierFeatureMap);
            numberMap.put("carrierFeatures", carrierFeatureMap.size());

            // inline edited carrier features only
            List<TracfoneOneCarrierFeature> editedCarrierFeatures = searchPlanModel.getCarrierFeatures();
            TracfoneOneCarrierFeature bulkEdits = searchPlanModel.getBulkUpdateFields();

            if (searchPlanModel.isCopyProfiles()) {
                // get the number of profiles for a service plan
                List<String> profileIds = tracfoneServicePlanAction.getMspProfileCount(searchPlanModel);
                LOGGER.info("COUNT FOR profile links " + profileIds.size());
                numberMap.put("profiles", profileIds.size());
                if (searchPlanModel.isCopyBuckets()) {
                    int bucketCount = tracfoneServicePlanAction.getMspBucketCount(TRACFONE_COUNT_BUCKETS_BY_SP, searchPlanModel, profileIds);
                    numberMap.put("buckets", bucketCount);
                }
                if (searchPlanModel.isCopyChildBuckets()) {
                    int childBucketCount = tracfoneServicePlanAction.getMspBucketCount(TRACFONE_COUNT_CHILD_BUCKETS_BY_SP, searchPlanModel, profileIds);
                    numberMap.put("childBuckets", childBucketCount);
                }

                executorService.execute(() -> {
                    TracfoneOneCarrierFeature carrierFeatureForCopy;
                    for (TFOneCarrierFeature carrierFeatureFromDb : carrierFeatureMap.values()) {
                        carrierFeatureForCopy = copyCarrierFeature(carrierFeatureFromDb, searchPlanModel.getToServicePlanId());
                        updateBulkUpdateColumns(carrierFeatureForCopy, bulkEdits);
                        TracfoneOneCarrierFeature editedCarrierFeature = null;
                        for (TracfoneOneCarrierFeature inlineEditedFeature : editedCarrierFeatures) {
                            if (inlineEditedFeature.getObjId().equalsIgnoreCase(carrierFeatureFromDb.getObjId())) {
                                editedCarrierFeature = inlineEditedFeature;
                                updateBulkUpdateColumns(carrierFeatureForCopy, inlineEditedFeature);
                            }
                        }
                        try {
                            // if buckets and child buckets need to be copied get those also
                            carrierFeatureForCopy.setRatePlanExtensionLinks(copyProfilesAndBuckets(carrierFeatureFromDb, searchPlanModel, editedCarrierFeature));
                            carrierFeatureForCopy.setDbEnv(searchPlanModel.getDbEnv());
                            carrierFeatureForCopy.setObjId(null);
                            carrierFeatureForCopy.setLegacy(searchPlanModel.isLegacy());
                            LOGGER.info(Thread.currentThread().getName() + " Carrier Feature - COPIED THE profiles and buckets " + carrierFeatureForCopy);
                            tracfoneRatePlanAction.insertRatePlanAssociation(carrierFeatureForCopy, userId);
                        } catch (Exception e) {
                            LOGGER.error(Thread.currentThread().getName() + EXCEPTION, e);
                        }
                    }
                });
            } else {
                executorService.execute(() -> {
                    // Insert Carrier Features only
                    TracfoneOneRatePlan tfRatePlan = new TracfoneOneRatePlan();
                    tfRatePlan.setDbEnv(searchPlanModel.getDbEnv());
                    // loop through the carrier feature map and convert all the TFOneCarrierFeature objects to TracfoneOneCarrierFeature
                    // update all the bulk edit fields
                    // check if there are any inline edits needed
                    tfRatePlan.setCarrierFeatures(createCarrierFeaturesForCopy(carrierFeatureMap, bulkEdits, editedCarrierFeatures, searchPlanModel.getToServicePlanId(), searchPlanModel.isLegacy()));
                    LOGGER.info(Thread.currentThread().getName() + " Carrier Features - All getting inserted " + tfRatePlan);
                    try {
                        tracfoneRatePlanAction.insertCarrierFeatures(tfRatePlan, searchPlanModel.getCarrierName(), userId);
                    } catch (TracfoneOneException e) {
                        LOGGER.error(Thread.currentThread().getName() + EXCEPTION + e);
                    }
                    LOGGER.info(Thread.currentThread().getName() + " Carrier Features - All getting inserted DONE ");
                });
            }
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_MIRROR_SERVICE_PLAN_ERROR, TRACFONE_MIRROR_SERVICE_PLAN_ERROR_MESSAGE, ex);
        } finally {
            executorService.shutdown();
        }
        LOGGER.info(NUMBER_MAP_IS + numberMap);
        return numberMap;
    }

    private List<TracfoneOneCarrierFeature> createCarrierFeaturesForCopy(Map<String, TFOneCarrierFeature> carrierFeatureMap, TracfoneOneCarrierFeature bulkEdits, List<TracfoneOneCarrierFeature> editedCarrierFeatures, String toServicePlanId, boolean legacy) {
        List<TracfoneOneCarrierFeature> carrierFeaturesForCopy = new ArrayList<>();
        TracfoneOneCarrierFeature carrierFeatureForCopy;
        for (TFOneCarrierFeature carrierFeatureFromDb : carrierFeatureMap.values()) {
            carrierFeatureForCopy = copyCarrierFeature(carrierFeatureFromDb, toServicePlanId);
            updateBulkUpdateColumns(carrierFeatureForCopy, bulkEdits);
            for (TracfoneOneCarrierFeature inlineEditedFeature : editedCarrierFeatures) {
                if (inlineEditedFeature.getObjId().equalsIgnoreCase(carrierFeatureFromDb.getObjId())) {
                    updateBulkUpdateColumns(carrierFeatureForCopy, inlineEditedFeature);
                }
            }
        }
        return carrierFeaturesForCopy;
    }

    private void updateBulkUpdateColumns(TracfoneOneCarrierFeature carrierFeatureForInsert, TracfoneOneCarrierFeature bulkUpdateFields) {
        if (bulkUpdateFields.getxTechnology() != null) {
            carrierFeatureForInsert.setxTechnology(bulkUpdateFields.getxTechnology());
        }
        if (bulkUpdateFields.getCreateMformIgFlag() != null) {
            carrierFeatureForInsert.setCreateMformIgFlag(bulkUpdateFields.getCreateMformIgFlag());
        }
        if (bulkUpdateFields.getDataSaver() != null) {
            carrierFeatureForInsert.setDataSaver(bulkUpdateFields.getDataSaver());
        }
        if (bulkUpdateFields.getDataSaverCode() != null) {
            carrierFeatureForInsert.setDataSaverCode(bulkUpdateFields.getDataSaverCode());
        }
        if (bulkUpdateFields.getDev() != null) {
            carrierFeatureForInsert.setDev(bulkUpdateFields.getDev());
        }
        if (bulkUpdateFields.getTmoNextGenFlag() != null) {
            carrierFeatureForInsert.setTmoNextGenFlag(bulkUpdateFields.getTmoNextGenFlag());
        }
        if (bulkUpdateFields.getUseCfExtensionFlag() != null) {
            carrierFeatureForInsert.setUseCfExtensionFlag(bulkUpdateFields.getUseCfExtensionFlag());
        }
        if (bulkUpdateFields.getUseRpExtensionFlag() != null) {
            carrierFeatureForInsert.setUseRpExtensionFlag(bulkUpdateFields.getUseRpExtensionFlag());
        }
        if (bulkUpdateFields.getxCallerId() != null) {
            carrierFeatureForInsert.setxCallerId(bulkUpdateFields.getxCallerId());
        }
        if (bulkUpdateFields.getxCallWaiting() != null) {
            carrierFeatureForInsert.setxCallWaiting(bulkUpdateFields.getxCallWaiting());
        }
        if (bulkUpdateFields.getxCwCode() != null) {
            carrierFeatureForInsert.setxCwCode(bulkUpdateFields.getxCwCode());
        }
        if (bulkUpdateFields.getxCwPackage() != null) {
            carrierFeatureForInsert.setxCwPackage(bulkUpdateFields.getxCwPackage());
        }
        if (bulkUpdateFields.getxData() != null) {
            carrierFeatureForInsert.setxData(bulkUpdateFields.getxData());
        }
        if (bulkUpdateFields.getxDigFeature() != null) {
            carrierFeatureForInsert.setxDigFeature(bulkUpdateFields.getxDigFeature());
        }
        if (bulkUpdateFields.getxDigitalFeature() != null) {
            carrierFeatureForInsert.setxDigitalFeature(bulkUpdateFields.getxDigitalFeature());
        }
        if (bulkUpdateFields.getxFeature2xCarrier() != null) {
            carrierFeatureForInsert.setxFeature2xCarrier(bulkUpdateFields.getxFeature2xCarrier());
        }
        if (bulkUpdateFields.getxFeatures2BusOrg() != null) {
            carrierFeatureForInsert.setxFeatures2BusOrg(bulkUpdateFields.getxFeatures2BusOrg());
        }
        if (bulkUpdateFields.getxIdCode() != null) {
            carrierFeatureForInsert.setxIdCode(bulkUpdateFields.getxIdCode());
        }
        if (bulkUpdateFields.getxIdPackage() != null) {
            carrierFeatureForInsert.setxIdPackage(bulkUpdateFields.getxIdPackage());
        }
        if (bulkUpdateFields.getxIsSwbCarrier() != null) {
            carrierFeatureForInsert.setxIsSwbCarrier(bulkUpdateFields.getxIsSwbCarrier());
        }
        if (bulkUpdateFields.getxMpn() != null) {
            carrierFeatureForInsert.setxMpn(bulkUpdateFields.getxMpn());
        }
        if (bulkUpdateFields.getxMpnCode() != null) {
            carrierFeatureForInsert.setxMpnCode(bulkUpdateFields.getxMpnCode());
        }
        if (bulkUpdateFields.getxPoolName() != null) {
            carrierFeatureForInsert.setxPoolName(bulkUpdateFields.getxPoolName());
        }
        if (bulkUpdateFields.getxRatePlan() != null) {
            carrierFeatureForInsert.setxRatePlan(bulkUpdateFields.getxRatePlan());
        }
        if (bulkUpdateFields.getxRestrictedUse() != null) {
            carrierFeatureForInsert.setxRestrictedUse(bulkUpdateFields.getxRestrictedUse());
        }
        if (bulkUpdateFields.getxSms() != null) {
            carrierFeatureForInsert.setxSms(bulkUpdateFields.getxSms());
        }
        if (bulkUpdateFields.getxSmscNumber() != null) {
            carrierFeatureForInsert.setxSmscNumber(bulkUpdateFields.getxSmscNumber());
        }
        if (bulkUpdateFields.getxSmsCode() != null) {
            carrierFeatureForInsert.setxSmsCode(bulkUpdateFields.getxSmsCode());
        }
        if (bulkUpdateFields.getxSmsPackage() != null) {
            carrierFeatureForInsert.setxSmsPackage(bulkUpdateFields.getxSmsPackage());
        }
        if (bulkUpdateFields.getxSwitchBaseRate() != null) {
            carrierFeatureForInsert.setxSwitchBaseRate(bulkUpdateFields.getxSwitchBaseRate());
        }
        if (bulkUpdateFields.getxVmCode() != null) {
            carrierFeatureForInsert.setxVmCode(bulkUpdateFields.getxVmCode());
        }
        if (bulkUpdateFields.getxVmPackage() != null) {
            carrierFeatureForInsert.setxVmPackage(bulkUpdateFields.getxVmPackage());
        }
        if (bulkUpdateFields.getxVoicemail() != null) {
            carrierFeatureForInsert.setxVoicemail(bulkUpdateFields.getxVoicemail());
        }
        if (bulkUpdateFields.getServicePlanCarrierFeature() != null && bulkUpdateFields.getServicePlanCarrierFeature().getPriority() != null) {
            carrierFeatureForInsert.getServicePlanCarrierFeature().setPriority(bulkUpdateFields.getServicePlanCarrierFeature().getPriority());
        }
    }

    private Map<String, TFOneCarrierFeature> createCarrierFeatureMap(TracfoneOneSearchPlanModel tfSearchModel) throws TracfoneOneException {
        TracfoneOneSearchCarrierFeatureModel tracfoneOneSearchCFModel = new TracfoneOneSearchCarrierFeatureModel();
        tracfoneOneSearchCFModel.setDbEnv(tfSearchModel.getDbEnv());
        tracfoneOneSearchCFModel.setCarrierName(tfSearchModel.getCarrierName());
        tracfoneOneSearchCFModel.setServicePlanId(tfSearchModel.getServicePlanId());
        tracfoneOneSearchCFModel.setLegacy(tfSearchModel.isLegacy());
        List<TFOneCarrierFeature> carrierFeatures = tracfoneRatePlanAction.searchCarrierFeatures(tracfoneOneSearchCFModel);
        LOGGER.info("Carrier Features on the From Service Plan " + carrierFeatures);
        return createNewCFMapping(carrierFeatures);
    }

    private List<TracfoneOneRatePlanExtensionLink> copyProfilesAndBuckets(TracfoneOneCarrierFeature carrierFeature, TracfoneOneSearchPlanModel tfSearchModel) throws TracfoneOneException {
        List<TracfoneOneRatePlanExtensionLink> links = new ArrayList<>();

        TracfoneOneCarrierFeature tracfoneOneCarrierFeature = new TracfoneOneCarrierFeature();
        tracfoneOneCarrierFeature.setDbEnv(tfSearchModel.getDbEnv());
        tracfoneOneCarrierFeature.setObjId(carrierFeature.getObjId());
        List<TracfoneOneCarrierFeature> carrierFeatures = new ArrayList<>();
        carrierFeatures.add(tracfoneOneCarrierFeature);
        List<TFOneCarrierFeature> carrierFeatureLinks = tracfoneRatePlanAction.getCarrierFeatureLinks(carrierFeatures);
        LOGGER.info(Thread.currentThread().getName() + " RP Extension Links found from DB " + carrierFeatureLinks);
        if (!carrierFeatureLinks.isEmpty()) {
            Map<String, TFOneRatePlanExtensionLink> linksMap = createNewLinksMapping(carrierFeatureLinks.get(0).getRpExtensionLinks());
            List<TracfoneOneRatePlanExtensionLink> profiles = carrierFeature.getRatePlanExtensionLinks();
            LOGGER.info(Thread.currentThread().getName() + " RP Extension Links sent from UI " + profiles);

            for (TracfoneOneRatePlanExtensionLink profile : profiles) {
                LOGGER.info(Thread.currentThread().getName() + " RP Extension Link from UI " + profile);
                if (!profile.isEdited()) {
                    TFOneRatePlanExtensionLink dbProfile = linksMap.get(profile.getObjId());
                    profile.setChildPlanId(dbProfile.getChildPlanId());
                    profile.setProfileId(dbProfile.getProfileId());
                    profile.setRatePlanExtensionId(dbProfile.getRatePlanExtensionId());
                    LOGGER.info(Thread.currentThread().getName() + " RP Extension Link found from DB " + profile);
                }

                TracfoneOneSearchBucketModel searchBucketModel = new TracfoneOneSearchBucketModel();
                searchBucketModel.setDbEnv(tfSearchModel.getDbEnv());
                searchBucketModel.getProfileIds().add(profile.getProfileId());
                searchBucketModel.getServicePlanIds().add(tfSearchModel.getServicePlanId());
                if (tfSearchModel.isCopyBuckets()) {
                    List<TFOneCarrierProfileBucket> buckets = tracfoneBucketAction.searchCarrierProfileBuckets(searchBucketModel);
                    LOGGER.info(Thread.currentThread().getName() + " Buckets found from DB " + buckets);
                    Map<String, TFOneCarrierProfileBucket> bucketsMap = createNewBucketMapping(buckets);
                    profile.setTracfoneOneCarrierProfileBuckets(copyBuckets(profile.getTracfoneOneCarrierProfileBuckets(),
                            bucketsMap, tfSearchModel.getToServicePlanId()));
                }
                if (tfSearchModel.isCopyChildBuckets()) {
                    searchBucketModel.setChildPlanId(profile.getChildPlanId());
                    List<TFOneCarrierProfileChildBucket> childBuckets = tracfoneBucketAction.searchCarrierProfileChildBuckets(searchBucketModel);
                    LOGGER.info(Thread.currentThread().getName() + " Child Buckets found from DB " + childBuckets);
                    Map<String, TFOneCarrierProfileChildBucket> childBucketsMap = createNewChildBucketMapping(childBuckets);
                    profile.setTracfoneOneCarrierProfileChildBuckets(copyChildBuckets(profile.getTracfoneOneCarrierProfileChildBuckets(),
                            childBucketsMap, tfSearchModel.getToServicePlanId()));
                }
                links.add(profile);
            }
        }
        LOGGER.info(Thread.currentThread().getName() + " RP Extension Links and buckets that should be added " + links);
        return links;
    }

    private List<TracfoneOneRatePlanExtensionLink> copyProfilesAndBuckets(TFOneCarrierFeature carrierFeature, TracfoneOneSearchPlanModel tfSearchModel, TracfoneOneCarrierFeature editedCarrierFeature) throws TracfoneOneException {
        List<TracfoneOneRatePlanExtensionLink> linksForCopy = new ArrayList<>();

        TracfoneOneCarrierFeature tracfoneOneCarrierFeature = new TracfoneOneCarrierFeature();
        tracfoneOneCarrierFeature.setDbEnv(tfSearchModel.getDbEnv());
        tracfoneOneCarrierFeature.setObjId(carrierFeature.getObjId());
        List<TracfoneOneCarrierFeature> carrierFeatures = new ArrayList<>();
        carrierFeatures.add(tracfoneOneCarrierFeature);
        List<TFOneCarrierFeature> carrierFeatureLinks = tracfoneRatePlanAction.getCarrierFeatureLinks(carrierFeatures);

        LOGGER.info(Thread.currentThread().getName() + " RP Extension Links found from DB " + carrierFeatureLinks);
        if (!carrierFeatureLinks.isEmpty()) {
            Map<String, TFOneRatePlanExtensionLink> linksMap = createNewLinksMapping(carrierFeatureLinks.get(0).getRpExtensionLinks());
            // Remove all the links that have been removed by the user
            List<String> removedLinks = tfSearchModel.getRemovedLinks();
            LOGGER.info("Links that need to be removed " + removedLinks);
            for (String objId : removedLinks) {
                linksMap.remove(objId);
            }

            List<TracfoneOneRatePlanExtensionLink> editedLinks = new ArrayList<>();
            if (null != editedCarrierFeature && !editedCarrierFeature.getRatePlanExtensionLinks().isEmpty()) {
                editedLinks = editedCarrierFeature.getRatePlanExtensionLinks();
            }

            TracfoneOneRatePlanExtensionLink linkForCopy;
            for (TFOneRatePlanExtensionLink linkFromDb : linksMap.values()) {
                linkForCopy = new TracfoneOneRatePlanExtensionLink();
                linkForCopy.setRatePlanExtensionId(linkFromDb.getRatePlanExtensionId());
                linkForCopy.setProfileId(linkFromDb.getProfileId());
                linkForCopy.setChildPlanId(linkFromDb.getChildPlanId());
                // adding the inline edits, if any
                TracfoneOneRatePlanExtensionLink editedLink = null;
                for (TracfoneOneRatePlanExtensionLink inlineEditedLink : editedLinks) {
                    if (inlineEditedLink.getObjId().equalsIgnoreCase(linkFromDb.getObjId())) {
                        editedLink = inlineEditedLink;
                        if (!StringUtils.isNullOrEmpty(inlineEditedLink.getProfileId())) {
                            linkForCopy.setProfileId(inlineEditedLink.getProfileId());
                        }
                        if (!StringUtils.isNullOrEmpty(inlineEditedLink.getRatePlanExtensionId())) {
                            linkForCopy.setRatePlanExtensionId(inlineEditedLink.getRatePlanExtensionId());
                        }
                        if (!StringUtils.isNullOrEmpty(inlineEditedLink.getChildPlanId())) {
                            linkForCopy.setChildPlanId(inlineEditedLink.getChildPlanId());
                        }
                        break;
                    }
                }

                TracfoneOneSearchBucketModel searchBucketModel = new TracfoneOneSearchBucketModel();
                searchBucketModel.setDbEnv(tfSearchModel.getDbEnv());
                searchBucketModel.getProfileIds().add(linkForCopy.getProfileId());
                searchBucketModel.getServicePlanIds().add(tfSearchModel.getServicePlanId());
                if (tfSearchModel.isCopyBuckets()) {
                    List<TFOneCarrierProfileBucket> buckets = tracfoneBucketAction.searchCarrierProfileBuckets(searchBucketModel);
                    LOGGER.info(Thread.currentThread().getName() + " Buckets found from DB " + buckets);
                    if (!buckets.isEmpty()) {
                        linkForCopy.setTracfoneOneCarrierProfileBuckets(copyBuckets(buckets, tfSearchModel, editedLink));
                    }
                }
                if (tfSearchModel.isCopyChildBuckets()) {
                    searchBucketModel.setChildPlanId(linkForCopy.getChildPlanId());
                    List<TFOneCarrierProfileChildBucket> childBuckets = tracfoneBucketAction.searchCarrierProfileChildBuckets(searchBucketModel);
                    LOGGER.info(Thread.currentThread().getName() + " Child Buckets found from DB " + childBuckets);
                    if (!childBuckets.isEmpty()) {
                        linkForCopy.setTracfoneOneCarrierProfileChildBuckets(copyChildBuckets(childBuckets, tfSearchModel, editedLink));
                    }
                }

                linksForCopy.add(linkForCopy);
            }
        }
        LOGGER.info(Thread.currentThread().getName() + " RP Extension Links and buckets that should be added " + linksForCopy);
        return linksForCopy;
    }

    private List<TracfoneOneCarrierProfileChildBucket> copyChildBuckets(List<TFOneCarrierProfileChildBucket> dbChildBuckets, TracfoneOneSearchPlanModel searchPlanModel, TracfoneOneRatePlanExtensionLink editedLink) {
        List<TracfoneOneCarrierProfileChildBucket> bucketsForCopy = new ArrayList<>();
        LOGGER.info("CHILD editedLink is " + editedLink);
        for (TFOneCarrierProfileChildBucket bucketFromDb : dbChildBuckets) {
            TracfoneOneCarrierProfileChildBucket bucketForCopy = null;
            boolean isRemoved = false;
            for (String removedId : searchPlanModel.getRemovedChildBuckets()) {
                if (removedId.equalsIgnoreCase(bucketFromDb.getObjId())) {
                    isRemoved = true;
                    break;
                }
            }
            LOGGER.info("Is removed? " + isRemoved);
            if (isRemoved) {
                continue;
            }
            if (editedLink != null) {
                List<TracfoneOneCarrierProfileChildBucket> editedBuckets = editedLink.getTracfoneOneCarrierProfileChildBuckets();
                for (TracfoneOneCarrierProfileChildBucket editedBucket : editedBuckets) {
                    if (editedBucket.getProfileId().equalsIgnoreCase(bucketFromDb.getProfileId()) &&
                            editedBucket.getChildPlanId().equalsIgnoreCase(bucketFromDb.getChildPlanId()) &&
                            editedBucket.getBucketId().equalsIgnoreCase(bucketFromDb.getBucketId())) {
                        bucketForCopy = editedBucket;
                        break;
                    }
                }
            }
            LOGGER.info("CHILD bucketFromDB " + bucketFromDb);
            LOGGER.info("CHILD bucketForCopy is " + bucketForCopy);
            if (bucketForCopy == null) {
                bucketForCopy = new TracfoneOneCarrierProfileChildBucket();
                copyChildBucket(bucketForCopy, bucketFromDb, searchPlanModel.getToServicePlanId());
                LOGGER.info("CHILD bucketForCopy after copy is " + bucketForCopy);
                if (!bucketFromDb.getTfOneCarrierProfileChildTiers().isEmpty()) {
                    for (TFOneCarrierProfileChildTier dbTier : bucketFromDb.getTfOneCarrierProfileChildTiers()) {
                        TracfoneOneCarrierProfileChildTier tier = new TracfoneOneCarrierProfileChildTier();
                        tier.setUsageTierId(dbTier.getUsageTierId());
                        tier.setTierDescription(dbTier.getTierDescription());
                        tier.setTierValue(dbTier.getTierValue());
                        tier.setTierBehavior(dbTier.getTierBehavior());
                        bucketForCopy.getTracfoneOneCarrierProfileChildTiers().add(tier);
                    }
                }
            }
            bucketsForCopy.add(bucketForCopy);
        }
        LOGGER.info("CHILD bucketSSSSSForCopy is " + bucketsForCopy);
        return bucketsForCopy;
    }

    private List<TracfoneOneCarrierProfileChildBucket> copyChildBuckets(List<TracfoneOneCarrierProfileChildBucket> childBuckets, Map<String, TFOneCarrierProfileChildBucket> bucketsMap, String toServicePlanId) {
        List<TracfoneOneCarrierProfileChildBucket> bucketsToCopy = new ArrayList<>();
        if (childBuckets != null && !childBuckets.isEmpty()) {
            for (TracfoneOneCarrierProfileChildBucket childBucket : childBuckets) {
                LOGGER.info(Thread.currentThread().getName() + " Child Bucket from UI " + childBucket);
                if (!childBucket.isEdited()) {
                    TFOneCarrierProfileChildBucket dbBucket = bucketsMap.get(childBucket.getObjId());
                    copyChildBucket(childBucket, dbBucket, toServicePlanId);

                    if (!childBucket.getTracfoneOneCarrierProfileChildTiers().isEmpty()) {
                        copyChildTiers(childBucket.getTracfoneOneCarrierProfileChildTiers(), dbBucket.getTfOneCarrierProfileChildTiers());
                    }
                    LOGGER.info(Thread.currentThread().getName() + " Child Bucket found from DB " + childBucket);
                } else {
                    childBucket.setServicePlanId(toServicePlanId);
                    TFOneCarrierProfileChildBucket dbBucket = bucketsMap.get(childBucket.getObjId());
                    if (!childBucket.getTracfoneOneCarrierProfileChildTiers().isEmpty()) {
                        copyChildTiers(childBucket.getTracfoneOneCarrierProfileChildTiers(), dbBucket.getTfOneCarrierProfileChildTiers());
                    }
                    LOGGER.info(Thread.currentThread().getName() + " Edited Child Bucket inside else block " + childBucket);
                }
                bucketsToCopy.add(childBucket);
            }
        } else {
            Collection<TFOneCarrierProfileChildBucket> dbBuckets = bucketsMap.values();
            for (TFOneCarrierProfileChildBucket dbBucket : dbBuckets) {
                TracfoneOneCarrierProfileChildBucket bucket = new TracfoneOneCarrierProfileChildBucket();
                copyChildBucket(bucket, dbBucket, toServicePlanId);

                if (!dbBucket.getTfOneCarrierProfileChildTiers().isEmpty()) {
                    for (TFOneCarrierProfileChildTier dbTier : dbBucket.getTfOneCarrierProfileChildTiers()) {
                        TracfoneOneCarrierProfileChildTier tier = new TracfoneOneCarrierProfileChildTier();
                        tier.setUsageTierId(dbTier.getUsageTierId());
                        tier.setTierDescription(dbTier.getTierDescription());
                        tier.setTierValue(dbTier.getTierValue());
                        tier.setTierBehavior(dbTier.getTierBehavior());
                        bucket.getTracfoneOneCarrierProfileChildTiers().add(tier);
                    }
                }
                bucketsToCopy.add(bucket);
            }
        }
        return bucketsToCopy;
    }

    private void copyChildBucket(TracfoneOneCarrierProfileChildBucket childBucket, TFOneCarrierProfileChildBucket dbBucket, String toServicePlanId) {
        childBucket.setServicePlanId(toServicePlanId);
        childBucket.setProfileId(dbBucket.getProfileId());
        childBucket.setChildPlanId(dbBucket.getChildPlanId());
        childBucket.setBucketId(dbBucket.getBucketId());
        childBucket.setActiveFlag(dbBucket.getActiveFlag());
        childBucket.setAutoRenewDay(dbBucket.getAutoRenewDay());
        childBucket.setAutoRenewFlag(dbBucket.getAutoRenewFlag());
        childBucket.setAutoRenewFrequency(dbBucket.getAutoRenewFrequency());
        childBucket.setAutoRenewValue(dbBucket.getAutoRenewValue());
        childBucket.setBenefitType(dbBucket.getBenefitType());
        childBucket.setBucketGroup(dbBucket.getBucketGroup());
        childBucket.setBucketRequirement(dbBucket.getBucketRequirement());
        childBucket.setBucketType(dbBucket.getBucketType());
        childBucket.setBucketValue(dbBucket.getBucketValue());
        childBucket.setHideUbiFlag(dbBucket.getHideUbiFlag());
        childBucket.setPriority(dbBucket.getPriority());
        childBucket.setUnitOfMeasure(dbBucket.getUnitOfMeasure());
    }

    private void copyChildTiers(List<TracfoneOneCarrierProfileChildTier> tracfoneOneCarrierProfileChildTiers, List<TFOneCarrierProfileChildTier> tfOneCarrierProfileChildTiers) {
        for (TracfoneOneCarrierProfileChildTier tier : tracfoneOneCarrierProfileChildTiers) {
            if (!tier.isEdited()) {
                for (TFOneCarrierProfileChildTier dbTier : tfOneCarrierProfileChildTiers) {
                    if (dbTier.getObjId().equals(tier.getObjId())) {
                        tier.setUsageTierId(dbTier.getUsageTierId());
                        tier.setTierDescription(dbTier.getTierDescription());
                        tier.setTierValue(dbTier.getTierValue());
                        tier.setTierBehavior(dbTier.getTierBehavior());
                        break;
                    }
                }
            }
        }
    }

    private List<TracfoneOneCarrierProfileBucket> copyBuckets(List<TracfoneOneCarrierProfileBucket> buckets, Map<String, TFOneCarrierProfileBucket> bucketsMap, String toServicePlanId) {
        List<TracfoneOneCarrierProfileBucket> bucketsToCopy = new ArrayList<>();
        if (buckets != null && !buckets.isEmpty()) {
            for (TracfoneOneCarrierProfileBucket bucket : buckets) {
                LOGGER.info(Thread.currentThread().getName() + " Bucket from UI " + bucket);
                if (!bucket.isEdited()) {
                    TFOneCarrierProfileBucket dbBucket = bucketsMap.get(bucket.getObjectId());
                    copyBucket(bucket, dbBucket, toServicePlanId);

                    if (!bucket.getTracfoneOneCarrierProfileBucketTiers().isEmpty()) {
                        copyTiers(bucket.getTracfoneOneCarrierProfileBucketTiers(), dbBucket.getTfOneCarrierProfileBucketTiers());
                    }
                    LOGGER.info(Thread.currentThread().getName() + " Bucket found from DB " + bucket);
                } else {
                    bucket.setServicePlanId(toServicePlanId);
                    TFOneCarrierProfileBucket dbBucket = bucketsMap.get(bucket.getObjectId());
                    if (!bucket.getTracfoneOneCarrierProfileBucketTiers().isEmpty()) {
                        copyTiers(bucket.getTracfoneOneCarrierProfileBucketTiers(), dbBucket.getTfOneCarrierProfileBucketTiers());
                    }
                   LOGGER.info("Edit buckets inside else block " + bucket);
                }
                bucketsToCopy.add(bucket);
            }
        } else {
            Collection<TFOneCarrierProfileBucket> dbBuckets = bucketsMap.values();
            for (TFOneCarrierProfileBucket dbBucket : dbBuckets) {
                TracfoneOneCarrierProfileBucket bucket = new TracfoneOneCarrierProfileBucket();
                copyBucket(bucket, dbBucket, toServicePlanId);

                if (!dbBucket.getTfOneCarrierProfileBucketTiers().isEmpty()) {
                    for (TFOneCarrierProfileBucketTier dbTier : dbBucket.getTfOneCarrierProfileBucketTiers()) {
                        TracfoneOneCarrierProfileBucketTier tier = new TracfoneOneCarrierProfileBucketTier();
                        tier.setUsageTierId(dbTier.getUsageTierId());
                        tier.setTierDescription(dbTier.getTierDescription());
                        tier.setTierValue(dbTier.getTierValue());
                        tier.setTierBehavior(dbTier.getTierBehavior());
                        bucket.getTracfoneOneCarrierProfileBucketTiers().add(tier);
                    }
                }
                bucketsToCopy.add(bucket);
            }
        }
        return bucketsToCopy;
    }

    private List<TracfoneOneCarrierProfileBucket> copyBuckets(List<TFOneCarrierProfileBucket> dbBuckets, TracfoneOneSearchPlanModel tfSearchModel, TracfoneOneRatePlanExtensionLink editedLink) {
        List<TracfoneOneCarrierProfileBucket> bucketsForCopy = new ArrayList<>();
        LOGGER.info("Is there an editedlink " + editedLink);
        for (TFOneCarrierProfileBucket bucketFromDb : dbBuckets) {
            TracfoneOneCarrierProfileBucket bucketForCopy = null;
            boolean isRemoved = false;
            for (String removedId : tfSearchModel.getRemovedBuckets()) {
                if (removedId.equalsIgnoreCase(bucketFromDb.getObjid())) {
                    isRemoved = true;
                    break;
                }
            }
            LOGGER.info("Is removed? " + isRemoved);
            if (isRemoved) {
                continue;
            }
            if (editedLink != null) {
                List<TracfoneOneCarrierProfileBucket> editedBuckets = editedLink.getTracfoneOneCarrierProfileBuckets();
                for (TracfoneOneCarrierProfileBucket editedBucket : editedBuckets) {
                    if (editedBucket.getProfileId().equalsIgnoreCase(bucketFromDb.getProfileId()) &&
                            editedBucket.getBucketId().equalsIgnoreCase(bucketFromDb.getBucketId())) {
                        bucketForCopy = editedBucket;
                        break;
                    }
                }
            }
            LOGGER.info("bucketFromDB " + bucketFromDb);
            LOGGER.info("bucketForCopy " + bucketForCopy);
            if (bucketForCopy == null) {
                bucketForCopy = new TracfoneOneCarrierProfileBucket();
                copyBucket(bucketForCopy, bucketFromDb, tfSearchModel.getToServicePlanId());
                LOGGER.info("bucketForCopy after copy " + bucketForCopy);
                if (!bucketFromDb.getTfOneCarrierProfileBucketTiers().isEmpty()) {
                    for (TFOneCarrierProfileBucketTier dbTier : bucketFromDb.getTfOneCarrierProfileBucketTiers()) {
                        TracfoneOneCarrierProfileBucketTier tier = new TracfoneOneCarrierProfileBucketTier();
                        tier.setUsageTierId(dbTier.getUsageTierId());
                        tier.setTierDescription(dbTier.getTierDescription());
                        tier.setTierValue(dbTier.getTierValue());
                        tier.setTierBehavior(dbTier.getTierBehavior());
                        bucketForCopy.getTracfoneOneCarrierProfileBucketTiers().add(tier);
                    }
                }
            }
            bucketsForCopy.add(bucketForCopy);
        }

        LOGGER.info("bucketSSSSSForCopy " + bucketsForCopy);
        return bucketsForCopy;
    }

    private void copyBucket(TracfoneOneCarrierProfileBucket bucket, TFOneCarrierProfileBucket dbBucket, String toServicePlanId) {
        bucket.setServicePlanId(toServicePlanId);
        bucket.setProfileId(dbBucket.getProfileId());
        bucket.setBucketId(dbBucket.getBucketId());
        bucket.setActiveFlag(dbBucket.getActiveFlag());
        bucket.setAutoRenewDay(dbBucket.getAutoRenewDay());
        bucket.setAutoRenewFlag(dbBucket.getAutoRenewFlag());
        bucket.setAutoRenewFrequency(dbBucket.getAutoRenewFrequency());
        bucket.setAutoRenewValue(dbBucket.getAutoRenewValue());
        bucket.setBenefitType(dbBucket.getBenefitType());
        bucket.setBucketGroup(dbBucket.getBucketGroup());
        bucket.setBucketRequirement(dbBucket.getBucketRequirement());
        bucket.setBucketType(dbBucket.getBucketType());
        bucket.setBucketValue(dbBucket.getBucketValue());
        bucket.setSuiDisplayType(dbBucket.getSuiDisplayType());
        bucket.setHideUbiFlag(dbBucket.getHideUbiFlag());
        bucket.setPriority(dbBucket.getPriority());
        bucket.setUnitOfMeasure(dbBucket.getUnitOfMeasure());
    }

    private void copyTiers(List<TracfoneOneCarrierProfileBucketTier> tracfoneOneCarrierProfileBucketTiers, List<TFOneCarrierProfileBucketTier> tfOneCarrierProfileBucketTiers) {
        for (TracfoneOneCarrierProfileBucketTier tier : tracfoneOneCarrierProfileBucketTiers) {
            if (!tier.isEdited()) {
                for (TFOneCarrierProfileBucketTier dbTier : tfOneCarrierProfileBucketTiers) {
                    if (dbTier.getObjId().equals(tier.getObjId())) {
                        tier.setUsageTierId(dbTier.getUsageTierId());
                        tier.setTierDescription(dbTier.getTierDescription());
                        tier.setTierValue(dbTier.getTierValue());
                        tier.setTierBehavior(dbTier.getTierBehavior());
                        break;
                    }
                }
            }
        }
    }

    private TracfoneOneCarrierFeature copyCarrierFeature(TFOneCarrierFeature carrierFeature, String servicePlanId) {
        TracfoneOneCarrierFeature tfCarrierFeature = new TracfoneOneCarrierFeature();
        //mtm sp carrier features
        TracfoneOneServicePlanCarrierFeature servicePlanCarrierFeature = new TracfoneOneServicePlanCarrierFeature();
        servicePlanCarrierFeature.setServicePlanId(servicePlanId);
        if (carrierFeature.getServicePlanCarrierFeature() != null) {
            servicePlanCarrierFeature.setPriority(carrierFeature.getServicePlanCarrierFeature().getPriority());
        }
        tfCarrierFeature.setServicePlanCarrierFeature(servicePlanCarrierFeature);
        // table x carrier features
        tfCarrierFeature.setxTechnology(carrierFeature.getxTechnology());
        tfCarrierFeature.setCreateMformIgFlag(carrierFeature.getCreateMformIgFlag());
        tfCarrierFeature.setDataSaver(carrierFeature.getDataSaver());
        tfCarrierFeature.setDataSaverCode(carrierFeature.getDataSaverCode());
        tfCarrierFeature.setDev(carrierFeature.getDev());
        tfCarrierFeature.setTmoNextGenFlag(carrierFeature.getTmoNextGenFlag());
        tfCarrierFeature.setUseCfExtensionFlag(carrierFeature.getUseCfExtensionFlag());
        tfCarrierFeature.setUseRpExtensionFlag(carrierFeature.getUseRpExtensionFlag());
        tfCarrierFeature.setxCallerId(carrierFeature.getxCallerId());
        tfCarrierFeature.setxCallWaiting(carrierFeature.getxCallWaiting());
        tfCarrierFeature.setxCwCode(carrierFeature.getxCwCode());
        tfCarrierFeature.setxCwPackage(carrierFeature.getxCwPackage());
        tfCarrierFeature.setxData(carrierFeature.getxData());
        tfCarrierFeature.setxDigFeature(carrierFeature.getxDigFeature());
        tfCarrierFeature.setxDigitalFeature(carrierFeature.getxDigitalFeature());
        tfCarrierFeature.setxFeature2xCarrier(carrierFeature.getxFeature2xCarrier());
        tfCarrierFeature.setxFeatures2BusOrg(carrierFeature.getxFeatures2BusOrg());
        tfCarrierFeature.setxIdCode(carrierFeature.getxIdCode());
        tfCarrierFeature.setxIdPackage(carrierFeature.getxIdPackage());
        tfCarrierFeature.setxIsSwbCarrier(carrierFeature.getxIsSwbCarrier());
        tfCarrierFeature.setxMpn(carrierFeature.getxMpn());
        tfCarrierFeature.setxMpnCode(carrierFeature.getxMpnCode());
        tfCarrierFeature.setxPoolName(carrierFeature.getxPoolName());
        tfCarrierFeature.setxRatePlan(carrierFeature.getxRatePlan());
        tfCarrierFeature.setxRestrictedUse(carrierFeature.getxRestrictedUse());
        tfCarrierFeature.setxSms(carrierFeature.getxSms());
        tfCarrierFeature.setxSmscNumber(carrierFeature.getxSmscNumber());
        tfCarrierFeature.setxSmsCode(carrierFeature.getxSmsCode());
        tfCarrierFeature.setxSmsPackage(carrierFeature.getxSmsPackage());
        tfCarrierFeature.setxSwitchBaseRate(carrierFeature.getxSwitchBaseRate());
        tfCarrierFeature.setxVmCode(carrierFeature.getxVmCode());
        tfCarrierFeature.setxVmPackage(carrierFeature.getxVmPackage());
        tfCarrierFeature.setxVoicemail(carrierFeature.getxVoicemail());

        return tfCarrierFeature;
    }

    private TracfoneOneSearchBucketModel getTracfoneOneSearchBucketModel(TracfoneOneSearchServicePlanModel tfServicePlanModel) {
        TracfoneOneSearchBucketModel tfOneSearchBucketModel = new TracfoneOneSearchBucketModel();
        tfOneSearchBucketModel.setDbEnv(tfServicePlanModel.getDbEnv());
        tfOneSearchBucketModel.getProfileIds().add(tfServicePlanModel.getProfileId());
        tfOneSearchBucketModel.getServicePlanIds().add(tfServicePlanModel.getServicePlanId());
        return tfOneSearchBucketModel;
    }

    private TFOneCarrierProfileChildBucket filterChildBuckets(TracfoneOneSearchServicePlanModel tfServicePlanModel, TFOneCarrierProfileChildBucket childBucket) {
        TFOneCarrierProfileChildBucket filteredBucket = null;
        // if only bucket id matches the search criteria
        if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId())) {
            if (childBucket.getBucketId().equalsIgnoreCase(tfServicePlanModel.getBucketId())) {
                // check if bucket requirement was also specified to match
                if (!StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement())) {
                    if (tfServicePlanModel.getBucketRequirement().equalsIgnoreCase(childBucket.getBucketRequirement())) {
                        filteredBucket = childBucket;
                    }
                } else {
                    filteredBucket = childBucket;
                }
            }
            // if only bucket requirement matches the search criteria
        } else if (childBucket.getBucketRequirement().equalsIgnoreCase(tfServicePlanModel.getBucketRequirement())) {
            filteredBucket = childBucket;
        }
        LOGGER.info("filtered feature for Bucket ID " + tfServicePlanModel.getBucketId() +
                " and Bucket Requirement " + tfServicePlanModel.getBucketRequirement() + " is " + filteredBucket);
        return filteredBucket;
    }

    private boolean hasBucketFilter(TracfoneOneSearchServicePlanModel tfServicePlanModel) {
        return !StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketId()) || !StringUtils.isNullOrEmpty(tfServicePlanModel.getBucketRequirement());
    }

    private boolean hasFeaturesFilter(TracfoneOneSearchServicePlanModel tfServicePlanModel) {
        return !StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureName()) || !StringUtils.isNullOrEmpty(tfServicePlanModel.getFeatureRequirement());
    }

    private boolean hasProfileFilter(TracfoneOneSearchServicePlanModel tfServicePlanModel) {
        return !StringUtils.isNullOrEmpty(tfServicePlanModel.getProfileId()) || !StringUtils.isNullOrEmpty(tfServicePlanModel.getProfileDesc());
    }
}
