/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * x_rp_ancillary_code
 * @author Pritesh Singh
 */
public class TracfoneOneAncillaryCode {
    
    private String dbEnv;
    @NotNull(message = "Ancillary Code cannot be null")
    @Size(min=1, message = "Ancillary Code cannot be null")
    @Size(max=5, message = "Ancillary Code cannot have more than 5 characters")
    private String ancillaryCode;
    @NotNull(message = "Description cannot be null")
    @Size(min=1, message = "Description cannot be null")
    @Size(max=2000, message = "Description cannot have more than 2000 characters")
    private String description;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getAncillaryCode() {
        return ancillaryCode;
    }

    public void setAncillaryCode(String ancillaryCode) {
        this.ancillaryCode = ancillaryCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "TracfoneOneAncillaryCode{" + "dbEnv=" + dbEnv + ", ancillaryCode=" + ancillaryCode + ", description=" + description + '}';
    }

}
