/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.response;

/**
 * @author Shireen Fathima
 */
public class TFOneParent {
    private String objId;
    private String xParentName;
    private String parentId;
    private String status;
    private String holdAnalogDeac;
    private String holdDigitalDeac;
    private String parent2TempQueue;
    private String noInventory;
    private String vmAccessNum;
    private String autoPortIn;
    private String autoPortOut;
    private String noMsid;
    private String otaCarrier;
    private String otaEndDate;
    private String otaPsmsAddress;
    private String otaStartDate;
    private String nextAvailable;
    private String queueName;
    private String blockPortIn;
    private String meidCarrier;
    private String otaReact;
    private String aggCarrCode;
    private String suiRuleObjId;
    private String deactSimExpDays;
    private String overrideSmsAddress;
    private String triggerId;
    private String parentShortName;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getxParentName() {
        return xParentName;
    }

    public void setxParentName(String xParentName) {
        this.xParentName = xParentName;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getHoldAnalogDeac() {
        return holdAnalogDeac;
    }

    public void setHoldAnalogDeac(String holdAnalogDeac) {
        this.holdAnalogDeac = holdAnalogDeac;
    }

    public String getHoldDigitalDeac() {
        return holdDigitalDeac;
    }

    public void setHoldDigitalDeac(String holdDigitalDeac) {
        this.holdDigitalDeac = holdDigitalDeac;
    }

    public String getParent2TempQueue() {
        return parent2TempQueue;
    }

    public void setParent2TempQueue(String parent2TempQueue) {
        this.parent2TempQueue = parent2TempQueue;
    }

    public String getNoInventory() {
        return noInventory;
    }

    public void setNoInventory(String noInventory) {
        this.noInventory = noInventory;
    }

    public String getVmAccessNum() {
        return vmAccessNum;
    }

    public void setVmAccessNum(String vmAccessNum) {
        this.vmAccessNum = vmAccessNum;
    }

    public String getAutoPortIn() {
        return autoPortIn;
    }

    public void setAutoPortIn(String autoPortIn) {
        this.autoPortIn = autoPortIn;
    }

    public String getAutoPortOut() {
        return autoPortOut;
    }

    public void setAutoPortOut(String autoPortOut) {
        this.autoPortOut = autoPortOut;
    }

    public String getNoMsid() {
        return noMsid;
    }

    public void setNoMsid(String noMsid) {
        this.noMsid = noMsid;
    }

    public String getOtaCarrier() {
        return otaCarrier;
    }

    public void setOtaCarrier(String otaCarrier) {
        this.otaCarrier = otaCarrier;
    }

    public String getOtaEndDate() {
        return otaEndDate;
    }

    public void setOtaEndDate(String otaEndDate) {
        this.otaEndDate = otaEndDate;
    }

    public String getOtaPsmsAddress() {
        return otaPsmsAddress;
    }

    public void setOtaPsmsAddress(String otaPsmsAddress) {
        this.otaPsmsAddress = otaPsmsAddress;
    }

    public String getOtaStartDate() {
        return otaStartDate;
    }

    public void setOtaStartDate(String otaStartDate) {
        this.otaStartDate = otaStartDate;
    }

    public String getNextAvailable() {
        return nextAvailable;
    }

    public void setNextAvailable(String nextAvailable) {
        this.nextAvailable = nextAvailable;
    }

    public String getQueueName() {
        return queueName;
    }

    public void setQueueName(String queueName) {
        this.queueName = queueName;
    }

    public String getBlockPortIn() {
        return blockPortIn;
    }

    public void setBlockPortIn(String blockPortIn) {
        this.blockPortIn = blockPortIn;
    }

    public String getMeidCarrier() {
        return meidCarrier;
    }

    public void setMeidCarrier(String meidCarrier) {
        this.meidCarrier = meidCarrier;
    }

    public String getOtaReact() {
        return otaReact;
    }

    public void setOtaReact(String otaReact) {
        this.otaReact = otaReact;
    }

    public String getAggCarrCode() {
        return aggCarrCode;
    }

    public void setAggCarrCode(String aggCarrCode) {
        this.aggCarrCode = aggCarrCode;
    }

    public String getSuiRuleObjId() {
        return suiRuleObjId;
    }

    public void setSuiRuleObjId(String suiRuleObjId) {
        this.suiRuleObjId = suiRuleObjId;
    }

    public String getDeactSimExpDays() {
        return deactSimExpDays;
    }

    public void setDeactSimExpDays(String deactSimExpDays) {
        this.deactSimExpDays = deactSimExpDays;
    }

    public String getOverrideSmsAddress() {
        return overrideSmsAddress;
    }

    public void setOverrideSmsAddress(String overrideSmsAddress) {
        this.overrideSmsAddress = overrideSmsAddress;
    }

    public String getTriggerId() {
        return triggerId;
    }

    public void setTriggerId(String triggerId) {
        this.triggerId = triggerId;
    }

    public String getParentShortName() {
        return parentShortName;
    }

    public void setParentShortName(String parentShortName) {
        this.parentShortName = parentShortName;
    }

    @Override
    public String toString() {
        return "TFOneParent{" +
                "objId='" + objId + '\'' +
                ", xParentName='" + xParentName + '\'' +
                ", parentId='" + parentId + '\'' +
                ", status='" + status + '\'' +
                ", holdAnalogDeac='" + holdAnalogDeac + '\'' +
                ", holdDigitalDeac='" + holdDigitalDeac + '\'' +
                ", parent2TempQueue='" + parent2TempQueue + '\'' +
                ", noInventory='" + noInventory + '\'' +
                ", vmAccessNum='" + vmAccessNum + '\'' +
                ", autoPortIn='" + autoPortIn + '\'' +
                ", autoPortOut='" + autoPortOut + '\'' +
                ", noMsid='" + noMsid + '\'' +
                ", otaCarrier='" + otaCarrier + '\'' +
                ", otaEndDate='" + otaEndDate + '\'' +
                ", otaPsmsAddress='" + otaPsmsAddress + '\'' +
                ", otaStartDate='" + otaStartDate + '\'' +
                ", nextAvailable='" + nextAvailable + '\'' +
                ", queueName='" + queueName + '\'' +
                ", blockPortIn='" + blockPortIn + '\'' +
                ", meidCarrier='" + meidCarrier + '\'' +
                ", otaReact='" + otaReact + '\'' +
                ", aggCarrCode='" + aggCarrCode + '\'' +
                ", suiRuleObjId='" + suiRuleObjId + '\'' +
                ", deactSimExpDays='" + deactSimExpDays + '\'' +
                ", overrideSmsAddress='" + overrideSmsAddress + '\'' +
                ", triggerId='" + triggerId + '\'' +
                ", parentShortName='" + parentShortName + '\'' +
                '}';
    }
}
