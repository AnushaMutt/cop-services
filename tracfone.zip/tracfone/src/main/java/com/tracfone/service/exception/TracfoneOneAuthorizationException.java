/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.exception;

/**
 *
 * @author druiz
 */
public class TracfoneOneAuthorizationException extends Exception {
    
    private String errorCode;
    private String errorMessage;

    public TracfoneOneAuthorizationException(String errorCode, String errorMessage) {

        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
    
    public String getClientErrorMessage(){
        long threadId = Thread.currentThread().getId();
        return this.getErrorCode() + "-" + threadId + " - " + this.getErrorMessage();
    }
}
