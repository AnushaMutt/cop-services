package com.tracfone.service.model.retail.response;

import java.util.ArrayList;
import java.util.List;

public class TFOneRetailTpAdminSearchResults {
    List<TFOneRetailTpNorm> tfOneRetailTpNorms;
    private String count;
    private String startIndex;
    private String endIndex;
    private String lastUpdateDate;
    private String updatedZipCount;
    private String updatedStoreCount;

    public TFOneRetailTpAdminSearchResults() {
        tfOneRetailTpNorms = new ArrayList<>();
    }

    public List<TFOneRetailTpNorm> getTfOneRetailTpNorms() {
        return tfOneRetailTpNorms;
    }

    public void setTfOneRetailTpNorms(List<TFOneRetailTpNorm> tfOneRetailTpNorms) {
        this.tfOneRetailTpNorms = tfOneRetailTpNorms;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getStartIndex() {
        return startIndex;
    }

    public void setStartIndex(String startIndex) {
        this.startIndex = startIndex;
    }

    public String getEndIndex() {
        return endIndex;
    }

    public void setEndIndex(String endIndex) {
        this.endIndex = endIndex;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getUpdatedZipCount() {
        return updatedZipCount;
    }

    public void setUpdatedZipCount(String updatedZipCount) {
        this.updatedZipCount = updatedZipCount;
    }

    public String getUpdatedStoreCount() {
        return updatedStoreCount;
    }

    public void setUpdatedStoreCount(String updatedStoreCount) {
        this.updatedStoreCount = updatedStoreCount;
    }

    @Override
    public String toString() {
        return "TFOneRetailTpAdminSearchResults{" +
                "tfOneRetailTpNorms=" + tfOneRetailTpNorms +
                ", count='" + count + '\'' +
                ", startIndex='" + startIndex + '\'' +
                ", endIndex='" + endIndex + '\'' +
                ", lastUpdateDate='" + lastUpdateDate + '\'' +
                ", updatedZipCount='" + updatedZipCount + '\'' +
                ", updatedStoreCount='" + updatedStoreCount + '\'' +
                '}';
    }
}
