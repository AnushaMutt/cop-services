package com.tracfone.service.model.response;

/**
 * @author Thejaswini
 */
public class TFOneCingularMrktInfo {
    private String mkt;
    private String npa;
    private String nxx;
    private String npanxx;
    private String rcNumber;
    private String rcName;
    private String rcState;
    private String zip;
    private String mktType;
    private String accountNum;
    private String marketCode;
    private String dealerCode;
    private String subMarketId;
    private String template;

    public String getMkt() {
        return mkt;
    }

    public void setMkt(String mkt) {
        this.mkt = mkt;
    }

    public String getNpa() {
        return npa;
    }

    public void setNpa(String npa) {
        this.npa = npa;
    }

    public String getNxx() {
        return nxx;
    }

    public void setNxx(String nxx) {
        this.nxx = nxx;
    }

    public String getNpanxx() {
        return npanxx;
    }

    public void setNpanxx(String npanxx) {
        this.npanxx = npanxx;
    }

    public String getRcNumber() {
        return rcNumber;
    }

    public void setRcNumber(String rcNumber) {
        this.rcNumber = rcNumber;
    }

    public String getRcName() {
        return rcName;
    }

    public void setRcName(String rcName) {
        this.rcName = rcName;
    }

    public String getRcState() {
        return rcState;
    }

    public void setRcState(String rcState) {
        this.rcState = rcState;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getMktType() {
        return mktType;
    }

    public void setMktType(String mktType) {
        this.mktType = mktType;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getMarketCode() {
        return marketCode;
    }

    public void setMarketCode(String marketCode) {
        this.marketCode = marketCode;
    }

    public String getDealerCode() {
        return dealerCode;
    }

    public void setDealerCode(String dealerCode) {
        this.dealerCode = dealerCode;
    }

    public String getSubMarketId() {
        return subMarketId;
    }

    public void setSubMarketId(String subMarketId) {
        this.subMarketId = subMarketId;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    @Override
    public String toString() {
        return "TFOneCingularMrktInfo{" +
                "mkt='" + mkt + '\'' +
                ", npa='" + npa + '\'' +
                ", nxx='" + nxx + '\'' +
                ", npanxx='" + npanxx + '\'' +
                ", rcNumber='" + rcNumber + '\'' +
                ", rcName='" + rcName + '\'' +
                ", rcState='" + rcState + '\'' +
                ", zip='" + zip + '\'' +
                ", mktType='" + mktType + '\'' +
                ", accountNum='" + accountNum + '\'' +
                ", marketCode='" + marketCode + '\'' +
                ", dealerCode='" + dealerCode + '\'' +
                ", subMarketId='" + subMarketId + '\'' +
                ", template='" + template + '\'' +
                '}';
    }
}
