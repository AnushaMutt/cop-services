package com.tracfone.service.model.request;

/**
 * @author Gaurav.Sharma
 */
public class TracfoneOneThrottleRework {
    private TracfoneOneThrottleTransaction searchCriteria;
    private TracfoneOneThrottleTrans reworkCriteria;
    private String chunkSize;
    private boolean isReworkRequeueAll;

    public TracfoneOneThrottleTransaction getSearchCriteria() {
        return searchCriteria;
    }

    public void setSearchCriteria(TracfoneOneThrottleTransaction searchCriteria) {
        this.searchCriteria = searchCriteria;
    }

    public TracfoneOneThrottleTrans getReworkCriteria() {
        return reworkCriteria;
    }

    public void setReworkCriteria(TracfoneOneThrottleTrans reworkCriteria) {
        this.reworkCriteria = reworkCriteria;
    }

    public String getChunkSize() {
        return chunkSize;
    }

    public void setChunkSize(String chunkSize) {
        this.chunkSize = chunkSize;
    }

    public boolean isIsReworkRequeueAll() {
        return isReworkRequeueAll;
    }

    public void setIsReworkRequeueAll(boolean isReworkRequeueAll) {
        this.isReworkRequeueAll = isReworkRequeueAll;
    }
    
    @Override
    public String toString() {
        return "TracfoneOneThrottleRework{" +
                "searchCriteria=" + searchCriteria +
                ", reworkCriteria=" + reworkCriteria +
                ", chunkSize='" + chunkSize + '\'' +
                '}';
    }
}
