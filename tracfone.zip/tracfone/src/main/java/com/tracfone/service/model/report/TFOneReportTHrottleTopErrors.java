
package com.tracfone.service.model.report;

/**
 *
 * @author druiz
 */
public class TFOneReportTHrottleTopErrors {
      
    private String xDate;
    private String parentName;
    private String transactType;
    private String newApiMessage;
    private Integer transactionNum;
    private Integer cnt;
    private Integer rnk2; 

    public String getxDate() {
        return xDate;
    }

    public void setxDate(String xDate) {
        this.xDate = xDate;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public String getTransactType() {
        return transactType;
    }

    public void setTransactType(String transactType) {
        this.transactType = transactType;
    }

    public String getNewApiMessage() {
        return newApiMessage;
    }

    public void setNewApiMessage(String newApiMessage) {
        this.newApiMessage = newApiMessage;
    }

    public Integer getTransactionNum() {
        return transactionNum;
    }

    public void setTransactionNum(Integer transactionNum) {
        this.transactionNum = transactionNum;
    }

    public Integer getCnt() {
        return cnt;
    }

    public void setCnt(Integer cnt) {
        this.cnt = cnt;
    }

    public Integer getRnk2() {
        return rnk2;
    }

    public void setRnk2(Integer rnk2) {
        this.rnk2 = rnk2;
    }
}
