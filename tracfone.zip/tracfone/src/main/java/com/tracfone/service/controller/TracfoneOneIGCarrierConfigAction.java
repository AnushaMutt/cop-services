package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfig;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfigDetails;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGCarrierConfig;
import com.tracfone.service.model.response.TFOneIGCarrierConfigDetails;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneIGCarrierConfigConstant;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author Gaurav.Sharma
 */
@Stateless
public class TracfoneOneIGCarrierConfigAction implements TracfoneOneIGCarrierConfigActionLocal, TracfoneOneIGCarrierConfigConstant, TracfoneOneConstant {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneIGCarrierConfigAction.class);

    @EJB
    private DataBaseController dbControllerEJB;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    private static final String AND = " AND ";
    private static final String COMMA = ",";
    private static final String NULL = "NULL";

    @Override
    public List<String> getCarriers(String dbEnv) throws TracfoneOneException {
        List<String> carrierData = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
                PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_CARRIER);) {
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    carrierData.add(resultSet.getString(CARRIER));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return carrierData;
    }

    @Override
    public List<TFOneIGCarrierConfig> getCarrierConfig(TracfoneOneIGCarrierConfig carrierConfig) throws TracfoneOneException {
        List<TFOneIGCarrierConfig> carrierConfigs = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(carrierConfig.getDbEnv()).getConnection();
                PreparedStatement stmt = con.prepareStatement(viewCarrierConfigStatement(TRACFONE_GET_CARRIER_CONFIG_AND_DETAILS, carrierConfig));) {
            setIGCarrierConfigStatement(stmt, carrierConfig);

            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    carrierConfigs.add(setIGCarrierConfig(resultSet));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return carrierConfigs;
    }

    private String viewCarrierConfigStatement(String query, TracfoneOneIGCarrierConfig carrierConfig) {
        StringBuilder builder = new StringBuilder(query);

        if (!StringUtils.isNullOrEmpty(carrierConfig.getCarrier())) {
            builder.append(AND).append("CC.CARRIER = ? ");
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getConfigId())) {
            builder.append(AND).append("CC.CONFIG_ID = ? ");
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getPropName())) {
            builder.append(AND).append("UPPER(CC.PROP_NAME) like ? ");
        }
        builder.append("order by cc.CONFIG_ID");
        LOGGER.info("Search Query for IG Carrier Config " + builder);
        return builder.substring(0, builder.lastIndexOf(""));
    }

    private int setIGCarrierConfigStatement(PreparedStatement stmt, TracfoneOneIGCarrierConfig carrierConfig) throws SQLException {
        int index = 1;

        if (!StringUtils.isNullOrEmpty(carrierConfig.getCarrier())) {
            stmt.setString(index++, carrierConfig.getCarrier());
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getConfigId())) {
            stmt.setString(index++, carrierConfig.getConfigId());
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getPropName())) {
            stmt.setString(index++, "%" + carrierConfig.getPropName().toUpperCase() + "%");
        }
        return index;
    }

    private TFOneIGCarrierConfig setIGCarrierConfig(ResultSet resultSet) throws SQLException {
        TFOneIGCarrierConfig carrierConfig = new TFOneIGCarrierConfig();
        carrierConfig.setCarrier(resultSet.getString(CARRIER));
        carrierConfig.setConfigId(resultSet.getString(CONFIG_ID));
        carrierConfig.setPropName(resultSet.getString(PROP_NAME));
        carrierConfig.setPropType(resultSet.getString("PROP_TYPE"));
        carrierConfig.setDescription(resultSet.getString("DESCRIPTION"));
        TFOneIGCarrierConfigDetails carrierDetails = new TFOneIGCarrierConfigDetails();
        carrierDetails.setConfigId(resultSet.getString(CONFIG_ID));
        carrierDetails.setPropKey(resultSet.getString("PROP_KEY"));
        carrierDetails.setPropValue(resultSet.getString("PROP_VALUE"));
        carrierDetails.setPropValueType(resultSet.getString("PROP_VALUE_TYPE"));
        carrierDetails.setPropValueKey(resultSet.getString("PROP_VALUE_KEY"));
        carrierDetails.setPropValueKeyType(resultSet.getString("PROP_VALUE_KEY_TYPE"));
        carrierDetails.setPropValueKeyKey(resultSet.getString("PROP_VALUE_KEY_KEY"));
        carrierDetails.setRemarks(resultSet.getString("REMARKS"));
        carrierConfig.setCarrierDetails(carrierDetails);
        LOGGER.info("TFOneIGCarrierConfig - " + carrierConfig);
        return carrierConfig;
    }

    @Override
    public TFOneGeneralResponse updateCarrierConfigDetails(TracfoneOneIGCarrierConfig carrierConfig, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(carrierConfig.getDbEnv()).getConnection();
                PreparedStatement stmt = con.prepareStatement(updateCarrierDetailsStatement(TRACFONE_UPDATE_CARRIER_CONFIG_DETAILS, carrierConfig));) {
            setUpdateIGCarrierConfigDetailsStatement(stmt, carrierConfig);
            LOGGER.error("Requested Object - {}", carrierConfig.getIgCarrierDetails());
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Intergate Carrier Details", "Update Intergate Carrier Details " + carrierConfig, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, carrierConfig.getConfigId());
    }

    private String updateCarrierDetailsStatement(String query, TracfoneOneIGCarrierConfig carrierConfig) {
        StringBuilder builder = new StringBuilder(query);

        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getPropKey())) {
            builder.append("PROP_KEY = ? ").append(COMMA);
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getPropValueType())) {
            builder.append("PROP_VALUE_TYPE = ? ").append(COMMA);
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getPropValue())) {
            builder.append("PROP_VALUE = ? ").append(COMMA);
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getPropValueKey())) {
            builder.append("PROP_VALUE_KEY = ? ").append(COMMA);
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getPropValueKeyType())) {
            builder.append("PROP_VALUE_KEY_TYPE = ? ").append(COMMA);
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getPropValueKeyKey())) {
            builder.append("PROP_VALUE_KEY_KEY = ? ").append(COMMA);
        }
        if (!NULL.equalsIgnoreCase(carrierConfig.getIgCarrierDetails().getRemarks())) {
            builder.append("REMARKS = ? ").append(COMMA);
        }
        builder = new StringBuilder(builder.substring(0, builder.lastIndexOf(COMMA)));
        builder.append(COMMA).append("UPDATE_DATE = sysdate WHERE CONFIG_ID = ?");
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getOldPropKey())) {
            builder.append(AND).append("PROP_KEY = ? ");
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getOldPropValueType())) {
            builder.append(AND).append("PROP_VALUE_TYPE = ? ");
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getOldPropValue())) {
            builder.append(AND).append("PROP_VALUE = ? ");
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getOldPropValueKey())) {
            builder.append(AND).append("PROP_VALUE_KEY = ?");
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getOldPropValueKeyType())) {
            builder.append(AND).append("PROP_VALUE_KEY_TYPE = ?");
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getOldPropValueKeyKey())) {
            builder.append(AND).append("PROP_VALUE_KEY_KEY = ?");
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getOldRemark())) {
            builder.append(AND).append("REMARKS = ?");
        }
        LOGGER.info("Update Query - {}", builder);
        return builder.toString();
    }

    private void setUpdateIGCarrierConfigDetailsStatement(PreparedStatement stmt, TracfoneOneIGCarrierConfig carrierConfig) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getPropKey())) {
            stmt.setString(index++, carrierConfig.getIgCarrierDetails().getPropKey());
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getPropValueType())) {
            stmt.setString(index++, carrierConfig.getIgCarrierDetails().getPropValueType());
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getPropValue())) {
            stmt.setString(index++, carrierConfig.getIgCarrierDetails().getPropValue());
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getPropValueKey())) {
            stmt.setString(index++, carrierConfig.getIgCarrierDetails().getPropValueKey());
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getPropValueKeyType())) {
            stmt.setString(index++, carrierConfig.getIgCarrierDetails().getPropValueKeyType());
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getPropValueKeyKey())) {
            stmt.setString(index++, carrierConfig.getIgCarrierDetails().getPropValueKeyKey());
        }
        if (!NULL.equalsIgnoreCase(carrierConfig.getIgCarrierDetails().getRemarks())) {
            stmt.setString(index++, carrierConfig.getIgCarrierDetails().getRemarks());
        }
        stmt.setString(index++, carrierConfig.getConfigId());
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getOldPropKey())) {
            stmt.setString(index++, carrierConfig.getIgCarrierDetails().getOldPropKey());
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getOldPropValueType())) {
            stmt.setString(index++, carrierConfig.getIgCarrierDetails().getOldPropValueType());
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getOldPropValue())) {
            stmt.setString(index++, carrierConfig.getIgCarrierDetails().getOldPropValue());
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getOldPropValueKey())) {
            stmt.setString(index++, carrierConfig.getIgCarrierDetails().getOldPropValueKey());
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getOldPropValueKeyType())) {
            stmt.setString(index++, carrierConfig.getIgCarrierDetails().getOldPropValueKeyType());
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getOldPropValueKeyKey())) {
            stmt.setString(index++, carrierConfig.getIgCarrierDetails().getOldPropValueKeyKey());
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getIgCarrierDetails().getOldRemark())) {
            stmt.setString(index, carrierConfig.getIgCarrierDetails().getOldRemark());
        }
    }

    @Override
    public TFOneGeneralResponse deleteCarrierConfigDetails(TracfoneOneIGCarrierConfigDetails carrierConfig, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(carrierConfig.getDbEnv()).getConnection();
                PreparedStatement stmt = con.prepareStatement(carrierConfigDetailsStatement(TRACFONE_DELETE_CARRIER_DETAILS, carrierConfig));) {
            setCarrierDetailsStatement(stmt, carrierConfig);
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Intergate Carrier Details", "Delete Intergate Carrier Details " + carrierConfig, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, carrierConfig.getConfigId());
    }

    private String carrierConfigDetailsStatement(String query, TracfoneOneIGCarrierConfigDetails carrierConfig) {
        StringBuilder builder = new StringBuilder(query);
        if (!StringUtils.isNullOrEmpty(carrierConfig.getConfigId())) {
            builder.append("CONFIG_ID = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getPropKey())) {
            builder.append("PROP_KEY = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getPropValueType())) {
            builder.append("PROP_VALUE_TYPE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getPropValue())) {
            builder.append("PROP_VALUE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getPropValueKey())) {
            builder.append("PROP_VALUE_KEY = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getPropValueKeyType())) {
            builder.append("PROP_VALUE_KEY_TYPE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getPropValueKeyKey())) {
            builder.append("PROP_VALUE_KEY_KEY = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(carrierConfig.getRemarks())) {
            builder.append("REMARKS = ?").append(AND);
        }
        builder = new StringBuilder(builder.substring(0, builder.lastIndexOf(AND)));
        LOGGER.info("Dynamic Query - {}", builder);
        return builder.toString();
    }

    private void setCarrierDetailsStatement(PreparedStatement stmt, TracfoneOneIGCarrierConfigDetails carrierDetails) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(carrierDetails.getConfigId())) {
            stmt.setString(index++, carrierDetails.getConfigId());
        }
        if (!StringUtils.isNullOrEmpty(carrierDetails.getPropKey())) {
            stmt.setString(index++, carrierDetails.getPropKey());
        }
        if (!StringUtils.isNullOrEmpty(carrierDetails.getPropValueType())) {
            stmt.setString(index++, carrierDetails.getPropValueType());
        }
        if (!StringUtils.isNullOrEmpty(carrierDetails.getPropValue())) {
            stmt.setString(index++, carrierDetails.getPropValue());
        }
        if (!StringUtils.isNullOrEmpty(carrierDetails.getPropValueKey())) {
            stmt.setString(index++, carrierDetails.getPropValueKey());
        }
        if (!StringUtils.isNullOrEmpty(carrierDetails.getPropValueKeyType())) {
            stmt.setString(index++, carrierDetails.getPropValueKeyType());
        }
        if (!StringUtils.isNullOrEmpty(carrierDetails.getPropValueKeyKey())) {
            stmt.setString(index++, carrierDetails.getPropValueKeyKey());
        }
        if (!StringUtils.isNullOrEmpty(carrierDetails.getRemarks())) {
            stmt.setString(index, carrierDetails.getRemarks());
        }
    }

    @Override
    public TFOneGeneralResponse insertCarrierConfigDetails(TracfoneOneIGCarrierConfig carrierDetails, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(carrierDetails.getDbEnv()).getConnection();
                PreparedStatement stmt = con.prepareStatement((TRACFONE_INSERT_CARRIER_CONFIG_DETAIL));) {
            int index = 1;
            stmt.setString(index++, carrierDetails.getConfigId());
            stmt.setString(index++, carrierDetails.getIgCarrierDetails().getPropKey());
            stmt.setString(index++, carrierDetails.getIgCarrierDetails().getPropValueType());
            stmt.setString(index++, carrierDetails.getIgCarrierDetails().getPropValue());
            stmt.setString(index++, carrierDetails.getIgCarrierDetails().getPropValueKey());
            stmt.setString(index++, carrierDetails.getIgCarrierDetails().getPropValueKeyType());
            stmt.setString(index++, carrierDetails.getIgCarrierDetails().getPropValueKeyKey());
            stmt.setString(index++, carrierDetails.getIgCarrierDetails().getRemarks());
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Carreier Detail", "Inserted Carrier Detail Object " + carrierDetails, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, carrierDetails.getConfigId());
    }

    @Override
    public boolean validateDuplicateCarrierConfigDetails(TracfoneOneIGCarrierConfigDetails carrierDetails) throws TracfoneOneException {
        boolean duplicateCarrierDetailExist = false;
        try (Connection con = dbControllerEJB.getDataSource(carrierDetails.getDbEnv()).getConnection();) {
            int count = 0;
            try (PreparedStatement stmt = con.prepareStatement(carrierConfigDetailsStatement(TRACFONE_DUPLICATE_CARRIER_CONFIG_DETAILS_CHECK, carrierDetails));) {
                setCarrierDetailsStatement(stmt, carrierDetails);
                try (ResultSet resultSet = stmt.executeQuery();) {
                    LOGGER.info("What am I searching for? " + carrierDetails);
                    while (resultSet.next()) {
                        count = resultSet.getInt(1);
                        LOGGER.info("Carrier Detail Found" + count);
                    }
                }
            }
            if (count > 0) {
                duplicateCarrierDetailExist = true;
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return duplicateCarrierDetailExist;
    }

    @Override
    public TFOneGeneralResponse insertCarrierConfig(TracfoneOneIGCarrierConfig carrierConfig, int userId) throws TracfoneOneException {
        String configId = "";
        try (Connection con = dbControllerEJB.getDataSource(carrierConfig.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement((TRACFONE_INSERT_CARRIER_CONFIG));
             PreparedStatement sdtmt = con.prepareStatement((TRACFONE_INSERT_CARRIER_CONFIG_DETAIL))) {
            configId = getNextSequence(con, SEQU_CARRIER_CONFIG_STMT, "CONFIGURATIONIDSEQ_SEQ");
            carrierConfig.setConfigId(configId);
            int index = 1;
            stmt.setString(index++, carrierConfig.getConfigId());
            stmt.setString(index++, carrierConfig.getCarrier());
            stmt.setString(index++, carrierConfig.getPropName());
            stmt.setString(index++, carrierConfig.getPropType());
            stmt.setString(index++, carrierConfig.getDescription());
            stmt.executeQuery();

            for (TracfoneOneIGCarrierConfigDetails details: carrierConfig.getIgCarrierDetailsArray()) {
                details.setConfigId(configId);
                    if (carrierConfig.getPropType().equals("LIST") || (carrierConfig.getPropType().equals("MAP") && details.getPropValueType().equals("LIST"))) {
                    List<String> propValues = details.getPropValues();
                    for (String propValue : propValues) {
                        details.setPropValue(propValue);
                        insertConfigDetails(details, userId);
                    }
                } else {
                    insertConfigDetails(details, userId);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Carreier Config", "Inserted Carrier Config Object " + carrierConfig, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, carrierConfig.getConfigId());
    }

    public TFOneGeneralResponse insertConfigDetails(TracfoneOneIGCarrierConfigDetails carrierDetails, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(carrierDetails.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement((TRACFONE_INSERT_CARRIER_CONFIG_DETAIL));) {
            int index = 1;
            stmt.setString(index++, carrierDetails.getConfigId());
            stmt.setString(index++, carrierDetails.getPropKey());
            stmt.setString(index++, carrierDetails.getPropValueType());
            stmt.setString(index++, carrierDetails.getPropValue());
            stmt.setString(index++, carrierDetails.getPropValueKey());
            stmt.setString(index++, carrierDetails.getPropValueKeyType());
            stmt.setString(index++, carrierDetails.getPropValueKeyKey());
            stmt.setString(index++, carrierDetails.getRemarks());
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Carreier Detail", "Inserted Carrier Detail Object " + carrierDetails, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, carrierDetails.getConfigId());
    }

    @Override
    public List<TFOneIGCarrierConfig> checkDuplicateCarrierConfig(TracfoneOneIGCarrierConfig carrierConfig) throws TracfoneOneException {
        List<TFOneIGCarrierConfig> carrierConfigs = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(carrierConfig.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DUPLICATE_CARRIER_CONFIG);) {
            int index = 1;
            stmt.setString(index++, carrierConfig.getCarrier());
            stmt.setString(index++, carrierConfig.getPropName());
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    TFOneIGCarrierConfig tfOneIGCarrierConfig = new TFOneIGCarrierConfig();
                    tfOneIGCarrierConfig.setCarrier(resultSet.getString(CARRIER));
                    tfOneIGCarrierConfig.setConfigId(resultSet.getString(CONFIG_ID));
                    tfOneIGCarrierConfig.setPropName(resultSet.getString(PROP_NAME));
                    tfOneIGCarrierConfig.setPropType(resultSet.getString("PROP_TYPE"));
                    tfOneIGCarrierConfig.setDescription(resultSet.getString("DESCRIPTION"));
                    carrierConfigs.add(tfOneIGCarrierConfig);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return carrierConfigs;
    }

    @Override
    public List<String> getPropNameForRef(TracfoneOneIGCarrierConfig carrierConfig) throws TracfoneOneException {
        List<String> carrierData = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(carrierConfig.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_PROP_NAME_FOR_REFERENCE);) {
            stmt.setString(1,carrierConfig.getCarrier());
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    carrierData.add(resultSet.getString(PROP_NAME));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return carrierData;
    }

    @Override
    public List<String> getPropNameForRefList(TracfoneOneIGCarrierConfig carrierConfig) throws TracfoneOneException {
        List<String> carrierData = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(carrierConfig.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_PROP_NAME_FOR_REFERENCE_LIST);) {
            stmt.setString(1,carrierConfig.getCarrier());
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    carrierData.add(resultSet.getString(PROP_NAME));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return carrierData;
    }

    private String getNextSequence(Connection con, String queryString, String seqId) throws SQLException {
        String sequenceId = null;
        try (PreparedStatement stmt = con.prepareStatement(queryString);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                sequenceId = resultSet.getString(seqId);
            }
        }
        return sequenceId;
    }

}
