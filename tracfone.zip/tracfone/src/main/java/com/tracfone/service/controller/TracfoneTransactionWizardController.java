/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.ejb.entity.TFTransactionArchive;
import com.tracfone.ejb.entity.session.CarrierFacadeLocal;
import com.tracfone.ejb.entity.session.TFTransactionArchiveFacadeLocal;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TFRatePlan;
import com.tracfone.service.model.request.TracfoneOneActionItemId;
import com.tracfone.service.model.request.TracfoneOneNewTransaction;
import com.tracfone.service.model.request.TracfoneOneSearchServicePlanModel;
import com.tracfone.service.model.request.TracfoneOneWizardArchive;
import com.tracfone.service.model.response.TFOneActionItemBucket;
import com.tracfone.service.model.response.TFOneActionItemBucketTier;
import com.tracfone.service.model.response.TFOneAdminActionItem;
import com.tracfone.service.model.response.TFOneCarrierChildPlan;
import com.tracfone.service.model.response.TFOneCarrierRatePlan;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneFeatures;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneRPFeatureNameList;
import com.tracfone.service.model.response.TFOneRatePlan;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import com.tracfone.service.model.response.TFOneServicePlan;
import com.tracfone.service.model.response.TFOneTransactionArchive;
import com.tracfone.service.model.response.TFTransactionCarrier;
import com.tracfone.service.model.response.TracfoneOneViewActionItems;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantInsertWizard;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import static com.tracfone.service.util.TracfoneOneConstant.BUCKET_;

/**
 * @author Srinivas Murthy Pulavarthy
 */
@Stateless
public class TracfoneTransactionWizardController implements TracfoneTransactionWizardControllerLocal {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneTransactionWizardController.class);

    @EJB
    CarrierFacadeLocal carrierFacadeEJB;

    @EJB
    TFTransactionArchiveFacadeLocal tfTransactionArchiveFacadeLocal;

    @EJB
    TracfoneControllerLocalAction tfControllerLocalActionEJB;

    @EJB
    DataBaseController dbControllerEJB;

    @EJB
    JmsController jmsController;

    @Override
    public List<TFTransactionCarrier> getCarriers(Integer userId, boolean showTemplates) throws TracfoneOneException {

        List<TFTransactionCarrier> tfTransactioncarrierList = null;

        try {
            EntityManager em = carrierFacadeEJB.getEntityManager();
            Query query = em.createNativeQuery(TracfoneOneConstantInsertWizard.AVAILABLE_CARRIERS_SQL);
            query.setParameter("param_carrierName", TracfoneOneConstantInsertWizard.AVAILABLE_CARRIERS_SQL_PARAMETER);

            tfTransactioncarrierList = new ArrayList<>();
            List<String> carriers = (List) query.getResultList();
            for (String carrier : carriers) {
                if ("VZW".equalsIgnoreCase(carrier)) {
                    if (showTemplates) {
                        for (String template : TracfoneOneConstantInsertWizard.vzwTemplates) {
                            TFTransactionCarrier tfTransactioncarrier = createCarrierTemplate(template, "VERIZON WIRELESS - ");
                            tfTransactioncarrierList.add(tfTransactioncarrier);
                        }
                    } else {
                        TFTransactionCarrier tfTransactioncarrier = createCarrierTemplate(null, TracfoneOneConstantInsertWizard.vzwTemplates.get(0));
                        tfTransactioncarrier.setTfOnecarrier("VERIZON WIRELESS");
                        tfTransactioncarrierList.add(tfTransactioncarrier);
                    }
                } else if ("ATT".equalsIgnoreCase(carrier)) {
                    if (showTemplates) {
                        for (String template : TracfoneOneConstantInsertWizard.attTemplates) {
                            TFTransactionCarrier tfTransactioncarrier = createCarrierTemplate(template, "AT&T - ");
                            tfTransactioncarrierList.add(tfTransactioncarrier);
                        }
                    } else {
                        TFTransactionCarrier tfTransactioncarrier = createCarrierTemplate(null, TracfoneOneConstantInsertWizard.attTemplates.get(0));
                        tfTransactioncarrier.setTfOnecarrier("AT&T");
                        tfTransactioncarrierList.add(tfTransactioncarrier);
                    }
                } else if ("TMO".equalsIgnoreCase(carrier)) {
                    // Always show only one value T-MOBILE
                    TFTransactionCarrier tfTransactioncarrier = createCarrierTemplate(null, TracfoneOneConstantInsertWizard.tmoTemplates.get(0));
                    tfTransactioncarrier.setTfOnecarrier("T-MOBILE");
                    tfTransactioncarrierList.add(tfTransactioncarrier);
                } else {
                    TFTransactionCarrier tfTransactioncarrier = createCarrierTemplate(null, carrier);
                    tfTransactioncarrierList.add(tfTransactioncarrier);
                }
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_CARRIER_NAMES_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_CARRIER_NAMES_ERROR_MESSAGE, ex);
        }
        return tfTransactioncarrierList;
    }

    private TFTransactionCarrier createCarrierTemplate(String template, String carrierName) {
        TFTransactionCarrier tfTransactioncarrier = new TFTransactionCarrier();
        if (StringUtils.isNullOrEmpty(template)) {
            tfTransactioncarrier.setShortName(carrierName);
            tfTransactioncarrier.setTfOnecarrier(carrierName);
        } else {
            tfTransactioncarrier.setShortName(template);
            tfTransactioncarrier.setTfOnecarrier(carrierName + template);
        }
        tfTransactioncarrier.setOrderTypes(TracfoneOneConstantInsertWizard.INSERT_WIZARD_ORDERTYPES);
        return tfTransactioncarrier;
    }

    @Override
    public TFOneCarrierRatePlan getCarrierRatePlan(Integer userId, String carrier) throws TracfoneOneException {

        if (!StringUtils.isNullOrEmpty(carrier)) {
            if (TracfoneOneConstantInsertWizard.attTemplates.contains(carrier)) {
                carrier = "ATT";
            } else if (TracfoneOneConstantInsertWizard.vzwTemplates.contains(carrier)) {
                carrier = "VZW";
            } else if (TracfoneOneConstantInsertWizard.tmoTemplates.contains(carrier)) {
                carrier = "TMO";
            }
        }

        //validate the carrier
        if (!validateCarrier(carrier)) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_INVALID_CARRIER_NAME_ERROR,
                    TracfoneOneConstantInsertWizard.TRACFONE_INVALID_CARRIER_NAME_ERROR_MESSAGE);
        }

        TFOneCarrierRatePlan tfOneCarrierRatePlan = null;
        try {
            EntityManager em = carrierFacadeEJB.getEntityManager();
//            String sqlString = carrier.equalsIgnoreCase("TMO") ? 
//                        TracfoneOneConstantInsertWizard.RATE_PLAN_PROFILES_SQL_GENESIS : 
//                        TracfoneOneConstantInsertWizard.RATE_PLAN_PROFILES_SQL;            
            Query query = em.createNativeQuery(TracfoneOneConstantInsertWizard.RATE_PLAN_PROFILES_SQL);
            query.setParameter("param_carrierName", TracfoneOneConstantInsertWizard.AVAILABLE_CARRIERS_SQL_PARAMETER);
            query.setParameter("param_featureValue", TracfoneOneConstantInsertWizard.PARAM_RATE_PLAN_SQL_PARAMETER);
            query.setParameter("param_carrier", carrier);
            tfOneCarrierRatePlan = new TFOneCarrierRatePlan();
            List<TFOneRatePlan> ratePlans = new ArrayList<>();
            List<Object[]> rawList = (List) query.getResultList();

            for (Object[] object : rawList) {
                String ratePlan = "";
                String value = "";
                if(null != object[0] && !object[0].toString().isEmpty())
                    ratePlan = (String) object[0];
                if(null != object[1] && !object[1].toString().isEmpty())
                    value = (String) object[1];

                TFOneRatePlan tfOneRatePlan = new TFOneRatePlan();
                tfOneRatePlan.setRatePlanName(ratePlan);
                tfOneRatePlan.setRatePlanProfile(getRatePlanProfiles(value));
                ratePlans.add(tfOneRatePlan);
            }
            tfOneCarrierRatePlan.setRatePlans(ratePlans);
            tfOneCarrierRatePlan.setCarrierName(carrier.toLowerCase());
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_RATE_PLAN_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_RATE_PLAN_ERROR_MESSAGE, ex);
        }
        return tfOneCarrierRatePlan;
    }

    @Override
    public TFOneCarrierChildPlan getCarrierChildPlans(Integer userId, String carrier) throws TracfoneOneException {

        if (!StringUtils.isNullOrEmpty(carrier)) {
            if (TracfoneOneConstantInsertWizard.attTemplates.contains(carrier)) {
                carrier = "ATT";
            } else if (TracfoneOneConstantInsertWizard.vzwTemplates.contains(carrier)) {
                carrier = "VZW";
            } else if (TracfoneOneConstantInsertWizard.tmoTemplates.contains(carrier)) {
                carrier = "TMO";
            }
        }

        //validate the carrier
        if (!validateCarrier(carrier)) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_INVALID_CARRIER_NAME_ERROR,
                    TracfoneOneConstantInsertWizard.TRACFONE_INVALID_CARRIER_NAME_ERROR_MESSAGE);
        }

        TFOneCarrierChildPlan tfOneCarrierChildPlan = new TFOneCarrierChildPlan();
        try {
            EntityManager em = carrierFacadeEJB.getEntityManager();
            Query query = em.createNativeQuery(TracfoneOneConstantInsertWizard.CHILD_PLAN_PROFILE_FROM_CARRIER);
            query.setParameter("param_carrier_name", carrier);

            List<Object[]> rawList = (List) query.getResultList();

            String currentChildPlanId = "";
            List<TFOneChildPlan> childPlanList = new ArrayList<>();
            TFOneChildPlan childPlan = new TFOneChildPlan();
            List<TFOneRatePlanProfile> ratePlanProfiles = new ArrayList<>();
            int count = 0;
            if(null != rawList && rawList.size() > 0){
                while (count < rawList.size()) {
                    Object[] object = rawList.get(count);
                    String childPlanId = "";
                    if(null != object[0] && !object[0].toString().isEmpty())
                        childPlanId = object[0].toString();

                    if (!childPlanId.equalsIgnoreCase(currentChildPlanId)) {
                        currentChildPlanId = childPlanId;
                        childPlan = new TFOneChildPlan();
                        ratePlanProfiles = new ArrayList<>();
                        if(null != object[0] && !object[0].toString().isEmpty())
                            childPlan.setChildPlanId(object[0].toString());
                        if(null != object[1] && !object[1].toString().isEmpty())
                            childPlan.setChildPlanName(object[1].toString());
                        childPlan.setRatePlanProfiles(ratePlanProfiles);
                        childPlanList.add(childPlan);
                    }

                    TFOneRatePlanProfile currentProfile = new TFOneRatePlanProfile();
                    if(null != object[2] && !object[3].toString().isEmpty())
                        currentProfile.setProfileId(object[2].toString());
                    if(null != object[3] && !object[3].toString().isEmpty())
                        currentProfile.setProfileDescription(object[3].toString());
                    ratePlanProfiles.add(currentProfile);

                    count++;
                }
            }

            tfOneCarrierChildPlan.setCarrierName(carrier);
            tfOneCarrierChildPlan.setChildPlans(childPlanList);

        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_CARRIER_CHILD_PLAN_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_CARRIER_CHILD_PLAN_MESSAGE, ex);
        }
        return tfOneCarrierChildPlan;
    }

    @Override
    public TFOneCarrierServicePlan getCarrierServicePlans(Integer userId, String carrier) throws TracfoneOneException {

        if (!StringUtils.isNullOrEmpty(carrier)) {
            if (TracfoneOneConstantInsertWizard.attTemplates.contains(carrier)) {
                carrier = "ATT";
            } else if (TracfoneOneConstantInsertWizard.vzwTemplates.contains(carrier)) {
                carrier = "VZW";
            } else if (TracfoneOneConstantInsertWizard.tmoTemplates.contains(carrier)) {
                carrier = "TMO";
            }
        }

        //validate the carrier
        if (!validateCarrier(carrier)) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_INVALID_CARRIER_NAME_ERROR,
                    TracfoneOneConstantInsertWizard.TRACFONE_INVALID_CARRIER_NAME_ERROR_MESSAGE);
        }

        TFOneCarrierServicePlan tfOneCarrierServicePlan = new TFOneCarrierServicePlan();
        try {
            EntityManager em = carrierFacadeEJB.getEntityManager();
            Query query = em.createNativeQuery(TracfoneOneConstantInsertWizard.CARRIER_SERVICE_PLANS);
            query.setParameter("param_carrier_name", carrier);

            List<Object[]> rawList = (List) query.getResultList();

            String currentServicePlanId = "";
            List<TFOneServicePlan> servicePlanList = new ArrayList<>();
            TFOneServicePlan servicePlan = new TFOneServicePlan();
            List<TFOneRatePlanProfile> ratePlanProfiles = new ArrayList<>();
            int count = 0;
            if(null != rawList && rawList.size() > 0){
                while (count < rawList.size()) {
                    Object[] object = rawList.get(count);
                    String servicePlanId = object[0].toString();

                    if (!servicePlanId.equalsIgnoreCase(currentServicePlanId)) {
                        currentServicePlanId = servicePlanId;
                        servicePlan = new TFOneServicePlan();
                        ratePlanProfiles = new ArrayList<>();
                        if(null != object[0] && !object[0].toString().isEmpty())
                            servicePlan.setServicePlanId(object[0].toString());
                        if(null != object[1] && !object[1].toString().isEmpty())
                            servicePlan.setServicePlanName(object[1].toString());
                        if (count > 0) {
                            servicePlan.setRatePlanProfiles(ratePlanProfiles);
                            servicePlanList.add(servicePlan);
                        }
                    }

                    TFOneRatePlanProfile currentProfile = new TFOneRatePlanProfile();
                    if(null != object[2] && !object[2].toString().isEmpty())
                        currentProfile.setProfileId(object[2].toString());
                    if(null != object[3] && !object[3].toString().isEmpty())
                        currentProfile.setProfileDescription(object[3].toString());
                    ratePlanProfiles.add(currentProfile);

                    count++;
                }  
           }

            tfOneCarrierServicePlan.setCarrierName(carrier);
            tfOneCarrierServicePlan.setServicePlans(servicePlanList);

        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_CARRIER_SERVICE_PLANS_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_CARRIER_SERVICE_PLANS_MESSAGE, ex);
        }
        return tfOneCarrierServicePlan;
    }

    @Override
    public List<TFOneServicePlan> getServicePlansForProfileId(Integer userId, String profileId) throws TracfoneOneException {
        List<TFOneServicePlan> tfOneServicePlans = new ArrayList<>();
        try {
            EntityManager em = carrierFacadeEJB.getEntityManager();
            Query query = em.createNativeQuery(TracfoneOneConstantInsertWizard.SERVICE_PLANS_FOR_PROFILE_ID);
            query.setParameter("param_profile_id", profileId);

            List<Object[]> rawList = (List) query.getResultList();
            for (Object[] result : rawList) {
                TFOneServicePlan servicePlan = new TFOneServicePlan();
                servicePlan.setServicePlanId(result[0].toString());
                servicePlan.setCustomerPrice(result[1].toString());
                servicePlan.setServicePlanName(result[2].toString());
                tfOneServicePlans.add(servicePlan);
            }

        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_PROFILE_ID_SERVICE_PLANS_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_PROFILE_ID_SERVICE_PLANS_MESSAGE, ex);
        }
        return tfOneServicePlans;
    }

    @Override
    public HashMap<String, String> getMatchingFeaturesNames(String featureValuesString) throws TracfoneOneException {

        HashMap<String, String> featuresHash = null;
        try {
            EntityManager em = carrierFacadeEJB.getEntityManager();
            featuresHash = new HashMap<>();
            //Srinivas: THis is a hack until JPA comes with a suitable method to pass the String for IN clause to support, nonsense forget it !!!!!
            String sql = TracfoneOneConstantInsertWizard.GET_CARRIER_FEATURES_VALUES + featureValuesString + TracfoneOneConstantInsertWizard.GET_CARRIER_FEATURES_VALUES_2;
            Query query = em.createNativeQuery(sql);
            List<Object[]> rawList = (List) query.getResultList();
            for (Object[] object : rawList) {
                featuresHash.put((String) object[0], (String) object[1]);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_FEATURES_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_FEATURES_ERROR_MESSAGE, ex);
        }

        return featuresHash;
    }

    /**
     * This method is used to retrieve the default profile for a rate plan.
     *
     * @param userId
     * @param ratePlanName
     * @return
     * @throws TracfoneOneException
     */
    @Override
    public TFOneCarrierRatePlan getCarrierRatePlanDefaultProfile(int userId, String ratePlanName) throws TracfoneOneException {
        TFOneCarrierRatePlan tfOneCarrierRatePlan = new TFOneCarrierRatePlan();
        tfOneCarrierRatePlan.setRatePlans(new ArrayList<>());
        TFOneRatePlan tfOneRatePlan = new TFOneRatePlan();
        tfOneRatePlan.setRatePlanName(ratePlanName);
        tfOneCarrierRatePlan.getRatePlans().add(tfOneRatePlan);
        LOGGER.info("ratePlanName " + ratePlanName);
        try {
            EntityManager em = carrierFacadeEJB.getEntityManager();
            Query query = em.createNativeQuery(TracfoneOneConstantInsertWizard.RATE_PLAN_DEFAULT_PROFILE_SQL);
            query.setParameter("param_default_profile", ratePlanName + " DEFAULT%");

            List<Object[]> rawList = (List) query.getResultList();
            LOGGER.info("results here " + rawList);
            if (!rawList.isEmpty()) {
                Object[] object = rawList.get(0);
                TFOneRatePlanProfile tfOneRatePlanProfile = new TFOneRatePlanProfile();
                BigDecimal profileId = (BigDecimal) object[0];
                tfOneRatePlanProfile.setProfileId(profileId.toString());
                tfOneRatePlanProfile.setProfileDescription(object[1].toString());
                LOGGER.info("TFOneRatePlanProfile " + tfOneRatePlanProfile);
                tfOneRatePlan.getRatePlanProfile().add(tfOneRatePlanProfile);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_RATE_PLAN_DEFAULT_PROFILE_ERROR,
                    TracfoneOneConstantInsertWizard.TRACFONE_RATE_PLAN_DEFAULT_PROFILE_ERROR_MESSAGE,
                    ex);
        }
        return tfOneCarrierRatePlan;
    }

    @Override
    public List<TFOneRatePlanProfile> getProfilesForFeature(int userId, TracfoneOneSearchServicePlanModel tracfoneOneSearchServicePlanModel) throws TracfoneOneException {
        List<TFOneRatePlanProfile> tfOneRatePlanProfiles = new ArrayList<>();
        TFOneRatePlanProfile tfOneRatePlanProfile;

        if (!StringUtils.isNullOrEmpty(tracfoneOneSearchServicePlanModel.getCarrierName())) {
            if (TracfoneOneConstantInsertWizard.attTemplates.contains(tracfoneOneSearchServicePlanModel.getCarrierName())) {
                tracfoneOneSearchServicePlanModel.setCarrierName("ATT");
            } else if (TracfoneOneConstantInsertWizard.vzwTemplates.contains(tracfoneOneSearchServicePlanModel.getCarrierName())) {
                tracfoneOneSearchServicePlanModel.setCarrierName("VZW");
            } else if (TracfoneOneConstantInsertWizard.tmoTemplates.contains(tracfoneOneSearchServicePlanModel.getCarrierName())) {
                tracfoneOneSearchServicePlanModel.setCarrierName("TMO");
            }
        }

        try {
            Query query = carrierFacadeEJB.getEntityManager().createNativeQuery(buildProfileSearchQuery(tracfoneOneSearchServicePlanModel));
            setProfileSearchQueryParams(query, tracfoneOneSearchServicePlanModel);
            List<Object[]> profiles = query.getResultList();

            if (null != profiles && !profiles.isEmpty()) {
                for (Object[] profile : profiles)  {
                    tfOneRatePlanProfile = new TFOneRatePlanProfile();
                    tfOneRatePlanProfile.setProfileId(String.valueOf(profile[0]));
                    tfOneRatePlanProfile.setProfileDescription(String.valueOf(profile[1]));
                    tfOneRatePlanProfiles.add(tfOneRatePlanProfile);
                }

            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_PROFILE_FOR_FEATURE_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_PROFILE_FOR_FEATURE_ERROR_MESSAGE, ex);
        }
        return tfOneRatePlanProfiles;
    }

    @Override
    public List<TFOneFeatures> getRatePlanByProfile(int userId, String profileid) throws TracfoneOneException {
        List<TFOneFeatures> tfOneFeatures = new ArrayList<>();
        TFOneFeatures tfOneFeature;
        try {
            List<String> ratePlans = carrierFacadeEJB.getEntityManager().getEntityManagerFactory().createEntityManager()
                    .createNativeQuery(TracfoneOneConstantInsertWizard.GET_RATEPLAN_BY_PROFILE)
                    .setParameter(1, profileid)
                    .getResultList();

            if (null != ratePlans && !ratePlans.isEmpty()) {
                for (String ratePlan : ratePlans)  {
                    tfOneFeature = new TFOneFeatures();
                    tfOneFeature.setFeatureValue(ratePlan);
                    tfOneFeatures.add(tfOneFeature);
                }
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_RATE_PLAN_FOR_PROFILE_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_RATE_PLAN_FOR_PROFILE_ERROR_MESSAGE, ex);
        }
        return tfOneFeatures;
    }

    @Override
    public List<TFOneRPFeatureNameList> getAllMasterFeatures() throws TracfoneOneException {
        List<TFOneRPFeatureNameList> tfOneRPFeatureNameLists = new ArrayList<>();
        TFOneRPFeatureNameList tfOneRPFeatureNameList;
        try {
            List<String> features = carrierFacadeEJB.getEntityManager().getEntityManagerFactory().createEntityManager()
                    .createNativeQuery(TracfoneOneConstantInsertWizard.TRACFONE_GET_ALL_MASTER_FEATURES)
                    .getResultList();
            if (null != features && !features.isEmpty()) {
                for (String featureName : features)  {
                    tfOneRPFeatureNameList = new TFOneRPFeatureNameList();
                    tfOneRPFeatureNameList.setFeatureName(featureName);
                    tfOneRPFeatureNameLists.add(tfOneRPFeatureNameList);
                }
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_MASTER_FEATURES_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_MASTER_FEATURES_ERROR_MESSAGE, ex);
        }
        return tfOneRPFeatureNameLists;
    }

    /**
     * @param rawValue
     * @return
     */
    private List<TFOneRatePlanProfile> getRatePlanProfiles(String rawValue) {
        List<TFOneRatePlanProfile> tfOneRatePlanProfiles = new ArrayList<>();
        StringTokenizer tokenizer = new StringTokenizer(rawValue, ",");

        while (tokenizer.hasMoreTokens()) {
            TFOneRatePlanProfile ratePlanProfiles = new TFOneRatePlanProfile();
            String rpProfile = (String) tokenizer.nextElement();
            ratePlanProfiles.setProfileId(rpProfile.substring(0, rpProfile.indexOf('-')));
            ratePlanProfiles.setProfileDescription(rpProfile.substring(rpProfile.indexOf('-') + 1));
            tfOneRatePlanProfiles.add(ratePlanProfiles);
        }
        return tfOneRatePlanProfiles;
    }

    @Override
    public TFOneRatePlanProfile getFeatures(Integer userId, String profileId) throws TracfoneOneException {

        //validate the profile Id
        if (!validateProfileId(profileId)) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_INVALID_CARRIER_NAME_ERROR,
                    TracfoneOneConstantInsertWizard.TRACFONE_INVALID_CARRIER_NAME_ERROR_MESSAGE);
        }

        TFOneRatePlanProfile tfOneRatePlanProfile = null;
        try {
            EntityManager em = carrierFacadeEJB.getEntityManager();
            tfOneRatePlanProfile = new TFOneRatePlanProfile();
            List<TFOneFeatures> featuresList = new ArrayList<>();
            Query query = em.createNativeQuery(TracfoneOneConstantInsertWizard.CARRIER_FEATURES_WITH_DESC_SQL);
            query.setParameter("param_profileId", profileId);
            List<Object[]> rawList = (List) query.getResultList();
            if (null != rawList && !rawList.isEmpty()) {
                tfOneRatePlanProfile.setProfileDescription((String) rawList.get(0)[8]);
                for (Object[] object : rawList) {
                    TFOneFeatures feature = new TFOneFeatures();
                    feature.setId(((java.math.BigDecimal) object[0]).longValue());
                    feature.setProfileId(((java.math.BigDecimal) object[1]).longValue());
                    feature.setRestrictSUIFlag((String) object[2]);
                    feature.setDisplaySUIFlag((String) object[3]);
                    feature.setFeatureName((String) object[4]);
                    feature.setFeatureValue((String) object[5]);
                    feature.setFeatureRequirement((String) object[6]);
                    feature.setToggleFlag((String) object[7]);
                    featuresList.add(feature);
                }

                Collections.sort(featuresList);
            }
            tfOneRatePlanProfile.setProfileId(profileId);
            tfOneRatePlanProfile.setFeatures(featuresList);
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_FEATURES_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_FEATURES_ERROR_MESSAGE, ex);
        }
        return tfOneRatePlanProfile;
    }

    @Override
    public List<TFOneActionItemBucket> getBucketsForProfileIdAndServicePlan(Integer userId, String profileId, String servicePlanId) throws TracfoneOneException {
        List<TFOneActionItemBucket> tfOneActionItemBucketsList = new ArrayList<>();
        try {
            EntityManager em = carrierFacadeEJB.getEntityManager();
            Query query = em.createNativeQuery(TracfoneOneConstantInsertWizard.BUCKETS_WITH_TIERS_FOR_PROFILE_AND_SERVICE_PLAN);
            query.setParameter("profile_id", profileId);
            query.setParameter("service_plan_id", servicePlanId);
            List<Object[]> rawList = (List) query.getResultList();
            String currentBucketId = "";
            TFOneActionItemBucket tfOneActionItemBucket = new TFOneActionItemBucket();
            List<TFOneActionItemBucketTier> bucketTiersList = new ArrayList<>();

            for (int i = 0; i < rawList.size(); i++) {
                Object[] object = rawList.get(i);
                String bucketId = object[0].toString();
                if (!bucketId.equalsIgnoreCase(currentBucketId)) {
                    currentBucketId = bucketId;
                    tfOneActionItemBucket = new TFOneActionItemBucket();
                    tfOneActionItemBucket.setBucketId(bucketId);
                    tfOneActionItemBucket.setBucketType(object[1].toString());
                    tfOneActionItemBucket.setBucketDescription(object[2].toString());
                    bucketTiersList = new ArrayList<>();
                    tfOneActionItemBucket.setBucketTiers(bucketTiersList);
                    tfOneActionItemBucketsList.add(tfOneActionItemBucket);
                }

                if (object[3] != null && object[4] != null && object[5] != null) {
                    TFOneActionItemBucketTier bucketTier = new TFOneActionItemBucketTier();
                    bucketTier.setTierValue(object[3].toString());
                    bucketTier.setTierBehavior(object[4].toString());
                    bucketTier.setUsageTierId(object[5].toString());
                    bucketTiersList.add(bucketTier);
                }
            }
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_BUCKETS_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_BUCKETS_ERROR_MESSAGE, ex);
        }
        return tfOneActionItemBucketsList;
    }

    @Override
    public List<TFOneActionItemBucket> getBuckets(Integer userId, TFRatePlan tfRatePlan) throws TracfoneOneException {

        List<TFOneActionItemBucket> tfOneActionItemBuckets = null;
        try {
            EntityManager em = carrierFacadeEJB.getEntityManager();
            Query query = em.createNativeQuery(TracfoneOneConstantInsertWizard.BUCKETS_SQL);
            tfOneActionItemBuckets = new ArrayList<>();
            query.setParameter("param_ratePlan", tfRatePlan.getRatePlan());
            List<Object[]> rawList = (List) query.getResultList();

            for (Object[] object : rawList) {
                TFOneActionItemBucket tfOneActionItemBucket = new TFOneActionItemBucket();
                tfOneActionItemBucket.setBucketId((String) object[0]);
                tfOneActionItemBucket.setBucketDescription((String) object[1]);
                tfOneActionItemBucket.setBucketType((String) object[2]);
                tfOneActionItemBuckets.add(tfOneActionItemBucket);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_BUCKETS_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_BUCKETS_ERROR_MESSAGE, ex);
        }
        return tfOneActionItemBuckets;
    }

    @Override
    public TFOneGeneralResponse insertTransaction(TracfoneOneNewTransaction tfOneNewTransaction, int userId, String userInitials) throws TracfoneOneException {

        TFOneGeneralResponse response = null;
        try {
            //get the nonsensical step of getting table x feature objID from tablex carrier features table for the selected RatePlan
            //setObjIdForRatePlan(tfOneNewTransaction);
            //tfOneNewTransaction.setRatePlanExtensionObjId(new Integer(1));
            tfOneNewTransaction.setAppSys("COP");
            tfOneNewTransaction.setStatus("COPQ");

            response = tfControllerLocalActionEJB.insertTransaction(tfOneNewTransaction, userId, userInitials, true, null);
//            TracfoneOneActionItemId tracfoneOneActionItemId = new TracfoneOneActionItemId();
//            tracfoneOneActionItemId.setActionItemId(Arrays.asList(response.getMessage()));
//            tracfoneOneActionItemId.setExactMatchForActionItemId(true);
//            tracfoneOneActionItemId.setDbenv(tfOneNewTransaction.getDbenv());
//            TracfoneOneViewActionItems tfOneViewActionItems = tfControllerLocalActionEJB.viewActionitemId(tracfoneOneActionItemId, userId);
//            
//            //GetCarrierSpecific Fields
//            Map<String, String> carrierAdditionalFields = getCarrierAdditionalFields(tfOneNewTransaction);
//            
//            //Set the Action ItemId from the above 
//            tfOneNewTransaction.setActionItemId(response.getMessage());
//            String qLink = getQueueLinkName(tfOneNewTransaction.getTemplate(), tfOneNewTransaction.getDbenv());
//            jmsController.sendJMS(transactionToXML(tfOneNewTransaction,  carrierAdditionalFields, tfOneViewActionItems),  qLink);  
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_INSERT_WIZARD_TRANSACTION_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_INSERT_WIZARD_TRANSACTION_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public List<TFOneTransactionArchive> getTransactionsInsertedByUser(Integer userId, int profileId, String dbEnv) throws TracfoneOneException {

        List<TFOneTransactionArchive> tfOneTransactionArchives = new ArrayList<TFOneTransactionArchive>();
        List<TFTransactionArchive> tfTransactionArchives = tfTransactionArchiveFacadeLocal.findAllTransactionByUserIdAndDbEnv(userId, dbEnv);

        if (tfTransactionArchives.isEmpty()) {
            return tfOneTransactionArchives;
        }

        Map<String, TFOneTransactionArchive> actionItemIDsToCheck = new HashMap<>();
        List<TFOneTransactionArchive> actionItemIDsDone = new ArrayList<>();
        List<String> ignoreStatus = Arrays.asList(new String[]{"F", "E", "S", "W", "SS", "EE"});

        for (TFTransactionArchive tfTransactionArchive : tfTransactionArchives) {
            TFOneTransactionArchive tfOneTransactionArchive = new TFOneTransactionArchive();
            tfOneTransactionArchive.setId(tfTransactionArchive.getId());
            tfOneTransactionArchive.setActionItemId(tfTransactionArchive.getActionItemId());
            tfOneTransactionArchive.setDbEnv(tfTransactionArchive.getDbEnv());
            tfOneTransactionArchive.setCreatedDate(tfTransactionArchive.getCreateddate());
            tfOneTransactionArchive.setModifiedDate(tfTransactionArchive.getModifieddate());
            tfOneTransactionArchive.setDeactivationDate(tfTransactionArchive.getDeactivationDate());
            tfOneTransactionArchive.setStatus(tfTransactionArchive.getStatus());
            //tfOneTransactionArchive.setTransactionId(tfTransactionArchive.getTransactionId());

            tfOneTransactionArchives.add(tfOneTransactionArchive);

            if (!ignoreStatus.contains(tfTransactionArchive.getStatus())) {
                actionItemIDsToCheck.put(tfTransactionArchive.getActionItemId(), tfOneTransactionArchive);
            } else {
                actionItemIDsDone.add(tfOneTransactionArchive);
            }
        }

        TracfoneOneActionItemId tracfoneOneActionItemId = new TracfoneOneActionItemId();
        List<String> actionItems = new ArrayList<String>();
        actionItems.addAll(actionItemIDsToCheck.keySet());
        tracfoneOneActionItemId.setActionItemId(actionItems);
        tracfoneOneActionItemId.setExactMatchForActionItemId(true);
        tracfoneOneActionItemId.setDbenv(dbEnv);
        TracfoneOneViewActionItems tracfoneOneViewActionItems = null;

        try {
            tracfoneOneViewActionItems = tfControllerLocalActionEJB.viewActionitemId(tracfoneOneActionItemId, profileId);
        } catch (TracfoneOneAuthorizationException ex) {
            LOGGER.error(ex);
        }

        for (TFOneAdminActionItem actionItem : tracfoneOneViewActionItems.getActionItems()) {

            if (actionItemIDsToCheck.containsKey(actionItem.getActionItemId())) {
                actionItemIDsToCheck.get(actionItem.getActionItemId()).setStatus(actionItem.getStatus());
                actionItemIDsToCheck.get(actionItem.getActionItemId()).setActionItem(actionItem);
            }
        }
        actionItemIDsDone.addAll(actionItemIDsToCheck.values());

        return actionItemIDsDone;
    }

    @Override
    public List<TFOneTransactionArchive> getAllTransactionsInserted(int profileId, String dbEnv) throws TracfoneOneException {

        List<TFOneTransactionArchive> tfOneTransactionArchives = new ArrayList<TFOneTransactionArchive>();
        List<TFTransactionArchive> tfTransactionArchives = tfTransactionArchiveFacadeLocal.findAllTransactionByDbEnv(dbEnv);

        if (tfTransactionArchives.isEmpty()) {
            return tfOneTransactionArchives;
        }

        Map<String, TFOneTransactionArchive> actionItemIDsToCheck = new HashMap<>();
        List<TFOneTransactionArchive> actionItemIDsDone = new ArrayList<>();
        List<String> ignoreStatus = Arrays.asList(new String[]{"F", "E", "S", "W", "SS", "EE"});

        for (TFTransactionArchive tfTransactionArchive : tfTransactionArchives) {
            TFOneTransactionArchive tfOneTransactionArchive = new TFOneTransactionArchive();
            tfOneTransactionArchive.setId(tfTransactionArchive.getId());
            tfOneTransactionArchive.setActionItemId(tfTransactionArchive.getActionItemId());
            tfOneTransactionArchive.setDbEnv(tfTransactionArchive.getDbEnv());
            tfOneTransactionArchive.setCreatedDate(tfTransactionArchive.getCreateddate());
            tfOneTransactionArchive.setModifiedDate(tfTransactionArchive.getModifieddate());
            tfOneTransactionArchive.setDeactivationDate(tfTransactionArchive.getDeactivationDate());
            tfOneTransactionArchive.setStatus(tfTransactionArchive.getStatus());
            //tfOneTransactionArchive.setTransactionId(tfTransactionArchive.getTransactionId());

            tfOneTransactionArchives.add(tfOneTransactionArchive);

            if (!ignoreStatus.contains(tfTransactionArchive.getStatus())) {
                actionItemIDsToCheck.put(tfTransactionArchive.getActionItemId(), tfOneTransactionArchive);
            } else {
                actionItemIDsDone.add(tfOneTransactionArchive);
            }
        }

        TracfoneOneActionItemId tracfoneOneActionItemId = new TracfoneOneActionItemId();
        List<String> actionItems = new ArrayList<String>();
        actionItems.addAll(actionItemIDsToCheck.keySet());
        tracfoneOneActionItemId.setActionItemId(actionItems);
        tracfoneOneActionItemId.setExactMatchForActionItemId(true);
        tracfoneOneActionItemId.setDbenv(dbEnv);
        TracfoneOneViewActionItems tracfoneOneViewActionItems = null;

        try {
            tracfoneOneViewActionItems = tfControllerLocalActionEJB.viewActionitemId(tracfoneOneActionItemId, profileId);
        } catch (TracfoneOneAuthorizationException ex) {
            LOGGER.error(ex);
        }

        for (TFOneAdminActionItem actionItem : tracfoneOneViewActionItems.getActionItems()) {

            if (actionItemIDsToCheck.containsKey(actionItem.getActionItemId())) {
                actionItemIDsToCheck.get(actionItem.getActionItemId()).setStatus(actionItem.getStatus());
                actionItemIDsToCheck.get(actionItem.getActionItemId()).setActionItem(actionItem);
                //actionItemIDsToCheck.get(actionItem.getActionItemId()).setStatus(actionItem.getStatusMessage());
            }
        }
        actionItemIDsDone.addAll(actionItemIDsToCheck.values());

        return actionItemIDsDone;
    }

    @Override
    public TFOneGeneralResponse extendDeactDateDefault(TracfoneOneWizardArchive request) throws TracfoneOneException {

        TFTransactionArchive transaction = tfTransactionArchiveFacadeLocal.findByAId(request.getActionItemId());
        Calendar extendDeactCal = Calendar.getInstance();

        // Set current date for modified time.
        transaction.setModifieddate(extendDeactCal.getTime());

        // Add default time to extend deactivation date.
        extendDeactCal.setTime(transaction.getDeactivationDate());
        extendDeactCal.add(Calendar.DATE, 7);
        transaction.setDeactivationDate(extendDeactCal.getTime());

        try {
            tfTransactionArchiveFacadeLocal.edit(transaction);
        } catch (Exception e) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_EXTENDDEACTDATE_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_EXTENDDEACTDATE_ERROR_MESSAGE, e);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Deactivation date updated successfully.");
    }

    @Override
    public TFOneGeneralResponse extendDeactDateManual(List<TracfoneOneWizardArchive> request) throws TracfoneOneException {
        int maxDaysAllowed = 300;

        for (TracfoneOneWizardArchive tfArchive : request) {
            TFTransactionArchive transaction = tfTransactionArchiveFacadeLocal.findByAId(tfArchive.getActionItemId());
            Calendar extendDeactCal = Calendar.getInstance();

            // Set current date for modified time.
            transaction.setModifieddate(extendDeactCal.getTime());

            // Add default time to extend deactivation date.
            extendDeactCal.setTime(transaction.getDeactivationDate());
            int daysToExtend = tfArchive.getDaysToExtend();

            if (daysToExtend > maxDaysAllowed) {
                daysToExtend = maxDaysAllowed;
            }

            extendDeactCal.add(Calendar.DATE, daysToExtend);
            transaction.setDeactivationDate(extendDeactCal.getTime());

            try {
                tfTransactionArchiveFacadeLocal.edit(transaction);
            } catch (Exception e) {
                throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_EXTENDDEACTDATE_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_EXTENDDEACTDATE_ERROR_MESSAGE, e);
            }
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Deactivation date updated successfully.");
    }

    /**
     * @param carrier
     * @return
     */
    private boolean validateCarrier(String carrier) {
        if (carrier != null && !carrier.isEmpty() && carrier.length() > 0 && carrier.matches(TracfoneOneConstantInsertWizard.CARRIER_NAME_PATTERN)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @param profileId
     * @return
     */
    private boolean validateProfileId(String profileId) {

        if (profileId != null && !profileId.isEmpty() && profileId.length() > 0 && profileId.matches(TracfoneOneConstantInsertWizard.PROFILE_ID_PATTERN)) {
            return true;
        } else {
            return false;
        }
    }


    /**
     * Converts
     *
     * @param tfOneNewTransaction
     * @return
     * @throws JSONException
     */
    private JSONObject getTransactionJsonObj(TracfoneOneNewTransaction tfOneNewTransaction, String transactionId) throws JSONException {
        JSONObject obj = new JSONObject();

        // IG Transaction Table Fields
        obj.put("APPLICATION_SYSTEM", tfOneNewTransaction.getAppSys());
        //obj.put("", tfOneNewTransaction.getRatePlanProfileId());
        obj.put("CARRIER_FEATURE_OBJID", tfOneNewTransaction.getCarrFeat());
        obj.put("TRANSACTION_ID", transactionId);
        obj.put("TEMPLATE", tfOneNewTransaction.getTemplate());
        obj.put("ACTION_ITEM_ID", tfOneNewTransaction.getActionItemId());
        obj.put("CARRIER_ID", tfOneNewTransaction.getCarrierId());
        obj.put("ORDER_TYPE", tfOneNewTransaction.getOrderType());
        obj.put("ESN", tfOneNewTransaction.getEsn());
        obj.put("ESN_HEX", tfOneNewTransaction.getEsnHex());
        obj.put("ICCID", tfOneNewTransaction.getIccid());
        obj.put("MIN", tfOneNewTransaction.getMin());
        obj.put("MSID", tfOneNewTransaction.getMsid());
        obj.put("RATE_PLAN", tfOneNewTransaction.getRatePlan());
        obj.put("NETWORK_LOGIN", tfOneNewTransaction.getNetworkLogin());
        obj.put("NETWORK_PASSWORD", tfOneNewTransaction.getNetworkPassword());
        obj.put("ACCOUNT_NUM", tfOneNewTransaction.getAccountNum());
        obj.put("DEALER_CODE", tfOneNewTransaction.getDealerCode());
        obj.put("MARKET_CODE", tfOneNewTransaction.getMarketCode());
        obj.put("COM_PORT", tfOneNewTransaction.getComPort());
        obj.put("RATE_CENTER_NO", tfOneNewTransaction.getRateCenterNo());
        obj.put("ZIP_CODE", tfOneNewTransaction.getZipCode());
        obj.put("STATUS", tfOneNewTransaction.getStatus());
        obj.put("Q_TRANSACTION", tfOneNewTransaction.getqTransaction());
        obj.put("LD_PROVIDER", tfOneNewTransaction.getLdProvider());
        obj.put("TECHNOLOGY_FLAG", tfOneNewTransaction.getTechFlag());
        obj.put("TRANSMISSION_METHOD", tfOneNewTransaction.getTransMethod());
        obj.put("BALANCE", tfOneNewTransaction.getBalance());
        obj.put("OLD_MIN", tfOneNewTransaction.getOldMin());
        obj.put("DIGITAL_FEATURE", tfOneNewTransaction.getDigitalFeature());
        obj.put("DIGITAL_FEATURE_CODE", tfOneNewTransaction.getDigitalFeatureCode());
        obj.put("VOICE_MAIL", tfOneNewTransaction.getVoiceMail());
        obj.put("VOICE_MAIL_PACKAGE", tfOneNewTransaction.getVoiceMailPackage());
        obj.put("CALLER_ID", tfOneNewTransaction.getCallerId());
        obj.put("CALLER_ID_PACKAGE", tfOneNewTransaction.getCallerIdPackage());
        obj.put("CALL_WAITING", tfOneNewTransaction.getCallWaiting());
        obj.put("CALL_WAITING_PACKAGE", tfOneNewTransaction.getCallWaitingPackage());
        obj.put("SMS", tfOneNewTransaction.getSms());
        obj.put("SMS_PACKAGE", tfOneNewTransaction.getSmsPackage());
        obj.put("X_MPN", tfOneNewTransaction.getMpn());
        obj.put("X_MPN_CODE", tfOneNewTransaction.getMpnCode());
        obj.put("X_POOL_NAME", tfOneNewTransaction.getIpPool());
        obj.put("LANGUAGE", tfOneNewTransaction.getLanguage());
        obj.put("DATA_SAVER", tfOneNewTransaction.getDataSaver());
        obj.put("DATA_SAVER_CODE", tfOneNewTransaction.getDataSaverCode());
        obj.put("PHONE_MANF", tfOneNewTransaction.getPhoneManf());
        //obj.put(ControllerUtil.getIGDColumnName(tfOneNewTransaction.getRechargeDate()), tfOneNewTransaction.getRechargeDate());
        obj.put("EXP_DATE", tfOneNewTransaction.getExpireDate());
        obj.put("DOWNLOAD_DATE", tfOneNewTransaction.getDownloadDt());
        obj.put("PRL_NUMBER", tfOneNewTransaction.getPrlNumber());
        obj.put("X_MAKE", tfOneNewTransaction.getMake());
        obj.put("X_MODEL", tfOneNewTransaction.getModel());
        obj.put("OLD_ESN ", tfOneNewTransaction.getOldEsn());
        obj.put("OLD_ESN_HEX", tfOneNewTransaction.getOldEsnHex());
        obj.put("SUBSCRIBER_UPDATE", tfOneNewTransaction.getSubscriberUpdate());
        obj.put("SYSTEM_LOGIN", tfOneNewTransaction.getSystemLogin());
        obj.put("SYSTEM_PASSWORD", tfOneNewTransaction.getSystemPassword());
        obj.put("IMSI", tfOneNewTransaction.getImsi());
        obj.put("NEW_IMSI_FLAG", tfOneNewTransaction.getNewImsiFlag());
        obj.put("PIN", tfOneNewTransaction.getPin());
        obj.put("CF_EXTENSION_COUNT", tfOneNewTransaction.getCfExtensionCount());
        obj.put("CF_PROFILE_ID", tfOneNewTransaction.getCfProfileId());
        obj.put("X_CAMPAIGN_NAME", tfOneNewTransaction.getxCampaignName());
        obj.put("AMOUNT", tfOneNewTransaction.getAmount());
        obj.put("FAX_BATCH_SIZE", tfOneNewTransaction.getFaxBatchSize());
        obj.put("FAX_NUM2", tfOneNewTransaction.getFaxNum2());
        obj.put("FAX_NUM", tfOneNewTransaction.getFaxNum());
        obj.put("FAX_BATCH_Q_TIME", tfOneNewTransaction.getFaxBatchQtime());
        obj.put("ONLINE_NUM", tfOneNewTransaction.getOnlineNum());
        obj.put("ONLINE_NUM2", tfOneNewTransaction.getOnlineNum2());
        obj.put("EMAIL", tfOneNewTransaction.getEmail());
        obj.put("SEQUENCE_NUM", tfOneNewTransaction.getSequenceNum());
        obj.put("OTA_TYPE", tfOneNewTransaction.getOtaType());
        obj.put("RTP_SERVER", tfOneNewTransaction.getRtpServer());
        obj.put("STATE_FIELD", tfOneNewTransaction.getStateField());
        obj.put("EXE_NAME", tfOneNewTransaction.getExeName());
        obj.put("EXPIDITE", tfOneNewTransaction.getExpidite());
        obj.put("BLACKOUT_WAIT", tfOneNewTransaction.getBlackoutWait());
        obj.put("TUX_ITI_SERVER", tfOneNewTransaction.getTuxItiServer());
        obj.put("TRANS_PROF_KEY", tfOneNewTransaction.getTransProfKey());
        //obj.put(ControllerUtil.getIGDColumnName(tfOneNewTransaction.getRatePlanExtensionConfig()), tfOneNewTransaction.getRatePlanExtensionConfig());
        obj.put("RP_EXT_OBJID", tfOneNewTransaction.getRatePlanExtensionObjId());
        obj.put("APPLICATION_SYSTEM_NAME", "IG");


        // IG Transaction Additional Info Table Fields.
        //obj.put(ControllerUtil.getIGDColumnName(tfOneNewTransaction.getExpDt()), tfOneNewTransaction.getExpDt());
        obj.put("FIRST_NAME", tfOneNewTransaction.getFirstName());
        obj.put("LAST_NAME", tfOneNewTransaction.getLastName());
        obj.put("MIDDLE_INITIAL", tfOneNewTransaction.getMiddleInitial());
        obj.put("SUFFIX", tfOneNewTransaction.getSuffix());
        obj.put("PREFIX", tfOneNewTransaction.getPrefix());
        obj.put("SSN_LAST_4", tfOneNewTransaction.getSsnLast4());
        obj.put("OSP_ACCOUNT", tfOneNewTransaction.getOspAccount());
        obj.put("CURR_ADDR_HOUSE_NUMBER", tfOneNewTransaction.getCurrAddrHouseNumber());
        obj.put("CURR_ADDR_DIRECTION", tfOneNewTransaction.getCurrAddrDirection());
        obj.put("CURR_ADDR_STREET_NAME", tfOneNewTransaction.getCurrAddrStreetName());
        obj.put("CURR_ADDR_STREET_TYPE", tfOneNewTransaction.getCurrAddrStreetType());
        obj.put("CURR_ADDR_UNIT", tfOneNewTransaction.getCurrAddrUnit());
        obj.put("ADDRESS_1", tfOneNewTransaction.getAddress1());
        obj.put("ADDRESS_2", tfOneNewTransaction.getAddress2());
        obj.put("CITY", tfOneNewTransaction.getCity());
        obj.put("STATE", tfOneNewTransaction.getState());
        obj.put("COUNTRY", tfOneNewTransaction.getCountry());
        obj.put("ZIP_CODE_1", tfOneNewTransaction.getZipCode1());

        // Buckets
        int bucketCounter = 0;
        int featureCounter = 0;

        for (TFOneActionItemBucket bucket : tfOneNewTransaction.getBuckets()) {
            obj.put(BUCKET_ + bucketCounter + "_ID", bucket.getBucketId());
            obj.put(BUCKET_ + bucketCounter + "_BALANCE", bucket.getBucketBalance());
            obj.put(BUCKET_ + bucketCounter + "_VALUE", bucket.getBucketValue());
            obj.put(BUCKET_ + bucketCounter + "_EXPIRATION_DATE", bucket.getExpirationDate());
            obj.put(BUCKET_ + bucketCounter + "_RECHARGE_DATE", bucket.getRechargeDate());
            obj.put(BUCKET_ + bucketCounter + "_DIRECTION", bucket.getDirection());
            obj.put(BUCKET_ + bucketCounter + "_BENEFIT_TYPE", bucket.getBenefitType());
            obj.put(BUCKET_ + bucketCounter + "_BUCKET_TYPE", bucket.getBucketType());
            bucketCounter++;
        }

        //Add the bucket count
        obj.put("REQUEST_BUCKET_COUNT", bucketCounter);

        for (TFOneFeatures feature : tfOneNewTransaction.getFeatures()) {
            obj.put("FEATURE_" + featureCounter, feature.getFeatureValue());
            obj.put("FEATURE_VALUE_" + featureCounter, feature.getFeatureRequirementFlag());
            featureCounter++;
        }
        //Add the feature count
        obj.put("NUMBER_OF_FEATURES", featureCounter);

        return obj;
    }

    private String getQueueLinkName(String template, String dbEnv) {

        String queueLink = null;
        if (template != null && dbEnv != null) {

            //TMOBILE
            if (("TMOBILE").equalsIgnoreCase(template) ||
                    ("TMOUN").equalsIgnoreCase(template) ||
                    ("TMOWFM").equalsIgnoreCase(template) ||
                    ("TMOSM").equalsIgnoreCase(template)) {
                queueLink = "tmobileQ-" + dbEnv;
            }

            //VZW
            if (("RSS").equalsIgnoreCase(template) ||
                    ("SUREPAY").equalsIgnoreCase(template)) {
                queueLink = "verizonQ-" + dbEnv;
            }

            //ATT
            if (("CSI_TLG").equalsIgnoreCase(template)) {
                queueLink = "csiQ-" + dbEnv;
            }
        }
        return queueLink;
    }


    private Map<String, String> getCarrierAdditionalFields(TracfoneOneNewTransaction tfOneNewTransaction) throws TracfoneOneException {

        String carrierTemplateName = tfOneNewTransaction.getTemplate();
        String dataSource = tfOneNewTransaction.getDbenv();
        Map<String, String> carrierAddionalFields = new HashMap<>();

        //ATT
        if (("CSI_TLG").equalsIgnoreCase(carrierTemplateName)) {
            carrierAddionalFields = getATTAdditionalFields(dataSource, tfOneNewTransaction.getZipCode());
        }
        //TMOBILE
        //VERIZON
        return carrierAddionalFields;
    }

    private Map<String, String> getATTAdditionalFields(String dataSource, String zipCode) throws TracfoneOneException {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet resultSet = null;
        Map<String, String> attFields = new HashMap<>();
        try {

            con = dbControllerEJB.getDataSource(dataSource).getConnection();
            stmt = con.prepareStatement(TracfoneOneConstant.GET_ATT_ADDITIONAL_FIELDS);
            stmt.setLong(1, Long.valueOf(zipCode));
            resultSet = stmt.executeQuery();
            while (resultSet.next()) {
                attFields.put("ACCOUNT_NUM", resultSet.getString("account_num"));
                attFields.put("MARKET_CODE", resultSet.getString("market_code"));
                attFields.put("DEALER_CODE", resultSet.getString("dealer_code"));
                attFields.put("SUBMARKET", resultSet.getString("submarketid"));
            }

        } catch (Exception e) {
            throw new TracfoneOneException(TracfoneOneConstantInsertWizard.TRACFONE_CARRIER_ADDIONAL_FIELDS_ERROR, TracfoneOneConstantInsertWizard.TRACFONE_CARRIER_ADDIONAL_FIELDS_MESSAGE, e);

        } finally {
            try {
                try {
                    if (resultSet != null) {
                        resultSet.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }
                try {
                    if (stmt != null) {
                        stmt.close();
                    }
                } catch (Exception ex) {
                    LOGGER.error(ex);
                }

            } catch (Exception ex) {
                LOGGER.error(ex);
            }
            return attFields;
        }
    }

    /**
     * @param carrierJsonObject
     * @param carrierAdditionalFields
     */
    private void addCarrierSpecificFields(JSONObject carrierJsonObject, Map<String, String> carrierAdditionalFields) throws JSONException {

        //Add carrierSpecific fields
        for (Map.Entry<String, String> entry : carrierAdditionalFields.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            carrierJsonObject.put(key, value);
        }

    }

    private void setProfileSearchQueryParams(Query query, TracfoneOneSearchServicePlanModel tracfoneOneSearchServicePlanModel) {
        int index = 1;
        query.setParameter(index++, tracfoneOneSearchServicePlanModel.getFeatureName());
        if (!StringUtils.isNullOrEmpty(tracfoneOneSearchServicePlanModel.getFeatureRequirement())) {
            query.setParameter(index++, tracfoneOneSearchServicePlanModel.getFeatureRequirement());
        }
        query.setParameter(index++, tracfoneOneSearchServicePlanModel.getCarrierName());
    }

    private String buildProfileSearchQuery(TracfoneOneSearchServicePlanModel tracfoneOneSearchServicePlanModel) {
        StringBuilder builder = new StringBuilder();
        if (!StringUtils.isNullOrEmpty(tracfoneOneSearchServicePlanModel.getFeatureRequirement())) {
            builder.append(TracfoneOneConstantInsertWizard.GET_PROFILES_BY_FEATURE_REQUIREMENT);
        } else {
            builder.append(TracfoneOneConstantInsertWizard.GET_PROFILES_BY_FEATURE);
        }
        return builder.toString();
    }
}