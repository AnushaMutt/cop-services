package com.tracfone.service.model.response;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * @author Thejaswini
 */
public class TFOneCarriersimpref {
    private String rank;
    private String minDllExch;
    private String maxDllExch;
    private String carrierName;
    private String simProfile;
    private String dbEnv;

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getMinDllExch() {
        return minDllExch;
    }

    public void setMinDllExch(String minDllExch) {
        this.minDllExch = minDllExch;
    }

    public String getMaxDllExch() {
        return maxDllExch;
    }

    public void setMaxDllExch(String maxDllExch) {
        this.maxDllExch = maxDllExch;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getSimProfile() {
        return simProfile;
    }

    public void setSimProfile(String simProfile) {
        this.simProfile = simProfile;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    @Override
    public String toString() {
        return "TFOneCarriersimpref{" +
                "rank='" + rank + '\'' +
                ", minDllExch='" + minDllExch + '\'' +
                ", maxDllExch='" + maxDllExch + '\'' +
                ", carrierName='" + carrierName + '\'' +
                ", simProfile='" + simProfile + '\'' +
                '}';
    }
}
