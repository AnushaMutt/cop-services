package com.tracfone.service.model.retail.request;

public class TracfoneOneRetailLocation {
    private String objIds;
    private String parentId;
    private String storeName;
    private String storeNum;
    private String zip;
    private String radius;
    private String brand;

    public String getObjIds() {
        return objIds;
    }

    public void setObjIds(String objIds) {
        this.objIds = objIds;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getStoreNum() {
        return storeNum;
    }

    public void setStoreNum(String storeNum) {
        this.storeNum = storeNum;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getRadius() {
        return radius;
    }

    public void setRadius(String radius) {
        this.radius = radius;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    @Override
    public String toString() {
        return "TracfoneOneRetailLocation{" +
                "objIds='" + objIds + '\'' +
                ", parentId='" + parentId + '\'' +
                ", storeName='" + storeName + '\'' +
                ", storeNum='" + storeNum + '\'' +
                ", zip='" + zip + '\'' +
                ", radius='" + radius + '\'' +
                ", brand='" + brand + '\'' +
                '}';
    }
}
