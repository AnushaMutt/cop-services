package com.tracfone.service.model.request;

import javax.validation.constraints.Size;

/**
 * TABLE: mapinfo.eg_zip2tech
 */
public class TracfoneOneZip2Tech {
    private String dbEnv;
    private String zips;
    @Size(max = 2, message = "State cannot have more than 2 characters")
    private String state;
    @Size(max = 50, message = "County cannot have more than 50 characters")
    private String county;
    @Size(max = 20, message = "Pref1 cannot have more than 20 characters")
    private String pref1;
    @Size(max = 20, message = "Pref2 cannot have more than 20 characters")
    private String pref2;
    @Size(max = 20, message = "Service cannot have more than 20 characters")
    private String service;
    @Size(max = 2, message = "Language cannot have more than 2 characters")
    private String language;
    @Size(max = 50, message = "Action cannot have more than 50 characters")
    private String action;
    @Size(max = 50, message = "Market cannot have more than 50 characters")
    private String market;
    @Size(max = 20, message = "Zip2 cannot have more than 20 characters")
    private String zip2;
    @Size(max = 20, message = "AID cannot have more than 20 characters")
    private String aid;
    @Size(max = 20, message = "VID cannot have more than 20 characters")
    private String vid;
    @Size(max = 20, message = "VC cannot have more than 20 characters")
    private String vc;
    @Size(max = 20, message = "SAHCID cannot have more than 20 characters")
    private String sahcid;
    @Size(max = 20, message = "Com cannot have more than 20 characters")
    private String com;
    @Size(max = 30, message = "Locale cannot have more than 30 characters")
    private String locale;
    @Size(max = 30, message = "Sitetype cannot have more than 30 characters")
    private String siteType;
    @Size(max = 50, message = "Gotophonelist cannot have more than 50 characters")
    private String gotoPhoneList;
    @Size(max = 20, message = "Tech cannot have more than 20 characters")
    private String tech;
    @Size(max = 30, message = "Tech Zip cannot have more than 30 characters")
    private String techZip;
    @Size(max = 20, message = "Techkey cannot have more than 20 characters")
    private String techkey;
    @Size(max = 30, message = "Pref Parent cannot have more than 30 characters")
    private String prefParent;

    private String oldService;
    private String oldTechKey;
    private String oldPrefParent;
    private String oldZip;
    private TracfoneonePaginationSearch paginationSearch;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getZips() {
        return zips;
    }

    public void setZips(String zips) {
        this.zips = zips;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getPref1() {
        return pref1;
    }

    public void setPref1(String pref1) {
        this.pref1 = pref1;
    }

    public String getPref2() {
        return pref2;
    }

    public void setPref2(String pref2) {
        this.pref2 = pref2;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getMarket() {
        return market;
    }

    public void setMarket(String market) {
        this.market = market;
    }

    public String getZip2() {
        return zip2;
    }

    public void setZip2(String zip2) {
        this.zip2 = zip2;
    }

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getVid() {
        return vid;
    }

    public void setVid(String vid) {
        this.vid = vid;
    }

    public String getVc() {
        return vc;
    }

    public void setVc(String vc) {
        this.vc = vc;
    }

    public String getSahcid() {
        return sahcid;
    }

    public void setSahcid(String sahcid) {
        this.sahcid = sahcid;
    }

    public String getCom() {
        return com;
    }

    public void setCom(String com) {
        this.com = com;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    public String getSiteType() {
        return siteType;
    }

    public void setSiteType(String siteType) {
        this.siteType = siteType;
    }

    public String getGotoPhoneList() {
        return gotoPhoneList;
    }

    public void setGotoPhoneList(String gotoPhoneList) {
        this.gotoPhoneList = gotoPhoneList;
    }

    public String getTech() {
        return tech;
    }

    public void setTech(String tech) {
        this.tech = tech;
    }

    public String getTechZip() {
        return techZip;
    }

    public void setTechZip(String techZip) {
        this.techZip = techZip;
    }

    public String getTechkey() {
        return techkey;
    }

    public void setTechkey(String techkey) {
        this.techkey = techkey;
    }

    public String getPrefParent() {
        return prefParent;
    }

    public void setPrefParent(String prefParent) {
        this.prefParent = prefParent;
    }

    public String getOldService() {
        return oldService;
    }

    public void setOldService(String oldService) {
        this.oldService = oldService;
    }

    public String getOldTechKey() {
        return oldTechKey;
    }

    public void setOldTechKey(String oldTechKey) {
        this.oldTechKey = oldTechKey;
    }

    public String getOldPrefParent() {
        return oldPrefParent;
    }

    public void setOldPrefParent(String oldPrefParent) {
        this.oldPrefParent = oldPrefParent;
    }

    public TracfoneonePaginationSearch getPaginationSearch() {
        return paginationSearch;
    }

    public void setPaginationSearch(TracfoneonePaginationSearch paginationSearch) {
        this.paginationSearch = paginationSearch;
    }

    public String getOldZip() {
        return oldZip;
    }

    public void setOldZip(String oldZip) {
        this.oldZip = oldZip;
    }

    @Override
    public String toString() {
        return "TracfoneOneZip2Tech{" +
                "dbEnv='" + dbEnv + '\'' +
                ", zips='" + zips + '\'' +
                ", state='" + state + '\'' +
                ", county='" + county + '\'' +
                ", pref1='" + pref1 + '\'' +
                ", pref2='" + pref2 + '\'' +
                ", service='" + service + '\'' +
                ", language='" + language + '\'' +
                ", action='" + action + '\'' +
                ", market='" + market + '\'' +
                ", zip2='" + zip2 + '\'' +
                ", aid='" + aid + '\'' +
                ", vid='" + vid + '\'' +
                ", vc='" + vc + '\'' +
                ", sahcid='" + sahcid + '\'' +
                ", com='" + com + '\'' +
                ", locale='" + locale + '\'' +
                ", siteType='" + siteType + '\'' +
                ", gotoPhoneList='" + gotoPhoneList + '\'' +
                ", tech='" + tech + '\'' +
                ", techZip='" + techZip + '\'' +
                ", techkey='" + techkey + '\'' +
                ", prefParent='" + prefParent + '\'' +
                ", oldService='" + oldService + '\'' +
                ", oldTechKey='" + oldTechKey + '\'' +
                ", oldPrefParent='" + oldPrefParent + '\'' +
                ", oldZip='" + oldZip + '\'' +
                ", paginationSearch=" + paginationSearch +
                '}';
    }
}
