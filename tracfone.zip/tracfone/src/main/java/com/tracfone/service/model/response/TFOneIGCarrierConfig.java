package com.tracfone.service.model.response;


/**
 *
 * @author Gaurav.Sharma
 */
public class TFOneIGCarrierConfig {

    private String configId;
    private String carrier;
    private String propName;
    private String propType;
    private String description;
    private TFOneIGCarrierConfigDetails carrierDetails;

    public String getConfigId() {
        return configId;
    }

    public void setConfigId(String configId) {
        this.configId = configId;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getPropName() {
        return propName;
    }

    public void setPropName(String propName) {
        this.propName = propName;
    }

    public String getPropType() {
        return propType;
    }

    public void setPropType(String propType) {
        this.propType = propType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public TFOneIGCarrierConfigDetails getCarrierDetails() {
        return carrierDetails;
    }

    public void setCarrierDetails(TFOneIGCarrierConfigDetails carrierDetails) {
        this.carrierDetails = carrierDetails;
    }

    @Override
    public String toString() {
        return "TFOneIGCarrierConfig{" + "configId=" + configId + ", carrier=" + carrier + ", propName=" + propName + ", propType=" + propType + ", description=" + description + ", carrierDetails=" + carrierDetails + '}';
    }

}
