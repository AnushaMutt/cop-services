package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneUserTask;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneUserReporting;
import com.tracfone.service.model.response.TFOneUserTask;

import java.util.List;

public interface TracfoneOneUserReportingControllerLocal {
    List<TFOneUserTask> getAllUserTasks(TracfoneOneUserTask tracfoneOneUserTask) throws TracfoneOneException;

    TFOneGeneralResponse reassignTransaction(TracfoneOneUserTask tracfoneOneUserTask, int userId) throws TracfoneOneException;

    List<TFOneUserReporting> assignTransactionReport(TracfoneOneUserTask tracfoneOneUserTask) throws TracfoneOneException;

    List<TFOneUserReporting> transactionTypeReport(TracfoneOneUserTask tracfoneOneUserTask) throws TracfoneOneException;
}
