package com.tracfone.service.model.response;

/**
 * @author Thejaswini
 */
public class TFOneThrottlePolicy {
    private String objId;
    private String policyName;
    private String policyDesc;
    private String bypassTransQueue;
    private String dataSuspendedFlag;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    public String getPolicyDesc() {
        return policyDesc;
    }

    public void setPolicyDesc(String policyDesc) {
        this.policyDesc = policyDesc;
    }

    public String getBypassTransQueue() {
        return bypassTransQueue;
    }

    public void setBypassTransQueue(String bypassTransQueue) {
        this.bypassTransQueue = bypassTransQueue;
    }

    public String getDataSuspendedFlag() {
        return dataSuspendedFlag;
    }

    public void setDataSuspendedFlag(String dataSuspendedFlag) {
        this.dataSuspendedFlag = dataSuspendedFlag;
    }

    @Override
    public String toString() {
        return "TFOneThrottlePolicy{" +
                "objId='" + objId + '\'' +
                ", policyName='" + policyName + '\'' +
                ", policyDesc='" + policyDesc + '\'' +
                ", bypassTransQueue='" + bypassTransQueue + '\'' +
                ", dataSuspendedFlag='" + dataSuspendedFlag + '\'' +
                '}';
    }
}
