package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneTTransactionNotes;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantThrottleTransNotes;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @author Pritesh.Singh
 */
@Stateless
public class TracfoneOneTTransNotesAction implements TracfoneOneTTransNotesActionLocal,
        TracfoneOneConstantThrottleTransNotes, TracfoneOneConstant {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneTTransNotesAction.class);

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;
    @EJB
    private DataBaseController dbControllerEJB;

    @Override
    public void insertThrottleTransNotes(TracfoneOneTTransactionNotes tfTTransactionNotes, String userName) throws TracfoneOneException {
        Long startTime = System.nanoTime();
        try (Connection con = dbControllerEJB.getDataSource(tfTTransactionNotes.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_TT_NOTES);) {
            for (String objId : tfTTransactionNotes.getObjIds()) {
                stmt.setString(1, userName);
                stmt.setLong(2, Long.valueOf(objId));
                stmt.setString(3, tfTTransactionNotes.getNotes());
                stmt.addBatch();
            }
            stmt.executeBatch();
            Long endTime = System.nanoTime();
            LOGGER.debug("Throttle Trans insert notes execution time in milliseconds: " + (endTime - startTime) / 1000000);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_POSTGRES_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_POSTGRES_DATASOURCE_CONNECTION_ERROR_CODE_MESSAGE, e);
        }
    }
}
