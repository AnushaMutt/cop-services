package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import com.tracfone.service.model.request.TracfoneOneCarrierZonesDeployment;
import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfig;
import com.tracfone.service.model.request.TracfoneOneNpaNxx2Carrier;
import com.tracfone.service.model.response.TFOneCPrefResponse;
import com.tracfone.service.model.response.TFOneCarrierZonesDeployment;
import com.tracfone.service.model.response.TFOneCingularMrktInfo;
import com.tracfone.service.model.response.TFOneMissingCarrierZones;
import com.tracfone.service.model.response.TFOneMissingCingularMktInfo;
import com.tracfone.service.model.response.TFOneNpaNxx2Carrier;

import javax.ejb.Local;
import java.util.List;

/**
 * @author Gaurav.Sharma
 */
@Local
public interface TracfoneCarrierZonesDeploymentActionLocal {

    TFOneCarrierZonesDeployment validateCarrierZones(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException;

    TFOneCarrierZonesDeployment validateNpaNxx(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException;

    TFOneMissingCarrierZones insertMissingCarrierZones(List<TracfoneOneCarrierZones> carrierZones, int userId, String carrierName) throws TracfoneOneException;

    TFOneCPrefResponse insertCPref(List<TracfoneOneCarrierZones> carrierZones, int userId) throws TracfoneOneException;

    TFOneNpaNxx2Carrier insertNpaNxx(List<TracfoneOneNpaNxx2Carrier> nxx2Carrier, int userId) throws TracfoneOneException;

    TFOneCarrierZonesDeployment validateARUSA(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException;

    TFOneCarrierZonesDeployment validateCingularMrktInfo(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException;

    TFOneCarrierZonesDeployment validateZipMktSubMkt(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException;

    List<TFOneCingularMrktInfo> updateDealerNan(List<TracfoneOneCingularMrktInfo> cingularMrktInfos) throws TracfoneOneException;

    TFOneMissingCingularMktInfo insertCingularMktInfo(List<TracfoneOneCingularMrktInfo> mrktInfos, int userId) throws TracfoneOneException;

    TFOneNpaNxx2Carrier insertTmoNpaNxx(List<TracfoneOneNpaNxx2Carrier> nxx2Carrier, int userId) throws TracfoneOneException;

    TFOneCarrierZonesDeployment validateNextAvailable(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException;

    TFOneNpaNxx2Carrier insertNpaNxxAtt(List<TracfoneOneNpaNxx2Carrier> nxx2Carriers, int userId) throws TracfoneOneException;

    public List<String> getCarriers(TracfoneOneIGCarrierConfig carrierConfig) throws TracfoneOneException;
}
