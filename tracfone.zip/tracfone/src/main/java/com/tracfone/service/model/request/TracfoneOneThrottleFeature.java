package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * @author Thejaswini
 */
public class TracfoneOneThrottleFeature {
    private String dbEnv;
    private String objId;
    @Digits(integer = 38, fraction = 0, message = "Priority must be a number")
    @Size(max = 38, message = "Rule Id cannot have more than 38 digits")
    @Size(min = 1, message = "Rule Id cannot be null")
    private String ruleId;
    @Size(max = 40, message = "Feature Flag Name cannot have more than 40 characters")
    @Size(min = 1, message = "Feature Flag Name cannot be null")
    private String featureFlagName;
    @Size(max = 1, message = "Feature Flag Value cannot have more than 1 character")
    private String featureFlagValue;
    @Size(max = 30, message = "Feature Name cannot have more than 30 characters")
    @Size(min = 1, message = "Feature Name cannot be null")
    private String featureName;
    @Size(max = 30, message = "Feature Value cannot have more than 30 characters")
    private String featureValue;
    @Size(max = 1, message = "Status cannot have more than 1 character")
    @Size(min = 1, message = "Status cannot be null")
    private String status;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getRuleId() {
        return ruleId;
    }

    public void setRuleId(String ruleId) {
        this.ruleId = ruleId;
    }

    public String getFeatureFlagName() {
        return featureFlagName;
    }

    public void setFeatureFlagName(String featureFlagName) {
        this.featureFlagName = featureFlagName;
    }

    public String getFeatureFlagValue() {
        return featureFlagValue;
    }

    public void setFeatureFlagValue(String featureFlagValue) {
        this.featureFlagValue = featureFlagValue;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public String getFeatureValue() {
        return featureValue;
    }

    public void setFeatureValue(String featureValue) {
        this.featureValue = featureValue;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    @Override
    public String toString() {
        return "TracfoneOneThrottleFeatures{" +
                "objId='" + objId + '\'' +
                ", ruleId='" + ruleId + '\'' +
                ", featureFlagName='" + featureFlagName + '\'' +
                ", featureFlagValue='" + featureFlagValue + '\'' +
                ", featureName='" + featureName + '\'' +
                ", featureValue='" + featureValue + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
