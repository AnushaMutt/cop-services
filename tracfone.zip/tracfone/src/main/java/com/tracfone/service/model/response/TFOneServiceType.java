package com.tracfone.service.model.response;

/**
 *
 * @author Gaurav.Sharma
 */
public class TFOneServiceType {

    private String objId;
    private String serviceType;
    private String serviceTypeCategory;
    private String remarks;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getServiceTypeCategory() {
        return serviceTypeCategory;
    }

    public void setServiceTypeCategory(String serviceTypeCategory) {
        this.serviceTypeCategory = serviceTypeCategory;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "TFOneServiceType{"
                + "objId='" + objId + '\''
                + ", serviceType='" + serviceType + '\''
                + ", serviceTypeCategory='" + serviceTypeCategory + '\''
                + ", remarks='" + remarks + '\''
                + '}';
    }
}
