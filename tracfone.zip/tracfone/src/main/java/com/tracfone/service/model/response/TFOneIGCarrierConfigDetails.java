package com.tracfone.service.model.response;

/**
 *
 * @author Gaurav.Sharma
 */
public class TFOneIGCarrierConfigDetails {
    
    private String configId;
    private String propKey;
    private String propValueType;
    private String propValue;
    private String propValueKey;
    private String propValueKeyType;
    private String propValueKeyKey;
    private String remarks;

    public String getPropKey() {
        return propKey;
    }

    public void setPropKey(String propKey) {
        this.propKey = propKey;
    }

    public String getPropValueType() {
        return propValueType;
    }

    public void setPropValueType(String propValueType) {
        this.propValueType = propValueType;
    }

    public String getPropValue() {
        return propValue;
    }

    public void setPropValue(String propValue) {
        this.propValue = propValue;
    }

    public String getPropValueKey() {
        return propValueKey;
    }

    public void setPropValueKey(String propValueKey) {
        this.propValueKey = propValueKey;
    }

    public String getPropValueKeyType() {
        return propValueKeyType;
    }

    public void setPropValueKeyType(String propValueKeyType) {
        this.propValueKeyType = propValueKeyType;
    }

    public String getPropValueKeyKey() {
        return propValueKeyKey;
    }

    public void setPropValueKeyKey(String propValueKeyKey) {
        this.propValueKeyKey = propValueKeyKey;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getConfigId() {
        return configId;
    }

    public void setConfigId(String configId) {
        this.configId = configId;
    }

    @Override
    public String toString() {
        return "TFOneIGCarrierDetails{" + "configId=" + configId + ", propKey=" + propKey + ", propValueType=" + propValueType + ", propValue=" + propValue + ", propValueKey=" + propValueKey + ", propValueKeyType=" + propValueKeyType + ", propValueKeyKey=" + propValueKeyKey + ", remarks=" + remarks + '}';
    }
}
