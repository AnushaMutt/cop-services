/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

/**
 * @author Gaurav.Sharma
 */
public class TFOneThrottleTransaction {

    private String objId;
    private String transactionNum;
    private String status;
    private String min;
    private String esn;
    private String transactionType;
    private String ruleId;
    private String apiMessage;
    private String apiStatus;
    private String cos;
    private String entitlement;
    private String parentName;
    private String policyName;
    private String priority;
    private String propagateFlagValue;
    private String subscriberId;
    private String threshold;
    private String throttleGroupType;
    private String usageTierId;
    private String groupId;
    private String creationDate;
    private String lastUpdateDate;

    public String getTransactionNum() {
        return transactionNum;
    }

    public void setTransactionNum(String transactionNum) {
        this.transactionNum = transactionNum;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getEsn() {
        return esn;
    }

    public void setEsn(String esn) {
        this.esn = esn;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getRuleId() {
        return ruleId;
    }

    public void setRuleId(String ruleId) {
        this.ruleId = ruleId;
    }

    public String getApiMessage() {
        return apiMessage;
    }

    public void setApiMessage(String apiMessage) {
        this.apiMessage = apiMessage;
    }

    public String getApiStatus() {
        return apiStatus;
    }

    public void setApiStatus(String apiStatus) {
        this.apiStatus = apiStatus;
    }

    public String getCos() {
        return cos;
    }

    public void setCos(String cos) {
        this.cos = cos;
    }

    public String getEntitlement() {
        return entitlement;
    }

    public void setEntitlement(String entitlement) {
        this.entitlement = entitlement;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getPropagateFlagValue() {
        return propagateFlagValue;
    }

    public void setPropagateFlagValue(String propagateFlagValue) {
        this.propagateFlagValue = propagateFlagValue;
    }

    public String getSubscriberId() {
        return subscriberId;
    }

    public void setSubscriberId(String subscriberId) {
        this.subscriberId = subscriberId;
    }

    public String getThreshold() {
        return threshold;
    }

    public void setThreshold(String threshold) {
        this.threshold = threshold;
    }

    public String getThrottleGroupType() {
        return throttleGroupType;
    }

    public void setThrottleGroupType(String throttleGroupType) {
        this.throttleGroupType = throttleGroupType;
    }

    public String getUsageTierId() {
        return usageTierId;
    }

    public void setUsageTierId(String usageTierId) {
        this.usageTierId = usageTierId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getObjId() {
        return objId;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    @Override
    public String toString() {
        return "TFOneViewThrottleTransaction{" + "transactionNum=" + transactionNum + ", "
                + "objId=" + objId + ", "
                + "creationDate=" + creationDate + ", "
                + "lastUpdateDate=" + lastUpdateDate + ", "
                + "transactionType=" + transactionType + ", "
                + "status=" + status + ", "
                + "ruleId=" + ruleId + ", "
                + "min=" + min + ", "
                + "esn=" + esn + ", "
                + "priority=" + priority + ", "
                + "threshold=" + threshold + ", "
                + "usageTierId=" + usageTierId + ", "
                + "throttleGroupType=" + throttleGroupType + ", "
                + "subscriberId=" + subscriberId + ", "
                + "propogateFlagValue=" + propagateFlagValue + ", "
                + "policyName=" + policyName + ", "
                + "cos=" + cos + ", "
                + "entitlement=" + entitlement + ", "
                + "apiMessage=" + apiMessage + ", "
                + "apiStatus=" + apiStatus + ", "
                + "parentName=" + parentName + '}'
                + "groupId=" + groupId + '}';
    }
}
