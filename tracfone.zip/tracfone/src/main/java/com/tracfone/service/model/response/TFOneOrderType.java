package com.tracfone.service.model.response;

public class TFOneOrderType {
    private String objId;
    private String orderType;
    private String npa;
    private String nxx;
    private String billCycle;
    private String dealerCode;
    private String ldAccountNum;
    private String marketCode;
    private String orderType2xTransProfile;
    private String orderType2xCarrier;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getNpa() {
        return npa;
    }

    public void setNpa(String npa) {
        this.npa = npa;
    }

    public String getNxx() {
        return nxx;
    }

    public void setNxx(String nxx) {
        this.nxx = nxx;
    }

    public String getBillCycle() {
        return billCycle;
    }

    public void setBillCycle(String billCycle) {
        this.billCycle = billCycle;
    }

    public String getDealerCode() {
        return dealerCode;
    }

    public void setDealerCode(String dealerCode) {
        this.dealerCode = dealerCode;
    }

    public String getLdAccountNum() {
        return ldAccountNum;
    }

    public void setLdAccountNum(String ldAccountNum) {
        this.ldAccountNum = ldAccountNum;
    }

    public String getMarketCode() {
        return marketCode;
    }

    public void setMarketCode(String marketCode) {
        this.marketCode = marketCode;
    }

    public String getOrderType2xTransProfile() {
        return orderType2xTransProfile;
    }

    public void setOrderType2xTransProfile(String orderType2xTransProfile) {
        this.orderType2xTransProfile = orderType2xTransProfile;
    }

    public String getOrderType2xCarrier() {
        return orderType2xCarrier;
    }

    public void setOrderType2xCarrier(String orderType2xCarrier) {
        this.orderType2xCarrier = orderType2xCarrier;
    }

    @Override
    public String toString() {
        return "TracfoneOneOrderType{" +
                ", objId='" + objId + '\'' +
                ", orderType='" + orderType + '\'' +
                ", npa='" + npa + '\'' +
                ", nxx='" + nxx + '\'' +
                ", billCycle='" + billCycle + '\'' +
                ", dealerCode='" + dealerCode + '\'' +
                ", ldAccountNum='" + ldAccountNum + '\'' +
                ", marketCode='" + marketCode + '\'' +
                ", orderType2xTransProfile='" + orderType2xTransProfile + '\'' +
                ", orderType2xCarrier='" + orderType2xCarrier + '\'' +
                '}';
    }
}
