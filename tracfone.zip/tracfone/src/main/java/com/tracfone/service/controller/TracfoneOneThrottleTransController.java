package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneThrottleRework;
import com.tracfone.service.model.request.TracfoneOneThrottleTrans;
import com.tracfone.service.model.request.TracfoneOneThrottleTransaction;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneThrottlePolicy;
import com.tracfone.service.model.response.TFOneThrottleTransSearchResult;
import com.tracfone.service.util.TracfoneOneConstantThrottleTrans;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Stateless
public class TracfoneOneThrottleTransController implements TracfoneOneThrottleTransControllerLocal, TracfoneOneConstantThrottleTrans {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneThrottleTransController.class);

    @EJB
    TracfoneOneThrottleTransActionLocal throttleTransAction;

    @Override
    public TFOneThrottleTransSearchResult viewThrottleTransaction(TracfoneOneThrottleTransaction throttleTransactions) throws TracfoneOneException {
        TFOneThrottleTransSearchResult throttleTransactionSearchResult;
        LOGGER.debug("Search Criteria for TT - " + throttleTransactions);
        try {
            throttleTransactionSearchResult = throttleTransAction.viewThrottleTransaction(throttleTransactions);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_THROTTLE_TRANSACTION_ERROR, TRACFONE_GET_THROTTLE_TRANSACTION_ERROR_MESSAGE, ex);
        }
        return throttleTransactionSearchResult;
    }

    @Override
    public TFOneGeneralResponse reworkRequeue(TracfoneOneThrottleRework tfThrottleTransaction, String type, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse;
        try {
            if (tfThrottleTransaction.isIsReworkRequeueAll())
                tfOneGeneralResponse = throttleTransAction.reworkRequeueAll(tfThrottleTransaction, type, userId);
            else
                tfOneGeneralResponse = throttleTransAction.reworkRequeue(tfThrottleTransaction, type, userId);
        } catch (Exception ex) {
            LOGGER.error(ex);
            if ("REWORK".equalsIgnoreCase(type))
                throw new TracfoneOneException(TRACFONE_REWORK_THROTTLE_TRANSACTION_ERROR, TRACFONE_REWORK_THROTTLE_TRANSACTION_ERROR_MESSAGE, ex);
            else
                throw new TracfoneOneException(TRACFONE_REQUEUE_THROTTLE_TRANSACTION_ERROR, TRACFONE_REQUEUE_THROTTLE_TRANSACTION_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }

    @Override
    public TFOneGeneralResponse insertThrottleTransaction(TracfoneOneThrottleTrans tfThrottleTrans, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = throttleTransAction.insertThrottleTransaction(tfThrottleTrans, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_THROTTLE_TRANSACTION_ERROR, TRACFONE_ADD_THROTTLE_TRANSACTION_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<TFOneThrottlePolicy> getPolicyName(String dbEnv) throws TracfoneOneException {
        List<TFOneThrottlePolicy> policyList = new ArrayList<>();
        try {
            policyList = throttleTransAction.getPolicyName(dbEnv);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_POLICY_NAME_ERROR, TRACFONE_GET_POLICY_NAME_ERROR_MESSAGE, ex);
        }
        return policyList;
    }

    @Override
    public TFOneGeneralResponse insertThrottle(TracfoneOneThrottleTrans tfThrottleTrans, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            if (tfThrottleTrans.getTransactionType().equalsIgnoreCase("TTON")) {
                response = throttleTransAction.insertTTONThrottleTrans(tfThrottleTrans, userId);
            } else if (tfThrottleTrans.getTransactionType().equalsIgnoreCase("TTOFF")) {
                response = throttleTransAction.insertTTOFFThrottleTrans(tfThrottleTrans, userId);
            } else if (tfThrottleTrans.getTransactionType().equalsIgnoreCase("HSBON")) {
                response = throttleTransAction.insertHSBONThrottleTrans(tfThrottleTrans, userId);
            } else if (tfThrottleTrans.getTransactionType().equalsIgnoreCase("HSBOF")) {
                response = throttleTransAction.insertHSBOFThrottleTrans(tfThrottleTrans, userId);
            } else {
                throw new TracfoneOneException(TRACFONE_ADD_THROTTLE_TRANSACTION_TYPE_ERROR, TRACFONE_ADD_THROTTLE_TRANSACTION_TYPE_ERROR_MESSAGE);
            }
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_THROTTLE_TRANSACTION_ERROR, TRACFONE_ADD_THROTTLE_TRANSACTION_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<String> getUsageTierId(String dbEnv) throws TracfoneOneException {
        List<String> usageTierIdList = new ArrayList<>();
        try {
            usageTierIdList = throttleTransAction.getUsageTierId(dbEnv);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_USAGE_TIER_ID_ERROR, TRACFONE_GET_USAGE_TIER_ID_ERROR_MESSAGE, ex);
        }
        return usageTierIdList;
    }

    @Override
    public List<String> getCos(String dbEnv) throws TracfoneOneException {
        List<String> cosList = new ArrayList<>();
        try {
            cosList = throttleTransAction.getCos(dbEnv);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_COS_ERROR, TRACFONE_GET_COS_ERROR_MESSAGE, ex);
        }
        return cosList;
    }

    @Override
    public List<String> getPriority(String dbEnv, String cos) throws TracfoneOneException {
        List<String> priorityList = new ArrayList<>();
        try {
            priorityList = throttleTransAction.getPriority(dbEnv, cos);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_PRIORITY_ERROR, TRACFONE_GET_PRIORITY_ERROR_MESSAGE, ex);
        }
        return priorityList;
    }

    @Override
    public List<String> getThresholdEntitlement(String dbEnv, String columnName) throws TracfoneOneException {
        List<String> list = new ArrayList<>(1);
        try {
            list = throttleTransAction.getThresholdEntitlement(dbEnv, columnName);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            if (columnName.equalsIgnoreCase("THRESHOLD")) {
                throw new TracfoneOneException(TRACFONE_GET_THRESHOLD_ERROR, TRACFONE_GET_THRESHOLD_ERROR_MESSAGE, ex);
            } else if (columnName.equalsIgnoreCase("ENTITLEMENT")) {
                throw new TracfoneOneException(TRACFONE_GET_ENTITLEMENT_ERROR, TRACFONE_GET_ENTITLEMENT_ERROR_MESSAGE, ex);
            }
        }
        return list;
    }

    @Override
    public List<String> getRuleId(String dbEnv, String objId) throws TracfoneOneException {
        List<String> ruleIdList = new ArrayList<>(1);
        try {
            ruleIdList = throttleTransAction.getRuleId(dbEnv, objId);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_RULE_ID_ERROR, TRACFONE_GET_RULE_ID_ERROR_MESSAGE, ex);
        }
        return ruleIdList;
    }
    
    @Override
    public TFOneGeneralResponse reworkRequeueAll(TracfoneOneThrottleRework tfThrottleTransaction, String type, int userId) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                try{
                    throttleTransAction.reworkRequeue(tfThrottleTransaction, type, userId);
                }catch(TracfoneOneException ex){
                    LOGGER.error(type + " Failed for : " + tfThrottleTransaction, ex);
                }
            });
        } catch (Exception ex) {
            LOGGER.error(ex);
            if ("REWORK".equalsIgnoreCase(type))
                throw new TracfoneOneException(TRACFONE_REWORK_THROTTLE_TRANSACTION_ERROR, TRACFONE_REWORK_THROTTLE_TRANSACTION_ERROR_MESSAGE, ex);
            else
                throw new TracfoneOneException(TRACFONE_REQUEUE_THROTTLE_TRANSACTION_ERROR, TRACFONE_REQUEUE_THROTTLE_TRANSACTION_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }
    
    @Override
    public List<String> getObjIds(TracfoneOneThrottleRework tfThrottleTransaction) throws TracfoneOneException {
        List<String> tfOneGeneralResponse;
        try {
                tfOneGeneralResponse = throttleTransAction.getAllObjIdsFromSearch(tfThrottleTransaction);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_REQUEUE_THROTTLE_TRANSACTION_ERROR, TRACFONE_REQUEUE_THROTTLE_TRANSACTION_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }
}
