/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.response;

/**
 *
 * @author Shireen Fathima
 */
public class TFOneRatePlanExtensionLink {
    
    private String objId;
    private String carrierFeatureId;
    private String childPlanId;
    private String childPlanDescription;
    private String ratePlanExtensionId;
    private String lineStatusCode;
    private String throttleStatusCode;
    private String ancillaryCode;
    private String profileId;
    private String profileDescription;
    
    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getChildPlanId() {
        return childPlanId;
    }

    public void setChildPlanId(String childPlanId) {
        this.childPlanId = childPlanId;
    }

    public String getCarrierFeatureId() {
        return carrierFeatureId;
    }

    public void setCarrierFeatureId(String carrierFeatureId) {
        this.carrierFeatureId = carrierFeatureId;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getRatePlanExtensionId() {
        return ratePlanExtensionId;
    }

    public void setRatePlanExtensionId(String ratePlanExtensionId) {
        this.ratePlanExtensionId = ratePlanExtensionId;
    }

    public String getChildPlanDescription() {
        return childPlanDescription;
    }

    public void setChildPlanDescription(String childPlanDescription) {
        this.childPlanDescription = childPlanDescription;
    }

    public String getLineStatusCode() {
        return lineStatusCode;
    }

    public void setLineStatusCode(String lineStatusCode) {
        this.lineStatusCode = lineStatusCode;
    }

    public String getThrottleStatusCode() {
        return throttleStatusCode;
    }

    public void setThrottleStatusCode(String throttleStatusCode) {
        this.throttleStatusCode = throttleStatusCode;
    }

    public String getAncillaryCode() {
        return ancillaryCode;
    }

    public void setAncillaryCode(String ancillaryCode) {
        this.ancillaryCode = ancillaryCode;
    }

    public String getProfileDescription() {
        return profileDescription;
    }

    public void setProfileDescription(String profileDescription) {
        this.profileDescription = profileDescription;
    }

    @Override
    public String toString() {
        return "TFOneRatePlanExtensionLink{" + "objId=" + objId + ", "
                + "childPlanId=" + childPlanId + ", "
                + "carrierFeatureId=" + carrierFeatureId + ", "
                + "childPlanDescription=" + childPlanDescription + ", "
                + "profileDescription=" + profileDescription + ", "
                + "lineStatusCode=" + lineStatusCode + ", "
                + "throttleStatusCode=" + throttleStatusCode + ", "
                + "ancillaryCode=" + ancillaryCode + ", "
                + "profileId=" + profileId + ", "
                + "ratePlanExtensionId=" + ratePlanExtensionId + '}';
    }

    
    
}
