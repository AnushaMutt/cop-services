/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneApn;
import com.tracfone.service.model.request.TracfoneOneCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucketTier;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildTier;
import com.tracfone.service.model.request.TracfoneOneRatePlan;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionLink;
import com.tracfone.service.model.request.TracfoneOneSearchCarrierFeatureModel;
import com.tracfone.service.model.request.TracfoneOneServicePlanCarrierFeature;
import com.tracfone.service.model.response.TFOneApn;
import com.tracfone.service.model.response.TFOneBusinessOrganization;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOneRatePlan;
import com.tracfone.service.model.response.TFOneRatePlanExtensionLink;
import com.tracfone.service.model.response.TFOneServicePlanCarrierFeature;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantPlanWizard;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author Shireen Fathima
 */
@Stateless
public class TracfoneRatePlanAction implements TracfoneRatePlanLocalAction,
        TracfoneOneConstantPlanWizard,
        TracfoneOneConstant {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneConstantPlanWizard.class);

    @EJB
    private DataBaseController dbControllerEJB;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    private static final String COMMA = ",";

    private static final String AND = " AND ";

    @Override
    public TFOneGeneralResponse insertRatePlan(TracfoneOneRatePlan tfRatePlan, int userId) throws TracfoneOneException {
        String ratePlanId = "";
        try (Connection con = dbControllerEJB.getDataSource(tfRatePlan.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_RATEPLAN);) {
            // Get the rate plan id from the sequence
            ratePlanId = getMaxRatePlanId(con);
            tfRatePlan.setRatePlanId(ratePlanId);
            setRatePlanQueryParameters(stmt, tfRatePlan, false);

            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Rate Plan", "Inserted Rate Plan with objid " + ratePlanId, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, ratePlanId);
    }

    @Override
    public List<TracfoneOneCarrierFeature> insertCarrierFeatures(TracfoneOneRatePlan tfRatePlan, String carrierName, int userId) throws TracfoneOneException {
        List<TracfoneOneCarrierFeature> carrierFeatures = tfRatePlan.getCarrierFeatures();
        List<String> carrierFeatureIds = new ArrayList<>();
        String carrierId = null;

        try (Connection con = dbControllerEJB.getDataSource(tfRatePlan.getDbEnv()).getConnection();
             PreparedStatement carrierFeatureStmt = con.prepareStatement(TRACFONE_INSERT_CARRIER_FEATURE);
             PreparedStatement mtmSpCarrierFeatureStmt = con.prepareStatement(TRACFONE_INSERT_MTM_SP_CARRIER_FEATURE);
             PreparedStatement mtmSpCarrierFeatureDfltStmt = con.prepareStatement(TRACFONE_INSERT_MTM_SP_CARRIER_FEATURE_DFLT);) {

            TracfoneOneServicePlanCarrierFeature spCarrierFeature;
            LOGGER.info("Number of Carrier Features to be added is " + carrierFeatures.size());
            boolean isLegacy = false;
            for (TracfoneOneCarrierFeature carrierFeature : carrierFeatures) {
                carrierId = carrierFeature.getxFeature2xCarrier();
                LOGGER.info("CarrierId of CF is " + carrierId);
                // Get the carrier feature id from the sequence
                String carrierFeatureId = getNextSequenceId(con, TRACFONE_CARRIER_FEATURE_ID_SEQ_STMT, "CARRIER_FEATUREID_SEQ");
                carrierFeatureIds.add(carrierFeatureId);
                carrierFeature.setObjId(carrierFeatureId);
                setCarrierFeatureQueryParameters(carrierFeatureStmt, carrierFeature, false);
                carrierFeatureStmt.addBatch();

                spCarrierFeature = carrierFeature.getServicePlanCarrierFeature();
                spCarrierFeature.setCarrierFeaturesId(carrierFeatureId);
                if (carrierFeature.isLegacy()) {
                    setMtmQueryParameters(mtmSpCarrierFeatureDfltStmt, spCarrierFeature);
                    mtmSpCarrierFeatureDfltStmt.addBatch();
                    isLegacy = true;
                } else {
                    setMtmQueryParameters(mtmSpCarrierFeatureStmt, spCarrierFeature);
                    mtmSpCarrierFeatureStmt.addBatch();
                }
            }

            int[] countCF = carrierFeatureStmt.executeBatch();
            LOGGER.info("Number of Carrier Features added is " + countCF.length);
            int[] countSPCF;
            if (isLegacy) {
                countSPCF = mtmSpCarrierFeatureDfltStmt.executeBatch();
            } else {
                countSPCF = mtmSpCarrierFeatureStmt.executeBatch();
            }
            LOGGER.info("Number of MTM SP Carrier Features added is " + countSPCF.length);

            // Here counts should be the same.
            if (countCF.length != countSPCF.length) {
                LOGGER.info("Mismatch in the records inserted into table_x_carrier_features and mtm_sp_carrierfeatures");
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId,
                    "Insert Carrier Features",
                    "Inserted Carrier Features with objids " + carrierFeatureIds,
                    carrierId);
            tracfoneAuditEvent.fire(audit);
        }

        return carrierFeatures;
    }

    @Override
    public TFOneRatePlan viewRatePlan(TracfoneOneRatePlan tfRatePlan, boolean isOnlyObjid) throws TracfoneOneException {
        TFOneRatePlan tfOneRatePlan = new TFOneRatePlan();
        try (Connection con = dbControllerEJB.getDataSource(tfRatePlan.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSelectStatement(tfRatePlan, isOnlyObjid));) {
            setSelectStatement(stmt, tfRatePlan, isOnlyObjid);
            try (ResultSet resultSet = stmt.executeQuery();) {

                while (resultSet.next()) {
                    tfOneRatePlan.setObjId(resultSet.getString(OBJID));
                    tfOneRatePlan.setRatePlanName(resultSet.getString(X_RATE_PLAN));
                }
                LOGGER.info("viewrateplan search criteria is " + tfRatePlan);
                LOGGER.info("Found Rate Plan for viewrateplan " + tfOneRatePlan);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfOneRatePlan;
    }

    @Override
    public TFOneGeneralResponse updateRatePlan(TracfoneOneRatePlan tfRatePlan, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfRatePlan.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_RATEPLAN);) {
            setRatePlanQueryParameters(stmt, tfRatePlan, true);
            TFOneRatePlan oldRatePlan = viewRatePlan(tfRatePlan, true);
            if (null != oldRatePlan
                    && !StringUtils.isNullOrEmpty(oldRatePlan.getRatePlanName())
                    && !tfRatePlan.getRatePlanName().equalsIgnoreCase(oldRatePlan.getRatePlanName())) {
                LOGGER.info("Old Rate Plan Name is " + oldRatePlan.getRatePlanName());
                /* check if rate plan name has been updated, if no, do just the rate plan update
                 otherwise,
                 retrieve all APNs with old rate plan name - update them all
                 retrieve all profiles with old rate plan name - update them all
                 retrieve all carrier features with old rate plan name - update them all
                 retrieve all IG Buckets with old rate plan name - update them all
                 then update the rate plan*/
                try (PreparedStatement apnStmt = con.prepareStatement(TRACFONE_UPDATE_RATEPLAN_APN);
                     PreparedStatement cfStmt = con.prepareStatement(TRACFONE_UPDATE_RATEPLAN_CF);
                     PreparedStatement igStmt = con.prepareStatement(TRACFONE_UPDATE_RATEPLAN_IG_BUCKETS);) {

                    getUpdateRpChildrenQuery(cfStmt, oldRatePlan.getRatePlanName(), tfRatePlan.getRatePlanName());
                    cfStmt.executeUpdate();
                    LOGGER.info("Carrier Features are updated with new rate plan name");
                    getUpdateRpChildrenQuery(igStmt, oldRatePlan.getRatePlanName(), tfRatePlan.getRatePlanName());
                    igStmt.executeUpdate();
                    LOGGER.info("IG Buckets are updated with new rate plan name");
                    /*TODO - need to figure out how to update the profile description*/
                    getUpdateRpChildrenQuery(apnStmt, oldRatePlan.getRatePlanName(), tfRatePlan.getRatePlanName());
                    apnStmt.executeUpdate();
                    LOGGER.info("APNs are updated with new rate plan name");
                    stmt.executeUpdate();
                    LOGGER.info("Rate Plan is updated with new rate plan name " + tfRatePlan.getRatePlanName());

                    LOGGER.info("Commit complete - Rate plan and its children are updated");
                } catch (SQLException ex) {
                    LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, ex);
                    throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                            TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, ex);
                }
            } else {
                stmt.executeUpdate();
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Rate Plan", "Updated Rate Plan object " + tfRatePlan, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfRatePlan.getRatePlanName());
    }

    @Override
    public TFOneGeneralResponse deleteRatePlan(String dbEnv,
                                               List<String> idsToBeDeleted,
                                               int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(buildInClause(TRACFONE_DELETE_RATEPLAN, idsToBeDeleted.size()));
             PreparedStatement apnStmt = con.prepareStatement(buildInClause(TRACFONE_DELETE_RATEPLAN_APN, idsToBeDeleted.size()));
             PreparedStatement igStmt = con.prepareStatement(buildInClause(TRACFONE_DELETE_RATEPLAN_IG_BUCKETS, idsToBeDeleted.size()));) {
            getInStringQuery(igStmt, idsToBeDeleted);
            igStmt.executeUpdate();
            LOGGER.info("IG Buckets are deleted");
            getInStringQuery(apnStmt, idsToBeDeleted);
            apnStmt.executeUpdate();
            LOGGER.info("APNs are deleted");
            getInStringQuery(stmt, idsToBeDeleted);
            stmt.executeUpdate();
            LOGGER.info("Rate Plans are deleted " + idsToBeDeleted);

            LOGGER.info("Commit complete - Rate plan and its children are deleted");
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Rate Plan", "Deleted Rate Plan objids " + idsToBeDeleted, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, idsToBeDeleted.toString());
    }

    private String getNextSequenceId(Connection con, String queryString, String sequenceName) throws SQLException {
        String sequenceId = null;
        try (PreparedStatement stmt = con.prepareStatement(queryString);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                sequenceId = resultSet.getString(sequenceName);
            }
        }

        return sequenceId;
    }

    private String getSelectStatement(TracfoneOneRatePlan tfRatePlan, boolean isOnlyObjid) {
        String query = null;

        StringBuilder builder = new StringBuilder(TRACFONE_VIEW_RATEPLAN);
        generateAndQuery(builder, tfRatePlan, isOnlyObjid);

        if (builder.lastIndexOf(AND) != -1) {
            query = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("View Query " + query);

        return query;
    }

    private void setRatePlanQueryParameters(PreparedStatement stmt, TracfoneOneRatePlan tfRatePlan, boolean isUpdate) throws SQLException {
        int index = 1;
        if (!isUpdate) {
            stmt.setLong(index++, Long.valueOf(tfRatePlan.getRatePlanId()));
        }
        stmt.setString(index++, tfRatePlan.getRatePlanName().trim());
        if (!StringUtils.isNullOrEmpty(tfRatePlan.getPrivateNetwork())) {
            stmt.setString(index++, tfRatePlan.getPrivateNetwork().trim().toUpperCase());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfRatePlan.getEspidUpdate())) {
            stmt.setString(index++, tfRatePlan.getEspidUpdate().trim().toUpperCase());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfRatePlan.getEspidNum())) {
            stmt.setString(index++, tfRatePlan.getEspidNum().trim().toUpperCase());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfRatePlan.getAllowMformApnRequestFlag())) {
            stmt.setString(index++, tfRatePlan.getAllowMformApnRequestFlag().trim().toUpperCase());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfRatePlan.getPropagateFlagValue())) {
            stmt.setLong(index++, Long.valueOf(tfRatePlan.getPropagateFlagValue()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfRatePlan.getCalculateDataUnitsFlag())) {
            stmt.setString(index++, tfRatePlan.getCalculateDataUnitsFlag().trim().toUpperCase());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfRatePlan.getThresholdsToTmo())) {
            stmt.setString(index++, tfRatePlan.getThresholdsToTmo().trim().toUpperCase());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfRatePlan.getHotspotBucketsFlag())) {
            stmt.setString(index++, tfRatePlan.getHotspotBucketsFlag().trim().toUpperCase());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (isUpdate) {
            stmt.setLong(index++, Long.valueOf(tfRatePlan.getRatePlanId()));
        }
    }

    private void setCarrierFeatureQueryParameters(PreparedStatement stmt, TracfoneOneCarrierFeature tfCarrierFeature, boolean isUpdate) throws SQLException {
        int index = 1;
        if (!isUpdate) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getObjId()));
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getDev())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getDev()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxTechnology())) {
            stmt.setString(index++, tfCarrierFeature.getxTechnology().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxRatePlan())) {
            stmt.setString(index++, tfCarrierFeature.getxRatePlan().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxVoicemail())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxVoicemail()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxVmCode())) {
            stmt.setString(index++, tfCarrierFeature.getxVmCode().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxVmPackage())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxVmPackage()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxCallerId())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxCallerId()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxIdCode())) {
            stmt.setString(index++, tfCarrierFeature.getxIdCode().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxIdPackage())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxIdPackage()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxSms())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxSms()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxSmsCode())) {
            stmt.setString(index++, tfCarrierFeature.getxSmsCode().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxSmsPackage())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxSmsPackage()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxCallWaiting())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxCallWaiting()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxCwCode())) {
            stmt.setString(index++, tfCarrierFeature.getxCwCode().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxCwPackage())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxCwPackage()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxDigitalFeature())) {
            stmt.setString(index++, tfCarrierFeature.getxDigitalFeature().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxDigFeature())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxDigFeature()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxFeature2xCarrier())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxFeature2xCarrier()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxSmscNumber())) {
            stmt.setString(index++, tfCarrierFeature.getxSmscNumber().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxData())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxData()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxRestrictedUse())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxRestrictedUse()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxSwitchBaseRate())) {
            stmt.setString(index++, tfCarrierFeature.getxSwitchBaseRate().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxFeatures2BusOrg())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxFeatures2BusOrg()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxIsSwbCarrier())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxIsSwbCarrier()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxMpn())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getxMpn()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxMpnCode())) {
            stmt.setString(index++, tfCarrierFeature.getxMpnCode().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxPoolName())) {
            stmt.setString(index++, tfCarrierFeature.getxPoolName().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getCreateMformIgFlag())) {
            stmt.setString(index++, tfCarrierFeature.getCreateMformIgFlag().trim().toUpperCase());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getUseCfExtensionFlag())) {
            stmt.setString(index++, tfCarrierFeature.getUseCfExtensionFlag().trim().toUpperCase());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getDataSaver())) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getDataSaver()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getDataSaverCode())) {
            stmt.setString(index++, tfCarrierFeature.getDataSaverCode().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getUseRpExtensionFlag())) {
            stmt.setString(index++, tfCarrierFeature.getUseRpExtensionFlag().trim().toUpperCase());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getTmoNextGenFlag())) {
            stmt.setString(index++, tfCarrierFeature.getTmoNextGenFlag().trim().toUpperCase());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (isUpdate) {
            stmt.setLong(index++, Long.valueOf(tfCarrierFeature.getObjId()));
        }
    }

    private void setMtmQueryParameters(PreparedStatement stmt,
                                       TracfoneOneServicePlanCarrierFeature tfServicePlanCarrierFeature) throws SQLException {
        if (!StringUtils.isNullOrEmpty(tfServicePlanCarrierFeature.getPriority())) {
            stmt.setLong(1, Long.valueOf(tfServicePlanCarrierFeature.getPriority()));
        } else {
            stmt.setNull(1, Types.INTEGER);
        }
        stmt.setLong(2, Long.valueOf(tfServicePlanCarrierFeature.getServicePlanId()));
        stmt.setLong(3, Long.valueOf(tfServicePlanCarrierFeature.getCarrierFeaturesId()));
    }

    @Override
    public List<TFOneCarrierServicePlan> getServicePlansForCarrier(String carrierName, String dbEnv) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> tfOneCarrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneCarrierServicePlan;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_SERVICEPLANS);) {
            stmt.setString(1, carrierName);
            try (ResultSet resultSet = stmt.executeQuery();) {

                while (resultSet.next()) {
                    tfOneCarrierServicePlan = new TFOneCarrierServicePlan();
                    tfOneCarrierServicePlan.setServicePlanId(resultSet.getString(OBJID));
                    tfOneCarrierServicePlan.setMktName(resultSet.getString("mkt_name"));
                    tfOneCarrierServicePlans.add(tfOneCarrierServicePlan);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfOneCarrierServicePlans;
    }

    @Override
    public List<TFOneBusinessOrganization> getAllBusinessOrgs(String dbEnv) throws TracfoneOneException {
        List<TFOneBusinessOrganization> tfAllBusOrgs = new ArrayList<>();
        TFOneBusinessOrganization tfOneBusOrg;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_BUS_ORGS);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                tfOneBusOrg = new TFOneBusinessOrganization();
                tfOneBusOrg.setObjId(resultSet.getString(OBJID));
                tfOneBusOrg.setOrgId(resultSet.getString("org_id"));
                tfAllBusOrgs.add(tfOneBusOrg);
            }

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfAllBusOrgs;
    }

    private TFOneCarrierFeature setCarrierFeature(ResultSet resultSet) throws SQLException {
        TFOneCarrierFeature tfOneCarrierFeature = new TFOneCarrierFeature();
        tfOneCarrierFeature.setObjId(resultSet.getString(OBJID));
        tfOneCarrierFeature.setDev(resultSet.getString("DEV"));
        tfOneCarrierFeature.setxTechnology(resultSet.getString("X_TECHNOLOGY"));
        tfOneCarrierFeature.setxRatePlan(resultSet.getString(X_RATE_PLAN));
        tfOneCarrierFeature.setxVoicemail(resultSet.getString("X_VOICEMAIL"));
        tfOneCarrierFeature.setxVmCode(resultSet.getString("X_VM_CODE"));
        tfOneCarrierFeature.setxVmPackage(resultSet.getString("X_VM_PACKAGE"));
        tfOneCarrierFeature.setxCallerId(resultSet.getString("X_CALLER_ID"));
        tfOneCarrierFeature.setxIdCode(resultSet.getString("X_ID_CODE"));
        tfOneCarrierFeature.setxIdPackage(resultSet.getString("X_ID_PACKAGE"));
        tfOneCarrierFeature.setxSms(resultSet.getString("X_SMS"));
        tfOneCarrierFeature.setxSmsCode(resultSet.getString("X_SMS_CODE"));
        tfOneCarrierFeature.setxSmsPackage(resultSet.getString("X_SMS_PACKAGE"));
        tfOneCarrierFeature.setxCallWaiting(resultSet.getString("X_CALL_WAITING"));
        tfOneCarrierFeature.setxCwCode(resultSet.getString("X_CW_CODE"));
        tfOneCarrierFeature.setxCwPackage(resultSet.getString("X_CW_PACKAGE"));
        tfOneCarrierFeature.setxDigitalFeature(resultSet.getString("X_DIGITAL_FEATURE"));
        tfOneCarrierFeature.setxDigFeature(resultSet.getString("X_DIG_FEATURE"));
        tfOneCarrierFeature.setxFeature2xCarrier(resultSet.getString(X_FEATURE2X_CARRIER));
        tfOneCarrierFeature.setxSmscNumber(resultSet.getString("X_SMSC_NUMBER"));
        tfOneCarrierFeature.setxData(resultSet.getString(X_DATA));
        tfOneCarrierFeature.setxRestrictedUse(resultSet.getString("X_RESTRICTED_USE"));
        tfOneCarrierFeature.setxSwitchBaseRate(resultSet.getString("X_SWITCH_BASE_RATE"));
        tfOneCarrierFeature.setxFeatures2BusOrg(resultSet.getString("X_FEATURES2BUS_ORG"));
        tfOneCarrierFeature.setxIsSwbCarrier(resultSet.getString("X_IS_SWB_CARRIER"));
        tfOneCarrierFeature.setxMpn(resultSet.getString("X_MPN"));
        tfOneCarrierFeature.setxMpnCode(resultSet.getString("X_MPN_CODE"));
        tfOneCarrierFeature.setCreateMformIgFlag(resultSet.getString("CREATE_MFORM_IG_FLAG"));
        tfOneCarrierFeature.setxPoolName(resultSet.getString("X_POOL_NAME"));
        tfOneCarrierFeature.setUseCfExtensionFlag(resultSet.getString("USE_CF_EXTENSION_FLAG"));
        tfOneCarrierFeature.setDataSaver(resultSet.getString("DATA_SAVER"));
        tfOneCarrierFeature.setDataSaverCode(resultSet.getString("DATA_SAVER_CODE"));
        tfOneCarrierFeature.setUseRpExtensionFlag(resultSet.getString("USE_RP_EXTENSION_FLAG"));
        tfOneCarrierFeature.setTmoNextGenFlag(resultSet.getString("TMO_NEXT_GEN_FLAG"));
        return tfOneCarrierFeature;
    }

    private TFOneRatePlan setRatePlan(ResultSet resultSet) throws SQLException {
        TFOneRatePlan tfOneRatePlan = new TFOneRatePlan();
        tfOneRatePlan.setObjId(resultSet.getString(OBJID));
        tfOneRatePlan.setRatePlanName(resultSet.getString(X_RATE_PLAN));
        tfOneRatePlan.setPrivateNetwork(resultSet.getString("X_PRIVATE_NETWORK"));
        tfOneRatePlan.setEspidUpdate(resultSet.getString("X_ESPID_UPDATE"));
        tfOneRatePlan.setEspidNum(resultSet.getString("X_ESPID_NUM"));
        tfOneRatePlan.setAllowMformApnRequestFlag(resultSet.getString("ALLOW_MFORM_APN_RQST_FLAG"));
        tfOneRatePlan.setPropagateFlagValue(resultSet.getString("PROPAGATE_FLAG_VALUE"));
        tfOneRatePlan.setCalculateDataUnitsFlag(resultSet.getString("CALCULATE_DATA_UNITS_FLAG"));
        tfOneRatePlan.setThresholdsToTmo(resultSet.getString("THRESHOLDS_TO_TMO"));
        tfOneRatePlan.setHotspotBucketsFlag(resultSet.getString("HOTSPOT_BUCKETS_FLAG"));
        return tfOneRatePlan;
    }

    @Override
    public TFOneGeneralResponse deleteCarrierFeatures(String dbEnv,
                                                      String servicePlanId,
                                                      List<String> idsToBeDeleted,
                                                      int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement carrierFeaturesStmt = con.prepareStatement(buildInClause(TRACFONE_DELETE_CARRIER_FEATURE, idsToBeDeleted.size()));
             PreparedStatement mtmSpCarrierFeaturesStmt = con.prepareStatement(buildInClause(TRACFONE_DELETE_MTM_SP_CARRIER_FEATURE, idsToBeDeleted.size()));) {
            getDeleteQuery(mtmSpCarrierFeaturesStmt, servicePlanId, idsToBeDeleted);
            mtmSpCarrierFeaturesStmt.executeQuery();

            getInQuery(carrierFeaturesStmt, idsToBeDeleted);
            carrierFeaturesStmt.executeQuery();
            LOGGER.info("Carrier Features deleted " + idsToBeDeleted);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Carrier Feature", "Deleted Carrier Feature objids " + idsToBeDeleted, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, idsToBeDeleted.toString());
    }

    private void getInQuery(PreparedStatement stmt, List<String> idsToBeDeleted) throws SQLException {
        int index = 1;
        for (String id : idsToBeDeleted) {
            stmt.setLong(index++, Long.valueOf(id));
        }
    }

    private void getDeleteQuery(PreparedStatement stmt, String servicePlanId, List<String> idsToBeDeleted) throws SQLException {
        int index = 1;
        stmt.setLong(index++, Long.valueOf(servicePlanId));
        for (String id : idsToBeDeleted) {
            stmt.setLong(index++, Long.valueOf(id));
        }
    }

    private String buildInClause(String deleteQuery, int size) {
        StringBuilder query = new StringBuilder(deleteQuery);
        if (size != 1) {
            int index = 1;
            while (index < size) {
                query.append(", ?");
                index++;
            }
        }
        query.append(")");
        LOGGER.info("Query with IN Clause is " + query);
        return query.toString();
    }

    @Override
    public List<TFOneRatePlan> getMasterRatePlans(String dbEnv) throws TracfoneOneException {
        List<TFOneRatePlan> tfAllRatePlans = new ArrayList<>();
        TFOneRatePlan tfOneRatePlan;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_VIEW_ALL_RATEPLAN);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                tfOneRatePlan = setRatePlan(resultSet);
                tfAllRatePlans.add(tfOneRatePlan);
            }

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfAllRatePlans;
    }

    @Override
    public TFOneGeneralResponse updateCarrierFeature(TracfoneOneCarrierFeature tfCarrierFeature, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfCarrierFeature.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CARRIER_FEATURE);) {
            LOGGER.info("before update CF is " + tfCarrierFeature);
            setCarrierFeatureQueryParameters(stmt, tfCarrierFeature, true);
            stmt.executeUpdate();

            if (tfCarrierFeature.isLegacy()) {
                updateMtmSpCarrierFeaturesDflt(con, tfCarrierFeature.getServicePlanCarrierFeature());
            } else {
                updateMtmSpCarrierFeatures(con, tfCarrierFeature.getServicePlanCarrierFeature());
            }
            LOGGER.info("updated CF is " + tfCarrierFeature);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Carrier Feature", "Updated Carrier Feature object " + tfCarrierFeature, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfCarrierFeature.getObjId());
    }

    private void updateMtmSpCarrierFeatures(Connection con, TracfoneOneServicePlanCarrierFeature servicePlanCarrierFeature) throws SQLException {
        try (PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_MTM_SP_CARRIER_FEATURE);) {
            setMtmQueryParameters(stmt, servicePlanCarrierFeature);
            stmt.executeUpdate();
        }
    }

    private void updateMtmSpCarrierFeaturesDflt(Connection con, TracfoneOneServicePlanCarrierFeature servicePlanCarrierFeature) throws SQLException {
        try (PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_MTM_SP_CARRIER_FEATURE_DFLT);) {
            setMtmQueryParameters(stmt, servicePlanCarrierFeature);
            stmt.executeUpdate();
        }
    }

    @Override
    public List<TFOneCarrierFeature> searchCarrierFeatures(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(tfCarrierFeatureModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchStatement(tfCarrierFeatureModel));) {
            setSearchCFParameters(tfCarrierFeatureModel, stmt);

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    TFOneCarrierFeature tfOneCarrierFeature = setCarrierFeature(resultSet);
                    // carrier id
                    tfOneCarrierFeature.setxCarrierId(resultSet.getString("X_CARRIER_ID"));
                    // mtm sp carrier features
                    TFOneServicePlanCarrierFeature servicePlanCarrierFeature = new TFOneServicePlanCarrierFeature();
                    servicePlanCarrierFeature.setServicePlanId(resultSet.getString("X_SERVICE_PLAN_ID"));
                    servicePlanCarrierFeature.setCarrierFeaturesId(resultSet.getString("X_CARRIER_FEATURES_ID"));
                    servicePlanCarrierFeature.setPriority(resultSet.getString("PRIORITY"));
                    tfOneCarrierFeature.setServicePlanId(servicePlanCarrierFeature.getServicePlanId());
                    tfOneCarrierFeature.setServicePlanCarrierFeature(servicePlanCarrierFeature);
                    carrierFeatures.add(tfOneCarrierFeature);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException ex) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_CARRIER_FEATURES_ERROR,
                    TRACFONE_SEARCH_CARRIER_FEATURES_ERROR_MESSAGE, ex);
        }

        return carrierFeatures;
    }

    private void setSearchCFParameters(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel, PreparedStatement stmt) throws SQLException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        int index = 1;
        stmt.setString(index++, tfCarrierFeatureModel.getCarrierName());
        stmt.setLong(index++, Long.valueOf(tfCarrierFeatureModel.getServicePlanId()));
        setCarrierFeatureSearchQueryParams(stmt, index, tfCarrierFeatureModel);
    }

    private String getSearchStatement(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        String query = null;
        String searchQuery = TRACFONE_SEARCH_CARRIER_FEATURE;
        if (tfCarrierFeatureModel.isLegacy()) {
            searchQuery = TRACFONE_SEARCH_LEGACY_CARRIER_FEATURE;
        }
        StringBuilder builder = new StringBuilder(searchQuery);

        generateSearchCarrierFeatureQuery(builder, tfCarrierFeatureModel.getTracfoneOneCarrierFeature());

        if (builder.lastIndexOf(AND) != -1) {
            query = builder.substring(0, builder.lastIndexOf(AND));
        } else {
            query = builder.toString();
        }
        // add ordering if specified.
        List<String> orderBy = tfCarrierFeatureModel.getOrderBy();
        if (!orderBy.isEmpty()) {
            builder = new StringBuilder(query);
            builder.append(" ORDER BY ");
            for (String columnName : orderBy) {
                builder.append("CF.").append(columnName).append(COMMA);
            }
            query = builder.substring(0, builder.lastIndexOf(COMMA));
        }
        LOGGER.info("Search Carrier Features Query is" + query);
        return query;
    }

    @Override
    public List<String> getAllCarrierNames(String dbEnv) throws TracfoneOneException {
        List<String> carrierNames = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_CARRIERS);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                carrierNames.add(resultSet.getString("x_carrier_name"));
            }

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return carrierNames;
    }

    private void generateSearchCarrierFeatureQuery(StringBuilder builder, TracfoneOneCarrierFeature tfCarrierFeature) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        buildSearchClauseForElement("getDev", "DEV", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxTechnology", "X_TECHNOLOGY", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxRatePlan", X_RATE_PLAN, tfCarrierFeature, builder);
        buildSearchClauseForElement("getxVoicemail", "X_VOICEMAIL", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxVmCode", "X_VM_CODE", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxVmPackage", "X_VM_PACKAGE", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxCallerId", "X_CALLER_ID", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxIdCode", "X_ID_CODE", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxIdPackage", "X_ID_PACKAGE", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxSms", "X_SMS", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxSmsCode", "X_SMS_CODE", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxSmsPackage", "X_SMS_PACKAGE", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxCallWaiting", "X_CALL_WAITING", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxCwCode", "X_CW_CODE", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxCwPackage", "X_CW_PACKAGE", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxDigitalFeature", "X_DIGITAL_FEATURE", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxDigFeature", "X_DIG_FEATURE", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxFeature2xCarrier", X_FEATURE2X_CARRIER, tfCarrierFeature, builder);
        buildSearchClauseForElement("getxSmscNumber", "X_SMSC_NUMBER", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxData", X_DATA, tfCarrierFeature, builder);
        buildSearchClauseForElement("getxRestrictedUse", "X_RESTRICTED_USE", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxSwitchBaseRate", "X_SWITCH_BASE_RATE", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxFeatures2BusOrg", "X_FEATURES2BUS_ORG", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxIsSwbCarrier", "X_IS_SWB_CARRIER", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxMpn", "X_MPN", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxMpnCode", "X_MPN_CODE", tfCarrierFeature, builder);
        buildSearchClauseForElement("getxPoolName", "X_POOL_NAME", tfCarrierFeature, builder);
        buildSearchClauseForElement("getCreateMformIgFlag", "CREATE_MFORM_IG_FLAG", tfCarrierFeature, builder);
        buildSearchClauseForElement("getUseCfExtensionFlag", "USE_CF_EXTENSION_FLAG", tfCarrierFeature, builder);
        buildSearchClauseForElement("getDataSaver", "DATA_SAVER", tfCarrierFeature, builder);
        buildSearchClauseForElement("getDataSaverCode", "DATA_SAVER_CODE", tfCarrierFeature, builder);
        buildSearchClauseForElement("getUseRpExtensionFlag", "USE_RP_EXTENSION_FLAG", tfCarrierFeature, builder);
        buildSearchClauseForElement("getTmoNextGenFlag", "TMO_NEXT_GEN_FLAG", tfCarrierFeature, builder);
    }

    private void buildInClauseForSearchQuery(StringBuilder builder, long size) {
        int index = 1;
        while (index <= size) {
            builder.append(", ?");
            index++;
        }
        builder.append(")");
    }

    private void buildSearchClauseForElement(String methodName, String columnName, TracfoneOneCarrierFeature tfCarrierFeature, StringBuilder builder) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        Method m = tfCarrierFeature.getClass().getMethod(methodName);
        Object element = m.invoke(tfCarrierFeature);
        if (element != null) {
            String elementValue = element.toString();
            LOGGER.info(methodName);
            LOGGER.info(elementValue);
            if (elementValue.contains(COMMA)) {
                builder.append("cf.").append(columnName).append(" in (?");
                buildInClauseForSearchQuery(builder, elementValue.chars().filter(ch -> ch == ',').count());
                builder.append(AND);
            } else {
                builder.append("cf.").append(columnName).append(" = ?");
                builder.append(AND);
            }
        }
    }

    private void setCarrierFeatureSearchQueryParams(PreparedStatement stmt, int index,
                                                    TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, SQLException {
        TracfoneOneCarrierFeature tracfoneOneCarrierFeature = tfCarrierFeatureModel.getTracfoneOneCarrierFeature();
        index = setSearchParamsForElement(stmt, "getDev", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxTechnology", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getxRatePlan", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getxVoicemail", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxVmCode", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getxVmPackage", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxCallerId", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxIdCode", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getxIdPackage", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxSms", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxSmsCode", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getxSmsPackage", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxCallWaiting", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxCwCode", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getxCwPackage", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxDigitalFeature", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getxDigFeature", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxFeature2xCarrier", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxSmscNumber", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getxData", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxRestrictedUse", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxSwitchBaseRate", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getxFeatures2BusOrg", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxIsSwbCarrier", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxMpn", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getxMpnCode", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getxPoolName", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getCreateMformIgFlag", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getUseCfExtensionFlag", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getDataSaver", tracfoneOneCarrierFeature, index, true);
        index = setSearchParamsForElement(stmt, "getDataSaverCode", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getUseRpExtensionFlag", tracfoneOneCarrierFeature, index, false);
        index = setSearchParamsForElement(stmt, "getTmoNextGenFlag", tracfoneOneCarrierFeature, index, false);

        if (!StringUtils.isNullOrEmpty(tfCarrierFeatureModel.getProfileId())) {
            stmt.setString(index++, tfCarrierFeatureModel.getProfileId());
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeatureModel.getProfileDesc())) {
            stmt.setString(index++, "%" + tfCarrierFeatureModel.getProfileDesc().toUpperCase() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeatureModel.getBucketId())) {
            stmt.setString(index++, tfCarrierFeatureModel.getBucketId());
            stmt.setString(index++, tfCarrierFeatureModel.getBucketId());
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeatureModel.getBucketRequirement())) {
            stmt.setString(index++, tfCarrierFeatureModel.getBucketRequirement());
            stmt.setString(index, tfCarrierFeatureModel.getBucketRequirement());
        }
    }

    private int setSearchParamsForElement(PreparedStatement stmt, String methodName,
                                          TracfoneOneCarrierFeature tracfoneOneCarrierFeature,
                                          int index,
                                          boolean isLong) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, SQLException {
        Method m = tracfoneOneCarrierFeature.getClass().getMethod(methodName);
        Object element = m.invoke(tracfoneOneCarrierFeature);
        if (element != null) {
            String elementValue = element.toString();
            LOGGER.info(methodName);
            LOGGER.info(elementValue);
            if (elementValue.contains(COMMA)) {
                List<String> elementValues = Arrays.asList(elementValue.split(COMMA));
                if (isLong) {
                    for (String value : elementValues) {
                        stmt.setLong(index++, Long.valueOf(value));
                    }
                } else {
                    for (String value : elementValues) {
                        stmt.setString(index++, value);
                    }
                }
            } else {
                if (isLong) {
                    stmt.setLong(index++, Long.valueOf(elementValue));
                } else {
                    stmt.setString(index++, elementValue);
                }
            }
        }
        return index;
    }

    @Override
    public TFOneGeneralResponse insertApn(TracfoneOneApn tfOneApn, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneApn.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_APN);) {

            setApnQueryParams(stmt, tfOneApn);

            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId,
                    "Insert APN",
                    "Inserted APN for rate plan, apn and orgid " + tfOneApn.getRatePlan() + AND + tfOneApn.getApn() + AND + tfOneApn.getOrgId(),
                    null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneApn.getRatePlan());
    }

    private int setApnQueryParams(PreparedStatement stmt, TracfoneOneApn tfOneApn) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tfOneApn.getxParentName())) {
            stmt.setString(index++, tfOneApn.getxParentName().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getRatePlan())) {
            stmt.setString(index++, tfOneApn.getRatePlan().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getOrgId())) {
            stmt.setString(index++, tfOneApn.getOrgId().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getApn())) {
            stmt.setString(index++, tfOneApn.getApn().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getUsername())) {
            stmt.setString(index++, tfOneApn.getUsername().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getPassword())) {
            stmt.setString(index++, tfOneApn.getPassword().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getAuthType())) {
            stmt.setString(index++, tfOneApn.getAuthType().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getProxyAddress())) {
            stmt.setString(index++, tfOneApn.getProxyAddress().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getProxyPort())) {
            stmt.setString(index++, tfOneApn.getProxyPort().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getConnectionType())) {
            stmt.setString(index++, tfOneApn.getConnectionType().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getMmsApn())) {
            stmt.setString(index++, tfOneApn.getMmsApn().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getMmsUsername())) {
            stmt.setString(index++, tfOneApn.getMmsUsername().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getMmsPassword())) {
            stmt.setString(index++, tfOneApn.getMmsPassword().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getMmsAuthType())) {
            stmt.setString(index++, tfOneApn.getMmsAuthType().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getMmsc())) {
            stmt.setString(index++, tfOneApn.getMmsc().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getMmsProxyAddress())) {
            stmt.setString(index++, tfOneApn.getMmsProxyAddress().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getMmsProxyPort())) {
            stmt.setString(index++, tfOneApn.getMmsProxyPort().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getMmsApnType())) {
            stmt.setString(index++, tfOneApn.getMmsApnType().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getRtspProxyAddr())) {
            stmt.setString(index++, tfOneApn.getRtspProxyAddr().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(tfOneApn.getRtspProxyPort())) {
            stmt.setString(index++, tfOneApn.getRtspProxyPort().trim());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        return index;
    }

    @Override
    public TFOneGeneralResponse updateApn(TracfoneOneApn tfOneApn, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneApn.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_APN);) {
            LOGGER.info("APN sent for update is " + tfOneApn);
            int index = setApnQueryParams(stmt, tfOneApn);
            // where clause params
            stmt.setString(index++, tfOneApn.getRatePlan());
            stmt.setString(index++, tfOneApn.getOldApn().toUpperCase());
            stmt.setString(index++, tfOneApn.getOldOrgId().toUpperCase());
            stmt.setString(index++, tfOneApn.getOldParentName().toUpperCase());

            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update APN", "Updated APN object " + tfOneApn, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneApn.getRatePlan());
    }

    @Override
    public TFOneGeneralResponse deleteApn(TracfoneOneApn tfOneApn, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneApn.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_APN);) {
            buildApnQuery(stmt, tfOneApn);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId,
                    "Delete APN",
                    "Deleted APN for rate plan, apn and orgid " + tfOneApn.getRatePlan() + AND + tfOneApn.getApn() + AND + tfOneApn.getOrgId(),
                    null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneApn.getApn());
    }

    @Override
    public List<TFOneParent> getAllParentNames(String dbEnv, String carrierName) throws TracfoneOneException {
        List<TFOneParent> tfAllParentNames = new ArrayList<>();
        TFOneParent tfOneParent;
        String query = TRACFONE_GET_ALL_PARENT_NAMES;
        if (StringUtils.isNullOrEmpty(carrierName)) {
            query = TRACFONE_GET_ALL_PARENT_SHORTNAMES;
        }
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(query);) {
            if (!StringUtils.isNullOrEmpty(carrierName)) {
                stmt.setString(1, carrierName);
            }
            try (ResultSet resultSet = stmt.executeQuery();) {

                while (resultSet.next()) {
                    tfOneParent = new TFOneParent();
                    tfOneParent.setObjId(resultSet.getString(OBJID));
                    tfOneParent.setxParentName(resultSet.getString("x_parent_name"));
                    tfOneParent.setParentShortName(resultSet.getString("PARENT_SHORT_NAME"));
                    tfOneParent.setParentId(resultSet.getString("X_PARENT_ID"));
                    tfAllParentNames.add(tfOneParent);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfAllParentNames;
    }

    private String getMaxRatePlanId(Connection con) throws SQLException {
        String ratePlanId = null;
        try (PreparedStatement stmt = con.prepareStatement(TRACFONE_MAX_RATEPLAN_OBJID);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                long objid = resultSet.getLong(OBJID);
                ratePlanId = String.valueOf(objid + 1);
            }
        }
        return ratePlanId;
    }

    @Override
    public List<TFOneRatePlan> searchRatePlansForUpdate(TracfoneOneRatePlan tracfoneOneRatePlan) throws TracfoneOneException {
        List<TFOneRatePlan> tfRatePlans = new ArrayList<>();
        TFOneRatePlan tfOneRatePlan;

        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneRatePlan.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchRatePlanStatement(tracfoneOneRatePlan));) {
            setSelectStatement(stmt, tracfoneOneRatePlan, false);
            try (ResultSet resultSet = stmt.executeQuery();) {

                while (resultSet.next()) {
                    tfOneRatePlan = setRatePlan(resultSet);
                    tfRatePlans.add(tfOneRatePlan);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfRatePlans;
    }

    private String getSearchRatePlanStatement(TracfoneOneRatePlan tracfoneOneRatePlan) {
        String searchQuery = null;
        StringBuilder builder = new StringBuilder(TRACFONE_SEARCH_UNLINKED_RP);
        generateAndQuery(builder, tracfoneOneRatePlan, false);

        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Query " + searchQuery);

        return searchQuery;
    }

    private void setSelectStatement(PreparedStatement stmt, TracfoneOneRatePlan tfRatePlan, boolean isOnlyObjid) throws SQLException {
        int index = 1;
        if (isOnlyObjid) {
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getRatePlanId())) {
                stmt.setLong(index++, Long.valueOf(tfRatePlan.getRatePlanId()));
            }
        } else {
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getRatePlanName())) {
                stmt.setString(index++, tfRatePlan.getRatePlanName());
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getPrivateNetwork())) {
                stmt.setString(index++, tfRatePlan.getPrivateNetwork().toUpperCase());
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getEspidUpdate())) {
                stmt.setString(index++, tfRatePlan.getEspidUpdate().toUpperCase());
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getEspidNum())) {
                stmt.setString(index++, tfRatePlan.getEspidNum().toUpperCase());
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getAllowMformApnRequestFlag())) {
                stmt.setString(index++, tfRatePlan.getAllowMformApnRequestFlag().toUpperCase());
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getPropagateFlagValue())) {
                stmt.setLong(index++, Long.valueOf(tfRatePlan.getPropagateFlagValue()));
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getCalculateDataUnitsFlag())) {
                stmt.setString(index++, tfRatePlan.getCalculateDataUnitsFlag().toUpperCase());
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getThresholdsToTmo())) {
                stmt.setString(index++, tfRatePlan.getThresholdsToTmo().toUpperCase());
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getHotspotBucketsFlag())) {
                stmt.setString(index, tfRatePlan.getHotspotBucketsFlag().toUpperCase());
            }
        }
    }

    private void generateAndQuery(StringBuilder builder, TracfoneOneRatePlan tfRatePlan, boolean isOnlyObjid) {
        if (isOnlyObjid) {
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getRatePlanId())) {
                builder.append("OBJID = ?");
                builder.append(AND);
            }
        } else {
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getRatePlanName())) {
                builder.append("X_RATE_PLAN = ?");
                builder.append(AND);
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getPrivateNetwork())) {
                builder.append("UPPER(X_PRIVATE_NETWORK) = ?");
                builder.append(AND);
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getEspidUpdate())) {
                builder.append("UPPER(X_ESPID_UPDATE) = ?");
                builder.append(AND);
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getEspidNum())) {
                builder.append("UPPER(X_ESPID_NUM) = ?");
                builder.append(AND);
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getAllowMformApnRequestFlag())) {
                builder.append("UPPER(ALLOW_MFORM_APN_RQST_FLAG) = ?");
                builder.append(AND);
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getPropagateFlagValue())) {
                builder.append("PROPAGATE_FLAG_VALUE = ?");
                builder.append(AND);
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getCalculateDataUnitsFlag())) {
                builder.append("UPPER(CALCULATE_DATA_UNITS_FLAG) = ?");
                builder.append(AND);
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getThresholdsToTmo())) {
                builder.append("UPPER(THRESHOLDS_TO_TMO) = ?");
                builder.append(AND);
            }
            if (!StringUtils.isNullOrEmpty(tfRatePlan.getHotspotBucketsFlag())) {
                builder.append("UPPER(HOTSPOT_BUCKETS_FLAG) = ?");
                builder.append(AND);
            }
        }
    }

    private void buildApnQuery(PreparedStatement stmt, TracfoneOneApn tfOneApn) throws SQLException {
        stmt.setString(1, tfOneApn.getRatePlan().trim());
        stmt.setString(2, tfOneApn.getApn().trim().toUpperCase());
        stmt.setString(3, tfOneApn.getOrgId().trim().toUpperCase());
        stmt.setString(4, tfOneApn.getxParentName().trim().toUpperCase());
    }

    @Override
    public List<TFOneApn> getAllRatePlanApns(TracfoneOneApn tracfoneOneApn) throws TracfoneOneException {
        List<TFOneApn> ratePlanApns = new ArrayList<>();

        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneApn.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_RATEPLAN_APNS);) {
            stmt.setString(1, tracfoneOneApn.getRatePlan());
            try (ResultSet resultSet = stmt.executeQuery();) {

                while (resultSet.next()) {
                    TFOneApn tfOneRatePlanApn = setRatePlanForApn(resultSet);
                    ratePlanApns.add(tfOneRatePlanApn);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return ratePlanApns;
    }

    private TFOneApn setRatePlanForApn(ResultSet resultSet) throws SQLException {
        TFOneApn tfOneApn = new TFOneApn();
        tfOneApn.setxParentName(resultSet.getString("X_PARENT_NAME"));
        tfOneApn.setRatePlan(resultSet.getString("RATE_PLAN"));
        tfOneApn.setOrgId(resultSet.getString("ORG_ID"));
        tfOneApn.setApn(resultSet.getString("APN"));
        tfOneApn.setUsername(resultSet.getString("USERNAME"));
        tfOneApn.setPassword(resultSet.getString("PASSWORD"));
        tfOneApn.setAuthType(resultSet.getString("AUTH_TYPE"));
        tfOneApn.setProxyAddress(resultSet.getString("PROXY_ADDRESS"));
        tfOneApn.setProxyPort(resultSet.getString("PROXY_PORT"));
        tfOneApn.setConnectionType(resultSet.getString("CONNECTION_TYPE"));
        tfOneApn.setMmsApn(resultSet.getString("MMS_APN"));
        tfOneApn.setMmsUsername(resultSet.getString("MMS_USERNAME"));
        tfOneApn.setMmsPassword(resultSet.getString("MMS_PASSWORD"));
        tfOneApn.setMmsAuthType(resultSet.getString("MMS_AUTH_TYPE"));
        tfOneApn.setMmsc(resultSet.getString("MMSC"));
        tfOneApn.setMmsProxyAddress(resultSet.getString("MMS_PROXY_ADDRESS"));
        tfOneApn.setMmsProxyPort(resultSet.getString("MMS_PROXY_PORT"));
        tfOneApn.setMmsApnType(resultSet.getString("MMS_APN_TYPE"));
        tfOneApn.setRtspProxyAddr(resultSet.getString("RTSP_PROXY_ADDR"));
        tfOneApn.setRtspProxyPort(resultSet.getString("RTSP_PROXY_PORT"));
        return tfOneApn;
    }

    private String getDeleteMtmStatement(List<String> idsToBeDeleted, String query) {
        StringBuilder builder = new StringBuilder(query);
        int size = idsToBeDeleted.size();
        if (size != 1) {
            int index = 1;
            while (index < size) {
                builder.append(", ?");
                index++;
            }
        }
        builder.append("))");
        LOGGER.info("Query with IN Clause is " + builder.toString());
        return builder.toString();
    }

    private void getInStringQuery(PreparedStatement stmt, List<String> idsToBeDeleted) throws SQLException {
        int index = 1;
        for (String id : idsToBeDeleted) {
            stmt.setString(index++, id);
        }
    }

    private void getUpdateRpChildrenQuery(PreparedStatement stmt, String oldName, String newName) throws SQLException {
        stmt.setString(1, newName);
        stmt.setString(2, oldName);
    }

    @Override
    public boolean isDuplicateApn(TracfoneOneApn searchApn) throws TracfoneOneException {
        boolean isDuplicate = false;
        try (Connection con = dbControllerEJB.getDataSource(searchApn.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_VIEW_APN);) {
            buildApnQuery(stmt, searchApn);
            try (ResultSet resultSet = stmt.executeQuery();) {

                while (resultSet.next()) {
                    isDuplicate = true;
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return isDuplicate;
    }

    @Override
    public List<TFOneCarrierFeature> getCarrierFeatureLinks(List<TracfoneOneCarrierFeature> selectedCarrierFeatures) throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        TFOneCarrierFeature tfOneCarrierFeature;
        List<TFOneRatePlanExtensionLink> links;
        TFOneRatePlanExtensionLink tfOneRatePlanExtensionLink;
        try (Connection con = dbControllerEJB.getDataSource(selectedCarrierFeatures.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_VIEW_RP_EXTENSION_LINK_FOR_CF + " order by el.rp_extension_objid, el.child_plan_id");) {

            for (TracfoneOneCarrierFeature cf : selectedCarrierFeatures) {
                stmt.setLong(1, Long.valueOf(cf.getObjId()));
                try (ResultSet resultSet = stmt.executeQuery();) {
                    links = new ArrayList<>();
                    tfOneCarrierFeature = new TFOneCarrierFeature();
                    tfOneCarrierFeature.setObjId(cf.getObjId());

                    while (resultSet.next()) {
                        tfOneRatePlanExtensionLink = new TFOneRatePlanExtensionLink();
                        tfOneRatePlanExtensionLink.setObjId(resultSet.getString(OBJID));
                        tfOneRatePlanExtensionLink.setChildPlanId(resultSet.getString("CHILD_PLAN_ID"));
                        tfOneRatePlanExtensionLink.setChildPlanDescription(resultSet.getString("CHILD_DESCRIPTION"));
                        tfOneRatePlanExtensionLink.setProfileId(resultSet.getString("PROFILE_ID"));
                        tfOneRatePlanExtensionLink.setProfileDescription(resultSet.getString("PROFILE_DESC"));
                        tfOneRatePlanExtensionLink.setRatePlanExtensionId(resultSet.getString("RP_EXTENSION_OBJID"));
                        tfOneRatePlanExtensionLink.setLineStatusCode(resultSet.getString("LINE_STATUS_CODE"));
                        tfOneRatePlanExtensionLink.setThrottleStatusCode(resultSet.getString("THROTTLE_STATUS_CODE"));
                        tfOneRatePlanExtensionLink.setAncillaryCode(resultSet.getString("ANCILLARY_CODE"));
                        links.add(tfOneRatePlanExtensionLink);
                    }
                    tfOneCarrierFeature.setRpExtensionLinks(links);
                    carrierFeatures.add(tfOneCarrierFeature);
                } catch (SQLException ex) {
                    LOGGER.error("Unable to get RP Extension Linsk for " + cf.getObjId(), ex);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return carrierFeatures;
    }

    @Override
    public TFOneGeneralResponse insertRatePlanAssociation(TracfoneOneCarrierFeature tfOneCarrierFeature, int userId) throws TracfoneOneException {
        String carrierId = null;
        String carrierFeatureId = null;
        if (StringUtils.isNullOrEmpty(tfOneCarrierFeature.getObjId())) {
            TracfoneOneRatePlan ratePlan = new TracfoneOneRatePlan();
            ratePlan.setDbEnv(tfOneCarrierFeature.getDbEnv());
            ratePlan.getCarrierFeatures().add(tfOneCarrierFeature);
            List<TracfoneOneCarrierFeature> carrierFeatures = insertCarrierFeatures(ratePlan, tfOneCarrierFeature.getxFeature2xCarrier(), userId);
            carrierFeatureId = carrierFeatures.get(0).getObjId();
            carrierId = carrierFeatures.get(0).getxFeature2xCarrier();
        } else {
            carrierFeatureId = tfOneCarrierFeature.getObjId();
        }
        LOGGER.info("Carrier Feature id for rate plan association " + carrierFeatureId);
        try (Connection con = dbControllerEJB.getDataSource(tfOneCarrierFeature.getDbEnv()).getConnection();) {
            // Add the rp_extension_links and buckets and tiers
            List<TracfoneOneRatePlanExtensionLink> rpExtensionLinks = tfOneCarrierFeature.getRatePlanExtensionLinks();
            for (TracfoneOneRatePlanExtensionLink extensionLink : rpExtensionLinks) {
                extensionLink.setCarrierFeatureId(carrierFeatureId);
                addLinkAndBuckets(con, extensionLink, tfOneCarrierFeature.getServicePlanCarrierFeature().getServicePlanId());
            }
        } catch (Exception e) {
            List<String> idsToBeDeleted = new ArrayList<>();
            idsToBeDeleted.add(carrierFeatureId);
            deleteCarrierFeatures(tfOneCarrierFeature.getDbEnv(),
                    tfOneCarrierFeature.getServicePlanCarrierFeature().getServicePlanId(),
                    idsToBeDeleted,
                    userId);
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId,
                    "Insert Rate Plan Associations",
                    "Inserted Carrier Feature with objids " + tfOneCarrierFeature,
                    carrierId);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneCarrierFeature.getObjId());
    }


    private void setLinkQueryParameters(PreparedStatement stmt, TracfoneOneRatePlanExtensionLink extensionLink) throws SQLException {
        stmt.setLong(1, Long.valueOf(extensionLink.getObjId()));
        stmt.setLong(2, Long.valueOf(extensionLink.getCarrierFeatureId()));
        stmt.setLong(3, Long.valueOf(extensionLink.getRatePlanExtensionId()));
        stmt.setLong(4, Long.valueOf(extensionLink.getProfileId()));
        if (!StringUtils.isNullOrEmpty(extensionLink.getChildPlanId())) {
            stmt.setString(5, extensionLink.getChildPlanId().trim());
        } else {
            stmt.setNull(5, Types.VARCHAR);
        }
    }

    private void addLinkAndBuckets(Connection con, TracfoneOneRatePlanExtensionLink extensionLink, String servicePlanId) throws SQLException {
        try (PreparedStatement extensionLinkStmt = con.prepareStatement(TRACFONE_INSERT_RP_EXTENSION_LINK);) {
            String extensionLinkObjId = getNextSequenceId(con, TRACFONE_EXTENSION_LINK_ID_SEQ_STMT, "EXTENSION_LINKID_SEQ");
            extensionLink.setObjId(extensionLinkObjId);
            LOGGER.info("Extension Link object " + extensionLink);
            setLinkQueryParameters(extensionLinkStmt, extensionLink);
            extensionLinkStmt.executeQuery();
            LOGGER.info("Extension Link object ADDED" + extensionLink);
            if (!extensionLink.getTracfoneOneCarrierProfileBuckets().isEmpty()) {
                List<TracfoneOneCarrierProfileBucket> buckets = extensionLink.getTracfoneOneCarrierProfileBuckets();
                for (TracfoneOneCarrierProfileBucket bucket : buckets) {
                    addBucketAndTiers(con, bucket, servicePlanId, extensionLink.getProfileId());
                }
            }

            if (!extensionLink.getTracfoneOneCarrierProfileChildBuckets().isEmpty()) {
                List<TracfoneOneCarrierProfileChildBucket> childBuckets = extensionLink.getTracfoneOneCarrierProfileChildBuckets();
                for (TracfoneOneCarrierProfileChildBucket childBucket : childBuckets) {
                    addChildBucketAndTiers(con, childBucket, servicePlanId, extensionLink.getProfileId());
                }
            }
        }
    }

    private void setBucketQueryParameters(PreparedStatement stmt, TracfoneOneCarrierProfileBucket carrierProfileBucket) throws SQLException {
        int index = 1;
        stmt.setLong(index++, Long.valueOf(carrierProfileBucket.getObjectId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileBucket.getProfileId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileBucket.getServicePlanId()));
        stmt.setString(index++, carrierProfileBucket.getBucketId());
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getBucketValue())) {
            stmt.setLong(index++, Long.valueOf(carrierProfileBucket.getBucketValue()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getUnitOfMeasure())) {
            stmt.setString(index++, carrierProfileBucket.getUnitOfMeasure());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getBucketType())) {
            stmt.setString(index++, carrierProfileBucket.getBucketType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getBucketGroup())) {
            stmt.setString(index++, carrierProfileBucket.getBucketGroup());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getBucketRequirement())) {
            stmt.setString(index++, carrierProfileBucket.getBucketRequirement());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        stmt.setString(index++, carrierProfileBucket.getActiveFlag().toUpperCase());
        stmt.setString(index++, carrierProfileBucket.getAutoRenewFlag());
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getAutoRenewFrequency())) {
            stmt.setString(index++, carrierProfileBucket.getAutoRenewFrequency());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getAutoRenewValue())) {
            stmt.setString(index++, carrierProfileBucket.getAutoRenewValue());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getAutoRenewDay())) {
            stmt.setString(index++, carrierProfileBucket.getAutoRenewDay());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getBenefitType())) {
            stmt.setString(index++, carrierProfileBucket.getBenefitType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getSuiDisplayType())) {
            stmt.setString(index++, carrierProfileBucket.getSuiDisplayType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getPriority())) {
            stmt.setLong(index++, Long.valueOf(carrierProfileBucket.getPriority()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucket.getHideUbiFlag())) {
            stmt.setString(index, carrierProfileBucket.getHideUbiFlag());
        } else {
            stmt.setNull(index, Types.VARCHAR);
        }
    }

    private void setBucketTierQueryParameters(PreparedStatement stmt, TracfoneOneCarrierProfileBucketTier carrierProfileBucketTier) throws SQLException {
        int index = 1;
        stmt.setLong(index++, Long.valueOf(carrierProfileBucketTier.getObjId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileBucketTier.getCarrierProfileBucketsObjId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileBucketTier.getUsageTierId()));
        if (!StringUtils.isNullOrEmpty(carrierProfileBucketTier.getTierDescription())) {
            stmt.setString(index++, carrierProfileBucketTier.getTierDescription());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucketTier.getTierValue())) {
            stmt.setLong(index++, Long.valueOf(carrierProfileBucketTier.getTierValue()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileBucketTier.getTierBehavior())) {
            stmt.setString(index, carrierProfileBucketTier.getTierBehavior());
        } else {
            stmt.setNull(index, Types.VARCHAR);
        }
    }

    private void addBucketAndTiers(Connection con, TracfoneOneCarrierProfileBucket bucket, String servicePlanId, String profileId) throws SQLException {
        int duplicate = 0;
        try (PreparedStatement cpDuplicateStmt = con.prepareStatement(TRACFONE_DUPLICATE_BUCKET_CHECK);) {
            cpDuplicateStmt.setString(1, profileId);
            cpDuplicateStmt.setString(2, servicePlanId);
            cpDuplicateStmt.setString(3, bucket.getBucketId());
            try (ResultSet resultSet = cpDuplicateStmt.executeQuery()) {
                while (resultSet.next()) {
                    duplicate = resultSet.getInt(1);
                }
            }
        }
        LOGGER.info("Does bucket already exist? " + duplicate);
        if (duplicate == 0) {
            try (PreparedStatement cpBucketStmt = con.prepareStatement(TRACFONE_INSERT_CARRIER_PROFILE_BUCKET);
                 PreparedStatement cpBucketTierStmt = con.prepareStatement(TRACFONE_INSERT_BUCKET_TIER);) {

                String bucketObjId = getNextSequenceId(con, TRACFONE_CARRIER_PROFILE_BUCKET_SEQ_STMT, "CARRIER_PROFILE_BUCKETID_SEQ");
                bucket.setObjectId(bucketObjId);
                bucket.setServicePlanId(servicePlanId);
                bucket.setProfileId(profileId);
                setBucketQueryParameters(cpBucketStmt, bucket);
                cpBucketStmt.execute();
                LOGGER.info("Added Bucket " + bucket);
                if (!bucket.getTracfoneOneCarrierProfileBucketTiers().isEmpty()) {
                    List<TracfoneOneCarrierProfileBucketTier> bucketTiers = bucket.getTracfoneOneCarrierProfileBucketTiers();
                    for (TracfoneOneCarrierProfileBucketTier bucketTier : bucketTiers) {
                        // Get the carrier profile bucket tier id from the sequence
                        bucketTier.setObjId(getNextSequenceId(con, TRACFONE_BUCKET_TIER_SEQ_STMT, "BUCKET_TIERID_SEQ"));
                        bucketTier.setCarrierProfileBucketsObjId(bucketObjId);
                        setBucketTierQueryParameters(cpBucketTierStmt, bucketTier);
                        cpBucketTierStmt.addBatch();
                    }
                    cpBucketTierStmt.executeBatch();
                    LOGGER.info("Added Bucket tiers " + bucketTiers);
                }
            }
        }
    }

    private void addChildBucketAndTiers(Connection con, TracfoneOneCarrierProfileChildBucket childBucket, String servicePlanId, String profileId) throws SQLException {
        int duplicate = 0;
        try (PreparedStatement cpDuplicateStmt = con.prepareStatement(TRACFONE_DUPLICATE_CHILD_BUCKET_CHECK);) {
            cpDuplicateStmt.setString(1, profileId);
            cpDuplicateStmt.setString(2, servicePlanId);
            cpDuplicateStmt.setString(3, childBucket.getBucketId());
            cpDuplicateStmt.setString(4, childBucket.getChildPlanId());
            try (ResultSet resultSet = cpDuplicateStmt.executeQuery()) {
                while (resultSet.next()) {
                    duplicate = resultSet.getInt(1);
                }
            }
        }
        LOGGER.info("Does child bucket already exist? " + duplicate);
        if (duplicate == 0) {
            try (PreparedStatement cpChildBucketStmt = con.prepareStatement(TRACFONE_INSERT_CHILD_BUCKET);
                 PreparedStatement cpChildBucketTierStmt = con.prepareStatement(TRACFONE_INSERT_CHILD_BUCKET_TIER);) {
                String childBucketObjId = getNextSequenceId(con, TRACFONE_CHILD_BUCKET_SEQ_STMT, "CHILD_BUCKETID_SEQ");
                childBucket.setObjId(childBucketObjId);
                childBucket.setServicePlanId(servicePlanId);
                childBucket.setProfileId(profileId);
                setChildBucketQueryParameters(cpChildBucketStmt, childBucket);
                cpChildBucketStmt.execute();
                LOGGER.info("Added Child Bucket " + childBucket);
                if (!childBucket.getTracfoneOneCarrierProfileChildTiers().isEmpty()) {
                    List<TracfoneOneCarrierProfileChildTier> childBucketTiers = childBucket.getTracfoneOneCarrierProfileChildTiers();
                    for (TracfoneOneCarrierProfileChildTier childBucketTier : childBucketTiers) {
                        // Get the carrier profile child bucket tier id from the sequence
                        childBucketTier.setObjId(getNextSequenceId(con, TRACFONE_CHILD_BUCKET_TIER_SEQ_STMT, "CHILD_BUCKET_TIERID_SEQ"));
                        childBucketTier.setCarrierProfileChildObjId(childBucketObjId);
                        setChildBucketTierQueryParameters(cpChildBucketTierStmt, childBucketTier);
                        cpChildBucketTierStmt.addBatch();
                    }
                    cpChildBucketTierStmt.executeBatch();
                    LOGGER.info("Added Child Bucket tiers " + childBucketTiers);
                }
            }
        }
    }

    private void setChildBucketQueryParameters(PreparedStatement stmt, TracfoneOneCarrierProfileChildBucket carrierProfileChildBucket) throws SQLException {
        int index = 1;
        stmt.setLong(index++, Long.valueOf(carrierProfileChildBucket.getObjId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileChildBucket.getProfileId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileChildBucket.getServicePlanId()));
        stmt.setString(index++, carrierProfileChildBucket.getChildPlanId());
        stmt.setString(index++, carrierProfileChildBucket.getBucketId());
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getBucketValue())) {
            stmt.setLong(index++, Long.valueOf(carrierProfileChildBucket.getBucketValue()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getUnitOfMeasure())) {
            stmt.setString(index++, carrierProfileChildBucket.getUnitOfMeasure());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getBucketType())) {
            stmt.setString(index++, carrierProfileChildBucket.getBucketType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getBucketGroup())) {
            stmt.setString(index++, carrierProfileChildBucket.getBucketGroup());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getBucketRequirement())) {
            stmt.setString(index++, carrierProfileChildBucket.getBucketRequirement());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        stmt.setString(index++, carrierProfileChildBucket.getActiveFlag().toUpperCase());
        stmt.setString(index++, carrierProfileChildBucket.getAutoRenewFlag());
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getAutoRenewFrequency())) {
            stmt.setString(index++, carrierProfileChildBucket.getAutoRenewFrequency());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getAutoRenewValue())) {
            stmt.setString(index++, carrierProfileChildBucket.getAutoRenewValue());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getAutoRenewDay())) {
            stmt.setString(index++, carrierProfileChildBucket.getAutoRenewDay());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getBenefitType())) {
            stmt.setString(index++, carrierProfileChildBucket.getBenefitType());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getHideUbiFlag())) {
            stmt.setString(index++, carrierProfileChildBucket.getHideUbiFlag());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildBucket.getPriority())) {
            stmt.setLong(index, Long.valueOf(carrierProfileChildBucket.getPriority()));
        } else {
            stmt.setNull(index, Types.INTEGER);
        }
    }

    private void setChildBucketTierQueryParameters(PreparedStatement stmt, TracfoneOneCarrierProfileChildTier carrierProfileChildTier) throws SQLException {
        int index = 1;
        stmt.setLong(index++, Long.valueOf(carrierProfileChildTier.getObjId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileChildTier.getCarrierProfileChildObjId()));
        stmt.setLong(index++, Long.valueOf(carrierProfileChildTier.getUsageTierId()));
        if (!StringUtils.isNullOrEmpty(carrierProfileChildTier.getTierDescription())) {
            stmt.setString(index++, carrierProfileChildTier.getTierDescription());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildTier.getTierValue())) {
            stmt.setLong(index++, Long.valueOf(carrierProfileChildTier.getTierValue()));
        } else {
            stmt.setNull(index++, Types.INTEGER);
        }
        if (!StringUtils.isNullOrEmpty(carrierProfileChildTier.getTierBehavior())) {
            stmt.setString(index, carrierProfileChildTier.getTierBehavior());
        } else {
            stmt.setNull(index, Types.VARCHAR);
        }
    }

    @Override
    public List<TFOneCarrierFeature> searchCarrierFeaturesForUpdate(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        String queryForProfileAndBucket = getSearchStatementForProfileAndBucket(tfCarrierFeatureModel);
        try (Connection con = dbControllerEJB.getDataSource(tfCarrierFeatureModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchStatement(tfCarrierFeatureModel, queryForProfileAndBucket));) {
            setSearchCFParametersForUpdate(tfCarrierFeatureModel, stmt);

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    TFOneCarrierFeature tfOneCarrierFeature = setCarrierFeature(resultSet);
                    tfOneCarrierFeature.setBrand(resultSet.getString("BRAND"));

                    TFOneServicePlanCarrierFeature tfOneServicePlanCarrierFeature = new TFOneServicePlanCarrierFeature();
                    tfOneServicePlanCarrierFeature.setPriority(resultSet.getString("PRIORITY"));
                    tfOneServicePlanCarrierFeature.setServicePlanId(resultSet.getString("X_SERVICE_PLAN_ID"));
                    tfOneCarrierFeature.setServicePlanCarrierFeature(tfOneServicePlanCarrierFeature);

                    carrierFeatures.add(tfOneCarrierFeature);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException ex) {
            LOGGER.error(TRACFONE_SEARCH_CARRIER_FEATURES_ERROR_MESSAGE, ex);
            throw new TracfoneOneException(TRACFONE_SEARCH_CARRIER_FEATURES_ERROR,
                    TRACFONE_SEARCH_CARRIER_FEATURES_ERROR_MESSAGE, ex);
        }
        return carrierFeatures;
    }

    @Override
    public List<TFOneRatePlan> getCarrierRatePlans(String dbEnv, String carrierName) throws TracfoneOneException {
        List<TFOneRatePlan> tfAllRatePlans = new ArrayList<>();
        TFOneRatePlan tfOneRatePlan;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_VIEW_ALL_CF_RATEPLAN);) {
            stmt.setString(1, carrierName);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneRatePlan = new TFOneRatePlan();
                    tfOneRatePlan.setObjId(resultSet.getString(OBJID));
                    tfOneRatePlan.setRatePlanName(resultSet.getString(X_RATE_PLAN));
                    tfAllRatePlans.add(tfOneRatePlan);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfAllRatePlans;
    }

    @Override
    public List<String> duplicateCarrierFeatures(TracfoneOneCarrierFeature tfCarrierFeature) throws TracfoneOneException {
        List<String> objIds = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(tfCarrierFeature.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getDuplicateCarrierFeatureStatement(tfCarrierFeature));) {
            setDuplicateCarrierFeatureParams(tfCarrierFeature, stmt);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    objIds.add(resultSet.getString(OBJID));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return objIds;
    }

    @Override
    public List<TFOneCarrierFeature> getCarrierFeatureMap(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws TracfoneOneException {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(tfCarrierFeatureModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getCarrierFeatureMapStatement(tfCarrierFeatureModel));) {
            int index = 1;
            stmt.setString(index++, tfCarrierFeatureModel.getCarrierName());
            stmt.setLong(index++, Long.valueOf(tfCarrierFeatureModel.getServicePlanId()));

            try (ResultSet resultSet = stmt.executeQuery();) {
                List<String> orderBy = tfCarrierFeatureModel.getOrderBy();
                while (resultSet.next()) {
                    TFOneCarrierFeature tfOneCarrierFeature = new TFOneCarrierFeature();
                    if (orderBy.contains(X_DATA)) {
                        tfOneCarrierFeature.setxData(resultSet.getString(X_DATA));
                    }
                    if (orderBy.contains(X_RATE_PLAN)) {
                        tfOneCarrierFeature.setxRatePlan(resultSet.getString(X_RATE_PLAN));
                    }
                    if (orderBy.contains(X_FEATURE2X_CARRIER)) {
                        tfOneCarrierFeature.setxFeature2xCarrier(resultSet.getString(X_FEATURE2X_CARRIER));
                    }
                    // mtm sp carrier features
                    carrierFeatures.add(tfOneCarrierFeature);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return carrierFeatures;
    }

    private String getCarrierFeatureMapStatement(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) {

        List<String> orderBy = tfCarrierFeatureModel.getOrderBy();
        StringBuilder mapQuery = new StringBuilder();
        String columns = null;
        if (!orderBy.isEmpty()) {
            for (String columnName : orderBy) {
                mapQuery.append("CF.").append(columnName).append(COMMA);
            }
            columns = mapQuery.substring(0, mapQuery.lastIndexOf(COMMA));
        }

        mapQuery = new StringBuilder("SELECT DISTINCT ").append(columns);
        String searchQuery = TRACFONE_SEARCH_CARRIER_FEATURE_MAP;
        if (tfCarrierFeatureModel.isLegacy()) {
            searchQuery = TRACFONE_SEARCH_LEGACY_CARRIER_FEATURE_MAP;
        }
        mapQuery.append(searchQuery).append(columns);

        LOGGER.info("Search Carrier Features Query is" + mapQuery.toString());
        return mapQuery.toString();
    }

    private String getDuplicateCarrierFeatureStatement(TracfoneOneCarrierFeature tfCarrierFeature) {
        String searchQuery = TRACFONE_DUPLICATE_CARRIER_FEATURE;
        if (tfCarrierFeature.isLegacy()) {
            searchQuery = TRACFONE_DUPLICATE_LEGACY_CARRIER_FEATURE;
        }

        StringBuilder builder = new StringBuilder(searchQuery);
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getServicePlanCarrierFeature().getServicePlanId())) {
            builder.append("mtm.x_service_plan_id = ? ");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getServicePlanCarrierFeature().getPriority())) {
            builder.append("mtm.priority = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxData())) {
            builder.append("cf.X_DATA = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxFeature2xCarrier())) {
            builder.append("cf.X_FEATURE2X_CARRIER = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxFeatures2BusOrg())) {
            builder.append("cf.X_FEATURES2BUS_ORG = ?");
            builder.append(AND);
        }

        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("What is the duplicate check query: " + searchQuery);
        return searchQuery;
    }

    private void setDuplicateCarrierFeatureParams(TracfoneOneCarrierFeature tfCarrierFeature, PreparedStatement stmt) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getServicePlanCarrierFeature().getServicePlanId())) {
            stmt.setString(index++, tfCarrierFeature.getServicePlanCarrierFeature().getServicePlanId());
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getServicePlanCarrierFeature().getPriority())) {
            stmt.setString(index++, tfCarrierFeature.getServicePlanCarrierFeature().getPriority());
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxData())) {
            stmt.setString(index++, tfCarrierFeature.getxData());
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxFeature2xCarrier())) {
            stmt.setString(index++, tfCarrierFeature.getxFeature2xCarrier());
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeature.getxFeatures2BusOrg())) {
            stmt.setString(index, tfCarrierFeature.getxFeatures2BusOrg());
        }
    }

    private void setSearchCFParametersForUpdate(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel, PreparedStatement stmt) throws SQLException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tfCarrierFeatureModel.getCarrierName())) {
            stmt.setString(index++, tfCarrierFeatureModel.getCarrierName());
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeatureModel.getServicePlanId())) {
            stmt.setString(index++, tfCarrierFeatureModel.getServicePlanId());
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeatureModel.getTracfoneOneCarrierFeature().getServicePlanCarrierFeature().getPriority())) {
            stmt.setString(index++, tfCarrierFeatureModel.getTracfoneOneCarrierFeature().getServicePlanCarrierFeature().getPriority());
        }
        setCarrierFeatureSearchQueryParams(stmt, index, tfCarrierFeatureModel);
    }

    private String getSearchStatementForProfileAndBucket(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_GET_ALL_ASSOCIATED_CARRIER_FEATURE_OBJID);
        if (!StringUtils.isNullOrEmpty(tfCarrierFeatureModel.getProfileId())) {
            builder.append("p.profile_id = ? ");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeatureModel.getProfileDesc())) {
            builder.append("UPPER(p.profile_desc) LIKE ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeatureModel.getBucketId())) {
            builder.append("(b.bucket_id = ? or cb.bucket_id = ?)");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeatureModel.getBucketRequirement())) {
            builder.append("(b.bucket_requirement = ? or cb.bucket_requirement = ?)");
            builder.append(AND);
        }

        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND)).concat(")");
        }
        LOGGER.info("What is the search query for update: " + searchQuery);
        return searchQuery;
    }

    private String getSearchStatement(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel, String queryForProfileAndBucket) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        String query = null;
        String searchQuery = TRACFONE_SEARCH_CARRIER_FEATURE_FOR_UPDATE;
        if (tfCarrierFeatureModel.isLegacy()) {
            searchQuery = TRACFONE_SEARCH_LEGACY_CARRIER_FEATURE_FOR_UPDATE;
        }
        StringBuilder builder = new StringBuilder(searchQuery);
        if (!StringUtils.isNullOrEmpty(tfCarrierFeatureModel.getServicePlanId())) {
            builder.append("mtm.x_service_plan_id = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfCarrierFeatureModel.getTracfoneOneCarrierFeature().getServicePlanCarrierFeature().getPriority())) {
            builder.append("mtm.priority = ?");
            builder.append(AND);
        }

        generateSearchCarrierFeatureQuery(builder, tfCarrierFeatureModel.getTracfoneOneCarrierFeature());

        if (!StringUtils.isNullOrEmpty(queryForProfileAndBucket)) {
            query = builder.append(queryForProfileAndBucket).toString();
        } else {
            query = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Search Carrier Features Query is " + query);
        return query;
    }

}
