package com.tracfone.service.model.request;

/**
 * COP.COP_USER_TASK_DETAIL
 *
 * @author Pritesh.Singh
 */
public class TracfoneOneUserTaskDetail {
    private String id;
    private String userTaskId;
    private String taskDetails;
    private String userComments;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserTaskId() {
        return userTaskId;
    }

    public void setUserTaskId(String userTaskId) {
        this.userTaskId = userTaskId;
    }

    public String getTaskDetails() {
        return taskDetails;
    }

    public void setTaskDetails(String taskDetails) {
        this.taskDetails = taskDetails;
    }

    public String getUserComments() {
        return userComments;
    }

    public void setUserComments(String userComments) {
        this.userComments = userComments;
    }

    @Override
    public String toString() {
        return "TracfoneOneUserTaskDetail{" +
                "id='" + id + '\'' +
                ", userTaskId='" + userTaskId + '\'' +
                ", taskDetails='" + taskDetails + '\'' +
                ", userComments='" + userComments + '\'' +
                '}';
    }
}
