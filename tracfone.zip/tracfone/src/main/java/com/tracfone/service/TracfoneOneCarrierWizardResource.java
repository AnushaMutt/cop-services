package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneCarrierMaintenanceControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.controller.TracfoneRatePlanControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneArUsaMarket;
import com.tracfone.service.model.request.TracfoneOneArUsaPostalZips;
import com.tracfone.service.model.request.TracfoneOneCarrier;
import com.tracfone.service.model.request.TracfoneOneCarrierGroup;
import com.tracfone.service.model.request.TracfoneOneCarrierPref;
import com.tracfone.service.model.request.TracfoneOneCarrierRule;
import com.tracfone.service.model.request.TracfoneOneCarrierSimPref;
import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;
import com.tracfone.service.model.request.TracfoneOneDataConfig;
import com.tracfone.service.model.request.TracfoneOneDataConfigMapping;
import com.tracfone.service.model.request.TracfoneOneGeoLoc;
import com.tracfone.service.model.request.TracfoneOneIgOrderType;
import com.tracfone.service.model.request.TracfoneOneNotCertifyModel;
import com.tracfone.service.model.request.TracfoneOneNpanxx2Carrierzones;
import com.tracfone.service.model.request.TracfoneOneOrderType;
import com.tracfone.service.model.request.TracfoneOneParent;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneThrottleFeature;
import com.tracfone.service.model.request.TracfoneOneThrottlePolicy;
import com.tracfone.service.model.request.TracfoneOneThrottleRule;
import com.tracfone.service.model.request.TracfoneOneTmoZipNgp;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.request.TracfoneOneVerizonZipNPANXX;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneArUsaMarketSearchResult;
import com.tracfone.service.model.response.TFOneArUsaPostalZips;
import com.tracfone.service.model.response.TFOneBulkInsertReport;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierGroup;
import com.tracfone.service.model.response.TFOneCarrierPref;
import com.tracfone.service.model.response.TFOneCarrierRule;
import com.tracfone.service.model.response.TFOneCarrierZones;
import com.tracfone.service.model.response.TFOneCarriersimpref;
import com.tracfone.service.model.response.TFOneCingularMrktInfo;
import com.tracfone.service.model.response.TFOneDataConfig;
import com.tracfone.service.model.response.TFOneDataConfigMapping;
import com.tracfone.service.model.response.TFOneDatabaseEnvironment;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneGeoLoc;
import com.tracfone.service.model.response.TFOneIgOrderType;
import com.tracfone.service.model.response.TFOneNotCertifyModel;
import com.tracfone.service.model.response.TFOneNpaNxx2CarrierZonesSearchResult;
import com.tracfone.service.model.response.TFOneOrderType;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOnePartClass;
import com.tracfone.service.model.response.TFOneThrottleFeature;
import com.tracfone.service.model.response.TFOneThrottlePolicy;
import com.tracfone.service.model.response.TFOneThrottleRule;
import com.tracfone.service.model.response.TFOneTmoZipNgp;
import com.tracfone.service.model.response.TFOneVerizonZipNPANXX;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.validation.Valid;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.BULK_AR_USA_MARKET_INSERT;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.BULK_AR_USA_POSTAL_ZIPS_INSERT;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.BULK_CARRIERPREF_INSERT;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.BULK_CARRIERZONES_INSERT;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.BULK_NPANXX2CARRIERZONES_INSERT;
import static com.tracfone.service.util.TracfoneOneConstantPlanWizard.BULK_GEO_LOC_INSERT;

/**
 * This resource file is going to be used for all services in the Carrier Maintenance Wizard
 *
 * @author Pritesh Singh
 */
@Path("carrier")
public class TracfoneOneCarrierWizardResource {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneCarrierWizardResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @EJB
    private TracfoneCarrierMaintenanceControllerLocal tracfoneCarrierMaintenanceController;

    @EJB
    private TracfoneControllerLocal tracfoneController;

    @EJB
    private TracfoneRatePlanControllerLocal tracfoneRatePlanController;

    @EJB
    private TracfoneControllerLocalAction tracfoneControllerAction;

    @Context
    private SecurityContext securityContext;

    @GET
    @Path("carriermaintenance/dbenvs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    public Response getDatabaseEnvironments() {
        List<TFOneDatabaseEnvironment> tfOneDatabaseEnvironment = null;
        Response response = null;
        try {
            tfOneDatabaseEnvironment = tracfoneController.getDatabaseEnvironments(getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        response = Response.ok(gson.toJson(tfOneDatabaseEnvironment), MediaType.APPLICATION_JSON).build();
        return response;
    }

    /**
     * This method is used to search table_x_parent based on
     * X_PARENT_NAME(like search), X_PARENT_ID & X_STATUS
     *
     * @param tracfoneOneParent
     * @return
     */
    @POST
    @Path("carriermaintenance/searchparent")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchParent(final TracfoneOneParent tracfoneOneParent) {
        List<TFOneParent> tfOneParents = null;
        try {
            tfOneParents = tracfoneCarrierMaintenanceController.searchParent(tracfoneOneParent);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneParents), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search all carriers groups based on X_CARRIER_GROUP2X_PARENT,
     * X_CARRIER_GROUP_ID, X_CARRIER_NAME, X_STATUS
     * table_x_carrier_group
     *
     * @param tracfoneOneCarrierGroup
     * @return
     */
    @POST
    @Path("carriermaintenance/searchcarriergroups")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierGroups(final TracfoneOneCarrierGroup tracfoneOneCarrierGroup) {
        List<TFOneCarrierGroup> carrierGroups = new ArrayList<>();
        try {
            carrierGroups = tracfoneCarrierMaintenanceController.searchCarrierGroups(tracfoneOneCarrierGroup);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierGroups), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search table_x_carrier based on
     * X_MKT_SUBMKT_NAME(like search), X_CARRIER_ID & X_STATUS
     *
     * @param tracfoneOneCarrier
     * @return
     */
    @POST
    @Path("carriermaintenance/searchcarrier")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrier(final TracfoneOneCarrier tracfoneOneCarrier) {
        List<TFOneCarrier> tfOneCarriers = null;
        try {
            tfOneCarriers = tracfoneCarrierMaintenanceController.searchCarrier(tracfoneOneCarrier);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneCarriers), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all X_CARRIER_RULES based on search on all columns
     *
     * @param tracfoneOneCarrierRule
     * @return
     */
    @POST
    @Path("carriermaintenance/searchcarrierrules")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierRules(final TracfoneOneCarrierRule tracfoneOneCarrierRule) {
        List<TFOneCarrierRule> tfOneCarrierRules = new ArrayList<>();
        try {
            tfOneCarrierRules = tracfoneCarrierMaintenanceController.searchCarrierRules(tracfoneOneCarrierRule);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneCarrierRules), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all order types based on X_ORDER_TYPE2X_CARRIER
     * TABLE_X_ORDER_TYPE
     *
     * @param tracfoneOneOrderType
     * @return
     */
    @POST
    @Path("carriermaintenance/searchordertypes")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchOrderTypes(final TracfoneOneOrderType tracfoneOneOrderType) {
        List<TFOneOrderType> orderTypes = new ArrayList<>();
        try {
            orderTypes = tracfoneCarrierMaintenanceController.searchOrderTypes(tracfoneOneOrderType);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(orderTypes), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search data_config_mapping  based on any column
     *
     * @param tfDataConfigMapping
     * @return
     */
    @POST
    @Path("carriermaintenance/searchdataconfigmapping")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchDataConfigMapping(final TracfoneOneDataConfigMapping tfDataConfigMapping) {
        List<TFOneDataConfigMapping> tfOneDataConfigMappings = new ArrayList<>();
        try {
            tfOneDataConfigMappings = tracfoneCarrierMaintenanceController.searchDataConfigMapping(tfDataConfigMapping);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneDataConfigMappings), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a record in data_config_mapping table
     *
     * @param tfDataConfigMapping
     * @return
     */
    @POST
    @Path("carriermaintenance/adddataconfigmapping")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertDataConfigMapping(@Valid final TracfoneOneDataConfigMapping tfDataConfigMapping) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertDataConfigMapping(tfDataConfigMapping,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete a record in data_config_mapping table based on every column
     *
     * @param tfDataConfigMapping
     * @return
     */
    @POST
    @Path("carriermaintenance/deletedataconfigmapping")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteDataConfigMapping(final TracfoneOneDataConfigMapping tfDataConfigMapping) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.deleteDataConfigMapping(tfDataConfigMapping,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a record in data_config_mapping
     *
     * @param tfDataConfigMapping
     * @return
     */
    @POST
    @Path("carriermaintenance/updatedataconfigmapping")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateDataConfigMapping(@Valid final TracfoneOneDataConfigMapping tfDataConfigMapping) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateDataConfigMapping(tfDataConfigMapping,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update table_x_parent based on objId
     *
     * @param tracfoneOneParent
     * @return
     */
    @POST
    @Path("carriermaintenance/updateparent")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateParent(@Valid TracfoneOneParent tracfoneOneParent) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateParent(tracfoneOneParent, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update table_x_carrier_group based on objId
     *
     * @param tracfoneOneCarrierGroup
     * @return
     */
    @POST
    @Path("carriermaintenance/updatecarriergroup")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrierGroup(@Valid TracfoneOneCarrierGroup tracfoneOneCarrierGroup) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateCarrierGroup(tracfoneOneCarrierGroup, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update table_x_carrier based on objId
     *
     * @param tracfoneOneCarrier
     * @return
     */
    @POST
    @Path("carriermaintenance/updatecarrier")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrier(@Valid final TracfoneOneCarrier tracfoneOneCarrier) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateCarrier(tracfoneOneCarrier, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update TABLE_X_CARRIER_RULES based on objId
     *
     * @param tracfoneOneCarrierRule
     * @return
     */
    @POST
    @Path("carriermaintenance/updatecarrierrule")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrierRule(@Valid TracfoneOneCarrierRule tracfoneOneCarrierRule) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateCarrierRule(tracfoneOneCarrierRule, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update TABLE_X_ORDER_TYPE based on objId
     *
     * @param tracfoneOneOrderType
     * @return
     */
    @POST
    @Path("carriermaintenance/updateordertype")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateOrderType(@Valid TracfoneOneOrderType tracfoneOneOrderType) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateOrderType(tracfoneOneOrderType, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete TABLE_X_ORDER_TYPE based on objId
     *
     * @param tracfoneOneOrderType
     * @return
     */
    @POST
    @Path("carriermaintenance/deleteordertype")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteOrderType(@Valid TracfoneOneOrderType tracfoneOneOrderType) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.deleteOrderType(tracfoneOneOrderType, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert a record in  table_x_parent
     *
     * @param tracfoneOneParent
     * @return
     */
    @POST
    @Path("carriermaintenance/addparent")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertParent(@Valid TracfoneOneParent tracfoneOneParent) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertParent(tracfoneOneParent, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert records in  table_x_carrier_group
     *
     * @param tracfoneOneCarrierGroups
     * @return
     */
    @POST
    @Path("carriermaintenance/addcarriergroups")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarrierGroups(@Valid final List<TracfoneOneCarrierGroup> tracfoneOneCarrierGroups) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertCarrierGroups(tracfoneOneCarrierGroups, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert records in table table_x_carrier
     *
     * @param tracfoneOneCarriers
     * @return
     */
    @POST
    @Path("carriermaintenance/addcarriers")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarriers(@Valid final List<TracfoneOneCarrier> tracfoneOneCarriers) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertCarriers(tracfoneOneCarriers, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert a record  in table TABLE_X_CARRIER_RULES
     *
     * @param tracfoneOneCarrierRule
     * @return
     */
    @POST
    @Path("carriermaintenance/addcarrierrule")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarrierRule(@Valid TracfoneOneCarrierRule tracfoneOneCarrierRule) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertCarrierRule(tracfoneOneCarrierRule, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert records in table TABLE_X_ORDER_TYPE
     *
     * @param tracfoneOneOrderTypes
     * @return
     */
    @POST
    @Path("carriermaintenance/addordertype")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertOrderType(@Valid List<TracfoneOneOrderType> tracfoneOneOrderTypes) {
        List<TFOneOrderType> tfOneOrderTypes = new ArrayList<>();
        try {
            tfOneOrderTypes = tracfoneCarrierMaintenanceController.insertOrderType(tracfoneOneOrderTypes, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneOrderTypes), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve records from TABLE_X_DATA_CONFIG based on any column
     *
     * @param tracfoneOneDataConfig
     * @return
     */
    @POST
    @Path("carriermaintenance/searchdataconfigs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchDataConfigs(TracfoneOneDataConfig tracfoneOneDataConfig) {
        List<TFOneDataConfig> dataConfigs = new ArrayList<>();
        try {
            dataConfigs = tracfoneCarrierMaintenanceController.searchDataConfigs(tracfoneOneDataConfig);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(dataConfigs), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all OBJID from table TABLE_PART_CLASS for the drop down
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("carriermaintenance/viewpartclasses")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllPartClasses(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOnePartClass> allPartClasses = new ArrayList<>();
        try {
            allPartClasses = tracfoneCarrierMaintenanceController.getAllPartClasses(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(allPartClasses), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all parent names for the drop down in add
     * apn screen based on the carrier selected in Step 1
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("carriermaintenance/viewparentnames")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllParentNames(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneParent> allParents = new ArrayList<>();
        try {
            allParents = tracfoneRatePlanController.getAllParentNames(tracfoneOneSearchPlanModel.getDbEnv(),
                    tracfoneOneSearchPlanModel.getCarrierName());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(allParents), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert a record in  X_IG_ORDER_TYPE
     *
     * @param tracfoneOneIgOrderType
     * @return
     */
    @POST
    @Path("carriermaintenance/addigordertypes")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertIgOrderTypes(@Valid final TracfoneOneIgOrderType tracfoneOneIgOrderType) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertIgOrderTypes(tracfoneOneIgOrderType, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update X_IG_ORDER_TYPE table
     *
     * @param tracfoneOneIgOrderType
     * @return
     */
    @POST
    @Path("carriermaintenance/updateigordertypes")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateIgOrderTypes(@Valid final TracfoneOneIgOrderType tracfoneOneIgOrderType) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateIgOrderTypes(tracfoneOneIgOrderType,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search X_IG_ORDER_TYPE
     *
     * @param tracfoneOneIgOrderType
     * @return
     */
    @POST
    @Path("carriermaintenance/searchigordertypes")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchIgOrderTypes(final TracfoneOneIgOrderType tracfoneOneIgOrderType) {
        List<TFOneIgOrderType> tfOneIGOrderType = null;
        try {
            tfOneIGOrderType = tracfoneCarrierMaintenanceController.searchIgOrderTypes(tracfoneOneIgOrderType, false);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneIGOrderType), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add new Throttle Policy
     *
     * @param tracfoneOneThrottlePolicy
     * @return
     */
    @POST
    @Path("carriermaintenance/addthrottlepolicy")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertThrottlePolicy(@Valid final TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertThrottlePolicy(tracfoneOneThrottlePolicy,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add new Throttle Rules
     *
     * @param tracfoneOneThrottleRules
     * @return
     */
    @POST
    @Path("carriermaintenance/addthrottlerules")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertThrottleRules(@Valid final List<TracfoneOneThrottleRule> tracfoneOneThrottleRules) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertThrottleRules(tracfoneOneThrottleRules,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add new Throttle Features
     *
     * @param tracfoneOneThrottleFeatures
     * @return
     */
    @POST
    @Path("carriermaintenance/addthrottlefeatures")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertThrottleFeatures(@Valid final List<TracfoneOneThrottleFeature> tracfoneOneThrottleFeatures) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertThrottleFeatures(tracfoneOneThrottleFeatures,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search TABLE_X_THROTTLING_POLICY
     *
     * @param tracfoneOneThrottlePolicy
     * @return
     */
    @POST
    @Path("carriermaintenance/searchthrottlepolicies")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchThrottlePolicies(final TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy) {
        List<TFOneThrottlePolicy> tfOneThrottlePolicy = null;
        try {
            tfOneThrottlePolicy = tracfoneCarrierMaintenanceController.searchThrottlePolicies(tracfoneOneThrottlePolicy);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneThrottlePolicy), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search TABLE_X_THROTTLING_RULE
     *
     * @param tracfoneOneThrottleRule
     * @return
     */
    @POST
    @Path("carriermaintenance/searchthrottlerules")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchThrottleRules(final TracfoneOneThrottleRule tracfoneOneThrottleRule) {
        List<TFOneThrottleRule> tfOneThrottleRule = null;
        try {
            tfOneThrottleRule = tracfoneCarrierMaintenanceController.searchThrottleRules(tracfoneOneThrottleRule);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneThrottleRule), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search TABLE_X_THROTTLING_FEATURES
     *
     * @param tracfoneOneThrottleFeature
     * @return
     */
    @POST
    @Path("carriermaintenance/searchthrottlefeatures")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchThrottleFeatures(final TracfoneOneThrottleFeature tracfoneOneThrottleFeature) {
        List<TFOneThrottleFeature> tfOneThrottleFeatures = null;
        try {
            tfOneThrottleFeatures = tracfoneCarrierMaintenanceController.searchThrottleFeatures(tracfoneOneThrottleFeature);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneThrottleFeatures), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update TABLE_X_THROTTLING_POLICY table
     *
     * @param tracfoneOneThrottlePolicy
     * @return
     */
    @POST
    @Path("carriermaintenance/updatethrottlepolicy")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateThrottlePolicy(@Valid final TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateThrottlePolicy(tracfoneOneThrottlePolicy,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update TABLE_X_THROTTLING_RULE table
     *
     * @param tracfoneOneThrottleRule
     * @return
     */
    @POST
    @Path("carriermaintenance/updatethrottlerule")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateThrottleRule(@Valid final TracfoneOneThrottleRule tracfoneOneThrottleRule) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateThrottleRule(tracfoneOneThrottleRule,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update TABLE_X_THROTTLING_FEATURES table
     *
     * @param tracfoneOneThrottleFeature
     * @return
     */
    @POST
    @Path("carriermaintenance/updatethrottlefeature")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateThrottleFeature(@Valid final TracfoneOneThrottleFeature tracfoneOneThrottleFeature) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateThrottleFeature(tracfoneOneThrottleFeature,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }


    /**
     * This method is used to search X_VERIZON_ZIP_NPANXX
     *
     * @param tracfoneOneVerizonZipNPANXX
     * @return
     */
    @POST
    @Path("carriermaintenance/searchverizonzipnpanxx")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchVerizonZipNPANXX(final TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX) {
        List<TFOneVerizonZipNPANXX> tfOneVerizonZipNPANXX = null;
        try {
            tfOneVerizonZipNPANXX = tracfoneCarrierMaintenanceController.searchVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneVerizonZipNPANXX), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert into X_VERIZON_ZIP_NPANXX
     *
     * @param tracfoneOneVerizonZipNPANXX
     * @return
     */
    @POST
    @Path("carriermaintenance/addverizonzipnpanxx")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertVerizonZipNPANXX(@Valid TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update X_VERIZON_ZIP_NPANXX table
     *
     * @param tracfoneOneVerizonZipNPANXX
     * @return
     */
    @POST
    @Path("carriermaintenance/updateverizonzipnpanxx")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateVerizonZipNPANXX(@Valid final TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete a record in X_VERIZON_ZIP_NPANXX table
     *
     * @param tracfoneOneVerizonZipNPANXX
     * @return
     */
    @POST
    @Path("carriermaintenance/deleteverizonzipnpanxx")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteVerizonZipNPANXX(final TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.deleteVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method will be used to bulk insert X_VERIZON_ZIP_NPANXX based on a csv upload
     *
     * @param tracfoneOneVerizonZipNPANXX
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkinsertverizonzipnpanxx")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertVerizonZipNPANXX(List<TracfoneOneVerizonZipNPANXX> tracfoneOneVerizonZipNPANXX) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkInsertVerizonZipNPANXX(tracfoneOneVerizonZipNPANXX,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/bulkinsertvznsummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertVznSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(),
                    "Bulk Verizon ZIP NPANXX Insert",
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/geterrorrecorddetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        try {
            tracfoneOneUserHistory.setType("Bulk Verizon ZIP NPANXX Insert");
            summary = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(summary), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search x_tmo_zip_ngp
     *
     * @param tracfoneOneTmoZipNgp
     * @return
     */
    @POST
    @Path("carriermaintenance/searchtmozipngp")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchTmoZipNgp(final TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp) {
        List<TFOneTmoZipNgp> tfOneTmoZipNgp = null;
        try {
            tfOneTmoZipNgp = tracfoneCarrierMaintenanceController.searchTmoZipNgp(tracfoneOneTmoZipNgp);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneTmoZipNgp), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert into x_tmo_zip_ngp
     *
     * @param tracfoneOneTmoZipNgp
     * @return
     */
    @POST
    @Path("carriermaintenance/addtmozipngp")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertTmoZipNgp(@Valid TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertTmoZipNgp(tracfoneOneTmoZipNgp, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update x_tmo_zip_ngp table
     *
     * @param tracfoneOneTmoZipNgp
     * @return
     */
    @POST
    @Path("carriermaintenance/updatetmozipngp")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateTmoZipNgp(@Valid final TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateTmoZipNgp(tracfoneOneTmoZipNgp,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete a record in x_tmo_zip_ngp table
     *
     * @param tracfoneOneTmoZipNgp
     * @return
     */
    @POST
    @Path("carriermaintenance/deletetmozipngp")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteTmoZipNgp(final TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.deleteTmoZipNgp(tracfoneOneTmoZipNgp,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method will be used to bulk insert x_tmo_zip_ngp based on a csv upload
     *
     * @param tracfoneOneTmoZipNgp
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkinserttmozipngp")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertTmoZipNgp(List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNgp) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkInsertTmoZipNgp(tracfoneOneTmoZipNgp,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/bulkinserttmozipngpsummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertTmoZipNgpSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(),
                    "Bulk TMO ZIP NGP Insert",
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/gettmozipngperrorrecords")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getTmoZipNgpErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        try {
            tracfoneOneUserHistory.setType("Bulk TMO ZIP NGP Insert");
            summary = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(summary), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search X_CINGULAR_MRKT_INFO
     *
     * @param tracfoneOneCingularMrktInfo
     * @return
     */
    @POST
    @Path("carriermaintenance/searchcingularmrktinfo")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCingularMrktInfo(final TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo) {
        List<TFOneCingularMrktInfo> tfOneCingularMrktInfo = null;
        try {
            tfOneCingularMrktInfo = tracfoneCarrierMaintenanceController.searchCingularMrktInfo(tracfoneOneCingularMrktInfo);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneCingularMrktInfo), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert into X_CINGULAR_MRKT_INFO
     *
     * @param tracfoneOneCingularMrktInfo
     * @return
     */
    @POST
    @Path("carriermaintenance/addcingulatmrktinfo")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCingularMrktInfo(@Valid TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertCingularMrktInfo(tracfoneOneCingularMrktInfo, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update X_CINGULAR_MRKT_INFO table
     *
     * @param tracfoneOneCingularMrktInfo
     * @return
     */
    @POST
    @Path("carriermaintenance/updatecingulatmrktinfo")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCingularMrktInfo(@Valid final TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateCingularMrktInfo(tracfoneOneCingularMrktInfo,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete a record in X_CINGULAR_MRKT_INFO table
     *
     * @param tracfoneOneCingularMrktInfo
     * @return
     */
    @POST
    @Path("carriermaintenance/deletecingulatmrktinfo")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteCingularMrktInfo(final TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.deleteCingularMrktInfo(tracfoneOneCingularMrktInfo,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method will be used to bulk insert X_CINGULAR_MRKT_INFO based on a csv upload
     *
     * @param tracfoneOneCingularMrktInfo
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkinsertcingularmrktinfo")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertCingularMrktInfo(List<TracfoneOneCingularMrktInfo> tracfoneOneCingularMrktInfo) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkInsertCingularMrktInfo(tracfoneOneCingularMrktInfo,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/bulkinsertcingularmrktinfosummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertCingularMrktInfoSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(),
                    "Bulk Cingular Mrkt Info Insert",
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/getcingularmrktinfoerrorrecords")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCingularMrktInfoErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        try {
            tracfoneOneUserHistory.setType("Bulk Cingular Mrkt Info Insert");
            summary = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(summary), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search TABLE_X_NOT_CERTIFY_MODELS
     *
     * @param tracfoneOneNotCertifyModel
     * @return
     */
    @POST
    @Path("carriermaintenance/searchnotcertifymodel")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchNotCertifyModel(final TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel) {
        List<TFOneNotCertifyModel> tfOneCingularMrktInfo = null;
        try {
            tfOneCingularMrktInfo = tracfoneCarrierMaintenanceController.searchNotCertifyModel(tracfoneOneNotCertifyModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneCingularMrktInfo), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert into TABLE_X_NOT_CERTIFY_MODELS
     *
     * @param tracfoneOneNotCertifyModel
     * @return
     */
    @POST
    @Path("carriermaintenance/addnotcertifymodel")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertNotCertifyModel(@Valid TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertNotCertifyModel(tracfoneOneNotCertifyModel, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update TABLE_X_NOT_CERTIFY_MODELS table
     *
     * @param tracfoneOneNotCertifyModel
     * @return
     */
    @POST
    @Path("carriermaintenance/updatenotcertifymodel")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateNotCertifyModel(@Valid final TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateNotCertifyModel(tracfoneOneNotCertifyModel,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete a record in TABLE_X_NOT_CERTIFY_MODELS table
     *
     * @param tracfoneOneNotCertifyModel
     * @return
     */
    @POST
    @Path("carriermaintenance/deletenotcertifymodel")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteNotCertifyModel(final TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.deleteNotCertifyModel(tracfoneOneNotCertifyModel,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method will be used to bulk insert TABLE_X_NOT_CERTIFY_MODELS based on a csv upload
     *
     * @param tracfoneOneNotCertifyModel
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkinsertnotcertifymodel")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertNotCertifyModel(List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModel) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkInsertNotCertifyModel(tracfoneOneNotCertifyModel,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/bulkinsertnotcertifymodelsummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertNotCertifyModelSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(),
                    "Bulk Not Certify Model Insert",
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/getnotcertifymodelerrorrecords")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getNotCertifyModelErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        try {
            tracfoneOneUserHistory.setType("Bulk Not Certify Model Insert");
            summary = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(summary), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to bulk update TABLE_X_NOT_CERTIFY_MODELS table
     *
     * @param tracfoneOneNotCertifyModels
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkupdatenotcertifymodel")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkUpdateNotCertifyModel(@Valid final List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModels) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.bulkUpdateNotCertifyModel(tracfoneOneNotCertifyModels,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/bulkupdatetmozipngp")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkUpdateTmoZipNgp(@Valid final List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNgp) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.bulkUpdateTmoZipNgp(tracfoneOneTmoZipNgp,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search CARRIERSIMPREF
     *
     * @param tracfoneOneCarriersimpref
     * @return
     */
    @POST
    @Path("carriermaintenance/searchcarriersimpref")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierSimPref(final TracfoneOneCarrierSimPref tracfoneOneCarriersimpref) {
        List<TFOneCarriersimpref> tfOneCingularMrktInfo = null;
        try {
            tfOneCingularMrktInfo = tracfoneCarrierMaintenanceController.searchCarrierSimPref(tracfoneOneCarriersimpref);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneCingularMrktInfo), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert into CARRIERSIMPREF
     *
     * @param tracfoneOneCarriersimpref
     * @return
     */
    @POST
    @Path("carriermaintenance/addcarriersimpref")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarrierSimPref(@Valid TracfoneOneCarrierSimPref tracfoneOneCarriersimpref) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertCarrierSimPref(tracfoneOneCarriersimpref, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update CARRIERSIMPREF table
     *
     * @param tracfoneOneCarriersimpref
     * @return
     */
    @POST
    @Path("carriermaintenance/updatecarriersimpref")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrierSimPref(@Valid final TracfoneOneCarrierSimPref tracfoneOneCarriersimpref) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateCarrierSimPref(tracfoneOneCarriersimpref,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete a record in CARRIERSIMPREF table
     *
     * @param tracfoneOneCarriersimpref
     * @return
     */
    @POST
    @Path("carriermaintenance/deletecarriersimpref")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteCarrierSimPref(final TracfoneOneCarrierSimPref tracfoneOneCarriersimpref) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.deleteCarrierSimPref(tracfoneOneCarriersimpref,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method will be used to bulk insert CARRIERSIMPREF based on a csv upload
     *
     * @param tracfoneOneCarriersimpref
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkinsertcarriersimpref")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertCarrierSimPref(List<TracfoneOneCarrierSimPref> tracfoneOneCarriersimpref) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkInsertCarrierSimPref(tracfoneOneCarriersimpref,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to bulk update CARRIERSIMPREF table
     *
     * @param tracfoneOneCarrierSimPrefs
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkupdatecarriersimpref")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkUpdateCarrierSimPref(@Valid final List<TracfoneOneCarrierSimPref> tracfoneOneCarrierSimPrefs) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.bulkUpdateCarrierSimPref(tracfoneOneCarrierSimPrefs,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/bulkinsertcarriersimprefsummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertCarrierSimPrefSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(),
                    "Bulk Carrier sim pref Insert",
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/getcarriersimpreferrorrecords")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierSimPrefErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        try {
            tracfoneOneUserHistory.setType("Bulk Carrier sim pref Insert");
            summary = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(summary), MediaType.APPLICATION_JSON).build();
    }


    /**
     * This method is used to insert into npanxx2carrierzones
     *
     * @param tracfoneOneNpanxx2Carrierzones
     * @return
     */
    @POST
    @Path("carriermaintenance/addnpanxx2Carrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertNpanxx2Carrierzones(@Valid TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search Npanxx2Carrierzones
     *
     * @param tracfoneOneNpanxx2Carrierzones
     * @return
     */
    @POST
    @Path("carriermaintenance/searchnpanxx2Carrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchNpanxx2Carrierzones(final TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) {
        TFOneNpaNxx2CarrierZonesSearchResult tfOneNpaNxx2CarrierZonesSearchResult;
        try {
            tfOneNpaNxx2CarrierZonesSearchResult = tracfoneCarrierMaintenanceController.searchNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneNpaNxx2CarrierZonesSearchResult), MediaType.APPLICATION_JSON).build();
    }


    /**
     * This method is used to delete a record in Npanxx2Carrierzones table
     *
     * @param tracfoneOneNpanxx2Carrierzones
     * @return
     */
    @POST
    @Path("carriermaintenance/deletenpanxx2carrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteNpanxx2Carrierzones(final TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.deleteNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update Npanxx2Carrierzones table
     *
     * @param tracfoneOneNpanxx2Carrierzones
     * @return
     */
    @POST
    @Path("carriermaintenance/updatenpanxx2carrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateNpanxx2Carrierzones(@Valid final TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }


    /**
     * This method will be used to bulk insert Npanxx2Carrierzones table
     *
     * @param tracfoneOneNpanxx2Carrierzones
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkinsertnpanxx2carrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertNpanxx2Carrierzones(List<TracfoneOneNpanxx2Carrierzones> tracfoneOneNpanxx2Carrierzones) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkInsertNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones,
                    getUserFromPrincipal().getUserId(),
                    getUserFromPrincipal().getDescription());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to bulk update Npanxx2Carrierzones table
     *
     * @param tracfoneOneNpanxx2Carrierzones
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkupdatenpanxx2carrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkUpdateNpanxx2Carrierzones(@Valid final List<TracfoneOneNpanxx2Carrierzones> tracfoneOneNpanxx2Carrierzones) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.bulkUpdateNpanxx2Carrierzones(tracfoneOneNpanxx2Carrierzones,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }


    @POST
    @Path("carriermaintenance/bulkinsertnpanxx2carrierzonessummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertNpanxx2CarrierzonesSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(),
                    BULK_NPANXX2CARRIERZONES_INSERT,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/getnpanxx2carrierzoneserrorrecorddetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getNpanxx2CarrierzonesErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        try {
            tracfoneOneUserHistory.setType("Npa nxx 2 Carrierzones Error Record Details");
            summary = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(summary), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is to get AR_USA_POSTAL_ZIPS Details
     *
     * @return
     */
    @POST
    @Path("carriermaintenance/getarusapostalzips")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getArUsaPostalZips(final TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips) {
        List<TFOneArUsaPostalZips> tfOneArUsaPostalZips = new ArrayList<>();
        try {
            tfOneArUsaPostalZips = tracfoneCarrierMaintenanceController.getArUsaPostalZips(tracfoneOneArUsaPostalZips);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneArUsaPostalZips), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add AR_USA_POSTAL_ZIPS details
     *
     * @param tracfoneOneArUsaPostalZips
     * @return
     */
    @POST
    @Path("carriermaintenance/addarusapostalzips")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertArUsaPostalZips(@Valid final TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertArUsaPostalZips(tracfoneOneArUsaPostalZips, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete a record in AR_USA_POSTAL_ZIPS
     *
     * @param tracfoneOneArUsaPostalZips
     * @return
     */
    @POST
    @Path("carriermaintenance/deletearusapostalzips")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteArUsaPostalZips(final TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.deleteArUsaPostalZips(tracfoneOneArUsaPostalZips,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }


    /**
     * This method is used to update a record in AR_USA_POSTAL_ZIPS
     *
     * @param tracfoneOneArUsaPostalZips
     * @return
     */
    @POST
    @Path("carriermaintenance/updatearusapostalzips")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateArUsaPostalZips(@Valid final TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateArUsaPostalZips(tracfoneOneArUsaPostalZips,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to bulk update AR_USA_POSTAL_ZIPS
     *
     * @param tracfoneOneArUsaPostalZips
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkupdatearusapostalzips")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkUpdateArUsaPostalZips(@Valid final List<TracfoneOneArUsaPostalZips> tracfoneOneArUsaPostalZips) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.bulkUpdateArUsaPostalZips(tracfoneOneArUsaPostalZips,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }


    /**
     * This method is to get AR_USA_MARKET Details
     *
     * @return
     */
    @POST
    @Path("carriermaintenance/getarusamarketdetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getArUsaMarketDetails(final TracfoneOneArUsaMarket tracfoneOneArUsaMarket) {
        TFOneArUsaMarketSearchResult tfOneArUsaMarket;
        try {
            tfOneArUsaMarket = tracfoneCarrierMaintenanceController.getArUsaMarketDetails(tracfoneOneArUsaMarket);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneArUsaMarket), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add Ar Usa Market details
     *
     * @param tracfoneOneArUsaMarket
     * @return
     */
    @POST
    @Path("carriermaintenance/addarusamarketdetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertArUsaMarketDetails(@Valid final TracfoneOneArUsaMarket tracfoneOneArUsaMarket) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertArUsaMarketDetails(tracfoneOneArUsaMarket, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete a record in Ar Usa Market table
     *
     * @param tracfoneOneArUsaMarket
     * @return
     */
    @POST
    @Path("carriermaintenance/deletearusamarketdetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteArUsaMarketDetails(final TracfoneOneArUsaMarket tracfoneOneArUsaMarket) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.deleteArUsaMarketDetails(tracfoneOneArUsaMarket,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }


    /**
     * This method is used to update a record in Ar Usa Market table
     *
     * @param tracfoneOneArUsaMarket
     * @return
     */
    @POST
    @Path("carriermaintenance/updatearusamarketdetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateArUsaMarketDetails(@Valid final TracfoneOneArUsaMarket tracfoneOneArUsaMarket) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateArUsaMarketDetails(tracfoneOneArUsaMarket,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to bulk update Ar Usa Market table
     *
     * @param tracfoneOneArUsaMarket
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkupdatearusamarketdetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkUpdateArUsaMarketDetails(@Valid final List<TracfoneOneArUsaMarket> tracfoneOneArUsaMarket) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.bulkUpdateArUsaMarketDetails(tracfoneOneArUsaMarket,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method will be used to bulk insert AR_USA_Market table
     *
     * @param tracfoneOneArUsaMarket
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkinsertarusamarket")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertArUsaMarket(List<TracfoneOneArUsaMarket> tracfoneOneArUsaMarket) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkInsertArUsaMarket(tracfoneOneArUsaMarket,
                    getUserFromPrincipal().getUserId(),
                    getUserFromPrincipal().getDescription());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/getbulkinsertarusamarketsummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertArUsaMarketSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(),
                    BULK_AR_USA_MARKET_INSERT,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/getarusamarketerrorrecorddetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getArUsaMarketErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        try {
            tracfoneOneUserHistory.setType("AR USA Market Error Record Details");
            summary = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(summary), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method will be used to bulk insert AR_USA_POSTAL_ZIPS table
     *
     * @param tracfoneOneArUsaPostalZips
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkinsertarusapostalzips")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertArUsaPostalZips(List<TracfoneOneArUsaPostalZips> tracfoneOneArUsaPostalZips) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkInsertArUsaPostalZips(tracfoneOneArUsaPostalZips,
                    getUserFromPrincipal().getUserId(),
                    getUserFromPrincipal().getDescription());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/getbulkinsertarusapostalzipssummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertArUsaPostalZipsSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(),
                    BULK_AR_USA_POSTAL_ZIPS_INSERT,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/getarusapostalzipserrorrecorddetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getArUsaPostalZipsErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        try {
            tracfoneOneUserHistory.setType("AR USA Postal Zips Error Record Details");
            summary = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(summary), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add C_RTL_ZIP_GEOLOC
     *
     * @param tfOneGeoLoc
     * @return
     */
    @POST
    @Path("carriermaintenance/addgeoloc")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response addGeoLoc(@Valid final TracfoneOneGeoLoc tfOneGeoLoc) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertGeoLoc(tfOneGeoLoc, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete a record in C_RTL_ZIP_GEOLOC table
     *
     * @param tfOneGeoLoc
     * @return
     */
    @POST
    @Path("carriermaintenance/deletegeoloc")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteGeoLoc(final TracfoneOneGeoLoc tfOneGeoLoc) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.deleteGeoLoc(tfOneGeoLoc,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method will be used to bulk insert C_RTL_ZIP_GEOLOC table
     *
     * @param tfGeoLocs
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkinsertgeoloc")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertGeoLoc(List<TracfoneOneGeoLoc> tfGeoLocs) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkInsertGeoLoc(tfGeoLocs,
                    getUserFromPrincipal().getUserId(),
                    getUserFromPrincipal().getDescription());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all objid from C_SEC_USER
     */
    @GET
    @Path("carriermaintenance/getuser")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getUsers() {
        List<String> userData = new ArrayList<>();
        try {
            userData = tracfoneCarrierMaintenanceController.getUsers();
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(userData), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/bulkinsertgeolocsummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertGeoLocSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(),
                    BULK_GEO_LOC_INSERT,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/getgeolocerrorrecorddetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getGeoLocErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        try {
            tracfoneOneUserHistory.setType(BULK_GEO_LOC_INSERT);
            summary = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(summary), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search C_RTL_ZIP_GEOLOC based on
     * ZIP
     *
     * @param tfOneGeoLoc
     * @return
     */
    @POST
    @Path("carriermaintenance/searchgeoloc")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchGeoLoc(final TracfoneOneGeoLoc tfOneGeoLoc) {
        List<TFOneGeoLoc> tfOneGeoLocs = null;
        try {
            tfOneGeoLocs = tracfoneCarrierMaintenanceController.searchGeoLoc(tfOneGeoLoc);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneGeoLocs), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a record in C_RTL_ZIP_GEOLOC
     *
     * @param tfGeoLoc
     * @return
     */
    @POST
    @Path("carriermaintenance/updategeoloc")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateGeoLoc(@Valid final TracfoneOneGeoLoc tfGeoLoc) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateGeoLoc(tfGeoLoc,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to bulk update C_RTL_ZIP_GEOLOC table
     *
     * @param geoLocs
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkupdategeoloc")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkUpdateGeoLoc(final List<TracfoneOneGeoLoc> geoLocs) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.bulkUpdateGeoLoc(geoLocs,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search Carrierzones
     *
     * @param tracfoneOneCarrierZones
     * @return
     */
    @POST
    @Path("carriermaintenance/searchCarrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierzones(final TracfoneOneCarrierZones tracfoneOneCarrierZones) {
        List<TFOneCarrierZones> tfOneCarrierZones = new ArrayList<>();
        try {
            tfOneCarrierZones = tracfoneCarrierMaintenanceController.searchCarrierzones(tracfoneOneCarrierZones);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneCarrierZones), MediaType.APPLICATION_JSON).build();
    }
    /**
     * This method is used to insert into carrierzones
     *
     * @param tracfoneOneCarrierZones
     * @return
     */
    @POST
    @Path("carriermaintenance/addCarrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarrierzones(@Valid  TracfoneOneCarrierZones tracfoneOneCarrierZones) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertCarrierzones(tracfoneOneCarrierZones, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }
    /**
     * This method is used to delete a record in Carrierzones table
     *
     * @param tracfoneOneCarrierZones
     * @return
     */
    @POST
    @Path("carriermaintenance/deletecarrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteCarrierzones(final TracfoneOneCarrierZones tracfoneOneCarrierZones) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.deleteCarrierzones(tracfoneOneCarrierZones,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }
    /**
     * This method is used to update Carrierzones table
     *
     * @param tracfoneOneCarrierZones
     * @return
     */
    @POST
    @Path("carriermaintenance/updateCarrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrierzones(@Valid final TracfoneOneCarrierZones tracfoneOneCarrierZones) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateCarrierzones(tracfoneOneCarrierZones,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to bulk update Carrierzones table
     *
     * @param tracfoneOneCarrierZones
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkupdatecarrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkUpdateCarrierZones(@Valid final List<TracfoneOneCarrierZones> tracfoneOneCarrierZones) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.bulkUpdateCarrierZones(tracfoneOneCarrierZones,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method will be used to bulk insert Carrierzones table
     *
     * @param tracfoneOneCarrierZones
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkinsertcarrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertCarrierzones(List<TracfoneOneCarrierZones> tracfoneOneCarrierZones) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkInsertCarrierzones(tracfoneOneCarrierZones,
                    getUserFromPrincipal().getUserId());
        }catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }
    /**
     * This method is used to delete records from Carrierzones table
     *
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkdeletecarrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkDeleteCarrierZones(List<TracfoneOneCarrierZones> tracfoneOneCarrierZones) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkDeleteCarrierZones(tracfoneOneCarrierZones,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/bulkinsertcarrierzonessummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertCarrierzonesSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(), BULK_CARRIERZONES_INSERT,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }
    @POST
    @Path("carriermaintenance/getcarrierzoneserrorrecorddetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierzonesErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        try {
            tracfoneOneUserHistory.setType("Carrierzones Error Record Details");
            summary = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(summary), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to bulk delete records from NPANXX2Carrierzones table
     *
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkdeletenpanxx2carrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkDeleteNpanxx2CarrierZones(List<TracfoneOneNpanxx2Carrierzones> tracfoneOneNpanxx2Carrierzones) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkDeleteNpanxx2CarrierZones(tracfoneOneNpanxx2Carrierzones,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }


    /**
     * This method is used to delete records from  Ar Usa Market table
     *
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkdeletearusamarket")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkDeleteArUsaMarket(List<TracfoneOneArUsaMarket> tracfoneOneArUsaMarket) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkDeleteArUsaMarket(tracfoneOneArUsaMarket,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to bulk delete records from AR_USA_POSTAL_ZIPS table
     *
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkdeletearusapostalzips")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkDeleteArUsaPostalZips(List<TracfoneOneArUsaPostalZips> tracfoneOneArUsaPostalZips) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkDeleteArUsaPostalZips(tracfoneOneArUsaPostalZips,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search Carrierpref
     *
     * @param tracfoneOneCarrierPref
     * @return
     */
    @POST
    @Path("carriermaintenance/searchCarrierpref")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierpref(final TracfoneOneCarrierPref tracfoneOneCarrierPref) {
        List<TFOneCarrierPref> tfOneCarrierPref = new ArrayList<>();
        try {
            tfOneCarrierPref = tracfoneCarrierMaintenanceController.searchCarrierpref(tracfoneOneCarrierPref);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneCarrierPref), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert into Carrierpref
     *
     * @param tracfoneOneCarrierPref
     * @return
     */
    @POST
    @Path("carriermaintenance/addCarrierpref")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarrierpref(@Valid  TracfoneOneCarrierPref tracfoneOneCarrierPref) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.insertCarrierpref(tracfoneOneCarrierPref, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete a record in Carrierpref table
     *
     * @param tracfoneOneCarrierPref
     * @return
     */
    @POST
    @Path("carriermaintenance/deletecarrierpref")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteCarrierpref(final TracfoneOneCarrierPref tracfoneOneCarrierPref) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.deleteCarrierpref(tracfoneOneCarrierPref,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }
    /**
     * This method is used to update Carrierpref table
     *
     * @param tracfoneOneCarrierPref
     * @return
     */
    @POST
    @Path("carriermaintenance/updateCarrierpref")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrierpref(@Valid final TracfoneOneCarrierPref tracfoneOneCarrierPref) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.updateCarrierpref(tracfoneOneCarrierPref,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to bulk update Carrierpref table
     *
     * @param tracfoneOneCarrierPref
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkupdatecarrierpref")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkUpdateCarrierpref(@Valid final List<TracfoneOneCarrierPref> tracfoneOneCarrierPref) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneCarrierMaintenanceController.bulkUpdateCarrierpref(tracfoneOneCarrierPref,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method will be used to bulk insert Carrierpref table
     *
     * @param tracfoneOneCarrierPref
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkinsertcarrierpref")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertCarrierpref(List<TracfoneOneCarrierPref> tracfoneOneCarrierPref) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkInsertCarrierpref(tracfoneOneCarrierPref,
                    getUserFromPrincipal().getUserId(),getUserFromPrincipal().getDescription());
        }catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete records from Carrierpref table
     *
     * @return
     */
    @POST
    @Path("carriermaintenance/bulkdeletecarrierpref")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkDeleteCarrierpref(List<TracfoneOneCarrierPref> tracfoneOneCarrierPref) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneCarrierMaintenanceController.bulkDeleteCarrierpref(tracfoneOneCarrierPref,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carriermaintenance/bulkinsertcarrierprefsummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertCarrierprefSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(), BULK_CARRIERPREF_INSERT,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }
    @POST
    @Path("carriermaintenance/getcarrierpreferrorrecorddetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierprefErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        try {
            tracfoneOneUserHistory.setType("Carrierpref Error Record Details");
            summary = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(summary), MediaType.APPLICATION_JSON).build();
    }

    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }
}
