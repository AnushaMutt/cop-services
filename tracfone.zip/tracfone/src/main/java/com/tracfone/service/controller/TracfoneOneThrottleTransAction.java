package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneSearchAdditionalModel;
import com.tracfone.service.model.request.TracfoneOneThrottleRework;
import com.tracfone.service.model.request.TracfoneOneThrottleTrans;
import com.tracfone.service.model.request.TracfoneOneThrottleTransaction;
import com.tracfone.service.model.request.TracfoneonePaginationSearch;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneThrottlePolicy;
import com.tracfone.service.model.response.TFOneThrottleTransSearchResult;
import com.tracfone.service.model.response.TFOneThrottleTransaction;
import com.tracfone.service.util.ThrottleTransControllerUtil;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantThrottleTrans;
import jersey.repackaged.com.google.common.collect.Lists;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Gaurav.Sharma
 */
@Stateless
public class TracfoneOneThrottleTransAction implements TracfoneOneThrottleTransActionLocal, TracfoneOneConstantThrottleTrans, TracfoneOneConstant {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneThrottleTransAction.class);

    @EJB
    private DataBaseController dbControllerEJB;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    private static final String NULL = "NULL";
    private static final String AND = " AND ";
    private static final String OR = " OR ";
    private static final String COMMA = ", ";
    private static final String SUCCESS = "Success";
    private static final String TTOFF = "TTOFF";
    private static final String HSBON = "HSBON";
    private static final String TT_OBJID_SEQ = "TT_OBJID_SEQ";
    private static final String OBJID = "objId";
    private static final String REWORK = "REWORK";

    @Override
    public TFOneThrottleTransSearchResult viewThrottleTransaction(TracfoneOneThrottleTransaction throttleTransactions) throws TracfoneOneException {
        TFOneThrottleTransSearchResult throttleTransSearchResult = new TFOneThrottleTransSearchResult();
        try (Connection con = dbControllerEJB.getDataSource(throttleTransactions.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getThrottleTransactionStatement(THROTTLE_TRANSACTION_START, throttleTransactions));
             PreparedStatement stmtCount = con.prepareStatement(generateDynamicSearchQuery(GET_THROTTLE_TRANSACTION_COUNT, throttleTransactions, "tt."))) {

            setViewThrottleTransactionStatement(stmt, stmtCount, throttleTransactions);
            TFOneThrottleTransaction throttleTransaction;
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    throttleTransaction = setThrottleTransaction(resultSet);
                    throttleTransSearchResult.getThrottleTransactions().add(throttleTransaction);
                }
            }

            int count = 0;
            try (ResultSet resultSetCount = stmtCount.executeQuery()) {
                while (resultSetCount.next()) {
                    count = resultSetCount.getInt(1);
                }
            }
            LOGGER.info("Total Count " + count);
            TracfoneonePaginationSearch tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
            tracfoneonePaginationSearch.setStartIndex(throttleTransactions.getPaginationSearch().getStartIndex());
            tracfoneonePaginationSearch.setEndIndex(throttleTransactions.getPaginationSearch().getEndIndex());
            tracfoneonePaginationSearch.setTotal(count);
            throttleTransSearchResult.setPaginationSearch(tracfoneonePaginationSearch);
            LOGGER.info("Result " + throttleTransSearchResult);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return throttleTransSearchResult;
    }

    @Override
    public TFOneGeneralResponse reworkRequeue(TracfoneOneThrottleRework tracfoneOneThrottleRework, String type, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = new TFOneGeneralResponse(SUCCESS, "Transactions re-queued successfully");
        TracfoneOneThrottleTransaction tracfoneOneSearchCriteria = tracfoneOneThrottleRework.getSearchCriteria();
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleRework.getChunkSize())) {
            List<String> objIds = getAllObjIdsFromSearch(tracfoneOneThrottleRework);
            TracfoneOneSearchAdditionalModel objIdSearchModel = createSearchModel(OBJID, "string", objIds, false, false);
            tracfoneOneSearchCriteria.getSearchColumns().add(objIdSearchModel);
        }
        LOGGER.info("Request for rework/requeue is " + tracfoneOneThrottleRework);
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneThrottleRework.getSearchCriteria().getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(generateReworkQuery(tracfoneOneThrottleRework, type))) {
            // Prepare statement SEARCH section of SQL block.
            stmt.setLong(1, userId);
            stmt.setString(2, "TT_" + type);
            int index = setReworkSearchStatement(stmt, tracfoneOneSearchCriteria);
            // Prepare statement UPDATE section of SQL Block.
            if (REWORK.equalsIgnoreCase(type)) {
                setThrottleParameters1(stmt, tracfoneOneThrottleRework.getReworkCriteria(), index);
            }
            stmt.executeUpdate();
        } catch (Exception e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Throttle ".concat(type), "Search and Rework criteria " + tracfoneOneThrottleRework, null);
            tracfoneAuditEvent.fire(audit);
        }
        if (REWORK.equalsIgnoreCase(type)) {
            response = new TFOneGeneralResponse(SUCCESS, "Transactions reworked successfully");
        }
        return response;
    }

    private TracfoneOneSearchAdditionalModel createSearchModel(String columnName, String columnType, List<String> values, boolean isColumnNotIn, boolean isColumnLike) {
        TracfoneOneSearchAdditionalModel searchAdditionalModel = new TracfoneOneSearchAdditionalModel();
        searchAdditionalModel.setSearchColumnName(columnName);
        searchAdditionalModel.setSearchColumnType(columnType);
        searchAdditionalModel.setSearchValues(values);
        searchAdditionalModel.setSearchIsColumnNotIn(isColumnNotIn);
        searchAdditionalModel.setSearchIsColumnLike(isColumnLike);
        return searchAdditionalModel;
    }

    private int setReworkSearchStatement(PreparedStatement stmt, TracfoneOneThrottleTransaction tracfoneOneThrottleTransaction) throws SQLException {
        int index = 3;
        for (TracfoneOneSearchAdditionalModel column : tracfoneOneThrottleTransaction.getSearchColumns()) {
            for (String fieldValue : column.getSearchValues()) {
                if (NULL.equalsIgnoreCase(fieldValue)) {
                    break;
                }
                if (column.isSearchIsColumnLike()) {
                    stmt.setString(index++, "%" + fieldValue.trim() + "%");
                } else {
                    stmt.setString(index++, fieldValue.trim());
                }
            }
        }
        index = setReworkSearchStatementDate(index, stmt, tracfoneOneThrottleTransaction);
        return index;
    }

    private int setReworkSearchStatementDate(int index, PreparedStatement stmt, TracfoneOneThrottleTransaction tracfoneOneThrottleTransaction) throws SQLException {
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleTransaction.getCreationFromDate())) {
            stmt.setString(index++, tracfoneOneThrottleTransaction.getCreationFromDate().trim());
            //to date
            if (tracfoneOneThrottleTransaction.getCreationToDate() != null && !tracfoneOneThrottleTransaction.getCreationToDate().isEmpty()) {
                stmt.setString(index++, tracfoneOneThrottleTransaction.getCreationToDate().trim());
            } else {
                stmt.setString(index++, getDefaultTodayDate().trim());
            }
        } else if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleTransaction.getCreationToDate())) {
            stmt.setString(index++, tracfoneOneThrottleTransaction.getCreationToDate().trim());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleTransaction.getUpdateFromDate())) {
            stmt.setString(index++, tracfoneOneThrottleTransaction.getUpdateFromDate().trim());
            //to date
            if (tracfoneOneThrottleTransaction.getUpdateToDate() != null && !tracfoneOneThrottleTransaction.getUpdateToDate().isEmpty()) {
                stmt.setString(index++, tracfoneOneThrottleTransaction.getUpdateToDate().trim());
            } else {
                stmt.setString(index++, getDefaultTodayDate().trim());
            }
        } else if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleTransaction.getUpdateToDate())) {
            stmt.setString(index++, tracfoneOneThrottleTransaction.getUpdateToDate().trim());
        }
        return index;
    }

    private String generateReworkQuery(TracfoneOneThrottleRework tracfoneOneThrottleRework, String type) {
        StringBuilder reworkBuilder = new StringBuilder(generateDynamicSearchQuery(SEARCH_THROTTLE_REWORKTRANSACTION,
                tracfoneOneThrottleRework.getSearchCriteria(), "tig."));
        reworkBuilder.append(";");
        // add new trans function
        reworkBuilder.append(THROTTLE_REWORKTRANSACTION_NEWTANSACTIONCHECK);
        // start of rework query
        reworkBuilder.append(THROTTLE_REWORKTRANSACTION_START);
        if (REWORK.equalsIgnoreCase(type)) {
            reworkBuilder = new StringBuilder(buildReworkQuery1(reworkBuilder, tracfoneOneThrottleRework.getReworkCriteria()));
        } else {
            reworkBuilder.append("tig.x_status = 'Q', tig.x_api_message = null\n");
        }
        reworkBuilder.append(THROTTLE_REWORKTRANSACTION_END);
        LOGGER.debug("REWORK/REQUEUE SQL is " + reworkBuilder.toString());
        LOGGER.info("REWORK/REQUEUE SQL is " + reworkBuilder.toString());
        return reworkBuilder.toString();
    }

    @Override
    public List<String> getAllObjIdsFromSearch(TracfoneOneThrottleRework tracfoneOneRework) {
        List<String> objIds = new ArrayList<>();
        TracfoneOneThrottleTransaction searchCriteria = tracfoneOneRework.getSearchCriteria();
        searchCriteria.getPaginationSearch().setEndIndex(Integer.valueOf(tracfoneOneRework.getChunkSize()));

        try {
            TFOneThrottleTransSearchResult searchResults = viewThrottleTransaction(searchCriteria);
            if (!searchResults.getThrottleTransactions().isEmpty()) {
                objIds = searchResults.getThrottleTransactions()
                        .stream()
                        .map(a -> a.getObjId())
                        .collect(Collectors.toList());
                LOGGER.debug("Objids retrieved are " + objIds);
            }
        } catch (TracfoneOneException e) {
            LOGGER.error("Error when searching with chunk size ", e);
        }
        return objIds;
    }

    private String buildReworkQuery1(StringBuilder builder, TracfoneOneThrottleTrans tfThrottleTransaction) {
        if (null != tfThrottleTransaction.getTransactionNum()) {
            builder.append("X_TRANSACTION_NUM = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getRuleId()) {
            builder.append("X_RULE_ID = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getMin()) {
            builder.append("X_MIN = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getEsn()) {
            builder.append("X_ESN = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getTransactionType()) {
            builder.append("X_TRANSACT_TYPE = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getStatus()) {
            builder.append("X_STATUS = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getApiStatus()) {
            builder.append("X_API_STATUS = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getApiMessage()) {
            builder.append("X_API_MESSAGE = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getSubscriberId()) {
            builder.append("X_SUBSCRIBER_ID = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getGroupId()) {
            builder.append("X_GROUP_ID = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getPropagateFlagValue()) {
            builder.append("PROPAGATE_FLAG_VALUE = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getParentName()) {
            builder.append("PARENT_NAME = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getUsageTierId()) {
            builder.append("USAGE_TIER_ID = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getCos()) {
            builder.append("COS = ?").append(COMMA);
        }
        builder = buildReworkQuery2(builder, tfThrottleTransaction);
        return builder.toString();
    }

    private StringBuilder buildReworkQuery2(StringBuilder builder, TracfoneOneThrottleTrans tfThrottleTransaction) {
        if (null != tfThrottleTransaction.getPolicyName()) {
            builder.append("POLICY_NAME = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getEntitlement()) {
            builder.append("ENTITLEMENT = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getPriority()) {
            builder.append("PRIORITY = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getThreshold()) {
            builder.append("THRESHOLD = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getThrottleGroupType()) {
            builder.append("THROTTLE_GROUP_TYPE = ?").append(COMMA);
        }
        if (null != tfThrottleTransaction.getCreationDate()) {
            builder.append("X_CREATION_DATE =  to_date(?,'YYYY-MM-DD hh24:MI:SS')").append(COMMA);
        }
        builder.append("X_LAST_UPDATE = sysdate ");
        return builder;
    }

    private void setThrottleParameters1(PreparedStatement stmt, TracfoneOneThrottleTrans tfThrottleTransaction, int index) throws SQLException {
        if (null != tfThrottleTransaction.getTransactionNum()) {
            stmt.setString(index++, tfThrottleTransaction.getTransactionNum());
        }
        if (null != tfThrottleTransaction.getRuleId()) {
            stmt.setString(index++, tfThrottleTransaction.getRuleId());
        }
        if (null != tfThrottleTransaction.getMin()) {
            stmt.setString(index++, tfThrottleTransaction.getMin());
        }
        if (null != tfThrottleTransaction.getEsn()) {
            stmt.setString(index++, tfThrottleTransaction.getEsn());
        }
        if (null != tfThrottleTransaction.getTransactionType()) {
            stmt.setString(index++, tfThrottleTransaction.getTransactionType());
        }
        if (null != tfThrottleTransaction.getStatus()) {
            stmt.setString(index++, tfThrottleTransaction.getStatus());
        }
        if (null != tfThrottleTransaction.getApiStatus()) {
            stmt.setString(index++, tfThrottleTransaction.getApiStatus());
        }
        if (null != tfThrottleTransaction.getApiMessage()) {
            stmt.setString(index++, tfThrottleTransaction.getApiMessage());
        }
        if (null != tfThrottleTransaction.getSubscriberId()) {
            stmt.setString(index++, tfThrottleTransaction.getSubscriberId());
        }
        setThrottleParameters2(stmt, tfThrottleTransaction, index);
    }

    private void setThrottleParameters2(PreparedStatement stmt, TracfoneOneThrottleTrans tfThrottleTransaction, int index) throws SQLException {

        if (null != tfThrottleTransaction.getGroupId()) {
            stmt.setString(index++, tfThrottleTransaction.getGroupId());
        }
        if (null != tfThrottleTransaction.getPropagateFlagValue()) {
            stmt.setString(index++, tfThrottleTransaction.getPropagateFlagValue());
        }
        if (null != tfThrottleTransaction.getParentName()) {
            stmt.setString(index++, tfThrottleTransaction.getParentName());
        }
        if (null != tfThrottleTransaction.getUsageTierId()) {
            stmt.setString(index++, tfThrottleTransaction.getUsageTierId());
        }
        if (null != tfThrottleTransaction.getCos()) {
            stmt.setString(index++, tfThrottleTransaction.getCos());
        }
        if (null != tfThrottleTransaction.getPolicyName()) {
            stmt.setString(index++, tfThrottleTransaction.getPolicyName());
        }
        if (null != tfThrottleTransaction.getEntitlement()) {
            stmt.setString(index++, tfThrottleTransaction.getEntitlement());
        }
        if (null != tfThrottleTransaction.getPriority()) {
            stmt.setString(index++, tfThrottleTransaction.getPriority());
        }
        if (null != tfThrottleTransaction.getThreshold()) {
            stmt.setString(index++, tfThrottleTransaction.getThreshold());
        }
        if (null != tfThrottleTransaction.getThrottleGroupType()) {
            stmt.setString(index++, tfThrottleTransaction.getThrottleGroupType());
        }
        if (null != tfThrottleTransaction.getCreationDate()) {
            stmt.setString(index, tfThrottleTransaction.getCreationDate());
        }
    }


    private String getThrottleTransactionStatement(String query, TracfoneOneThrottleTransaction tracfoneOneThrottleTransaction) {
        boolean pagination = false;
        int startIndex = 0;
        int endIndex = 0;
        if (tracfoneOneThrottleTransaction.getPaginationSearch() != null) {
            startIndex = tracfoneOneThrottleTransaction.getPaginationSearch().getStartIndex();
            endIndex = tracfoneOneThrottleTransaction.getPaginationSearch().getEndIndex();
            pagination = (endIndex - startIndex) <= TracfoneOneConstant.FETCH_SIZE;
        }

        StringBuilder sBuilder = new StringBuilder(generateDynamicSearchQuery(query + GET_THROTTLE_TRANSACTION, tracfoneOneThrottleTransaction, "tt."));
        // Pagination check for large result queries.
        if (pagination) {
            // Adding 1 to each of these since a ROWNUM of 0 never exists and it is being sent this way from the UI
            startIndex++;
            endIndex++;
            sBuilder.append(") a "
                    + "where ROWNUM < "
                    + endIndex + ") "
                    + "where rnum  >= " + startIndex);
        } else {
            TracfoneonePaginationSearch defaultPagination = new TracfoneonePaginationSearch();
            defaultPagination.setStartIndex(1);
            defaultPagination.setEndIndex(1000);
            tracfoneOneThrottleTransaction.setPaginationSearch(defaultPagination);
            sBuilder.append(") a "
                    + " where ROWNUM < "
                    + "1000 ) "
                    + "where rnum  >= 0");
        }

        LOGGER.info("The search query is " + sBuilder.toString());
        return sBuilder.toString();
    }

    private String generateDynamicSearchQuery(String query, TracfoneOneThrottleTransaction tracfoneOneThrottleTransaction, String alias) {
        StringBuilder sBuilder = new StringBuilder(query);
        String dbColumnName = null;
        for (TracfoneOneSearchAdditionalModel searchColumn : tracfoneOneThrottleTransaction.getSearchColumns()) {
            LOGGER.info("Request values for " + searchColumn.getSearchColumnName() + " are " + searchColumn.getSearchValues());
            dbColumnName = alias.concat(ThrottleTransControllerUtil.getDBColumnName(searchColumn.getSearchColumnName()));

            if (OBJID.equalsIgnoreCase(dbColumnName)) {
                sBuilder = handleSearchQueryForObjIds(sBuilder, dbColumnName, searchColumn.getSearchValues());
            } else {
                if (NULL.equalsIgnoreCase(searchColumn.getSearchValues().get(0))) {
                    sBuilder = buildNullClause(sBuilder, dbColumnName, "").append(AND);
                } else if (searchColumn.isSearchIsColumnNotIn()) {
                    sBuilder = buildNullOrNotInClause(searchColumn.getSearchValues().size(), sBuilder, dbColumnName);
                } else if (searchColumn.isSearchIsColumnLike()) {
                    sBuilder = buildQueryParamStringForLike(sBuilder, dbColumnName);
                } else {
                    sBuilder = buildQueryParamString(searchColumn.getSearchValues().size(), sBuilder, dbColumnName);
                }
            }
        }

        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleTransaction.getCreationFromDate())) {
            sBuilder.append(alias).append("X_CREATION_DATE >= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS')").append(AND).append(alias).append("X_CREATION_DATE <= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ");
        } else if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleTransaction.getCreationToDate())) {
            sBuilder.append(alias).append("X_CREATION_DATE <= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleTransaction.getUpdateFromDate())) {
            sBuilder.append(alias).append("X_LAST_UPDATE >= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS')").append(AND).append(alias).append("X_LAST_UPDATE <= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ");
        } else if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleTransaction.getUpdateToDate())) {
            sBuilder.append(alias).append("X_LAST_UPDATE <= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ");
        }
        LOGGER.info("generateDynamicSearchQuery " + sBuilder.toString());
        return sBuilder.substring(0, sBuilder.lastIndexOf(AND));
    }

    private StringBuilder handleSearchQueryForObjIds(StringBuilder sBuilder, String dbColumnName, List<String> searchValues) {
        if (searchValues.size() < 1000) {
            sBuilder = buildQueryParamString(searchValues.size(), sBuilder, dbColumnName);
        } else {
            List<List<String>> splitIds = Lists.partition(searchValues, 1000);
            sBuilder.append("(");
            StringBuilder transBuilder = new StringBuilder();
            for (List<String> objIds : splitIds) {
                StringBuilder tempBuilder = new StringBuilder();
                tempBuilder = buildQueryParamString(objIds.size(), tempBuilder, "ig.TRANSACTION_ID");
                transBuilder.append(tempBuilder.substring(4));
                transBuilder.append(OR);
                LOGGER.info("transactions ids query " + transBuilder);
            }
            sBuilder = sBuilder.append(transBuilder.substring(0, transBuilder.lastIndexOf(OR))).append(")");
            LOGGER.info("sBuilder split query " + sBuilder);
        }
        return sBuilder;
    }

    private void setViewThrottleTransactionStatement(PreparedStatement stmt, PreparedStatement stmtCount, TracfoneOneThrottleTransaction tracfoneOneThrottleTransaction) throws SQLException {
        int index = 1;
        for (TracfoneOneSearchAdditionalModel column : tracfoneOneThrottleTransaction.getSearchColumns()) {
            for (String fieldValue : column.getSearchValues()) {
                if (NULL.equalsIgnoreCase(fieldValue)) {
                    break;
                }
                if (column.isSearchIsColumnLike()) {
                    stmt.setString(index, "%" + fieldValue.trim() + "%");
                    stmtCount.setString(index++, "%" + fieldValue.trim() + "%");
                } else {
                    stmt.setString(index, fieldValue.trim());
                    stmtCount.setString(index++, fieldValue.trim());
                }
            }
        }
        setViewThrottleTransactionStatementDates(index, stmt, stmtCount, tracfoneOneThrottleTransaction);
    }

    private void setViewThrottleTransactionStatementDates(int index, PreparedStatement stmt, PreparedStatement stmtCount, TracfoneOneThrottleTransaction tracfoneOneThrottleTransaction) throws SQLException {
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleTransaction.getCreationFromDate())) {
            stmt.setString(index, tracfoneOneThrottleTransaction.getCreationFromDate().trim());
            stmtCount.setString(index++, tracfoneOneThrottleTransaction.getCreationFromDate().trim());
            //to date
            if (tracfoneOneThrottleTransaction.getCreationToDate() != null && !tracfoneOneThrottleTransaction.getCreationToDate().isEmpty()) {
                stmt.setString(index, tracfoneOneThrottleTransaction.getCreationToDate().trim());
                stmtCount.setString(index++, tracfoneOneThrottleTransaction.getCreationToDate().trim());
            } else {
                stmt.setString(index, getDefaultTodayDate().trim());
                stmtCount.setString(index++, getDefaultTodayDate().trim());
            }
        } else if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleTransaction.getCreationToDate())) {
            stmt.setString(index, tracfoneOneThrottleTransaction.getCreationToDate().trim());
            stmtCount.setString(index++, tracfoneOneThrottleTransaction.getCreationToDate().trim());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleTransaction.getUpdateFromDate())) {
            stmt.setString(index, tracfoneOneThrottleTransaction.getUpdateFromDate().trim());
            stmtCount.setString(index++, tracfoneOneThrottleTransaction.getUpdateFromDate().trim());
            //to date
            if (tracfoneOneThrottleTransaction.getUpdateToDate() != null && !tracfoneOneThrottleTransaction.getUpdateToDate().isEmpty()) {
                stmt.setString(index, tracfoneOneThrottleTransaction.getUpdateToDate().trim());
                stmtCount.setString(index, tracfoneOneThrottleTransaction.getUpdateToDate().trim());
            } else {
                stmt.setString(index, getDefaultTodayDate().trim());
                stmtCount.setString(index, getDefaultTodayDate().trim());
            }
        } else if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleTransaction.getUpdateToDate())) {
            stmt.setString(index, tracfoneOneThrottleTransaction.getUpdateToDate().trim());
            stmtCount.setString(index, tracfoneOneThrottleTransaction.getUpdateToDate().trim());
        }
    }

    private TFOneThrottleTransaction setThrottleTransaction(ResultSet resultSet) throws SQLException {
        TFOneThrottleTransaction throttleTransaction = new TFOneThrottleTransaction();
        throttleTransaction.setObjId(resultSet.getString("OBJID"));
        throttleTransaction.setCreationDate(resultSet.getString("X_CREATION_DATE"));
        throttleTransaction.setLastUpdateDate(resultSet.getString("X_LAST_UPDATE"));
        throttleTransaction.setTransactionNum(resultSet.getString("X_TRANSACTION_NUM"));
        throttleTransaction.setStatus(resultSet.getString("X_STATUS"));
        throttleTransaction.setMin(resultSet.getString("X_MIN"));
        throttleTransaction.setEsn(resultSet.getString("X_ESN"));
        throttleTransaction.setThrottleGroupType(resultSet.getString("THROTTLE_GROUP_TYPE"));
        throttleTransaction.setTransactionType(resultSet.getString("X_TRANSACT_TYPE"));
        throttleTransaction.setParentName(resultSet.getString("PARENT_NAME"));
        throttleTransaction.setPolicyName(resultSet.getString("POLICY_NAME"));
        throttleTransaction.setPriority(resultSet.getString("PRIORITY"));
        throttleTransaction.setRuleId(resultSet.getString("X_RULE_ID"));
        throttleTransaction.setPropagateFlagValue(resultSet.getString("PROPAGATE_FLAG_VALUE"));
        throttleTransaction.setSubscriberId(resultSet.getString("X_SUBSCRIBER_ID"));
        throttleTransaction.setThreshold(resultSet.getString("THRESHOLD"));
        throttleTransaction.setEntitlement(resultSet.getString("ENTITLEMENT"));
        throttleTransaction.setGroupId(resultSet.getString("X_GROUP_ID"));
        throttleTransaction.setCos(resultSet.getString("COS"));
        throttleTransaction.setApiStatus(resultSet.getString("X_API_STATUS"));
        throttleTransaction.setApiMessage(resultSet.getString("X_API_MESSAGE"));
        throttleTransaction.setUsageTierId(resultSet.getString("USAGE_TIER_ID"));
        return throttleTransaction;
    }

    private StringBuilder buildNullOrNotInClause(int size, StringBuilder sbuilder, String optionalFieldName) {
        sbuilder = buildQueryParamStringForNotINs(size, sbuilder, optionalFieldName, true);
        sbuilder = buildNullClause(sbuilder, optionalFieldName, OR);
        return sbuilder.append(")").append(AND);
    }

    private StringBuilder buildNullClause(StringBuilder sbuilder, String fieldName, String connector) {
        return sbuilder.append(connector).append(fieldName).append(" IS NULL ");
    }

    private StringBuilder buildQueryParamStringForNotINs(int amountQueryParam, StringBuilder sBuilder, String queryParamName, boolean includeNullCheck) {
        if (amountQueryParam <= 0) {
            return sBuilder;
        }
        // Construct the insert param with the first value.
        if (includeNullCheck) {
            sBuilder.append("(");
        }
        sBuilder.append(queryParamName).append(" not in ( ").append("?");
        amountQueryParam -= 1;

        for (int i = 0; i < amountQueryParam; i++) {
            sBuilder.append(",?");
        }
        sBuilder.append(" )");
        return sBuilder;
    }

    private StringBuilder buildQueryParamStringForLike(StringBuilder sBuilder, String queryParamName) {
        return sBuilder.append(queryParamName).append(" like ? ").append(AND);
    }

    private StringBuilder buildQueryParamString(int amountQueryParam, StringBuilder sBuilder, String queryParamName) {
        if (amountQueryParam <= 0) {
            return sBuilder;
        }
        // Construct the insert param with the first value.
        sBuilder.append(queryParamName).append(" in ( ").append("?");
        amountQueryParam -= 1;

        for (int i = 0; i < amountQueryParam; i++) {
            sBuilder.append(",?");
        }
        sBuilder.append(" )").append(AND);
        return sBuilder;
    }

    private String getDefaultTodayDate() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy:MM:dd");
        return sdFormat.format(cal.getTime());
    }

    @Override
    public TFOneGeneralResponse reworkRequeueAll(TracfoneOneThrottleRework tracfoneOneThrottleRework, String type, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = new TFOneGeneralResponse(SUCCESS, "Transactions re-queued successfully");
        TracfoneOneThrottleTransaction tracfoneOneSearchCriteria = tracfoneOneThrottleRework.getSearchCriteria();
        if (!StringUtils.isNullOrEmpty(tracfoneOneThrottleRework.getChunkSize())) {
            //Get the list of objids
            List<String> objIds = getAllObjIdsFromSearch(tracfoneOneThrottleRework);
            //split objids
            List<List<String>> splitObj = Lists.partition(objIds, 999);
            for (List<String> objids : splitObj) {
                //create a new objid search model
                TracfoneOneSearchAdditionalModel objIdSearchModel = createSearchModel(OBJID, "string", objids, false, false);
                //clear old objids
                tracfoneOneSearchCriteria.getSearchColumns().clear();
                //set new objids
                tracfoneOneSearchCriteria.getSearchColumns().add(objIdSearchModel);
                LOGGER.info("Request for rework/requeue is " + tracfoneOneThrottleRework);
                try (Connection con = dbControllerEJB.getDataSource(tracfoneOneThrottleRework.getSearchCriteria().getDbEnv()).getConnection();
                     PreparedStatement stmt = con.prepareStatement(generateReworkQuery(tracfoneOneThrottleRework, type));) {
                    // Prepare statement SEARCH section of SQL block.
                    stmt.setLong(1, userId);
                    stmt.setString(2, "TT_" + type);
                    int index = setReworkSearchStatement(stmt, tracfoneOneSearchCriteria);
                    // Prepare statement UPDATE section of SQL Block.
                    if (REWORK.equalsIgnoreCase(type)) {
                        setThrottleParameters1(stmt, tracfoneOneThrottleRework.getReworkCriteria(), index);
                    }
                    stmt.executeUpdate();
                } catch (Exception e) {
                    LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
                    throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                            TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
                } finally {
                    TracfoneAudit audit = new TracfoneAudit(userId, "Throttle ".concat(type), "Search and Rework criteria " + tracfoneOneThrottleRework, null);
                    tracfoneAuditEvent.fire(audit);
                }
                if (REWORK.equalsIgnoreCase(type)) {
                    response = new TFOneGeneralResponse(SUCCESS, "Transactions reworked successfully");
                }
            }
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse insertThrottleTransaction(TracfoneOneThrottleTrans tfThrottleTrans, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try (Connection con = dbControllerEJB.getDataSource(tfThrottleTrans.getDbEnv()).getConnection();
             CallableStatement stmt = con.prepareCall(buildInsertQuery(tfThrottleTrans.getTransactionType()));) {

            setInsertQueryParameters(stmt, tfThrottleTrans);
            stmt.executeUpdate();

            if (tfThrottleTrans.getTransactionType().equalsIgnoreCase("TTON")) {
                response = new TFOneGeneralResponse(SUCCESS, SUCCESS);
            } else if (tfThrottleTrans.getTransactionType().equalsIgnoreCase(TTOFF)) {
                response = new TFOneGeneralResponse(SUCCESS,
                        stmt.getString(3) + " - " + (stmt.getString(4)));
            } else if (tfThrottleTrans.getTransactionType().equalsIgnoreCase(HSBON)) {
                response = new TFOneGeneralResponse(SUCCESS,
                        stmt.getString(6).concat(" - ").concat(stmt.getString(7)));
            }

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Throttle Transaction", "Inserted Throttle Transaction" + tfThrottleTrans, null);
            tracfoneAuditEvent.fire(audit);
        }
        return response;
    }

    @Override
    public List<TFOneThrottlePolicy> getPolicyName(String dbEnv) throws TracfoneOneException {
        List<TFOneThrottlePolicy> policyList = new ArrayList<>(1);
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_POLICY_NAME);) {
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    TFOneThrottlePolicy policy = new TFOneThrottlePolicy();
                    policy.setPolicyName(resultSet.getString("X_POLICY_NAME"));
                    policy.setObjId(resultSet.getString("OBJID"));
                    policy.setPolicyDesc(resultSet.getString("X_POLICY_DESCRIPTION"));
                    policyList.add(policy);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return policyList;
    }

    private String buildInsertQuery(String transactionType) {
        String query = null;
        if (transactionType.equalsIgnoreCase("TTON")) {
            query = TRACFONE_GENERATE_TTON_THROTTLE_TRANSACTION;
        } else if (transactionType.equalsIgnoreCase(TTOFF)) {
            query = TRACFONE_GENERATE_TTOFF_THROTTLE_TRANSACTION;
        } else if (transactionType.equalsIgnoreCase(HSBON)) {
            query = TRACFONE_GENERATE_HSBON_THROTTLE_TRANSACTION;
        }
        return query;
    }

    private void setInsertQueryParameters(CallableStatement stmt, TracfoneOneThrottleTrans tfThrottleTrans) throws SQLException {
        int index = 1;
        if (tfThrottleTrans.getTransactionType().equalsIgnoreCase("TTON")) {
            stmt.setString(index++, tfThrottleTrans.getMin());
            stmt.setString(index++, tfThrottleTrans.getEsn());
            stmt.setString(index++, tfThrottleTrans.getPolicyName());
            stmt.setString(index++, tfThrottleTrans.getTransactionNum());
            stmt.registerOutParameter(index++, Types.INTEGER);
            stmt.registerOutParameter(index, Types.VARCHAR);
        } else if (tfThrottleTrans.getTransactionType().equalsIgnoreCase(TTOFF)) {
            stmt.setString(index++, tfThrottleTrans.getMin());
            stmt.setString(index++, tfThrottleTrans.getEsn());
            stmt.registerOutParameter(index++, Types.INTEGER);
            stmt.registerOutParameter(index++, Types.VARCHAR);
            stmt.setString(index, "tfThrottleTrans.getByPassOff()");
        } else if (tfThrottleTrans.getTransactionType().equalsIgnoreCase(HSBON)) {
            stmt.setString(index++, "tfThrottleTrans.getSource()");
            stmt.setString(index++, tfThrottleTrans.getMin());
            stmt.setString(index++, tfThrottleTrans.getParentName());
            stmt.setString(index++, tfThrottleTrans.getUsageTierId());
            stmt.setString(index++, tfThrottleTrans.getPolicyName());
            stmt.registerOutParameter(index++, Types.INTEGER);
            stmt.registerOutParameter(index++, Types.VARCHAR);
            stmt.setString(index, tfThrottleTrans.getThrottleGroupType());
        }
    }

    private String getNextSequence(Connection con, String queryString, String seqId) throws SQLException {
        String sequenceId = null;
        try (PreparedStatement stmt = con.prepareStatement(queryString);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                sequenceId = resultSet.getString(seqId);
            }
        }

        return sequenceId;
    }

    @Override
    public TFOneGeneralResponse insertTTONThrottleTrans(TracfoneOneThrottleTrans tfThrottleTrans, int userId) throws TracfoneOneException {
        String objId;
        try (Connection con = dbControllerEJB.getDataSource(tfThrottleTrans.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(createTTSearchQuery(tfThrottleTrans));) {
            objId = getNextSequence(con, TRACFONE_TT_SEQ_STMT, TT_OBJID_SEQ);
            tfThrottleTrans.setObjId(objId);
            setInsertQueryTTParameters(stmt, tfThrottleTrans, "TT", "TTON");
            stmt.execute();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert TTON Throttle Transaction", "Inserted TTON Throttle Transaction" + tfThrottleTrans, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, objId);
    }

    @Override
    public TFOneGeneralResponse insertTTOFFThrottleTrans(TracfoneOneThrottleTrans tfThrottleTrans, int userId) throws TracfoneOneException {
        String objId;
        try (Connection con = dbControllerEJB.getDataSource(tfThrottleTrans.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(createTTSearchQuery(tfThrottleTrans));) {
            objId = getNextSequence(con, TRACFONE_TT_SEQ_STMT, TT_OBJID_SEQ);
            tfThrottleTrans.setObjId(objId);
            setInsertQueryTTParameters(stmt, tfThrottleTrans, "TT", TTOFF);
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert TTOFF Throttle Transaction", "Inserted TTOFF Throttle Transaction" + tfThrottleTrans, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, objId);
    }

    @Override
    public TFOneGeneralResponse insertHSBONThrottleTrans(TracfoneOneThrottleTrans tfThrottleTrans, int userId) throws TracfoneOneException {
        String objId;
        try (Connection con = dbControllerEJB.getDataSource(tfThrottleTrans.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(createTTSearchQuery(tfThrottleTrans));) {
            objId = getNextSequence(con, TRACFONE_TT_SEQ_STMT, TT_OBJID_SEQ);
            tfThrottleTrans.setObjId(objId);
            setInsertQueryTTParameters(stmt, tfThrottleTrans, "HS", HSBON);
            stmt.execute();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert HSBON Throttle Transaction", "Inserted HSBON Throttle Transaction" + tfThrottleTrans, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, objId);
    }

    @Override
    public TFOneGeneralResponse insertHSBOFThrottleTrans(TracfoneOneThrottleTrans tfThrottleTrans, int userId) throws TracfoneOneException {
        String objId;
        try (Connection con = dbControllerEJB.getDataSource(tfThrottleTrans.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(createTTSearchQuery(tfThrottleTrans));) {
            objId = getNextSequence(con, TRACFONE_TT_SEQ_STMT, TT_OBJID_SEQ);
            tfThrottleTrans.setObjId(objId);
            setInsertQueryTTParameters(stmt, tfThrottleTrans, "HS", "HSBOF");

            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert HSBOF Throttle Transaction", "Inserted HSBOF Throttle Transaction" + tfThrottleTrans, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, objId);
    }

    private void setInsertQueryTTParameters(PreparedStatement stmt, TracfoneOneThrottleTrans tfThrottleTrans,
                                            String throttleGroupType, String transactType) throws SQLException {
        int index = 1;
        stmt.setString(index++, tfThrottleTrans.getObjId());
        if (!StringUtils.isNullOrEmpty(throttleGroupType)) {
            stmt.setString(index++, throttleGroupType);
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getTransactionNum())) {
            stmt.setString(index++, tfThrottleTrans.getTransactionNum());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getRuleId())) {
            stmt.setString(index++, tfThrottleTrans.getRuleId());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getMin())) {
            stmt.setString(index++, tfThrottleTrans.getMin());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getEsn())) {
            stmt.setString(index++, tfThrottleTrans.getEsn());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getStatus())) {
            stmt.setString(index++, tfThrottleTrans.getStatus());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getApiStatus())) {
            stmt.setString(index++, tfThrottleTrans.getApiStatus());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getApiMessage())) {
            stmt.setString(index++, tfThrottleTrans.getApiMessage());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getSubscriberId())) {
            stmt.setString(index++, tfThrottleTrans.getSubscriberId());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getGroupId())) {
            stmt.setString(index++, tfThrottleTrans.getGroupId());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getPropagateFlagValue())) {
            stmt.setString(index++, tfThrottleTrans.getPropagateFlagValue());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getParentName())) {
            stmt.setString(index++, tfThrottleTrans.getParentName());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getUsageTierId())) {
            stmt.setString(index++, tfThrottleTrans.getUsageTierId());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getCos())) {
            stmt.setString(index++, tfThrottleTrans.getCos());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getPolicyName())) {
            stmt.setString(index++, tfThrottleTrans.getPolicyName());
        }

        setInsertQueryTTParameters2(index, stmt, transactType, tfThrottleTrans);
    }

    private void setInsertQueryTTParameters2(int index, PreparedStatement stmt,
                                             String transactType, TracfoneOneThrottleTrans tfThrottleTrans) throws SQLException {
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getEntitlement())) {
            stmt.setString(index++, tfThrottleTrans.getEntitlement());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getPriority())) {
            stmt.setString(index++, tfThrottleTrans.getPriority());
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getThreshold())) {
            stmt.setString(index++, tfThrottleTrans.getThreshold());
        }
        if (!StringUtils.isNullOrEmpty(transactType)) {
            stmt.setString(index, transactType);
        }
    }

    private String createTTSearchQuery(TracfoneOneThrottleTrans tfThrottleTrans) {
        StringBuilder builder = new StringBuilder
                ("insert INTO w3ci.TABLE_X_THROTTLING_TRANSACTION(OBJID, X_CREATION_DATE, X_LAST_UPDATE, THROTTLE_GROUP_TYPE ");
        StringBuilder totalColumnNo = new StringBuilder(", ?");
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getTransactionNum())) {
            builder.append(", X_TRANSACTION_NUM");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getRuleId())) {
            builder.append(", X_RULE_ID");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getMin())) {
            builder.append(", X_MIN");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getEsn())) {
            builder.append(", X_ESN");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getStatus())) {
            builder.append(", X_STATUS");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getApiStatus())) {
            builder.append(", X_API_STATUS");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getApiMessage())) {
            builder.append(", X_API_MESSAGE");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getSubscriberId())) {
            builder.append(", X_SUBSCRIBER_ID");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getGroupId())) {
            builder.append(", X_GROUP_ID");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getPropagateFlagValue())) {
            builder.append(", PROPAGATE_FLAG_VALUE");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getParentName())) {
            builder.append(", PARENT_NAME");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getUsageTierId())) {
            builder.append(", USAGE_TIER_ID");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getCos())) {
            builder.append(", COS");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getPolicyName())) {
            builder.append(", POLICY_NAME");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getEntitlement())) {
            builder.append(", ENTITLEMENT");
            totalColumnNo.append(", ?");
        }
        return createTTSearchQuery2(builder, totalColumnNo, tfThrottleTrans);
    }

    private String createTTSearchQuery2(StringBuilder builder, StringBuilder totalColumnNo, TracfoneOneThrottleTrans tfThrottleTrans) {
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getPriority())) {
            builder.append(", PRIORITY");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getThreshold())) {
            builder.append(", THRESHOLD");
            totalColumnNo.append(", ?");
        }
        if (!StringUtils.isNullOrEmpty(tfThrottleTrans.getTransactionType())) {
            builder.append(", X_TRANSACT_TYPE");
            totalColumnNo.append(", ?");
        }
        totalColumnNo.append(")");
        builder.append(") values (?, sysdate, sysdate ");
        return builder.append(totalColumnNo).toString();
    }

    @Override
    public List<String> getUsageTierId(String dbEnv) throws TracfoneOneException {
        List<String> usageTierIdList = new ArrayList<>(1);
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_USAGE_TIER_ID);) {
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    usageTierIdList.add(resultSet.getString("USAGE_TIER_ID"));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return usageTierIdList;
    }

    @Override
    public List<String> getCos(String dbEnv) throws TracfoneOneException {
        List<String> cosList = new ArrayList<>(1);
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_COS);) {
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    cosList.add(resultSet.getString("COS"));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return cosList;
    }

    @Override
    public List<String> getPriority(String dbEnv, String cos) throws TracfoneOneException {
        List<String> priorityList = new ArrayList<>(1);
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_PRIORITY);) {
            stmt.setString(1, cos);
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    priorityList.add(resultSet.getString("QUEUE_PRIORITY"));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return priorityList;
    }

    @Override
    public List<String> getThresholdEntitlement(String dbEnv, String columnName) throws TracfoneOneException {
        List<String> list = new ArrayList<>(1);
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT distinct ".concat(columnName)
                     .concat(" FROM x_policy_mapping_config"));) {
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    list.add(resultSet.getString(columnName));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return list;
    }

    @Override
    public List<String> getRuleId(String dbEnv, String objId) throws TracfoneOneException {
        List<String> ruleIdList = new ArrayList<>(1);
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_RULE_ID);) {
            stmt.setString(1, objId);
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    ruleIdList.add(resultSet.getString("objid"));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return ruleIdList;
    }
}
