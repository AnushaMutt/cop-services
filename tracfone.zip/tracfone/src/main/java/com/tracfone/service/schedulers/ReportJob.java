package com.tracfone.service.schedulers;

import com.google.gson.Gson;
import com.tracfone.service.model.event.TracfoneOneReportRequest;
import com.tracfone.service.model.report.TFOneReportAllFailures;
import com.tracfone.service.report.workers.AllFailuresWorkerBean;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Srinivas Murthy Pulavarthy
 */
@Singleton
public class ReportJob {

    @EJB
    AllFailuresWorkerBean failuresWorkerBean;

    @Inject
    private Event<TracfoneOneReportRequest> tracfoneOneConstantReportEvent;

    private static final Logger LOGGER = LogManager.getLogger(ReportJob.class);

//    @Schedule(second = "*/55", minute = "*", hour = "*", persistent = false)
    public void runAllFailuresReport() {
        try {
            List<TFOneReportAllFailures> igFailures = new ArrayList<>();
//            List<TFOneReportAllFailures> igFailures = failuresWorkerBean.runAllFailuresReport();
            if (!igFailures.isEmpty()) {
                Gson gson = new Gson();
                TracfoneOneReportRequest reportRequest = new TracfoneOneReportRequest();
                reportRequest.setJsonResponse(gson.toJson(igFailures));
                reportRequest.setReportName(TracfoneOneConstantReport.TRACFONE_REPORTNAME_ALLFAILURES);
                tracfoneOneConstantReportEvent.fire(reportRequest);
            } else {
                LOGGER.info("AllFailuresWorkerBean returned an empty response.");
            }
        } catch (Exception ex) {
            LOGGER.error("IG Failures report storing error. EX: " + ex.getMessage());
        }
    }

}
