/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.schedulers;

import com.tracfone.ejb.entity.TFTransactionArchive;
import com.tracfone.ejb.entity.session.TFTransactionArchiveFacadeLocal;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.model.request.TracfoneOneActionItemId;
import com.tracfone.service.model.request.TracfoneOneNewTransaction;
import com.tracfone.service.model.response.TFOneAdminActionItem;
import com.tracfone.service.model.response.TracfoneOneViewActionItems;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Stateless;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author druiz
 */
@Stateless
public class PurgeJob {

    @EJB
    TracfoneControllerLocal controllerEJB;

    @EJB
    TFTransactionArchiveFacadeLocal tfTransactionArchiveEJB;

    @EJB
    TracfoneControllerLocalAction reworkEJB;

    private static final Logger LOGGER = LogManager.getLogger(PurgeJob.class);

    /**
     * This method Deletes the past Audit Records.
     */
    @Schedule(second = "30", minute = "30", hour = "5", dayOfWeek = "*", persistent = false)
    public void purgeCopAudit() {

        try {
            controllerEJB.purgeUserAudit();
            LOGGER.info("Purgin Audit Records STSRT ");
        } catch (Exception ex) {
            LOGGER.error("COP Purge User Audit Error : " + ex.getMessage());
        }
        LOGGER.info("Purgin Audit Records COMPLETED");
    }

    /**
     * This method Deletes the past TFOneReports.
     */
    //@Schedule(second = "30", minute = "30", hour = "5", dayOfWeek = "*", persistent = false)
    public void purgeCopTFOneReport() {

        try {
            //controllerEJB.purgeTFOneReport();
            LOGGER.info("Purge Report Records START");
        } catch (Exception ex) {
            LOGGER.error("COP TF Report Purge Error :  " + ex.getMessage());
        }
        LOGGER.info("Purge Report Records COMPLETED");

    }

    /**
     * This method deactivates the Transaction eligible for Deactivation in TransactionArchives table.
     */
    //@Schedule( second = "*/55", minute = "*", hour = "*", persistent = false )
    public void deactiveCOPTransactionArchives() {

        try {
            String dbEnv = null;
            List<TFTransactionArchive> tfTransactionArchives = controllerEJB.deactiveCOPTransactionArchive();
            Map<String, TracfoneOneActionItemId> dbEnvTracfoneOneActionItemId = new HashMap<>();

            //Check if the List is not empty
            if (tfTransactionArchives.isEmpty()) {
                LOGGER.info("No Transactions to Deactivate.");
                return;
            } else {

                //Loop through all the TransactionArchives and set in HashMap
                for (TFTransactionArchive tfTransactionArchive : tfTransactionArchives) {

                    dbEnv = tfTransactionArchive.getDbEnv();
                    if (dbEnvTracfoneOneActionItemId.containsKey(dbEnv)) {
                        TracfoneOneActionItemId tracfoneOneActionItemId = (TracfoneOneActionItemId) dbEnvTracfoneOneActionItemId.get(dbEnv);
                        tracfoneOneActionItemId.getActionItemId().add(tfTransactionArchive.getActionItemId());
                    } else {
                        //get the transaction details
                        TracfoneOneActionItemId tracfoneOneActionItemId = new TracfoneOneActionItemId();
                        List<String> actionItemIds = new ArrayList<>();
                        actionItemIds.add(tfTransactionArchive.getActionItemId());
                        tracfoneOneActionItemId.setActionItemId(actionItemIds);
                        tracfoneOneActionItemId.setDbenv(dbEnv);
                        dbEnvTracfoneOneActionItemId.put(dbEnv, tracfoneOneActionItemId);
                    }
                }

                //Loop through all the Env and their respective TracfoneOneActionItemIds
                for (Map.Entry<String, TracfoneOneActionItemId> entry : dbEnvTracfoneOneActionItemId.entrySet()) {


                    TracfoneOneActionItemId tracfoneOneActionItemId = entry.getValue();

                    //Get the list of TracfoneOneViewActionItems
                    TracfoneOneViewActionItems tracfoneOneViewActionItems = reworkEJB.viewActionitemId(tracfoneOneActionItemId, -999);
                    List<TFOneAdminActionItem> tfOneAdminActionItem = tracfoneOneViewActionItems.getActionItems();

                    //Loop through the TDOneAdminActionItems and insert the deactivation record in IG_TRANSACTION
                    for (TFOneAdminActionItem tFOneAdminActionItem : tfOneAdminActionItem) {
                        TracfoneOneNewTransaction tfOneNewTransaction = new TracfoneOneNewTransaction();
                        tfOneNewTransaction.setMin(tFOneAdminActionItem.getMin());
                        tfOneNewTransaction.setEsn(tFOneAdminActionItem.getEsn());
                        tfOneNewTransaction.setRatePlan(tFOneAdminActionItem.getRatePlan());
                        tfOneNewTransaction.setStatus("Q");
                        tfOneNewTransaction.setStatus("COP deactivation JOB");
                        tfOneNewTransaction.setOrderType("D");
                        reworkEJB.insertTransaction(tfOneNewTransaction, -999, "COP JOB");
                    }

                    //Update the Transaction Ids Status in TransactionArchive in COP schema
                    for (TFTransactionArchive tfTransactionArchive : tfTransactionArchives) {
                        tfTransactionArchive.setStatus("C");
                        tfTransactionArchive.setStatus("COP deactivation Completed");
                        tfTransactionArchive.setModifieddate(Calendar.getInstance().getTime());
                        tfTransactionArchiveEJB.edit(tfTransactionArchive);
                    }
                }
            }
            LOGGER.info("Deactivation Job Completed.");
        } catch (Exception ex) {
            LOGGER.error("Deactivation Job failed with Errors. EX: " + ex.getMessage());
        }
    }


    /**
     * This method Deletes the past COP user history details.
     */
    //@Schedule(second = "30", minute = "30", hour = "5", dayOfWeek = "*", persistent = false)
    public void purgeCopUserHistoryAndDetails() {

        try {
            controllerEJB.purgeUserHistory();
            LOGGER.info("Purgin User History START");
        } catch (Exception ex) {
            LOGGER.error("Purgin User History error " + ex.getMessage());
        }
        LOGGER.info("Purgin User History COMPLETED");
    }

    /**
     * This method Deletes the past COP user Job details.
     */
    //@Schedule(second = "30", minute = "30", hour = "5", dayOfWeek = "*", persistent = false)
    public void purgeCopUserTasks() {

        try {
            controllerEJB.purgeUserTasks();
            LOGGER.info("Purgin User History START");
        } catch (Exception ex) {
            LOGGER.error("Purgin User History error " + ex.getMessage());
        }
        LOGGER.info("Purgin User History COMPLETED");
    }
}
