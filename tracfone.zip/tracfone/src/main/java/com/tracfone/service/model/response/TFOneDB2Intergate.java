package com.tracfone.service.model.response;

/**
 * @author Gaurav.Sharma
 */
public class TFOneDB2Intergate {

    private String queryId;
    private String queryName;
    private String activeFlag;
    private String useNewSql;
    private String intervalTime;
    private String selectQueryClob;
    private String numberOfRecords;
    private String updateQuery;
    private String templates;
    private String orderTypes;
    private String extraWhereClauseConditions;
    private String appName;
    private String startingRecord;
    private String remarks;

    public String getQueryId() {
        return queryId;
    }

    public void setQueryId(String queryId) {
        this.queryId = queryId;
    }

    public String getQueryName() {
        return queryName;
    }

    public void setQueryName(String queryName) {
        this.queryName = queryName;
    }

    public String getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(String activeFlag) {
        this.activeFlag = activeFlag;
    }

    public String getUseNewSql() {
        return useNewSql;
    }

    public void setUseNewSql(String useNewSql) {
        this.useNewSql = useNewSql;
    }

    public String getIntervalTime() {
        return intervalTime;
    }

    public void setIntervalTime(String intervalTime) {
        this.intervalTime = intervalTime;
    }

    public String getSelectQueryClob() {
        return selectQueryClob;
    }

    public void setSelectQueryClob(String selectQueryClob) {
        this.selectQueryClob = selectQueryClob;
    }

    public String getNumberOfRecords() {
        return numberOfRecords;
    }

    public void setNumberOfRecords(String numberOfRecords) {
        this.numberOfRecords = numberOfRecords;
    }

    public String getUpdateQuery() {
        return updateQuery;
    }

    public void setUpdateQuery(String updateQuery) {
        this.updateQuery = updateQuery;
    }

    public String getTemplates() {
        return templates;
    }

    public void setTemplates(String templates) {
        this.templates = templates;
    }

    public String getOrderTypes() {
        return orderTypes;
    }

    public void setOrderTypes(String orderTypes) {
        this.orderTypes = orderTypes;
    }

    public String getExtraWhereClauseConditions() {
        return extraWhereClauseConditions;
    }

    public void setExtraWhereClauseConditions(String extraWhereClauseConditions) {
        this.extraWhereClauseConditions = extraWhereClauseConditions;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getStartingRecord() {
        return startingRecord;
    }

    public void setStartingRecord(String startingRecord) {
        this.startingRecord = startingRecord;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "TFOneDB2Intergate{" +
                "queryId='" + queryId + '\'' +
                ", queryName='" + queryName + '\'' +
                ", activeFlag='" + activeFlag + '\'' +
                ", useNewSql='" + useNewSql + '\'' +
                ", intervalTime='" + intervalTime + '\'' +
                ", selectQueryClob='" + selectQueryClob + '\'' +
                ", numberOfRecords='" + numberOfRecords + '\'' +
                ", updateQuery='" + updateQuery + '\'' +
                ", templates='" + templates + '\'' +
                ", orderTypes='" + orderTypes + '\'' +
                ", extraWhereClauseConditions='" + extraWhereClauseConditions + '\'' +
                ", appName='" + appName + '\'' +
                ", startingRecord='" + startingRecord + '\'' +
                ", remarks='" + remarks + '\'' +
                '}';
    }
}
