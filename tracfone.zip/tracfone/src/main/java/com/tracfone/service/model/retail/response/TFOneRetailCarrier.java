package com.tracfone.service.model.retail.response;

public class TFOneRetailCarrier {
    private String objId;
    private String secUserId;
    private String status;
    private String carrier;
    private String carrierLong;
    private String insertDate;
    private String updateDate;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(String secUserId) {
        this.secUserId = secUserId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getCarrierLong() {
        return carrierLong;
    }

    public void setCarrierLong(String carrierLong) {
        this.carrierLong = carrierLong;
    }

    public String getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(String insertDate) {
        this.insertDate = insertDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    @Override
    public String toString() {
        return "TFOneRetailCarrier{" +
                "objId='" + objId + '\'' +
                ", secUserId=" + secUserId +
                ", status='" + status + '\'' +
                ", carrier='" + carrier + '\'' +
                ", carrierLong='" + carrierLong + '\'' +
                ", insertDate=" + insertDate +
                ", updateDate=" + updateDate +
                '}';
    }
}
