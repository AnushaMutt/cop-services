package com.tracfone.service.model.retail.response;

public class TFOneRetailTpNorm {
    private String objId;
    private String secUserId;
    private String tp2Zip;
    private String tp2CarrierDtl;
    private String rank;
    private String state;
    private String coverage;
    private String coverageNotes;
    private String env;
    private String insertDate;
    private String updateDate;
    private String carrier;
    private String brand;
    private String tech;
    private String carrierStatus;
    private String brandStatus;
    private String techStatus;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(String secUserId) {
        this.secUserId = secUserId;
    }

    public String getTp2Zip() {
        return tp2Zip;
    }

    public void setTp2Zip(String tp2Zip) {
        this.tp2Zip = tp2Zip;
    }

    public String getTp2CarrierDtl() {
        return tp2CarrierDtl;
    }

    public void setTp2CarrierDtl(String tp2CarrierDtl) {
        this.tp2CarrierDtl = tp2CarrierDtl;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCoverage() {
        return coverage;
    }

    public void setCoverage(String coverage) {
        this.coverage = coverage;
    }

    public String getCoverageNotes() {
        return coverageNotes;
    }

    public void setCoverageNotes(String coverageNotes) {
        this.coverageNotes = coverageNotes;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(String insertDate) {
        this.insertDate = insertDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getTech() {
        return tech;
    }

    public void setTech(String tech) {
        this.tech = tech;
    }

    public String getCarrierStatus() {
        return carrierStatus;
    }

    public void setCarrierStatus(String carrierStatus) {
        this.carrierStatus = carrierStatus;
    }

    public String getBrandStatus() {
        return brandStatus;
    }

    public void setBrandStatus(String brandStatus) {
        this.brandStatus = brandStatus;
    }

    public String getTechStatus() {
        return techStatus;
    }

    public void setTechStatus(String techStatus) {
        this.techStatus = techStatus;
    }

    @Override
    public String toString() {
        return "TFOneRetailTpNorm{" +
                "objId='" + objId + '\'' +
                ", secUserId='" + secUserId + '\'' +
                ", tp2Zip='" + tp2Zip + '\'' +
                ", tp2CarrierDtl='" + tp2CarrierDtl + '\'' +
                ", rank='" + rank + '\'' +
                ", state='" + state + '\'' +
                ", coverage='" + coverage + '\'' +
                ", coverageNotes='" + coverageNotes + '\'' +
                ", env='" + env + '\'' +
                ", insertDate='" + insertDate + '\'' +
                ", updateDate='" + updateDate + '\'' +
                ", carrier='" + carrier + '\'' +
                ", brand='" + brand + '\'' +
                ", tech='" + tech + '\'' +
                ", carrierStatus='" + carrierStatus + '\'' +
                ", brandStatus='" + brandStatus + '\'' +
                ", techStatus='" + techStatus + '\'' +
                '}';
    }
}
