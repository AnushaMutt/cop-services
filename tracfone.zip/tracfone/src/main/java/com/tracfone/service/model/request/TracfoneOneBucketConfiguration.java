/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 *
 * @author Shireen Fathima
 */
public class TracfoneOneBucketConfiguration {
    
    private String dbEnv;
    @Digits(integer=38, fraction=0, message = "Profile Id must be a number")
    private String servicePlanId;
    @Size(max=50, message = "Bucket Id cannot have more than 50 characters")
    private String bucketId;
    @Digits(integer=38, fraction=0, message = "Profile Id must be a number")
    private String bucketValue;
    @Size(max=20, message = "Bucket Type cannot have more than 20 characters")
    private String bucketType;
    @Size(max=1, message = "Is Child Flag cannot have more than 1 character")
    private String isChildFlag;
    @Size(max=1, message = "Is Active Flag cannot have more than 1 character")
    private String isActiveFlag;
    @Size(max=10, message = "Child Plan Id cannot have more than 10 characters")
    private String childPlanId;
    @Size(max=30, message = "Parent Short Name cannot have more than 30 characters")
    private String parentShortName;
    @Size(max=100, message = "Benefit Type cannot have more than 100 characters")
    private String benefitType;   

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }
    
    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public String getBucketId() {
        return bucketId;
    }

    public void setBucketId(String bucketId) {
        this.bucketId = bucketId;
    }

    public String getBucketValue() {
        return bucketValue;
    }

    public void setBucketValue(String bucketValue) {
        this.bucketValue = bucketValue;
    }

    public String getBucketType() {
        return bucketType;
    }

    public void setBucketType(String bucketType) {
        this.bucketType = bucketType;
    }

    public String getIsChildFlag() {
        return isChildFlag;
    }

    public void setIsChildFlag(String isChildFlag) {
        this.isChildFlag = isChildFlag;
    }

    public String getIsActiveFlag() {
        return isActiveFlag;
    }

    public void setIsActiveFlag(String isActiveFlag) {
        this.isActiveFlag = isActiveFlag;
    }

    public String getChildPlanId() {
        return childPlanId;
    }

    public void setChildPlanId(String childPlanId) {
        this.childPlanId = childPlanId;
    }

    public String getParentShortName() {
        return parentShortName;
    }

    public void setParentShortName(String parentShortName) {
        this.parentShortName = parentShortName;
    }

    public String getBenefitType() {
        return benefitType;
    }

    public void setBenefitType(String benefitType) {
        this.benefitType = benefitType;
    }

    @Override
    public String toString() {
        return "TracfoneOneBucketConfiguration{" + "dbEnv=" + dbEnv + ", "
                + "servicePlanId=" + servicePlanId + ", "
                + "bucketId=" + bucketId + ", "
                + "bucketValue=" + bucketValue + ", "
                + "bucketType=" + bucketType + ", "
                + "isChildFlag=" + isChildFlag + ", "
                + "isActiveFlag=" + isActiveFlag + ", "
                + "childPlanId=" + childPlanId + ", "
                + "parentShortName=" + parentShortName + ", "
                + "benefitType=" + benefitType + '}';
    }
    
    
    
}
