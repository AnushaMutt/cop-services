/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author Srinivas Murthy Pulavarthy
 */
public class TFOneTransactionArchive implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private TFOneAdminActionItem actionItem;
    
    private Long id;
     
    private Long userId;
    
    private String transactionId;
    
    private String actionItemId;
    
    private String status;
    
    private String dbEnv;
    
    private Date createdDate;
    
    private Date modifiedDate;
    
    private Date deactivationDate;

    public TFOneAdminActionItem getActionItem() {
        return actionItem;
    }

    public void setActionItem(TFOneAdminActionItem actionItem) {
        this.actionItem = actionItem;
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    
     public Date getDeactivationDate() {
        return deactivationDate;
    }

    public void setDeactivationDate(Date deactivationDate) {
        this.deactivationDate = deactivationDate;
    }

    public String getActionItemId() {
        return actionItemId;
    }

    public void setActionItemId(String actionItemId) {
        this.actionItemId = actionItemId;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }
    
    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TFOneTransactionArchive)) {
            return false;
        }
        TFOneTransactionArchive other = (TFOneTransactionArchive) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.tracfone.ejb.entity.TFTransactionArchive[ id=" + id + " ]";
    }
}
