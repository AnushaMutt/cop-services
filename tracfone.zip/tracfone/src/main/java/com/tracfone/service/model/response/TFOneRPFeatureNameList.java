/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

/**
 *
 * @author Nidhi Mantri
 * This one is use for master feature  table X_RP_FEATURE_NAME_LIST
 */
public class TFOneRPFeatureNameList {

    String featureName;
    
    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    @Override
    public String toString() {
        return "TFOneRPFeatureNameList{" + "featureName=" + featureName + '}';
    }
   
    
}


