package com.tracfone.service.model.retail.request;

public class TracfoneOneRetailTpAdminSearchModel {
    // for search
    private String zipCodes;
    private String states;
    private String carrierDetails;
    // for update
    private String objIds;
    private String coverage;
    private String coverageNotes;
    private String startIndex;
    private String endIndex;
    private boolean updateAll;

    public String getZipCodes() {
        return zipCodes;
    }

    public void setZipCodes(String zipCodes) {
        this.zipCodes = zipCodes;
    }

    public String getStates() {
        return states;
    }

    public void setStates(String states) {
        this.states = states;
    }

    public String getCarrierDetails() {
        return carrierDetails;
    }

    public void setCarrierDetails(String carrierDetails) {
        this.carrierDetails = carrierDetails;
    }

    public String getStartIndex() {
        return startIndex;
    }

    public void setStartIndex(String startIndex) {
        this.startIndex = startIndex;
    }

    public String getEndIndex() {
        return endIndex;
    }

    public void setEndIndex(String endIndex) {
        this.endIndex = endIndex;
    }

    public boolean isUpdateAll() {
        return updateAll;
    }

    public void setUpdateAll(boolean updateAll) {
        this.updateAll = updateAll;
    }

    public String getObjIds() {
        return objIds;
    }

    public void setObjIds(String objIds) {
        this.objIds = objIds;
    }

    public String getCoverage() {
        return coverage;
    }

    public void setCoverage(String coverage) {
        this.coverage = coverage;
    }

    public String getCoverageNotes() {
        return coverageNotes;
    }

    public void setCoverageNotes(String coverageNotes) {
        this.coverageNotes = coverageNotes;
    }

    @Override
    public String toString() {
        return "TracfoneOneRetailTpAdminSearchModel{" +
                "zipCodes='" + zipCodes + '\'' +
                ", states='" + states + '\'' +
                ", carrierDetails='" + carrierDetails + '\'' +
                ", objIds='" + objIds + '\'' +
                ", coverage='" + coverage + '\'' +
                ", coverageNotes='" + coverageNotes + '\'' +
                ", startIndex='" + startIndex + '\'' +
                ", endIndex='" + endIndex + '\'' +
                ", updateAll=" + updateAll +
                '}';
    }
}
