/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneAncillaryCode;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeConfig;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeDiscount;
import com.tracfone.service.model.request.TracfoneOneChildPlan;
import com.tracfone.service.model.request.TracfoneOneLineStatusCode;
import com.tracfone.service.model.request.TracfoneOneMultiRatePlanEsn;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtension;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionLink;
import com.tracfone.service.model.request.TracfoneOneRatePlanProfile;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneThrottleStatusCode;
import com.tracfone.service.model.response.TFOneAncillaryCode;
import com.tracfone.service.model.response.TFOneAncillaryCodeConfig;
import com.tracfone.service.model.response.TFOneAncillaryCodeDiscount;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneMultiRatePlanEsn;
import com.tracfone.service.model.response.TFOneRatePlanExtension;
import com.tracfone.service.model.response.TFOneRatePlanProfile;

import javax.ejb.Local;
import java.util.List;

/**
 * @author Shireen Fathima
 */
@Local
public interface TracfoneProfileControllerLocal {

    TFOneGeneralResponse insertProfile(TracfoneOneRatePlanProfile tfRatePlanProfile, int userId) throws TracfoneOneException;

    TFOneRatePlanProfile viewProfile(TracfoneOneRatePlanProfile tfRatePlanProfile) throws TracfoneOneException;

    TFOneGeneralResponse updateProfile(TracfoneOneRatePlanProfile tfRatePlanProfile, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteProfile(TracfoneOneRatePlanProfile tfRatePlanProfile, int userId) throws TracfoneOneException;

    List<TFOneAncillaryCode> getAllAncillaryCodes(String dbEnv) throws TracfoneOneException;

    List<TFOneChildPlan> getAllChildPlans(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse updateChildPlan(TracfoneOneChildPlan tfOneChildIdentifierList, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertChildPlan(TracfoneOneChildPlan tfOneChildIdentifierList, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteChildPlan(TracfoneOneChildPlan tfOneChildIdentifierList, int userId) throws TracfoneOneException;

    List<TFOneRatePlanProfile> searchProfile(TracfoneOneSearchProfileModel tfRatePlanProfile) throws TracfoneOneException;

    List<TFOneRatePlanProfile> searchProfilesForUpdate(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) throws TracfoneOneException;

    TFOneGeneralResponse deleteAncillaryCode(TracfoneOneAncillaryCode ancillaryCode, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertAncillaryCode(TracfoneOneAncillaryCode ancillaryCode, int userId) throws TracfoneOneException;

    List<TFOneAncillaryCode> searchAncillaryCodes(TracfoneOneAncillaryCode ancillaryCode) throws TracfoneOneException;

    TFOneGeneralResponse updateAncillaryCode(TracfoneOneAncillaryCode ancillaryCode, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteRpExtension(TracfoneOneRatePlanExtension tfRpExtension, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertRpExtension(TracfoneOneRatePlanExtension tfRpExtension, int userId) throws TracfoneOneException;

    List<TFOneRatePlanExtension> searchRpExtensions(TracfoneOneRatePlanExtension tfRatePlanExtension) throws TracfoneOneException;

    TFOneGeneralResponse insertRpExtensionLink(TracfoneOneRatePlanExtensionLink tfRpExtensionLink, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteRpExtensionLink(TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateRpExtensionLink(TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink, int userId) throws TracfoneOneException;

    List<TFOneCarrierServicePlan> getProfileServicePlans(String dbEnv, String profileId) throws TracfoneOneException;

    List<TFOneCarrierServicePlan> getRatePlanServicePlans(String dbEnv, String ratePlan) throws TracfoneOneException;

    TFOneGeneralResponse insertAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig, int userId) throws TracfoneOneException;

    List<TFOneAncillaryCodeConfig> getAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig) throws TracfoneOneException;

    List<TFOneAncillaryCodeDiscount> searchAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount) throws TracfoneOneException;

    TFOneGeneralResponse updateAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteLineStatusCode(TracfoneOneLineStatusCode tfOneLineStatus, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteThrottleStatusCode(TracfoneOneThrottleStatusCode tfOneThrottleStatusCode, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertMultiRatePlanEsn(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateMultiRatePlanEsn(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteMultiRatePlanEsn(List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsn, int userId) throws TracfoneOneException;

    List<TFOneMultiRatePlanEsn> searchMultiRatePlanEsns(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn) throws TracfoneOneException;

    void bulkInsertProfiles(List<TracfoneOneRatePlanProfile> tfRatePlanProfiles, int userId) throws TracfoneOneException;

    void bulkInsertRatePlanEsn(List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsn, int userId) throws TracfoneOneException;

    void bulkDeleteMultiRatePlanEsn(List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsn, int userId) throws TracfoneOneException;

    List<String> validateInsertProfiles(List<TracfoneOneRatePlanProfile> tfRatePlanProfiles, int userId) throws TracfoneOneException;
}
