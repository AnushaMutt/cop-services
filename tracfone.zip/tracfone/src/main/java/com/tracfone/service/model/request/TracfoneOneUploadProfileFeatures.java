/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.List;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * This will be used for the File Upload functionality to add profile features
 * x_rp_extension_config table
 * @author Shireen Fathima
 */
public class TracfoneOneUploadProfileFeatures {
    
    @NotNull(message = "Database cannot be null")
    @Size(min=1, message = "Database cannot be blank")
    private String dbEnv;
    @NotNull(message = "Insert Flag cannot be null")
    @Size(min=1, message = "Insert Flag cannot be blank")
    @Size(max=1, message = "Insert Flag cannot have more than one character")
    private String insertFlag;
    @NotNull(message = "Profile Id cannot be null")
    private String profileId;
    private List<TracfoneOneRatePlanExtensionConfig> successRpExtensionConfigs;
    private List<TracfoneOneRatePlanExtensionConfig> errorRpExtensionConfigs;

    public TracfoneOneUploadProfileFeatures() {
        successRpExtensionConfigs = new ArrayList<>();
        errorRpExtensionConfigs = new ArrayList<>();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getInsertFlag() {
        return insertFlag;
    }

    public void setInsertFlag(String insertFlag) {
        this.insertFlag = insertFlag;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public List<TracfoneOneRatePlanExtensionConfig> getSuccessRpExtensionConfigs() {
        return successRpExtensionConfigs;
    }

    public void setSuccessRpExtensionConfigs(List<TracfoneOneRatePlanExtensionConfig> successRpExtensionConfigs) {
        this.successRpExtensionConfigs = successRpExtensionConfigs;
    }

    public List<TracfoneOneRatePlanExtensionConfig> getErrorRpExtensionConfigs() {
        return errorRpExtensionConfigs;
    }

    public void setErrorRpExtensionConfigs(List<TracfoneOneRatePlanExtensionConfig> errorRpExtensionConfigs) {
        this.errorRpExtensionConfigs = errorRpExtensionConfigs;
    }

    @Override
    public String toString() {
        return "TracfoneOneUploadProfileFeatures{" + "dbEnv=" + dbEnv + ", "
                + "insertFlag=" + insertFlag + ", "
                + "profileId=" + profileId + ", "
                + "successRpExtensionConfigs=" + successRpExtensionConfigs + ", "
                + "errorRpExtensionConfigs=" + errorRpExtensionConfigs + '}';
    }

    
}
