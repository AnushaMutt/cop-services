/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneFeatureRequirement;
import com.tracfone.service.model.request.TracfoneOneLineStatusCode;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionConfig;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneThrottleStatusCode;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneFeatureRequirement;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneLineStatusCode;
import com.tracfone.service.model.response.TFOneRPFeatureNameList;
import com.tracfone.service.model.response.TFOneRatePlanExtensionConfig;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import com.tracfone.service.model.response.TFOneThrottleStatusCode;

import javax.ejb.Local;
import java.util.List;
import java.util.Set;

/**
 * @author Nidhi Mantri
 */
@Local
public interface TracfoneFeatureLocalAction {

    List<TFOneRPFeatureNameList> getAllMasterFeatures(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse insertRpExtensionConfig(List<TracfoneOneRatePlanExtensionConfig> tfOneRpExtensionConfigs, int userId, String unique) throws TracfoneOneException;

    List<TFOneRatePlanExtensionConfig> getAllProfileFeatures(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) throws TracfoneOneException;

    TFOneGeneralResponse deleteRpExtensionConfigs(String dbEnv, List<String> toBeDeletedIds, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateRpExtensionConfig(TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig, int userId) throws TracfoneOneException;

    List<String> findExistingMasterFeatures(String dbEnv, Set<String> featureNames) throws TracfoneOneException;

    void insertMasterFeature(String dbEnv, Set<String> featureNames, int userId) throws TracfoneOneException;

    List<TFOneRatePlanExtensionConfig> viewRpExtensionConfig(TracfoneOneRatePlanExtensionConfig searchConfig) throws TracfoneOneException;

    List<TFOneRatePlanProfile> searchBucketProfile(String dbEnv, String servicePlanId, boolean isChild) throws TracfoneOneException;

    List<TFOneCarrierServicePlan> getBucketServicePlansForCopy(String dbEnv, boolean isChild) throws TracfoneOneException;

    List<TFOneChildPlan> getBucketChildPlans(String dbEnv, String profileId, String servicePlanId) throws TracfoneOneException;

    List<TFOneLineStatusCode> getAllLineStatusCodes(String dbEnv) throws TracfoneOneException;

    List<TFOneThrottleStatusCode> getAllThrottleStatusCodes(String dbEnv) throws TracfoneOneException;

    List<TFOneCarrier> getAllCarrierIds(String dbEnv, String carrierName, String parent) throws TracfoneOneException;

    TFOneGeneralResponse insertLineStatusCode(TracfoneOneLineStatusCode tfOneLineStatus, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateLineStatusCode(TracfoneOneLineStatusCode tfOneLineStatus, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertThrottleStatusCode(TracfoneOneThrottleStatusCode tfThrottleStatusCode, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateThrottleStatusCode(TracfoneOneThrottleStatusCode tfThrottleStatusCode, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertFeatureRequirement(TracfoneOneFeatureRequirement tfFeatureRequirement, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateFeatureRequirement(TracfoneOneFeatureRequirement tfFeatureRequirement, int userId) throws TracfoneOneException;

    List<TFOneFeatureRequirement> getAllFeatureRequirements(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse deleteFeatureRequirement(TracfoneOneFeatureRequirement tfOneFeatureRequirement, int userId) throws TracfoneOneException;

    boolean checkFeatureRequirementDependencies(TracfoneOneFeatureRequirement tfOneFeatureRequirement) throws TracfoneOneException;

    Set<String> getAllFeatureValuesByProfileId(TracfoneOneRatePlanExtensionConfig tracfoneOneRatePlanExtensionConfig) throws TracfoneOneException;

    List<TFOneRatePlanExtensionConfig> searchProfileFeatures(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) throws TracfoneOneException;

    List<String> getAllFeatureValues(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse bulkUpdateProfileFeatures(TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig, int userId) throws TracfoneOneException;
}
