package com.tracfone.service.model.response;

/**
 * @author Thejaswini
 */
public class TFOneTmoZipNgp {
    private String zip;
    private String ngp;
    private String ngpName;
    private String priority;

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getNgp() {
        return ngp;
    }

    public void setNgp(String ngp) {
        this.ngp = ngp;
    }

    public String getNgpName() {
        return ngpName;
    }

    public void setNgpName(String ngpName) {
        this.ngpName = ngpName;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    @Override
    public String toString() {
        return "TFOneTmoZipNgp{" +
                "zip='" + zip + '\'' +
                ", ngp='" + ngp + '\'' +
                ", ngpName='" + ngpName + '\'' +
                ", priority='" + priority + '\'' +
                '}';
    }
}
