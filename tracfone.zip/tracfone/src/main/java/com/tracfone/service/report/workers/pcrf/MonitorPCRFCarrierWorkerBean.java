package com.tracfone.service.report.workers.pcrf;


import com.tracfone.service.model.report.TFOneReportPCRFMonitor;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Resource;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

@Stateless
public class MonitorPCRFCarrierWorkerBean {

    @Resource(lookup = "jndi/cop_report")
    private DataSource dataSourceReports;

    private AtomicBoolean busy = new AtomicBoolean(false);
    private static final Logger LOGGER = LogManager.getLogger(MonitorPCRFCarrierWorkerBean.class);

    @Lock(LockType.READ)
    public List<TFOneReportPCRFMonitor> runMonitorReport() {
        List<TFOneReportPCRFMonitor> pcrfMonitors = new ArrayList<>();

        if (!busy.compareAndSet(false, true)) {
            return pcrfMonitors;
        }

        try (Connection con = dataSourceReports.getConnection();
             PreparedStatement stmt = con.prepareStatement(TracfoneOneConstantReport.REPORT_SQL_PCRF_MONITOR);
             ResultSet resultSet = stmt.executeQuery();) {
            while (resultSet.next()) {
                TFOneReportPCRFMonitor pcrfMonitor = new TFOneReportPCRFMonitor();
                pcrfMonitor.setxDate(resultSet.getString("insert_timestamp"));
                pcrfMonitor.setPcrfParentName(resultSet.getString("pcrf_parent_name"));
                pcrfMonitor.setOrderType(resultSet.getString("order_type"));
                pcrfMonitor.setSumQ(resultSet.getString("sum_Q"));
                pcrfMonitor.setSumL(resultSet.getString("sum_L"));
                pcrfMonitor.setSumW(resultSet.getString("sum_W"));
                pcrfMonitor.setSumS(resultSet.getString("sum_S"));
                pcrfMonitor.setSumC(resultSet.getString("sum_C"));
                pcrfMonitor.setSumF(resultSet.getString("sum_F"));
                pcrfMonitor.setSumE(resultSet.getString("sum_E"));
                pcrfMonitor.setSumOthers(resultSet.getString("sum_others"));
                pcrfMonitors.add(pcrfMonitor);
            }
        } catch (Exception e) {
            LOGGER.error("PCRF Monitor Report Retrieval Error - ", e);
        } finally {
            busy.set(false);
        }
        return pcrfMonitors;
    }
}