package com.tracfone.service.model.request;

/**
 * @author Pritesh.Singh
 */

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

public class TracfoneOneGeoLoc {
    @Size(min = 1, message = "Zip cannot be null")
    private String zip;
    @Size(max = 2, message = "State cannot have more than 2 characters")
    private String state;
    @Digits(integer = 38, fraction = 0, message = "POPCY must be a number")
    private String popcy;
    @Digits(integer = 38, fraction = 0, message = "POP05 must be a number")
    private String pop05;
    @Digits(integer = 38, fraction = 9, message = "LATITUDE must be a number")
    private String latitude;
    @Digits(integer = 38, fraction = 9, message = "LONGITUDE must be a number")
    private String longitude;
    @Digits(integer = 38, fraction = 20, message = "RLATITUDE must be a number")
    private String rlatitude;
    @Digits(integer = 38, fraction = 20, message = "RLONGITUDE must be a number")
    private String rlongitude;
    @Digits(integer = 38, fraction = 40, message = "SRLATITUDE must be a number")
    private String srlatitude;
    @Digits(integer = 38, fraction = 40, message = "CRLATITUDE must be a number")
    private String crlatitude;
    @Digits(integer = 38, fraction = 0, message = "RZG2USER must be a number")
    private String rzg2user;
    private String oldZip;
    private boolean checkDuplicate;


    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPopcy() {
        return popcy;
    }

    public void setPopcy(String popcy) {
        this.popcy = popcy;
    }

    public String getPop05() {
        return pop05;
    }

    public void setPop05(String pop05) {
        this.pop05 = pop05;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getRlatitude() {
        return rlatitude;
    }

    public void setRlatitude(String rlatitude) {
        this.rlatitude = rlatitude;
    }

    public String getRlongitude() {
        return rlongitude;
    }

    public void setRlongitude(String rlongitude) {
        this.rlongitude = rlongitude;
    }

    public String getSrlatitude() {
        return srlatitude;
    }

    public void setSrlatitude(String srlatitude) {
        this.srlatitude = srlatitude;
    }

    public String getCrlatitude() {
        return crlatitude;
    }

    public void setCrlatitude(String crlatitude) {
        this.crlatitude = crlatitude;
    }

    public String getRzg2user() {
        return rzg2user;
    }

    public void setRzg2user(String rzg2user) {
        this.rzg2user = rzg2user;
    }

    public String getOldZip() {
        return oldZip;
    }

    public void setOldZip(String oldZip) {
        this.oldZip = oldZip;
    }

    public boolean isCheckDuplicate() {
        return checkDuplicate;
    }

    public void setCheckDuplicate(boolean checkDuplicate) {
        this.checkDuplicate = checkDuplicate;
    }

    @Override
    public String toString() {
        return "TracfoneOneGeoLoc{" +
                "zip='" + zip + '\'' +
                ", state='" + state + '\'' +
                ", popcy='" + popcy + '\'' +
                ", pop05='" + pop05 + '\'' +
                ", latitude='" + latitude + '\'' +
                ", longitude='" + longitude + '\'' +
                ", rlatitude='" + rlatitude + '\'' +
                ", rlongitude='" + rlongitude + '\'' +
                ", srlatitude='" + srlatitude + '\'' +
                ", crlatitude='" + crlatitude + '\'' +
                ", rzg2user='" + rzg2user + '\'' +
                ", oldZip='" + oldZip + '\'' +
                ", checkDuplicate=" + checkDuplicate +
                '}';
    }
}
