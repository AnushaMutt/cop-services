package com.tracfone.service.model.retail.request;

public class TracfoneOneRetailMaster {
    private String objId;
    private String status;
    private String storeName;
    private String master2Parent;
    private String secUserId;
    private String insertDate;
    private String updateDate;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getMaster2Parent() {
        return master2Parent;
    }

    public void setMaster2Parent(String master2Parent) {
        this.master2Parent = master2Parent;
    }

    public String getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(String secUserId) {
        this.secUserId = secUserId;
    }

    public String getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(String insertDate) {
        this.insertDate = insertDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    @Override
    public String toString() {
        return "TracfoneOneMaster{" +
                "objId='" + objId + '\'' +
                ", status='" + status + '\'' +
                ", storeName='" + storeName + '\'' +
                ", master2Parent='" + master2Parent + '\'' +
                ", secUserId='" + secUserId + '\'' +
                ", insertDate='" + insertDate + '\'' +
                ", updateDate='" + updateDate + '\'' +
                '}';
    }
}
