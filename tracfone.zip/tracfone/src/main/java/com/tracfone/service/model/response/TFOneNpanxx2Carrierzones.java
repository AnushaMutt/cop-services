package com.tracfone.service.model.response;

import com.tracfone.service.model.request.TracfoneonePaginationSearch;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

public class TFOneNpanxx2Carrierzones {
    private String npa;
    private String nxx;
    private String carrierId;
    private String carrierName;
    private String leadTime;
    private String targetLevel;
    private String rateCenter;
    private String state;
    private String carrierIdDescription;
    private String zone;
    private String county;
    private String marketId;
    private String mrktArea;
    private String sid;
    private String technology;
    private String frequency1;
    private String frequency2;
    private String btaMktNumber;
    private String btaMktName;
    private String gsmTech;
    private String cdmaTech;
    private String tdmaTech;
    private String mnc;
    private String dbEnv;
    private TracfoneonePaginationSearch paginationSearch;

    public String getNpa() {
        return npa;
    }

    public void setNpa(String npa) {
        this.npa = npa;
    }

    public String getNxx() {
        return nxx;
    }

    public void setNxx(String nxx) {
        this.nxx = nxx;
    }

    public String getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(String carrierId) {
        this.carrierId = carrierId;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getLeadTime() {
        return leadTime;
    }

    public void setLeadTime(String leadTime) {
        this.leadTime = leadTime;
    }

    public String getTargetLevel() {
        return targetLevel;
    }

    public void setTargetLevel(String targetLevel) {
        this.targetLevel = targetLevel;
    }

    public String getRateCenter() {
        return rateCenter;
    }

    public void setRateCenter(String rateCenter) {
        this.rateCenter = rateCenter;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCarrierIdDescription() {
        return carrierIdDescription;
    }

    public void setCarrierIdDescription(String carrierIdDescription) {
        this.carrierIdDescription = carrierIdDescription;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getMarketId() {
        return marketId;
    }

    public void setMarketId(String marketId) {
        this.marketId = marketId;
    }

    public String getMrktArea() {
        return mrktArea;
    }

    public void setMrktArea(String mrktArea) {
        this.mrktArea = mrktArea;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getTechnology() {
        return technology;
    }

    public void setTechnology(String technology) {
        this.technology = technology;
    }

    public String getFrequency1() {
        return frequency1;
    }

    public void setFrequency1(String frequency1) {
        this.frequency1 = frequency1;
    }

    public String getFrequency2() {
        return frequency2;
    }

    public void setFrequency2(String frequency2) {
        this.frequency2 = frequency2;
    }

    public String getBtaMktNumber() {
        return btaMktNumber;
    }

    public void setBtaMktNumber(String btaMktNumber) {
        this.btaMktNumber = btaMktNumber;
    }

    public String getBtaMktName() {
        return btaMktName;
    }

    public void setBtaMktName(String btaMktName) {
        this.btaMktName = btaMktName;
    }

    public String getGsmTech() {
        return gsmTech;
    }

    public void setGsmTech(String gsmTech) {
        this.gsmTech = gsmTech;
    }

    public String getCdmaTech() {
        return cdmaTech;
    }

    public void setCdmaTech(String cdmaTech) {
        this.cdmaTech = cdmaTech;
    }

    public String getTdmaTech() {
        return tdmaTech;
    }

    public void setTdmaTech(String tdmaTech) {
        this.tdmaTech = tdmaTech;
    }

    public String getMnc() {
        return mnc;
    }

    public void setMnc(String mnc) {
        this.mnc = mnc;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public TracfoneonePaginationSearch getPaginationSearch() {
        return paginationSearch;
    }

    public void setPaginationSearch(TracfoneonePaginationSearch paginationSearch) {
        this.paginationSearch = paginationSearch;
    }

    @Override
    public String toString() {
        return "TFOneNpanxx2Carrierzones{" +
                "npa='" + npa + '\'' +
                ", nxx='" + nxx + '\'' +
                ", carrierId='" + carrierId + '\'' +
                ", carrierName='" + carrierName + '\'' +
                ", leadTime='" + leadTime + '\'' +
                ", targetLevel='" + targetLevel + '\'' +
                ", rateCenter='" + rateCenter + '\'' +
                ", state='" + state + '\'' +
                ", carrierIdDescription='" + carrierIdDescription + '\'' +
                ", zone='" + zone + '\'' +
                ", county='" + county + '\'' +
                ", marketId='" + marketId + '\'' +
                ", mrktArea='" + mrktArea + '\'' +
                ", sid='" + sid + '\'' +
                ", technology='" + technology + '\'' +
                ", frequency1='" + frequency1 + '\'' +
                ", frequency2='" + frequency2 + '\'' +
                ", btaMktNumber='" + btaMktNumber + '\'' +
                ", btaMktName='" + btaMktName + '\'' +
                ", gsmTech='" + gsmTech + '\'' +
                ", cdmaTech='" + cdmaTech + '\'' +
                ", tdmaTech='" + tdmaTech + '\'' +
                ", mnc='" + mnc + '\'' +
                ", dbEnv='" + dbEnv + '\'' +
                '}';
    }
}
