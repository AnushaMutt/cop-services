package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneCarrierMaintenanceControllerLocal;
import com.tracfone.service.controller.TracfoneCarrierZonesDeploymentControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import com.tracfone.service.model.request.TracfoneOneCarrierZonesDeployment;
import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfig;
import com.tracfone.service.model.request.TracfoneOneNpaNxx2Carrier;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneCPrefResponse;
import com.tracfone.service.model.response.TFOneCarrierZonesDeployment;
import com.tracfone.service.model.response.TFOneCingularMrktInfo;
import com.tracfone.service.model.response.TFOneMissingCarrierZones;
import com.tracfone.service.model.response.TFOneMissingCingularMktInfo;
import com.tracfone.service.model.response.TFOneNpaNxx2Carrier;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author Gaurav.Sharma
 */
@Path("czdeploy")
public class TracfoneOneCarrierZonesDeploymentResource {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneCarrierZonesDeploymentResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @Context
    private SecurityContext securityContext;

    @EJB
    private TracfoneCarrierZonesDeploymentControllerLocal controllerLocal;

    @EJB
    private TracfoneCarrierMaintenanceControllerLocal tracfoneCarrierMaintenanceController;

    /**
     * This method is used to validate carrier zones based on the uploaded zip
     * codes
     *
     * @param carrierZonesDeployment
     * @return
     */
    @POST
    @Path("carrierzonesdplymnt/validatecarrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response validateCarrierZones(final TracfoneOneCarrierZonesDeployment carrierZonesDeployment) {
        TFOneCarrierZonesDeployment zonesDeployment;
        try {
            zonesDeployment = controllerLocal.validateCarrierZones(carrierZonesDeployment);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(zonesDeployment), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to validate NPANXX based on the uploaded zip codes
     *
     * @param carrierZonesDeployment
     * @return
     */
    @POST
    @Path("carrierzonesdplymnt/validatenpanxx")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response validateNpaNxx(final TracfoneOneCarrierZonesDeployment carrierZonesDeployment) {
        TFOneCarrierZonesDeployment zonesDeployment;
        try {
            zonesDeployment = controllerLocal.validateNpaNxx(carrierZonesDeployment);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(zonesDeployment), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to validate NPANXX based on the uploaded zip codes
     *
     * @param carrierZonesDeployment
     * @return
     */
    @POST
    @Path("carrierzonesdplymnt/validatearmarket")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response validateArMarket(final TracfoneOneCarrierZonesDeployment carrierZonesDeployment) {
        TFOneCarrierZonesDeployment zonesDeployment;
        try {
            zonesDeployment = controllerLocal.validateARUSA(carrierZonesDeployment);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(zonesDeployment), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to Insert Missing Carrier Zones into master table
     *
     * @param carrierZones
     * @param carrierName
     * @return
     */
    @POST
    @Path("carrierzonesdplymnt/addcarrierzones/{carriername}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response addCarrierZones(final List<TracfoneOneCarrierZones> carrierZones, @PathParam("carriername") final String carrierName) {
        TFOneMissingCarrierZones response;
        try {
            response = controllerLocal.insertMissingCarrierZones(carrierZones, getUserFromPrincipal().getUserId(), carrierName);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert carrier pref into master table carrierpref
     *
     * @param carrierZones
     * @return
     */
    @POST
    @Path("carrierzonesdplymnt/addcarrierpref")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response addCarrierPref(final List<TracfoneOneCarrierZones> carrierZones) {
        TFOneCPrefResponse response;
        try {
            response = controllerLocal.insertCPref(carrierZones, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert into master table npanxx2carrierzones
     *
     * @param nxx2Carriers
     * @return
     */
    @POST
    @Path("carrierzonesdplymnt/addnpanxx2carrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response addNpaNxx(final List<TracfoneOneNpaNxx2Carrier> nxx2Carriers) {
        TFOneNpaNxx2Carrier response;
        try {
            response = controllerLocal.insertNpaNxx(nxx2Carriers, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * @param mrktInfos
     * @return
     */
    @POST
    @Path("carrierzonesdplymnt/addcingularmktinfo")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response addCingularMktInfo(final List<TracfoneOneCingularMrktInfo> mrktInfos) {
        TFOneMissingCingularMktInfo response;
        try {
            response = controllerLocal.insertCingularMktInfo(mrktInfos, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to validate x_cingular_mrkt_info based on the uploaded zip
     * codes
     *
     * @param carrierZonesDeployment
     * @return
     */
    @POST
    @Path("carrierzonesdplymnt/validatecingularmrktinfo")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response validateCingularMrktInfo(final TracfoneOneCarrierZonesDeployment carrierZonesDeployment) {
        TFOneCarrierZonesDeployment zonesDeployment;
        try {
            zonesDeployment = controllerLocal.validateCingularMrktInfo(carrierZonesDeployment);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(zonesDeployment), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to validate ATT_ZIPMKTSUBMKT based on the uploaded zip codes
     *
     * @param carrierZonesDeployment
     * @return
     */
    @POST
    @Path("carrierzonesdplymnt/validatezipmktsubmkt")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response validateZipMktSubMkt(final TracfoneOneCarrierZonesDeployment carrierZonesDeployment) {
        TFOneCarrierZonesDeployment zonesDeployment;
        try {
            zonesDeployment = controllerLocal.validateZipMktSubMkt(carrierZonesDeployment);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(zonesDeployment), MediaType.APPLICATION_JSON).build();
    }

    /**
     * @param cingularMrktInfos
     * @return
     */
    @POST
    @Path("carrierzonesdplymnt/updatedealernan")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateDealerNan(List<TracfoneOneCingularMrktInfo> cingularMrktInfos) {
        List<TFOneCingularMrktInfo> cingularMrktInfoList;
        try {
            cingularMrktInfoList = controllerLocal.updateDealerNan(cingularMrktInfos);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(cingularMrktInfoList), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to validate tmobile_nextavailable@carrier table based on the uploaded zip codes
     *
     * @param carrierZonesDeployment
     * @return
     */
    @POST
    @Path("carrierzonesdplymnt/validatenextavailable")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response validateNextAvailable(final TracfoneOneCarrierZonesDeployment carrierZonesDeployment) {
        TFOneCarrierZonesDeployment zonesDeployment;
        try {
            zonesDeployment = controllerLocal.validateNextAvailable(carrierZonesDeployment);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(zonesDeployment), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert into master table npanxx2carrierzones
     *
     * @param nxx2Carriers
     * @return
     */
    @POST
    @Path("carrierzonesdplymnt/addtmonpanxx2carrierzones")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response addTmoNpaNxx(final List<TracfoneOneNpaNxx2Carrier> nxx2Carriers) {
        TFOneNpaNxx2Carrier response;
        try {
            response = controllerLocal.insertTmoNpaNxx(nxx2Carriers, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }


    /**
     * This method is used to insert into master table npanxx2carrierzones
     *
     * @param nxx2Carriers
     * @return
     */
    @POST
    @Path("carrierzonesdplymnt/addnpanxx2carrierzonesatt")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response addNpaNxxAtt(final List<TracfoneOneNpaNxx2Carrier> nxx2Carriers) {
        TFOneNpaNxx2Carrier response;
        try {
            response = controllerLocal.insertNpaNxxAtt(nxx2Carriers, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all carriers
     *
     * @param carrierConfig
     * @return
     */
    @POST
    @Path("carrierzonesdplymnt/getcarriers")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarriers(final TracfoneOneIGCarrierConfig carrierConfig) {
        List<String> carrierData = new ArrayList<>();
        try {
            carrierData = controllerLocal.getCarriers(carrierConfig);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(carrierData), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves the user object making request from the principal.
     *
     * @return
     */
    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }
}
