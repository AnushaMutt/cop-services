/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

import com.tracfone.service.model.request.TracfoneonePaginationSearch;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author druiz
 */
@XmlRootElement(name = "ViewActionItemRequest")
public class TracfoneOneViewActionItems {

    @XmlElement(name = "actionItems")
    List<TFOneAdminActionItem> actionItems;
    @XmlElement(name = "pagination")
    private TracfoneonePaginationSearch paginationSearch;

    public List<TFOneAdminActionItem> getActionItems() {
        return actionItems;
    }

    public void setActionItems(List<TFOneAdminActionItem> actionItems) {
        this.actionItems = actionItems;
    }

    public TracfoneonePaginationSearch getPaginationSearch() {
        return paginationSearch;
    }

    public void setPaginationSearch(TracfoneonePaginationSearch paginationSearch) {
        this.paginationSearch = paginationSearch;
    }

}
