package com.tracfone.service.model.retail.request;

import java.util.Date;

/**
 * C_RTL_CARRIER
 *
 * @author Pritesh Singh
 */
public class TracfoneOneRetailCarrier {
    private String objId;
    private String secUserId;
    private String status;
    private String carrier;
    private String carrierLong;
    private Date insertDate;
    private Date updateDate;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(String secUserId) {
        this.secUserId = secUserId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getCarrierLong() {
        return carrierLong;
    }

    public void setCarrierLong(String carrierLong) {
        this.carrierLong = carrierLong;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    @Override
    public String toString() {
        return "TracfoneOneRetailCarrier{" +
                "objId='" + objId + '\'' +
                ", secUserId='" + secUserId + '\'' +
                ", status='" + status + '\'' +
                ", carrier='" + carrier + '\'' +
                ", carrierLong='" + carrierLong + '\'' +
                ", insertDate=" + insertDate +
                ", updateDate=" + updateDate +
                '}';
    }
}

