package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneBucketControllerLocal;
import com.tracfone.service.controller.TracfoneFeatureControllerLocal;
import com.tracfone.service.controller.TracfoneRatePlanControllerLocal;
import com.tracfone.service.controller.TracfoneServicePlanControllerLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.model.request.TracfoneOneBucketList;
import com.tracfone.service.model.request.TracfoneOneFeatureRequirement;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchServicePlanModel;
import com.tracfone.service.model.response.TFOneBusinessOrganization;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneFeatureRequirement;
import com.tracfone.service.model.response.TFOneRPFeatureNameList;
import com.tracfone.service.model.response.TFOneRatePlan;
import com.tracfone.service.model.response.TFOneRatePlanExtensionConfig;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * This resource file is going to be used for all services in the View Service Plan
 *
 * @author Pritesh Singh
 */
@Path("serviceplan")
public class TracfoneOneViewServicePlanResource {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneViewServicePlanResource.class);

    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @EJB
    private TracfoneBucketControllerLocal tracfoneBucketController;

    @EJB
    private TracfoneFeatureControllerLocal tracfoneFeatureController;

    @EJB
    private TracfoneRatePlanControllerLocal tracfoneRatePlanController;

    @EJB
    private TracfoneServicePlanControllerLocal tracfoneServicePlanController;

    /**
     * This method is used to retrieve all carriers available in
     * table_x_carrier_features
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("servicerateplanview/viewcarriers")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllCarrierNames(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<String> carrierNames = new ArrayList<>();
        try {
            carrierNames = tracfoneRatePlanController.getAllCarrierNames(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierNames), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all service plans based on the selected
     * carrier
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("servicerateplanview/viewserviceplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getServicePlansForCarrier(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        try {
            carrierServicePlans = tracfoneServicePlanController.getServicePlansForCarrier(tracfoneOneSearchPlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierServicePlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all rate plan names from the master table
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("servicerateplanview/viewcarrierrateplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierRatePlans(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneRatePlan> ratePlans = new ArrayList<>();
        try {
            ratePlans = tracfoneServicePlanController.getCarrierRatePlans(tracfoneOneSearchPlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(ratePlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all business orgs for a drop down
     * required when adding carrier features
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("servicerateplanview/viewbusorgs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllBusinessOrgs(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneBusinessOrganization> allBusOrgs = new ArrayList<>();
        try {
            allBusOrgs = tracfoneRatePlanController.getAllBusinessOrgs(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(allBusOrgs), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all the objects from the bucket master
     * table BUCKET_LIST
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("servicerateplanview/viewallbucketlist")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllBucketList(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TracfoneOneBucketList> tracfoneOneBucketLists = null;
        try {
            tracfoneOneBucketLists = tracfoneBucketController.getAllBucketList(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tracfoneOneBucketLists), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieve the list of feature from master
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("servicerateplanview/viewallmasterfeatures")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllMasterFeatures(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneRPFeatureNameList> features = null;

        try {
            features = tracfoneFeatureController.getAllMasterFeatures(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(features), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for service plans
     *
     * @param tfServicePlanModel
     * @return
     */
    @POST
    @Path("servicerateplanview/searchserviceplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchServicePlans(final TracfoneOneSearchServicePlanModel tfServicePlanModel) {
        List<TFOneCarrierServicePlan> servicePlans = null;
        try {
            servicePlans = tracfoneServicePlanController.searchServicePlans(tfServicePlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(servicePlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to view carrier features associated to a service plan id
     *
     * @param tfServicePlanModel
     * @return
     */
    @POST
    @Path("servicerateplanview/viewserviceplancarrierfeatures")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response viewServicePlanCarrierFeatures(final TracfoneOneSearchServicePlanModel tfServicePlanModel) {
        List<TFOneCarrierFeature> carrierFeatures = null;
        try {
            carrierFeatures = tracfoneServicePlanController.viewServicePlanCarrierFeatures(tfServicePlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierFeatures), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieve the list of RP Extension Links on basis of Carrier Feature ObjId
     *
     * @param tfServicePlanModel
     * @return
     */
    @POST
    @Path("servicerateplanview/viewcarrierfeaturelinks")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierFeatureLinks(final TracfoneOneSearchServicePlanModel tfServicePlanModel) {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        try {
            carrierFeatures = tracfoneServicePlanController.getCarrierFeatureLinks(tfServicePlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierFeatures), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieve the list of features from rp_extension Config on basis of
     * profile ids
     *
     * @param tfServicePlanModel
     * @return
     */
    @POST
    @Path("servicerateplanview/viewallprofilesfeatures")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllProfileFeatures(final TracfoneOneSearchServicePlanModel tfServicePlanModel) {
        List<TFOneRatePlanExtensionConfig> profileFeatures = new ArrayList<>();

        try {
            profileFeatures = tracfoneServicePlanController.getAllProfileFeatures(tfServicePlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(profileFeatures), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for Carrier_Profile_Buckets based on service plan and profile
     *
     * @param tfServicePlanModel
     * @return
     */
    @POST
    @Path("servicerateplanview/searchcpbuckets")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierProfileBuckets(final TracfoneOneSearchServicePlanModel tfServicePlanModel) {
        List<TFOneCarrierProfileBucket> tfOneBuckets = new ArrayList<>();
        try {
            tfOneBuckets = tracfoneServicePlanController.searchCarrierProfileBuckets(tfServicePlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneBuckets), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for Carrier_Profile_Child_Buckets based on
     * service plan, profile and child plan
     *
     * @param tfServicePlanModel
     * @return
     */
    @POST
    @Path("servicerateplanview/searchcpchildbuckets")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierProfileChildBuckets(final TracfoneOneSearchServicePlanModel tfServicePlanModel) {
        List<TFOneCarrierProfileChildBucket> tfOneBuckets = new ArrayList<>();
        try {
            tfOneBuckets = tracfoneServicePlanController.searchCarrierProfileChildBuckets(tfServicePlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneBuckets), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all X_RP_FEATURE_REQUIREMENT
     *
     * @param tfFeatureRequirement
     * @return
     */
    @POST
    @Path("servicerateplanview/viewfeaturerequirements")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllFeatureRequirements(final TracfoneOneFeatureRequirement tfFeatureRequirement) {
        List<TFOneFeatureRequirement> tfFeatureRequirements = new ArrayList<>();
        try {
            tfFeatureRequirements = tracfoneFeatureController.getAllFeatureRequirements(tfFeatureRequirement.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfFeatureRequirements), MediaType.APPLICATION_JSON).build();
    }

}
