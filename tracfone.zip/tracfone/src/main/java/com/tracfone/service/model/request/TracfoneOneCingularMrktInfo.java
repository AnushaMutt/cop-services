package com.tracfone.service.model.request;

import javax.validation.constraints.Size;

/**
 * @author Thejaswini
 */
public class TracfoneOneCingularMrktInfo {
    @Size(min = 1, message = "MKT cannot be null")
    @Size(max = 20, message = "MKT cannot have more than 20 characters")
    private String mkt;
    @Size(max = 20, message = "NPA cannot have more than 20 characters")
    private String npa;
    @Size(max = 20, message = "NXX cannot have more than 20 characters")
    private String nxx;
    @Size(max = 20, message = "NPANXX cannot have more than 20 characters")
    private String npanxx;
    @Size(min = 1, message = "RC Number cannot be null")
    @Size(max = 20, message = "RC Number cannot have more than 20 characters")
    private String rcNumber;
    @Size(min = 1, message = "RC Name cannot be null")
    @Size(max = 20, message = "RC Name cannot have more than 20 characters")
    private String rcName;
    @Size(min = 1, message = "RC State cannot be null")
    @Size(max = 20, message = "RC State cannot have more than 20 characters")
    private String rcState;
    @Size(min = 1, message = "Zip cannot be null")
    @Size(max = 20, message = "Zip cannot have more than 20 characters")
    private String zip;
    @Size(min = 1, message = "MKT Type cannot be null")
    @Size(max = 20, message = "MKT Type cannot have more than 20 characters")
    private String mktType;
    @Size(min = 1, message = "Account Num cannot be null")
    @Size(max = 30, message = "Account Num cannot have more than 30 characters")
    private String accountNum;
    @Size(min = 1, message = "Market Code cannot be null")
    @Size(max = 30, message = "Market Code cannot have more than 30 characters")
    private String marketCode;
    @Size(max = 30, message = "Dealer Code cannot have more than 30 characters")
    private String dealerCode;
    @Size(max = 30, message = "Sub Market Id cannot have more than 30 characters")
    private String subMarketId;
    @Size(max = 20, message = "Template cannot have more than 20 characters")
    private String template;
    private String oldZip;
    private String dbEnv;
    private String reasonToFail;
    private String techReasonToFail;

    public String getMkt() {
        return mkt;
    }

    public void setMkt(String mkt) {
        this.mkt = mkt;
    }

    public String getNpa() {
        return npa;
    }

    public void setNpa(String npa) {
        this.npa = npa;
    }

    public String getNxx() {
        return nxx;
    }

    public void setNxx(String nxx) {
        this.nxx = nxx;
    }

    public String getNpanxx() {
        return npanxx;
    }

    public void setNpanxx(String npanxx) {
        this.npanxx = npanxx;
    }

    public String getRcNumber() {
        return rcNumber;
    }

    public void setRcNumber(String rcNumber) {
        this.rcNumber = rcNumber;
    }

    public String getRcName() {
        return rcName;
    }

    public void setRcName(String rcName) {
        this.rcName = rcName;
    }

    public String getRcState() {
        return rcState;
    }

    public void setRcState(String rcState) {
        this.rcState = rcState;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getMktType() {
        return mktType;
    }

    public void setMktType(String mktType) {
        this.mktType = mktType;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getMarketCode() {
        return marketCode;
    }

    public void setMarketCode(String marketCode) {
        this.marketCode = marketCode;
    }

    public String getDealerCode() {
        return dealerCode;
    }

    public void setDealerCode(String dealerCode) {
        this.dealerCode = dealerCode;
    }

    public String getSubMarketId() {
        return subMarketId;
    }

    public void setSubMarketId(String subMarketId) {
        this.subMarketId = subMarketId;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getOldZip() {
        return oldZip;
    }

    public void setOldZip(String oldZip) {
        this.oldZip = oldZip;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getReasonToFail() {
        return reasonToFail;
    }

    public void setReasonToFail(String reasonToFail) {
        this.reasonToFail = reasonToFail;
    }

    public String getTechReasonToFail() {
        return techReasonToFail;
    }

    public void setTechReasonToFail(String techReasonToFail) {
        this.techReasonToFail = techReasonToFail;
    }

    @Override
    public String toString() {
        return "TracfoneOneCingularMrktInfo{" +
                "mkt='" + mkt + '\'' +
                ", npa='" + npa + '\'' +
                ", nxx='" + nxx + '\'' +
                ", npanxx='" + npanxx + '\'' +
                ", rcNumber='" + rcNumber + '\'' +
                ", rcName='" + rcName + '\'' +
                ", rcState='" + rcState + '\'' +
                ", zip='" + zip + '\'' +
                ", mktType='" + mktType + '\'' +
                ", accountNum='" + accountNum + '\'' +
                ", marketCode='" + marketCode + '\'' +
                ", dealerCode='" + dealerCode + '\'' +
                ", subMarketId='" + subMarketId + '\'' +
                ", template='" + template + '\'' +
                ", oldZip='" + oldZip + '\'' +
                ", dbEnv='" + dbEnv + '\'' +
                ", reasonToFail='" + reasonToFail + '\'' +
                ", techReasonToFail='" + techReasonToFail + '\'' +
                '}';
    }
}
