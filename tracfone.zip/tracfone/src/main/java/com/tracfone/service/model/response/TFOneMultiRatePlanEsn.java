package com.tracfone.service.model.response;

public class TFOneMultiRatePlanEsn {
    private String xEsn;
    private String xPriority;
    private String xServicePlanId;
    private String xDateAdded;
    private String xReason;
    private String delFlag;
    private String xProductId;

    public String getxEsn() {
        return xEsn;
    }

    public void setxEsn(String xEsn) {
        this.xEsn = xEsn;
    }

    public String getxPriority() {
        return xPriority;
    }

    public void setxPriority(String xPriority) {
        this.xPriority = xPriority;
    }

    public String getxServicePlanId() {
        return xServicePlanId;
    }

    public void setxServicePlanId(String xServicePlanId) {
        this.xServicePlanId = xServicePlanId;
    }

    public String getxDateAdded() {
        return xDateAdded;
    }

    public void setxDateAdded(String xDateAdded) {
        this.xDateAdded = xDateAdded;
    }

    public String getxReason() {
        return xReason;
    }

    public void setxReason(String xReason) {
        this.xReason = xReason;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public String getxProductId() {
        return xProductId;
    }

    public void setxProductId(String xProductId) {
        this.xProductId = xProductId;
    }

    @Override
    public String toString() {
        return "TFOneMultiRatePlanEsns{" +
                "xEsn='" + xEsn + '\'' +
                ", xPrority='" + xPriority + '\'' +
                ", xServicePlanId='" + xServicePlanId + '\'' +
                ", xDateAdded='" + xDateAdded + '\'' +
                ", xReason='" + xReason + '\'' +
                ", delFlag='" + delFlag + '\'' +
                ", xProductId='" + xProductId + '\'' +
                '}';
    }
}
