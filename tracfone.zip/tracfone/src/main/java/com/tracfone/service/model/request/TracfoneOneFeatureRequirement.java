package com.tracfone.service.model.request;

import javax.validation.constraints.Size;

/**
 * X_RP_FEATURE_REQUIREMENT
 *
 * @author Pritesh Singh
 */
public class TracfoneOneFeatureRequirement {
    private String dbEnv;
    @Size(min = 1, message = "Feature Requirement cannot be blank")
    @Size(max = 3, message = "Feature Requirement cannot have more than 3 characters")
    private String featureRequirement;
    @Size(min = 1, message = "Description cannot be blank")
    @Size(max = 20, message = "Description cannot have more than 20 characters")
    private String description;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getFeatureRequirement() {
        return featureRequirement;
    }

    public void setFeatureRequirement(String featureRequirement) {
        this.featureRequirement = featureRequirement;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "TracfoneOneFeatureRequirement{" +
                "dbEnv='" + dbEnv + '\'' +
                ", featureRequirement='" + featureRequirement + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
