/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * x_apn
 * @author Shireen Fathima
 */
public class TracfoneOneApn {
    
    private String dbEnv;
    @NotNull(message = "Parent Name cannot be null")
    @Size(min=1, message = "Parent Name cannot be blank")
    @Size(max=60, message = "Parent Name cannot have more than 60 characters")
    private String xParentName;
    private String oldParentName;
    @NotNull(message = "Rate Plan Name cannot be null")
    @Size(min=1, message = "Rate Plan Name cannot be blank")
    @Size(max=60, message = "Rate Plan Name cannot have more than 60 characters")
    private String ratePlan;
    @NotNull(message = "Brand cannot be null")
    @Size(min=1, message = "Brand cannot be blank")
    @Size(max=30, message = "Brand cannot have more than 30 characters")
    private String orgId;
    private String oldOrgId;
    @NotNull(message = "APN cannot be null")
    @Size(min=1, message = "APN cannot be blank")
    @Size(max=30, message = "APN cannot have more than 30 characters")
    private String apn;
    private String oldApn;
    @Size(max=30, message = "Username cannot have more than 30 characters")
    private String username;
    @Size(max=30, message = "Password cannot have more than 30 characters")
    private String password;
    @Size(max=30, message = "Auth Type cannot have more than 30 characters")
    private String authType;
    @Size(max=300, message = "Proxy Address cannot have more than 30 characters")
    private String proxyAddress;
    @Size(max=30, message = "Proxy Port cannot have more than 30 characters")
    private String proxyPort;
    @Size(max=30, message = "Connection Type cannot have more than 30 characters")
    private String connectionType;
    @Size(max=300, message = "MMS APN cannot have more than 300 characters")
    private String mmsApn;
    @Size(max=30, message = "MMS Username cannot have more than 30 characters")
    private String mmsUsername;
    @Size(max=30, message = "MMS Password cannot have more than 30 characters")
    private String mmsPassword;
    @Size(max=30, message = "MMS Auth Type cannot have more than 30 characters")
    private String mmsAuthType;
    @Size(max=300, message = "MMSC cannot have more than 300 characters")
    private String mmsc;
    @Size(max=300, message = "MMS Proxy Address cannot have more than 300 characters")
    private String mmsProxyAddress;
    @Size(max=30, message = "MMS Proxy Port cannot have more than 30 characters")
    private String mmsProxyPort;
    @Size(max=30, message = "MMS APN Type cannot have more than 30 characters")
    private String mmsApnType;
    @Size(max=300, message = "RTSP Proxy Address cannot have more than 300 characters")
    private String rtspProxyAddr;
    @Size(max=30, message = "RTSP Proxy Port cannot have more than 30 characters")
    private String rtspProxyPort;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getxParentName() {
        return xParentName;
    }

    public void setxParentName(String xParentName) {
        this.xParentName = xParentName;
    }

    public String getOldParentName() {
        return oldParentName;
    }

    public void setOldParentName(String oldParentName) {
        this.oldParentName = oldParentName;
    }

    public String getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(String ratePlan) {
        this.ratePlan = ratePlan;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getApn() {
        return apn;
    }

    public void setApn(String apn) {
        this.apn = apn;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAuthType() {
        return authType;
    }

    public void setAuthType(String authType) {
        this.authType = authType;
    }

    public String getProxyAddress() {
        return proxyAddress;
    }

    public void setProxyAddress(String proxyAddress) {
        this.proxyAddress = proxyAddress;
    }

    public String getProxyPort() {
        return proxyPort;
    }

    public void setProxyPort(String proxyPort) {
        this.proxyPort = proxyPort;
    }

    public String getConnectionType() {
        return connectionType;
    }

    public void setConnectionType(String connectionType) {
        this.connectionType = connectionType;
    }

    public String getMmsApn() {
        return mmsApn;
    }

    public void setMmsApn(String mmsApn) {
        this.mmsApn = mmsApn;
    }

    public String getMmsUsername() {
        return mmsUsername;
    }

    public void setMmsUsername(String mmsUsername) {
        this.mmsUsername = mmsUsername;
    }

    public String getMmsPassword() {
        return mmsPassword;
    }

    public void setMmsPassword(String mmsPassword) {
        this.mmsPassword = mmsPassword;
    }

    public String getMmsAuthType() {
        return mmsAuthType;
    }

    public void setMmsAuthType(String mmsAuthType) {
        this.mmsAuthType = mmsAuthType;
    }

    public String getMmsc() {
        return mmsc;
    }

    public void setMmsc(String mmsc) {
        this.mmsc = mmsc;
    }

    public String getMmsProxyAddress() {
        return mmsProxyAddress;
    }

    public void setMmsProxyAddress(String mmsProxyAddress) {
        this.mmsProxyAddress = mmsProxyAddress;
    }

    public String getMmsProxyPort() {
        return mmsProxyPort;
    }

    public void setMmsProxyPort(String mmsProxyPort) {
        this.mmsProxyPort = mmsProxyPort;
    }

    public String getMmsApnType() {
        return mmsApnType;
    }

    public void setMmsApnType(String mmsApnType) {
        this.mmsApnType = mmsApnType;
    }

    public String getRtspProxyAddr() {
        return rtspProxyAddr;
    }

    public void setRtspProxyAddr(String rtspProxyAddr) {
        this.rtspProxyAddr = rtspProxyAddr;
    }

    public String getRtspProxyPort() {
        return rtspProxyPort;
    }

    public void setRtspProxyPort(String rtspProxyPort) {
        this.rtspProxyPort = rtspProxyPort;
    }

    public String getOldOrgId() {
        return oldOrgId;
    }

    public void setOldOrgId(String oldOrgId) {
        this.oldOrgId = oldOrgId;
    }

    public String getOldApn() {
        return oldApn;
    }

    public void setOldApn(String oldApn) {
        this.oldApn = oldApn;
    }
    

    @Override
    public String toString() {
        return "TracfoneOneApn{" + "dbEnv=" + dbEnv + ", "
                + "xParentName=" + xParentName + ", "
                + "oldParentName=" + oldParentName + ", "
                + "ratePlan=" + ratePlan + ", "
                + "orgId=" + orgId + ", "
                + "oldOrgId=" + oldOrgId + ", "
                + "apn=" + apn + ", "
                + "oldApn=" + oldApn + ", "
                + "username=" + username + ", "
                + "password=" + password + ", "
                + "authType=" + authType + ", "
                + "proxyAddress=" + proxyAddress + ", "
                + "proxyPort=" + proxyPort + ", "
                + "connectionType=" + connectionType + ", "
                + "mmsApn=" + mmsApn + ", "
                + "mmsUsername=" + mmsUsername + ", "
                + "mmsPassword=" + mmsPassword + ", "
                + "mmsAuthType=" + mmsAuthType + ", "
                + "mmsc=" + mmsc + ", "
                + "mmsProxyAddress=" + mmsProxyAddress + ", "
                + "mmsProxyPort=" + mmsProxyPort + ", "
                + "mmsApnType=" + mmsApnType + ", "
                + "rtspProxyAddr=" + rtspProxyAddr + ", "
                + "rtspProxyPort=" + rtspProxyPort + '}';
    }
    
}
