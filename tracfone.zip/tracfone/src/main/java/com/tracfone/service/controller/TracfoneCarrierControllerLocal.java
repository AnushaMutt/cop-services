package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneCarrierSubscriber;
import com.tracfone.service.model.response.TFOneCarrierSubscriber;
import javax.ejb.Local;
import java.util.List;

/**
 *
 * @author Srinivas Murthy Pulavarthy
 */
@Local
public interface TracfoneCarrierControllerLocal { 
    
    /**
     * 
     * @param userId
     * @param subscriberInfo
     * @return
     * @throws TracfoneOneException 
     */
    public TFOneCarrierSubscriber inquireSubscriber(int userId, final TracfoneOneCarrierSubscriber subscriberInfo) throws TracfoneOneException;

    public List<TFOneCarrierSubscriber> bulkInquiry(int userId, final TracfoneOneCarrierSubscriber subscriberInfo) throws TracfoneOneException;


}
