/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

/**
 * @author Shireen Fathima
 */
public class TFOneCarrier {
    private String objId;
    private String carrierId;
    private String submarketName;
    private String submarketOf;
    private String city;
    private String state;
    private String tapeReturnCharge;
    private String countryCode;
    private String activeLinePercent;
    private String status;
    private String ldProvider;
    private String ldAccount;
    private String ldPicCode;
    private String ratePlan;
    private String dummyEsn;
    private String billDate;
    private String voiceMail;
    private String vmCode;
    private String vmPackage;
    private String callerId;
    private String idCode;
    private String idPackage;
    private String callWaiting;
    private String cwCode;
    private String cwPackage;
    private String reactTechnology;
    private String reactAnalog;
    private String actTechnology;
    private String actAnalog;
    private String digitalRatePlan;
    private String digitalFeature;
    private String prlPreLoaded;
    private String carrier2CarrierGroup;
    private String tapeReturnAddr2Address;
    private String carrier2Provider;
    private String carrier2Address;
    private String carrier2Personality;
    private String carrier2Rule;
    private String carrier2CarrScript;
    private String specialMkt;
    private String newAnalogPlan;
    private String newDigitalPlan;
    private String sms;
    private String smsCode;
    private String smsPackage;
    private String vmSetUpLandLine;
    private String carrier2RulesCdma;
    private String carrier2RulesGsm;
    private String carrier2RulesTdma;
    private String dataService;
    private String automated;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(String carrierId) {
        this.carrierId = carrierId;
    }

    public String getSubmarketName() {
        return submarketName;
    }

    public void setSubmarketName(String submarketName) {
        this.submarketName = submarketName;
    }

    public String getSubmarketOf() {
        return submarketOf;
    }

    public void setSubmarketOf(String submarketOf) {
        this.submarketOf = submarketOf;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getTapeReturnCharge() {
        return tapeReturnCharge;
    }

    public void setTapeReturnCharge(String tapeReturnCharge) {
        this.tapeReturnCharge = tapeReturnCharge;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getActiveLinePercent() {
        return activeLinePercent;
    }

    public void setActiveLinePercent(String activeLinePercent) {
        this.activeLinePercent = activeLinePercent;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLdProvider() {
        return ldProvider;
    }

    public void setLdProvider(String ldProvider) {
        this.ldProvider = ldProvider;
    }

    public String getLdAccount() {
        return ldAccount;
    }

    public void setLdAccount(String ldAccount) {
        this.ldAccount = ldAccount;
    }

    public String getLdPicCode() {
        return ldPicCode;
    }

    public void setLdPicCode(String ldPicCode) {
        this.ldPicCode = ldPicCode;
    }

    public String getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(String ratePlan) {
        this.ratePlan = ratePlan;
    }

    public String getDummyEsn() {
        return dummyEsn;
    }

    public void setDummyEsn(String dummyEsn) {
        this.dummyEsn = dummyEsn;
    }

    public String getBillDate() {
        return billDate;
    }

    public void setBillDate(String billDate) {
        this.billDate = billDate;
    }

    public String getVoiceMail() {
        return voiceMail;
    }

    public void setVoiceMail(String voiceMail) {
        this.voiceMail = voiceMail;
    }

    public String getVmCode() {
        return vmCode;
    }

    public void setVmCode(String vmCode) {
        this.vmCode = vmCode;
    }

    public String getVmPackage() {
        return vmPackage;
    }

    public void setVmPackage(String vmPackage) {
        this.vmPackage = vmPackage;
    }

    public String getCallerId() {
        return callerId;
    }

    public void setCallerId(String callerId) {
        this.callerId = callerId;
    }

    public String getIdCode() {
        return idCode;
    }

    public void setIdCode(String idCode) {
        this.idCode = idCode;
    }

    public String getIdPackage() {
        return idPackage;
    }

    public void setIdPackage(String idPackage) {
        this.idPackage = idPackage;
    }

    public String getCallWaiting() {
        return callWaiting;
    }

    public void setCallWaiting(String callWaiting) {
        this.callWaiting = callWaiting;
    }

    public String getCwCode() {
        return cwCode;
    }

    public void setCwCode(String cwCode) {
        this.cwCode = cwCode;
    }

    public String getCwPackage() {
        return cwPackage;
    }

    public void setCwPackage(String cwPackage) {
        this.cwPackage = cwPackage;
    }

    public String getReactTechnology() {
        return reactTechnology;
    }

    public void setReactTechnology(String reactTechnology) {
        this.reactTechnology = reactTechnology;
    }

    public String getReactAnalog() {
        return reactAnalog;
    }

    public void setReactAnalog(String reactAnalog) {
        this.reactAnalog = reactAnalog;
    }

    public String getActTechnology() {
        return actTechnology;
    }

    public void setActTechnology(String actTechnology) {
        this.actTechnology = actTechnology;
    }

    public String getActAnalog() {
        return actAnalog;
    }

    public void setActAnalog(String actAnalog) {
        this.actAnalog = actAnalog;
    }

    public String getDigitalRatePlan() {
        return digitalRatePlan;
    }

    public void setDigitalRatePlan(String digitalRatePlan) {
        this.digitalRatePlan = digitalRatePlan;
    }

    public String getDigitalFeature() {
        return digitalFeature;
    }

    public void setDigitalFeature(String digitalFeature) {
        this.digitalFeature = digitalFeature;
    }

    public String getPrlPreLoaded() {
        return prlPreLoaded;
    }

    public void setPrlPreLoaded(String prlPreLoaded) {
        this.prlPreLoaded = prlPreLoaded;
    }

    public String getCarrier2CarrierGroup() {
        return carrier2CarrierGroup;
    }

    public void setCarrier2CarrierGroup(String carrier2CarrierGroup) {
        this.carrier2CarrierGroup = carrier2CarrierGroup;
    }

    public String getTapeReturnAddr2Address() {
        return tapeReturnAddr2Address;
    }

    public void setTapeReturnAddr2Address(String tapeReturnAddr2Address) {
        this.tapeReturnAddr2Address = tapeReturnAddr2Address;
    }

    public String getCarrier2Provider() {
        return carrier2Provider;
    }

    public void setCarrier2Provider(String carrier2Provider) {
        this.carrier2Provider = carrier2Provider;
    }

    public String getCarrier2Address() {
        return carrier2Address;
    }

    public void setCarrier2Address(String carrier2Address) {
        this.carrier2Address = carrier2Address;
    }

    public String getCarrier2Personality() {
        return carrier2Personality;
    }

    public void setCarrier2Personality(String carrier2Personality) {
        this.carrier2Personality = carrier2Personality;
    }

    public String getCarrier2Rule() {
        return carrier2Rule;
    }

    public void setCarrier2Rule(String carrier2Rule) {
        this.carrier2Rule = carrier2Rule;
    }

    public String getCarrier2CarrScript() {
        return carrier2CarrScript;
    }

    public void setCarrier2CarrScript(String carrier2CarrScript) {
        this.carrier2CarrScript = carrier2CarrScript;
    }

    public String getSpecialMkt() {
        return specialMkt;
    }

    public void setSpecialMkt(String specialMkt) {
        this.specialMkt = specialMkt;
    }

    public String getNewAnalogPlan() {
        return newAnalogPlan;
    }

    public void setNewAnalogPlan(String newAnalogPlan) {
        this.newAnalogPlan = newAnalogPlan;
    }

    public String getNewDigitalPlan() {
        return newDigitalPlan;
    }

    public void setNewDigitalPlan(String newDigitalPlan) {
        this.newDigitalPlan = newDigitalPlan;
    }

    public String getSms() {
        return sms;
    }

    public void setSms(String sms) {
        this.sms = sms;
    }

    public String getSmsCode() {
        return smsCode;
    }

    public void setSmsCode(String smsCode) {
        this.smsCode = smsCode;
    }

    public String getSmsPackage() {
        return smsPackage;
    }

    public void setSmsPackage(String smsPackage) {
        this.smsPackage = smsPackage;
    }

    public String getVmSetUpLandLine() {
        return vmSetUpLandLine;
    }

    public void setVmSetUpLandLine(String vmSetUpLandLine) {
        this.vmSetUpLandLine = vmSetUpLandLine;
    }

    public String getCarrier2RulesCdma() {
        return carrier2RulesCdma;
    }

    public void setCarrier2RulesCdma(String carrier2RulesCdma) {
        this.carrier2RulesCdma = carrier2RulesCdma;
    }

    public String getCarrier2RulesGsm() {
        return carrier2RulesGsm;
    }

    public void setCarrier2RulesGsm(String carrier2RulesGsm) {
        this.carrier2RulesGsm = carrier2RulesGsm;
    }

    public String getCarrier2RulesTdma() {
        return carrier2RulesTdma;
    }

    public void setCarrier2RulesTdma(String carrier2RulesTdma) {
        this.carrier2RulesTdma = carrier2RulesTdma;
    }

    public String getDataService() {
        return dataService;
    }

    public void setDataService(String dataService) {
        this.dataService = dataService;
    }

    public String getAutomated() {
        return automated;
    }

    public void setAutomated(String automated) {
        this.automated = automated;
    }

    @Override
    public String toString() {
        return "TFOneCarrier{" +
                "objId='" + objId + '\'' +
                ", carrierId='" + carrierId + '\'' +
                ", submarketName='" + submarketName + '\'' +
                ", submarketOf='" + submarketOf + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", tapereturnCharge='" + tapeReturnCharge + '\'' +
                ", countryCode='" + countryCode + '\'' +
                ", activelinePercent='" + activeLinePercent + '\'' +
                ", status='" + status + '\'' +
                ", ldProvider='" + ldProvider + '\'' +
                ", ldAccount='" + ldAccount + '\'' +
                ", ldPicCode='" + ldPicCode + '\'' +
                ", ratePlan='" + ratePlan + '\'' +
                ", dummyEsn='" + dummyEsn + '\'' +
                ", billDate='" + billDate + '\'' +
                ", voiceMail='" + voiceMail + '\'' +
                ", vmCode='" + vmCode + '\'' +
                ", vmPackage='" + vmPackage + '\'' +
                ", callerId='" + callerId + '\'' +
                ", idCode='" + idCode + '\'' +
                ", idPackage='" + idPackage + '\'' +
                ", callWaiting='" + callWaiting + '\'' +
                ", cwCode='" + cwCode + '\'' +
                ", cwPackage='" + cwPackage + '\'' +
                ", reactTechnology='" + reactTechnology + '\'' +
                ", reactAnalog='" + reactAnalog + '\'' +
                ", actTechnology='" + actTechnology + '\'' +
                ", actAnalog='" + actAnalog + '\'' +
                ", digitalRatePlan='" + digitalRatePlan + '\'' +
                ", digitalFeature='" + digitalFeature + '\'' +
                ", prlPreLoaded='" + prlPreLoaded + '\'' +
                ", carrier2CarrierGroup='" + carrier2CarrierGroup + '\'' +
                ", tapereturnAddr2Address='" + tapeReturnAddr2Address + '\'' +
                ", carrier2Provider='" + carrier2Provider + '\'' +
                ", carrier2Address='" + carrier2Address + '\'' +
                ", carrier2Personality='" + carrier2Personality + '\'' +
                ", carrier2Rule='" + carrier2Rule + '\'' +
                ", carrier2CarrScript='" + carrier2CarrScript + '\'' +
                ", specialMkt='" + specialMkt + '\'' +
                ", newAnalogPlan='" + newAnalogPlan + '\'' +
                ", newDigitalPlan='" + newDigitalPlan + '\'' +
                ", sms='" + sms + '\'' +
                ", smsCode='" + smsCode + '\'' +
                ", smsPackage='" + smsPackage + '\'' +
                ", vmSetUpLandLine='" + vmSetUpLandLine + '\'' +
                ", carrier2RulesCdma='" + carrier2RulesCdma + '\'' +
                ", carrier2RulesGsm='" + carrier2RulesGsm + '\'' +
                ", carrier2RulesTdma='" + carrier2RulesTdma + '\'' +
                ", dataService='" + dataService + '\'' +
                ", automated='" + automated + '\'' +
                '}';
    }
}