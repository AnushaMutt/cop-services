/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.response;

/**
 *
 * @author Shireen Fathima
 */
public class TFOneAncillaryCode {
    
    private String ancillaryCode;
    private String description;

    public String getAncillaryCode() {
        return ancillaryCode;
    }

    public void setAncillaryCode(String ancillaryCode) {
        this.ancillaryCode = ancillaryCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "TFOneAncillaryCode{" + "ancillaryCode=" + ancillaryCode + ", "
                + "description=" + description + '}';
    }  
    
    
}
