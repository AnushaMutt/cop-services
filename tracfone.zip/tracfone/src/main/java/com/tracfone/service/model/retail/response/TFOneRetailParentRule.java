package com.tracfone.service.model.retail.response;

public class TFOneRetailParentRule {
    private String objId;
    private String rule2Parent;
    private String rule2cPrefGrpTrait;
    private String rule2cPrefGrpRank;
    private String rule2TraitRule;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getRule2Parent() {
        return rule2Parent;
    }

    public void setRule2Parent(String rule2Parent) {
        this.rule2Parent = rule2Parent;
    }

    public String getRule2cPrefGrpTrait() {
        return rule2cPrefGrpTrait;
    }

    public void setRule2cPrefGrpTrait(String rule2cPrefGrpTrait) {
        this.rule2cPrefGrpTrait = rule2cPrefGrpTrait;
    }

    public String getRule2cPrefGrpRank() {
        return rule2cPrefGrpRank;
    }

    public void setRule2cPrefGrpRank(String rule2cPrefGrpRank) {
        this.rule2cPrefGrpRank = rule2cPrefGrpRank;
    }

    public String getRule2TraitRule() {
        return rule2TraitRule;
    }

    public void setRule2TraitRule(String rule2TraitRule) {
        this.rule2TraitRule = rule2TraitRule;
    }

    @Override
    public String toString() {
        return "TFOneRetailParentRule{" +
                "objId='" + objId + '\'' +
                ", rule2Parent='" + rule2Parent + '\'' +
                ", rule2cPrefGrpTrait='" + rule2cPrefGrpTrait + '\'' +
                ", rule2cPrefGrpRank='" + rule2cPrefGrpRank + '\'' +
                ", rule2TraitRule='" + rule2TraitRule + '\'' +
                '}';
    }
}
