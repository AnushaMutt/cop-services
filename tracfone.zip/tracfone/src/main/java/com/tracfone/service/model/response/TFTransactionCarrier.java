/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

import java.util.List;

/**
 *
 * @author Srinivas Murthy Pulavarthy
 */
public class TFTransactionCarrier {
    
    private String shortName;
    private String tfOnecarrier;
    private List<String> orderTypes;

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getTfOnecarrier() {
        return tfOnecarrier;
    }

    public void setTfOnecarrier(String tfOnecarrier) {
        this.tfOnecarrier = tfOnecarrier;
    }

    public List<String> getOrderTypes() {
        return orderTypes;
    }

    public void setOrderTypes(List<String> orderTypes) {
        this.orderTypes = orderTypes;
    }

    @Override
    public String toString() {
        return "TFTransactionCarrier{" +
                "shortName='" + shortName + '\'' +
                ", tfOnecarrier='" + tfOnecarrier + '\'' +
                ", orderTypes=" + orderTypes +
                '}';
    }
}
