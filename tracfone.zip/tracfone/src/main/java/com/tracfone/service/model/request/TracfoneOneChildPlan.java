/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Shireen Fathima
 */
public class TracfoneOneChildPlan {
    
    private String dbEnv;
    @NotNull(message = "Child Plan Id cannot be null")
    @Size(min=1, message = "Child Plan Id cannot be blank")
    @Size(max=5, message = "Child Plan Id cannot have more than 5 characters")
    private String childPlanId;
    @NotNull(message = "Child Description cannot be null")
    @Size(min=1, message = "Child Description cannot be blank")
    @Size(max=150, message = "Child Description cannot have more than 150 characters")
    private String childDescription;    

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getChildPlanId() {
        return childPlanId;
    }

    public void setChildPlanId(String childPlanId) {
        this.childPlanId = childPlanId;
    }

    public String getChildDescription() {
        return childDescription;
    }

    public void setChildDescription(String childDescription) {
        this.childDescription = childDescription;
    }

    @Override
    public String toString() {
        return "TracfoneOneChildIdentifierList{" + "dbEnv=" + dbEnv + ", childPlanId=" + childPlanId + ", childDescription=" + childDescription + '}';
    }
    
}
