package com.tracfone.service.model.response;

public class TFOneCarrierRule {
    private String objId;
    private String coolingPeriod;
    private String esnChangeDays;
    private String lineExpireDays;
    private String lineReturnDays;
    private String coolingAfterInsert;
    private String npaNxxFlag;
    private String usedLineExpireDays;
    private String gsmGracePeriod;
    private String technology;
    private String reserveOnSuspend;
    private String reservePeriod;
    private String deacAfterGrace;
    private String cancelSuspendDays;
    private String cancelSuspend;
    private String blockCreateActItem;
    private String allow2gAct;
    private String allow2gReact;
    private String allowNonHdActs;
    private String allowNonHdReacts;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getCoolingPeriod() {
        return coolingPeriod;
    }

    public void setCoolingPeriod(String coolingPeriod) {
        this.coolingPeriod = coolingPeriod;
    }

    public String getEsnChangeDays() {
        return esnChangeDays;
    }

    public void setEsnChangeDays(String esnChangeDays) {
        this.esnChangeDays = esnChangeDays;
    }

    public String getLineExpireDays() {
        return lineExpireDays;
    }

    public void setLineExpireDays(String lineExpireDays) {
        this.lineExpireDays = lineExpireDays;
    }

    public String getLineReturnDays() {
        return lineReturnDays;
    }

    public void setLineReturnDays(String lineReturnDays) {
        this.lineReturnDays = lineReturnDays;
    }

    public String getCoolingAfterInsert() {
        return coolingAfterInsert;
    }

    public void setCoolingAfterInsert(String coolingAfterInsert) {
        this.coolingAfterInsert = coolingAfterInsert;
    }

    public String getNpaNxxFlag() {
        return npaNxxFlag;
    }

    public void setNpaNxxFlag(String npaNxxFlag) {
        this.npaNxxFlag = npaNxxFlag;
    }

    public String getUsedLineExpireDays() {
        return usedLineExpireDays;
    }

    public void setUsedLineExpireDays(String usedLineExpireDays) {
        this.usedLineExpireDays = usedLineExpireDays;
    }

    public String getGsmGracePeriod() {
        return gsmGracePeriod;
    }

    public void setGsmGracePeriod(String gsmGracePeriod) {
        this.gsmGracePeriod = gsmGracePeriod;
    }

    public String getTechnology() {
        return technology;
    }

    public void setTechnology(String technology) {
        this.technology = technology;
    }

    public String getReserveOnSuspend() {
        return reserveOnSuspend;
    }

    public void setReserveOnSuspend(String reserveOnSuspend) {
        this.reserveOnSuspend = reserveOnSuspend;
    }

    public String getReservePeriod() {
        return reservePeriod;
    }

    public void setReservePeriod(String reservePeriod) {
        this.reservePeriod = reservePeriod;
    }

    public String getDeacAfterGrace() {
        return deacAfterGrace;
    }

    public void setDeacAfterGrace(String deacAfterGrace) {
        this.deacAfterGrace = deacAfterGrace;
    }

    public String getCancelSuspendDays() {
        return cancelSuspendDays;
    }

    public void setCancelSuspendDays(String cancelSuspendDays) {
        this.cancelSuspendDays = cancelSuspendDays;
    }

    public String getCancelSuspend() {
        return cancelSuspend;
    }

    public void setCancelSuspend(String cancelSuspend) {
        this.cancelSuspend = cancelSuspend;
    }

    public String getBlockCreateActItem() {
        return blockCreateActItem;
    }

    public void setBlockCreateActItem(String blockCreateActItem) {
        this.blockCreateActItem = blockCreateActItem;
    }

    public String getAllow2gAct() {
        return allow2gAct;
    }

    public void setAllow2gAct(String allow2gAct) {
        this.allow2gAct = allow2gAct;
    }

    public String getAllow2gReact() {
        return allow2gReact;
    }

    public void setAllow2gReact(String allow2gReact) {
        this.allow2gReact = allow2gReact;
    }

    public String getAllowNonHdActs() {
        return allowNonHdActs;
    }

    public void setAllowNonHdActs(String allowNonHdActs) {
        this.allowNonHdActs = allowNonHdActs;
    }

    public String getAllowNonHdReacts() {
        return allowNonHdReacts;
    }

    public void setAllowNonHdReacts(String allowNonHdReacts) {
        this.allowNonHdReacts = allowNonHdReacts;
    }

    @Override
    public String toString() {
        return "TFOneCarrierRule{" +
                "objId='" + objId + '\'' +
                ", coolingPeriod='" + coolingPeriod + '\'' +
                ", esnChangeDays='" + esnChangeDays + '\'' +
                ", lineExpireDays='" + lineExpireDays + '\'' +
                ", lineReturnDays='" + lineReturnDays + '\'' +
                ", coolingAfterInsert='" + coolingAfterInsert + '\'' +
                ", npaNxxFlag='" + npaNxxFlag + '\'' +
                ", usedLineExpireDays='" + usedLineExpireDays + '\'' +
                ", gsmGracePeriod='" + gsmGracePeriod + '\'' +
                ", technology='" + technology + '\'' +
                ", reserveOnSuspend='" + reserveOnSuspend + '\'' +
                ", reservePeriod='" + reservePeriod + '\'' +
                ", deacAfterGrace='" + deacAfterGrace + '\'' +
                ", cancelSuspendDays='" + cancelSuspendDays + '\'' +
                ", cancelSuspend='" + cancelSuspend + '\'' +
                ", blockCreateActItem='" + blockCreateActItem + '\'' +
                ", allow2gAct='" + allow2gAct + '\'' +
                ", allow2gReact='" + allow2gReact + '\'' +
                ", allowNonHdActs='" + allowNonHdActs + '\'' +
                ", allowNonHdReacts='" + allowNonHdReacts + '\'' +
                '}';
    }
}
