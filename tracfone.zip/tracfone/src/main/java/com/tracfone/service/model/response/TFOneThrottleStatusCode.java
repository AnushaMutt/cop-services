package com.tracfone.service.model.response;

public class TFOneThrottleStatusCode {
    private String throttleStatusCode;
    private String description;

    public String getThrottleStatusCode() {
        return throttleStatusCode;
    }

    public void setThrottleStatusCode(String throttleStatusCode) {
        this.throttleStatusCode = throttleStatusCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "TFOneThrottleStatusCode{" +
                "throttleStatusCode='" + throttleStatusCode + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
