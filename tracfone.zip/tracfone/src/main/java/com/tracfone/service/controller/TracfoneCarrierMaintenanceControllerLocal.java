package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneArUsaMarket;
import com.tracfone.service.model.request.TracfoneOneArUsaPostalZips;
import com.tracfone.service.model.request.TracfoneOneCarrier;
import com.tracfone.service.model.request.TracfoneOneCarrierGroup;
import com.tracfone.service.model.request.TracfoneOneCarrierPref;
import com.tracfone.service.model.request.TracfoneOneCarrierRule;
import com.tracfone.service.model.request.TracfoneOneCarrierSimPref;
import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;
import com.tracfone.service.model.request.TracfoneOneDataConfig;
import com.tracfone.service.model.request.TracfoneOneDataConfigMapping;
import com.tracfone.service.model.request.TracfoneOneGeoLoc;
import com.tracfone.service.model.request.TracfoneOneIgOrderType;
import com.tracfone.service.model.request.TracfoneOneNotCertifyModel;
import com.tracfone.service.model.request.TracfoneOneNpanxx2Carrierzones;
import com.tracfone.service.model.request.TracfoneOneOrderType;
import com.tracfone.service.model.request.TracfoneOneParent;
import com.tracfone.service.model.request.TracfoneOneThrottleFeature;
import com.tracfone.service.model.request.TracfoneOneThrottlePolicy;
import com.tracfone.service.model.request.TracfoneOneThrottleRule;
import com.tracfone.service.model.request.TracfoneOneTmoZipNgp;
import com.tracfone.service.model.request.TracfoneOneVerizonZipNPANXX;
import com.tracfone.service.model.response.TFOneArUsaMarketSearchResult;
import com.tracfone.service.model.response.TFOneArUsaPostalZips;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierGroup;
import com.tracfone.service.model.response.TFOneCarrierPref;
import com.tracfone.service.model.response.TFOneCarrierRule;
import com.tracfone.service.model.response.TFOneCarrierZones;
import com.tracfone.service.model.response.TFOneCarriersimpref;
import com.tracfone.service.model.response.TFOneCingularMrktInfo;
import com.tracfone.service.model.response.TFOneDataConfig;
import com.tracfone.service.model.response.TFOneDataConfigMapping;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneGeoLoc;
import com.tracfone.service.model.response.TFOneIgOrderType;
import com.tracfone.service.model.response.TFOneNotCertifyModel;
import com.tracfone.service.model.response.TFOneNpaNxx2CarrierZonesSearchResult;
import com.tracfone.service.model.response.TFOneOrderType;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOnePartClass;
import com.tracfone.service.model.response.TFOneThrottleFeature;
import com.tracfone.service.model.response.TFOneThrottlePolicy;
import com.tracfone.service.model.response.TFOneThrottleRule;
import com.tracfone.service.model.response.TFOneTmoZipNgp;
import com.tracfone.service.model.response.TFOneVerizonZipNPANXX;

import javax.ejb.Local;
import java.util.List;

/**
 * @author Pritesh Singh
 */
@Local
public interface TracfoneCarrierMaintenanceControllerLocal {
    List<TFOneCarrierGroup> searchCarrierGroups(TracfoneOneCarrierGroup tracfoneOneCarrierGroup) throws TracfoneOneException;

    List<TFOneOrderType> searchOrderTypes(TracfoneOneOrderType tracfoneOneOrderType) throws TracfoneOneException;

    List<TFOneParent> searchParent(TracfoneOneParent tracfoneOneParent) throws TracfoneOneException;

    List<TFOneCarrier> searchCarrier(TracfoneOneCarrier tracfoneOneCarrier) throws TracfoneOneException;

    List<TFOneDataConfigMapping> searchDataConfigMapping(TracfoneOneDataConfigMapping tfDataConfigMapping) throws TracfoneOneException;

    TFOneGeneralResponse insertDataConfigMapping(TracfoneOneDataConfigMapping tfDataConfigMapping, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteDataConfigMapping(TracfoneOneDataConfigMapping tfDataConfigMapping, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateDataConfigMapping(TracfoneOneDataConfigMapping tfDataConfigMapping, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateParent(TracfoneOneParent tracfoneOneParent, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrierGroup(TracfoneOneCarrierGroup tracfoneOneCarrierGroup, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrier(TracfoneOneCarrier tracfoneOneCarrier, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrierRule(TracfoneOneCarrierRule tracfoneOneCarrierRule, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateOrderType(TracfoneOneOrderType tracfoneOneOrderType, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertParent(TracfoneOneParent tracfoneOneParent, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertCarrierGroups(List<TracfoneOneCarrierGroup> tracfoneOneCarrierGroups, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertCarriers(List<TracfoneOneCarrier> tracfoneOneCarriers, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertCarrierRule(TracfoneOneCarrierRule tracfoneOneCarrierRule, int userId) throws TracfoneOneException;

    List<TFOneOrderType> insertOrderType(List<TracfoneOneOrderType> tracfoneOneOrderTypes, int userId) throws TracfoneOneException;

    List<TFOneCarrierRule> searchCarrierRules(TracfoneOneCarrierRule tracfoneOneCarrierRule) throws TracfoneOneException;

    List<TFOneDataConfig> searchDataConfigs(TracfoneOneDataConfig tracfoneOneDataConfig) throws TracfoneOneException;

    List<TFOnePartClass> getAllPartClasses(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse deleteOrderType(TracfoneOneOrderType tracfoneOneOrderType, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertIgOrderTypes(TracfoneOneIgOrderType tracfoneOneIgOrderType, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateIgOrderTypes(TracfoneOneIgOrderType tracfoneOneIgOrderType, int userId) throws TracfoneOneException;

    List<TFOneIgOrderType> searchIgOrderTypes(TracfoneOneIgOrderType tracfoneOneIgOrderType, boolean searchAll) throws TracfoneOneException;

    TFOneGeneralResponse insertThrottlePolicy(TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertThrottleRules(List<TracfoneOneThrottleRule> tracfoneOneThrottleRules, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertThrottleFeatures(List<TracfoneOneThrottleFeature> tracfoneOneThrottleFeatures, int userId) throws TracfoneOneException;

    List<TFOneThrottlePolicy> searchThrottlePolicies(TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy) throws TracfoneOneException;

    List<TFOneThrottleRule> searchThrottleRules(TracfoneOneThrottleRule tracfoneOneThrottleRule) throws TracfoneOneException;

    List<TFOneThrottleFeature> searchThrottleFeatures(TracfoneOneThrottleFeature tracfoneOneThrottleFeature) throws TracfoneOneException;

    TFOneGeneralResponse updateThrottlePolicy(TracfoneOneThrottlePolicy tracfoneOneThrottlePolicy, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateThrottleRule(TracfoneOneThrottleRule tracfoneOneThrottleRule, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateThrottleFeature(TracfoneOneThrottleFeature tracfoneOneThrottleFeature, int userId) throws TracfoneOneException;

    List<TFOneVerizonZipNPANXX> searchVerizonZipNPANXX(TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX) throws TracfoneOneException;

    TFOneGeneralResponse updateVerizonZipNPANXX(TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertVerizonZipNPANXX(TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteVerizonZipNPANXX(TracfoneOneVerizonZipNPANXX tracfoneOneVerizonZipNPANXX, int userId) throws TracfoneOneException;

    void bulkInsertVerizonZipNPANXX(List<TracfoneOneVerizonZipNPANXX> tracfoneOneVerizonZipNPANXX, int userId) throws TracfoneOneException;

    List<TFOneTmoZipNgp> searchTmoZipNgp(TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp) throws TracfoneOneException;

    TFOneGeneralResponse insertTmoZipNgp(TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateTmoZipNgp(TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteTmoZipNgp(TracfoneOneTmoZipNgp tracfoneOneTmoZipNgp, int userId) throws TracfoneOneException;

    void bulkInsertTmoZipNgp(List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNgp, int userId) throws TracfoneOneException;

    List<TFOneCingularMrktInfo> searchCingularMrktInfo(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo) throws TracfoneOneException;

    TFOneGeneralResponse insertCingularMrktInfo(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateCingularMrktInfo(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteCingularMrktInfo(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo, int userId) throws TracfoneOneException;

    void bulkInsertCingularMrktInfo(List<TracfoneOneCingularMrktInfo> tracfoneOneCingularMrktInfo, int userId) throws TracfoneOneException;

    List<TFOneNotCertifyModel> searchNotCertifyModel(TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel) throws TracfoneOneException;

    TFOneGeneralResponse insertNotCertifyModel(TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateNotCertifyModel(TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteNotCertifyModel(TracfoneOneNotCertifyModel tracfoneOneNotCertifyModel, int userId) throws TracfoneOneException;

    void bulkInsertNotCertifyModel(List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModel, int userId) throws TracfoneOneException;

    TFOneGeneralResponse bulkUpdateNotCertifyModel(List<TracfoneOneNotCertifyModel> tracfoneOneNotCertifyModels, int userId) throws TracfoneOneException;

    public TFOneGeneralResponse bulkUpdateTmoZipNgp(List<TracfoneOneTmoZipNgp> tracfoneOneTmoZipNgp, int userId) throws TracfoneOneException;

    List<TFOneCarriersimpref> searchCarrierSimPref(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref) throws TracfoneOneException;

    TFOneGeneralResponse insertCarrierSimPref(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrierSimPref(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteCarrierSimPref(TracfoneOneCarrierSimPref tracfoneOneCarriersimpref, int userId) throws TracfoneOneException;

    void bulkInsertCarrierSimPref(List<TracfoneOneCarrierSimPref> tracfoneOneCarriersimpref, int userId) throws TracfoneOneException;

    TFOneGeneralResponse bulkUpdateCarrierSimPref(List<TracfoneOneCarrierSimPref> tracfoneOneCarrierSimPrefs, int userId) throws TracfoneOneException;

    TFOneGeneralResponse insertNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones, int userId) throws TracfoneOneException;

    TFOneNpaNxx2CarrierZonesSearchResult searchNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones) throws TracfoneOneException;

    TFOneGeneralResponse deleteNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateNpanxx2Carrierzones(TracfoneOneNpanxx2Carrierzones tracfoneOneNpanxx2Carrierzones, int userId) throws TracfoneOneException;

    void bulkInsertNpanxx2Carrierzones(List<TracfoneOneNpanxx2Carrierzones> tracfoneOneNpanxx2Carrierzones, int userId, String description) throws TracfoneOneException;

    TFOneGeneralResponse bulkUpdateNpanxx2Carrierzones(List<TracfoneOneNpanxx2Carrierzones> tracfoneOneNpanxx2Carrierzones, int userId) throws TracfoneOneException;

    List<TFOneArUsaPostalZips> getArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips) throws TracfoneOneException;

    TFOneGeneralResponse insertArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateArUsaPostalZips(TracfoneOneArUsaPostalZips tracfoneOneArUsaPostalZips, int userId) throws TracfoneOneException;

    TFOneGeneralResponse bulkUpdateArUsaPostalZips(List<TracfoneOneArUsaPostalZips> tracfoneOneArUsaPostalZips, int userId) throws TracfoneOneException;

    TFOneArUsaMarketSearchResult getArUsaMarketDetails(TracfoneOneArUsaMarket tracfoneOneArUsaMarket) throws TracfoneOneException;

    TFOneGeneralResponse insertArUsaMarketDetails(TracfoneOneArUsaMarket tracfoneOneArUsaMarket, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteArUsaMarketDetails(TracfoneOneArUsaMarket tracfoneOneArUsaMarket, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateArUsaMarketDetails(TracfoneOneArUsaMarket tracfoneOneArUsaMarket, int userId) throws TracfoneOneException;

    TFOneGeneralResponse bulkUpdateArUsaMarketDetails(List<TracfoneOneArUsaMarket> tracfoneOneArUsaMarket, int userId) throws TracfoneOneException;

    void bulkInsertArUsaPostalZips(List<TracfoneOneArUsaPostalZips> tracfoneOneArUsaPostalZips, int userId, String description) throws TracfoneOneException;

    void bulkInsertArUsaMarket(List<TracfoneOneArUsaMarket> tracfoneOneArUsaMarket, int userId, String description) throws TracfoneOneException;

    TFOneGeneralResponse insertGeoLoc(TracfoneOneGeoLoc tfOneGeoLoc, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteGeoLoc(TracfoneOneGeoLoc tfOneGeoLoc, int userId) throws TracfoneOneException;

    void bulkInsertGeoLoc(List<TracfoneOneGeoLoc> tfGeoLocs, int userId, String description) throws TracfoneOneException;

    List<String> getUsers() throws TracfoneOneException;

    List<TFOneGeoLoc> searchGeoLoc(TracfoneOneGeoLoc tfOneGeoLoc) throws TracfoneOneException;

    TFOneGeneralResponse updateGeoLoc(TracfoneOneGeoLoc tfGeoLoc, int userId) throws TracfoneOneException;

    TFOneGeneralResponse bulkUpdateGeoLoc(List<TracfoneOneGeoLoc> geoLocs, int userId) throws TracfoneOneException;

    List<TFOneCarrierZones> searchCarrierzones(TracfoneOneCarrierZones tracfoneOneCarrierZones) throws TracfoneOneException;

    TFOneGeneralResponse insertCarrierzones(TracfoneOneCarrierZones tracfoneOneCarrierZones, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteCarrierzones(TracfoneOneCarrierZones tracfoneOneCarrierZones, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrierzones(TracfoneOneCarrierZones tracfoneOneCarrierZones, int userId) throws TracfoneOneException;

    void bulkInsertCarrierzones(List<TracfoneOneCarrierZones> tracfoneOneCarrierZones, int userId) throws TracfoneOneException;

    TFOneGeneralResponse bulkUpdateCarrierZones(List<TracfoneOneCarrierZones> tracfoneOneCarrierZones, int userId) throws TracfoneOneException;

    void bulkDeleteCarrierZones(List<TracfoneOneCarrierZones> tracfoneOneCarrierZones, int userId) throws TracfoneOneException;

    void bulkDeleteArUsaPostalZips(List<TracfoneOneArUsaPostalZips> tracfoneOneArUsaPostalZips, int userId) throws TracfoneOneException;

    void bulkDeleteArUsaMarket(List<TracfoneOneArUsaMarket> tracfoneOneArUsaMarket, int userId) throws TracfoneOneException;

    void bulkDeleteNpanxx2CarrierZones(List<TracfoneOneNpanxx2Carrierzones> tracfoneOneNpanxx2Carrierzones, int userId) throws TracfoneOneException;

    List<TFOneCarrierPref> searchCarrierpref(TracfoneOneCarrierPref tracfoneOneCarrierPref) throws TracfoneOneException;

    TFOneGeneralResponse insertCarrierpref(TracfoneOneCarrierPref tracfoneOneCarrierPref, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteCarrierpref(TracfoneOneCarrierPref tracfoneOneCarrierPref, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrierpref(TracfoneOneCarrierPref tracfoneOneCarrierPref, int userId) throws TracfoneOneException;

    void bulkInsertCarrierpref(List<TracfoneOneCarrierPref> tracfoneOneCarrierPref, int userId,String description) throws TracfoneOneException;

    TFOneGeneralResponse bulkUpdateCarrierpref(List<TracfoneOneCarrierPref> tracfoneOneCarrierPref, int userId) throws TracfoneOneException;

    void bulkDeleteCarrierpref(List<TracfoneOneCarrierPref> tracfoneOneCarrierPref, int userId) throws TracfoneOneException;



}

