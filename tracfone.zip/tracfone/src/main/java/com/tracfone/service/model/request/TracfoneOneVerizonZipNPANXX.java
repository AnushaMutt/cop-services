package com.tracfone.service.model.request;

import javax.validation.constraints.Size;

/**
 * @author Thejaswini
 */
public class TracfoneOneVerizonZipNPANXX {
    @Size(min = 1, message = "ZIP cannot be null")
    private String zip;
    @Size(max = 30, message = "NPA cannot have more than 30 characters")
    @Size(min = 1, message = "NPA cannot be null")
    private String nPA;
    @Size(max = 30, message = "NXX cannot have more than 30 characters")
    @Size(min = 1, message = "NXX cannot be null")
    private String nXX;
    @Size(max = 30, message = "NPANXX cannot have more than 30 characters")
    @Size(min = 1, message = "NPANXX cannot be null")
    private String nPANXX;
    @Size(max = 30, message = "AccountNum cannot have more than 30 characters")
    @Size(min = 1, message = "AccountNum cannot be null")
    private String accountNum;
    @Size(max = 30, message = "template cannot have more than 30 characters")
    @Size(min = 1, message = "template cannot be null")
    private String template;
    private String dbEnv;
    private String oldZip;
    private String oldNPANXX;
    private String oldAccountNum;
    private boolean checkDuplicate;

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getnPA() {
        return nPA;
    }

    public void setnPA(String nPA) {
        this.nPA = nPA;
    }

    public String getnXX() {
        return nXX;
    }

    public void setnXX(String nXX) {
        this.nXX = nXX;
    }

    public String getnPANXX() {
        return nPANXX;
    }

    public void setnPANXX(String nPANXX) {
        this.nPANXX = nPANXX;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getOldZip() {
        return oldZip;
    }

    public void setOldZip(String oldZip) {
        this.oldZip = oldZip;
    }

    public String getOldNPANXX() {
        return oldNPANXX;
    }

    public void setOldNPANXX(String oldNPANXX) {
        this.oldNPANXX = oldNPANXX;
    }

    public String getOldAccountNum() {
        return oldAccountNum;
    }

    public void setOldAccountNum(String oldAccountNum) {
        this.oldAccountNum = oldAccountNum;
    }

    public boolean isCheckDuplicate() {
        return checkDuplicate;
    }

    public void setCheckDuplicate(boolean checkDuplicate) {
        this.checkDuplicate = checkDuplicate;
    }

    @Override
    public String toString() {
        return "TracfoneOneVerizonZipNPANXX{" +
                "zip='" + zip + '\'' +
                ", nPA='" + nPA + '\'' +
                ", nXX='" + nXX + '\'' +
                ", nPANXX='" + nPANXX + '\'' +
                ", accountNum='" + accountNum + '\'' +
                ", template='" + template + '\'' +
                ", dbEnv='" + dbEnv + '\'' +
                ", oldZip='" + oldZip + '\'' +
                ", oldNPANXX='" + oldNPANXX + '\'' +
                ", oldAccountNum='" + oldAccountNum + '\'' +
                ", validate=" + checkDuplicate +
                '}';
    }
}
