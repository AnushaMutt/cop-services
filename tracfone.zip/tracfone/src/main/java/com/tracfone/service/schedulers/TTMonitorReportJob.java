package com.tracfone.service.schedulers;

import com.google.gson.Gson;
import com.tracfone.service.model.event.TracfoneOneReportRequest;
import com.tracfone.service.model.report.TFOneReportTTMonitor;
import com.tracfone.service.report.workers.throttle.MonitorTTCarrierWorkerBean;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Singleton
public class TTMonitorReportJob {

    @EJB
    MonitorTTCarrierWorkerBean monitorTTCarrierWorkerBean;

    @Inject
    private Event<TracfoneOneReportRequest> tracfoneOneConstantReportEvent;

    private static final Logger LOGGER = LogManager.getLogger(TTMonitorReportJob.class);

//    @Schedule(second = "*/50", minute = "*", hour = "*", persistent = false)
    public void runTTMonitorReport() {
        try {
            List<TFOneReportTTMonitor> throttleTransReport = new ArrayList<>();
//                    List<TFOneReportTTMonitor> throttleTransReport = monitorTTCarrierWorkerBean.runMonitorReport();
            if (!throttleTransReport.isEmpty()) {
                Gson gson = new Gson();
                TracfoneOneReportRequest reportRequest = new TracfoneOneReportRequest();
                reportRequest.setJsonResponse(gson.toJson(throttleTransReport));
                reportRequest.setReportName(TracfoneOneConstantReport.TRACFONE_REPORTNAME_TT_MONITOR);
                tracfoneOneConstantReportEvent.fire(reportRequest);
            } else {
                LOGGER.info("MonitorTTCarrierWorkerBean returned an empty response.");
            }
        } catch (Exception ex) {
            LOGGER.error("Throttle Monitor report could not be retrieved because of an exception ", ex);
        }
    }

}
