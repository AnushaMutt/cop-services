package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneTTransactionNotes;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.util.TracfoneOneConstantThrottleTransNotes;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author Pritesh.Singh
 */
@Stateless
public class TracfoneOneTTransNotesController implements TracfoneOneTTransNotesControllerLocal, TracfoneOneConstantThrottleTransNotes {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneTTransNotesController.class);
    @EJB
    private TracfoneOneTTransNotesActionLocal tracfoneOneTTransNotesActionLocal;

    @Override
    public TFOneGeneralResponse insertThrottleTransNotes(TracfoneOneTTransactionNotes tfTTransactionNotes, String userName) throws TracfoneOneException {
        TFOneGeneralResponse tfOneGeneralResponse = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                try {
                    tracfoneOneTTransNotesActionLocal.insertThrottleTransNotes(tfTTransactionNotes, userName);
                } catch (TracfoneOneException ex) {
                    LOGGER.info(ex.getErrorMessage());
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_TT_NOTES_ERROR, TRACFONE_ADD_TT_NOTES_ERROR_MESSAGE, ex);
        }
        return tfOneGeneralResponse;
    }
}




