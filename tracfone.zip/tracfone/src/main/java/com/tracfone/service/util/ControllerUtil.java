/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.util;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author druiz
 */
public class ControllerUtil {

    public static Map<String, String> columnMap = new HashMap<String, String>();
    public static Map<String, String> carrierFeatureMap = new HashMap<String, String>();
    public static Map<String, String> igTransactionColumnNames = new HashMap<String, String>();

    private ControllerUtil() {
        throw new IllegalStateException("Utility class");
    }

    static {
        // IG Column names with Table parent.
        ControllerUtil.columnMap.put("callTransActionType", "IG.CALL_TRANS_ACTION_TYPE");
        ControllerUtil.columnMap.put("carrierId", "IG.CARRIER_ID");
        ControllerUtil.columnMap.put("min", "IG.MIN");
        ControllerUtil.columnMap.put("esnPartClassModel", "IG.ESN_PART_CLASS_MODEL");
        ControllerUtil.columnMap.put("esnHex", "IG.ESN_HEX");
        ControllerUtil.columnMap.put("oldEsn", "IG.OLD_ESN");
        ControllerUtil.columnMap.put("oldEsnHex", "IG.OLD_ESN_HEX");
        ControllerUtil.columnMap.put("pin", "IG.PIN");
        ControllerUtil.columnMap.put("phoneManf", "IG.PHONE_MANF");
        ControllerUtil.columnMap.put("endUser", "IG.END_USER");
        ControllerUtil.columnMap.put("accountNum", "IG.ACCOUNT_NUM");
        ControllerUtil.columnMap.put("marketCode", "IG.MARKET_CODE");
        ControllerUtil.columnMap.put("ratePlan", "IG.RATE_PLAN");
        ControllerUtil.columnMap.put("ldProvider", "IG.LD_PROVIDER");
        ControllerUtil.columnMap.put("sequenceNum", "IG.SEQUENCE_NUM");
        ControllerUtil.columnMap.put("dealerCode", "IG.DEALER_CODE");
        ControllerUtil.columnMap.put("transmissionMethod", "IG.TRANSMISSION_METHOD");
        ControllerUtil.columnMap.put("faxNum", "IG.FAX_NUM");
        ControllerUtil.columnMap.put("onlineNum", "IG.ONLINE_NUM");
        ControllerUtil.columnMap.put("email", "IG.EMAIL");
        ControllerUtil.columnMap.put("networkLogin", "IG.NETWORK_LOGIN");
        ControllerUtil.columnMap.put("networkPassword", "IG.NETWORK_PASSWORD");
        ControllerUtil.columnMap.put("systemLogin", "IG.SYSTEM_LOGIN");
        ControllerUtil.columnMap.put("systemPassword", "IG.SYSTEM_PASSWORD");
        ControllerUtil.columnMap.put("template", "IG.TEMPLATE");
        ControllerUtil.columnMap.put("exeName", "IG.EXE_NAME");
        ControllerUtil.columnMap.put("comPort", "IG.COM_PORT");
        ControllerUtil.columnMap.put("faxBatchSize", "IG.FAX_BATCH_SIZE");
        ControllerUtil.columnMap.put("faxBatchQtime", "IG.FAX_BATCH_Q_TIME");
        ControllerUtil.columnMap.put("expidite", "IG.EXPIDITE");
        ControllerUtil.columnMap.put("transProfKey", "IG.TRANS_PROF_KEY");
        ControllerUtil.columnMap.put("qTransaction", "IG.Q_TRANSACTION");
        ControllerUtil.columnMap.put("onlineNum2", "IG.ONLINE_NUM2");
        ControllerUtil.columnMap.put("faxNum2", "IG.FAX_NUM2");
        ControllerUtil.columnMap.put("igDbSecsToComp", "IG.IGDB_SECS_TO_COMP");
        ControllerUtil.columnMap.put("blackoutWait", "IG.BLACKOUT_WAIT");
        ControllerUtil.columnMap.put("tuxItiServer", "IG.TUX_ITI_SERVER");
        ControllerUtil.columnMap.put("technologyFlag", "IG.TECHNOLOGY_FLAG");
        ControllerUtil.columnMap.put("voiceMail", "IG.VOICE_MAIL");
        ControllerUtil.columnMap.put("voiceMailPackage", "IG.VOICE_MAIL_PACKAGE");
        ControllerUtil.columnMap.put("callerId", "IG.CALLER_ID");
        ControllerUtil.columnMap.put("callerIdPackage", "IG.CALLER_ID_PACKAGE");
        ControllerUtil.columnMap.put("callWaiting", "IG.CALL_WAITING");
        ControllerUtil.columnMap.put("callWaitingPackage", "IG.CALL_WAITING_PACKAGE");
        ControllerUtil.columnMap.put("rtpServer", "IG.RTP_SERVER");
        ControllerUtil.columnMap.put("digitalFeatureCode", "IG.DIGITAL_FEATURE_CODE");
        ControllerUtil.columnMap.put("stateField", "IG.STATE_FIELD");
        ControllerUtil.columnMap.put("zipCode", "IG.ZIP_CODE");
        ControllerUtil.columnMap.put("msid", "IG.MSID");
        ControllerUtil.columnMap.put("newMsidFlag", "IG.NEW_MSID_FLAG");
        ControllerUtil.columnMap.put("sms", "IG.SMS");
        ControllerUtil.columnMap.put("smsPackage", "IG.SMS_PACKAGE");
        ControllerUtil.columnMap.put("iccid", "IG.ICCID");
        ControllerUtil.columnMap.put("oldMin", "IG.OLD_MIN");
        ControllerUtil.columnMap.put("digitalFeature", "IG.DIGITAL_FEATURE");
        ControllerUtil.columnMap.put("otaType", "IG.OTA_TYPE");
        ControllerUtil.columnMap.put("rateCenterNo", "IG.RATE_CENTER_NO");
        ControllerUtil.columnMap.put("applicationSystem", "IG.APPLICATION_SYSTEM");
        ControllerUtil.columnMap.put("subscriberUpdate", "IG.SUBSCRIBER_UPDATE");
        ControllerUtil.columnMap.put("downloadDate", "IG.DOWNLOAD_DATE");
        ControllerUtil.columnMap.put("prlNumber", "IG.PRL_NUMBER");
        ControllerUtil.columnMap.put("amount", "IG.AMOUNT");
        ControllerUtil.columnMap.put("balance", "IG.BALANCE");
        ControllerUtil.columnMap.put("language", "IG.LANGUAGE");
        ControllerUtil.columnMap.put("expDate", "IG.EXP_DATE");
        ControllerUtil.columnMap.put("xMpn", "IG.X_MPN");
        ControllerUtil.columnMap.put("xMpnCode", "IG.X_MPN_CODE");
        ControllerUtil.columnMap.put("xPoolName", "IG.X_POOL_NAME");
        ControllerUtil.columnMap.put("imsi", "IG.IMSI");
        ControllerUtil.columnMap.put("newImsiFlag", "IG.NEW_IMSI_FLAG");
        ControllerUtil.columnMap.put("xMake", "IG.X_MAKE");
        ControllerUtil.columnMap.put("xModel", "IG.X_MODEL");
        ControllerUtil.columnMap.put("xMode", "IG.X_MODE");
        ControllerUtil.columnMap.put("carrierInitialTransTime", "IG.CARRIER_INITIAL_TRANS_TIME");
        ControllerUtil.columnMap.put("carrierEndTransTime", "IG.CARRIER_END_TRANS_TIME");
        ControllerUtil.columnMap.put("igCarrSecsToComp", "IG.IGCARR_SECS_TO_COMP");
        ControllerUtil.columnMap.put("cfExtensionCount", "IG.CF_EXTENSION_COUNT");
        ControllerUtil.columnMap.put("dataSaver", "IG.DATA_SAVER");
        ControllerUtil.columnMap.put("dataSaverCode", "IG.DATA_SAVER_CODE");
        ControllerUtil.columnMap.put("xCampaignName", "IG.X_CAMPAIGN_NAME");
        ControllerUtil.columnMap.put("carrierFeatureObjid", "IG.CARRIER_FEATURE_OBJID");
        ControllerUtil.columnMap.put("cfProfileId", "IG.CF_PROFILE_ID");
        ControllerUtil.columnMap.put("rpExtObjid", "IG.RP_EXT_OBJID");
        ControllerUtil.columnMap.put("firstName", "IGA.FIRST_NAME");
        ControllerUtil.columnMap.put("middleInitial", "IGA.MIDDLE_INITIAL");
        ControllerUtil.columnMap.put("lastName", "IGA.LAST_NAME");
        ControllerUtil.columnMap.put("suffix", "IGA.SUFFIX");
        ControllerUtil.columnMap.put("prefix", "IGA.PREFIX");
        ControllerUtil.columnMap.put("ssnLast4", "IGA.SSN_LAST_4");
        ControllerUtil.columnMap.put("address1", "IGA.ADDRESS_1");
        ControllerUtil.columnMap.put("address2", "IGA.ADDRESS_2");
        ControllerUtil.columnMap.put("city", "IGA.CITY");
        ControllerUtil.columnMap.put("state", "IGA.STATE");
        ControllerUtil.columnMap.put("zipCode1", "IGA.ZIP_CODE_ADDL");
        ControllerUtil.columnMap.put("country", "IGA.COUNTRY");
        ControllerUtil.columnMap.put("ospAccount", "IGA.OSP_ACCOUNT");
        ControllerUtil.columnMap.put("currAddrHouseNumber", "IGA.CURR_ADDR_HOUSE_NUMBER");
        ControllerUtil.columnMap.put("currAddrDirection", "IGA.CURR_ADDR_DIRECTION");
        ControllerUtil.columnMap.put("currAddrStreetName", "IGA.CURR_ADDR_STREET_NAME");
        ControllerUtil.columnMap.put("currAddrStreetType", "IGA.CURR_ADDR_STREET_TYPE");
        ControllerUtil.columnMap.put("currAddrUnit", "IGA.CURR_ADDR_UNIT");
        ControllerUtil.columnMap.put("tmoNextGenFlag", "IG.TMO_NEXT_GEN_FLAG");
        ControllerUtil.columnMap.put("carrierAccountId", "IG.CARRIER_ACCOUNT_ID");
        ControllerUtil.columnMap.put("servicePlanId", "IG.SERVICE_PLAN_ID");

        // IG Column names.
        ControllerUtil.igTransactionColumnNames.put("callTransActionType", "CALL_TRANS_ACTION_TYPE");
        ControllerUtil.igTransactionColumnNames.put("carrierId", "CARRIER_ID");
        ControllerUtil.igTransactionColumnNames.put("min", "MIN");
        ControllerUtil.igTransactionColumnNames.put("esnPartClassModel", "ESN_PART_CLASS_MODEL");
        ControllerUtil.igTransactionColumnNames.put("esnHex", "ESN_HEX");
        ControllerUtil.igTransactionColumnNames.put("oldEsn", "OLD_ESN");
        ControllerUtil.igTransactionColumnNames.put("oldEsnHex", "OLD_ESN_HEX");
        ControllerUtil.igTransactionColumnNames.put("pin", "PIN");
        ControllerUtil.igTransactionColumnNames.put("phoneManf", "PHONE_MANF");
        ControllerUtil.igTransactionColumnNames.put("endUser", "END_USER");
        ControllerUtil.igTransactionColumnNames.put("accountNum", "ACCOUNT_NUM");
        ControllerUtil.igTransactionColumnNames.put("marketCode", "MARKET_CODE");
        ControllerUtil.igTransactionColumnNames.put("ratePlan", "RATE_PLAN");
        ControllerUtil.igTransactionColumnNames.put("ldProvider", "LD_PROVIDER");
        ControllerUtil.igTransactionColumnNames.put("sequenceNum", "SEQUENCE_NUM");
        ControllerUtil.igTransactionColumnNames.put("dealerCode", "DEALER_CODE");
        ControllerUtil.igTransactionColumnNames.put("transmissionMethod", "TRANSMISSION_METHOD");
        ControllerUtil.igTransactionColumnNames.put("faxNum", "FAX_NUM");
        ControllerUtil.igTransactionColumnNames.put("onlineNum", "ONLINE_NUM");
        ControllerUtil.igTransactionColumnNames.put("email", "EMAIL");
        ControllerUtil.igTransactionColumnNames.put("networkLogin", "NETWORK_LOGIN");
        ControllerUtil.igTransactionColumnNames.put("networkPassword", "NETWORK_PASSWORD");
        ControllerUtil.igTransactionColumnNames.put("systemLogin", "SYSTEM_LOGIN");
        ControllerUtil.igTransactionColumnNames.put("systemPassword", "SYSTEM_PASSWORD");
        ControllerUtil.igTransactionColumnNames.put("template", "TEMPLATE");
        ControllerUtil.igTransactionColumnNames.put("exeName", "EXE_NAME");
        ControllerUtil.igTransactionColumnNames.put("comPort", "COM_PORT");
        ControllerUtil.igTransactionColumnNames.put("faxBatchSize", "FAX_BATCH_SIZE");
        ControllerUtil.igTransactionColumnNames.put("faxBatchQtime", "FAX_BATCH_Q_TIME");
        ControllerUtil.igTransactionColumnNames.put("expidite", "EXPIDITE");
        ControllerUtil.igTransactionColumnNames.put("transProfKey", "TRANS_PROF_KEY");
        ControllerUtil.igTransactionColumnNames.put("qTransaction", "Q_TRANSACTION");
        ControllerUtil.igTransactionColumnNames.put("onlineNum2", "ONLINE_NUM2");
        ControllerUtil.igTransactionColumnNames.put("faxNum2", "FAX_NUM2");
        ControllerUtil.igTransactionColumnNames.put("igDbSecsToComp", "IGDB_SECS_TO_COMP");
        ControllerUtil.igTransactionColumnNames.put("blackoutWait", "BLACKOUT_WAIT");
        ControllerUtil.igTransactionColumnNames.put("tuxItiServer", "TUX_ITI_SERVER");
        ControllerUtil.igTransactionColumnNames.put("technologyFlag", "TECHNOLOGY_FLAG");
        ControllerUtil.igTransactionColumnNames.put("voiceMail", "VOICE_MAIL");
        ControllerUtil.igTransactionColumnNames.put("voiceMailPackage", "VOICE_MAIL_PACKAGE");
        ControllerUtil.igTransactionColumnNames.put("callerId", "CALLER_ID");
        ControllerUtil.igTransactionColumnNames.put("callerIdPackage", "CALLER_ID_PACKAGE");
        ControllerUtil.igTransactionColumnNames.put("callWaiting", "CALL_WAITING");
        ControllerUtil.igTransactionColumnNames.put("callWaitingPackage", "CALL_WAITING_PACKAGE");
        ControllerUtil.igTransactionColumnNames.put("rtpServer", "RTP_SERVER");
        ControllerUtil.igTransactionColumnNames.put("digitalFeatureCode", "DIGITAL_FEATURE_CODE");
        ControllerUtil.igTransactionColumnNames.put("stateField", "STATE_FIELD");
        ControllerUtil.igTransactionColumnNames.put("zipCode", "ZIP_CODE");
        ControllerUtil.igTransactionColumnNames.put("msid", "MSID");
        ControllerUtil.igTransactionColumnNames.put("newMsidFlag", "NEW_MSID_FLAG");
        ControllerUtil.igTransactionColumnNames.put("sms", "SMS");
        ControllerUtil.igTransactionColumnNames.put("smsPackage", "SMS_PACKAGE");
        ControllerUtil.igTransactionColumnNames.put("iccid", "ICCID");
        ControllerUtil.igTransactionColumnNames.put("oldMin", "OLD_MIN");
        ControllerUtil.igTransactionColumnNames.put("digitalFeature", "DIGITAL_FEATURE");
        ControllerUtil.igTransactionColumnNames.put("otaType", "OTA_TYPE");
        ControllerUtil.igTransactionColumnNames.put("rateCenterNo", "RATE_CENTER_NO");
        ControllerUtil.igTransactionColumnNames.put("applicationSystem", "APPLICATION_SYSTEM");
        ControllerUtil.igTransactionColumnNames.put("subscriberUpdate", "SUBSCRIBER_UPDATE");
        ControllerUtil.igTransactionColumnNames.put("downloadDate", "DOWNLOAD_DATE");
        ControllerUtil.igTransactionColumnNames.put("prlNumber", "PRL_NUMBER");
        ControllerUtil.igTransactionColumnNames.put("amount", "AMOUNT");
        ControllerUtil.igTransactionColumnNames.put("balance", "BALANCE");
        ControllerUtil.igTransactionColumnNames.put("language", "LANGUAGE");
        ControllerUtil.igTransactionColumnNames.put("expDate", "EXP_DATE");
        ControllerUtil.igTransactionColumnNames.put("xMpn", "X_MPN");
        ControllerUtil.igTransactionColumnNames.put("xMpnCode", "X_MPN_CODE");
        ControllerUtil.igTransactionColumnNames.put("xPoolName", "X_POOL_NAME");
        ControllerUtil.igTransactionColumnNames.put("imsi", "IMSI");
        ControllerUtil.igTransactionColumnNames.put("newImsiFlag", "NEW_IMSI_FLAG");
        ControllerUtil.igTransactionColumnNames.put("xMake", "X_MAKE");
        ControllerUtil.igTransactionColumnNames.put("xModel", "X_MODEL");
        ControllerUtil.igTransactionColumnNames.put("xMode", "X_MODE");
        ControllerUtil.igTransactionColumnNames.put("carrierInitialTransTime", "CARRIER_INITIAL_TRANS_TIME");
        ControllerUtil.igTransactionColumnNames.put("carrierEndTransTime", "CARRIER_END_TRANS_TIME");
        ControllerUtil.igTransactionColumnNames.put("igCarrSecsToComp", "IGCARR_SECS_TO_COMP");
        ControllerUtil.igTransactionColumnNames.put("cfExtensionCount", "CF_EXTENSION_COUNT");
        ControllerUtil.igTransactionColumnNames.put("dataSaver", "DATA_SAVER");
        ControllerUtil.igTransactionColumnNames.put("dataSaverCode", "DATA_SAVER_CODE");
        ControllerUtil.igTransactionColumnNames.put("xCampaignName", "X_CAMPAIGN_NAME");
        ControllerUtil.igTransactionColumnNames.put("carrierFeatureObjid", "CARRIER_FEATURE_OBJID");
        ControllerUtil.igTransactionColumnNames.put("cfProfileId", "CF_PROFILE_ID");
        ControllerUtil.igTransactionColumnNames.put("rpExtObjid", "RP_EXT_OBJID");
        ControllerUtil.igTransactionColumnNames.put("firstName", "FIRST_NAME");
        ControllerUtil.igTransactionColumnNames.put("middleInitial", "MIDDLE_INITIAL");
        ControllerUtil.igTransactionColumnNames.put("lastName", "LAST_NAME");
        ControllerUtil.igTransactionColumnNames.put("suffix", "SUFFIX");
        ControllerUtil.igTransactionColumnNames.put("prefix", "PREFIX");
        ControllerUtil.igTransactionColumnNames.put("ssnLast4", "SSN_LAST_4");
        ControllerUtil.igTransactionColumnNames.put("address1", "ADDRESS_1");
        ControllerUtil.igTransactionColumnNames.put("address2", "ADDRESS_2");
        ControllerUtil.igTransactionColumnNames.put("city", "CITY");
        ControllerUtil.igTransactionColumnNames.put("state", "STATE");
        ControllerUtil.igTransactionColumnNames.put("zipCode1", "ZIP_CODE_ADDL");
        ControllerUtil.igTransactionColumnNames.put("country", "COUNTRY");
        ControllerUtil.igTransactionColumnNames.put("ospAccount", "OSP_ACCOUNT");
        ControllerUtil.igTransactionColumnNames.put("currAddrHouseNumber", "CURR_ADDR_HOUSE_NUMBER");
        ControllerUtil.igTransactionColumnNames.put("currAddrDirection", "CURR_ADDR_DIRECTION");
        ControllerUtil.igTransactionColumnNames.put("currAddrStreetName", "CURR_ADDR_STREET_NAME");
        ControllerUtil.igTransactionColumnNames.put("currAddrStreetType", "CURR_ADDR_STREET_TYPE");
        ControllerUtil.igTransactionColumnNames.put("currAddrUnit", "CURR_ADDR_UNIT");
        //ControllerUtil.igTransactionColumnNames.put("tmoNextGenFlag", "TMO_NEXT_GEN_FLAG");

        ControllerUtil.carrierFeatureMap.put("OBJID", "setObjId");
        ControllerUtil.carrierFeatureMap.put("DEV", "setDev");
        ControllerUtil.carrierFeatureMap.put("X_TECHNOLOGY", "setxTechnology");
        ControllerUtil.carrierFeatureMap.put("X_RATE_PLAN", "setxRatePlan");
        ControllerUtil.carrierFeatureMap.put("X_VOICEMAIL", "setxVoicemail");
        ControllerUtil.carrierFeatureMap.put("X_VM_CODE", "setxVmCode");
        ControllerUtil.carrierFeatureMap.put("X_VM_PACKAGE", "setxVmPackage");
        ControllerUtil.carrierFeatureMap.put("X_CALLER_ID", "setxCallerId");
        ControllerUtil.carrierFeatureMap.put("X_ID_CODE", "setxIdCode");
        ControllerUtil.carrierFeatureMap.put("X_ID_PACKAGE", "setxIdPackage");
        ControllerUtil.carrierFeatureMap.put("X_SMS", "setxSms");
        ControllerUtil.carrierFeatureMap.put("X_SMS_CODE", "setxSmsCode");
        ControllerUtil.carrierFeatureMap.put("X_SMS_PACKAGE", "setxSmsPackage");
        ControllerUtil.carrierFeatureMap.put("X_CALL_WAITING", "setxCallWaiting");
        ControllerUtil.carrierFeatureMap.put("X_CW_CODE", "setxCwCode");
        ControllerUtil.carrierFeatureMap.put("X_CW_PACKAGE", "setxCwPackage");
        ControllerUtil.carrierFeatureMap.put("X_DIGITAL_FEATURE", "setxDigitalFeature");
        ControllerUtil.carrierFeatureMap.put("X_DIG_FEATURE", "setxDigFeature");
        ControllerUtil.carrierFeatureMap.put("X_FEATURE2X_CARRIER", "setxFeature2xCarrier");
        ControllerUtil.carrierFeatureMap.put("X_SMSC_NUMBER", "setxSmscNumber");
        ControllerUtil.carrierFeatureMap.put("X_DATA", "setxData");
        ControllerUtil.carrierFeatureMap.put("X_RESTRICTED_USE", "setxRestrictedUse");
        ControllerUtil.carrierFeatureMap.put("X_SWITCH_BASE_RATE", "setxSwitchBaseRate");
        ControllerUtil.carrierFeatureMap.put("X_FEATURES2BUS_ORG", "setxFeatures2BusOrg");
        ControllerUtil.carrierFeatureMap.put("X_IS_SWB_CARRIER", "setxIsSwbCarrier");
        ControllerUtil.carrierFeatureMap.put("X_MPN", "setxMpn");
        ControllerUtil.carrierFeatureMap.put("X_MPN_CODE", "setxMpnCode");
        ControllerUtil.carrierFeatureMap.put("X_POOL_NAME", "setxPoolName");
        ControllerUtil.carrierFeatureMap.put("CREATE_MFORM_IG_FLAG", "setCreateMformIgFlag");
        ControllerUtil.carrierFeatureMap.put("USE_CF_EXTENSION_FLAG", "setUseCfExtensionFlag");
        ControllerUtil.carrierFeatureMap.put("DATA_SAVER", "setDataSaver");
        ControllerUtil.carrierFeatureMap.put("DATA_SAVER_CODE", "setDataSaverCode");
        ControllerUtil.carrierFeatureMap.put("USE_RP_EXTENSION_FLAG", "setUseRpExtensionFlag");
        ControllerUtil.carrierFeatureMap.put("TMO_NEXT_GEN_FLAG", "setTmoNextGenFlag");
    }

    /**
     *
     * @param key
     * @return
     */
    public static String getDBColumnName(String key) {
        return ControllerUtil.columnMap.get(key);
    }
    
    /**
     * This method is used to retrieve the setter method that should be used for setting carrier features values
     * @param key
     * @return
     */
    public static String getCarrierFeatureSetter(String key) {
        return ControllerUtil.carrierFeatureMap.get(key);
    }

}
