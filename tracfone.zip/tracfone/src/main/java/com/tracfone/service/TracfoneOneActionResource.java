package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneBucketControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneActionItemId;
import com.tracfone.service.model.request.TracfoneOneBucketDetail;
import com.tracfone.service.model.request.TracfoneOneBulkTransaction;
import com.tracfone.service.model.request.TracfoneOneColumnDesc;
import com.tracfone.service.model.request.TracfoneOneNewTransaction;
import com.tracfone.service.model.request.TracfoneOneRework;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.request.TracfoneOneUserTask;
import com.tracfone.service.model.response.TFOneActionItemBucket;
import com.tracfone.service.model.response.TFOneAdminActionItem;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneBulkInsertReport;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneCarrierTransactionResponse;
import com.tracfone.service.model.response.TFOneColumnDesc;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGFailLogs;
import com.tracfone.service.model.response.TFOneUserHistory;
import com.tracfone.service.model.response.TFOneUserTask;
import com.tracfone.service.model.response.TracfoneOneViewActionItems;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author druiz
 */
@Path("action")
public class TracfoneOneActionResource {

    @EJB
    private TracfoneControllerLocalAction tracfoneControllerAction;

    @EJB
    private TracfoneControllerLocal tracfoneController;

    @EJB
    private TracfoneBucketControllerLocal tracfoneBucketController;

    @Context
    private SecurityContext securityContext;

    private static Logger logger = LogManager.getLogger(TracfoneOneActionResource.class);

    private static Gson gson = new GsonBuilder().serializeNulls().create();

    @POST
    @Path("actionitemid")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response viewActionItemId(final TracfoneOneActionItemId tracfoneOneActionItemId) {
        TracfoneOneViewActionItems aidResponse = null;
        try {
            aidResponse = tracfoneControllerAction.viewActionitemId(tracfoneOneActionItemId, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }

        return Response.ok(gson.toJson(aidResponse), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("buckets")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response retrieveBucketDetails(TracfoneOneBucketDetail bucketDetail) {
        List<TFOneActionItemBucket> tfOneBucketsResponse;
        try {
            tfOneBucketsResponse = tracfoneControllerAction.bucketsDetailTransaction(bucketDetail, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }

        return Response.ok(gson.toJson(tfOneBucketsResponse), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("transaction")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertTransaction(final TracfoneOneNewTransaction tfOneNewTransaction) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneControllerAction.insertTransaction(tfOneNewTransaction, getUserFromPrincipal().getUserId(), getUserFromPrincipal().getDescription());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }

        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("transaction/bulkinserts")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertBulkTransactions(final TracfoneOneBulkTransaction tfOneBulkTransaction) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneControllerAction.insertBulkTransactions(tfOneBulkTransaction,
                    getUserFromPrincipal().getUserId(),
                    getUserFromPrincipal().getDescription());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }

        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("transaction/bulkinsertsummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertReports = null;
        try {
            bulkInsertReports = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(),
                    "Bulk IG Insert",
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(bulkInsertReports), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("transaction/geterrorrecorddetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> reports = new ArrayList<>();
        try {
            reports = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(reports), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Re-queues the search criteria by setting status to Q
     * and status message to empty.
     *
     * @param tracfoneOneRework
     * @return
     */
    @POST
    @Path("requeue")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response requeueTransaction(TracfoneOneRework tracfoneOneRework) {
        TFOneGeneralResponse tfOneResponse = null;

        // Set the rework criterai to re-queue only.
        TFOneAdminActionItem reworkCriteria = new TFOneAdminActionItem();
        reworkCriteria.setStatus("Q");
        reworkCriteria.setStatusMessage(" ");
        tracfoneOneRework.setReworkCriteria(reworkCriteria);

        try {
            tfOneResponse = tracfoneControllerAction.reworkBatchTransaction(tracfoneOneRework, false, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }

        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("rework")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response reworkTransaction(TracfoneOneRework tracfoneOneRework) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneControllerAction.reworkBatchTransaction(tracfoneOneRework, true, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }

        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }


    @POST
    @Path("failedtransaction")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
//    @Authorized
    public Response viewFailedTransaction(final TracfoneOneActionItemId tracfoneOneActionItemId) {
        TracfoneOneViewActionItems aidResponse = null;
        try {
            aidResponse = tracfoneControllerAction.viewFailedTransaction(tracfoneOneActionItemId, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }

        return Response.ok(gson.toJson(aidResponse), MediaType.APPLICATION_JSON).build();
    }


    @POST
    @Path("transcarrierresponse")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    public Response transactionCarrierResponse(final TracfoneOneActionItemId tracfoneOneActionItemId) {
        TFOneCarrierTransactionResponse tfOneResponse = null;

        try {
            tfOneResponse = tracfoneControllerAction.getTransactionCarrierResponse(tracfoneOneActionItemId, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.NOT_FOUND.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }

        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for User Histories based on UserId
     *
     * @param tfOneUserHistory
     * @return
     */
    @POST
    @Path("userhistory")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getUserHistoryByUserId(final TracfoneOneUserHistory tfOneUserHistory) {
        List<TFOneUserHistory> userHistories = new ArrayList<>();
        try {
            userHistories = tracfoneControllerAction.getUserHistoryByUserId(tfOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(userHistories), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("assignusertask")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertUserTask(final TracfoneOneUserTask tfOneUserTask) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneControllerAction.insertUserTask(tfOneUserTask, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("updateusertask")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateUserTask(final TracfoneOneUserTask tfOneUserTask) {
        TFOneUserTask tfUserTask;
        try {
            tfUserTask = tracfoneControllerAction.updateUserTask(tfOneUserTask, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfUserTask), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("usertask")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getUserTaskByUserId(final TracfoneOneUserTask tfOneUserTask) {
        List<TFOneUserTask> userTasks;
        tfOneUserTask.setType("IG_TRANSACTION");
        try {
            userTasks = tracfoneControllerAction.getUserTaskByUserId(tfOneUserTask);
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(userTasks), MediaType.APPLICATION_JSON).build();
    }

    @GET
    @Path("userlist")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllUsers() {
        List<TFOneAdminUser> tfOneAdminUsers = null;
        try {
            tfOneAdminUsers = tracfoneController.getAllUsers(getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }

        return Response.ok(gson.toJson(tfOneAdminUsers), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("transaction/getIgInProgress")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getIgTransactionsInProgress(TracfoneOneNewTransaction tracfoneOneNewTransaction) {
        List<TFOneAdminActionItem> tfOneAdminActionItem;
        try {
            tfOneAdminActionItem = tracfoneControllerAction.getIgTransactionsInProgress(tracfoneOneNewTransaction);
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneAdminActionItem), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("transaction/deleteIgInProgress")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteIgTransactionInProgress(final TracfoneOneNewTransaction tracfoneOneNewTransaction) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneControllerAction.deleteIgTransactionInProgress(tracfoneOneNewTransaction,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get Id_Details based on Id Type
     *
     * @param tfUserHistory
     * @return
     */
    @POST
    @Path("transaction/getuserhistorydetail/{uniquekey}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getUserHistoryDetailByIdType(TracfoneOneUserHistory tfUserHistory,
                                                 final @PathParam("uniquekey") String uniqueKey) {
        TFOneGeneralResponse userHistoryIdDetail = null;
        try {
            userHistoryIdDetail = tracfoneControllerAction.getUserHistoryDetailByIdType(tfUserHistory.getDbEnv(),
                    uniqueKey, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(userHistoryIdDetail), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for Carrier_Profile_Buckets based on service plan and profile
     *
     * @param tfOneSearchBucketModel
     * @return
     */
    @POST
    @Path("transaction/searchcpbuckets")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierProfileBuckets(final TracfoneOneSearchBucketModel tfOneSearchBucketModel) {
        List<TFOneCarrierProfileBucket> tfOneBuckets = new ArrayList<>();
        try {
            tfOneBuckets = tracfoneBucketController.searchCarrierProfileBuckets(tfOneSearchBucketModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            logger.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneBuckets), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for Carrier_Profile_Child_Buckets based on
     * service plan, profile and child plan
     *
     * @param tfOneSearchBucketModel
     * @return
     */
    @POST
    @Path("transaction/searchcpchildbuckets")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierProfileChildBuckets(final TracfoneOneSearchBucketModel tfOneSearchBucketModel) {
        List<TFOneCarrierProfileChildBucket> tfOneBuckets = new ArrayList<>();
        try {
            tfOneBuckets = tracfoneBucketController.searchCarrierProfileChildBuckets(tfOneSearchBucketModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            logger.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneBuckets), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("transaction/getIgfaillogs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getIgFailLogs(TracfoneOneNewTransaction tracfoneOneNewTransaction) {
        List<TFOneIGFailLogs> tfOneAdminActionItem;
        try {
            tfOneAdminActionItem = tracfoneControllerAction.getIgFailLogs(tracfoneOneNewTransaction);
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneAdminActionItem), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get column desc based on table name
     *
     * @return
     */
    @POST
    @Path("transaction/gettabledesc")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getTableDesc(TracfoneOneColumnDesc tfColumnDesc) {
        List<TFOneColumnDesc> columnDescList = new ArrayList<>();
        try {
            columnDescList = tracfoneControllerAction.getTableDesc(tfColumnDesc);
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(columnDescList), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves the user object making request from the principal.
     *
     * @return
     */
    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }
}