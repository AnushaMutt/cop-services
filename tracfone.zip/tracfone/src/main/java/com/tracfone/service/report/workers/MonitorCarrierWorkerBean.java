/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.report.workers;

import com.tracfone.service.model.report.TFOneReportMonitor;
import com.tracfone.service.util.TracfoneOneConstantReport;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.annotation.Resource;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Stateless;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author druiz
 */
@Stateless
public class MonitorCarrierWorkerBean {

    @Resource(lookup = "jndi/cop_report")
    private DataSource dataSourceReports;

    private AtomicBoolean busy = new AtomicBoolean(false);

    private static final Logger LOGGER = LogManager.getLogger(MonitorCarrierWorkerBean.class);

    @Lock(LockType.READ)
    public List<TFOneReportMonitor> runMonitorReport() {
        List<TFOneReportMonitor> carrierMonitorReport = new ArrayList<>();
        if (!busy.compareAndSet(false, true)) {
            return carrierMonitorReport;
        }

        try (Connection con = dataSourceReports.getConnection();
             PreparedStatement stmt = con.prepareStatement(TracfoneOneConstantReport.REPORT_SQL_MONITOR);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                TFOneReportMonitor tfOneReportMonitor = new TFOneReportMonitor();
                tfOneReportMonitor.setxDate(resultSet.getString("X_DATE"));
                tfOneReportMonitor.setTemplate(resultSet.getString("TEMPLATE"));
                tfOneReportMonitor.setOrderType(resultSet.getString("ORDER_TYPE"));
                tfOneReportMonitor.setSumAllQ(resultSet.getString("SUM_ALL_Q"));
                tfOneReportMonitor.setSumAllL(resultSet.getString("SUM_ALL_L"));
                tfOneReportMonitor.setSumAllCp(resultSet.getString("SUM_ALL_CP"));
                tfOneReportMonitor.setSumAllWp(resultSet.getString("SUM_ALL_WP"));
                tfOneReportMonitor.setSumAllW(resultSet.getString("SUM_ALL_W"));
                tfOneReportMonitor.setSumAllS(resultSet.getString("SUM_ALL_S"));
                tfOneReportMonitor.setSumAllE(resultSet.getString("SUM_ALL_E"));
                tfOneReportMonitor.setSumAllF(resultSet.getString("SUM_ALL_F"));
                tfOneReportMonitor.setTransType(resultSet.getString("TRANS_TYPE"));
                tfOneReportMonitor.setSumAllTf(resultSet.getString("SUM_ALL_TF"));
                tfOneReportMonitor.setSumAllHw(resultSet.getString("SUM_ALL_HW"));
                carrierMonitorReport.add(tfOneReportMonitor);
            }
        } catch (Exception e) {
            LOGGER.error("Monitor report retrival error. EX: ", e);
        } finally {
            busy.set(false);
        }
        return carrierMonitorReport;
    }
}
