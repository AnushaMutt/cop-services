package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOnePCRFTransaction;
import com.tracfone.service.model.response.TFOnePCRFTransSearchResult;
import com.tracfone.service.util.TracfoneOneConstantPCRFTrans;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
 * @author Gaurav.Sharma
 */
@Stateless
public class TracfoneOnePCRFTransController implements TracfoneOnePCRFTransControllerLocal, TracfoneOneConstantPCRFTrans {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOnePCRFTransController.class);
    @EJB
    private TracfoneOnePCRFTransActionLocal pcrfTransAction;

    @Override
    public TFOnePCRFTransSearchResult viewPcrfTransaction(TracfoneOnePCRFTransaction pcrfTransactions) throws TracfoneOneException {
        TFOnePCRFTransSearchResult pcrfTransactionSearchResult;
        LOGGER.debug("Search Criteria for PCRF - " + pcrfTransactions);
        try {
            pcrfTransactionSearchResult = pcrfTransAction.viewPcrfTransaction(pcrfTransactions);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_PCRF_TRANSACTION_ERROR, TRACFONE_GET_PCRF_TRANSACTION_ERROR_MESSAGE, ex);
        }
        return pcrfTransactionSearchResult;
    }

}
