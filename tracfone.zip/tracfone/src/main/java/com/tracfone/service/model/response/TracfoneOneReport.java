
package com.tracfone.service.model.response;

import java.util.Date;

/**
 * @author druiz
 */
public class TracfoneOneReport {
    private String reportName;
    private String jsonResponse;
    private String reportSQL;
    private Date createDate;

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public String getJsonResponse() {
        return jsonResponse;
    }

    public void setJsonResponse(String jsonResponse) {
        this.jsonResponse = jsonResponse;
    }

    public String getReportSQL() {
        return reportSQL;
    }

    public void setReportSQL(String reportSQL) {
        this.reportSQL = reportSQL;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    @Override
    public String toString() {
        return "TracfoneOneReport{" +
                "reportName='" + reportName + '\'' +
                ", jsonResponse='" + jsonResponse + '\'' +
                ", reportSQL='" + reportSQL + '\'' +
                ", createDate=" + createDate +
                '}';
    }
}
