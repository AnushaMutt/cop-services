package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneBPTech;
import com.tracfone.service.model.request.TracfoneOneZip2Tech;
import com.tracfone.service.model.request.TracfoneonePaginationSearch;
import com.tracfone.service.model.response.TFOneBPTech;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneZip2Tech;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantZip2Tech;
import jersey.repackaged.com.google.common.collect.Lists;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

@Stateless
public class TracfoneOneZip2TechAction implements TracfoneOneZip2TechActionLocal, TracfoneOneConstantZip2Tech, TracfoneOneConstant {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneZip2TechAction.class);
    private static final String TECHKEY = "TECHKEY";

    @EJB
    private DataBaseController dbControllerEJB;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    private static final String AND = " AND ";

    @Override
    public List<TFOneZip2Tech> searchZip2Tech(TracfoneOneZip2Tech tfZip2Tech) throws TracfoneOneException {
        List<TFOneZip2Tech> zip2Techs = null;
        try (Connection con = dbControllerEJB.getDataSource(tfZip2Tech.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchQuery(TRACFONE_SEARCH_ZIP2TECH, tfZip2Tech, true));
             PreparedStatement totalCountStmt = con.prepareStatement(getSearchQuery(GET_ZIP2TECH_TRANSACTION_COUNT, tfZip2Tech, false));) {
            setSearchZip2TechParameters(tfZip2Tech, stmt, true);
            setSearchZip2TechParameters(tfZip2Tech, totalCountStmt, false);

            int count = 0;
            try (ResultSet resultSetCount = totalCountStmt.executeQuery()) {
                while (resultSetCount.next()) {
                    count = resultSetCount.getInt(1);
                }
            }
            LOGGER.info("Total Zip2Tech Count " + count);

            zip2Techs = new ArrayList<>(1);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    zip2Techs.add(setZip2Tech(resultSet));
                }
            }
            TracfoneonePaginationSearch tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
            tracfoneonePaginationSearch.setStartIndex(tfZip2Tech.getPaginationSearch().getStartIndex());
            tracfoneonePaginationSearch.setEndIndex(tfZip2Tech.getPaginationSearch().getEndIndex());
            tracfoneonePaginationSearch.setTotal(count);
            if (!zip2Techs.isEmpty()) {
                zip2Techs.get(0).setPaginationSearch(tracfoneonePaginationSearch);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return zip2Techs;
    }

    private TFOneZip2Tech setZip2Tech(ResultSet rs) throws SQLException {
        TFOneZip2Tech zip2Tech = new TFOneZip2Tech();
        zip2Tech.setZips(rs.getString("ZIP"));
        zip2Tech.setState(rs.getString("STATE"));
        zip2Tech.setCounty(rs.getString("COUNTY"));
        zip2Tech.setPref1(rs.getString("PREF1"));
        zip2Tech.setPref2(rs.getString("PREF2"));
        zip2Tech.setService(rs.getString("SERVICE"));
        zip2Tech.setLanguage(rs.getString("LANGUAGE"));
        zip2Tech.setAction(rs.getString("ACTION"));
        zip2Tech.setMarket(rs.getString("MARKET"));
        zip2Tech.setZip2(rs.getString("ZIP2"));
        zip2Tech.setAid(rs.getString("AID"));
        zip2Tech.setVid(rs.getString("VID"));
        zip2Tech.setVc(rs.getString("VC"));
        zip2Tech.setSahcid(rs.getString("SAHCID"));
        zip2Tech.setCom(rs.getString("COM"));
        zip2Tech.setLocale(rs.getString("LOCALE"));
        zip2Tech.setSiteType(rs.getString("SITETYPE"));
        zip2Tech.setGotoPhoneList(rs.getString("GOTOPHONELIST"));
        zip2Tech.setTech(rs.getString("TECH"));
        zip2Tech.setTechZip(rs.getString("TECHZIP"));
        zip2Tech.setTechkey(rs.getString(TECHKEY));
        zip2Tech.setPrefParent(rs.getString("X_PREF_PARENT"));
        return zip2Tech;
    }

    private void setSearchZip2TechParameters(TracfoneOneZip2Tech tfZip2Tech, PreparedStatement stmt, boolean isSearchStmt) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tfZip2Tech.getZips())) {
            for (String zip : tfZip2Tech.getZips().split(",")) {
                stmt.setString(index++, zip);
            }
        }
        if (!StringUtils.isNullOrEmpty(tfZip2Tech.getService())) {
            for (String service : tfZip2Tech.getService().split(",")) {
                stmt.setString(index++, service);
            }
        }
        if (!StringUtils.isNullOrEmpty(tfZip2Tech.getTechkey())) {
            for (String techKey : tfZip2Tech.getTechkey().split(",")) {
                stmt.setString(index++, techKey);
            }
        }
        if (!StringUtils.isNullOrEmpty(tfZip2Tech.getState())) {
            for (String state : tfZip2Tech.getState().split(",")) {
                stmt.setString(index++, state);
            }
        }
        if (!StringUtils.isNullOrEmpty(tfZip2Tech.getCounty())) {
            for (String country : tfZip2Tech.getCounty().split(",")) {
                stmt.setString(index++, country);
            }
        }
        setSearchZip2TechParameters2(stmt, index, tfZip2Tech, isSearchStmt);
    }

    private void setSearchZip2TechParameters2(PreparedStatement stmt, int index, TracfoneOneZip2Tech tfZip2Tech, boolean isSearchStmt) throws SQLException {
        if (!StringUtils.isNullOrEmpty(tfZip2Tech.getLanguage())) {
            stmt.setString(index++, tfZip2Tech.getLanguage());
        }
        if (!StringUtils.isNullOrEmpty(tfZip2Tech.getPrefParent())) {
            stmt.setString(index++, tfZip2Tech.getPrefParent());
        }
        if (isSearchStmt) {
            stmt.setInt(index++, tfZip2Tech.getPaginationSearch().getEndIndex());
            stmt.setInt(index, tfZip2Tech.getPaginationSearch().getStartIndex());
        }
    }

    private String getSearchQuery(String query, TracfoneOneZip2Tech tfZip2Tech, boolean isSearch) {
        String searchQuery = null;
        StringBuilder builder = new StringBuilder(query);

        if (!StringUtils.isNullOrEmpty(tfZip2Tech.getZips())) {
            List<String> zips = Arrays.asList(tfZip2Tech.getZips().split(","));
            int totalNumberOfZip = zips.size();
            LOGGER.info("Total number of zip to search Zip2Tech is : " + totalNumberOfZip);

            if (totalNumberOfZip < 1000) {
                builder.append("ZIP in(? ");
                buildInClause(builder, totalNumberOfZip);
            } else {
                builder.append("(");
                List<List<String>> splitZips = Lists.partition(zips, 1000);
                StringBuilder tempBuilder;

                for (List<String> splitedZips : splitZips) {
                    tempBuilder = new StringBuilder("ZIP in(? ");
                    buildInClause(tempBuilder, splitedZips.size());
                    builder.append(tempBuilder).append(" OR ");
                }

                builder.delete(builder.lastIndexOf(" OR "), builder.length());
                builder.append(")");
            }
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfZip2Tech.getService())) {
            buildInClause(builder.append("SERVICE in(? "), tfZip2Tech.getService().split(",").length);
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfZip2Tech.getTechkey())) {
            buildInClause(builder.append("TECHKEY in(? "), tfZip2Tech.getTechkey().split(",").length);
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfZip2Tech.getState())) {
            buildInClause(builder.append("STATE in(? "), tfZip2Tech.getState().split(",").length);
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfZip2Tech.getCounty())) {
            buildInClause(builder.append("COUNTY in(? "), tfZip2Tech.getCounty().split(",").length);
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfZip2Tech.getLanguage())) {
            builder.append("LANGUAGE = ? ");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfZip2Tech.getPrefParent())) {
            builder.append("X_PREF_PARENT = ? ");
            builder.append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Zip2Tech search query is : " + searchQuery);
        return (!isSearch ? searchQuery : searchQuery.concat(" order by ZIP asc) zip2techs where rownum <= ? ) WHERE rnum >= ?"));
    }

    private StringBuilder buildInClause(StringBuilder builder, int size) {
        int index = 1;
        while (index < size) {
            builder.append(",? ");
            index++;
        }
        return builder.append(")");
    }

    @Override
    public TFOneGeneralResponse updateZip2Techs(List<TracfoneOneZip2Tech> tfZip2Techs, int userId) throws TracfoneOneException {
        String unique = "";
        try (Connection con = dbControllerEJB.getDataSource(tfZip2Techs.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_ZIP2TECH);) {
            for (TracfoneOneZip2Tech tfZip2Tech : tfZip2Techs) {
                TracfoneonePaginationSearch paginationSearch = new TracfoneonePaginationSearch();
                paginationSearch.setStartIndex(1);
                paginationSearch.setEndIndex(10);
                tfZip2Tech.setPaginationSearch(paginationSearch);
                if (searchZip2Tech(tfZip2Tech).isEmpty()) {
                    int index = 1;
                    unique = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
                    stmt.setString(index++, tfZip2Tech.getService());
                    stmt.setString(index++, tfZip2Tech.getTechkey());
                    stmt.setString(index++, tfZip2Tech.getPrefParent());
                    stmt.setString(index++, tfZip2Tech.getZips());
                    stmt.setString(index++, "&zip=".concat(tfZip2Tech.getZips()));
                    stmt.setString(index++, "&techzip=".concat(tfZip2Tech.getZips()));
                    stmt.setString(index++, tfZip2Tech.getOldZip());
                    stmt.setString(index++, tfZip2Tech.getState());
                    stmt.setString(index++, tfZip2Tech.getCounty());
                    stmt.setString(index++, tfZip2Tech.getLanguage());
                    stmt.setString(index++, tfZip2Tech.getOldService());
                    stmt.setString(index++, tfZip2Tech.getOldTechKey());
                    stmt.setString(index, tfZip2Tech.getOldPrefParent());
                    stmt.executeUpdate();
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Zip2Tech", "Updated Zip2Techs " + tfZip2Techs, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, unique);
    }

    @Override
    public List<String> getZip2TechColumnValues(String columnName, String dbEnv) throws TracfoneOneException {
        List<String> columnValues = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT distinct ".concat(columnName).
                     concat(" FROM mapinfo.eg_zip2tech where ").concat(columnName)
                     .concat(" is not null order by ").concat(columnName));) {
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    columnValues.add(resultSet.getString(columnName));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return columnValues;
    }

    @Override
    public TFOneGeneralResponse insertZip2Tech(TracfoneOneZip2Tech tfZip2Tech, int userId, String uniqueId) throws TracfoneOneException {
        String unique = "";
        try (Connection con = dbControllerEJB.getDataSource(tfZip2Tech.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_ZIP2TECH);) {
            TracfoneonePaginationSearch paginationSearch = new TracfoneonePaginationSearch();
            paginationSearch.setStartIndex(1);
            paginationSearch.setEndIndex(10);
            tfZip2Tech.setPaginationSearch(paginationSearch);
            if (searchZip2Tech(tfZip2Tech).isEmpty()) {
                unique = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
                setInsertQueryParameters(stmt, tfZip2Tech);
                stmt.executeUpdate();
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit;
            // Added this logic to track bulk insert of ZIP2TECH
            if (StringUtils.isNullOrEmpty(uniqueId)) {
                audit = new TracfoneAudit(userId, "Insert Zip2Tech",
                        "Inserted Zip2Tech Object " + tfZip2Tech, null);
            } else {
                audit = new TracfoneAudit(userId, "Bulk Zip2Tech Insert",
                        "Inserted Zip2Tech Object " + tfZip2Tech, "CARRIER ID_" + uniqueId);
            }
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, unique);
    }

    private void setInsertQueryParameters(PreparedStatement stmt, TracfoneOneZip2Tech tfZip2Tech) throws SQLException {
        stmt.setString(1, tfZip2Tech.getZips());
        stmt.setString(2, tfZip2Tech.getState());
        stmt.setString(3, tfZip2Tech.getCounty());
        stmt.setString(4, tfZip2Tech.getPref1());
        stmt.setString(5, tfZip2Tech.getPref2());
        stmt.setString(6, tfZip2Tech.getService());
        stmt.setString(7, tfZip2Tech.getLanguage());
        stmt.setString(8, tfZip2Tech.getAction());
        stmt.setString(9, tfZip2Tech.getMarket());
        stmt.setString(10, tfZip2Tech.getZip2());
        stmt.setString(11, tfZip2Tech.getAid());
        stmt.setString(12, tfZip2Tech.getVid());
        stmt.setString(13, tfZip2Tech.getVc());
        stmt.setString(14, tfZip2Tech.getSahcid());
        stmt.setString(15, tfZip2Tech.getCom());
        stmt.setString(16, tfZip2Tech.getLocale());
        stmt.setString(17, tfZip2Tech.getSiteType());
        stmt.setString(18, tfZip2Tech.getGotoPhoneList());
        stmt.setString(19, tfZip2Tech.getTech());
        stmt.setString(20, tfZip2Tech.getTechZip());
        stmt.setString(21, tfZip2Tech.getTechkey());
        stmt.setString(22, tfZip2Tech.getPrefParent());
    }

    @Override
    public List<TFOneBPTech> searchBPTech(TracfoneOneBPTech tfBPTech) throws TracfoneOneException {
        List<TFOneBPTech> bpTechs = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(tfBPTech.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getBpSearchQuery(TRACFONE_SEARCH_BPTECH, tfBPTech));) {
            setBpTechParameters(tfBPTech, stmt);

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    bpTechs.add(setBpTech(resultSet));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return bpTechs;
    }

    private TFOneBPTech setBpTech(ResultSet rs) throws SQLException {
        TFOneBPTech tfOneBPTech = new TFOneBPTech();
        tfOneBPTech.setTechkey(rs.getString(TECHKEY));
        tfOneBPTech.setService(rs.getString("SERVICE"));
        tfOneBPTech.setBpCode(rs.getString("BP_CODE"));
        tfOneBPTech.setProductKey(rs.getString("PRODUCT_KEY"));
        return tfOneBPTech;
    }

    private void setBpTechParameters(TracfoneOneBPTech tfBPTech, PreparedStatement stmt) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tfBPTech.getService())) {
            for (String service : tfBPTech.getService().split(",")) {
                stmt.setString(index++, service);
            }
        }
        if (!StringUtils.isNullOrEmpty(tfBPTech.getTechkey())) {
            for (String techKey : tfBPTech.getTechkey().split(",")) {
                stmt.setString(index++, techKey);
            }
        }
        if (!StringUtils.isNullOrEmpty(tfBPTech.getBpCode())) {
            for (String bpCode : tfBPTech.getBpCode().split(",")) {
                stmt.setString(index++, bpCode);
            }
        }
        if (!StringUtils.isNullOrEmpty(tfBPTech.getProductKey())) {
            for (String productKey : tfBPTech.getProductKey().split(",")) {
                stmt.setString(index++, productKey);
            }
        }
    }

    private String getBpSearchQuery(String query, TracfoneOneBPTech tfBPTech) {
        String searchQuery = null;
        StringBuilder builder = new StringBuilder(query);

        if (!StringUtils.isNullOrEmpty(tfBPTech.getService())) {
            buildInClause(builder.append("SERVICE in(? "), tfBPTech.getService().split(",").length);
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfBPTech.getTechkey())) {
            buildInClause(builder.append("TECHKEY in(? "), tfBPTech.getTechkey().split(",").length);
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfBPTech.getBpCode())) {
            buildInClause(builder.append("BP_CODE in(? "), tfBPTech.getBpCode().split(",").length);
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tfBPTech.getProductKey())) {
            buildInClause(builder.append("PRODUCT_KEY in(? "), tfBPTech.getProductKey().split(",").length);
            builder.append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("BPTech search query is : " + searchQuery);
        return searchQuery;
    }

    @Override
    public List<String> getBPTechColumn(String columnName, String dbEnv) throws TracfoneOneException {
        List<String> columnValues = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT distinct ".concat(columnName).
                     concat(" FROM mapinfo.EG_BPTECH where ").concat(columnName)
                     .concat(" is not null order by ").concat(columnName));) {
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    columnValues.add(resultSet.getString(columnName));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return columnValues;
    }

    @Override
    public TFOneGeneralResponse updateBPTechs(List<TracfoneOneBPTech> tfBPTechs, int userId) throws TracfoneOneException {
        String uniqueId = "";
        try (Connection con = dbControllerEJB.getDataSource(tfBPTechs.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_BPTECH);) {

            for (TracfoneOneBPTech tfBPTech : tfBPTechs) {
                if (searchBPTech(tfBPTech).isEmpty()) {
                    uniqueId = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
                    stmt.setString(1, tfBPTech.getTechkey());
                    stmt.setString(2, tfBPTech.getService());
                    stmt.setString(3, tfBPTech.getBpCode());
                    stmt.setString(4, tfBPTech.getProductKey());
                    stmt.setString(5, tfBPTech.getOldTechkey());
                    stmt.setString(6, tfBPTech.getOldService());
                    stmt.setString(7, tfBPTech.getOldBpCode());
                    stmt.executeUpdate();
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update BPTech", "Updated BPTechs " + tfBPTechs, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, uniqueId);
    }

    @Override
    public TFOneGeneralResponse deleteZip2Techs(TracfoneOneZip2Tech tfZip2Tech, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfZip2Tech.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_ZIP2TECH);) {
            stmt.setString(1, tfZip2Tech.getZips());
            stmt.setString(2, tfZip2Tech.getLanguage());
            stmt.setString(3, tfZip2Tech.getService());
            stmt.setString(4, tfZip2Tech.getTechkey());
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Zip2Tech", "Deleted Zip2Tech Object " + tfZip2Tech, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, String.valueOf(tfZip2Tech.getZips()));
    }

    @Override
    public TFOneGeneralResponse insertBpTech(TracfoneOneBPTech tfBPTech, int userId, String unique) throws TracfoneOneException {
        String uniqueId = "";
        try (Connection con = dbControllerEJB.getDataSource(tfBPTech.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_BPTECH);) {
            String productKey = tfBPTech.getProductKey();
            tfBPTech.setProductKey(null);
            if (searchBPTech(tfBPTech).isEmpty()) {
                uniqueId = String.valueOf(new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
                stmt.setString(1, tfBPTech.getTechkey());
                stmt.setString(2, tfBPTech.getService());
                stmt.setString(3, tfBPTech.getBpCode());
                stmt.setString(4, productKey);
                stmt.executeUpdate();
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit;
            // Added this logic to track bulk insert of BPTECH
            if (StringUtils.isNullOrEmpty(unique)) {
                audit = new TracfoneAudit(userId, "Insert BPTech",
                        "Inserted BPTech Object " + tfBPTech, null);
            } else {
                audit = new TracfoneAudit(userId, "Bulk BPTech Insert",
                        "Inserted BPTech Object " + tfBPTech, "CARRIER ID_" + unique);
            }
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, uniqueId);
    }

    @Override
    public TFOneGeneralResponse deleteBpTech(TracfoneOneBPTech tfBPTech, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfBPTech.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_BPTECH);) {
            stmt.setString(1, tfBPTech.getTechkey());
            stmt.setString(2, tfBPTech.getService());
            stmt.setString(3, tfBPTech.getBpCode());
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete BPTech", "Deleted BPTech Object " + tfBPTech, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, String.valueOf(tfBPTech.getTechkey()));
    }

    @Override
    public boolean searchTechKey(TracfoneOneZip2Tech zip2Tech) throws TracfoneOneException {
        boolean dependencyExists = false;
        try (Connection con = dbControllerEJB.getDataSource(zip2Tech.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_COUNT_TECHKEY);) {
            stmt.setString(1, zip2Tech.getTechkey());

            try (ResultSet resultSetCount = stmt.executeQuery()) {
                while (resultSetCount.next()) {
                    LOGGER.info("Dependency in zip2tech table for this techkey ", zip2Tech.getTechkey());
                    if (Integer.valueOf(resultSetCount.getString(TECHKEY)) > 0) {
                        dependencyExists = true;
                    }
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return dependencyExists;
    }
}
