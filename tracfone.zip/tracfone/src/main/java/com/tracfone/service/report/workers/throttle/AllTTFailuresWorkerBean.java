package com.tracfone.service.report.workers.throttle;

import com.tracfone.service.model.report.TFOneReportAllTTFailures;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Resource;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

@Stateless
public class AllTTFailuresWorkerBean {

    @Resource(lookup = "jndi/cop_report")
    private DataSource dataSourceReports;

    private AtomicBoolean busy = new AtomicBoolean(false);
    private static final Logger LOGGER = LogManager.getLogger(AllTTFailuresWorkerBean.class);

    @Lock(LockType.READ)
    public List<TFOneReportAllTTFailures> runAllTTFailuresReport() {
        List<TFOneReportAllTTFailures> ttFailures = new ArrayList<>();

        if (!busy.compareAndSet(false, true)) {
            return ttFailures;
        }

        try (Connection con = dataSourceReports.getConnection();) {
            LOGGER.debug("AllTTFailures - Going to Got a connection");
            try (PreparedStatement stmt = con.prepareStatement(TracfoneOneConstantReport.REPORT_SQL_ALLTTFAILURES);
                 ResultSet resultSet = stmt.executeQuery();) {
                LOGGER.debug("AllTTFailures - Going to retrieve the report");
                while (resultSet.next()) {
                    TFOneReportAllTTFailures tfOneReportAllTTFailures = new TFOneReportAllTTFailures();
                    tfOneReportAllTTFailures.setParent(resultSet.getString("parent"));
                    tfOneReportAllTTFailures.setTimeSegment(resultSet.getString("X_TIME_SEGMENT"));
                    tfOneReportAllTTFailures.setOrderTypeGroup(resultSet.getString("orderTypeGroup"));
                    tfOneReportAllTTFailures.setTotalTransCount(resultSet.getString("TOTAL_TRANS_COUNT"));
                    tfOneReportAllTTFailures.setFailureCount(resultSet.getString("FAILURE_COUNT"));
                    tfOneReportAllTTFailures.setParentShort(resultSet.getString("parentShort"));
                    ttFailures.add(tfOneReportAllTTFailures);
                }
            }
        } catch (Exception e) {
            LOGGER.error("AllTTFailures Report Retrieval Error - ", e);
        } finally {
            busy.set(false);
        }
        return ttFailures;
    }
}
