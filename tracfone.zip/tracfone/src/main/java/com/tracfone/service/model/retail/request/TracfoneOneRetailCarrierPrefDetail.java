package com.tracfone.service.model.retail.request;

public class TracfoneOneRetailCarrierPrefDetail {
    private String objId;
    private String carrierPrefGroupId;
    private String carrierDetailId;
    private String rank;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getCarrierPrefGroupId() {
        return carrierPrefGroupId;
    }

    public void setCarrierPrefGroupId(String carrierPrefGroupId) {
        this.carrierPrefGroupId = carrierPrefGroupId;
    }

    public String getCarrierDetailId() {
        return carrierDetailId;
    }

    public void setCarrierDetailId(String carrierDetailId) {
        this.carrierDetailId = carrierDetailId;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    @Override
    public String toString() {
        return "TracfoneOneRetailCarrierPrefDetail{" +
                "objId='" + objId + '\'' +
                ", carrierPrefGroupId='" + carrierPrefGroupId + '\'' +
                ", carrierDetailId='" + carrierDetailId + '\'' +
                ", rank='" + rank + '\'' +
                '}';
    }
}
