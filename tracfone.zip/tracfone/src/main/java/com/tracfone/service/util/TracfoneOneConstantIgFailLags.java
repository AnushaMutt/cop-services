package com.tracfone.service.util;

/**
 * @author thejaswini
 */
public interface TracfoneOneConstantIgFailLags {

    String AND = " AND ";

    // ERROR MESSAGES
    String TRACFONE_GET_IG_FAIL_LOGS_ERROR = "TFE3000";
    String TRACFONE_GET_IG_FAIL_LOGS_ERROR_MESSAGE = "Unable to get IG Fail Logs";

    // Queries
    String TRACFONE_GET_ALL_IG_FAIL_LOGS = "select * from gw1.ig_failed_log where ";

    String TRACFONE_GET_ALL_IG_FAIL_LOGS_START = "select * from ( " +
            "select /*+ FIRST_ROWS(n) */ a.*, ROWNUM rnum from (";

    String TRACFONE_GET_ALL_IG_FAIL_LOGS_COUNT = "SELECT count(1) AS totalRecords FROM gw1.ig_failed_log  where ";

}
