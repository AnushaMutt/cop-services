/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.request;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * @author druiz
 */
@XmlRootElement(name = "ViewActionItemRequest")
public class TracfoneOneActionItemId {
    @XmlElement(name = "actionItemId")
    private List<String> actionItemId;
    @XmlElement(name = "transactionId")
    private List<String> transactionId;
    @XmlElement(name = "orderType")
    private List<String> orderType;
    @XmlElement(name = "esn")
    private List<String> esn;
    @XmlElement(name = "status")
    private List<String> status;
    @XmlElement(name = "fromCreationDate")
    private String creationFromDate;
    @XmlElement(name = "toCreationDate")
    private String creationToDate;
    @XmlElement(name = "fromUpdateDate")
    private String updateFromDate;
    @XmlElement(name = "toUpdateDate")
    private String updateToDate;
    @XmlElement(name = "statusMessage")
    private List<String> statusMessage;
    @XmlElement(name = "notInStatusMessage")
    private boolean notInStatusMessage;
    @XmlElement(name = "dbenv")
    private String dbenv;
    @XmlElement(name = "isExactMatch")
    private boolean isExactMatch;
    @XmlElement(name = "isExactMatchActionItemId")
    private boolean isExactMatchForActionItemId;
    @XmlElement(name = "notInActionItemId")
    private boolean notInActionItemId;
    @XmlElement(name = "notInStatus")
    private boolean notInStatus;
    @XmlElement(name = "notInOrderType")
    private boolean notInOrderType;
    @XmlElement(name = "additionalSearchColumns")
    private List<TracfoneOneSearchAdditionalModel> additionalColumns;
    @XmlElement(name = "pagination")
    private TracfoneonePaginationSearch paginationSearch;
    @XmlElement(name = "fromUserHistory")
    private boolean fromUserHistory;
    private boolean regexExp;
    private String matchParam;
    private boolean showFailLogs;

    public boolean isNotInStatus() {
        return notInStatus;
    }

    public void setNotInStatus(boolean notInStatus) {
        this.notInStatus = notInStatus;
    }

    public boolean isNotInOrderType() {
        return notInOrderType;
    }

    public void setNotInOrderType(boolean notInOrderType) {
        this.notInOrderType = notInOrderType;
    }

    public String getCreationFromDate() {
        return creationFromDate;
    }

    public void setCreationFromDate(String creationFromDate) {
        this.creationFromDate = creationFromDate;
    }

    public String getCreationToDate() {
        return creationToDate;
    }

    public void setCreationToDate(String creationToDate) {
        this.creationToDate = creationToDate;
    }

    public String getUpdateFromDate() {
        return updateFromDate;
    }

    public void setUpdateFromDate(String updateFromDate) {
        this.updateFromDate = updateFromDate;
    }

    public String getUpdateToDate() {
        return updateToDate;
    }

    public void setUpdateToDate(String updateToDate) {
        this.updateToDate = updateToDate;
    }

    public List<String> getActionItemId() {
        return actionItemId;
    }

    public TracfoneonePaginationSearch getPaginationSearch() {
        return paginationSearch;
    }

    public void setPaginationSearch(TracfoneonePaginationSearch paginationSearch) {
        this.paginationSearch = paginationSearch;
    }

    public void setActionItemId(List<String> actionItemId) {
        this.actionItemId = actionItemId;
    }

    public List<String> getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(List<String> transactionId) {
        this.transactionId = transactionId;
    }

    public List<String> getOrderType() {
        return orderType;
    }

    public void setOrderType(List<String> orderType) {
        this.orderType = orderType;
    }

    public List<String> getEsn() {
        return esn;
    }

    public void setEsn(List<String> esn) {
        this.esn = esn;
    }

    public List<String> getStatus() {
        return status;
    }

    public void setStatus(List<String> status) {
        this.status = status;
    }

    public List<String> getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(List<String> statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getDbenv() {
        return dbenv;
    }

    public void setDbenv(String dbenv) {
        this.dbenv = dbenv;
    }

    public boolean isIsExactMatch() {
        return isExactMatch;
    }

    public void setIsExactMatch(boolean isExactMatch) {
        this.isExactMatch = isExactMatch;
    }

    public List<TracfoneOneSearchAdditionalModel> getAdditionalColumns() {
        return additionalColumns;
    }

    public void setAdditionalColumns(List<TracfoneOneSearchAdditionalModel> additionalColumns) {
        this.additionalColumns = additionalColumns;
    }

    public boolean isExactMatchForActionItemId() {
        return isExactMatchForActionItemId;
    }

    public void setExactMatchForActionItemId(boolean isExactMatchForActionItemId) {
        this.isExactMatchForActionItemId = isExactMatchForActionItemId;
    }

    public boolean isNotInStatusMessage() {
        return notInStatusMessage;
    }

    public void setNotInStatusMessage(boolean notInStatusMessage) {
        this.notInStatusMessage = notInStatusMessage;
    }

    public boolean isNotInActionItemId() {
        return notInActionItemId;
    }

    public void setNotInActionItemId(boolean notInActionItemId) {
        this.notInActionItemId = notInActionItemId;
    }

    public boolean isFromUserHistory() {
        return fromUserHistory;
    }

    public void setFromUserHistory(boolean fromUserHistory) {
        this.fromUserHistory = fromUserHistory;
    }

    public boolean isIsExactMatchForActionItemId() {
        return isExactMatchForActionItemId;
    }

    public void setIsExactMatchForActionItemId(boolean isExactMatchForActionItemId) {
        this.isExactMatchForActionItemId = isExactMatchForActionItemId;
    }

    public String getMatchParam() {
        return matchParam;
    }

    public void setMatchParam(String matchParam) {
        this.matchParam = matchParam;
    }

    public boolean isRegexExp() {
        return regexExp;
    }

    public void setRegexExp(boolean regexExp) {
        this.regexExp = regexExp;
    }

    public boolean isShowFailLogs() {
        return showFailLogs;
    }

    public void setShowFailLogs(boolean showFailLogs) {
        this.showFailLogs = showFailLogs;
    }
}
