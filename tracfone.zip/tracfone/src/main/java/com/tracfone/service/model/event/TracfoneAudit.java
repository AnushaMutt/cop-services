/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.event;

/**
 *
 * @author jflores
 */
public class TracfoneAudit {

    private Integer userId;
    private String action;
    private String details;
    private String carrierId;

    public TracfoneAudit(Integer userId, String action, String details, String carrierId) {
        this.userId = userId;
        this.action = action;
        this.details = details;
        this.carrierId = carrierId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(String carrierId) {
        this.carrierId = carrierId;
    }

    @Override
    public String toString() {
        return "TracfoneAudit{" + "userId=" + userId + ", action=" + action + ", details=" + details + ", carrierId=" + carrierId + '}';
    }

}
