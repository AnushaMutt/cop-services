package com.tracfone.service.model.response;

public class TFOneZipMktSubMkt {
    private String zipCode;
    private String city;
    private String county;
    private String state;
    private String billingSystem;
    private String market;
    private String marketDescription;
    private String subMarketSite;
    private String rateCenterServiceArea;
    private String rateCenterDescription;
    private String nbiLocalMarket;
    private String nbiMarketDescription;
    private String nbiSubMarket;
    private String nbiRateCenter;
    private String nbiRateCenterDescription;
    private String compassMarketCode;
    private String estoreId;
    private String addDate;
    private String updateDate;

    public TFOneZipMktSubMkt() {
    }

    public TFOneZipMktSubMkt(String zipCode, String city, String county, String state, String billingSystem, String market, String marketDescription, String subMarketSite, String rateCenterServiceArea, String rateCenterDescription, String nbiLocalMarket, String nbiMarketDescription, String nbiSubMarket, String nbiRateCenter, String nbiRateCenterDescription, String compassMarketCode, String estoreId, String addDate, String updateDate) {
        this.zipCode = zipCode;
        this.city = city;
        this.county = county;
        this.state = state;
        this.billingSystem = billingSystem;
        this.market = market;
        this.marketDescription = marketDescription;
        this.subMarketSite = subMarketSite;
        this.rateCenterServiceArea = rateCenterServiceArea;
        this.rateCenterDescription = rateCenterDescription;
        this.nbiLocalMarket = nbiLocalMarket;
        this.nbiMarketDescription = nbiMarketDescription;
        this.nbiSubMarket = nbiSubMarket;
        this.nbiRateCenter = nbiRateCenter;
        this.nbiRateCenterDescription = nbiRateCenterDescription;
        this.compassMarketCode = compassMarketCode;
        this.estoreId = estoreId;
        this.addDate = addDate;
        this.updateDate = updateDate;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getBillingSystem() {
        return billingSystem;
    }

    public void setBillingSystem(String billingSystem) {
        this.billingSystem = billingSystem;
    }

    public String getMarket() {
        return market;
    }

    public void setMarket(String market) {
        this.market = market;
    }

    public String getMarketDescription() {
        return marketDescription;
    }

    public void setMarketDescription(String marketDescription) {
        this.marketDescription = marketDescription;
    }

    public String getSubMarketSite() {
        return subMarketSite;
    }

    public void setSubMarketSite(String subMarketSite) {
        this.subMarketSite = subMarketSite;
    }

    public String getRateCenterServiceArea() {
        return rateCenterServiceArea;
    }

    public void setRateCenterServiceArea(String rateCenterServiceArea) {
        this.rateCenterServiceArea = rateCenterServiceArea;
    }

    public String getRateCenterDescription() {
        return rateCenterDescription;
    }

    public void setRateCenterDescription(String rateCenterDescription) {
        this.rateCenterDescription = rateCenterDescription;
    }

    public String getNbiLocalMarket() {
        return nbiLocalMarket;
    }

    public void setNbiLocalMarket(String nbiLocalMarket) {
        this.nbiLocalMarket = nbiLocalMarket;
    }

    public String getNbiMarketDescription() {
        return nbiMarketDescription;
    }

    public void setNbiMarketDescription(String nbiMarketDescription) {
        this.nbiMarketDescription = nbiMarketDescription;
    }

    public String getNbiSubMarket() {
        return nbiSubMarket;
    }

    public void setNbiSubMarket(String nbiSubMarket) {
        this.nbiSubMarket = nbiSubMarket;
    }

    public String getNbiRateCenter() {
        return nbiRateCenter;
    }

    public void setNbiRateCenter(String nbiRateCenter) {
        this.nbiRateCenter = nbiRateCenter;
    }

    public String getNbiRateCenterDescription() {
        return nbiRateCenterDescription;
    }

    public void setNbiRateCenterDescription(String nbiRateCenterDescription) {
        this.nbiRateCenterDescription = nbiRateCenterDescription;
    }

    public String getCompassMarketCode() {
        return compassMarketCode;
    }

    public void setCompassMarketCode(String compassMarketCode) {
        this.compassMarketCode = compassMarketCode;
    }

    public String getEstoreId() {
        return estoreId;
    }

    public void setEstoreId(String estoreId) {
        this.estoreId = estoreId;
    }

    public String getAddDate() {
        return addDate;
    }

    public void setAddDate(String addDate) {
        this.addDate = addDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    @Override
    public String toString() {
        return "TFOneZipMktSubMkt{" +
                "zipCode='" + zipCode + '\'' +
                ", city='" + city + '\'' +
                ", county='" + county + '\'' +
                ", state='" + state + '\'' +
                ", billingSystem='" + billingSystem + '\'' +
                ", market='" + market + '\'' +
                ", marketDescription='" + marketDescription + '\'' +
                ", subMarketSite='" + subMarketSite + '\'' +
                ", rateCenterServiceArea='" + rateCenterServiceArea + '\'' +
                ", rateCenterDescription='" + rateCenterDescription + '\'' +
                ", nbiLocalMarket='" + nbiLocalMarket + '\'' +
                ", nbiMarketDescription='" + nbiMarketDescription + '\'' +
                ", nbiSubMarket='" + nbiSubMarket + '\'' +
                ", nbiRateCenter='" + nbiRateCenter + '\'' +
                ", nbiRateCenterDescription='" + nbiRateCenterDescription + '\'' +
                ", compassMarketCode='" + compassMarketCode + '\'' +
                ", estoreId='" + estoreId + '\'' +
                ", addDate='" + addDate + '\'' +
                ", updateDate='" + updateDate + '\'' +
                '}';
    }
}
