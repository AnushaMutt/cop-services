/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.exception;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author user
 */
public class TracfoneOneException extends Exception {

    private String errorCode;
    private String errorMessage;
    private int httpCode;

    public TracfoneOneException(String errorCode, String errorMessage, int httpCode) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.httpCode = httpCode;
    }
        
    public TracfoneOneException(String errorCode, String errorMessage) {

        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }
    
    public TracfoneOneException(String errorCode, String errorMessage, Exception exception) {

        super(exception);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
    
    public String getClientErrorMessage(){        
        long threadId = Thread.currentThread().getId();
        return this.getErrorCode() + "-" + threadId + " - " + this.getErrorMessage();
    }
    
    public int getHttpCode() {
        return httpCode;
    }

    public void setHttpCode(int httpCode) {
        this.httpCode = httpCode;
    }
    
    public Map<String, String> getToasterErrorMessage() { 
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("ERR", getErrorCode() + "-" + getErrorMessage());
        return errorMap;
    }
}