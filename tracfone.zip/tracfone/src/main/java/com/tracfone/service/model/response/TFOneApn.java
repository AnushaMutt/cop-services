/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.response;

/**
 *
 * @author Shireen Fathima
 */
public class TFOneApn {
    private String xParentName;
    private String ratePlan;
    private String orgId;
    private String apn;
    private String username;
    private String password;
    private String authType;
    private String proxyAddress;
    private String proxyPort;
    private String connectionType;
    private String mmsApn;
    private String mmsUsername;
    private String mmsPassword;
    private String mmsAuthType;
    private String mmsc;
    private String mmsProxyAddress;
    private String mmsProxyPort;
    private String mmsApnType;
    private String rtspProxyAddr;
    private String rtspProxyPort;

    public String getxParentName() {
        return xParentName;
    }

    public void setxParentName(String xParentName) {
        this.xParentName = xParentName;
    }

    public String getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(String ratePlan) {
        this.ratePlan = ratePlan;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getApn() {
        return apn;
    }

    public void setApn(String apn) {
        this.apn = apn;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAuthType() {
        return authType;
    }

    public void setAuthType(String authType) {
        this.authType = authType;
    }

    public String getProxyAddress() {
        return proxyAddress;
    }

    public void setProxyAddress(String proxyAddress) {
        this.proxyAddress = proxyAddress;
    }

    public String getProxyPort() {
        return proxyPort;
    }

    public void setProxyPort(String proxyPort) {
        this.proxyPort = proxyPort;
    }

    public String getConnectionType() {
        return connectionType;
    }

    public void setConnectionType(String connectionType) {
        this.connectionType = connectionType;
    }

    public String getMmsApn() {
        return mmsApn;
    }

    public void setMmsApn(String mmsApn) {
        this.mmsApn = mmsApn;
    }

    public String getMmsUsername() {
        return mmsUsername;
    }

    public void setMmsUsername(String mmsUsername) {
        this.mmsUsername = mmsUsername;
    }

    public String getMmsPassword() {
        return mmsPassword;
    }

    public void setMmsPassword(String mmsPassword) {
        this.mmsPassword = mmsPassword;
    }

    public String getMmsAuthType() {
        return mmsAuthType;
    }

    public void setMmsAuthType(String mmsAuthType) {
        this.mmsAuthType = mmsAuthType;
    }

    public String getMmsc() {
        return mmsc;
    }

    public void setMmsc(String mmsc) {
        this.mmsc = mmsc;
    }

    public String getMmsProxyAddress() {
        return mmsProxyAddress;
    }

    public void setMmsProxyAddress(String mmsProxyAddress) {
        this.mmsProxyAddress = mmsProxyAddress;
    }

    public String getMmsProxyPort() {
        return mmsProxyPort;
    }

    public void setMmsProxyPort(String mmsProxyPort) {
        this.mmsProxyPort = mmsProxyPort;
    }

    public String getMmsApnType() {
        return mmsApnType;
    }

    public void setMmsApnType(String mmsApnType) {
        this.mmsApnType = mmsApnType;
    }

    public String getRtspProxyAddr() {
        return rtspProxyAddr;
    }

    public void setRtspProxyAddr(String rtspProxyAddr) {
        this.rtspProxyAddr = rtspProxyAddr;
    }

    public String getRtspProxyPort() {
        return rtspProxyPort;
    }

    public void setRtspProxyPort(String rtspProxyPort) {
        this.rtspProxyPort = rtspProxyPort;
    }

    @Override
    public String toString() {
        return "TFOneApn{" + "xParentName=" + xParentName + ", "
                + "ratePlan=" + ratePlan + ", "
                + "orgId=" + orgId + ", "
                + "apn=" + apn + ", "
                + "username=" + username + ", "
                + "password=" + password + ", "
                + "authType=" + authType + ", "
                + "proxyAddress=" + proxyAddress + ", "
                + "proxyPort=" + proxyPort + ", "
                + "connectionType=" + connectionType + ", "
                + "mmsApn=" + mmsApn + ", "
                + "mmsUsername=" + mmsUsername + ", "
                + "mmsPassword=" + mmsPassword + ", "
                + "mmsAuthType=" + mmsAuthType + ", "
                + "mmsc=" + mmsc + ", "
                + "mmsProxyAddress=" + mmsProxyAddress + ", "
                + "mmsProxyPort=" + mmsProxyPort + ", "
                + "mmsApnType=" + mmsApnType + ", "
                + "rtspProxyAddr=" + rtspProxyAddr + ", "
                + "rtspProxyPort=" + rtspProxyPort + '}';
    }
}
