/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service;

import javax.ws.rs.core.Application;
import java.util.Set;

/**
 * @author Srinivas Murthy Pulavarthy
 */
@javax.ws.rs.ApplicationPath("")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }

    /**
     * Do not modify addRestResourceClasses() method.
     * It is automatically populated with
     * all resources defined in the project.
     * If required, comment out calling this method in getClasses().
     */
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(com.tracfone.service.TracfoneOneActionResource.class);
        resources.add(com.tracfone.service.TracfoneOneCarrierOutageResource.class);
        resources.add(com.tracfone.service.TracfoneOneCarrierWizardResource.class);
        resources.add(com.tracfone.service.TracfoneOneCarrierZonesDeploymentResource.class);
        resources.add(com.tracfone.service.TracfoneOneDB2IntergateResource.class);
        resources.add(com.tracfone.service.TracfoneOneDB2IntergateViewResource.class);
        resources.add(com.tracfone.service.TracfoneOneGeoCoderResource.class);
        resources.add(com.tracfone.service.TracfoneOneIGCarrierConfigResource.class);
        resources.add(com.tracfone.service.TracfoneOneIGCarrierConfigViewResource.class);
        resources.add(com.tracfone.service.TracfoneOneIgCarrierNotificationResource.class);
        resources.add(com.tracfone.service.TracfoneOneIgFailLogResource.class);
        resources.add(com.tracfone.service.TracfoneOneMirrorServicePlanResource.class);
        resources.add(com.tracfone.service.TracfoneOnePCRFTransResource.class);
        resources.add(com.tracfone.service.TracfoneOneReportingResource.class);
        resources.add(com.tracfone.service.TracfoneOneResource.class);
        resources.add(com.tracfone.service.TracfoneOneRetailStoreAdminResource.class);
        resources.add(com.tracfone.service.TracfoneOneRetailTraitAnalysisResource.class);
        resources.add(com.tracfone.service.TracfoneOneServiceRatePlanWizardResource.class);
        resources.add(com.tracfone.service.TracfoneOneThrottleTransResource.class);
        resources.add(com.tracfone.service.TracfoneOneTransactionWizardResource.class);
        resources.add(com.tracfone.service.TracfoneOneUserInquiryResource.class);
        resources.add(com.tracfone.service.TracfoneOneUserReportingResource.class);
        resources.add(com.tracfone.service.TracfoneOneViewServicePlanResource.class);
        resources.add(com.tracfone.service.TracfoneOneZip2TechResource.class);
        resources.add(com.tracfone.service.exception.TracfoneOneValidationExceptionMapper.class);
        resources.add(com.tracfone.service.filter.AuthenticationFilter.class);
        resources.add(com.tracfone.service.filter.AuthorizationFilter.class);
    }
}