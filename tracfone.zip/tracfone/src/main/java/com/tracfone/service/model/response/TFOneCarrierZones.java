package com.tracfone.service.model.response;

import java.math.BigDecimal;

/**
 *
 * @author Gaurav.Sharma
 */
public class TFOneCarrierZones {

    private String zipCode;
    private String state;
    private String county;
    private String zone;
    private String rateCente;
    private String marketId;
    private String marketArea;
    private String city;
    private String btaMarketNumber;
    private String btaMarketName;
    private String carrierId;
    private String carrierName;
    private String zipStatus;
    private String simProfile;
    private String simProfile2;
    private String planType;

    public TFOneCarrierZones() {
    }

    public TFOneCarrierZones(String zipCode, String state, String county, BigDecimal marketId, String marketArea, String city, BigDecimal btaMarketNumber, String btaMarketName) {
        this.zipCode = zipCode;
        this.state = state;
        this.county = county;
        this.marketId = String.valueOf(marketId);
        this.marketArea = marketArea;
        this.city = city;
        this.btaMarketNumber = String.valueOf(btaMarketNumber);
        this.btaMarketName = btaMarketName;
    }

    public TFOneCarrierZones(String zipCode) {
        this.zipCode = zipCode;
    }
    
    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public String getRateCente() {
        return rateCente;
    }

    public void setRateCente(String rateCente) {
        this.rateCente = rateCente;
    }

    public String getMarketId() {
        return marketId;
    }

    public void setMarketId(String marketId) {
        this.marketId = marketId;
    }

    public String getMarketArea() {
        return marketArea;
    }

    public void setMarketArea(String marketArea) {
        this.marketArea = marketArea;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getBtaMarketNumber() {
        return btaMarketNumber;
    }

    public void setBtaMarketNumber(String btaMarketNumber) {
        this.btaMarketNumber = btaMarketNumber;
    }

    public String getBtaMarketName() {
        return btaMarketName;
    }

    public void setBtaMarketName(String btaMarketName) {
        this.btaMarketName = btaMarketName;
    }

    public String getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(String carrierId) {
        this.carrierId = carrierId;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getZipStatus() {
        return zipStatus;
    }

    public void setZipStatus(String zipStatus) {
        this.zipStatus = zipStatus;
    }

    public String getSimProfile() {
        return simProfile;
    }

    public void setSimProfile(String simProfile) {
        this.simProfile = simProfile;
    }

    public String getSimProfile2() {
        return simProfile2;
    }

    public void setSimProfile2(String simProfile2) {
        this.simProfile2 = simProfile2;
    }

    public String getPlanType() {
        return planType;
    }

    public void setPlanType(String planType) {
        this.planType = planType;
    }

    @Override
    public String toString() {
        return "TFOneCarrierZones{" + "zipCode=" + zipCode + ", state=" + state + ", county=" + county + ", zone=" + zone + ", rateCente=" + rateCente + ", marketId=" + marketId + ", marketArea=" + marketArea + ", city=" + city + ", btaMarketNumber=" + btaMarketNumber + ", btaMarketName=" + btaMarketName + ", carrierId=" + carrierId + ", carrierName=" + carrierName + ", zipStatus=" + zipStatus + ", simProfile=" + simProfile + ", simProfile2=" + simProfile2 + ", planType=" + planType + '}';
    }
}
