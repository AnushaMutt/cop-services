package com.tracfone.service.model.request;

/**
 * @author Pritesh.Singh
 */
public class TracfoneOneColumnDesc {
    private String dbEnv;
    private String owner;
    private String tableName;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    @Override
    public String toString() {
        return "TracfoneOneColumnDesc{" +
                "dbEnv='" + dbEnv + '\'' +
                ", owner='" + owner + '\'' +
                ", tableName='" + tableName + '\'' +
                '}';
    }
}
