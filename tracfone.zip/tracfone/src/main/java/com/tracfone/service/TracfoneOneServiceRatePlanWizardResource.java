/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneBucketControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.controller.TracfoneFeatureControllerLocal;
import com.tracfone.service.controller.TracfoneProfileControllerLocal;
import com.tracfone.service.controller.TracfoneRatePlanControllerLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneAncillaryCode;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeConfig;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeDiscount;
import com.tracfone.service.model.request.TracfoneOneApn;
import com.tracfone.service.model.request.TracfoneOneBucket;
import com.tracfone.service.model.request.TracfoneOneBucketList;
import com.tracfone.service.model.request.TracfoneOneCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucketTier;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildTier;
import com.tracfone.service.model.request.TracfoneOneChildPlan;
import com.tracfone.service.model.request.TracfoneOneFeatureRequirement;
import com.tracfone.service.model.request.TracfoneOneLineStatusCode;
import com.tracfone.service.model.request.TracfoneOneMultiRatePlanEsn;
import com.tracfone.service.model.request.TracfoneOneRatePlan;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtension;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionConfig;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionLink;
import com.tracfone.service.model.request.TracfoneOneRatePlanProfile;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.request.TracfoneOneSearchCarrierFeatureModel;
import com.tracfone.service.model.request.TracfoneOneSearchPlanModel;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneThrottleStatusCode;
import com.tracfone.service.model.request.TracfoneOneUploadProfileFeatures;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneAncillaryCode;
import com.tracfone.service.model.response.TFOneAncillaryCodeConfig;
import com.tracfone.service.model.response.TFOneAncillaryCodeDiscount;
import com.tracfone.service.model.response.TFOneApn;
import com.tracfone.service.model.response.TFOneBucket;
import com.tracfone.service.model.response.TFOneBucketList;
import com.tracfone.service.model.response.TFOneBulkInsertReport;
import com.tracfone.service.model.response.TFOneBusinessOrganization;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneFeatureRequirement;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneLineStatusCode;
import com.tracfone.service.model.response.TFOneMultiRatePlanEsn;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOneRPFeatureNameList;
import com.tracfone.service.model.response.TFOneRatePlan;
import com.tracfone.service.model.response.TFOneRatePlanExtension;
import com.tracfone.service.model.response.TFOneRatePlanExtensionConfig;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import com.tracfone.service.model.response.TFOneThrottleStatusCode;
import com.tracfone.service.model.response.TFOneUploadProfileFeatures;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.validation.Valid;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * This resource file is going to be used for all services in the Service Plan
 * and Rate Plan Management Wizard
 *
 * @author Shireen Fathima
 * @author Shireen Fathima
 */
@Path("rateplan")
public class TracfoneOneServiceRatePlanWizardResource {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneServiceRatePlanWizardResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @Context
    private SecurityContext securityContext;

    @EJB
    private TracfoneBucketControllerLocal tracfoneBucketController;

    @EJB
    private TracfoneFeatureControllerLocal tracfoneFeatureController;

    @EJB
    private TracfoneProfileControllerLocal tracfoneProfileController;

    @EJB
    private TracfoneRatePlanControllerLocal tracfoneRatePlanController;

    @EJB
    private TracfoneControllerLocalAction tracfoneControllerAction;

    /**
     * This method is used to retrieve all carriers available in
     * table_x_carrier_features
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewcarriers")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllCarrierNames(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<String> carrierNames = new ArrayList<>();
        try {
            carrierNames = tracfoneRatePlanController.getAllCarrierNames(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierNames), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a new rate plan to the master table
     *
     * @param tfRatePlan
     * @return
     */
    @POST
    @Path("rateplanmaintenance/addrateplan")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertRatePlan(@Valid final TracfoneOneRatePlan tfRatePlan) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneRatePlanController.insertRatePlan(tfRatePlan,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a new apn into x_apn table
     *
     * @param tfOneApn
     * @return
     */
    @POST
    @Path("rateplanmaintenance/addapn")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertApn(@Valid final TracfoneOneApn tfOneApn) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneRatePlanController.insertApn(tfOneApn,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update the rate plan
     *
     * @param tfRatePlan
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updaterateplan")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateRatePlan(@Valid final TracfoneOneRatePlan tfRatePlan) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneRatePlanController.updateRatePlan(tfRatePlan,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update the apn
     *
     * @param tfOneApn
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updateapn")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateApn(@Valid final TracfoneOneApn tfOneApn) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneRatePlanController.updateApn(tfOneApn,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete the rate plan and it's children - x_apn,
     * ig_buckets, table_x_carrier_features, mtm_sp_carrierfeatures,
     * x_rp_profile, x_rp_extension_config, x_rp_extension_link
     *
     * @param tfRatePlan
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deleterateplan")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteRatePlan(final TracfoneOneRatePlan tfRatePlan) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneRatePlanController.deleteRatePlan(tfRatePlan,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete the APN based on columns - rate plan, apn
     * and org id
     *
     * @param tfOneApn
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deleteapn")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteApn(final TracfoneOneApn tfOneApn) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneRatePlanController.deleteApn(tfOneApn,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all rate plan names from the master table
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewmasterrateplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getMasterRatePlans(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneRatePlan> allRatePlans = new ArrayList<>();
        try {
            allRatePlans = tracfoneRatePlanController.getMasterRatePlans(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(allRatePlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all service plans based on the selected
     * carrier
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewserviceplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getServicePlansForCarrier(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneCarrierServicePlan> carrierServicePlans = new ArrayList<>();
        try {
            carrierServicePlans = tracfoneRatePlanController.getServicePlansForCarrier(tracfoneOneSearchPlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierServicePlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all business orgs for a drop down
     * required when adding carrier features
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewbusorgs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllBusinessOrgs(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneBusinessOrganization> allBusOrgs = new ArrayList<>();
        try {
            allBusOrgs = tracfoneRatePlanController.getAllBusinessOrgs(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(allBusOrgs), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all APNS for a particular rate plan
     *
     * @param tracfoneOneApn
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewrateplanapns")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllRatePlanApns(TracfoneOneApn tracfoneOneApn) {
        List<TFOneApn> ratePlanApns = new ArrayList<>();
        try {
            ratePlanApns = tracfoneRatePlanController.getAllRatePlanApns(tracfoneOneApn);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(ratePlanApns), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all rate plans that are not associated to
     * any service plans based on any column of the x_rate table.
     *
     * @param tracfoneOneRatePlan
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchunlinkedrateplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchRatePlansForUpdate(TracfoneOneRatePlan tracfoneOneRatePlan) {
        List<TFOneRatePlan> tfOneRatePlans = new ArrayList<>();
        try {
            tfOneRatePlans = tracfoneRatePlanController.searchRatePlansForUpdate(tracfoneOneRatePlan);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneRatePlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all parent names for the drop down in add
     * apn screen based on the carrier selected in Step 1
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewparentnames")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllParentNames(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneParent> allParents = new ArrayList<>();
        try {
            allParents = tracfoneRatePlanController.getAllParentNames(tracfoneOneSearchPlanModel.getDbEnv(),
                    tracfoneOneSearchPlanModel.getCarrierName());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(allParents), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a new rate plan profile for a new rate plan.
     * It does two things. Create a new rate plan profile. Associate the profile
     * to the rate plan
     *
     * @param tfRatePlanProfile
     * @return
     */
    @POST
    @Path("rateplanmaintenance/addprofile")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertProfile(@Valid final TracfoneOneRatePlanProfile tfRatePlanProfile) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.insertProfile(tfRatePlanProfile,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to wild card search for profiles that match any
     * profile id or profile description entered by the user
     *
     * @param tfRatePlanProfile
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchprofile")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchProfile(final TracfoneOneSearchProfileModel tfRatePlanProfile) {
        List<TFOneRatePlanProfile> tfOneRatePlanProfiles = null;
        try {
            tfOneRatePlanProfiles = tracfoneProfileController.searchProfile(tfRatePlanProfile);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneRatePlanProfiles), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update the profile description
     *
     * @param tfRatePlanProfile
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updateprofile")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateProfile(@Valid final TracfoneOneRatePlanProfile tfRatePlanProfile) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.updateProfile(tfRatePlanProfile,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete the profile and it's children -
     * rp_extension_link and rp_extension_config
     *
     * @param tfRatePlanProfile
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deleteprofile")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteProfile(final TracfoneOneRatePlanProfile tfRatePlanProfile) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.deleteProfile(tfRatePlanProfile,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve the ancillary codes from the master table
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewancillarycodes")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllAncillaryCodes(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneAncillaryCode> allAncillaryCodes = new ArrayList<>();
        try {
            allAncillaryCodes = tracfoneProfileController.getAllAncillaryCodes(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(allAncillaryCodes), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all matching ancillary codes based on code and description
     *
     * @param ancillaryCode
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchancillarycodes")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchAncillaryCodes(TracfoneOneAncillaryCode ancillaryCode) {
        List<TFOneAncillaryCode> allAncillaryCodes = new ArrayList<>();
        try {
            allAncillaryCodes = tracfoneProfileController.searchAncillaryCodes(ancillaryCode);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(allAncillaryCodes), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete  x_rp_ancillary_code
     * Validate whether that code is used in x_rp_extension table.
     * If it is used, throw an error. Else delete it and show success message
     *
     * @param ancillaryCode
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deleteancillarycode")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteAncillaryCode(TracfoneOneAncillaryCode ancillaryCode) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneProfileController.deleteAncillaryCode(ancillaryCode,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a new x_rp_ancillary_code
     *
     * @param ancillaryCode
     * @return
     */
    @POST
    @Path("rateplanmaintenance/addancillarycode")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertAncillaryCode(@Valid TracfoneOneAncillaryCode ancillaryCode) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneProfileController.insertAncillaryCode(ancillaryCode,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update the description of a x_rp_ancillary_code
     *
     * @param ancillaryCode
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updateancillarycode")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateAncillaryCode(@Valid TracfoneOneAncillaryCode ancillaryCode) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneProfileController.updateAncillaryCode(ancillaryCode,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search is for profiles in x_rp_profile
     * table based on columns in x_rp_profile and x_rp_extension_config tables.
     * based on - profile id, feature name, feature value, profile desc
     *
     * @param tracfoneOneSearchProfileModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchunlinkedprofiles")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchProfilesForUpdate(final TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) {
        List<TFOneRatePlanProfile> ratePlanProfiles = null;
        try {
            ratePlanProfiles = tracfoneProfileController.searchProfilesForUpdate(tracfoneOneSearchProfileModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(ratePlanProfiles), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update the carrier feature
     *
     * @param tfCarrierFeature
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updatecarrierfeature")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrierFeature(@Valid final TracfoneOneCarrierFeature tfCarrierFeature) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneRatePlanController.updateCarrierFeature(tfCarrierFeature,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for carrier features
     *
     * @param tfCarrierFeatureModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchcarrierfeatures")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierFeatures(final TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) {
        List<TFOneCarrierFeature> carrierFeatures = null;
        try {
            carrierFeatures = tracfoneRatePlanController.searchCarrierFeatures(tfCarrierFeatureModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierFeatures), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieve the list of feature from master
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewallmasterfeatures")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllMasterFeatures(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneRPFeatureNameList> features = null;

        try {
            features = tracfoneFeatureController.getAllMasterFeatures(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(features), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieve the list of features from rp_extension Config on basis of
     * profile ids
     *
     * @param tracfoneOneSearchProfileModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewallprofilesfeatures")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllProfileFeatures(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) {
        List<TFOneRatePlanProfile> profileFeatures = new ArrayList<>();

        try {
            profileFeatures = tracfoneFeatureController.getAllProfileFeatures(tracfoneOneSearchProfileModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(profileFeatures), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a new feature for a new profile id and update
     * in sa.x_rp_extension_config table
     *
     * @param tfOneRpExtensionConfigs
     * @return
     */
    @POST
    @Path("rateplanmaintenance/addrpextensionconfig")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertRpExtensionConfig(@Valid final List<TracfoneOneRatePlanExtensionConfig> tfOneRpExtensionConfigs) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneFeatureController.insertRpExtensionConfig(tfOneRpExtensionConfigs,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update sa.x_rp_extension_config table
     *
     * @param tfOneRpExtensionConfig
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updaterpextensionconfig")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateRpExtensionConfig(@Valid final TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneFeatureController.updateRpExtensionConfig(tfOneRpExtensionConfig,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete sa.x_rp_extension_config table
     *
     * @param tfOneRpExtensionConfig
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deleterpextensionconfig")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteRpExtensionConfig(final TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneFeatureController.deleteRpExtensionConfig(tfOneRpExtensionConfig,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a new bucket in ig bucket table. Create a new
     * bucket.
     *
     * @param tfBuckets
     * @return
     */
    @POST
    @Path("rateplanmaintenance/{parentshortname}/addlegacybucket")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertLegacyBucket(@Valid final List<TracfoneOneBucket> tfBuckets,
                                       @PathParam("parentshortname") String parentShortName) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneBucketController.insertLegacyBucket(tfBuckets, parentShortName,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update the IG bucket details
     *
     * @param tfOneIgBucket
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updateigbucket")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateIgBucket(@Valid final TracfoneOneBucket tfOneIgBucket) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneBucketController.updateIgBucket(tfOneIgBucket,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete the an IG Bucket object
     *
     * @param tfBucket
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deleteigbucket")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteIgBucket(final TracfoneOneBucket tfBucket) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneBucketController.deleteIgBucket(tfBucket,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for IG_Buckets based on rate plan
     *
     * @param tfOneSearchBucketModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchigbuckets")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchIgBuckets(final TracfoneOneSearchBucketModel tfOneSearchBucketModel) {
        List<TFOneBucket> tfOneBuckets = new ArrayList<>();
        try {
            tfOneBuckets = tracfoneBucketController.searchIgBuckets(tfOneSearchBucketModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneBuckets), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all rate plans in ig_bucket table
     *
     * @param tfOneSearchBucketModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewigbucketrateplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getIgBucketRatePlans(final TracfoneOneSearchBucketModel tfOneSearchBucketModel) {
        List<TFOneRatePlan> tfOneRatePlans = new ArrayList<>();
        try {
            tfOneRatePlans = tracfoneBucketController.getIgBucketRatePlans(tfOneSearchBucketModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneRatePlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all the objects from the bucket master
     * table BUCKET_LIST
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewallbucketlist")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllBucketList(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TracfoneOneBucketList> tracfoneOneBucketLists = null;
        try {
            tracfoneOneBucketLists = tracfoneBucketController.getAllBucketList(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tracfoneOneBucketLists), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all the child plans from master table
     * child_identifier_list
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewchildplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllChildPlans(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneChildPlan> childPlans = new ArrayList<>();
        try {
            childPlans = tracfoneProfileController.getAllChildPlans(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(childPlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update the CHILD_IDENTIFIER_LIST based on ChildId
     *
     * @param tfOneChildIdentifierList
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updatechildplan")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateChildPlan(@Valid TracfoneOneChildPlan tfOneChildIdentifierList) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.updateChildPlan(tfOneChildIdentifierList, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert into CHILD_IDENTIFIER_LIST
     *
     * @param tfOneChildIdentifierList
     * @return
     */
    @POST
    @Path("rateplanmaintenance/addchildplan")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertChildPlan(@Valid TracfoneOneChildPlan tfOneChildIdentifierList) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.insertChildPlan(tfOneChildIdentifierList, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete the CHILD_IDENTIFIER_LIST based on ChildId
     *
     * @param tfOneChildIdentifierList
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deletechildplan")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteChildPlan(TracfoneOneChildPlan tfOneChildIdentifierList) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.deleteChildPlan(tfOneChildIdentifierList, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieve the list of RP Extension Links on basis of Carrier Feature ObjId
     *
     * @param selectedCarrierFeatures
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewcarrierfeaturelinks")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierFeatureLinks(final List<TracfoneOneCarrierFeature> selectedCarrierFeatures) {
        List<TFOneCarrierFeature> carrierFeatures = new ArrayList<>();
        try {
            carrierFeatures = tracfoneRatePlanController.getCarrierFeatureLinks(selectedCarrierFeatures);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierFeatures), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to wild card search for X_RP_EXTENSION that match any
     * column entered by the user
     *
     * @param tfRatePlanExtension
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchrpextensions")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchRpExtensions(final TracfoneOneRatePlanExtension tfRatePlanExtension) {
        List<TFOneRatePlanExtension> tfRatePlanExtensions = null;
        try {
            tfRatePlanExtensions = tracfoneProfileController.searchRpExtensions(tfRatePlanExtension);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfRatePlanExtensions), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert into X_RP_EXTENSION
     *
     * @param tfRpExtension
     * @return
     */
    @POST
    @Path("rateplanmaintenance/addrpextension")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertRpExtension(@Valid TracfoneOneRatePlanExtension tfRpExtension) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.insertRpExtension(tfRpExtension, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete the X_RP_EXTENSION based on objId
     *
     * @param tfRpExtension
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deleterpextension")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteRpExtension(TracfoneOneRatePlanExtension tfRpExtension) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.deleteRpExtension(tfRpExtension, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for Carrier_Profile_Buckets based on service plan and profile
     *
     * @param tfOneSearchBucketModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchcpbuckets")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierProfileBuckets(final TracfoneOneSearchBucketModel tfOneSearchBucketModel) {
        List<TFOneCarrierProfileBucket> tfOneBuckets = new ArrayList<>();
        try {
            tfOneBuckets = tracfoneBucketController.searchCarrierProfileBuckets(tfOneSearchBucketModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneBuckets), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for Carrier_Profile_Child_Buckets based on
     * service plan, profile and child plan
     *
     * @param tfOneSearchBucketModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchcpchildbuckets")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierProfileChildBuckets(final TracfoneOneSearchBucketModel tfOneSearchBucketModel) {
        List<TFOneCarrierProfileChildBucket> tfOneBuckets = new ArrayList<>();
        try {
            tfOneBuckets = tracfoneBucketController.searchCarrierProfileChildBuckets(tfOneSearchBucketModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneBuckets), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to validate and insert a file upload for Profile features into
     * x_rp_extension_config table
     *
     * @param tfOneUploadProfileFeatures
     * @return
     */
    @POST
    @Path("rateplanmaintenance/validateaddprofilefeatures")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response validateAndAddProfileFeatures(@Valid final TracfoneOneUploadProfileFeatures tfOneUploadProfileFeatures) {
        TFOneUploadProfileFeatures tFOneUploadProfileFeatures = null;
        try {
            tFOneUploadProfileFeatures = tracfoneFeatureController.validateAndAddProfileFeatures(tfOneUploadProfileFeatures,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tFOneUploadProfileFeatures), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert rate plan associations - into
     * table_x_carrier_features, mtm_sp_carrierfeatures, x_rp_extension_link,
     * carrier_profile_bucket, carrier_profile_bucket_tier,
     * carrier_profile_child_bucket, carrier_profile_child_tier
     *
     * @param tracfoneOneCarrierFeature
     * @param carrierId
     * @param servicePlanId
     * @param ratePlanName
     * @return
     */
    @POST
    @Path("rateplanmaintenance/{carrier}/{serviceplanid}/{rateplan}/addrateplanassociation")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertRatePlanAssociation(@Valid TracfoneOneCarrierFeature tracfoneOneCarrierFeature,
                                              @PathParam("carrier") final String carrierId,
                                              @PathParam("serviceplanid") final String servicePlanId,
                                              @PathParam("rateplan") final String ratePlanName) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneRatePlanController.insertRatePlanAssociation(tracfoneOneCarrierFeature,
                    carrierId,
                    servicePlanId,
                    ratePlanName,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for carrier features for update
     *
     * @param tfCarrierFeatureModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchcarrierfeaturesforupdate")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchCarrierFeaturesForUpdate(final TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) {
        List<TFOneCarrierFeature> carrierFeatures = null;
        try {
            carrierFeatures = tracfoneRatePlanController.searchCarrierFeaturesForUpdate(tfCarrierFeatureModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carrierFeatures), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert into x_rp_extension_link table
     *
     * @param tfRpExtensionLink
     * @return
     */
    @POST
    @Path("rateplanmaintenance/addrpextensionlink")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertRpExtensionLink(final @Valid TracfoneOneRatePlanExtensionLink tfRpExtensionLink) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.insertRpExtensionLink(tfRpExtensionLink, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete sa.x_rp_extension_link based on objId
     *
     * @param tfOneRpExtensionLink
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deleterpextensionlink")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteRpExtensionLink(final TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.deleteRpExtensionLink(tfOneRpExtensionLink,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete sa.x_rp_extension_link based on objId
     *
     * @param tfOneRpExtensionLink
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deleteallrpextensionlinks")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteAllRpExtensionLink(final TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.deleteRpExtensionLink(tfOneRpExtensionLink,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update sa.x_rp_extension_link based on objId
     *
     * @param tfOneRpExtensionLink
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updaterpextensionlink")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateRpExtensionLink(@Valid final TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.updateRpExtensionLink(tfOneRpExtensionLink,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add into CARRIER_PROFILE_BUCKETS table
     *
     * @param tfCarrierProfileBuckets
     * @return
     */
    @POST
    @Path("rateplanmaintenance/{parentshortname}/addcpbucket")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarrierProfileBucket(@Valid final List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets,
                                               @PathParam("parentshortname") String parentShortName) {
        List<TFOneCarrierProfileBucket> tfOneBuckets = new ArrayList<>();
        try {
            tfOneBuckets = tracfoneBucketController.insertCarrierProfileBucket(tfCarrierProfileBuckets,
                    parentShortName,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneBuckets), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update the carrier profile bucket details
     *
     * @param tfCarrierProfileBucket
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updatecpbucket")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrierProfileBucket(@Valid final TracfoneOneCarrierProfileBucket tfCarrierProfileBucket) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneBucketController.updateCarrierProfileBucket(tfCarrierProfileBucket,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete the carrier profile  bucket
     * CARRIER_PROFILE_BUCKETS
     *
     * @param tfCarrierProfileBuckets
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deletecpbucket")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteCarrierProfileBucket(final List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneBucketController.deleteCarrierProfileBucket(tfCarrierProfileBuckets,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update the carrier profile bucket Tier details
     *
     * @param tfCarrierProfileBucketTier
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updatecpbuckettier")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrierProfileBucketTier(@Valid final TracfoneOneCarrierProfileBucketTier tfCarrierProfileBucketTier) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneBucketController.updateCarrierProfileBucketTier(tfCarrierProfileBucketTier,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }


    /**
     * This method is used to delete the carrier profile  bucket tier
     * CARRIER_PROFILE_BUCKET_TIER
     *
     * @param tfCarrierProfileBucketTier
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deletecpbuckettier")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteCarrierProfileBucketTier(final TracfoneOneCarrierProfileBucketTier tfCarrierProfileBucketTier) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneBucketController.deleteCarrierProfileBucketTier(tfCarrierProfileBucketTier,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add into CARRIER_PROFILE_CHILD_BUCKETS table
     *
     * @param tfCarrierProfileChildBuckets
     * @return
     */
    @POST
    @Path("rateplanmaintenance/{parentshortname}/addcpchildbucket")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertCarrierProfileChildBucket(@Valid final List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets,
                                                    @PathParam("parentshortname") String parentShortName) {
        List<TFOneCarrierProfileChildBucket> tfOneChildBuckets = new ArrayList<>();
        try {
            tfOneChildBuckets = tracfoneBucketController.insertCarrierProfileChildBucket(tfCarrierProfileChildBuckets,
                    parentShortName,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneChildBuckets), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update the carrier profile child bucket details
     *
     * @param tfCarrierProfileChildBucket
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updatecpchildbucket")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrierProfileChildBucket(@Valid final TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneBucketController.updateCarrierProfileChildBucket(tfCarrierProfileChildBucket,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete the carrier profile child bucket
     * CARRIER_PROFILE_CHILD_BUCKETS
     *
     * @param tfCarrierProfileChildBuckets
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deletecpchildbucket")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteCarrierProfileChildBucket(final List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneBucketController.deleteCarrierProfileChildBucket(tfCarrierProfileChildBuckets,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update the carrier profile child bucket tier
     *
     * @param tfCarrierProfileChildBucketTier
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updatecpchildbuckettier")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateCarrierProfileChildBucketTier(@Valid final TracfoneOneCarrierProfileChildTier tfCarrierProfileChildBucketTier) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneBucketController.updateCarrierProfileChildBucketTier(tfCarrierProfileChildBucketTier,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete the carrier profile child bucket tier
     * CARRIER_PROFILE_CHILD_TIER
     *
     * @param tfCarrierProfileChildTier
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deletecpchildbuckettier")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteCarrierProfileChildBucketTier(final TracfoneOneCarrierProfileChildTier tfCarrierProfileChildTier) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneBucketController.deleteCarrierProfileChildBucketTier(tfCarrierProfileChildTier,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to wild card search for profiles that match any
     * profile id or profile description entered by the user
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchcpbucketprofile")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchBucketProfile(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneRatePlanProfile> tfOneRatePlanProfiles = null;
        try {
            tfOneRatePlanProfiles = tracfoneFeatureController.searchBucketProfile(tracfoneOneSearchPlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneRatePlanProfiles), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to wild card search for profiles that match any
     * profile id or profile description entered by the user
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchcpchildbucketprofile")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchChildBucketProfile(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneRatePlanProfile> tfOneRatePlanProfiles = null;
        try {
            tfOneRatePlanProfiles = tracfoneFeatureController.searchChildBucketProfile(tracfoneOneSearchPlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneRatePlanProfiles), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all service plans based on the selected
     * profile from carrier profile buckets table
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewbucketserviceplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBucketServicePlansForCopy(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneCarrierServicePlan> bucketServicePlans = new ArrayList<>();
        try {
            bucketServicePlans = tracfoneFeatureController.getBucketServicePlansForCopy(tracfoneOneSearchPlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(bucketServicePlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all service plans based on the selected
     * profile from carrier profile child buckets table
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewchildbucketserviceplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getChildBucketServicePlansForCopy(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneCarrierServicePlan> bucketServicePlans = new ArrayList<>();
        try {
            bucketServicePlans = tracfoneFeatureController.getChildBucketServicePlansForCopy(tracfoneOneSearchPlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(bucketServicePlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all the child plans from carrier profile child buckets that match a service
     * plan id and profile id
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewbucketchildplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBucketChildPlans(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneChildPlan> childPlans = new ArrayList<>();
        try {
            childPlans = tracfoneFeatureController.getBucketChildPlans(tracfoneOneSearchPlanModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(childPlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve the line status codes from the master table
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewlinestatuscodes")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllLineStatusCodes(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneLineStatusCode> lineStatusCodes = new ArrayList<>();
        try {
            lineStatusCodes = tracfoneFeatureController.getAllLineStatusCodes(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(lineStatusCodes), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a new record
     * in sa.x_rp_line_status table
     *
     * @param tfOneLineStatus
     * @return
     */
    @POST
    @Path("rateplanmaintenance/addlinestatuscode")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertLineStatusCode(@Valid final TracfoneOneLineStatusCode tfOneLineStatus) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneFeatureController.insertLineStatusCode(tfOneLineStatus,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a record
     * in sa.x_rp_line_status table
     *
     * @param tfOneLineStatus
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updatelinestatuscode")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateLineStatusCode(@Valid final TracfoneOneLineStatusCode tfOneLineStatus) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneFeatureController.updateLineStatusCode(tfOneLineStatus,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete  x_rp_line_status
     * Validate whether that code is used in x_rp_extension table.
     * If it is used, throw an error. Else delete it and show success message
     *
     * @param tfOneLineStatus
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deletelinestatuscode")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteLineStatusCode(final TracfoneOneLineStatusCode tfOneLineStatus) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneProfileController.deleteLineStatusCode(tfOneLineStatus,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve the throttle status codes from the master table
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewthrottlestatuscodes")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllThrottleStatusCodes(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneThrottleStatusCode> throttleStatusCodes = new ArrayList<>();
        try {
            throttleStatusCodes = tracfoneFeatureController.getAllThrottleStatusCodes(tracfoneOneSearchPlanModel.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(throttleStatusCodes), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a new record
     * in sa.x_rp_throttle_status table
     *
     * @param tfThrottleStatusCode
     * @return
     */
    @POST
    @Path("rateplanmaintenance/addthrottlestatuscode")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertThrottleStatusCode(@Valid final TracfoneOneThrottleStatusCode tfThrottleStatusCode) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneFeatureController.insertThrottleStatusCode(tfThrottleStatusCode,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a record
     * in sa.x_rp_throttle_status table
     *
     * @param tfThrottleStatusCode
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updatethrottlestatuscode")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateThrottleStatusCode(@Valid final TracfoneOneThrottleStatusCode tfThrottleStatusCode) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneFeatureController.updateThrottleStatusCode(tfThrottleStatusCode,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete  x_rp_throttle_status
     * Validate whether that code is used in x_rp_extension table.
     * If it is used, throw an error. Else delete it and show success message
     *
     * @param tfOneThrottleStatusCode
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deletethrottlestatuscode")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteThrottleStatusCode(final TracfoneOneThrottleStatusCode tfOneThrottleStatusCode) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneProfileController.deleteThrottleStatusCode(tfOneThrottleStatusCode,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a new record
     * in sa.X_RP_FEATURE_REQUIREMENT table
     *
     * @param tfFeatureRequirement
     * @return
     */
    @POST
    @Path("rateplanmaintenance/addfeaturerequirement")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertFeatureRequirement(@Valid final TracfoneOneFeatureRequirement tfFeatureRequirement) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneFeatureController.insertFeatureRequirement(tfFeatureRequirement,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a record
     * in sa.X_RP_FEATURE_REQUIREMENT table
     *
     * @param tfFeatureRequirement
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updatefeaturerequirement")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateFeatureRequirement(@Valid final TracfoneOneFeatureRequirement tfFeatureRequirement) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneFeatureController.updateFeatureRequirement(tfFeatureRequirement,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete  X_RP_FEATURE_REQUIREMENT
     * Validate whether that code is used in rp_extension_config table.
     * If it is used, throw an error. Else delete it and show success message
     *
     * @param tfOneFeatureRequirement
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deletefeaturerequirement")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteFeatureRequirement(final TracfoneOneFeatureRequirement tfOneFeatureRequirement) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneFeatureController.deleteFeatureRequirement(tfOneFeatureRequirement,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all X_RP_FEATURE_REQUIREMENT
     *
     * @param tfFeatureRequirement
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewfeaturerequirements")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllFeatureRequirements(final TracfoneOneFeatureRequirement tfFeatureRequirement) {
        List<TFOneFeatureRequirement> tfFeatureRequirements = new ArrayList<>();
        try {
            tfFeatureRequirements = tracfoneFeatureController.getAllFeatureRequirements(tfFeatureRequirement.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfFeatureRequirements), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to copy all Carrier Profile Buckets and Child Buckets and Tiers from an existing
     * profile.
     *
     * @param tfOneSearchBucketModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/copyallbucketsfromprofile")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response copyAllBucketsFromProfile(final TracfoneOneSearchBucketModel tfOneSearchBucketModel) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneBucketController.copyAllBucketsFromProfile(tfOneSearchBucketModel,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete the carrier profile bucket & carrier profile child bucket
     * based on service plan id and profile id
     * sa.CARRIER_PROFILE_BUCKETS & sa.CARRIER_PROFILE_CHILD_BUCKETS
     *
     * @param tracfoneOneSearchBucketModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deleteallbucketsandtiers")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteAllBucketsAndTiers(final TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneBucketController.deleteAllBucketsAndTiers(tracfoneOneSearchBucketModel,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update profile id of carrier profile bucket & carrier profile child bucket
     * based on service plan id and profile id
     * sa.CARRIER_PROFILE_BUCKETS & sa.CARRIER_PROFILE_CHILD_BUCKETS
     *
     * @param tracfoneOneSearchBucketModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updateallbucketswithprofileid")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateAllBucketsWithProfileId(final TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneBucketController.updateAllBucketsWithProfileId(tracfoneOneSearchBucketModel,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all carrier id and market submarket names for the drop down in Step 1 of add
     * Rate Plan Association screen to be added into the newly inserted carrier features
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/{parent}/viewcarrierids")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllCarrierIds(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel,
                                     @PathParam("parent") String parent) {
        List<TFOneCarrier> carriers = new ArrayList<>();
        try {
            carriers = tracfoneFeatureController.getAllCarrierIds(tracfoneOneSearchPlanModel.getDbEnv(),
                    tracfoneOneSearchPlanModel.getCarrierName(),
                    parent);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(carriers), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to check if there are any service plans associated to the selected profile for delete
     * and return the list of service plans to show the user.
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/{profileid}/viewserviceplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getProfileServicePlans(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel,
                                           @PathParam("profileid") String profileId) {
        List<TFOneCarrierServicePlan> tfOneServicePlans = new ArrayList<>();
        try {
            tfOneServicePlans = tracfoneProfileController.getProfileServicePlans(tracfoneOneSearchPlanModel.getDbEnv(),
                    profileId);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneServicePlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to check if there are any service plans associated to the selected profile for delete
     * and return the list of service plans to show the user.
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/{rateplan}/viewrpserviceplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getRatePlanServicePlans(final TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel,
                                            @PathParam("rateplan") String ratePlan) {
        List<TFOneCarrierServicePlan> tfOneServicePlans = new ArrayList<>();
        try {
            tfOneServicePlans = tracfoneProfileController.getRatePlanServicePlans(tracfoneOneSearchPlanModel.getDbEnv(),
                    ratePlan);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneServicePlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all rate plan names from the master table
     *
     * @param tracfoneOneSearchPlanModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewcfrateplans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierFeatureRatePlans(TracfoneOneSearchPlanModel tracfoneOneSearchPlanModel) {
        List<TFOneRatePlan> ratePlans = new ArrayList<>();
        try {
            ratePlans = tracfoneRatePlanController.getCarrierRatePlans(tracfoneOneSearchPlanModel.getDbEnv(),
                    tracfoneOneSearchPlanModel.getCarrierName());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(ratePlans), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add an new Ancillary Code Config x_rp_ancillary_code_config
     *
     * @param tfAncillaryCodeConfig
     * @return
     */
    @POST
    @Path("rateplanmaintenance/addancillarycodeconfig")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertAncillaryCodeConfig(@Valid final TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneProfileController.insertAncillaryCodeConfig(tfAncillaryCodeConfig,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update an Ancillary Code Config x_rp_ancillary_code_config based on
     * extension obj id & profile id
     *
     * @param tfAncillaryCodeConfig
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updateancillarycodeconfig")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateAncillaryCodeConfig(@Valid final TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneProfileController.updateAncillaryCodeConfig(tfAncillaryCodeConfig,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete an Ancillary Code Config x_rp_ancillary_code_config based on
     * extension obj id & profile id
     *
     * @param tfAncillaryCodeConfig
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deleteancillarycodeconfig")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteAncillaryCodeConfig(final TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneProfileController.deleteAncillaryCodeConfig(tfAncillaryCodeConfig,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all Ancillary Code Config based on extension obj id & profile id
     * x_rp_ancillary_code_config
     *
     * @param tfAncillaryCodeConfig
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchancillarycodeconfig")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig) {
        List<TFOneAncillaryCodeConfig> tfAncillaryCodeConfigs = new ArrayList<>();
        try {
            tfAncillaryCodeConfigs = tracfoneProfileController.getAncillaryCodeConfig(tfAncillaryCodeConfig);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfAncillaryCodeConfigs), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add an new record into x_rp_ancillary_code_discount
     *
     * @param tfAncillaryCodeDiscount
     * @return
     */
    @POST
    @Path("rateplanmaintenance/insertancillarycodediscount")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertAncillaryCodeDiscount(@Valid final TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneProfileController.insertAncillaryCodeDiscount(tfAncillaryCodeDiscount,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete an record from x_rp_ancillary_code_discount
     * based on ANCILLARY_CODE & BRM_EQUIVALENT
     *
     * @param tfAncillaryCodeDiscount
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deleteancillarycodediscount")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteAncillaryCodeDiscount(final TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneProfileController.deleteAncillaryCodeDiscount(tfAncillaryCodeDiscount,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update an record from x_rp_ancillary_code_discount
     * based on ANCILLARY_CODE & BRM_EQUIVALENT
     *
     * @param tfAncillaryCodeDiscount
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updateancillarycodediscount")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateAncillaryCodeDiscount(@Valid final TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneProfileController.updateAncillaryCodeDiscount(tfAncillaryCodeDiscount,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve from x_rp_ancillary_code_discount
     * based on ANCILLARY_CODE & BRM_EQUIVALENT
     *
     * @param tfAncillaryCodeDiscount
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchancillarycodediscount")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchAncillaryCodeDiscount(final TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount) {
        List<TFOneAncillaryCodeDiscount> tfAncillaryCodeDiscounts = new ArrayList<>();
        try {
            tfAncillaryCodeDiscounts = tracfoneProfileController.searchAncillaryCodeDiscount(tfAncillaryCodeDiscount);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfAncillaryCodeDiscounts), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert into bucket_list
     *
     * @param tracfoneOneBucketLists
     * @return
     */
    @POST
    @Path("rateplanmaintenance/addbucketlist")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertBucketList(@Valid List<TracfoneOneBucketList> tracfoneOneBucketLists) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneBucketController.insertBucketList(tracfoneOneBucketLists, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update bucket_list based on BUCKET_ID
     *
     * @param tfOneBucketList
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updatebucketlist")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateBucketList(@Valid final TracfoneOneBucketList tfOneBucketList) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneBucketController.updateBucketList(tfOneBucketList,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all bucket from master table based on any column
     *
     * @param tracfoneOneBucketList
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchbucketlist")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchBucketList(final TracfoneOneBucketList tracfoneOneBucketList) {
        List<TFOneBucketList> tfOneBucketLists = new ArrayList<>();
        try {
            tfOneBucketLists = tracfoneBucketController.searchBucketList(tracfoneOneBucketList);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneBucketLists), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete an record from bucket_list
     * based on bucket_id
     *
     * @param tracfoneOneBucketList
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deletebucketlist")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteBucketList(final TracfoneOneBucketList tracfoneOneBucketList) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneBucketController.deleteBucketList(tracfoneOneBucketList,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to insert into X_MULTI_RATE_PLAN_ESNS
     *
     * @param tracfoneOneMultiRatePlanEsn
     * @return
     */
    @POST
    @Path("rateplanmaintenance/addmultirateplanesn")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertMultiRatePlanEsns(@Valid TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.insertMultiRatePlanEsn(tracfoneOneMultiRatePlanEsn, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to update a record based on X_ESN & X_SERVICE_PLAN_ID
     * sa.X_MULTI_RATE_PLAN_ESNS
     *
     * @param tracfoneOneMultiRatePlanEsn
     * @return
     */
    @POST
    @Path("rateplanmaintenance/updatemultirateplanesn")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateMultiRatePlanEsns(@Valid final TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.updateMultiRatePlanEsn(tracfoneOneMultiRatePlanEsn, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete a record based on X_ESN & X_SERVICE_PLAN_ID
     * sa.X_MULTI_RATE_PLAN_ESNS
     *
     * @param tracfoneOneMultiRatePlanEsn
     * @return
     */
    @POST
    @Path("rateplanmaintenance/deletemultirateplanesn")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response deleteMultiRatePlanEsns(final List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsn) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneProfileController.deleteMultiRatePlanEsn(tracfoneOneMultiRatePlanEsn, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }


    /**
     * This method is used to retrieve all X_MULTI_RATE_PLAN_ESNS based on any column
     *
     * @param tracfoneOneMultiRatePlanEsn
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchmultirateplanesns")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchMultiRatePlanEsns(final TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn) {
        List<TFOneMultiRatePlanEsn> tfOneMultiRatePlanEsnss = new ArrayList<>();
        try {
            tfOneMultiRatePlanEsnss = tracfoneProfileController.searchMultiRatePlanEsns(tracfoneOneMultiRatePlanEsn);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneMultiRatePlanEsnss), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method will be used to bulk insert profiles based on a csv upload of profile descriptions
     *
     * @param tfRatePlanProfiles
     * @return
     */
    @POST
    @Path("rateplanmaintenance/bulkinsertprofiles")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertProfiles(List<TracfoneOneRatePlanProfile> tfRatePlanProfiles) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneProfileController.bulkInsertProfiles(tfRatePlanProfiles,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * To search Profile features from rp_extension Config
     *
     * @param tracfoneOneSearchProfileModel
     * @return
     */
    @POST
    @Path("rateplanmaintenance/searchprofilefeatures")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response searchProfileFeatures(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) {
        List<TFOneRatePlanExtensionConfig> tfOneFeatures = new ArrayList<>();

        try {
            tfOneFeatures = tracfoneFeatureController.searchProfileFeatures(tracfoneOneSearchProfileModel);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneFeatures), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to retrieve all featurevalues
     *
     * @param tracfoneOneRatePlanExtensionConfig
     * @return
     */
    @POST
    @Path("rateplanmaintenance/viewfeaturevalues")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllFeatureValues(TracfoneOneRatePlanExtensionConfig tracfoneOneRatePlanExtensionConfig) {
        List<String> featureValues = new ArrayList<>();
        try {
            featureValues = tracfoneFeatureController.getAllFeatureValues(tracfoneOneRatePlanExtensionConfig.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(featureValues), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to bulk update Profile features
     *
     * @param tfOneRpExtensionConfig
     * @return
     */
    @POST
    @Path("rateplanmaintenance/bulkupdateprofilefeatures")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkUpdateProfileFeatures(TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneFeatureController.bulkUpdateProfileFeatures(tfOneRpExtensionConfig, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add a new feature for multiple profile ids and update
     * in sa.x_rp_extension_config table
     *
     * @param tfOneRpExtensionConfigs
     * @return
     */
    @POST
    @Path("rateplanmaintenance/bulkinsertprofilefeatures")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertProfileFeatures(@Valid final List<TracfoneOneRatePlanExtensionConfig> tfOneRpExtensionConfigs) {
        TFOneGeneralResponse tfOneResponse = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneFeatureController.bulkInsertProfileFeatures(tfOneRpExtensionConfigs,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("rateplanmaintenance/bulkinsertsummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(),
                    "Bulk PF Insert",
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("rateplanmaintenance/geterrorrecorddetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getErrorRecordDetails(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> summary = new ArrayList<>();
        try {
            tracfoneOneUserHistory.setType("Bulk IG Insert");
            summary = tracfoneControllerAction.getErrorRecordDetails(tracfoneOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(summary), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method will be used to bulk insert Rate Plan Esn based on a csv upload
     *
     * @param tracfoneOneMultiRatePlanEsn
     * @return
     */
    @POST
    @Path("rateplanmaintenance/bulkinsertrateplanesn")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkInsertRatePlanEsn(List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsn) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneProfileController.bulkInsertRatePlanEsn(tracfoneOneMultiRatePlanEsn,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("rateplanmaintenance/bulkinsertrpesnsummary")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBulkInsertRpEsnSummary(final TracfoneOneUserHistory tracfoneOneUserHistory) {
        List<TFOneBulkInsertReport> bulkInsertSummary = null;
        try {
            bulkInsertSummary = tracfoneControllerAction.getBulkInsertSummary(tracfoneOneUserHistory.getDbEnv(),
                    "Bulk Multi Rate Plan ESN Insert",
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(bulkInsertSummary), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to delete a record based on X_ESN & X_SERVICE_PLAN_ID
     * sa.X_MULTI_RATE_PLAN_ESNS
     *
     * @param tracfoneOneMultiRatePlanEsn
     * @return
     */
    @POST
    @Path("rateplanmaintenance/bulkdeletemultirateplanesn")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response bulkDeleteMultiRatePlanEsns(final List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsn) {
        TFOneGeneralResponse response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
        try {
            tracfoneProfileController.bulkDeleteMultiRatePlanEsn(tracfoneOneMultiRatePlanEsn, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method will be used to validate profile descriptions for bulk insertions
     *
     * @param tfRatePlanProfiles
     * @return
     */
    @POST
    @Path("rateplanmaintenance/validateinsertprofiles")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response validateInsertProfiles(List<TracfoneOneRatePlanProfile> tfRatePlanProfiles) {
        List<String>  duplicates = new ArrayList<>();
        try {
            duplicates = tracfoneProfileController.validateInsertProfiles(tfRatePlanProfiles,
                    getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(duplicates), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get bucket details
     *
     * @param tracfoneOneBucketList
     * @return
     */
    @POST
    @Path("rateplanmaintenance/getbucketdetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getBucketDetails(final TracfoneOneBucketList tracfoneOneBucketList) {
        TFOneCarrierProfileBucket tfOneCarrierProfileBucket = null;
        try {
            tfOneCarrierProfileBucket = tracfoneBucketController.getBucketDetails(tracfoneOneBucketList);
        } catch (TracfoneOneException tfoEx) {
            Map<String, String> errorMap = tfoEx.getToasterErrorMessage();
            LOGGER.error(errorMap, tfoEx);
            return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(gson.toJson(tfOneCarrierProfileBucket), MediaType.APPLICATION_JSON).build();
    }
    
    /**
     * Retrieves the user object making request from the principal.
     *
     * @return
     */
    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }

}
