package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.List;

public class TracfoneOneBulkTransaction {
    private TracfoneOneNewTransaction tracfoneOneNewTransaction;
    private List<TracfoneOneBulkIdentifier> identifierList;

    public TracfoneOneBulkTransaction() {
        identifierList = new ArrayList<>();
    }

    public TracfoneOneNewTransaction getTracfoneOneNewTransaction() {
        return tracfoneOneNewTransaction;
    }

    public void setTracfoneOneNewTransaction(TracfoneOneNewTransaction tracfoneOneNewTransaction) {
        this.tracfoneOneNewTransaction = tracfoneOneNewTransaction;
    }

    public List<TracfoneOneBulkIdentifier> getIdentifierList() {
        return identifierList;
    }

    public void setIdentifierList(List<TracfoneOneBulkIdentifier> identifierList) {
        this.identifierList = identifierList;
    }

    @Override
    public String toString() {
        return "TracfoneOneBulkTransaction{" +
                "tracfoneOneNewTransaction=" + tracfoneOneNewTransaction +
                ", identifierList=" + identifierList +
                '}';
    }
}
