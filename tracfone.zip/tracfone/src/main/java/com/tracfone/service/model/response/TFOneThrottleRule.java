package com.tracfone.service.model.response;

/**
 * @author Thejaswini
 */
public class TFOneThrottleRule {
    private String objId;
    private String parentId;
    private String policyId;
    private String ruleDesc;
    private String status;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getPolicyId() {
        return policyId;
    }

    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }

    public String getRuleDesc() {
        return ruleDesc;
    }

    public void setRuleDesc(String ruleDesc) {
        this.ruleDesc = ruleDesc;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "TFOneThrottleRule{" +
                "objId='" + objId + '\'' +
                ", parentId='" + parentId + '\'' +
                ", policyId='" + policyId + '\'' +
                ", ruleDesc='" + ruleDesc + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
