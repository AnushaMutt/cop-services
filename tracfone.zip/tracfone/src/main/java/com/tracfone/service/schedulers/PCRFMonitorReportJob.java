package com.tracfone.service.schedulers;

import com.google.gson.Gson;
import com.tracfone.service.model.event.TracfoneOneReportRequest;
import com.tracfone.service.model.report.TFOneReportPCRFMonitor;
import com.tracfone.service.report.workers.pcrf.MonitorPCRFCarrierWorkerBean;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Singleton
public class PCRFMonitorReportJob {

    @EJB
    MonitorPCRFCarrierWorkerBean monitorPCRFCarrierWorkerBean;

    @Inject
    private Event<TracfoneOneReportRequest> tracfoneOneConstantReportEvent;

    private static final Logger LOGGER = LogManager.getLogger(PCRFMonitorReportJob.class);

//    @Schedule(second = "*/50", minute = "*", hour = "*", persistent = false)
    public void runPCRFMonitorReport() {
        try {
            List<TFOneReportPCRFMonitor> carrierMonitorReport = new ArrayList<>();
//                    List<TFOneReportPCRFMonitor> carrierMonitorReport = monitorPCRFCarrierWorkerBean.runMonitorReport();
            if (!carrierMonitorReport.isEmpty()) {
                Gson gson = new Gson();
                TracfoneOneReportRequest reportRequest = new TracfoneOneReportRequest();
                reportRequest.setJsonResponse(gson.toJson(carrierMonitorReport));
                reportRequest.setReportName(TracfoneOneConstantReport.TRACFONE_REPORTNAME_PCRF_MONITOR);
                tracfoneOneConstantReportEvent.fire(reportRequest);
            } else {
                LOGGER.info("PCRF MonitorCarrierWorkerBean returned an empty response.");
            }
        } catch (Exception ex) {
            LOGGER.error("PCRF Monitor report could not be retrieved because of an exception", ex);
        }
    }

}
