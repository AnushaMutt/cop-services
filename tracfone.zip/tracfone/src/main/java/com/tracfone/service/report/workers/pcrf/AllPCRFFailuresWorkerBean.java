package com.tracfone.service.report.workers.pcrf;

import com.tracfone.service.model.report.TFOneReportAllPCRFFailures;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Resource;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

@Stateless
public class AllPCRFFailuresWorkerBean {
    @Resource(lookup = "jndi/cop_report")
    private DataSource dataSourceReports;

    private AtomicBoolean busy = new AtomicBoolean(false);
    private static final Logger LOGGER = LogManager.getLogger(AllPCRFFailuresWorkerBean.class);

    @Lock(LockType.READ)
    public List<TFOneReportAllPCRFFailures> runAllPCRFFailuresReport() {
        List<TFOneReportAllPCRFFailures> pcrfFailures = new ArrayList<>();

        if (!busy.compareAndSet(false, true)) {
            return pcrfFailures;
        }

        try (Connection con = dataSourceReports.getConnection();
             PreparedStatement stmt = con.prepareStatement(TracfoneOneConstantReport.REPORT_SQL_ALLPCRFFAILURES);
             ResultSet resultSet = stmt.executeQuery();) {
            while (resultSet.next()) {
                TFOneReportAllPCRFFailures tfOneReportAllPCRFFailures = new TFOneReportAllPCRFFailures();
                tfOneReportAllPCRFFailures.setPcrfParentName(resultSet.getString("PCRF_PARENT_NAME"));
                tfOneReportAllPCRFFailures.setSourceSystem(resultSet.getString("SOURCESYSTEM"));
                tfOneReportAllPCRFFailures.setxTimeSegment(resultSet.getString("X_TIME_SEGMENT"));
                tfOneReportAllPCRFFailures.setTotalTransCount(resultSet.getString("TOTAL_TRANS_COUNT"));
                tfOneReportAllPCRFFailures.setFailureCount(resultSet.getString("FAILURE_COUNT"));
                tfOneReportAllPCRFFailures.setOrderType(resultSet.getString("ORDER_TYPE"));
                tfOneReportAllPCRFFailures.setPercentFailure(resultSet.getString("PERCENT_FAILURE"));
                tfOneReportAllPCRFFailures.setSumF(resultSet.getString("SUM_F"));
                pcrfFailures.add(tfOneReportAllPCRFFailures);
            }
        } catch (Exception e) {
            LOGGER.error("AllPCRFFailures Report Retrieval Error - ", e);
        } finally {
            busy.set(false);
        }
        return pcrfFailures;
    }
}