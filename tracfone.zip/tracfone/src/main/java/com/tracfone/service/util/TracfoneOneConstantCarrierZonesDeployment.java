package com.tracfone.service.util;

/**
 * @author Gaurav.Sharma
 */
public interface TracfoneOneConstantCarrierZonesDeployment {

    // ERROR MESSAGES
    String TRACFONE_VALIDATE_CARRIER_ZONES_ERROR = "TFE7000";
    String TRACFONE_VALIDATE_CARRIER_ZONES_ERROR_MESSAGE = "Unable to validate Carrier Zones";

    String TRACFONE_VALIDATE_NPANAXX_ERROR = "TFE7001";
    String TRACFONE_VALIDATE_NPANAXX_ERROR_MESSAGE = "Unable to validate NPANAXX";

    String TRACFONE_VALIDATE_AR_USA_ERROR = "TFE7005";
    String TRACFONE_VALIDATE_AR_USA_ERROR_MESSAGE = "Unable to validate AR USA Data";

    String TRACFONE_INSERT_MISSING_CZ_ERROR = "TFE7002";
    String TRACFONE_INSERT_MISSING_CZ_ERROR_MESSAGE = "Unable to insert missing Carrier Zones";

    String TRACFONE_INSERT_CZ_ERROR = "TFE7003";
    String TRACFONE_INSERT_CZ_ERROR_MESSAGE = "Unable to insert Carrier Zones";

    String TRACFONE_UPDATE_CARRIER_ID_ERROR = "TFE7004";
    String TRACFONE_UPDATE_CARRIER_ID_ERROR_MESSAGE = "Unable to update Carrier Id";

    String TRACFONE_INSERT_NPAXX_ERROR = "TFE7006";
    String TRACFONE_INSERT_NPAXX_ERROR_MESSAGE = "Unable to update Carrier Id";

    String TRACFONE_VALIDATE_CINGULAR_MRKT_ERROR = "TFE7007";
    String TRACFONE_VALIDATE_CINGULAR_MRKT_ERROR_MESSAGE = "Unable to validate Cingular Mrkt Info";

    String TRACFONE_VALIDATE_ZIP_MKT_SUB_MKT_ERROR = "TFE7008";
    String TRACFONE_VALIDATE_ZIP_MKT_SUB_MKT_ERROR_MESSAGE = "Unable to validate Zip Mkt Sub Mkt";

    String TRACFONE_UPDATE_DEALER_NAN_ERROR = "TFE7009";
    String TRACFONE_UPDATE_DEALER_NAN_ERROR_MESSAGE = "Unable to perform upd_dealer_nan procedure";

    String TRACFONE_INSERT_MISSING_CINGULAR_MKT_INFO_ERROR = "TFE7010";
    String TRACFONE_INSERT_MISSING_CINGULAR_MKT_INFO_ERROR_MESSAGE = "Unable to insert Cingular Mrkt Info";


    String TRACFONE_VALIDATE_TMO_NEXT_AVAILABLE_ERROR = "TFE7011";
    String TRACFONE_VALIDATE_TMO_NEXT_AVAILABLE_ERROR_MESSAGE = "Unable to validate Tmo Next Available table";

    String TRACFONE_INSERT_TMO_NPANXX_ERROR = "TFE7012";
    String TRACFONE_INSERT_TMO_NPANXX_ERROR_MESSAGE = "Unable to insert NPANXX";

    String TRACFONE_DUPLICATE_CINGULAR_MKT_INFO_FOUND_ERROR = "TFE7013";
    String TRACFONE_DUPLICATE_CINGULAR_MKT_INFO_FOUND_ERROR_MESSAGE = "Duplicate Cingular Mkt Info found";

    String TRACFONE_GET_CARRIERS_ERROR = "TFE7014";
    String TRACFONE_GET_CARRIERS_ERROR_MESSAGE = "Unable to get Carriers";

    //Summary screen constant
    String INSERTED_NPANXX = "Inserted NPANXX ";
    String INSERT_NPANXX = "Insert NPANXX";
    String TABLE_NOT_FOUND_ORACODE = "ORA-00942";
    String INVALID_TYPE_ORACODE = "ORA-01722";
    String INVALID_DATA_TYPE = "Invalid values to insert";
    String TABLE_GRANT = "Please check the Grants";
    String GRANT_ORACODE = "ORA-01031";
    String DUPLICATE_RECORD_FOUND = "Duplicate record found.";
    String NPANXX2CARRIERZONES_TABLE_NOT_FOUND = "npanxx2carrierzones table was not found.";
    String NPANXX2CARRIERZONES_DUPLICATE = "unique constraint (SA.NPANXX2CARRIERZONES_UK1) violated";
    String FAILED_CHECK_TECHNICAL_REASON = "Failed due to other reason, Please check Technical Reason for more details";

    String TRACFONE_SEARCH_CARRIER_ZONES = "select b.TOTAL_RECORDS, a.ZIP, a.ST, a.COUNTY,ZONE, a.RATE_CENTE, a.MARKETID, a.MRKT_AREA, "
            + "a.CITY, a.BTA_MKT_NUMBER, a.BTA_MKT_NAME, a.CARRIER_ID, a.CARRIER_NAME, a.ZIP_STATUS, a.SIM_PROFILE, a.SIM_PROFILE_2, a.PLANTYPE"
            + " from(select cz.* from CARRIERZONES cz where zip = ? AND CARRIER_NAME in (";

    String TRACFONE_SEARCH_NPANXX = "select ZIP, NPA,NXX,NPANXX, ACCOUNT_NUM, TEMPLATE"
            + " from sa.x_verizon_zip_npanxx where zip in (";

    String INSERT_INTO_NPANXX2CARRIERZONES = "insert into npanxx2carrierzones\n";

    String NEW_LINE = "       \n";

    String TRACFONE_SEARCH_AR_USA = "SELECT DISTINCT\n"
            + "           Z.POSTAL_CODE,\n"
            + "           Z.STATE,\n"
            + "           UPPER(M.COUNTY) COUNTY,\n"
            + "           TO_NUMBER(REPLACE(CMA_MKT_CODE,'CMA')) CMA_MKT_CODE2,\n"
            + "           CASE WHEN CMA_MKT_NAME LIKE 'RSA%' THEN CMA_MKT_NAME||' - '||CMA_MKT_NAME_ALTERNATE ELSE CMA_MKT_NAME END CMA_MKT_NAME_ALTERNATE2,\n"
            + "           Z.CITY,\n"
            + "           TO_NUMBER(REPLACE(BTA_MKT_CODE,'BTA')) BTA_MKT_CODE2,\n"
            + "           BTA_MKT_NAME_ALTERNATE\n"
            + "      FROM cop.AR_USA_POSTAL_ZIPS Z,\n"
            + "           cop.AR_USA_MARKET M\n"
            + "     WHERE 1=1\n"
            + "       AND M.KEY_CODE = Z.KEY_CODE\n"
            + "       AND Z.POSTAL_CODE in (";

    String TRACFONE_INSERT_MISSING_CARRIERZONES = "insert into carrierzones"
            + " values(?, ? ,?, ?,SUBSTR(? ,1 ,15), ?, ? ,? ,? ,? ,null ,? ,? ,? ,? ,?)";

    String TRACFONE_INSERT_NAPNXX = INSERT_INTO_NPANXX2CARRIERZONES
            + "        values('555','555', ?, ?, 0, 0, substr(? ,1 ,15), ?,'VZW -'||?, ?, ?, ?, ?,\n"
            + "               '04152', 'CDMA', 1900, 0, ? , ?, null, 'CDMA', null, null)";

    String TRACFONE_INSERT_NAPNXX_ATT = INSERT_INTO_NPANXX2CARRIERZONES
            + "        values('111','111', ?, ?, 0, 0, substr(? ,1 ,15), ?,'ATT -'||?, ?, ?, ?, ?,\n"
            + "               '00410', 'GSM', 1900, 0, ? , ?, 'GSM', null, null, 'G0410')";

    String TRACFONE_GET_CPREF_COUNT = "select count(*) cnt from carrierpref where st = ? "
            + "and county = ? and carrier_id  = ?";
    String TRACFONE_GET_CPREF_RANK = "select nvl(max(to_number(new_rank)),0) max_rank\n"
            + "from carrierpref where st = ? and county = ?";

    String TRACFONE_INSERT_CARRIER_PREF = "Declare\n"
            + "    st varchar2(30) := ?;\n"
            + "    county varchar2(50) := ?;\n"
            + "    carrier_id number := ?;\n"
            + "    carrier_name varchar2(255) := ?;\n"
            + "      \n"
            + "    cursor cpref2 (c_st in varchar2, \n"
            + "                    c_county in varchar2) is\n"
            + "    select nvl(max(to_number(new_rank)),0) max_rank\n"
            + "      from carrierpref\n"
            + "     where st = c_st\n"
            + "       and county = c_county;\n"
            + "    cpref2_rec    cpref2%rowtype;\n"
            + "    cpref2_rec2   cpref2%rowtype;\n"
            + "    \n"
            + "    cursor cpref3 (c_st in varchar2, \n"
            + "                   c_county in varchar2,\n"
            + "                   c_carrier_id in varchar2) is\n"
            + "    select count(*) cnt\n"
            + "      from carrierpref\n"
            + "     where st = c_st\n"
            + "       and county = c_county\n"
            + "       and carrier_id  = c_carrier_id;\n"
            + "    cpref3_rec    cpref3%rowtype;\n"
            + "    cpref3_rec2   cpref3%rowtype;\n"
            + "    \n"
            + "    begin\n"
            + "\n"
            + NEW_LINE
            + "       cpref3_rec:= cpref3_rec2;\n"
            + "       open cpref3(st,county,carrier_id);\n"
            + "        fetch cpref3 into cpref3_rec;\n"
            + "       close cpref3;\n"
            + NEW_LINE
            + "       cpref2_rec:= cpref2_rec2;\n"
            + "       open cpref2(st,county);\n"
            + "        fetch cpref2 into cpref2_rec;\n"
            + "       close cpref2;\n"
            + NEW_LINE
            + NEW_LINE
            + "       if cpref3_rec.cnt>0 then \n"
            + "        goto next_rec;\n"
            + "       end if;\n"
            + NEW_LINE
            + "       if cpref2_rec.max_rank >0 then\n"
            + "       insert into carrierpref\n"
            + "       values(st,county,carrier_id,carrier_name,null,cpref2_rec.max_rank+1);\n"
            + "       commit;\n"
            + "       else \n"
            + "       insert into carrierpref\n"
            + "       values(st,county,carrier_id,carrier_name,null,1);\n"
            + "       commit;\n"
            + "       END IF;\n"
            + "       \n"
            + "       <<next_rec>>\n"
            + "       null;\n"
            + "    end;";

    String TRACFONE_FIND_CZ = "select * from CARRIERZONES where zip in (";

    String TRACFONE_SELECT_CARRIER_PREF = "select ST, COUNTY, CARRIER_ID, CARRIER_NAME, CARRIER_RANK, NEW_RANK  "
            + "from CARRIERPREF where ST = ? AND COUNTY = ? AND CARRIER_ID = ? AND CARRIER_NAME = ?";

    String TRACFONE_SEARCH_CINGULAR_MRKT_INFO = "select MKT, NPA, NXX, NPANXX, RC_NUMBER, RC_NAME, RC_STATE, ZIP, " +
            "MKT_TYPE, ACCOUNT_NUM, MARKET_CODE, DEALER_CODE, SUBMARKETID, " +
            "TEMPLATE from sa.x_cingular_mrkt_info where zip in (";

    String TRACFONE_SEARCH_ZIPMKT_SUBMKT = "select distinct ZIPCODE, CITY, COUNTY , STATE, BILLING_SYSTEM, MARKET, " +
            "MARKET_DESCRIPTION, SUB_MARKET_SITE, RATE_CENTER_SERVICE_AREA, RATE_CENTER_DESCRIPTION, " +
            "NBI_LOCAL_MARKET, NBI_MARKET_DESCRIPTION, NBI_SUB_MARKET, NBI_RATE_CENTER," +
            " NBI_RATE_CENTER_DESCRIPTION, COMPASS_MARKET_CODE, ESTORE_ID, ADD_DATE, UPDATE_DATE " +
            "from cop.ATT_ZIPMKTSUBMKT where zipcode in (";

    String TRACFONE_SEARCH_CINGULAR_MRKT_INFO_UPD_DEALER_NAN = "select distinct dealer_code from sa.x_cingular_mrkt_info " +
            "where submarketid = ? and rownum <2";

    String TRACFONE_INSERT_CINGULAR_MRKT_INFO = "insert into sa.X_CINGULAR_MRKT_INFO(MKT, NPA, NXX, NPANXX, RC_NUMBER, RC_NAME, RC_STATE, ZIP, MKT_TYPE, ACCOUNT_NUM, " +
            "MARKET_CODE, DEALER_CODE, SUBMARKETID, TEMPLATE) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    String TRACFONE_SEARCH_TMO_NEXT_AVAILABLE = "select distinct ZIP, X_TYPE, NGP, NGPNAME, ST, SUBMARKET, RATECENTER"
            + " from cop.tmobile_nextavailable where zip in (";

    String TRACFONE_INSERT_TMO_NAPNXX = INSERT_INTO_NPANXX2CARRIERZONES
            + "        values('777', '777', ?, ?, 0, 0, substr(?,1,15), ?,\n"
            + "        case when ? = '180260' then 'T-MOBILE WFM' else 'TMO -'|| ? end,\n"
            + "         ?, ? , ?,  ?, '00260', 'GSM', 1900, 0, ?, ?, 'GSM', null, null, 'G0260')";

    String TRACFONE_DUPLICATE_CINGULAR_MKT_INFO = "SELECT count(1) FROM sa.X_CINGULAR_MRKT_INFO where zip =  ?";

    String TRACFONE_GET_ALL_CARRIER = "select DISTINCT X_CARRIER_ID from sa.TABLE_X_CARRIER where UPPER(x_mkt_submkt_name) like ";
}