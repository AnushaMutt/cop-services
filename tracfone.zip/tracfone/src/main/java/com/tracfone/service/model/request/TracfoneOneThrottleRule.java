package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * @author Thejaswini
 */
public class TracfoneOneThrottleRule {
    private String dbEnv;
    private String objId;
    @Size(min = 1, message = "Parent Id cannot be null")
    private String parentId;
    @Digits(integer = 38, fraction = 0, message = "Policy Id must be a number")
    @Size(max = 38, message = "Policy Id cannot have more than 38 digits")
    @Size(min = 1, message = "Policy Id cannot be null")
    private String policyId;
    @Size(max = 40, message = "Rule Description cannot have more than 40 characters")
    @Size(min = 1, message = "Rule Description cannot be null")
    private String ruleDesc;
    @Size(max = 1, message = "Status cannot have more than 1 character")
    @Size(min = 1, message = "Status cannot be null")
    private String status;
    private String policyName;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getPolicyId() {
        return policyId;
    }

    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }

    public String getRuleDesc() {
        return ruleDesc;
    }

    public void setRuleDesc(String ruleDesc) {
        this.ruleDesc = ruleDesc;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    @Override
    public String toString() {
        return "TracfoneOneThrottleRule{" +
                "dbEnv='" + dbEnv + '\'' +
                ", objId='" + objId + '\'' +
                ", parentId='" + parentId + '\'' +
                ", policyId='" + policyId + '\'' +
                ", ruleDesc='" + ruleDesc + '\'' +
                ", status='" + status + '\'' +
                ", policyName='" + policyName + '\'' +
                '}';
    }
}
