/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * TABLE: IG_BUCKETS
 * @author Shireen Fathima
 */
public class TracfoneOneBucket {

    private String dbEnv;
    @NotNull(message = "Bucket Id cannot be null")
    @Size(min=1, message = "Bucket Id cannot be blank")
    @Size(max=30, message = "Bucket Id cannot have more than 30 characters")
    private String bucketId;
    @NotNull(message = "Active Flag cannot be null")
    @Size(min=1, message = "Active Flag cannot be blank")
    @Size(max=2, message = "Active Flag cannot have more than 2 characters")
    private String activeFlag;
    @Size(max=30, message = "Measure Unit cannot have more than 30 characters")
    private String measureUnit;
    @Size(max=100, message = "Bucket Desc cannot have more than 100 characters")
    private String bucketDesc;
    @Size(max=50, message = "Bucket Type cannot have more than 50 characters")
    private String bucketType;
    @NotNull(message = "Rate Plan Name cannot be null")
    @Size(min=1, message = "Rate Plan Name cannot be blank")
    @Size(max=60, message = "Rate Plan Name cannot have more than 60 characters")
    private String ratePlan;
    @Size(max=50, message = "SUI Display Type cannot have more than 50 characters")
    private String suiDisplayType;
    @Size(max=50, message = "Bucket Group cannot have more than 50 characters")
    private String bucketGroup;
    @Size(max=10, message = "Priority Group cannot have more than 10 characters")
    private String priorityGroup;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getBucketId() {
        return bucketId;
    }

    public void setBucketId(String bucketId) {
        this.bucketId = bucketId;
    }

    public String getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(String activeFlag) {
        this.activeFlag = activeFlag;
    }

    public String getMeasureUnit() {
        return measureUnit;
    }

    public void setMeasureUnit(String measureUnit) {
        this.measureUnit = measureUnit;
    }

    public String getBucketDesc() {
        return bucketDesc;
    }

    public void setBucketDesc(String bucketDesc) {
        this.bucketDesc = bucketDesc;
    }

    public String getBucketType() {
        return bucketType;
    }

    public void setBucketType(String bucketType) {
        this.bucketType = bucketType;
    }

    public String getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(String ratePlan) {
        this.ratePlan = ratePlan;
    }

    public String getSuiDisplayType() {
        return suiDisplayType;
    }

    public void setSuiDisplayType(String suiDisplayType) {
        this.suiDisplayType = suiDisplayType;
    }

    public String getBucketGroup() {
        return bucketGroup;
    }

    public void setBucketGroup(String bucketGroup) {
        this.bucketGroup = bucketGroup;
    }

    public String getPriorityGroup() {
        return priorityGroup;
    }

    public void setPriorityGroup(String priorityGroup) {
        this.priorityGroup = priorityGroup;
    }

    @Override
    public String toString() {
        return "TracfoneOneBucket{" + "dbEnv=" + dbEnv + ", "
                + "bucketId=" + bucketId + ", "
                + "activeFlag=" + activeFlag + ", "
                + "measureUnit=" + measureUnit + ", "
                + "bucketDesc=" + bucketDesc + ", "
                + "bucketType=" + bucketType + ", "
                + "ratePlan=" + ratePlan + ", "
                + "suiDisplayType=" + suiDisplayType + ", "
                + "bucketGroup=" + bucketGroup + ", "
                + "priorityGroup=" + priorityGroup + '}';
    }
}
