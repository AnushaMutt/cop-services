package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneCarrierOutage;
import com.tracfone.service.model.request.TracfoneOneServiceType;
import com.tracfone.service.model.response.TFOneCarrierOutage;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneServiceType;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantCarrierOutage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Stateless
public class TracfoneOneCarrierOutageAction implements TracfoneOneCarrierOutageLocalAction, TracfoneOneConstantCarrierOutage, TracfoneOneConstant {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneCarrierOutageAction.class);
    private static final String AND = " AND ";

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @EJB
    DataBaseController dbControllerEJB;

    @Override
    public List<TFOneCarrierOutage> searchCarrierOutage(TracfoneOneCarrierOutage tracfoneOneCarrierOutage) throws TracfoneOneException {
        List<TFOneCarrierOutage> carrierOutages = new ArrayList<>();

        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierOutage.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(searchCarrierOutageStatement(TRACFONE_SEARCH_CARRIER_OUTAGE, tracfoneOneCarrierOutage));) {
            setSearchCarrierOutageStatement(stmt, tracfoneOneCarrierOutage);

            TFOneCarrierOutage carrierOutage;
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    carrierOutage = setOneCarrierOutage(resultSet);
                    carrierOutages.add(carrierOutage);
                }
            }

            if (tracfoneOneCarrierOutage.isShowArchivedOutage()) {
                try (PreparedStatement archivedStmt = con.prepareStatement(searchCarrierOutageStatement(TRACFONE_SEARCH_CARRIER_OUTAGE_ARCHIVE, tracfoneOneCarrierOutage))) {
                    setSearchCarrierOutageStatement(archivedStmt, tracfoneOneCarrierOutage);
                    try (ResultSet resultSet = archivedStmt.executeQuery()) {
                        while (resultSet.next()) {
                            carrierOutage = setOneCarrierOutage(resultSet);
                            carrierOutage.setArchived(true);
                            carrierOutages.add(carrierOutage);
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return carrierOutages;
    }

    private TFOneCarrierOutage setOneCarrierOutage(ResultSet resultSet) throws SQLException {
        TFOneCarrierOutage carrierOutage;
        carrierOutage = new TFOneCarrierOutage();
        carrierOutage.setObjId(resultSet.getString("OBJID"));
        carrierOutage.setParentShortName(resultSet.getString("PARENT_SHORT_NAME"));
        carrierOutage.setBrand(resultSet.getString("BRAND"));
        carrierOutage.setChannel(resultSet.getString("CHANNEL"));
        carrierOutage.setZipCode(resultSet.getString("ZIPCODE"));
        carrierOutage.setServiceType(resultSet.getString(SERVICE_TYPE));
        carrierOutage.setOutageType(resultSet.getString("OUTAGE_TYPE"));
        carrierOutage.setStartTime(resultSet.getString("START_TIME"));
        carrierOutage.setEndTime(resultSet.getString("END_TIME"));
        carrierOutage.setCreatedBy(resultSet.getString("CREATED_BY"));
        carrierOutage.setScriptId(resultSet.getString("SCRIPT_ID"));
        carrierOutage.setScriptText(resultSet.getString("X_SCRIPT_TEXT"));
        carrierOutage.setOutageDescription(resultSet.getString("OUTAGE_DESCRIPTION"));
        LOGGER.info("TFOneCarrierOutage - " + carrierOutage);
        return carrierOutage;
    }

    private int setSearchCarrierOutageStatement(PreparedStatement stmt, TracfoneOneCarrierOutage tracfoneOneCarrierOutage) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getParentShortName())) {
            stmt.setString(index++, tracfoneOneCarrierOutage.getParentShortName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getBrand())) {
            stmt.setString(index++, "%" + tracfoneOneCarrierOutage.getBrand() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getScriptId())) {
            stmt.setString(index++, "%" + tracfoneOneCarrierOutage.getScriptId() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getCreatedBy())) {
            stmt.setString(index++, tracfoneOneCarrierOutage.getCreatedBy());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getStartTime())) {
            stmt.setString(index++, tracfoneOneCarrierOutage.getStartTime());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getEndTime())) {
            stmt.setString(index++, tracfoneOneCarrierOutage.getEndTime());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getOutageDescription())) {
            stmt.setString(index++, "%" + tracfoneOneCarrierOutage.getOutageDescription().toUpperCase() + "%");
        }
        return index;
    }

    private String searchCarrierOutageStatement(String query, TracfoneOneCarrierOutage tracfoneOneCarrierOutage) {
        StringBuilder builder = new StringBuilder(query);
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getParentShortName())) {
            builder.append("PARENT_SHORT_NAME = ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getBrand())) {
            builder.append("BRAND LIKE ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getScriptId())) {
            builder.append("SCRIPT_ID LIKE ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getCreatedBy())) {
            builder.append("CREATED_BY = ? ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getStartTime())) {
            builder.append("START_TIME >= to_date(? ,'mm/dd/yyyy hh24:mi:ss') ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getEndTime())) {
            builder.append("END_TIME <= to_date(? ,'mm/dd/yyyy hh24:mi:ss') ").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getOutageDescription())) {
            builder.append("UPPER(OUTAGE_DESCRIPTION) LIKE ? ").append(AND);
        }
        LOGGER.info("Search Query for Carrier Outage " + builder);
        return builder.substring(0, builder.lastIndexOf(AND));
    }

    @Override
    public void insertCarrierOutage(TracfoneOneCarrierOutage tracfoneOneCarrierOutage, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierOutage.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_CARRIER_OUTAGE);) {

            for (String zip : tracfoneOneCarrierOutage.getZipCode().split(",")) {
                tracfoneOneCarrierOutage.setZipCode(zip);
                setCarrierOutageQueryParams(stmt, tracfoneOneCarrierOutage);
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Carrier Outage", "Inserted Carrier Outage " + tracfoneOneCarrierOutage, null);
            tracfoneAuditEvent.fire(audit);
        }
    }

    private void setCarrierOutageQueryParams(PreparedStatement stmt, TracfoneOneCarrierOutage tracfoneOneCarrierOutage) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneCarrierOutage.getParentShortName());
        stmt.setString(index++, tracfoneOneCarrierOutage.getBrand());
        stmt.setString(index++, tracfoneOneCarrierOutage.getChannel());
        stmt.setString(index++, tracfoneOneCarrierOutage.getZipCode());
        stmt.setString(index++, tracfoneOneCarrierOutage.getServiceType());
        stmt.setString(index++, tracfoneOneCarrierOutage.getOutageType());
        stmt.setString(index++, tracfoneOneCarrierOutage.getStartTime());
        stmt.setString(index++, tracfoneOneCarrierOutage.getEndTime());
        stmt.setString(index++, tracfoneOneCarrierOutage.getCreatedBy());
        stmt.setString(index++, tracfoneOneCarrierOutage.getScriptId());
        stmt.setString(index++, tracfoneOneCarrierOutage.getScriptText());
        stmt.setString(index, tracfoneOneCarrierOutage.getOutageDescription());
    }

    @Override
    public TFOneGeneralResponse updateCarrierOutage(TracfoneOneCarrierOutage tracfoneOneCarrierOutage, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierOutage.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_CARRIER_OUTAGE);
             CallableStatement spStmt = con.prepareCall("{ call sa.CARRIER_OUTAGE_DTLS_ARCH_PRC() }");) {
            int index = 1;
            stmt.setString(index++, tracfoneOneCarrierOutage.getEndTime());
            stmt.setString(index++, tracfoneOneCarrierOutage.getServiceType());
            stmt.setString(index++, tracfoneOneCarrierOutage.getOutageType());
            stmt.setString(index++, tracfoneOneCarrierOutage.getBrand());
            stmt.setString(index++, tracfoneOneCarrierOutage.getChannel());
            if (tracfoneOneCarrierOutage.getOutageDescription() != null) {
                stmt.setString(index++, tracfoneOneCarrierOutage.getOutageDescription());
            } else {
                stmt.setNull(index++, Types.VARCHAR);
            }
            stmt.setLong(index++, Long.parseLong(tracfoneOneCarrierOutage.getObjId()));
            stmt.executeQuery();
            spStmt.execute();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Carrier Outage", "Updated Carrier Outage " + tracfoneOneCarrierOutage, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneCarrierOutage.getObjId());
    }

    @Override
    public List<String> findDuplicateCarrierOutageZips(TracfoneOneCarrierOutage tracfoneOneCarrierOutage) throws TracfoneOneException {
        List<String> duplicateZipCodes = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierOutage.getDbEnv()).getConnection();
             PreparedStatement stmtZipCode = con.prepareStatement(getDuplicateCheckQuery(tracfoneOneCarrierOutage));) {

            int index = 1;
            stmtZipCode.setString(index++, tracfoneOneCarrierOutage.getParentShortName());
            stmtZipCode.setString(index++, "%" + tracfoneOneCarrierOutage.getBrand() + "%");
            stmtZipCode.setString(index++, "%" + tracfoneOneCarrierOutage.getChannel() + "%");
            stmtZipCode.setString(index++, tracfoneOneCarrierOutage.getOutageType());
            stmtZipCode.setString(index++, "%" + tracfoneOneCarrierOutage.getServiceType() + "%");
            stmtZipCode.setString(index++, tracfoneOneCarrierOutage.getStartTime());
            if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getZipCode())) {
                for (String zip : tracfoneOneCarrierOutage.getZipCode().split(",")) {
                    stmtZipCode.setString(index++, zip);
                }
            }

            try (ResultSet resultSet = stmtZipCode.executeQuery()) {
                while (resultSet.next()) {
                    duplicateZipCodes.add(resultSet.getString("ZIPCODE"));
                }
            }
        } catch (NamingException | SQLException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        LOGGER.info("All duplicate Zip Codes: " + duplicateZipCodes);
        return duplicateZipCodes;
    }

    private String getDuplicateCheckQuery(TracfoneOneCarrierOutage tracfoneOneCarrierOutage) {
        StringBuilder builder = new StringBuilder(TRACFONE_GET_DUPLICATE_CARRIER_OUTAGE);
        if (!StringUtils.isNullOrEmpty(tracfoneOneCarrierOutage.getZipCode())) {
            builder.append(" and ZIPCODE in (?")
                    .append(buildInClauseQuery(tracfoneOneCarrierOutage.getZipCode().split(",").length, ""));
        }
        LOGGER.info("Query for duplicate check is " + builder.toString());
        return builder.toString();
    }

    @Override
    public TFOneGeneralResponse bulkUpdateOutages(TracfoneOneCarrierOutage tracfoneOneCarrierOutage, int userId) throws TracfoneOneException {
        String[] allObjIds = tracfoneOneCarrierOutage.getObjIds().split(",");
        LOGGER.info("All OBJID is : " + allObjIds);
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneCarrierOutage.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(buildInClauseQuery(allObjIds.length, TRACFONE_BULK_UPDATE_END_TIME));
             CallableStatement spStmt = con.prepareCall("{ call sa.CARRIER_OUTAGE_DTLS_ARCH_PRC() }")) {
            int index = 1;
            stmt.setString(index++, tracfoneOneCarrierOutage.getEndTime());
            for (String objId : allObjIds) {
                stmt.setString(index++, objId);
            }
            stmt.executeQuery();
            spStmt.execute();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Bulk Update Carrier Outage",
                    "Bulk Updated Carrier Outage " + tracfoneOneCarrierOutage, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, String.valueOf(allObjIds.length));
    }

    @Override
    public List<TFOneServiceType> viewAllServiceTypes(TracfoneOneServiceType tracfoneOneServiceType) throws TracfoneOneException {
        List<TFOneServiceType> tfOneServiceTypes = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneServiceType.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getServiceTypeQuery(tracfoneOneServiceType));) {
            if (!StringUtils.isNullOrEmpty(tracfoneOneServiceType.getServiceType())) {
                stmt.setString(1, tracfoneOneServiceType.getServiceType().toLowerCase());
            }
            try (ResultSet resultSet = stmt.executeQuery();) {
                TFOneServiceType tfOneServiceType;
                while (resultSet.next()) {
                    tfOneServiceType = new TFOneServiceType();
                    tfOneServiceType.setObjId(resultSet.getString("OBJID"));
                    tfOneServiceType.setServiceType(resultSet.getString(SERVICE_TYPE));
                    tfOneServiceType.setServiceTypeCategory(resultSet.getString("SERVICE_TYPE_CATEGORY"));
                    tfOneServiceType.setRemarks(resultSet.getString("REMARKS"));
                    tfOneServiceTypes.add(tfOneServiceType);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneServiceTypes;
    }

    @Override
    public TFOneGeneralResponse insertServiceType(TracfoneOneServiceType tracfoneOneServiceType, int userId) throws TracfoneOneException {
        String serviceTypeId = "";
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneServiceType.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_SERVICE_TYPE);) {
            serviceTypeId = getNextObjId(con);
            tracfoneOneServiceType.setObjId(serviceTypeId);
            setServiceTypeQueryParams(stmt, tracfoneOneServiceType, false);

            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Service Type", "Inserted Service Type Object " + tracfoneOneServiceType, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneServiceType.getObjId());
    }

    @Override
    public TFOneGeneralResponse updateServiceType(TracfoneOneServiceType tracfoneOneServiceType, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneServiceType.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_SERVICE_TYPE);) {
            setServiceTypeQueryParams(stmt, tracfoneOneServiceType, true);
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Service Type", "Updated Service Type Object " + tracfoneOneServiceType, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneServiceType.getObjId());
    }

    @Override
    public TFOneGeneralResponse deleteServiceType(TracfoneOneServiceType tracfoneOneServiceType, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneServiceType.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_SERVICE_TYPE);) {
            stmt.setString(1, tracfoneOneServiceType.getObjId());
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Service Type", "Deleted Service Type wiht ObjId " + tracfoneOneServiceType.getObjId(), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneServiceType.getObjId());
    }

    private void setServiceTypeQueryParams(PreparedStatement stmt, TracfoneOneServiceType tracfoneOneServiceType, boolean isUpate) throws SQLException {
        int index = 1;
        if (!isUpate) {
            stmt.setLong(index++, Long.valueOf(tracfoneOneServiceType.getObjId()));
        }
        stmt.setString(index++, tracfoneOneServiceType.getServiceType());
        stmt.setString(index++, tracfoneOneServiceType.getServiceTypeCategory());
        if (!StringUtils.isNullOrEmpty(tracfoneOneServiceType.getRemarks())) {
            stmt.setString(index++, tracfoneOneServiceType.getRemarks());
        } else {
            stmt.setNull(index++, Types.VARCHAR);
        }
        if (isUpate) {
            stmt.setLong(index, Long.valueOf(tracfoneOneServiceType.getObjId()));
        }
    }

    private String getNextObjId(Connection con) throws SQLException {
        String serviceTypeObjId = null;
        try (PreparedStatement stmt = con.prepareStatement(TRACFONE_MAX_SERVICE_TYPE_OBJID);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                long objid = resultSet.getLong("objid");
                serviceTypeObjId = String.valueOf(objid + 1);
            }
        }
        return serviceTypeObjId;
    }

    @Override
    public boolean checkServiceTypeDependencies(TracfoneOneServiceType tracfoneOneServiceType) throws TracfoneOneException {
        boolean dependencyExists = false;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneServiceType.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_CHECK_SERVICE_PLANS_OUTAGE);) {
            stmt.setString(1, "%" + tracfoneOneServiceType.getServiceType().toLowerCase() + "%");
            List<String> serviceTypes = new ArrayList<>();
            try (ResultSet resultSet = stmt.executeQuery();) {
                LOGGER.info("What am I searching for? " + tracfoneOneServiceType.getServiceType().toLowerCase());
                while (resultSet.next()) {
                    serviceTypes.add(resultSet.getString(SERVICE_TYPE));
                }
            }
            LOGGER.info("How many Service Types have been found? " + serviceTypes);
            if (!serviceTypes.isEmpty() && null != serviceTypes.stream()
                    .filter(s -> Arrays.asList(s.split(",")).contains(tracfoneOneServiceType.getServiceType()))
                    .findAny()
                    .orElse(null)) {
                dependencyExists = true;
                LOGGER.info("DEPENDENCY EXISTS FOR " + tracfoneOneServiceType.getServiceType());
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return dependencyExists;
    }

    private String getServiceTypeQuery(TracfoneOneServiceType tracfoneOneServiceType) {
        StringBuilder builder = new StringBuilder(TRACFONE_GET_ALL_SERVICE_TYPES);
        if (!StringUtils.isNullOrEmpty(tracfoneOneServiceType.getServiceType())) {
            builder.append(" where lower(SERVICE_TYPE) = ? ");
        }
        builder.append(" order by SERVICE_TYPE");
        LOGGER.info("Query with WHERE clause to get all service types " + builder.toString());
        return builder.toString();
    }

    private String buildInClauseQuery(int length, String query) {
        StringBuilder builder = new StringBuilder(query);
        if (length != 1) {
            int index = 1;
            while (index < length) {
                builder.append(", ?");
                index++;
            }
        }
        builder.append(")");
        LOGGER.info("Query with IN Clause is " + builder);
        return builder.toString();
    }

}
