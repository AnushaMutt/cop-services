package com.tracfone.service.model.report;

/**
 * @author Gaurav.Sharma
 */
public class TFOneReportTTGraphReport {

    private String template;
    private String orderType;
    private String count;
    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    @Override
    public String toString() {
        return "TFOneReportTTGraphReport{" +
                "template='" + template + '\'' +
                ", orderType='" + orderType + '\'' +
                ", count='" + count + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
