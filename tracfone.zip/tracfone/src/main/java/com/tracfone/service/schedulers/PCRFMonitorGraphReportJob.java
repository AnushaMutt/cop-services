package com.tracfone.service.schedulers;

import com.google.gson.Gson;
import com.tracfone.service.model.event.TracfoneOneReportRequest;
import com.tracfone.service.model.report.TFOneReportPCRFGraphReport;
import com.tracfone.service.report.workers.pcrf.MonitorPCRFGraphWorkerBean;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Singleton
public class PCRFMonitorGraphReportJob {

    @EJB
    MonitorPCRFGraphWorkerBean pcrfGraphWorkerBean;

    @Inject
    private Event<TracfoneOneReportRequest> tracfoneOneConstantReportEvent;

    private static final Logger LOGGER = LogManager.getLogger(PCRFMonitorGraphReportJob.class);

//    @Schedule(second = "*/50", minute = "*", hour = "*", persistent = false)
    public void runPCRFMonitorGraphReport() {
        try {
            List<TFOneReportPCRFGraphReport> pcrfMonitorGraphReport = new ArrayList<>();
//                    List<TFOneReportPCRFGraphReport> pcrfMonitorGraphReport = pcrfGraphWorkerBean.runPCRFMonitorGraphReport();

            if (!pcrfMonitorGraphReport.isEmpty()) {
                Gson gson = new Gson();
                TracfoneOneReportRequest reportRequest = new TracfoneOneReportRequest();
                reportRequest.setJsonResponse(gson.toJson(pcrfMonitorGraphReport));
                reportRequest.setReportName(TracfoneOneConstantReport.TRACFONE_REPORTNAME_PCRF_MONITOR_GRAPH);
                tracfoneOneConstantReportEvent.fire(reportRequest);

            } else {
                LOGGER.info("PCRF Monitor Graph WorkerBean returned an empty response.");
            }
        } catch (Exception ex) {
            LOGGER.error("PCRF Monitor Graph report could not be retrieved because of an exception ", ex);
        }
    }
}
