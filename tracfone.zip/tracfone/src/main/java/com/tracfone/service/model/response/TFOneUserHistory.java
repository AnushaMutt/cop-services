/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

import java.util.Date;
import java.util.List;

/**
 * @author Pritesh.Singh
 */
public class TFOneUserHistory {

    private String id;
    private String UserId;
    private String type;
    private String creationDate;
    private List<TFOneUserHistoryDetail> tfUserHistoryDetail;

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) { this.creationDate = creationDate; }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return UserId;
    }

    public void setUserId(String UserId) {
        this.UserId = UserId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<TFOneUserHistoryDetail> getTfUserHistoryDetail() {
        return tfUserHistoryDetail;
    }

    public void setTfUserHistoryDetail(List<TFOneUserHistoryDetail> tfUserHistoryDetail) { this.tfUserHistoryDetail = tfUserHistoryDetail; }

    @Override
    public String toString() {
        return "TFOneUserHistory{" +
                ", id='" + id + '\'' +
                ", UserId='" + UserId + '\'' +
                ", type='" + type + '\'' +
                ", creationDate=" + creationDate +
                ", tfUserHistoryDetail=" + tfUserHistoryDetail +
                '}';
    }
}
