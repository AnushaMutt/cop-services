package com.tracfone.service.model.response;

import com.tracfone.service.model.request.TracfoneonePaginationSearch;

import java.util.List;

public class TFOneIgFailLogSearchModel {
    private TracfoneonePaginationSearch paginationSearch;
    List<TFOneIGFailLogs> iGFailLogs;

    public TracfoneonePaginationSearch getPaginationSearch() {
        return paginationSearch;
    }

    public void setPaginationSearch(TracfoneonePaginationSearch paginationSearch) {
        this.paginationSearch = paginationSearch;
    }

    public List<TFOneIGFailLogs> getiGFailLogs() {
        return iGFailLogs;
    }

    public void setiGFailLogs(List<TFOneIGFailLogs> iGFailLogs) {
        this.iGFailLogs = iGFailLogs;
    }

    @Override
    public String toString() {
        return "TFOneIgFailLogSearchModel{" +
                "paginationSearch=" + paginationSearch +
                ", iGFailLogs=" + iGFailLogs +
                '}';
    }
}
