/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneBucket;
import com.tracfone.service.model.request.TracfoneOneBucketList;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileBucketTier;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildBucket;
import com.tracfone.service.model.request.TracfoneOneCarrierProfileChildTier;
import com.tracfone.service.model.request.TracfoneOneSearchBucketModel;
import com.tracfone.service.model.response.TFOneBucket;
import com.tracfone.service.model.response.TFOneBucketList;
import com.tracfone.service.model.response.TFOneCarrierProfileBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileBucketTier;
import com.tracfone.service.model.response.TFOneCarrierProfileChildBucket;
import com.tracfone.service.model.response.TFOneCarrierProfileChildTier;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneRatePlan;
import com.tracfone.service.util.TracfoneOneConstantPlanWizard;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Shireen Fathima
 */
@Stateless
public class TracfoneBucketController implements TracfoneBucketControllerLocal, TracfoneOneConstantPlanWizard {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneBucketController.class);

    @EJB
    TracfoneBucketLocalAction tracfoneBucketAction;

    @Override
    public TFOneGeneralResponse insertLegacyBucket(List<TracfoneOneBucket> tfBuckets, String parentShortName, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        Map<String, TracfoneOneBucketList> bucketListMap = new HashMap<>();
        TracfoneOneBucketList bucketList;
        for (TracfoneOneBucket tfBucket : tfBuckets) {
            bucketList = new TracfoneOneBucketList();
            bucketList.setDbEnv(tfBucket.getDbEnv());
            bucketList.setBucketId(tfBucket.getBucketId());
            bucketList.setDescription(tfBucket.getBucketDesc());
            bucketList.setActiveFlag("Y");
            bucketList.setParentShortName(parentShortName);
            bucketListMap.put(bucketList.getBucketId(), bucketList);
        }
        try {
            viewAndInsertBucketList(tfBuckets.get(0).getDbEnv(), bucketListMap, userId);
            response = tracfoneBucketAction.insertLegacyBucket(tfBuckets, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_IG_BUCKET_ERROR, TRACFONE_ADD_IG_BUCKET_ERROR_MESSAGE, ex);
        }

        return response;
    }

    private void viewAndInsertBucketList(String dbEnv, Map<String, TracfoneOneBucketList> bucketListMap, int userId) throws TracfoneOneException {
        LOGGER.info("Total Bucket Ids " + bucketListMap.keySet());
        List<String> existingBucketIds = tracfoneBucketAction.getBucketListByBucketIds(bucketListMap.keySet(), dbEnv);
        LOGGER.info("Total existing Bucket Ids " + existingBucketIds);
        for (String existingBucketId : existingBucketIds) {
            bucketListMap.remove(existingBucketId);
        }
        LOGGER.info("Total Buckets to be added in DB with Bucket id " + bucketListMap.keySet());
        if (!bucketListMap.isEmpty()) {
            tracfoneBucketAction.insertBucketList(bucketListMap.values(), userId);
        }
    }

    @Override
    public List<TracfoneOneBucketList> getAllBucketList(String dbEnv) throws TracfoneOneException {
        List<TracfoneOneBucketList> tracfoneOneBucketLists = null;
        try {
            tracfoneOneBucketLists = tracfoneBucketAction.getAllBucketList(dbEnv);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_BUCKETS_ERROR, TRACFONE_GET_BUCKETS_ERROR_MESSAGE, ex);
        }
        return tracfoneOneBucketLists;
    }

    @Override
    public TFOneGeneralResponse updateIgBucket(TracfoneOneBucket tfOneIgBucket, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneBucketAction.updateIgBucket(tfOneIgBucket, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_IG_BUCKET_ERROR, TRACFONE_UPDATE_IG_BUCKET_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public List<TFOneBucket> searchIgBuckets(TracfoneOneSearchBucketModel tfOneSearchBucketModel) throws TracfoneOneException {
        List<TFOneBucket> tracfoneOneBuckets = null;
        try {
            tracfoneOneBuckets = tracfoneBucketAction.searchIgBuckets(tfOneSearchBucketModel);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_IG_BUCKETS_ERROR, TRACFONE_SEARCH_IG_BUCKETS_ERROR_MESSAGE, ex);
        }
        return tracfoneOneBuckets;
    }

    @Override
    public List<TFOneCarrierProfileBucket> searchCarrierProfileBuckets(TracfoneOneSearchBucketModel tfOneSearchBucketModel) throws TracfoneOneException {
        List<TFOneCarrierProfileBucket> tracfoneOneCarrierProfileBuckets = null;
        try {
            tracfoneOneCarrierProfileBuckets = tracfoneBucketAction.searchCarrierProfileBuckets(tfOneSearchBucketModel);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_CP_BUCKETS_ERROR, TRACFONE_SEARCH_CP_BUCKETS_ERROR_MESSAGE, ex);
        }
        return tracfoneOneCarrierProfileBuckets;
    }

    @Override
    public TFOneGeneralResponse deleteIgBucket(TracfoneOneBucket tfBucket, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            List<String> idToBeDeleted = new ArrayList<>();
            idToBeDeleted.add(tfBucket.getBucketId());
            response = tracfoneBucketAction.deleteIgBucket(tfBucket.getDbEnv(), tfBucket.getRatePlan(), idToBeDeleted, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_IG_BUCKET_ERROR, TRACFONE_DELETE_IG_BUCKET_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public List<TFOneCarrierProfileChildBucket> searchCarrierProfileChildBuckets(TracfoneOneSearchBucketModel tfOneSearchBucketModel) throws TracfoneOneException {
        List<TFOneCarrierProfileChildBucket> tracfoneOneCarrierProfileChildBuckets = null;
        try {
            tracfoneOneCarrierProfileChildBuckets = tracfoneBucketAction.searchCarrierProfileChildBuckets(tfOneSearchBucketModel);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR, TRACFONE_SEARCH_CP_CHILD_BUCKETS_ERROR_MESSAGE, ex);
        }
        return tracfoneOneCarrierProfileChildBuckets;
    }

    @Override
    public List<TFOneCarrierProfileBucket> insertCarrierProfileBucket(List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets,
                                                                      String parentShortName, int userId) throws TracfoneOneException {
        List<TFOneCarrierProfileBucket> tfOneBuckets = null;
        Map<String, TracfoneOneBucketList> bucketListMap = new HashMap<>();
        TracfoneOneBucketList bucketList;
        for (TracfoneOneCarrierProfileBucket tfBucket : tfCarrierProfileBuckets) {
            bucketList = new TracfoneOneBucketList();
            bucketList.setDbEnv(tfBucket.getDbEnv());
            bucketList.setBucketId(tfBucket.getBucketId());
            bucketList.setDescription(tfBucket.getBucketDesc());
            bucketList.setActiveFlag("Y");
            bucketList.setParentShortName(parentShortName);
            bucketListMap.put(bucketList.getBucketId(), bucketList);
        }
        try {
            viewAndInsertBucketList(tfCarrierProfileBuckets.get(0).getDbEnv(), bucketListMap, userId);
            tfOneBuckets = tracfoneBucketAction.insertCarrierProfileBuckets(tfCarrierProfileBuckets, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_CP_BUCKET_ERROR, TRACFONE_ADD_CP_BUCKET_ERROR_MESSAGE, ex);
        }
        return tfOneBuckets;
    }

    @Override
    public TFOneGeneralResponse updateCarrierProfileBucket(TracfoneOneCarrierProfileBucket tfCarrierProfileBucket, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneBucketAction.updateCarrierProfileBucket(tfCarrierProfileBucket, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_CP_BUCKET_ERROR, TRACFONE_UPDATE_CP_BUCKET_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneGeneralResponse deleteCarrierProfileBucket(List<TracfoneOneCarrierProfileBucket> tfCarrierProfileBuckets, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            List<String> idToBeDeleted = new ArrayList<>();
            for (TracfoneOneCarrierProfileBucket tfCarrierProfileBucket : tfCarrierProfileBuckets) {
                idToBeDeleted.add(tfCarrierProfileBucket.getObjectId());
            }
            response = tracfoneBucketAction.deleteCarrierProfileBuckets(tfCarrierProfileBuckets.get(0).getDbEnv(), idToBeDeleted, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_CP_BUCKET_ERROR, TRACFONE_DELETE_CP_BUCKET_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneGeneralResponse updateCarrierProfileBucketTier(TracfoneOneCarrierProfileBucketTier tfCarrierProfileBucketTier, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneBucketAction.updateCarrierProfileBucketTier(tfCarrierProfileBucketTier, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_CP_BUCKET_TIER_ERROR, TRACFONE_UPDATE_CP_BUCKET_TIER_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneGeneralResponse deleteCarrierProfileBucketTier(TracfoneOneCarrierProfileBucketTier tfCarrierProfileBucketTier, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneBucketAction.deleteCarrierProfileBucketTier(tfCarrierProfileBucketTier, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_CP_BUCKET_TIER_ERROR, TRACFONE_DELETE_CP_BUCKET_TIER_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public List<TFOneCarrierProfileChildBucket> insertCarrierProfileChildBucket(List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets,
                                                                                String parentShortName, int userId) throws TracfoneOneException {
        List<TFOneCarrierProfileChildBucket> tfOneChildBuckets = null;

        Map<String, TracfoneOneBucketList> bucketListMap = new HashMap<>();
        TracfoneOneBucketList bucketList;
        for (TracfoneOneCarrierProfileChildBucket tfBucket : tfCarrierProfileChildBuckets) {
            bucketList = new TracfoneOneBucketList();
            bucketList.setDbEnv(tfBucket.getDbEnv());
            bucketList.setBucketId(tfBucket.getBucketId());
            bucketList.setDescription(tfBucket.getBucketDesc());
            bucketList.setActiveFlag("Y");
            bucketList.setParentShortName(parentShortName);
            bucketListMap.put(bucketList.getBucketId(), bucketList);
        }
        try {
            viewAndInsertBucketList(tfCarrierProfileChildBuckets.get(0).getDbEnv(), bucketListMap, userId);
            tfOneChildBuckets = tracfoneBucketAction.insertCarrierProfileChildBuckets(tfCarrierProfileChildBuckets, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_CP_CHILD_BUCKET_ERROR, TRACFONE_ADD_CP_CHILD_BUCKET_ERROR_MESSAGE, ex);
        }
        return tfOneChildBuckets;
    }

    @Override
    public TFOneGeneralResponse updateCarrierProfileChildBucket(TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneBucketAction.updateCarrierProfileChildBucket(tfCarrierProfileChildBucket, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_CP_CHILD_BUCKET_ERROR, TRACFONE_UPDATE_CP_CHILD_BUCKET_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse deleteCarrierProfileChildBucket(List<TracfoneOneCarrierProfileChildBucket> tfCarrierProfileChildBuckets, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        List<String> idsToBeDeleted = new ArrayList<>();
        for (TracfoneOneCarrierProfileChildBucket tfCarrierProfileChildBucket : tfCarrierProfileChildBuckets) {
            idsToBeDeleted.add(tfCarrierProfileChildBucket.getObjId());
        }
        try {
            response = tracfoneBucketAction.deleteCarrierProfileChildBuckets(tfCarrierProfileChildBuckets.get(0).getDbEnv(), idsToBeDeleted, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_CP_CHILD_BUCKET_ERROR, TRACFONE_DELETE_CP_CHILD_BUCKET_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse updateCarrierProfileChildBucketTier(TracfoneOneCarrierProfileChildTier tfCarrierProfileChildBucketTier, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneBucketAction.updateCarrierProfileChildBucketTier(tfCarrierProfileChildBucketTier, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_CP_CHILD_BUCKET_TIER_ERROR, TRACFONE_UPDATE_CP_CHILD_BUCKET_TIER_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse deleteCarrierProfileChildBucketTier(TracfoneOneCarrierProfileChildTier tfCarrierProfileChildTier, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneBucketAction.deleteCarrierProfileChildBucketTier(tfCarrierProfileChildTier, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_CP_CHILD_BUCKET_TIER_ERROR, TRACFONE_DELETE_CP_CHILD_BUCKET_TIER_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse copyAllBucketsFromProfile(TracfoneOneSearchBucketModel tfOneSearchBucketModel, int userId) throws TracfoneOneException {
        List<TracfoneOneCarrierProfileBucket> profileBuckets = new ArrayList<>();
        List<TracfoneOneCarrierProfileChildBucket> profileChildBuckets = new ArrayList<>();
        try {
            // get all the buckets for a service plan and profile combination
            TracfoneOneSearchBucketModel bucketSearch = new TracfoneOneSearchBucketModel();
            bucketSearch.setDbEnv(tfOneSearchBucketModel.getDbEnv());
            bucketSearch.getServicePlanIds().add(tfOneSearchBucketModel.getServicePlanIds().get(0));
            bucketSearch.getProfileIds().add(tfOneSearchBucketModel.getOldProfileId());
            // copy them over to a new object that has the new profile id
            List<TFOneCarrierProfileBucket> buckets = tracfoneBucketAction.searchCarrierProfileBuckets(bucketSearch);
            LOGGER.info("buckets found for service plan id + " + bucketSearch.getServicePlanIds() +
                    " and profile id " + bucketSearch.getProfileIds() + " is " + buckets);
            if (!buckets.isEmpty()) {
                profileBuckets = copyBuckets(buckets, tfOneSearchBucketModel.getProfileIds().get(0), tfOneSearchBucketModel.getDbEnv());
                LOGGER.info("buckets copied and ready to be inserted " + profileBuckets);
                tracfoneBucketAction.insertCarrierProfileBuckets(profileBuckets, userId);
            }
            List<TFOneCarrierProfileChildBucket> childBuckets = tracfoneBucketAction.searchCarrierProfileChildBuckets(bucketSearch);
            LOGGER.info("child buckets found for service plan id + " + bucketSearch.getServicePlanIds() +
                    " and profile id " + bucketSearch.getProfileIds() + " is " + childBuckets);
            if (!childBuckets.isEmpty()) {
                profileChildBuckets = copyChildBuckets(childBuckets, tfOneSearchBucketModel.getProfileIds().get(0), tfOneSearchBucketModel.getDbEnv());
                LOGGER.info("child buckets copied and ready to be inserted " + profileChildBuckets);
                tracfoneBucketAction.insertCarrierProfileChildBuckets(profileChildBuckets, userId);
            }
        } catch (Exception ex) {
            LOGGER.error(ex);
            if (!profileBuckets.isEmpty()) {
                LOGGER.info("Deleting newly created buckets " + profileBuckets);
                deleteCarrierProfileBucket(profileBuckets, userId);
            }
            if (!profileChildBuckets.isEmpty()) {
                LOGGER.info("Deleting newly created child buckets " + profileChildBuckets);
                deleteCarrierProfileChildBucket(profileChildBuckets, userId);
            }
            throw new TracfoneOneException(TRACFONE_COPY_BUCKETS_ERROR, TRACFONE_COPY_BUCKETS_ERROR_MESSAGE, ex);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TFOneGeneralResponse.SUCCESS);
    }

    private List<TracfoneOneCarrierProfileChildBucket> copyChildBuckets(List<TFOneCarrierProfileChildBucket> childBuckets, String profileId, String dbEnv) {
        List<TracfoneOneCarrierProfileChildBucket> profileChildBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileChildBucket profileChildBucket;
        for (TFOneCarrierProfileChildBucket childBucket : childBuckets) {
            profileChildBucket = new TracfoneOneCarrierProfileChildBucket();
            profileChildBucket.setDbEnv(dbEnv);
            profileChildBucket.setServicePlanId(childBucket.getServicePlanId());
            profileChildBucket.setProfileId(profileId);
            profileChildBucket.setChildPlanId(childBucket.getChildPlanId());
            profileChildBucket.setBucketId(childBucket.getBucketId());
            profileChildBucket.setActiveFlag(childBucket.getActiveFlag());
            profileChildBucket.setAutoRenewDay(childBucket.getAutoRenewDay());
            profileChildBucket.setAutoRenewFlag(childBucket.getAutoRenewFlag());
            profileChildBucket.setAutoRenewFrequency(childBucket.getAutoRenewFrequency());
            profileChildBucket.setAutoRenewValue(childBucket.getAutoRenewValue());
            profileChildBucket.setBenefitType(childBucket.getBenefitType());
            profileChildBucket.setBucketGroup(childBucket.getBucketGroup());
            profileChildBucket.setBucketRequirement(childBucket.getBucketRequirement());
            profileChildBucket.setBucketType(childBucket.getBucketType());
            profileChildBucket.setBucketValue(childBucket.getBucketValue());
            profileChildBucket.setHideUbiFlag(childBucket.getHideUbiFlag());
            profileChildBucket.setPriority(childBucket.getPriority());
            profileChildBucket.setUnitOfMeasure(childBucket.getUnitOfMeasure());
            if (!childBucket.getTfOneCarrierProfileChildTiers().isEmpty()) {
                profileChildBucket.setTracfoneOneCarrierProfileChildTiers(copyChildBucketTiers(childBucket.getTfOneCarrierProfileChildTiers()));
            }
            profileChildBuckets.add(profileChildBucket);
        }
        return profileChildBuckets;
    }

    private List<TracfoneOneCarrierProfileChildTier> copyChildBucketTiers(List<TFOneCarrierProfileChildTier> tfOneCarrierProfileChildTiers) {
        List<TracfoneOneCarrierProfileChildTier> profileChildTiers = new ArrayList<>();
        TracfoneOneCarrierProfileChildTier profileChildTier;
        for (TFOneCarrierProfileChildTier childTier : tfOneCarrierProfileChildTiers) {
            profileChildTier = new TracfoneOneCarrierProfileChildTier();
            profileChildTier.setUsageTierId(childTier.getUsageTierId());
            profileChildTier.setTierBehavior(childTier.getTierBehavior());
            profileChildTier.setTierDescription(childTier.getTierDescription());
            profileChildTier.setTierValue(childTier.getTierValue());
            profileChildTiers.add(profileChildTier);
        }
        return profileChildTiers;
    }

    private List<TracfoneOneCarrierProfileBucket> copyBuckets(List<TFOneCarrierProfileBucket> buckets, String profileId, String dbEnv) {
        List<TracfoneOneCarrierProfileBucket> profileBuckets = new ArrayList<>();
        TracfoneOneCarrierProfileBucket profileBucket;
        for (TFOneCarrierProfileBucket bucket : buckets) {
            profileBucket = new TracfoneOneCarrierProfileBucket();
            profileBucket.setDbEnv(dbEnv);
            profileBucket.setServicePlanId(bucket.getServicePlanId());
            profileBucket.setProfileId(profileId);
            profileBucket.setBucketId(bucket.getBucketId());
            profileBucket.setActiveFlag(bucket.getActiveFlag());
            profileBucket.setAutoRenewDay(bucket.getAutoRenewDay());
            profileBucket.setAutoRenewFlag(bucket.getAutoRenewFlag());
            profileBucket.setAutoRenewFrequency(bucket.getAutoRenewFrequency());
            profileBucket.setAutoRenewValue(bucket.getAutoRenewValue());
            profileBucket.setBenefitType(bucket.getBenefitType());
            profileBucket.setBucketGroup(bucket.getBucketGroup());
            profileBucket.setBucketRequirement(bucket.getBucketRequirement());
            profileBucket.setBucketType(bucket.getBucketType());
            profileBucket.setBucketValue(bucket.getBucketValue());
            profileBucket.setHideUbiFlag(bucket.getHideUbiFlag());
            profileBucket.setPriority(bucket.getPriority());
            profileBucket.setUnitOfMeasure(bucket.getUnitOfMeasure());
            if (!bucket.getTfOneCarrierProfileBucketTiers().isEmpty()) {
                profileBucket.setTracfoneOneCarrierProfileBucketTiers(copyBucketTiers(bucket.getTfOneCarrierProfileBucketTiers()));
            }
            profileBuckets.add(profileBucket);
        }
        return profileBuckets;
    }

    private List<TracfoneOneCarrierProfileBucketTier> copyBucketTiers(List<TFOneCarrierProfileBucketTier> tfOneCarrierProfileBucketTiers) {
        List<TracfoneOneCarrierProfileBucketTier> profileBucketTiers = new ArrayList<>();
        TracfoneOneCarrierProfileBucketTier profileBucketTier;
        for (TFOneCarrierProfileBucketTier bucketTier : tfOneCarrierProfileBucketTiers) {
            profileBucketTier = new TracfoneOneCarrierProfileBucketTier();
            profileBucketTier.setUsageTierId(bucketTier.getUsageTierId());
            profileBucketTier.setTierBehavior(bucketTier.getTierBehavior());
            profileBucketTier.setTierDescription(bucketTier.getTierDescription());
            profileBucketTier.setTierValue(bucketTier.getTierValue());
            profileBucketTiers.add(profileBucketTier);
        }
        return profileBucketTiers;
    }

    @Override
    public TFOneGeneralResponse deleteAllBucketsAndTiers(TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneBucketAction.deleteAllBucketsAndTiers(tracfoneOneSearchBucketModel, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_ALL_BUCKETS_ERROR, TRACFONE_DELETE_ALL_BUCKETS_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse updateAllBucketsWithProfileId(TracfoneOneSearchBucketModel tracfoneOneSearchBucketModel, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneBucketAction.updateAllBucketsWithProfileId(tracfoneOneSearchBucketModel, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_PROFILE_ON_BUCKETS_ERROR, TRACFONE_UPDATE_PROFILE_ON_BUCKETS_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public List<TFOneRatePlan> getIgBucketRatePlans(String dbEnv) throws TracfoneOneException {
        List<TFOneRatePlan> tfOneRatePlans = new ArrayList<>();
        try {
            tfOneRatePlans = tracfoneBucketAction.getIgBucketRatePlans(dbEnv);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_ADD_RATE_PLAN_ERROR, TRACFONE_ADD_RATE_PLAN_ERROR_MESSAGE, ex);
        }

        return tfOneRatePlans;
    }

    @Override
    public TFOneGeneralResponse insertBucketList(List<TracfoneOneBucketList> tracfoneOneBucketLists, int userId) throws TracfoneOneException {
        validateBucketIdExist(tracfoneOneBucketLists.get(0));
        try {
            tracfoneBucketAction.insertBucketList(tracfoneOneBucketLists, userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_BUCKET_LIST_ERROR, TRACFONE_ADD_BUCKET_LIST_ERROR_MESSAGE, ex);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tracfoneOneBucketLists.get(0).getBucketId());
    }

    private void validateBucketIdExist(TracfoneOneBucketList tracfoneOneBucketList) throws TracfoneOneException {
        if (tracfoneBucketAction.validateBucketIdExist(tracfoneOneBucketList)) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_BUCKET_ID_ERROR, TRACFONE_DUPLICATE_BUCKET_ID_ERROR_MESSAGE);
        }
    }

    @Override
    public TFOneGeneralResponse updateBucketList(TracfoneOneBucketList tfOneBucketList, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneBucketAction.updateBucketList(tfOneBucketList, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_BUCKET_LIST_ERROR, TRACFONE_UPDATE_BUCKET_LIST_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<TFOneBucketList> searchBucketList(TracfoneOneBucketList tracfoneOneBucketList) throws TracfoneOneException {
        List<TFOneBucketList> tfOneBucketLists = null;
        try {
            tfOneBucketLists = tracfoneBucketAction.searchBucketList(tracfoneOneBucketList);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_BUCKET_LIST_ERROR, TRACFONE_SEARCH_BUCKET_LIST_ERROR_MESSAGE, ex);
        }
        return tfOneBucketLists;
    }

    @Override
    public TFOneGeneralResponse deleteBucketList(TracfoneOneBucketList tracfoneOneBucketList, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            long totalBucketIdExists = 0;
            if (!tracfoneOneBucketList.isDelete()) {
                totalBucketIdExists = tracfoneBucketAction.checkBucketListDependencies(tracfoneOneBucketList);
                response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, String.valueOf(totalBucketIdExists));
            }
            if (tracfoneOneBucketList.isDelete() || totalBucketIdExists == 0) {
                response = tracfoneBucketAction.deleteBucketList(tracfoneOneBucketList, userId);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_BUCKET_LIST_ERROR, TRACFONE_DELETE_BUCKET_LIST_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneCarrierProfileBucket getBucketDetails(TracfoneOneBucketList tracfoneOneBucketList) throws TracfoneOneException {
        TFOneCarrierProfileBucket tfOneCarrierProfileBucket = null;
        try {
            tfOneCarrierProfileBucket = tracfoneBucketAction.getBucketDetails(tracfoneOneBucketList);
        } catch (Exception ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_BUCKET_DETAILS_ERROR, TRACFONE_GET_BUCKET_DETAILS_ERROR_MESSAGE, ex);
        }
        return tfOneCarrierProfileBucket;
    }
}
