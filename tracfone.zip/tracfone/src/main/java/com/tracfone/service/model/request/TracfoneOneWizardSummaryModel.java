/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import java.util.List;

/**
 *
 * @author Shireen Fathima
 */
public class TracfoneOneWizardSummaryModel {
    
    private String dbEnv;    
    private String carrierName;
    private String servicePlanId;
    private List<String> ratePlanIds;
    private List<String> carrierFeatureIds;
    private List<String> profileIds;
    private List<String> profileFeatureIds;
    private List<String> bucketIds;
    private List<String> carrierProfileBucketIds;
    private List<String> carrierProfileChildBucketIds;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public List<String> getRatePlanIds() {
        return ratePlanIds;
    }

    public void setRatePlanIds(List<String> ratePlanIds) {
        this.ratePlanIds = ratePlanIds;
    }

    public List<String> getCarrierFeatureIds() {
        return carrierFeatureIds;
    }

    public void setCarrierFeatureIds(List<String> carrierFeatureIds) {
        this.carrierFeatureIds = carrierFeatureIds;
    }

    public List<String> getProfileIds() {
        return profileIds;
    }

    public void setProfileIds(List<String> profileIds) {
        this.profileIds = profileIds;
    }

    public List<String> getProfileFeatureIds() {
        return profileFeatureIds;
    }

    public void setProfileFeatureIds(List<String> profileFeatureIds) {
        this.profileFeatureIds = profileFeatureIds;
    }

    public List<String> getBucketIds() {
        return bucketIds;
    }

    public void setBucketIds(List<String> bucketIds) {
        this.bucketIds = bucketIds;
    }

    public List<String> getCarrierProfileBucketIds() {
        return carrierProfileBucketIds;
    }

    public void setCarrierProfileBucketIds(List<String> carrierProfileBucketIds) {
        this.carrierProfileBucketIds = carrierProfileBucketIds;
    }

    public List<String> getCarrierProfileChildBucketIds() {
        return carrierProfileChildBucketIds;
    }

    public void setCarrierProfileChildBucketIds(List<String> carrierProfileChildBucketIds) {
        this.carrierProfileChildBucketIds = carrierProfileChildBucketIds;
    }

    @Override
    public String toString() {
        return "TracfoneOneWizardSummaryModel{" + "dbEnv=" + dbEnv + ", "
                + "carrierName=" + carrierName + ", "
                + "servicePlanId=" + servicePlanId + ", "
                + "ratePlanIds=" + ratePlanIds + ", "
                + "carrierFeatureIds=" + carrierFeatureIds + ", "
                + "profileIds=" + profileIds + ", "
                + "profileFeatureIds=" + profileFeatureIds + ", "
                + "bucketIds=" + bucketIds + ", "
                + "carrierProfileBucketIds=" + carrierProfileBucketIds + ", "
                + "carrierProfileChildBucketIds=" + carrierProfileChildBucketIds + '}';
    }
    
        
}
