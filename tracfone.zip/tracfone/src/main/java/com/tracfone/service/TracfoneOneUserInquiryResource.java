package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneCarrierControllerLocal;
import com.tracfone.service.controller.TracfoneOneGeoCoderControllerLocal;
import com.tracfone.service.controller.TracfoneTransactionWizardControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneCarrierSubscriber;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneCarrierSubscriber;
import com.tracfone.service.model.response.TFTransactionCarrier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;

/**
 * @author ramartinez
 */
@Path("userinquiry")
public class TracfoneOneUserInquiryResource {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneUserInquiryResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @Context
    private SecurityContext securityContext;

    @EJB
    private TracfoneOneGeoCoderControllerLocal tracfoneGeoCoderController;

    @EJB
    private TracfoneTransactionWizardControllerLocal tracfoneOneTransactionWizardController;

    @EJB
    private TracfoneCarrierControllerLocal tracfoneOneCarrierController;

    @POST
    @Path("carrierui/inquire")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response inquireSubscriberProfile(final TracfoneOneCarrierSubscriber subscriberInfo) {
        TFOneCarrierSubscriber carrierInfoResponse = null;
        try {
            carrierInfoResponse = tracfoneOneCarrierController.inquireSubscriber(getUserFromPrincipal().getUserId(), subscriberInfo);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(carrierInfoResponse), MediaType.APPLICATION_JSON).build();
    }

    @GET
    @Path("carrierui")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarriers() {
        List<TFTransactionCarrier> carriers = null;

        try {
            carriers = tracfoneOneTransactionWizardController.getCarriers(getUserFromPrincipal().getUserId(), false);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();

        }
        return Response.ok(gson.toJson(carriers), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("carrierui/inquiresims")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response inquireMultipleSims(final TracfoneOneCarrierSubscriber subscriberInfo) {
        List<TFOneCarrierSubscriber> subscribers = new ArrayList<>();
        try {
            subscribers = tracfoneOneCarrierController.bulkInquiry(getUserFromPrincipal().getUserId(), subscriberInfo);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(subscribers), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves the user object making request from the principal.
     *
     * @return
     */
    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }

}

