package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneOneIGCarrierConfigControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfig;
import com.tracfone.service.model.response.TFOneIGCarrierConfig;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author Gaurav.Sharma
 */
@Path("igcarrierconfig")
public class TracfoneOneIGCarrierConfigViewResource {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneIGCarrierConfigViewResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @EJB
    private TracfoneOneIGCarrierConfigControllerLocal configControllerLocal;

    @Context
    private SecurityContext securityContext;

    /**
     * This method is used to get all carriers
     *
     * @param carrierConfig
     * @return
     */
    @POST
    @Path("igconfig/getcarriers")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarriers(final TracfoneOneIGCarrierConfig carrierConfig) {
        List<String> carrierData = new ArrayList<>();
        try {
            carrierData = configControllerLocal.getCarriers(carrierConfig.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(carrierData), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get Carriers Configs and Carrier Details based on
     * the search criteria
     *
     * @param carrierConfig
     * @return
     */
    @POST
    @Path("igconfig/getcarrierconfig")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCarrierConfig(final TracfoneOneIGCarrierConfig carrierConfig) {
        List<TFOneIGCarrierConfig> carrierConfigs = new ArrayList<>();
        try {
            carrierConfigs = configControllerLocal.getCarrierConfig(carrierConfig);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(carrierConfigs), MediaType.APPLICATION_JSON).build();
    }
}
