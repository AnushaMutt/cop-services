package com.tracfone.service.model.report;

/**
 *
 * @author druiz
 */
public class TFOneReportMonitor {

    private String xDate;
    private String template;
    private String orderType;
    private String sumAllQ;
    private String sumAllL;
    private String sumAllCp;
    private String sumAllWp;
    private String sumAllW;
    private String sumAllS;
    private String sumAllE;
    private String sumAllF;
    private String transType;
    private String sumAllTf;
    private String sumAllHw;

    public String getxDate() {
        return xDate;
    }

    public void setxDate(String xDate) {
        this.xDate = xDate;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getSumAllQ() {
        return sumAllQ;
    }

    public void setSumAllQ(String sumAllQ) {
        this.sumAllQ = sumAllQ;
    }

    public String getSumAllL() {
        return sumAllL;
    }

    public void setSumAllL(String sumAllL) {
        this.sumAllL = sumAllL;
    }

    public String getSumAllCp() {
        return sumAllCp;
    }

    public void setSumAllCp(String sumAllCp) {
        this.sumAllCp = sumAllCp;
    }

    public String getSumAllWp() {
        return sumAllWp;
    }

    public void setSumAllWp(String sumAllWp) {
        this.sumAllWp = sumAllWp;
    }

    public String getSumAllW() {
        return sumAllW;
    }

    public void setSumAllW(String sumAllW) {
        this.sumAllW = sumAllW;
    }

    public String getSumAllS() {
        return sumAllS;
    }

    public void setSumAllS(String sumAllS) {
        this.sumAllS = sumAllS;
    }

    public String getSumAllE() {
        return sumAllE;
    }

    public void setSumAllE(String sumAllE) {
        this.sumAllE = sumAllE;
    }

    public String getSumAllF() {
        return sumAllF;
    }

    public void setSumAllF(String sumAllF) {
        this.sumAllF = sumAllF;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public String getSumAllTf() {
        return sumAllTf;
    }

    public void setSumAllTf(String sumAllTf) {
        this.sumAllTf = sumAllTf;
    }

    public String getSumAllHw() {
        return sumAllHw;
    }

    public void setSumAllHw(String sumAllHw) {
        this.sumAllHw = sumAllHw;
    }
}
