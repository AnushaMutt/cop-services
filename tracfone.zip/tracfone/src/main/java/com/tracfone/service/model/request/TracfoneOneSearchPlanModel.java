/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Shireen Fathima
 */
public class TracfoneOneSearchPlanModel {

    private String dbEnv;
    private String carrierName;
    private String servicePlanId;
    private String ratePlanName;
    private String carrierFeatureId;
    private String profileId;
    private String toServicePlanId;
    private boolean copyProfiles;
    private boolean copyBuckets;
    private boolean copyChildBuckets;
    private boolean legacy;
    private TracfoneOneCarrierFeature bulkUpdateFields;
    private List<String> removedLinks;
    private List<String> removedBuckets;
    private List<String> removedChildBuckets;
    private List<String> removedCarrierFeatures;
    private List<TracfoneOneCarrierFeature> carrierFeatures;

    public TracfoneOneSearchPlanModel() {
        bulkUpdateFields = new TracfoneOneCarrierFeature();
        removedLinks = new ArrayList<>();
        removedBuckets = new ArrayList<>();
        removedChildBuckets = new ArrayList<>();
        removedCarrierFeatures = new ArrayList<>();
        carrierFeatures = new ArrayList<>();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public String getRatePlanName() {
        return ratePlanName;
    }

    public void setRatePlanName(String ratePlanName) {
        this.ratePlanName = ratePlanName;
    }

    public String getCarrierFeatureId() {
        return carrierFeatureId;
    }

    public void setCarrierFeatureId(String carrierFeatureId) {
        this.carrierFeatureId = carrierFeatureId;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getToServicePlanId() {
        return toServicePlanId;
    }

    public void setToServicePlanId(String toServicePlanId) {
        this.toServicePlanId = toServicePlanId;
    }

    public boolean isCopyProfiles() {
        return copyProfiles;
    }

    public void setCopyProfiles(boolean copyProfiles) {
        this.copyProfiles = copyProfiles;
    }

    public boolean isCopyBuckets() {
        return copyBuckets;
    }

    public void setCopyBuckets(boolean copyBuckets) {
        this.copyBuckets = copyBuckets;
    }

    public boolean isCopyChildBuckets() {
        return copyChildBuckets;
    }

    public void setCopyChildBuckets(boolean copyChildBuckets) {
        this.copyChildBuckets = copyChildBuckets;
    }

    public boolean isLegacy() { return legacy; }

    public void setLegacy(boolean legacy) { this.legacy = legacy; }

    public List<TracfoneOneCarrierFeature> getCarrierFeatures() {
        return carrierFeatures;
    }

    public void setCarrierFeatures(List<TracfoneOneCarrierFeature> carrierFeatures) {
        this.carrierFeatures = carrierFeatures;
    }

    public TracfoneOneCarrierFeature getBulkUpdateFields() {
        return bulkUpdateFields;
    }

    public void setBulkUpdateFields(TracfoneOneCarrierFeature bulkUpdateFields) {
        this.bulkUpdateFields = bulkUpdateFields;
    }

    public List<String> getRemovedLinks() {
        return removedLinks;
    }

    public void setRemovedLinks(List<String> removedLinks) {
        this.removedLinks = removedLinks;
    }

    public List<String> getRemovedBuckets() {
        return removedBuckets;
    }

    public void setRemovedBuckets(List<String> removedBuckets) {
        this.removedBuckets = removedBuckets;
    }

    public List<String> getRemovedChildBuckets() {
        return removedChildBuckets;
    }

    public void setRemovedChildBuckets(List<String> removedChildBuckets) {
        this.removedChildBuckets = removedChildBuckets;
    }

    public List<String> getRemovedCarrierFeatures() {
        return removedCarrierFeatures;
    }

    public void setRemovedCarrierFeatures(List<String> removedCarrierFeatures) {
        this.removedCarrierFeatures = removedCarrierFeatures;
    }

    @Override
    public String toString() {
        return "TracfoneOneSearchPlanModel{" +
                "dbEnv='" + dbEnv + '\'' +
                ", carrierName='" + carrierName + '\'' +
                ", servicePlanId='" + servicePlanId + '\'' +
                ", ratePlanName='" + ratePlanName + '\'' +
                ", carrierFeatureId='" + carrierFeatureId + '\'' +
                ", profileId='" + profileId + '\'' +
                ", toServicePlanId='" + toServicePlanId + '\'' +
                ", copyProfiles=" + copyProfiles +
                ", copyBuckets=" + copyBuckets +
                ", copyChildBuckets=" + copyChildBuckets +
                ", legacy=" + legacy +
                ", bulkUpdateFields=" + bulkUpdateFields +
                ", removedLinks=" + removedLinks +
                ", removedBuckets=" + removedBuckets +
                ", removedChildBuckets=" + removedChildBuckets +
                ", removedCarrierFeatures=" + removedCarrierFeatures +
                ", carrierFeatures=" + carrierFeatures +
                '}';
    }
}
