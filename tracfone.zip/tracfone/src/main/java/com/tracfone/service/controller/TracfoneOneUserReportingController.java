package com.tracfone.service.controller;

import com.google.gson.Gson;
import com.mysql.jdbc.StringUtils;
import com.tracfone.ejb.entity.UserTask;
import com.tracfone.ejb.entity.UserTaskDetail;
import com.tracfone.ejb.entity.session.UserTaskFacadeLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneUserTask;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneUserReporting;
import com.tracfone.service.model.response.TFOneUserTask;
import com.tracfone.service.model.response.TFOneUserTaskDetail;
import com.tracfone.service.util.TracfoneOneConstant;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.persistence.Query;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Stateless
public class TracfoneOneUserReportingController implements TracfoneOneUserReportingControllerLocal, TracfoneOneConstant {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneUserReportingController.class);

    @EJB
    private UserTaskFacadeLocal userTaskFacade;

    @EJB
    DataBaseController dbControllerEJB;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @Override
    public List<TFOneUserTask> getAllUserTasks(TracfoneOneUserTask tracfoneOneUserTask) throws TracfoneOneException {
        List<TFOneUserTask> userTasks = new ArrayList<>();
        try {
            StringBuilder builder = new StringBuilder(buildInClause(TRACFONE_GET_USER_TASK, tracfoneOneUserTask.getStatus().size()));
            if (!StringUtils.isNullOrEmpty(tracfoneOneUserTask.getUserId())) {
                builder.append(" and ut.ASSIGNED_USERID = ? ");
            }
            builder.append(" order by ut.CREATION_DATE desc");
            LOGGER.info("User Task search query is : " + builder);

            Query query = userTaskFacade.getEntityManager().createNativeQuery(builder.toString());
            int index = 1;
            query.setParameter(index++, tracfoneOneUserTask.getFromCreationDate());
            query.setParameter(index++, tracfoneOneUserTask.getToCreationDate());
            for (String status : tracfoneOneUserTask.getStatus()) {
                query.setParameter(index++, status);
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneUserTask.getUserId())) {
                query.setParameter(index, Long.valueOf(tracfoneOneUserTask.getUserId()));
            }

            List<Object[]> userTaskLists = query.getResultList();
            for (Object[] userTask : userTaskLists) {
                TFOneUserTask tfUserTask = new TFOneUserTask();
                tfUserTask.setId(userTask[0].toString());
                tfUserTask.setTaskName(userTask[1] != null ? userTask[1].toString() : null);
                tfUserTask.setDescription(userTask[2] != null ? userTask[2].toString() : null);
                tfUserTask.setUserId(userTask[3].toString());
                tfUserTask.setAssignedUserId(userTask[4].toString());
                tfUserTask.setType(userTask[5].toString());
                tfUserTask.getStatus().add(userTask[6].toString());
                tfUserTask.setCreationDate(userTask[7].toString());
                tfUserTask.setAssignedUserName(userTask[11].toString());

                TFOneUserTaskDetail tfOneUserTaskDetail = new TFOneUserTaskDetail();
                tfOneUserTaskDetail.setTaskDetails(userTask[8].toString());
                tfOneUserTaskDetail.setId(userTask[9].toString());
                tfOneUserTaskDetail.setUserComments(userTask[10] != null ? userTask[10].toString() : null);
                tfUserTask.getTfOneUserTaskDetail().add(tfOneUserTaskDetail);
                userTasks.add(tfUserTask);
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_GET_ALL_USER_TASKS_ERROR_CODE, TRACFONE_GET_ALL_USER_TASKS_ERROR_MESSAGE, e);
        }
        return userTasks;
    }

    private String buildInClause(String query, int size) {
        StringBuilder builder = new StringBuilder(query);
        int index = 1;
        while (index < size) {
            builder.append(",? ");
            index++;
        }
        builder.append(")");
        return builder.toString();
    }

    @Override
    public TFOneGeneralResponse reassignTransaction(TracfoneOneUserTask tracfoneOneUserTask, int userId) throws TracfoneOneException {
        Gson gson = new Gson();
        try {
            // Cancel the existing assignment
            UserTask userTask = userTaskFacade.find(Integer.valueOf(tracfoneOneUserTask.getId()));
            LOGGER.info("Find user task " + userTask);
            UserTaskDetail userTaskDetail = userTask.getUserTaskDetails().get(0);
            LOGGER.info("Find user task detail " + userTaskDetail);
            userTask.setStatus(CANCELLED);
            userTaskFacade.edit(userTask);

            // Assign task and detail to new user
            UserTask userTaskToInsert = new UserTask();
            userTaskToInsert.setAssignedUserId(Integer.valueOf(tracfoneOneUserTask.getAssignedUserId()));
            userTaskToInsert.setStatus(ASSIGNED);
            userTaskToInsert.setUserId(userTask.getUserId());
            userTaskToInsert.setCreationDate(new Date());
            userTaskToInsert.setUpdateDate(new Date());
            userTaskToInsert.setType(userTask.getType());
            userTaskToInsert.setTaskName(tracfoneOneUserTask.getTaskName());
            userTaskToInsert.setDescription(tracfoneOneUserTask.getDescription());

            if (userTaskDetail != null) {
                List<UserTaskDetail> userTaskDetails = new ArrayList<>();
                UserTaskDetail userTaskDetailToInsert = new UserTaskDetail();
                userTaskDetailToInsert.setCreationDate(new Date());
                userTaskDetailToInsert.setUpdateDate(new Date());
                userTaskDetailToInsert.setTaskDetails(userTaskDetail.getTaskDetails());
                userTaskDetailToInsert.setUserComments(userTaskDetail.getUserComments());
                userTaskDetailToInsert.setUserTask(userTaskToInsert);
                userTaskDetails.add(userTaskDetailToInsert);
                userTaskToInsert.setUserTaskDetails(userTaskDetails);
            }

            userTaskFacade.create(userTaskToInsert);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_REASSIGN_TRANSACTION_ERROR_CODE, TRACFONE_REASSIGN_TRANSACTION_ERROR_CODE_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Reassign User Task", gson.toJson(tracfoneOneUserTask), "CARRIER ID");
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TRACFONE_REASSIGN_TRANSACTION_SUCCESS);
    }

    @Override
    public List<TFOneUserReporting> assignTransactionReport(TracfoneOneUserTask tracfoneOneUserTask) throws TracfoneOneException {
        List<TFOneUserReporting> reports = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneUserTask.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ASSIGN_TRANSACTION_REPORT);) {
            stmt.setLong(1, Long.valueOf(tracfoneOneUserTask.getAssignedUserId()));
            stmt.setString(2, tracfoneOneUserTask.getFromCreationDate());
            stmt.setString(3, tracfoneOneUserTask.getToCreationDate());
            stmt.setString(4, tracfoneOneUserTask.getType());
            // Get the number of transactions as per the search filter and split them by different types - INSERT, REWORK and RE_QUEUE
            List<String> cancelledList = new ArrayList<>();
            List<String> assignedList = new ArrayList<>();
            List<String> inProgressList = new ArrayList<>();
            List<String> completedList = new ArrayList<>();
            try (ResultSet rs = stmt.executeQuery();) {
                while (rs.next()) {
                    String status = rs.getString("STATUS");
                    if (CANCELLED.equalsIgnoreCase(status)) {
                        cancelledList.add(rs.getString("ID"));
                    } else if (ASSIGNED.equalsIgnoreCase(status)) {
                        assignedList.add(rs.getString("ID"));
                    } else if ("COMPLETED".equalsIgnoreCase(status)) {
                        completedList.add(rs.getString("ID"));
                    } else if ("IN PROGRESS".equalsIgnoreCase(status)) {
                        inProgressList.add(rs.getString("ID"));
                    }
                }
            }
            // This gives the number of transactions for each type
            LOGGER.info(" inProgressList " + inProgressList.size());
            LOGGER.info(" assignedList " + assignedList.size());
            LOGGER.info(" completedList " + completedList.size());
            LOGGER.info(" cancelledList " + cancelledList.size());

            // For each group retrieve the details and set into return object
            reports.add(setReportDetails(con, TRACFONE_GET_TASK_DETAILS, ASSIGNED, TASK_DETAILS, assignedList));
            reports.add(setReportDetails(con, TRACFONE_GET_TASK_DETAILS, CANCELLED, TASK_DETAILS, cancelledList));
            reports.add(setReportDetails(con, TRACFONE_GET_TASK_DETAILS, "COMPLETED", TASK_DETAILS, completedList));
            reports.add(setReportDetails(con, TRACFONE_GET_TASK_DETAILS, "IN PROGRESS", TASK_DETAILS, inProgressList));
            LOGGER.info(" reports " + reports);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_GET_ASSIGN_REPORT_ERROR_CODE, TRACFONE_GET_ASSIGN_REPORT_ERROR_MESSAGE, e);
        }
        return reports;
    }

    @Override
    public List<TFOneUserReporting> transactionTypeReport(TracfoneOneUserTask tracfoneOneUserTask) throws TracfoneOneException {
        List<TFOneUserReporting> reports = new ArrayList<>();
        StringBuilder builder = new StringBuilder(TRACFONE_GET_TRANSACTION_TYPE_REPORT);
        if ("IG".equalsIgnoreCase(tracfoneOneUserTask.getType())) {
            builder.append("uh.type in ('REWORK', 'RE-QUEUE', 'INSERT') ");
        } else {
            builder.append("uh.type like '" + tracfoneOneUserTask.getType() + "_%' ");
        }
        builder.append("order by uh.type");
        LOGGER.info("Transaction Type report query is : " + builder);

        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneUserTask.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(builder.toString());) {
            stmt.setLong(1, Long.valueOf(tracfoneOneUserTask.getAssignedUserId()));
            stmt.setString(2, tracfoneOneUserTask.getFromCreationDate());
            stmt.setString(3, tracfoneOneUserTask.getToCreationDate());
            // Get the number of transactions as per the search filter and split them by different types - INSERT, REWORK and RE_QUEUE
            List<String> requeueList = new ArrayList<>();
            List<String> reworkList = new ArrayList<>();
            List<String> insertList = new ArrayList<>();
            try (ResultSet rs = stmt.executeQuery();) {
                while (rs.next()) {
                    String type = rs.getString("TYPE");
                    if (type.contains("RE-QUEUE")) {
                        requeueList.add(rs.getString("ID"));
                    } else if (type.contains("INSERT")) {
                        insertList.add(rs.getString("ID"));
                    } else if (type.contains("REWORK")) {
                        reworkList.add(rs.getString("ID"));
                    }
                }
            }
            // This gives the number of transactions for each type
            LOGGER.info(" requeueList " + requeueList.size());
            LOGGER.info(" insertList " + insertList.size());
            LOGGER.info(" reworkList " + reworkList.size());

            // For each group retrieve the details and set into return object
            reports.add(setReportDetails(con, TRACFONE_GET_HISTORY_DETAILS, "RE-QUEUE", ID_DETAIL, requeueList));
            reports.add(setReportDetails(con, TRACFONE_GET_HISTORY_DETAILS, "REWORK", ID_DETAIL, reworkList));
            reports.add(setReportDetails(con, TRACFONE_GET_HISTORY_DETAILS, "INSERT", ID_DETAIL, insertList));
            LOGGER.info(" reports " + reports);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_GET_TRANSACTION_REPORT_ERROR_CODE, TRACFONE_GET_TRANSACTION_REPORT_ERROR_MESSAGE, e);
        }
        return reports;
    }

    private TFOneUserReporting setReportDetails(Connection con, String query, String status, String columnName, List<String> historyIds) throws SQLException {
        TFOneUserReporting report = new TFOneUserReporting();
        report.setStatus(status);
        report.setTasks(Long.valueOf(historyIds.size()));
        report.setTransactions(0L);
        if (!historyIds.isEmpty()) {
            try (PreparedStatement statement = con.prepareStatement(buildInClause(query, historyIds.size()));) {
                int index = 1;
                for (String id : historyIds) {
                    statement.setString(index++, id);
                }

                List<String> idDetails = new ArrayList<>();
                try (ResultSet rs = statement.executeQuery();) {
                    while (rs.next()) {
                        idDetails.add(rs.getString(columnName));
                    }
                }
                Long count = getTransactionCount(idDetails);
                report.setTransactions(count);
            }
        }

        LOGGER.info(" Report " + report);
        return report;
    }

    private Long getTransactionCount(List<String> idDetails) {
        Long count = 0L;
        for (String idDetail : idDetails) {
            count = count + idDetail.split(",").length;
        }
        LOGGER.info("Count " + count);
        return count;
    }
}
