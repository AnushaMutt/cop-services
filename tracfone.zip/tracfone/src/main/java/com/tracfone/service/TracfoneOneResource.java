/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneGroup;
import com.tracfone.service.model.request.TracfoneOneLogin;
import com.tracfone.service.model.request.TracfoneOneUser;
import com.tracfone.service.model.request.TracfoneOneUserProfile;
import com.tracfone.service.model.response.TFOneAdminAction;
import com.tracfone.service.model.response.TFOneAdminGroup;
import com.tracfone.service.model.response.TFOneAdminProfile;
import com.tracfone.service.model.response.TFOneAdminRole;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneAuditHistory;
import com.tracfone.service.model.response.TFOneDatabaseEnvironment;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.List;

/**
 * REST Web Service
 *
 * @author spulavarthy
 */
@Path("main")
public class TracfoneOneResource {

    @EJB
    private TracfoneControllerLocal tracfoneController;
    @EJB
    private TracfoneControllerLocalAction tracfoneControllerAction;

    @Context
    private SecurityContext securityContext;

    private static final Logger logger = LogManager.getLogger(TracfoneOneResource.class);
    private static Gson gson = new GsonBuilder().serializeNulls().create();

    /**
     * Retrieves representation of an instance of
     * com.tracfone.service.TracfoneoneProfileResource
     *
     * @return an instance of java.lang.String
     */
    @POST
    @Path("login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response authenticate(final TracfoneOneLogin loginModel) {

        TFOneAdminUser tfUser = null;
        try {
            tfUser = tracfoneController.login(loginModel.getUserName(), loginModel.getPassword());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }

        Response response = Response.ok(gson.toJson(tfUser), MediaType.APPLICATION_JSON).build();
        response.getHeaders().add("token", tfUser.getToken());
        return response;
    }

    /**
     * Log out the user and clear the token.
     *
     * @param user
     * @return
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("logout")
    @Produces(MediaType.APPLICATION_JSON)
    public Response logout(final TracfoneOneUser user) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = tracfoneController.logout(user.getToken());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves profile for user based on authentication token.
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Path("profile")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    public Response getProfile() {
        return getUserProfile(getUserFromPrincipal().getUserId(), getUserFromPrincipal().getUserId());
    }

    /**
     * Retrieves representation of an instance of
     * com.tracfone.service.TracfoneoneProfileResource. Retrieves profile for
     * userId in the path parameter.
     *
     * @param userId
     * @return
     */
    @GET
    @Path("profile/{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    public Response getProfileForUser(@PathParam("userId") Integer userId) {
        return getUserProfile(userId, getUserFromPrincipal().getUserId());
    }

    @POST
    @Path("profile/{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    public Response deleteProfile(@PathParam("userId") Integer userId) {
        TFOneGeneralResponse tfOneGeneralResponse = null;
        try {
            tfOneGeneralResponse = tracfoneController.deleteUserProfile(userId, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneGeneralResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves representation of an instance of
     * com.tracfone.service.TracfoneoneProfileResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Path("roles")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    public Response getRoles() {

        List<TFOneAdminRole> tfRoles = null;
        try {
            tfRoles = tracfoneController.getRoles(getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();

        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfRoles), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves the role assigned to the user.
     *
     * @param userId
     * @return role Id of the user.
     */
    @GET
    @Path("role/{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    public Response getRole(@PathParam("userId") Integer userId) {
        TFOneAdminRole tfRole = null;
        try {
            tfRole = tracfoneController.getRole(userId, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfRole), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves representation of an instance of
     * com.tracfone.service.TracfoneoneProfileResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Path("users")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllUsers() {
        List<TFOneAdminUser> tfUsers1 = null;
        Response response = null;
        try {
            tfUsers1 = tracfoneController.getAllUsers(getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }

        response = Response.ok(gson.toJson(tfUsers1), MediaType.APPLICATION_JSON).build();
        return response;
    }

    @PUT
    @Path("users")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateUser(final TracfoneOneUserProfile userProfileRequestModel) {
        Response response = null;
        TFOneGeneralResponse tfOneResponse = null;

        try {
            tfOneResponse = tracfoneController.updateUser(userProfileRequestModel, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }

        response = Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
        return response;
    }

    @POST
    @Path("users")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response createUser(final TracfoneOneUserProfile userProfileRequestModel) {
        Response response = null;
        TFOneGeneralResponse tfOneResponse = null;

        try {
            tracfoneController.duplicateUserNameCheck(userProfileRequestModel.getTfUser().getUserName());
            tracfoneController.duplicateSignatureCheck(userProfileRequestModel.getTfUser().getDescription());
            tfOneResponse = tracfoneController.createUser(userProfileRequestModel, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }

        response = Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
        return response;
    }

    @GET
    @Path("users/{actionId}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getUsersWithAction(@PathParam("actionId") Integer actionId) {
        List<TFOneAdminUser> tfUsers = null;

        try {
            tfUsers = tracfoneController.getAllUsersWithAction(actionId, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }

        return Response.ok(gson.toJson(tfUsers), MediaType.APPLICATION_JSON).build();
    }

    @GET
    @Path("actions/{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllActions(@PathParam("userId") Integer userId) {
        List<TFOneAdminAction> tfActions = null;
        Response response = null;

        try {
            tfActions = tracfoneController.getAllActions(userId, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }

        response = Response.ok(gson.toJson(tfActions), MediaType.APPLICATION_JSON).build();
        return response;
    }

    /**
     * @param userId
     * @return
     */
    @GET
    @Path("groups/{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllGroups(@PathParam("userId") Integer userId) {
        List<TFOneAdminGroup> tfGroups = null;
        Response response = null;

        try {
            tfGroups = tracfoneController.getAllGroups(userId, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }

        response = Response.ok(gson.toJson(tfGroups), MediaType.APPLICATION_JSON).build();
        return response;
    }

    @GET
    @Path("group/{groupId}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getGroup(@PathParam("groupId") int grouId) {
        Response response = null;
        TFOneAdminGroup tfGroup = null;

        try {
            tfGroup = tracfoneController.getGroup(grouId, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }

        response = Response.ok(gson.toJson(tfGroup), MediaType.APPLICATION_JSON).build();
        return response;
    }

    @POST
    @Path("group")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response createGroup(final TracfoneOneGroup groupRequestModel) {
        Response response = null;
        TFOneGeneralResponse tfOneResponse = null;

        try {
            tfOneResponse = tracfoneController.createGroup(groupRequestModel, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }

        response = Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
        return response;
    }

    @PUT
    @Path("group")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateGroup(final TracfoneOneGroup groupRequestModel) {
        Response response = null;
        TFOneGeneralResponse tfOneResponse = null;

        try {
            tfOneResponse = tracfoneController.updateGroup(groupRequestModel, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }

        response = Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
        return response;
    }

    @GET
    @Path("audithistory/{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAuditHistoryForUser(@PathParam("userId") Integer userId) {
        Response response = null;
        List<TFOneAuditHistory> auditHistory = null;

        try {
            auditHistory = tracfoneController.getAuditHistoryForUserId(userId);
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        response = Response.ok(gson.toJson(auditHistory), MediaType.APPLICATION_JSON).build();
        return response;
    }

    @GET
    @Path("dbenvs")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    public Response getDatabaseEnvironments() {
        List<TFOneDatabaseEnvironment> tfOneDatabaseEnvironment = null;
        Response response = null;
        try {
            tfOneDatabaseEnvironment = tracfoneController.getDatabaseEnvironments(getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }

        response = Response.ok(gson.toJson(tfOneDatabaseEnvironment), MediaType.APPLICATION_JSON).build();
        return response;
    }

    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }

    /**
     * Retrieves user profile for parameter userId, and uses the adminUserId to
     * authenticate request.
     *
     * @param adminUserId
     * @param userId
     * @return
     */
    private Response getUserProfile(Integer userId, Integer adminUserId) {
        TFOneAdminProfile userProfile = null;
        boolean allowRootRetrieval = false;
        try {
            userProfile = tracfoneController.getProfile(userId, adminUserId, allowRootRetrieval);
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            logger.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(userProfile), MediaType.APPLICATION_JSON).build();
    }
}
