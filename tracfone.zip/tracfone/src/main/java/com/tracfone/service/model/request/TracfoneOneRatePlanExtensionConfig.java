/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.request;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * Table sa.x_rp_extension_config
 *
 * @author Nidhi Mantri
 */
public class TracfoneOneRatePlanExtensionConfig {

    private String objid;
    @NotNull(message = "Profile Id cannot be null")
    @Size(min = 1, message = "Profile Id cannot be blank")
    private String profileId;
    @NotNull(message = "Feature  Name cannot be null")
    @Size(min = 1, message = "Feature Name cannot be blank")
    @Size(max = 100, message = "Feature Name cannot have more than 100 characters")
    private String featureName;
    @NotNull(message = "Feature Value cannot be null")
    @Size(min = 1, message = "Feature Value cannot be blank")
    @Size(max = 100, message = "Feature Value cannot have more than 100 characters")
    private String featureValue;
    @NotNull(message = "Feature Requirement cannot be null")
    @Size(min = 1, message = "Feature Requirement cannot be blank")
    @Size(max = 3, message = "Feature Requirement cannot have more than 3 characters")
    private String featureRequirement;
    @NotNull(message = "Toggle Flag  cannot be null")
    @Size(min = 1, message = "Toggle Flag cannot be blank")
    @Size(max = 1, message = "Toggle Flag cannot have more than 1 character")
    private String toggleFlag;
    private String notes;
    @NotNull(message = "Display Sui Flag cannot be null")
    @Size(min = 1, message = "Display Sui Flag cannot be blank")
    @Size(max = 1, message = "Display Sui Flag cannot have more than 1 character")
    private String displaySUIFlag;
    @NotNull(message = "Restricted Sui Flag  cannot be null")
    @Size(min = 1, message = "Restricted Sui Flag cannot be blank")
    @Size(max = 1, message = "Restricted Sui Flag cannot have more than 1 character")
    private String restrictSUIFlag;
    private String dbEnv;
    private String rowNum;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjid() {
        return objid;
    }

    public void setObjid(String objid) {
        this.objid = objid;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public String getFeatureValue() {
        return featureValue;
    }

    public void setFeatureValue(String featureValue) {
        this.featureValue = featureValue;
    }

    public String getFeatureRequirement() {
        return featureRequirement;
    }

    public void setFeatureRequirement(String featureRequirement) {
        this.featureRequirement = featureRequirement;
    }

    public String getToggleFlag() {
        return toggleFlag;
    }

    public void setToggleFlag(String toggleFlag) {
        this.toggleFlag = toggleFlag;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getDisplaySUIFlag() {
        return displaySUIFlag;
    }

    public void setDisplaySUIFlag(String displaySUIFlag) {
        this.displaySUIFlag = displaySUIFlag;
    }

    public String getRestrictSUIFlag() {
        return restrictSUIFlag;
    }

    public void setRestrictSUIFlag(String restrictSUIFlag) {
        this.restrictSUIFlag = restrictSUIFlag;
    }

    public String getRowNum() {
        return rowNum;
    }

    public void setRowNum(String rowNum) {
        this.rowNum = rowNum;
    }

    @Override
    public String toString() {
        return "TracfoneOneRatePlanExtensionConfig{" + "objid=" + objid + ", "
                + "profileId=" + profileId + ", "
                + "featureName=" + featureName + ", "
                + "featureValue=" + featureValue + ", "
                + "featureRequirement=" + featureRequirement + ", "
                + "toggleFlag=" + toggleFlag + ", "
                + "notes=" + notes + ", "
                + "displaySUIFlag=" + displaySUIFlag + ", "
                + "restrictSUIFlag=" + restrictSUIFlag + ", "
                + "dbEnv=" + dbEnv + ", "
                + "rowNum=" + rowNum + '}';
    }
    
    
}
