/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfig;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfigDetails;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGCarrierConfig;
import com.tracfone.service.util.TracfoneOneIGCarrierConfigConstant;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author Gaurav.Sharma
 */
@Stateless
public class TracfoneOneIGCarrierConfigController implements TracfoneOneIGCarrierConfigControllerLocal, TracfoneOneIGCarrierConfigConstant {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneIGCarrierConfigController.class);

    @EJB
    private TracfoneOneIGCarrierConfigActionLocal configActionLocal;

    @Override
    public List<String> getCarriers(String dbEnv) throws TracfoneOneException {
        List<String> carrierData = new ArrayList<>();
        try {
            carrierData = configActionLocal.getCarriers(dbEnv);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_CARRIERS_ERROR, TRACFONE_GET_CARRIERS_ERROR_MESSAGE, ex);
        }
        return carrierData;
    }

    @Override
    public List<TFOneIGCarrierConfig> getCarrierConfig(TracfoneOneIGCarrierConfig carrierConfig) throws TracfoneOneException {
        List<TFOneIGCarrierConfig> carrierConfigs = new ArrayList<>();
        try {
            carrierConfigs = configActionLocal.getCarrierConfig(carrierConfig);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_CARRIER_CONFIGS_ERROR, TRACFONE_GET_CARRIER_CONFIGS_MESSAGE, ex);
        }
        return carrierConfigs;
    }

    @Override
    public TFOneGeneralResponse updateCarrierConfigDetails(TracfoneOneIGCarrierConfig carrierDetails, int userId) throws TracfoneOneException {
        if (!carrierDetails.getPropType().equals("MAP")) {
            validateDuplicateCarrierConfigDetails(carrierDetails.getIgCarrierDetails());
        }
        TFOneGeneralResponse response = null;
        try {
            response = configActionLocal.updateCarrierConfigDetails(carrierDetails, userId);
        } catch (TracfoneOneException ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_CARRIER_CONFIG_DETAILS_ERROR, TRACFONE_UPDATE_CARRIER_CONFIG_DETAILS_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse deleteCarrierConfigDetails(TracfoneOneIGCarrierConfigDetails carrierDetails, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = configActionLocal.deleteCarrierConfigDetails(carrierDetails, userId);
        } catch (TracfoneOneException ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_CARRIER_CONFIG_DETAILS_ERROR, TRACFONE_DELETE_CARRIER_CONFIG_DETAILS_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse insertCarrierConfigDetails(TracfoneOneIGCarrierConfig carrierDetails, int userId) throws TracfoneOneException {
        if (!carrierDetails.getPropType().equals("MAP")) {
            validateDuplicateCarrierConfigDetails(carrierDetails.getIgCarrierDetails());
        }
        TFOneGeneralResponse response = null;
        try {
            response = configActionLocal.insertCarrierConfigDetails(carrierDetails, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (TracfoneOneException ex) {
            throw new TracfoneOneException(TRACFONE_INSERT_CARRIER_CONFIG_DETAILS_ERROR, TRACFONE_INSERT_CARRIER_CONFIG_DETAILS_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse insertCarrierConfig(TracfoneOneIGCarrierConfig carrierConfig, int userId) throws TracfoneOneException {
        validateDuplicateCarrierConfig(carrierConfig);
        TFOneGeneralResponse response = null;
        try {
            response = configActionLocal.insertCarrierConfig(carrierConfig, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (TracfoneOneException ex) {
            throw new TracfoneOneException(TRACFONE_INSERT_CARRIER_CONFIG_ERROR, TRACFONE_INSERT_CARRIER_CONFIG_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<String> getPropNameForRef(TracfoneOneIGCarrierConfig carrierConfig) throws TracfoneOneException {
        List<String> propNames = new ArrayList<>();
        try {
            propNames = configActionLocal.getPropNameForRef(carrierConfig);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_PROP_NAME_ERROR, TRACFONE_GET_PROP_NAME_ERROR_MESSAGE, ex);
        }
        return propNames;
    }

    @Override
    public List<String> getPropNameForRefList(TracfoneOneIGCarrierConfig carrierConfig) throws TracfoneOneException {
        List<String> propNames = new ArrayList<>();
        try {
            propNames = configActionLocal.getPropNameForRefList(carrierConfig);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_PROP_NAME_ERROR, TRACFONE_GET_PROP_NAME_ERROR_MESSAGE, ex);
        }
        return propNames;
    }

    private void validateDuplicateCarrierConfigDetails(TracfoneOneIGCarrierConfigDetails carrierDetails) throws TracfoneOneException {
        if (configActionLocal.validateDuplicateCarrierConfigDetails(carrierDetails)) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_CARRIER_CONFIG_DETAILS_ERROR, TRACFONE_DUPLICATE_CARRIER_CONFIG_DETAILS_MESSAGE);
        }
    }

    private void validateDuplicateCarrierConfig(TracfoneOneIGCarrierConfig tracfoneOneIGCarrierConfig) throws TracfoneOneException {
        TracfoneOneIGCarrierConfig carrierConfig = new TracfoneOneIGCarrierConfig();
        carrierConfig.setCarrier(tracfoneOneIGCarrierConfig.getCarrier());
        carrierConfig.setPropName(tracfoneOneIGCarrierConfig.getPropName());
        carrierConfig.setDbEnv(tracfoneOneIGCarrierConfig.getDbEnv());
        if (!configActionLocal.checkDuplicateCarrierConfig(carrierConfig).isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_CARRIER_CONFIG_ERROR, TRACFONE_DUPLICATE_CARRIER_CONFIG_MESSAGE);
        }
    }

}
