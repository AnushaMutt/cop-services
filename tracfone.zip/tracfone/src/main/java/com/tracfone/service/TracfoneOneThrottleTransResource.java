package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerLocalAction;
import com.tracfone.service.controller.TracfoneOneTTransNotesControllerLocal;
import com.tracfone.service.controller.TracfoneOneThrottleTransControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.filter.TracfoneOnePrincipal;
import com.tracfone.service.model.request.TracfoneOneTTransactionNotes;
import com.tracfone.service.model.request.TracfoneOneThrottlePolicy;
import com.tracfone.service.model.request.TracfoneOneThrottleRework;
import com.tracfone.service.model.request.TracfoneOneThrottleTrans;
import com.tracfone.service.model.request.TracfoneOneThrottleTransaction;
import com.tracfone.service.model.request.TracfoneOneUserHistory;
import com.tracfone.service.model.request.TracfoneOneUserTask;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneThrottlePolicy;
import com.tracfone.service.model.response.TFOneThrottleTransSearchResult;
import com.tracfone.service.model.response.TFOneUserHistory;
import com.tracfone.service.model.response.TFOneUserTask;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.validation.Valid;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.util.ArrayList;
import java.util.List;

@Path("throttle")
public class TracfoneOneThrottleTransResource implements TracfoneOneConstantReport {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneThrottleTransResource.class);
    private static final Gson gson = new GsonBuilder().serializeNulls().create();

    @EJB
    private TracfoneOneThrottleTransControllerLocal throttleTransController;

    @EJB
    private TracfoneControllerLocalAction tracfoneControllerAction;

    @EJB
    private TracfoneControllerLocal tracfoneController;

    @EJB
    TracfoneOneTTransNotesControllerLocal tracfoneOneTTransNotesControllerLocal;

    @Context
    private SecurityContext securityContext;

    /**
     * This method is used to search for User Histories based on UserId
     *
     * @param tfOneUserHistory
     * @return
     */
    @POST
    @Path("throttletransactions/userhistory")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getUserHistoryByUserId(final TracfoneOneUserHistory tfOneUserHistory) {
        List<TFOneUserHistory> userHistories = new ArrayList<>();
        try {
            tfOneUserHistory.setType("TT_");
            userHistories = tracfoneControllerAction.getUserHistoryByUserId(tfOneUserHistory);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(userHistories), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("throttletransactions/allusertasks")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getUserTaskByUserId(final TracfoneOneUserTask tfOneUserTask) {
        tfOneUserTask.setType("TT_TRANSACTION");
        List<TFOneUserTask> userTasks;
        try {
            userTasks = tracfoneControllerAction.getUserTaskByUserId(tfOneUserTask);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(userTasks), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("throttletransactions/updateusertask")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response updateUserTask(final TracfoneOneUserTask tfOneUserTask) {
        TFOneUserTask tfUserTask;
        try {
            tfUserTask = tracfoneControllerAction.updateUserTask(tfOneUserTask, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfUserTask), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to search for Throttle Transaction based
     *
     * @param throttleTransaction
     * @return
     */
    @POST
    @Path("throttletransactions/viewthrottletransaction")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response viewThrottleTransactions(final TracfoneOneThrottleTransaction throttleTransaction) {
        TFOneThrottleTransSearchResult throttleTransactions;
        try {
            throttleTransactions = throttleTransController.viewThrottleTransaction(throttleTransaction);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(throttleTransactions), MediaType.APPLICATION_JSON).build();
    }

    @GET
    @Path("throttletransactions/userlist")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllUsers() {
        List<TFOneAdminUser> tfOneAdminUsers = null;
        try {
            tfOneAdminUsers = tracfoneController.getAllUsers(getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        } catch (TracfoneOneAuthorizationException tfoAuthEx) {
            LOGGER.error(tfoAuthEx.getMessage(), tfoAuthEx);
            int httpResponseCode = Response.Status.UNAUTHORIZED.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoAuthEx.getErrorCode(), tfoAuthEx.getErrorMessage(), httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneAdminUsers), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("throttletransactions/assignusertask")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertUserTask(final TracfoneOneUserTask tfOneUserTask) {
        TFOneGeneralResponse response;
        try {
            response = tracfoneControllerAction.insertUserTask(tfOneUserTask, getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("throttletransactions/requeue")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response requeue(final TracfoneOneThrottleRework tracfoneOneThrottleRework) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = throttleTransController.reworkRequeue(tracfoneOneThrottleRework, "RE-QUEUE", getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("throttletransactions/rework")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response rework(final TracfoneOneThrottleRework tracfoneOneThrottleRework) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = throttleTransController.reworkRequeue(tracfoneOneThrottleRework, "REWORK", getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    @GET
    @Path("throttletransactions/allfailures/{flag}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllFailuresForTT(@PathParam("flag") boolean flag) {
        String jsonResponse = null;
        try {
            jsonResponse = tracfoneController.getAllFailures(TRACFONE_REPORTNAME_ALL_TT_FAILURES, flag);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(jsonResponse, MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add records into w3ci.TABLE_X_THROTTLING_TRANSACTION(Using stored procedure) table
     *
     * @return
     */
    @POST
    @Path("throttletransactions/addthrottletransaction")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertThrottleTransaction(@Valid TracfoneOneThrottleTrans tfThrottleTrans) {
        TFOneGeneralResponse response = null;
        try {
            if (tfThrottleTrans.isSitOrTst()) {
                response = throttleTransController.insertThrottleTransaction(tfThrottleTrans, getUserFromPrincipal().getUserId());
            }
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add record into w3ci.TABLE_X_THROTTLING_TRANSACTION table
     *
     * @return
     */
    @POST
    @Path("throttletransactions/addthrottletrans")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertThrottleTrans(@Valid TracfoneOneThrottleTrans tfThrottleTrans) {
        TFOneGeneralResponse response = null;
        try {
            if (tfThrottleTrans.isSitOrTst()) {
                response = throttleTransController.insertThrottle(tfThrottleTrans, getUserFromPrincipal().getUserId());
            }
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all policyname
     *
     * @param tfhrottleTrans
     * @return
     */
    @POST
    @Path("throttletransactions/getpolicyname")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getPolicyName(final TracfoneOneThrottleTrans tfhrottleTrans) {
        List<TFOneThrottlePolicy> policyList = new ArrayList<>();
        try {
            policyList = throttleTransController.getPolicyName(tfhrottleTrans.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(policyList), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all USAGE_TIER_ID FROM X_USAGE_TIER
     *
     * @param tfhrottleTrans
     * @return
     */
    @POST
    @Path("throttletransactions/getusagetierid")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getUsageTierId(final TracfoneOneThrottleTrans tfhrottleTrans) {
        List<String> usageTierIdList = new ArrayList<>();
        try {
            usageTierIdList = throttleTransController.getUsageTierId(tfhrottleTrans.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(usageTierIdList), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get all COS FROM sa.X_COS
     *
     * @param tfhrottleTrans
     * @return
     */
    @POST
    @Path("throttletransactions/getcos")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getCos(final TracfoneOneThrottleTrans tfhrottleTrans) {
        List<String> cosList = new ArrayList<>();
        try {
            cosList = throttleTransController.getCos(tfhrottleTrans.getDbEnv());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(cosList), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get QUEUE_PRIORITY based on COS FROM sa.X_COS
     *
     * @param tfhrottleTrans
     * @return
     */
    @POST
    @Path("throttletransactions/getpriority")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getPriority(final TracfoneOneThrottleTrans tfhrottleTrans) {
        List<String> priorityList = new ArrayList<>();
        try {
            priorityList = throttleTransController.getPriority(tfhrottleTrans.getDbEnv(), tfhrottleTrans.getCos());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(priorityList), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get THRESHOLD , ENTITLEMENT from x_policy_mapping_config
     *
     * @param tfhrottleTrans
     * @return
     */
    @POST
    @Path("throttletransactions/getthresholdentitlement/{columnname}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getThresholdEntitlement(final TracfoneOneThrottleTrans tfhrottleTrans,
                                            @PathParam("columnname") String columnName) {
        List<String> list = new ArrayList<>();
        try {
            list = throttleTransController.getThresholdEntitlement(tfhrottleTrans.getDbEnv(), columnName);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(list), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to get objid based FROM W3CI.TABLE_X_THROTTLING_RULE
     *
     * @param tfThrottlePolicy
     * @return
     */
    @POST
    @Path("throttletransactions/getruleid")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getRuleId(final TracfoneOneThrottlePolicy tfThrottlePolicy) {
        List<String> ruleIdList = new ArrayList<>();
        try {
            ruleIdList = throttleTransController.getRuleId(tfThrottlePolicy.getDbEnv(), tfThrottlePolicy.getObjId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(ruleIdList), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("throttletransactions/requeueall")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response requeueAll(final TracfoneOneThrottleRework tracfoneOneThrottleRework) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = throttleTransController.reworkRequeueAll(tracfoneOneThrottleRework, "RE-QUEUE", getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("throttletransactions/reworkall")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response reworkAll(final TracfoneOneThrottleRework tracfoneOneThrottleRework) {
        TFOneGeneralResponse tfOneResponse;
        try {
            tfOneResponse = throttleTransController.reworkRequeueAll(tracfoneOneThrottleRework, "REWORK", getUserFromPrincipal().getUserId());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("throttletransactions/getobjids")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getObjIds(final TracfoneOneThrottleRework tracfoneOneThrottleRework) {
        List<String> response = null;
        try {
            response = throttleTransController.getObjIds(tracfoneOneThrottleRework);
            LOGGER.info("Response : " + response);
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(response), MediaType.APPLICATION_JSON).build();
    }

    /**
     * This method is used to add record into THROTTLING_TRANSACTION_NOTE table
     *
     * @return
     */
    @POST
    @Path("throttletransactions/throttletransactionnote")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response insertThrottleTransNotes(@Valid TracfoneOneTTransactionNotes tfTTransactionNotes) {
        TFOneGeneralResponse tfOneResponse = null;
        try {
            tfOneResponse = tracfoneOneTTransNotesControllerLocal.insertThrottleTransNotes(tfTTransactionNotes,
                    getUserFromPrincipal().getUserName());
        } catch (TracfoneOneException tfoEx) {
            LOGGER.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return Response.ok(gson.toJson(tfOneResponse), MediaType.APPLICATION_JSON).build();
    }

    /**
     * Retrieves the user object making request from the principal.
     *
     * @return
     */
    private TFOneAdminUser getUserFromPrincipal() {
        TracfoneOnePrincipal principal = (TracfoneOnePrincipal) securityContext.getUserPrincipal();
        return principal.getTFUser();
    }
}
