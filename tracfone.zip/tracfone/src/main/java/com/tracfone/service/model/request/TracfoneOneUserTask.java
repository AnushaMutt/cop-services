package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.List;

/**
 * COP.COP_USER_TASK
 *
 * @author Pritesh.Singh
 */
public class TracfoneOneUserTask {
    private String dbEnv;
    private String id;
    private String taskName;
    private String description;
    private String userId;
    private String assignedUserId;
    private String type;
    private List<String> status;
    private String fromCreationDate;
    private String toCreationDate;
    private List<TracfoneOneUserTaskDetail> tfOneUserTaskDetails;
    private boolean validateTransactions;

    public TracfoneOneUserTask() {
        tfOneUserTaskDetails =  new ArrayList<>();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAssignedUserId() {
        return assignedUserId;
    }

    public void setAssignedUserId(String assignedUserId) {
        this.assignedUserId = assignedUserId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getStatus() {
        return status;
    }

    public void setStatus(List<String> status) {
        this.status = status;
    }

    public String getFromCreationDate() {
        return fromCreationDate;
    }

    public void setFromCreationDate(String fromCreationDate) {
        this.fromCreationDate = fromCreationDate;
    }

    public String getToCreationDate() {
        return toCreationDate;
    }

    public void setToCreationDate(String toCreationDate) {
        this.toCreationDate = toCreationDate;
    }

    public List<TracfoneOneUserTaskDetail> getTfOneUserTaskDetails() {
        return tfOneUserTaskDetails;
    }

    public void setTfOneUserTaskDetails(List<TracfoneOneUserTaskDetail> tfOneUserTaskDetails) {
        this.tfOneUserTaskDetails = tfOneUserTaskDetails;
    }

    public boolean isValidateTransactions() {
        return validateTransactions;
    }

    public void setValidateTransactions(boolean validateTransactions) {
        this.validateTransactions = validateTransactions;
    }

    @Override
    public String toString() {
        return "TracfoneOneUserTask{" +
                "dbEnv='" + dbEnv + '\'' +
                ", id='" + id + '\'' +
                ", taskName='" + taskName + '\'' +
                ", description='" + description + '\'' +
                ", userId='" + userId + '\'' +
                ", assignedUserId='" + assignedUserId + '\'' +
                ", type='" + type + '\'' +
                ", status=" + status +
                ", fromCreationDate='" + fromCreationDate + '\'' +
                ", toCreationDate='" + toCreationDate + '\'' +
                ", tfOneUserTaskDetails=" + tfOneUserTaskDetails +
                '}';
    }
}

