package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * TABLE: CARRIERPREF
 * @author Anjali
 */

public class TracfoneOneCarrierPref {
    private String dbEnv;

    @Size(min = 1, message = "State Codes cannot be null")
    @Size(max = 30, message = "State cannot have more than 200 characters")
    private String state;

    @Size(min = 1, message = "COUNTY Codes cannot be null")
    @Size(max = 50, message = "COUNTY cannot have more than 200 characters")
    private String county;

    @Size(min = 1, message = "CARRIERID Codes cannot be null")
    @Digits(integer = 38, fraction = 0, message = "CARRIERID must be a number")
    private String carrierId;

    @Size(min = 1, message = "CARRIERNAME Codes cannot be null")
    @Size(max = 255, message = "CARRIERNAME cannot have more than 200 characters")
    private String carrierName;

    @Size(max = 30, message = "CARRIERRANK cannot have more than 200 characters")
    private String carrierRank;

    @Size(min = 1, message = "NEWRANK Codes cannot be null")
    @Digits(integer = 38, fraction = 0, message = "NEWRANK must be a number")
    private String newRank;

    @Size(min = 1, message = "State Codes cannot be null")
    @Size(max = 30, message = "State cannot have more than 200 characters")
    private String oldState;

    @Size(min = 1, message = "COUNTY Codes cannot be null")
    @Size(max = 50, message = "COUNTY cannot have more than 200 characters")
    private String OldCounty;

    @Size(min = 1, message = "CARRIERID Codes cannot be null")
    @Digits(integer = 38, fraction = 0, message = "CARRIERID must be a number")
    private String OldCarrierId;

    @Size(min = 1, message = "CARRIERNAME Codes cannot be null")
    @Size(max = 255, message = "CARRIERNAME cannot have more than 200 characters")
    private String OldCarrierName;

    @Size(max = 30, message = "CARRIERRANK cannot have more than 200 characters")
    private String oldCarrierRank;

    @Size(min = 1, message = "NEWRANK Codes cannot be null")
    @Digits(integer = 38, fraction = 0, message = "NEWRANK must be a number")
    private String oldNewRank;

    private boolean checkDuplicate;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(String carrierId) {
        this.carrierId = carrierId;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getCarrierRank() {
        return carrierRank;
    }

    public void setCarrierRank(String carrierRank) {
        this.carrierRank = carrierRank;
    }

    public String getNewRank() {
        return newRank;
    }

    public void setNewRank(String newRank) {
        this.newRank = newRank;
    }

    public String getOldState() {
        return oldState;
    }

    public void setOldState(String oldState) {
        this.oldState = oldState;
    }

    public String getOldCounty() {
        return OldCounty;
    }

    public void setOldCounty(String oldCounty) {
        OldCounty = oldCounty;
    }

    public String getOldCarrierId() {
        return OldCarrierId;
    }

    public void setOldCarrierId(String oldCarrierId) {
        OldCarrierId = oldCarrierId;
    }

    public String getOldCarrierName() {
        return OldCarrierName;
    }

    public void setOldCarrierName(String oldCarrierName) {
        OldCarrierName = oldCarrierName;
    }

    public String getOldCarrierRank() {
        return oldCarrierRank;
    }

    public void setOldCarrierRank(String oldCarrierRank) {
        this.oldCarrierRank = oldCarrierRank;
    }

    public String getOldNewRank() {
        return oldNewRank;
    }

    public void setOldNewRank(String oldNewRank) {
        this.oldNewRank = oldNewRank;
    }

    public boolean isCheckDuplicate() {
        return checkDuplicate;
    }

    public void setCheckDuplicate(boolean checkDuplicate) {
        this.checkDuplicate = checkDuplicate;
    }

    @Override
    public String toString() {
        return "TracfoneOneCarrierPref{" +
                "dbEnv='" + dbEnv + '\'' +
                ", state='" + state + '\'' +
                ", county='" + county + '\'' +
                ", carrierId='" + carrierId + '\'' +
                ", carrierName='" + carrierName + '\'' +
                ", carrierRank='" + carrierRank + '\'' +
                ", newRank='" + newRank + '\'' +
                ", oldState='" + oldState + '\'' +
                ", OldCounty='" + OldCounty + '\'' +
                ", OldCarrierId='" + OldCarrierId + '\'' +
                ", OldCarrierName='" + OldCarrierName + '\'' +
                ", oldCarrierRank='" + oldCarrierRank + '\'' +
                ", oldNewRank='" + oldNewRank + '\'' +
                ", checkDuplicate=" + checkDuplicate +
                '}';
    }
}
