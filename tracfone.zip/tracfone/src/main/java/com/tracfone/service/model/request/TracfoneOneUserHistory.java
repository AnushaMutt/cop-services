/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * COP.COP_ID_USER_HISTORY
 *
 * @author Pritesh.Singh
 */
public class TracfoneOneUserHistory {

    private String dbEnv;
    private String id;
    private String userId;
    private String type;
    private String fromCreationDate;
    private String toCreationDate;
    private List<TracfoneOneUserHistoryDetail> tracfoneUserHistoryDetail;

    public TracfoneOneUserHistory() {
        tracfoneUserHistoryDetail = new ArrayList<>();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<TracfoneOneUserHistoryDetail> getTracfoneUserHistoryDetail() {
        return tracfoneUserHistoryDetail;
    }

    public void setTracfoneUserHistoryDetail(List<TracfoneOneUserHistoryDetail> tracfoneUserHistoryDetail) { this.tracfoneUserHistoryDetail = tracfoneUserHistoryDetail; }

    public String getFromCreationDate() { return fromCreationDate; }

    public void setFromCreationDate(String fromCreationDate) { this.fromCreationDate = fromCreationDate; }

    public String getToCreationDate() { return toCreationDate; }

    public void setToCreationDate(String toCreationDate) { this.toCreationDate = toCreationDate; }

    @Override
    public String toString() {
        return "TracfoneOneUserHistory{" +
                "dbEnv='" + dbEnv + '\'' +
                ", id='" + id + '\'' +
                ", userId='" + userId + '\'' +
                ", type='" + type + '\'' +
                ", fromCreationDate='" + fromCreationDate + '\'' +
                ", toCreationDate='" + toCreationDate + '\'' +
                ", tracfoneUserHistoryDetail=" + tracfoneUserHistoryDetail +
                '}';
    }
}
