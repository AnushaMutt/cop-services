package com.tracfone.service.model.response;

public class TFOneGeoCoderLocation {
    private String x;
    private String y;

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }

    @Override
    public String toString() {
        return "TFOneGeoCoderLocation{" +
                "x='" + x + '\'' +
                ", y='" + y + '\'' +
                '}';
    }
}
