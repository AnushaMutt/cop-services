package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOnePCRFTransaction;
import com.tracfone.service.model.response.TFOnePCRFTransSearchResult;

import javax.ejb.Local;

/**
 * @author Gaurav.Sharma
 */
@Local
public interface TracfoneOnePCRFTransControllerLocal {

    TFOnePCRFTransSearchResult viewPcrfTransaction(TracfoneOnePCRFTransaction pcrfTransaction) throws TracfoneOneException;

}
