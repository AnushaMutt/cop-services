/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.filter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;

import javax.annotation.Priority;
import javax.ejb.EJB;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;
import java.io.IOException;

/**
 * @author Srinivas Murthy P
 */
@Provider
@Authorized
@Priority(Priorities.AUTHORIZATION)
public class AuthorizationFilter implements ContainerRequestFilter {

    public AuthorizationFilter() {
    }

    @EJB
    private TracfoneControllerLocal tracfoneController;

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        try {
            TracfoneOnePrincipal principal = (TracfoneOnePrincipal) requestContext.getSecurityContext().getUserPrincipal();
            checkAccessForRequestedResource(principal.getTFUser().getUserId(), getMappedURI(requestContext.getUriInfo().getPathSegments().get(1).toString()));
        } catch (TracfoneOneException e) {
            abortWithUnauthorized(requestContext, e);
        }
    }


    private void abortWithUnauthorized(ContainerRequestContext requestContext, TracfoneOneException tex) {

        Gson gson = new GsonBuilder().serializeNulls().create();
        // Abort the filter chain with a 401 status code response
        // The WWW-Authenticate header is sent along with the response
        requestContext.abortWith(Response.status(Response.Status.OK)
                .entity(gson.toJson(new CopUIErrorResponse("Unauthorized Access for requested resource.", Response.Status.UNAUTHORIZED.getStatusCode())))
                .build());
    }

    private int checkAccessForRequestedResource(int userId, String requestedResource) throws TracfoneOneException {
        return tracfoneController.checkAccessForRequestedResource(userId, requestedResource);
    }

    /**
     * This method is a serious violation of the initial draft, its sad that we have compromised the
     * Authorization and its principal how it works.
     * <p>
     * But we are sure we will return back to this code in Java 50 version
     *
     * @param uri
     * @return
     */
    private String getMappedURI(String uri) {

        //check for User resources child action.
        if (uri.equalsIgnoreCase("audithistory")) {
            return "users";
        }
        //check for actionItem ID child actions.
        if (uri.equalsIgnoreCase("rework") ||
                uri.equalsIgnoreCase("requeue") ||
                uri.equalsIgnoreCase("buckets") ||
                uri.equalsIgnoreCase("userhistory") ||
                uri.equalsIgnoreCase("assignusertask") ||
                uri.equalsIgnoreCase("updateusertask") ||
                uri.equalsIgnoreCase("usertask") ||
                uri.equalsIgnoreCase("userlist") ||
                uri.equalsIgnoreCase("allfailures")) {
            return "actionitemid";
        }

        return uri;
    }
}
