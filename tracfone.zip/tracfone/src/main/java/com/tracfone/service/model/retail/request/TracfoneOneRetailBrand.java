package com.tracfone.service.model.retail.request;

/**
 * C_RTL_BRAND
 *
 * @author Pritesh Singh
 */
public class TracfoneOneRetailBrand {

    private String objId;
    private String secUserId;
    private String status;
    private String brand;
    private String brandLong;
    private String insertDate;
    private String updateDate;
    private String traitLogicRuleId;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getBrandLong() {
        return brandLong;
    }

    public void setBrandLong(String brandLong) {
        this.brandLong = brandLong;
    }

    public String getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(String insertDate) {
        this.insertDate = insertDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(String secUserId) {
        this.secUserId = secUserId;
    }

    public String getTraitLogicRuleId() {
        return traitLogicRuleId;
    }

    public void setTraitLogicRuleId(String traitLogicRuleId) {
        this.traitLogicRuleId = traitLogicRuleId;
    }

    @Override
    public String toString() {
        return "TracfoneOneRetailBrand{" +
                "objId='" + objId + '\'' +
                ", secUserId='" + secUserId + '\'' +
                ", status='" + status + '\'' +
                ", brand='" + brand + '\'' +
                ", brandLong='" + brandLong + '\'' +
                ", insertDate='" + insertDate + '\'' +
                ", updateDate='" + updateDate + '\'' +
                ", cRtlTraitLogicRuleId='" + traitLogicRuleId + '\'' +
                '}';
    }
}

