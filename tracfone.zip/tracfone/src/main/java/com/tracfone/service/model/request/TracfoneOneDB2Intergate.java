package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * TABLE GW1.DB2INTERGATE
 *
 * @author Gaurav.Sharma
 */
public class TracfoneOneDB2Intergate {

    private String dbEnv;
    @NotNull(message = "Query Id cannot be null")
    @Digits(integer = 10, fraction = 0, message = "Query Id must be a number")
    private String queryId;
    @Size(max = 30, message = "Query Name cannot have more than 30 characters")
    private String queryName;
    @Size(max = 5, message = "Active Flag cannot have more than 5 characters")
    private String activeFlag;
    @Size(max = 10, message = "Use New Sql cannot have more than 10 characters")
    private String useNewSql;
    @Size(max = 10, message = "Interval Time cannot have more than 10 characters")
    private String intervalTime;
    private String selectQueryClob;
    @Digits(integer = 38, fraction = 0, message = "Number of Records must be a number")
    private String numberOfRecords;
    @Size(max = 200, message = "Update Query cannot have more than 200 characters")
    private String updateQuery;
    @Size(max = 100, message = "Templates cannot have more than 100 characters")
    private String templates;
    @Size(max = 1000, message = "Order Types cannot have more than 1000 characters")
    private String orderTypes;
    @Size(max = 4000, message = "Extra Where Clause Conditions cannot have more than 4000 characters")
    private String extraWhereClauseConditions;
    @Size(max = 30, message = "App Name cannot have more than 30 characters")
    private String appName;
    @Digits(integer = 38, fraction = 0, message = "Starting Records must be a number")
    private String startingRecord;
    @Size(max = 100, message = "Remarks cannot have more than 30 characters")
    private String remarks;

    public String getQueryId() {
        return queryId;
    }

    public void setQueryId(String queryId) {
        this.queryId = queryId;
    }

    public String getQueryName() {
        return queryName;
    }

    public void setQueryName(String queryName) {
        this.queryName = queryName;
    }

    public String getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(String activeFlag) {
        this.activeFlag = activeFlag;
    }

    public String getUseNewSql() {
        return useNewSql;
    }

    public void setUseNewSql(String useNewSql) {
        this.useNewSql = useNewSql;
    }

    public String getIntervalTime() {
        return intervalTime;
    }

    public void setIntervalTime(String intervalTime) {
        this.intervalTime = intervalTime;
    }

    public String getSelectQueryClob() {
        return selectQueryClob;
    }

    public void setSelectQueryClob(String selectQueryClob) {
        this.selectQueryClob = selectQueryClob;
    }

    public String getNumberOfRecords() {
        return numberOfRecords;
    }

    public void setNumberOfRecords(String numberOfRecords) {
        this.numberOfRecords = numberOfRecords;
    }

    public String getUpdateQuery() {
        return updateQuery;
    }

    public void setUpdateQuery(String updateQuery) {
        this.updateQuery = updateQuery;
    }

    public String getTemplates() {
        return templates;
    }

    public void setTemplates(String templates) {
        this.templates = templates;
    }

    public String getOrderTypes() {
        return orderTypes;
    }

    public void setOrderTypes(String orderTypes) {
        this.orderTypes = orderTypes;
    }

    public String getExtraWhereClauseConditions() {
        return extraWhereClauseConditions;
    }

    public void setExtraWhereClauseConditions(String extraWhereClauseConditions) {
        this.extraWhereClauseConditions = extraWhereClauseConditions;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getStartingRecord() {
        return startingRecord;
    }

    public void setStartingRecord(String startingRecord) {
        this.startingRecord = startingRecord;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    @Override
    public String toString() {
        return "TracfoneOneDB2Intergate{" +
                "dbEnv='" + dbEnv + '\'' +
                ", queryId='" + queryId + '\'' +
                ", queryName='" + queryName + '\'' +
                ", activeFlag='" + activeFlag + '\'' +
                ", useNewSql='" + useNewSql + '\'' +
                ", intervalTime='" + intervalTime + '\'' +
                ", selectQueryClob='" + selectQueryClob + '\'' +
                ", numberOfRecords='" + numberOfRecords + '\'' +
                ", updateQuery='" + updateQuery + '\'' +
                ", templates='" + templates + '\'' +
                ", orderTypes='" + orderTypes + '\'' +
                ", extraWhereClauseConditions='" + extraWhereClauseConditions + '\'' +
                ", appName='" + appName + '\'' +
                ", startingRecord='" + startingRecord + '\'' +
                ", remarks='" + remarks + '\'' +
                '}';
    }
}
