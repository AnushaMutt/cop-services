package com.tracfone.service.model.request;

import javax.validation.constraints.Size;

public class TracfoneOneArUsaMarket {
    @Size(min = 1, message = "KEYCODE Codes cannot be null")
    @Size(max = 200, message = "KEYCODE cannot have more than 200 characters")
    private String keyCode;
    @Size(min = 1, message = "NATION Codes cannot be null")
    @Size(max = 3, message = "NATION cannot have more than 200 characters")
    private String nation;
    @Size(min = 1, message = "STATE Codes cannot be null")
    @Size(max = 2, message = "STATE cannot have more than 200 characters")
    private String state;
    @Size(min = 1, message = "COUNTY Codes cannot be null")
    @Size(max = 200, message = "COUNTY cannot have more than 200 characters")
    private String county;
    @Size(min = 1, message = "CARRIER_ENTITY Codes cannot be null")
    @Size(max = 200, message = "CARRIER_ENTITY cannot have more than 200 characters")
    private String carrierEntity;
    @Size(min = 1, message = "MARKETING_NAME Codes cannot be null")
    @Size(max = 200, message = "MARKETING_NAME cannot have more than 200 characters")
    private String marketingName;
    @Size(min = 1, message = "MHZ_TOTAL Codes cannot be null")
    @Size(max = 200, message = "MHZ_TOTAL cannot have more than 200 characters")
    private String mhzTotal;
    @Size(min = 1, message = "SPECTRUM_BLOCKS Codes cannot be null")
    @Size(max = 200, message = "SPECTRUM_BLOCKS cannot have more than 200 characters")
    private String spectrumBlocks;
    @Size(min = 1, message = "CMA_MKT_CODE Codes cannot be null")
    @Size(max = 200, message = "CMA_MKT_CODE cannot have more than 200 characters")
    private String cmaMktCode;
    @Size(min = 1, message = "CMA_MKT_STATE Codes cannot be null")
    @Size(max = 200, message = "CMA_MKT_STATE cannot have more than 200 characters")
    private String cmaMktState;
    @Size(min = 1, message = "CMA_MKT_NAME Codes cannot be null")
    @Size(max = 200, message = "CMA_MKT_NAME cannot have more than 200 characters")
    private String cmaMktName;
    @Size(min = 1, message = "CMA_MKT_NAME_ALTERNATE Codes cannot be null")
    @Size(max = 200, message = "CMA_MKT_NAME_ALTERNATE cannot have more than 200 characters")
    private String cmaMktNameAlternate;
    @Size(min = 1, message = "CMA_MKT_MULTI_STATE Codes cannot be null")
    @Size(max = 200, message = "CMA_MKT_MULTI_STATE cannot have more than 200 characters")
    private String cmaMktMultiState;
    @Size(min = 1, message = "BTA_MKT_CODE Codes cannot be null")
    @Size(max = 200, message = "BTA_MKT_CODE cannot have more than 200 characters")
    private String btaMktCode;
    @Size(min = 1, message = "BTA_MKT_STATE Codes cannot be null")
    @Size(max = 200, message = "BTA_MKT_STATE cannot have more than 200 characters")
    private String btaMktState;
    @Size(min = 1, message = "BTA_MKT_NAME Codes cannot be null")
    @Size(max = 200, message = "BTA_MKT_NAME cannot have more than 200 characters")
    private String btaMktName;
    @Size(min = 1, message = "BTA_MKT_NAME_ALTERNATE Codes cannot be null")
    @Size(max = 200, message = "BTA_MKT_NAME_ALTERNATE cannot have more than 200 characters")
    private String btaMktNameAlternate;
    @Size(min = 1, message = "BTA_MKT_MULTI_STATE Codes cannot be null")
    @Size(max = 200, message = "BTA_MKT_MULTI_STATE cannot have more than 200 characters")
    private String btaMktMultiState;
    @Size(min = 1, message = "BEA_MKT_CODE Codes cannot be null")
    @Size(max = 200, message = "BEA_MKT_CODE cannot have more than 200 characters")
    private String beaMktCode;
    @Size(min = 1, message = "BEA_MKT_STATE Codes cannot be null")
    @Size(max = 200, message = "BEA_MKT_STATE cannot have more than 200 characters")
    private String beaMktState;
    @Size(min = 1, message = "BEA_MKT_NAME Codes cannot be null")
    @Size(max = 200, message = "BEA_MKT_NAME cannot have more than 200 characters")
    private String beaMktName;
    @Size(min = 1, message = "BEA_MKT_NAME_ALTERNATE Codes cannot be null")
    @Size(max = 200, message = "BEA_MKT_NAME_ALTERNATE cannot have more than 200 characters")
    private String beaMktNameAlternate;
    @Size(min = 1, message = "BEA_MKT_MULTI_STATE Codes cannot be null")
    @Size(max = 200, message = "BEA_MKT_MULTI_STATE cannot have more than 200 characters")
    private String beaMktMultiState;
    @Size(max = 200, message = "PROTOCOL cannot have more than 200 characters")
    private String protocol;
    @Size(max = 200, message = "EXTENDEDSERVICES cannot have more than 200 characters")
    private String extendedServices;
    @Size(max = 200, message = "BID1 cannot have more than 200 characters")
    private String bid1;
    @Size(max = 200, message = "BID1NAME cannot have more than 200 characters")
    private String bid1Name;
    @Size(max = 200, message = "BID1BSID1 cannot have more than 200 characters")
    private String bid1Bsid1;
    @Size(max = 200, message = "BID1BSID2 cannot have more than 200 characters")
    private String bid1Bsid2;
    @Size(max = 200, message = "BID1BSID3 cannot have more than 200 characters")
    private String bid1Bsid3;
    @Size(max = 200, message = "BID1MNC cannot have more than 200 characters")
    private String bid1Mnc;
    @Size(max = 200, message = "BID2 cannot have more than 200 characters")
    private String bid2;
    @Size(max = 200, message = "BID2NAME cannot have more than 200 characters")
    private String bid2Name;
    @Size(max = 200, message = "BID2BSID1 cannot have more than 200 characters")
    private String bid2Bsid1;
    @Size(max = 200, message = "BID2BSID2 cannot have more than 200 characters")
    private String bid2Bsid2;
    @Size(max = 200, message = "BID2BSID3 cannot have more than 200 characters")
    private String bid2Bsid3;
    @Size(max = 200, message = "BID2MNC cannot have more than 200 characters")
    private String bid2Mnc;
    @Size(max = 200, message = "BID3 cannot have more than 200 characters")
    private String bid3;
    @Size(max = 200, message = "BID3NAME cannot have more than 200 characters")
    private String bid3Name;
    @Size(max = 200, message = "BID3BSID1 cannot have more than 200 characters")
    private String bid3Bsid1;
    @Size(max = 200, message = "BID3BSID2 cannot have more than 200 characters")
    private String bid3Bsid2;
    @Size(max = 200, message = "BID3BSID3 cannot have more than 200 characters")
    private String bid3Bsid3;
    @Size(max = 200, message = "BID3MNC cannot have more than 200 characters")
    private String bid3Mnc;
    @Size(max = 200, message = "BID4 cannot have more than 200 characters")
    private String bid4;
    @Size(max = 200, message = "BID4NAME cannot have more than 200 characters")
    private String bid4Name;
    @Size(max = 200, message = "BID4BSID1 cannot have more than 200 characters")
    private String bid4Bsid1;
    @Size(max = 200, message = "BID4BSID2 cannot have more than 200 characters")
    private String bid4Bsid2;
    @Size(max = 200, message = "BID4BSID3 cannot have more than 200 characters")
    private String bid4Bsid3;
    @Size(max = 200, message = "BID4MNC cannot have more than 200 characters")
    private String bid4Mnc;
    private String dbEnv;
    @Size(min = 1, message = "KEYCODE Codes cannot be null")
    @Size(max = 200, message = "KEYCODE cannot have more than 200 characters")
    private String oldKeyCode;
    @Size(min = 1, message = "CARRIER_ENTITY Codes cannot be null")
    @Size(max = 200, message = "CARRIER_ENTITY cannot have more than 200 characters")
    private String oldCarrierEntity;
    private boolean checkDuplicate;
    private TracfoneonePaginationSearch paginationSearch;

    public String getKeyCode() {
        return keyCode;
    }

    public void setKeyCode(String keyCode) {
        this.keyCode = keyCode;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getCarrierEntity() {
        return carrierEntity;
    }

    public void setCarrierEntity(String carrierEntity) {
        this.carrierEntity = carrierEntity;
    }

    public String getMarketingName() {
        return marketingName;
    }

    public void setMarketingName(String marketingName) {
        this.marketingName = marketingName;
    }

    public String getMhzTotal() {
        return mhzTotal;
    }

    public void setMhzTotal(String mhzTotal) {
        this.mhzTotal = mhzTotal;
    }

    public String getSpectrumBlocks() {
        return spectrumBlocks;
    }

    public void setSpectrumBlocks(String spectrumBlocks) {
        this.spectrumBlocks = spectrumBlocks;
    }

    public String getCmaMktCode() {
        return cmaMktCode;
    }

    public void setCmaMktCode(String cmaMktCode) {
        this.cmaMktCode = cmaMktCode;
    }

    public String getCmaMktState() {
        return cmaMktState;
    }

    public void setCmaMktState(String cmaMktState) {
        this.cmaMktState = cmaMktState;
    }

    public String getCmaMktName() {
        return cmaMktName;
    }

    public void setCmaMktName(String cmaMktName) {
        this.cmaMktName = cmaMktName;
    }

    public String getCmaMktNameAlternate() {
        return cmaMktNameAlternate;
    }

    public void setCmaMktNameAlternate(String cmaMktNameAlternate) {
        this.cmaMktNameAlternate = cmaMktNameAlternate;
    }

    public String getCmaMktMultiState() {
        return cmaMktMultiState;
    }

    public void setCmaMktMultiState(String cmaMktMultiState) {
        this.cmaMktMultiState = cmaMktMultiState;
    }

    public String getBtaMktCode() {
        return btaMktCode;
    }

    public void setBtaMktCode(String btaMktCode) {
        this.btaMktCode = btaMktCode;
    }

    public String getBtaMktState() {
        return btaMktState;
    }

    public void setBtaMktState(String btaMktState) {
        this.btaMktState = btaMktState;
    }

    public String getBtaMktName() {
        return btaMktName;
    }

    public void setBtaMktName(String btaMktName) {
        this.btaMktName = btaMktName;
    }

    public String getBtaMktNameAlternate() {
        return btaMktNameAlternate;
    }

    public void setBtaMktNameAlternate(String btaMktNameAlternate) {
        this.btaMktNameAlternate = btaMktNameAlternate;
    }

    public String getBtaMktMultiState() {
        return btaMktMultiState;
    }

    public void setBtaMktMultiState(String btaMktMultiState) {
        this.btaMktMultiState = btaMktMultiState;
    }

    public String getBeaMktCode() {
        return beaMktCode;
    }

    public void setBeaMktCode(String beaMktCode) {
        this.beaMktCode = beaMktCode;
    }

    public String getBeaMktState() {
        return beaMktState;
    }

    public void setBeaMktState(String beaMktState) {
        this.beaMktState = beaMktState;
    }

    public String getBeaMktName() {
        return beaMktName;
    }

    public void setBeaMktName(String beaMktName) {
        this.beaMktName = beaMktName;
    }

    public String getBeaMktNameAlternate() {
        return beaMktNameAlternate;
    }

    public void setBeaMktNameAlternate(String beaMktNameAlternate) {
        this.beaMktNameAlternate = beaMktNameAlternate;
    }

    public String getBeaMktMultiState() {
        return beaMktMultiState;
    }

    public void setBeaMktMultiState(String beaMktMultiState) {
        this.beaMktMultiState = beaMktMultiState;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public String getExtendedServices() {
        return extendedServices;
    }

    public void setExtendedServices(String extendedServices) {
        this.extendedServices = extendedServices;
    }

    public String getBid1() {
        return bid1;
    }

    public void setBid1(String bid1) {
        this.bid1 = bid1;
    }

    public String getBid1Name() {
        return bid1Name;
    }

    public void setBid1Name(String bid1Name) {
        this.bid1Name = bid1Name;
    }

    public String getBid1Bsid1() {
        return bid1Bsid1;
    }

    public void setBid1Bsid1(String bid1Bsid1) {
        this.bid1Bsid1 = bid1Bsid1;
    }

    public String getBid1Bsid2() {
        return bid1Bsid2;
    }

    public void setBid1Bsid2(String bid1Bsid2) {
        this.bid1Bsid2 = bid1Bsid2;
    }

    public String getBid1Bsid3() {
        return bid1Bsid3;
    }

    public void setBid1Bsid3(String bid1Bsid3) {
        this.bid1Bsid3 = bid1Bsid3;
    }

    public String getBid1Mnc() {
        return bid1Mnc;
    }

    public void setBid1Mnc(String bid1Mnc) {
        this.bid1Mnc = bid1Mnc;
    }

    public String getBid2() {
        return bid2;
    }

    public void setBid2(String bid2) {
        this.bid2 = bid2;
    }

    public String getBid2Name() {
        return bid2Name;
    }

    public void setBid2Name(String bid2Name) {
        this.bid2Name = bid2Name;
    }

    public String getBid2Bsid1() {
        return bid2Bsid1;
    }

    public void setBid2Bsid1(String bid2Bsid1) {
        this.bid2Bsid1 = bid2Bsid1;
    }

    public String getBid2Bsid2() {
        return bid2Bsid2;
    }

    public void setBid2Bsid2(String bid2Bsid2) {
        this.bid2Bsid2 = bid2Bsid2;
    }

    public String getBid2Bsid3() {
        return bid2Bsid3;
    }

    public void setBid2Bsid3(String bid2Bsid3) {
        this.bid2Bsid3 = bid2Bsid3;
    }

    public String getBid2Mnc() {
        return bid2Mnc;
    }

    public void setBid2Mnc(String bid2Mnc) {
        this.bid2Mnc = bid2Mnc;
    }

    public String getBid3() {
        return bid3;
    }

    public void setBid3(String bid3) {
        this.bid3 = bid3;
    }

    public String getBid3Name() {
        return bid3Name;
    }

    public void setBid3Name(String bid3Name) {
        this.bid3Name = bid3Name;
    }

    public String getBid3Bsid1() {
        return bid3Bsid1;
    }

    public void setBid3Bsid1(String bid3Bsid1) {
        this.bid3Bsid1 = bid3Bsid1;
    }

    public String getBid3Bsid2() {
        return bid3Bsid2;
    }

    public void setBid3Bsid2(String bid3Bsid2) {
        this.bid3Bsid2 = bid3Bsid2;
    }

    public String getBid3Bsid3() {
        return bid3Bsid3;
    }

    public void setBid3Bsid3(String bid3Bsid3) {
        this.bid3Bsid3 = bid3Bsid3;
    }

    public String getBid3Mnc() {
        return bid3Mnc;
    }

    public void setBid3Mnc(String bid3Mnc) {
        this.bid3Mnc = bid3Mnc;
    }

    public String getBid4() {
        return bid4;
    }

    public void setBid4(String bid4) {
        this.bid4 = bid4;
    }

    public String getBid4Name() {
        return bid4Name;
    }

    public void setBid4Name(String bid4Name) {
        this.bid4Name = bid4Name;
    }

    public String getBid4Bsid1() {
        return bid4Bsid1;
    }

    public void setBid4Bsid1(String bid4Bsid1) {
        this.bid4Bsid1 = bid4Bsid1;
    }

    public String getBid4Bsid2() {
        return bid4Bsid2;
    }

    public void setBid4Bsid2(String bid4Bsid2) {
        this.bid4Bsid2 = bid4Bsid2;
    }

    public String getBid4Bsid3() {
        return bid4Bsid3;
    }

    public void setBid4Bsid3(String bid4Bsid3) {
        this.bid4Bsid3 = bid4Bsid3;
    }

    public String getBid4Mnc() {
        return bid4Mnc;
    }

    public void setBid4Mnc(String bid4Mnc) {
        this.bid4Mnc = bid4Mnc;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getOldKeyCode() {
        return oldKeyCode;
    }

    public void setOldKeyCode(String oldKeyCode) {
        this.oldKeyCode = oldKeyCode;
    }

    public String getOldCarrierEntity() {
        return oldCarrierEntity;
    }

    public void setOldCarrierEntity(String oldCarrierEntity) {
        this.oldCarrierEntity = oldCarrierEntity;
    }

    public boolean isCheckDuplicate() {
        return checkDuplicate;
    }

    public void setCheckDuplicate(boolean checkDuplicate) {
        this.checkDuplicate = checkDuplicate;
    }

    public TracfoneonePaginationSearch getPaginationSearch() {
        return paginationSearch;
    }

    public void setPaginationSearch(TracfoneonePaginationSearch paginationSearch) {
        this.paginationSearch = paginationSearch;
    }

    @Override
    public String toString() {
        return "TracfoneOneArUsaMarket{" +
                "keyCode='" + keyCode + '\'' +
                ", nation='" + nation + '\'' +
                ", state='" + state + '\'' +
                ", county='" + county + '\'' +
                ", carrierEntity='" + carrierEntity + '\'' +
                ", marketingName='" + marketingName + '\'' +
                ", mhzTotal='" + mhzTotal + '\'' +
                ", spectrumBlocks='" + spectrumBlocks + '\'' +
                ", cmaMktCode='" + cmaMktCode + '\'' +
                ", cmaMktState='" + cmaMktState + '\'' +
                ", cmaMktName='" + cmaMktName + '\'' +
                ", cmaMktNameAlternate='" + cmaMktNameAlternate + '\'' +
                ", cmaMktMultiState='" + cmaMktMultiState + '\'' +
                ", btaMktCode='" + btaMktCode + '\'' +
                ", btaMktState='" + btaMktState + '\'' +
                ", btaMktName='" + btaMktName + '\'' +
                ", btaMktNameAlternate='" + btaMktNameAlternate + '\'' +
                ", btaMktMultiState='" + btaMktMultiState + '\'' +
                ", beaMktCode='" + beaMktCode + '\'' +
                ", beaMktState='" + beaMktState + '\'' +
                ", beaMktName='" + beaMktName + '\'' +
                ", beaMktNameAlternate='" + beaMktNameAlternate + '\'' +
                ", beaMktMultiState='" + beaMktMultiState + '\'' +
                ", protocol='" + protocol + '\'' +
                ", extendedServices='" + extendedServices + '\'' +
                ", bid1='" + bid1 + '\'' +
                ", bid1Name='" + bid1Name + '\'' +
                ", bid1Bsid1='" + bid1Bsid1 + '\'' +
                ", bid1Bsid2='" + bid1Bsid2 + '\'' +
                ", bid1Bsid3='" + bid1Bsid3 + '\'' +
                ", bid1Mnc='" + bid1Mnc + '\'' +
                ", bid2='" + bid2 + '\'' +
                ", bid2Name='" + bid2Name + '\'' +
                ", bid2Bsid1='" + bid2Bsid1 + '\'' +
                ", bid2Bsid2='" + bid2Bsid2 + '\'' +
                ", bid2Bsid3='" + bid2Bsid3 + '\'' +
                ", bid2Mnc='" + bid2Mnc + '\'' +
                ", bid3='" + bid3 + '\'' +
                ", bid3Name='" + bid3Name + '\'' +
                ", bid3Bsid1='" + bid3Bsid1 + '\'' +
                ", bid3Bsid2='" + bid3Bsid2 + '\'' +
                ", bid3Bsid3='" + bid3Bsid3 + '\'' +
                ", bid3Mnc='" + bid3Mnc + '\'' +
                ", bid4='" + bid4 + '\'' +
                ", bid4Name='" + bid4Name + '\'' +
                ", bid4Bsid1='" + bid4Bsid1 + '\'' +
                ", bid4Bsid2='" + bid4Bsid2 + '\'' +
                ", bid4Bsid3='" + bid4Bsid3 + '\'' +
                ", bid4Mnc='" + bid4Mnc + '\'' +
                ", dbEnv='" + dbEnv + '\'' +
                ", oldKeyCode='" + oldKeyCode + '\'' +
                ", oldCarrierEntity='" + oldCarrierEntity + '\'' +
                ", checkDuplicate=" + checkDuplicate +
                ", paginationSearch=" + paginationSearch +
                '}';
    }
}
