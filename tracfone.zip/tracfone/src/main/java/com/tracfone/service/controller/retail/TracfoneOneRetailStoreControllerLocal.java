package com.tracfone.service.controller.retail;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.retail.request.TracfoneOneRetailLocation;
import com.tracfone.service.model.retail.request.TracfoneOneRetailTpAdminSearchModel;

import javax.ejb.Local;
import java.util.List;

@Local
public interface TracfoneOneRetailStoreControllerLocal {

    TFOneGeneralResponse insertTpNorms(TracfoneOneRetailTpAdminSearchModel retailTpAdminSearchModel, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateRetailLocationRadius(List<TracfoneOneRetailLocation> tracfoneOneRetailLocations, int userId) throws TracfoneOneException;

    TFOneGeneralResponse openStores(List<TracfoneOneRetailLocation> tracfoneOneRetailLocation, int userId) throws TracfoneOneException;
}
