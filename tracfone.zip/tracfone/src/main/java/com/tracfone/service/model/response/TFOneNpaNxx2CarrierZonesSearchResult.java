package com.tracfone.service.model.response;

import com.tracfone.service.model.request.TracfoneonePaginationSearch;

import java.util.ArrayList;
import java.util.List;

public class TFOneNpaNxx2CarrierZonesSearchResult {
    private TracfoneonePaginationSearch paginationSearch;
    private List<TFOneNpanxx2Carrierzones> npanxx2Carrierzones;

    public TFOneNpaNxx2CarrierZonesSearchResult() {
        npanxx2Carrierzones = new ArrayList<>();
    }

    public TracfoneonePaginationSearch getPaginationSearch() {
        return paginationSearch;
    }

    public void setPaginationSearch(TracfoneonePaginationSearch paginationSearch) {
        this.paginationSearch = paginationSearch;
    }

    public List<TFOneNpanxx2Carrierzones> getNpanxx2Carrierzones() {
        return npanxx2Carrierzones;
    }

    public void setNpanxx2Carrierzones(List<TFOneNpanxx2Carrierzones> npanxx2Carrierzones) {
        this.npanxx2Carrierzones = npanxx2Carrierzones;
    }

    @Override
    public String toString() {
        return "TFOneNpaNxx2CarrierZonesSearchResult{" +
                "paginationSearch=" + paginationSearch +
                ", npanxx2Carrierzones=" + npanxx2Carrierzones +
                '}';
    }
}
