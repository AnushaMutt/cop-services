package com.tracfone.service.controller;

import java.util.Hashtable;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 *
 * @author spulavarthy
 */
@Singleton
public class DataBaseController {
 
  @Lock(LockType.READ)
  public DataSource getDataSource(String dsName) throws NamingException {  
      //System.out.println("Looking up DataSource: " + dsName);
    Context initCtx = new InitialContext(getEnvironmentConfig());
    DataSource dataSource = (DataSource)initCtx.lookup(dsName);
    return dataSource;
}

private Hashtable<String, String> getEnvironmentConfig() {

    Hashtable<String, String> environmentConfigMap = new Hashtable<String, String>(7);
    //environmentConfigMap.put(Context.PROVIDER_URL, "http://localhost:4848"); // Local Glassfish
    environmentConfigMap.put(Context.PROVIDER_URL, "t3://localhost:8301"); // Weblogic SITA.
    return environmentConfigMap;

}


}
