package com.tracfone.service.model.retail.response;

public class TFOneRetailTech {
    private String objId;
    private String secUserId;
    private String status;
    private String tech;
    private String techLong;
    private String insertDate;
    private String updateDate;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(String secUserId) {
        this.secUserId = secUserId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTech() {
        return tech;
    }

    public void setTech(String tech) {
        this.tech = tech;
    }

    public String getTechLong() {
        return techLong;
    }

    public void setTechLong(String techLong) {
        this.techLong = techLong;
    }

    public String getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(String insertDate) {
        this.insertDate = insertDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    @Override
    public String toString() {
        return "TFOneRetailTech{" +
                "objId='" + objId + '\'' +
                ", secUserId='" + secUserId + '\'' +
                ", status='" + status + '\'' +
                ", tech='" + tech + '\'' +
                ", techLong='" + techLong + '\'' +
                ", insertDate=" + insertDate +
                ", updateDate=" + updateDate +
                '}';
    }
}
