package com.tracfone.service.model.request;

import javax.validation.constraints.Size;

/**
 * @author Thejaswini
 */
public class TracfoneOneThrottlePolicy {
    private String dbEnv;
    private String objId;
    @Size(min = 1, message = "Policy Name cannot be null")
    @Size(max = 20, message = "Policy Name cannot have more than 20 characters")
    private String policyName;
    @Size(min = 1, message = "Policy Description cannot be null")
    @Size(max = 40, message = "Policy Description cannot have more than 40 characters")
    private String policyDesc;
    @Size(max = 30, message = "Bypass Trans Queue cannot have more than 30 characters")
    private String bypassTransQueue;
    @Size(max = 1, message = "Data Suspended Flag cannot have more than 1 character")
    private String dataSuspendedFlag;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    public String getPolicyDesc() {
        return policyDesc;
    }

    public void setPolicyDesc(String policyDesc) {
        this.policyDesc = policyDesc;
    }

    public String getBypassTransQueue() {
        return bypassTransQueue;
    }

    public void setBypassTransQueue(String bypassTransQueue) {
        this.bypassTransQueue = bypassTransQueue;
    }

    public String getDataSuspendedFlag() {
        return dataSuspendedFlag;
    }

    public void setDataSuspendedFlag(String dataSuspendedFlag) {
        this.dataSuspendedFlag = dataSuspendedFlag;
    }

    @Override
    public String toString() {
        return "TracfoneOneThrottlePolicy{" +
                "dbEnv='" + dbEnv + '\'' +
                ", objId='" + objId + '\'' +
                ", policyName='" + policyName + '\'' +
                ", policyDesc='" + policyDesc + '\'' +
                ", bypassTransQueue='" + bypassTransQueue + '\'' +
                ", dataSuspendedFlag='" + dataSuspendedFlag + '\'' +
                '}';
    }
}
