package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneIgFailLogs;
import com.tracfone.service.model.request.TracfoneonePaginationSearch;
import com.tracfone.service.model.response.TFOneIGFailLogs;
import com.tracfone.service.model.response.TFOneIgFailLogSearchModel;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantIgFailLags;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author thejaswini
 */
@Stateless
public class TracfoneOneIgFailLogsAction implements TracfoneOneIgFailLogsActionLocal, TracfoneOneConstantIgFailLags,TracfoneOneConstant {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneIgFailLogsAction.class);
    @EJB
    DataBaseController dbControllerEJB;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @Override
    public TFOneIgFailLogSearchModel getIgFailLogs(TracfoneOneIgFailLogs tracfoneOneIgFailLogs) throws TracfoneOneException {
        TFOneIgFailLogSearchModel tfOneIgFailLogSearchModel = new TFOneIgFailLogSearchModel();
        List<TFOneIGFailLogs> tfOneIGFailLogs = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneIgFailLogs.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getIgFailLogsStatement(TRACFONE_GET_ALL_IG_FAIL_LOGS_START,tracfoneOneIgFailLogs));
             PreparedStatement stmtCount = con.prepareStatement(getIgFailLogsQueryParams(TRACFONE_GET_ALL_IG_FAIL_LOGS_COUNT, tracfoneOneIgFailLogs))) {
            setIgFailLogsQueryParams(stmt,stmtCount, tracfoneOneIgFailLogs);
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneIGFailLogs.add(setIgFailLogs(resultSet));
                }
                tfOneIgFailLogSearchModel.setiGFailLogs(tfOneIGFailLogs);
            }

            int count = 0;
            try (ResultSet resultSetCount = stmtCount.executeQuery()) {
                while (resultSetCount.next()) {
                    count = resultSetCount.getInt(1);
                }
            }
            TracfoneonePaginationSearch tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
            tracfoneonePaginationSearch.setStartIndex(tracfoneOneIgFailLogs.getPaginationSearch().getStartIndex());
            tracfoneonePaginationSearch.setEndIndex(tracfoneOneIgFailLogs.getPaginationSearch().getEndIndex());
            tracfoneonePaginationSearch.setTotal(count);
            tfOneIgFailLogSearchModel.setPaginationSearch(tracfoneonePaginationSearch);

        } catch (Exception e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneIgFailLogSearchModel;
    }

    private String getIgFailLogsQueryParams(String query, TracfoneOneIgFailLogs tracfoneOneIgFailLogs) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(query);
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getActionItemId())) {
            builder.append("ACTION_ITEM_ID LIKE ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCarrierId())) {
            builder.append("CARRIER_ID = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getOrderType())) {
            builder.append("ORDER_TYPE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getMin())) {
            builder.append("MIN = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getEsn())) {
            builder.append("ESN = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getEsnHex())) {
            builder.append("ESN_HEX = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getOldEsn())) {
            builder.append("OLD_ESN = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getOldEsnHex())) {
            builder.append("OLD_ESN_HEX = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getPin())) {
            builder.append("PIN = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getPhoneManf())) {
            builder.append("PHONE_MANF = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getEndUser())) {
            builder.append("END_USER = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getAccountNum())) {
            builder.append("ACCOUNT_NUM = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getMarketCode())) {
            builder.append("MARKET_CODE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getRatePlan())) {
            builder.append("RATE_PLAN = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getLdProvider())) {
            builder.append("LD_PROVIDER = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getSequenceNum())) {
            builder.append("SEQUENCE_NUM = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getDealerCode())) {
            builder.append("DEALER_CODE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getTransmissionMethod())) {
            builder.append("TRANSMISSION_METHOD = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getFaxNum())) {
            builder.append("FAX_NUM = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getOnlineNum())) {
            builder.append("ONLINE_NUM = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getEmail())) {
            builder.append("EMAIL = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getNetworkLogin())) {
            builder.append("NETWORK_LOGIN = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getNetworkPassword())) {
            builder.append("NETWORK_PASSWORD = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getSystemLogin())) {
            builder.append("SYSTEM_LOGIN = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getSystemPassword())) {
            builder.append("SYSTEM_PASSWORD = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getTemplate())) {
            builder.append("TEMPLATE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getComPort())) {
            builder.append("COM_PORT = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getStatus())) {
            builder.append("STATUS = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getStatusMessage())) {
            builder.append("STATUS_MESSAGE LIKE ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getTransProfKey())) {
            builder.append("TRANS_PROF_KEY = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getqTransaction())) {
            builder.append("Q_TRANSACTION = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getFaxNum2())) {
            builder.append("FAX_NUM2 = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCreationDate())) {
            builder.append("CREATION_DATE between TO_DATE(?, 'DD/MM/yyyy HH24:MI:SS') and TO_DATE(?, 'DD/MM/yyyy HH24:MI:SS')").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getUpdateDate())) {
            builder.append("TO_CHAR(UPDATE_DATE,'DD-MM-YYYY') = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getBlackoutWait())) {
            builder.append("TO_CHAR(BLACKOUT_WAIT,'DD-MM-YYYY') = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getTransactionId())) {
            builder.append("TRANSACTION_ID = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getTechnologyFlag())) {
            builder.append("TECHNOLOGY_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getVoiceMail())) {
            builder.append("VOICE_MAIL = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getVoiceMailPackage())) {
            builder.append("VOICE_MAIL_PACKAGE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCallerId())) {
            builder.append("CALLER_ID = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCallerIdPackage())) {
            builder.append("CALLER_ID_PACKAGE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCallWaiting())) {
            builder.append("CALL_WAITING = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCallWaitingPackage())) {
            builder.append("CALL_WAITING_PACKAGE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getDigitalFeatureCode())) {
            builder.append("DIGITAL_FEATURE_CODE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getStateField())) {
            builder.append("STATE_FIELD = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getZipCode())) {
            builder.append("ZIP_CODE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getMsid())) {
            builder.append("MSID = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getNewMsidFlag())) {
            builder.append("NEW_MSID_FLAG = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getSms())) {
            builder.append("SMS = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getSmsPackage())) {
            builder.append("SMS_PACKAGE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getIccid())) {
            builder.append("ICCID = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getOldMin())) {
            builder.append("OLD_MIN = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getDigitalFeature())) {
            builder.append("DIGITAL_FEATURE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getOtaType())) {
            builder.append("OTA_TYPE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getRateCenterNo())) {
            builder.append("RATE_CENTER_NO = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getApplicationSystem())) {
            builder.append("APPLICATION_SYSTEM = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getSubscriberUpdate())) {
            builder.append("SUBSCRIBER_UPDATE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getPrlNumber())) {
            builder.append("PRL_NUMBER = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getAmount())) {
            builder.append("AMOUNT = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getBalance())) {
            builder.append("BALANCE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getLanguage())) {
            builder.append("LANGUAGE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getExpDate())) {
            builder.append("TO_CHAR(EXP_DATE,'DD-MM-YYYY') = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getxMpn())) {
            builder.append("X_MPN = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getxMpnCode())) {
            builder.append("X_MPN_CODE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getxPoolName())) {
            builder.append("X_POOL_NAME = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getxMake())) {
            builder.append("X_MAKE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getxModel())) {
            builder.append("X_MODEL = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getxMode())) {
            builder.append("X_MODE = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCarrierInitialTransTime())) {
            builder.append("TO_CHAR(CARRIER_INITIAL_TRANS_TIME,'DD-MM-YYYY') = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCarrierEndTransTime())) {
            builder.append("TO_CHAR(CARRIER_END_TRANS_TIME,'DD-MM-YYYY') = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getLoggedDate())) {
            builder.append("LOGGED_DATE between TO_DATE(?, 'DD/MM/yyyy HH24:MI:SS') and TO_DATE(?, 'DD/MM/yyyy HH24:MI:SS')").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getLoggedBy())) {
            builder.append("LOGGED_BY = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getDownloadDate())) {
            builder.append("TO_CHAR(DOWNLOAD_DATE,'DD-MM-YYYY') = ?").append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info("Query to get IG fail logss", searchQuery);
        return searchQuery;
    }

    private void setIgFailLogsQueryParams(PreparedStatement stmt, PreparedStatement stmtCount, TracfoneOneIgFailLogs tracfoneOneIgFailLogs) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getActionItemId())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getActionItemId() + "%");
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getActionItemId() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCarrierId())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getCarrierId());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getCarrierId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getOrderType())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getOrderType());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getOrderType());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getMin())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getMin());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getMin());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getEsn())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getEsn());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getEsn());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getEsnHex())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getEsnHex());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getEsnHex());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getOldEsn())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getOldEsn());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getOldEsn());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getOldEsnHex())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getOldEsnHex());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getOldEsnHex());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getPin())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getPin());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getPin());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getPhoneManf())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getPhoneManf());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getPhoneManf());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getEndUser())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getEndUser());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getEndUser());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getAccountNum())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getAccountNum());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getAccountNum());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getMarketCode())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getMarketCode());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getMarketCode());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getRatePlan())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getRatePlan());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getRatePlan());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getLdProvider())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getLdProvider());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getLdProvider());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getSequenceNum())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getSequenceNum());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getSequenceNum());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getDealerCode())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getDealerCode());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getDealerCode());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getTransmissionMethod())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getTransmissionMethod());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getTransmissionMethod());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getFaxNum())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getFaxNum());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getFaxNum());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getOnlineNum())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getOnlineNum());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getOnlineNum());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getEmail())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getEmail());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getEmail());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getNetworkLogin())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getNetworkLogin());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getNetworkLogin());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getNetworkPassword())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getNetworkPassword());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getNetworkPassword());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getSystemLogin())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getSystemLogin());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getSystemLogin());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getSystemPassword())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getSystemPassword());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getSystemPassword());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getTemplate())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getTemplate());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getTemplate());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getComPort())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getComPort());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getComPort());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getStatus())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getStatus());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getStatus());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getStatusMessage())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getStatusMessage() + "%");
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getStatusMessage() + "%");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getTransProfKey())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getTransProfKey());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getTransProfKey());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getqTransaction())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getqTransaction());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getqTransaction());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getFaxNum2())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getFaxNum2());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getFaxNum2());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCreationDate())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getCreationDate());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getCreationDate());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getToCreationDate())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getToCreationDate());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getToCreationDate());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getUpdateDate())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getUpdateDate());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getUpdateDate());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getBlackoutWait())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getBlackoutWait());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getBlackoutWait());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getTransactionId())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getTransactionId());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getTransactionId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getTechnologyFlag())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getTechnologyFlag());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getTechnologyFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getVoiceMail())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getVoiceMail());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getVoiceMail());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getVoiceMailPackage())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getVoiceMailPackage());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getVoiceMailPackage());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCallerId())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getCallerId());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getCallerId());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCallerIdPackage())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getCallerIdPackage());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getCallerIdPackage());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCallWaiting())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getCallWaiting());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getCallWaiting());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCallWaitingPackage())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getCallWaitingPackage());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getCallWaitingPackage());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getDigitalFeatureCode())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getDigitalFeatureCode());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getDigitalFeatureCode());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getStateField())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getStateField());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getStateField());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getZipCode())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getZipCode());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getZipCode());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getMsid())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getMsid());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getMsid());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getNewMsidFlag())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getNewMsidFlag());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getNewMsidFlag());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getSms())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getSms());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getSms());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getSmsPackage())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getSmsPackage());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getSmsPackage());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getIccid())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getIccid());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getIccid());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getOldMin())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getOldMin());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getOldMin());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getDigitalFeature())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getDigitalFeature());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getDigitalFeature());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getOtaType())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getOtaType());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getOtaType());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getRateCenterNo())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getRateCenterNo());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getRateCenterNo());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getApplicationSystem())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getApplicationSystem());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getApplicationSystem());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getSubscriberUpdate())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getSubscriberUpdate());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getSubscriberUpdate());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getPrlNumber())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getPrlNumber());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getPrlNumber());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getAmount())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getAmount());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getAmount());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getBalance())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getBalance());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getBalance());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getLanguage())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getLanguage());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getLanguage());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getExpDate())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getExpDate());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getExpDate());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getxMpn())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getxMpn());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getxMpn());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getxMpnCode())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getxMpnCode());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getxMpnCode());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getxPoolName())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getxPoolName());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getxPoolName());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getxMake())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getxMake());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getxMake());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getxModel())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getxMode());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getxMode());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getxMode())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getxMode());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getxMode());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCarrierInitialTransTime())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getCarrierInitialTransTime());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getCarrierInitialTransTime());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getCarrierEndTransTime())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getCarrierEndTransTime());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getCarrierEndTransTime());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getLoggedDate())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getLoggedDate());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getLoggedDate());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getToLoggedDate())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getToLoggedDate());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getToLoggedDate());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getLoggedBy())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getLoggedBy());
            stmtCount.setString(index++, tracfoneOneIgFailLogs.getLoggedBy());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneIgFailLogs.getDownloadDate())) {
            stmt.setString(index, tracfoneOneIgFailLogs.getDownloadDate());
            stmtCount.setString(index, tracfoneOneIgFailLogs.getDownloadDate());
        }

    }

    private TFOneIGFailLogs setIgFailLogs(ResultSet resultSet) throws SQLException {
        TFOneIGFailLogs tfOneIGFailLogs = new TFOneIGFailLogs();

        tfOneIGFailLogs.setActionItemId(resultSet.getString("ACTION_ITEM_ID"));
        tfOneIGFailLogs.setCarrierId(resultSet.getString("CARRIER_ID"));
        tfOneIGFailLogs.setOrderType(resultSet.getString("ORDER_TYPE"));
        tfOneIGFailLogs.setMin(resultSet.getString("MIN"));
        tfOneIGFailLogs.setEsn(resultSet.getString("ESN"));

        tfOneIGFailLogs.setEsnHex(resultSet.getString("ESN_HEX"));
        tfOneIGFailLogs.setOldEsn(resultSet.getString("OLD_ESN"));
        tfOneIGFailLogs.setOldEsnHex(resultSet.getString("OLD_ESN_HEX"));
        tfOneIGFailLogs.setPin(resultSet.getString("PIN"));
        tfOneIGFailLogs.setPhoneManf(resultSet.getString("PHONE_MANF"));

        tfOneIGFailLogs.setEndUser(resultSet.getString("END_USER"));
        tfOneIGFailLogs.setAccountNum(resultSet.getString("ACCOUNT_NUM"));
        tfOneIGFailLogs.setMarketCode(resultSet.getString("MARKET_CODE"));
        tfOneIGFailLogs.setRatePlan(resultSet.getString("RATE_PLAN"));
        tfOneIGFailLogs.setLdProvider(resultSet.getString("LD_PROVIDER"));

        tfOneIGFailLogs.setSequenceNum(resultSet.getString("SEQUENCE_NUM"));
        tfOneIGFailLogs.setDealerCode(resultSet.getString("DEALER_CODE"));
        tfOneIGFailLogs.setTransmissionMethod(resultSet.getString("TRANSMISSION_METHOD"));
        tfOneIGFailLogs.setFaxNum(resultSet.getString("FAX_NUM"));
        tfOneIGFailLogs.setOnlineNum(resultSet.getString("ONLINE_NUM"));

        tfOneIGFailLogs.setEmail(resultSet.getString("EMAIL"));
        tfOneIGFailLogs.setNetworkLogin(resultSet.getString("NETWORK_LOGIN"));
        tfOneIGFailLogs.setNetworkPassword(resultSet.getString("NETWORK_PASSWORD"));
        tfOneIGFailLogs.setSystemLogin(resultSet.getString("SYSTEM_LOGIN"));
        tfOneIGFailLogs.setSystemPassword(resultSet.getString("SYSTEM_PASSWORD"));

        tfOneIGFailLogs.setTemplate(resultSet.getString("TEMPLATE"));
        tfOneIGFailLogs.setComPort(resultSet.getString("COM_PORT"));
        tfOneIGFailLogs.setStatus(resultSet.getString("STATUS"));
        tfOneIGFailLogs.setStatusMessage(resultSet.getString("STATUS_MESSAGE"));
        tfOneIGFailLogs.setTransProfKey(resultSet.getString("TRANS_PROF_KEY"));

        tfOneIGFailLogs.setqTransaction(resultSet.getString("Q_TRANSACTION"));
        tfOneIGFailLogs.setFaxNum2(resultSet.getString("FAX_NUM2"));
        tfOneIGFailLogs.setCreationDate(resultSet.getString("CREATION_DATE"));
        tfOneIGFailLogs.setUpdateDate(resultSet.getString("UPDATE_DATE"));
        tfOneIGFailLogs.setBlackoutWait(resultSet.getString("BLACKOUT_WAIT"));

        tfOneIGFailLogs.setTransactionId(resultSet.getString("TRANSACTION_ID"));
        tfOneIGFailLogs.setTechnologyFlag(resultSet.getString("TECHNOLOGY_FLAG"));
        tfOneIGFailLogs.setVoiceMail(resultSet.getString("VOICE_MAIL"));
        tfOneIGFailLogs.setVoiceMailPackage(resultSet.getString("VOICE_MAIL_PACKAGE"));
        tfOneIGFailLogs.setCallerId(resultSet.getString("CALLER_ID"));

        tfOneIGFailLogs.setCallerIdPackage(resultSet.getString("CALLER_ID_PACKAGE"));
        tfOneIGFailLogs.setCallWaiting(resultSet.getString("CALL_WAITING"));
        tfOneIGFailLogs.setCallWaitingPackage(resultSet.getString("CALL_WAITING_PACKAGE"));
        tfOneIGFailLogs.setDigitalFeatureCode(resultSet.getString("DIGITAL_FEATURE_CODE"));
        tfOneIGFailLogs.setStateField(resultSet.getString("STATE_FIELD"));

        tfOneIGFailLogs.setZipCode(resultSet.getString("ZIP_CODE"));
        tfOneIGFailLogs.setMsid(resultSet.getString("MSID"));
        tfOneIGFailLogs.setNewMsidFlag(resultSet.getString("NEW_MSID_FLAG"));
        tfOneIGFailLogs.setSms(resultSet.getString("SMS"));
        tfOneIGFailLogs.setSmsPackage(resultSet.getString("SMS_PACKAGE"));

        tfOneIGFailLogs.setIccid(resultSet.getString("ICCID"));
        tfOneIGFailLogs.setOldMin(resultSet.getString("OLD_MIN"));
        tfOneIGFailLogs.setDigitalFeature(resultSet.getString("DIGITAL_FEATURE"));
        tfOneIGFailLogs.setOtaType(resultSet.getString("OTA_TYPE"));
        tfOneIGFailLogs.setRateCenterNo(resultSet.getString("RATE_CENTER_NO"));

        tfOneIGFailLogs.setApplicationSystem(resultSet.getString("APPLICATION_SYSTEM"));
        tfOneIGFailLogs.setSubscriberUpdate(resultSet.getString("SUBSCRIBER_UPDATE"));
        tfOneIGFailLogs.setPrlNumber(resultSet.getString("PRL_NUMBER"));
        tfOneIGFailLogs.setAmount(resultSet.getString("AMOUNT"));
        tfOneIGFailLogs.setBalance(resultSet.getString("BALANCE"));

        tfOneIGFailLogs.setLanguage(resultSet.getString("LANGUAGE"));
        tfOneIGFailLogs.setExpDate(resultSet.getString("EXP_DATE"));
        tfOneIGFailLogs.setxMpn(resultSet.getString("X_MPN"));
        tfOneIGFailLogs.setxMpnCode(resultSet.getString("X_MPN_CODE"));
        tfOneIGFailLogs.setxPoolName(resultSet.getString("X_POOL_NAME"));

        tfOneIGFailLogs.setxMake(resultSet.getString("X_MAKE"));
        tfOneIGFailLogs.setxModel(resultSet.getString("X_MODEL"));
        tfOneIGFailLogs.setxMode(resultSet.getString("X_MODE"));
        tfOneIGFailLogs.setCarrierInitialTransTime(resultSet.getString("CARRIER_INITIAL_TRANS_TIME"));
        tfOneIGFailLogs.setCarrierEndTransTime(resultSet.getString("CARRIER_END_TRANS_TIME"));

        tfOneIGFailLogs.setLoggedDate(resultSet.getString("LOGGED_DATE"));
        tfOneIGFailLogs.setLoggedBy(resultSet.getString("LOGGED_BY"));
        tfOneIGFailLogs.setDownloadDate(resultSet.getString("DOWNLOAD_DATE"));

        return tfOneIGFailLogs;
    }

    private String getIgFailLogsStatement(String query, TracfoneOneIgFailLogs tracfoneOneIgFailLogs) {
        boolean pagination = false;
        int startIndex = 0;
        int endIndex = 0;
        if (tracfoneOneIgFailLogs.getPaginationSearch() != null) {
            startIndex = tracfoneOneIgFailLogs.getPaginationSearch().getStartIndex();
            endIndex = tracfoneOneIgFailLogs.getPaginationSearch().getEndIndex();
            pagination = (endIndex - startIndex) <= TracfoneOneConstant.FETCH_SIZE;
        }
        StringBuilder sBuilder = new StringBuilder(getIgFailLogsQueryParams(query + TRACFONE_GET_ALL_IG_FAIL_LOGS, tracfoneOneIgFailLogs));
        // Pagination check for large result queries.
        if (pagination) {
            // Adding 1 to each of these since a ROWNUM of 0 never exists and it is being sent this way from the UI
            startIndex++;
            endIndex++;
            sBuilder.append(") a "
                    + "where ROWNUM < "
                    + endIndex + ") "
                    + "where rnum  >= " + startIndex);
        } else {
            TracfoneonePaginationSearch defaultPagination = new TracfoneonePaginationSearch();
            defaultPagination.setStartIndex(1);
            defaultPagination.setEndIndex(1000);
            tracfoneOneIgFailLogs.setPaginationSearch(defaultPagination);
            sBuilder.append(") a "
                    + " where ROWNUM < "
                    + "1000 ) "
                    + "where rnum  >= 0");
        }
        LOGGER.info("The search query is " + sBuilder.toString());

        return sBuilder.toString();
    }

}
