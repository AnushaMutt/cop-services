package com.tracfone.service.model.response;

/**
 * @author Thejaswini
 */
public class TFOneGeoCoder {
    private  String token;
    private  String expires;
    private  String ssl;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getExpires() {
        return expires;
    }

    public void setExpires(String expires) {
        this.expires = expires;
    }

    public String getSsl() {
        return ssl;
    }

    public void setSsl(String ssl) {
        this.ssl = ssl;
    }

    @Override
    public String toString() {
        return "TFOneGeoCoder{" +
                "token='" + token + '\'' +
                ", expires='" + expires + '\'' +
                ", ssl='" + ssl + '\'' +
                '}';
    }
}
