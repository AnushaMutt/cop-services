/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfig;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfigDetails;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneIGCarrierConfig;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Gaurav.Sharma
 */
@Local
public interface TracfoneOneIGCarrierConfigActionLocal {

    public List<String> getCarriers(String dbEnv) throws TracfoneOneException;

    public List<TFOneIGCarrierConfig> getCarrierConfig(TracfoneOneIGCarrierConfig carrierConfig) throws TracfoneOneException;

    public TFOneGeneralResponse updateCarrierConfigDetails(TracfoneOneIGCarrierConfig carrierDetails, int userId) throws TracfoneOneException;

    public TFOneGeneralResponse deleteCarrierConfigDetails(TracfoneOneIGCarrierConfigDetails carrierDetails, int userId) throws TracfoneOneException;

    public TFOneGeneralResponse insertCarrierConfigDetails(TracfoneOneIGCarrierConfig carrierDetails, int userId) throws TracfoneOneException;

    public boolean validateDuplicateCarrierConfigDetails(TracfoneOneIGCarrierConfigDetails carrierDetails) throws TracfoneOneException;

    public TFOneGeneralResponse insertCarrierConfig(TracfoneOneIGCarrierConfig carrierConfig, int userId) throws TracfoneOneException;

    public List<TFOneIGCarrierConfig> checkDuplicateCarrierConfig(TracfoneOneIGCarrierConfig carrierConfig) throws TracfoneOneException;

    public List<String> getPropNameForRef(TracfoneOneIGCarrierConfig carrierConfig) throws TracfoneOneException;

    public List<String> getPropNameForRefList(TracfoneOneIGCarrierConfig carrierConfig) throws TracfoneOneException;

}
