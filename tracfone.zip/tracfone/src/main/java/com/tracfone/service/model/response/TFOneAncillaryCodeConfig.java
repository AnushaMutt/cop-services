package com.tracfone.service.model.response;

public class TFOneAncillaryCodeConfig {
    private String extensionObjId;
    private String profileId;
    private String featureName;
    private String featureValue;
    private String featureRequirement;
    private String toggleFlag;
    private String notes;
    private String restrictSUIFlag;
    private String displaySUIFlag;

    public String getExtensionObjId() {
        return extensionObjId;
    }

    public void setExtensionObjId(String extensionObjId) {
        this.extensionObjId = extensionObjId;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public String getFeatureValue() {
        return featureValue;
    }

    public void setFeatureValue(String featureValue) {
        this.featureValue = featureValue;
    }

    public String getFeatureRequirement() {
        return featureRequirement;
    }

    public void setFeatureRequirement(String featureRequirement) {
        this.featureRequirement = featureRequirement;
    }

    public String getToggleFlag() {
        return toggleFlag;
    }

    public void setToggleFlag(String toggleFlag) {
        this.toggleFlag = toggleFlag;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getRestrictSUIFlag() {
        return restrictSUIFlag;
    }

    public void setRestrictSUIFlag(String restrictSUIFlag) {
        this.restrictSUIFlag = restrictSUIFlag;
    }

    public String getDisplaySUIFlag() {
        return displaySUIFlag;
    }

    public void setDisplaySUIFlag(String displaySUIFlag) {
        this.displaySUIFlag = displaySUIFlag;
    }

    @Override
    public String toString() {
        return "TFOneAncillaryCodeConfig{" +
                "extensionObjId='" + extensionObjId + '\'' +
                ", profileId='" + profileId + '\'' +
                ", featureName='" + featureName + '\'' +
                ", featureValue='" + featureValue + '\'' +
                ", featureRequirement='" + featureRequirement + '\'' +
                ", toggleFlag='" + toggleFlag + '\'' +
                ", notes='" + notes + '\'' +
                ", restrictSUIFlag='" + restrictSUIFlag + '\'' +
                ", displaySUIFlag='" + displaySUIFlag + '\'' +
                '}';
    }
}
