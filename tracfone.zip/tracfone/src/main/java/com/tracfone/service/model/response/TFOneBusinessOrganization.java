/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.response;

/**
 *
 * @author Shireen Fathima
 */
public class TFOneBusinessOrganization {
    
    private String objId;
    private String orgId;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @Override
    public String toString() {
        return "TFOneBusinessOrganization{" + "objId=" + objId + ", orgId=" + orgId + '}';
    }
    
}
