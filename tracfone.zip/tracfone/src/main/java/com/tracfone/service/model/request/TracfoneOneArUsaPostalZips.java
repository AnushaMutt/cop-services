package com.tracfone.service.model.request;

import javax.validation.constraints.Size;

public class TracfoneOneArUsaPostalZips {
    @Size(min = 1, message = "POSTAL_CODE Codes cannot be null")
    @Size( max = 5,message = "POSTAL_CODE cannot have more than 5 digits")
    private String postalCode;
    @Size(min = 1, message = "KEY_CODE Codes cannot be null")
    @Size(max = 15, message = "KEY_CODE cannot have more than 15 digits")
    private String keyCode;
    @Size(min = 1, message = "STATE Codes cannot be null")
    @Size(max = 50, message = "STATE cannot have more than 50 characters")
    private String state;
    @Size(min = 1, message = "CITY Codes cannot be null")
    @Size(max = 50, message = "CITY cannot have more than 50 characters")
    private String city;
    private String dbEnv;
    private boolean checkDuplicate;
    @Size(min = 1, message = "POSTAL_CODE Codes cannot be null")
    @Size(max = 5, message = "POSTAL_CODE cannot have more than 5 digits")
    private String oldPostalCode;


    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getKeyCode() {
        return keyCode;
    }

    public void setKeyCode(String keyCode) {
        this.keyCode = keyCode;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public boolean isCheckDuplicate() {
        return checkDuplicate;
    }

    public void setCheckDuplicate(boolean checkDuplicate) {
        this.checkDuplicate = checkDuplicate;
    }

    public String getOldPostalCode() {
        return oldPostalCode;
    }

    public void setOldPostalCode(String oldPostalCode) {
        this.oldPostalCode = oldPostalCode;
    }

    @Override
    public String toString() {
        return "TracfoneOneArUsaPostalZips{" +
                "postalCode='" + postalCode + '\'' +
                ", keyCode='" + keyCode + '\'' +
                ", state='" + state + '\'' +
                ", city='" + city + '\'' +
                ", dbEnv='" + dbEnv + '\'' +
                ", checkDuplicate=" + checkDuplicate +
                ", oldPostalCode='" + oldPostalCode + '\'' +
                '}';
    }
}
