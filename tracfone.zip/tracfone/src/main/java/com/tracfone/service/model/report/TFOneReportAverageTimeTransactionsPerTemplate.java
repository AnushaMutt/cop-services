package com.tracfone.service.model.report;

/**
 *
 * @author druiz
 */
public class TFOneReportAverageTimeTransactionsPerTemplate {

    private String carrier;
    private String orderType;
    private String timeSegment;
    private String avgTimeCarrier;
    private String avgTimeDb;
    private String totalTransactions;

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getTimeSegment() {
        return timeSegment;
    }

    public void setTimeSegment(String timeSegment) {
        this.timeSegment = timeSegment;
    }

    public String getAvgTimeCarrier() {
        return avgTimeCarrier;
    }

    public void setAvgTimeCarrier(String avgTimeCarrier) {
        this.avgTimeCarrier = avgTimeCarrier;
    }

    public String getAvgTimeDB() {
        return avgTimeDb;
    }

    public void setAvgTimeDB(String avgTimeDB) {
        this.avgTimeDb = avgTimeDB;
    }

    public String getTotalTransactions() {
        return totalTransactions;
    }

    public void setTotalTransactions(String totalTransactions) {
        this.totalTransactions = totalTransactions;
    }
    
    
    
}
