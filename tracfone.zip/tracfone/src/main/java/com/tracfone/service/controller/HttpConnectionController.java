package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.util.TracfoneOneConstantGeocode;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContexts;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Stateless;
import javax.net.ssl.SSLContext;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

/**
 *
 * @author Thejaswini
 */
public class HttpConnectionController implements TracfoneOneConstantGeocode {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneGeoCoderController.class);

    static PoolingHttpClientConnectionManager poolingConnManager = null;

    static {
        try {
            SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, TrustAllStrategy.INSTANCE).build();
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

            Registry<ConnectionSocketFactory> socketFactoryRegistry =
                    RegistryBuilder.<ConnectionSocketFactory>create()
                            .register("https", sslsf)
                            .register("http", new PlainConnectionSocketFactory())
                            .build();

            poolingConnManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
            poolingConnManager.setMaxTotal(5);
            poolingConnManager.setDefaultMaxPerRoute(4);
        } catch (KeyStoreException | NoSuchAlgorithmException | KeyManagementException e) {
            LOGGER.info(TRCFONE_POOLING_HTTP_CLIENT_CONNECTION_MANAGER_ERROR_MESSAGE , e);
            try {
                throw new TracfoneOneException(TRCFONE_POOLING_HTTP_CLIENT_CONNECTION_MANAGER_ERROR, TRCFONE_POOLING_HTTP_CLIENT_CONNECTION_MANAGER_ERROR_MESSAGE, e);
            } catch (TracfoneOneException ex) {
                LOGGER.info(TRCFONE_POOLING_HTTP_CLIENT_CONNECTION_MANAGER_ERROR_MESSAGE , e);
            }
        }
    }

    public static PoolingHttpClientConnectionManager getHttpConnectionPool(){
        return poolingConnManager;
    }

}
