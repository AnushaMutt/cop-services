/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.exception;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.HashMap;
import java.util.Map;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author Shireen Fathima
 */
@Provider
public class TracfoneOneValidationExceptionMapper implements ExceptionMapper<ConstraintViolationException> {
    
    private static final Gson gson = new GsonBuilder().serializeNulls().create();
    
    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneValidationExceptionMapper.class);
    
    private static final String ERR = "ERR";
    
    @Override
    public Response toResponse(ConstraintViolationException e) {
        Map<String, String> errorMap = prepareMessage(e);
        LOGGER.error(errorMap.get(ERR), e);
        return Response.ok(gson.toJson(errorMap), MediaType.APPLICATION_JSON).build();
    }
    
    private Map<String, String> prepareMessage(ConstraintViolationException e) {
        Map<String, String> errorMap = new HashMap<>();
        String msg = "";
        for (ConstraintViolation<?> cv : e.getConstraintViolations()) {
            msg += cv.getMessage() + ",";
        }
        errorMap.put(ERR, msg);
        return errorMap;
    }
    
}
