package com.tracfone.service.model.response;

public class TFOneUserReporting {
    private String status;
    private Long tasks;
    private Long transactions;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getTasks() {
        return tasks;
    }

    public void setTasks(Long tasks) {
        this.tasks = tasks;
    }

    public Long getTransactions() {
        return transactions;
    }

    public void setTransactions(Long transactions) {
        this.transactions = transactions;
    }

    @Override
    public String toString() {
        return "TFOneUserReporting{" +
                "status='" + status + '\'' +
                ", tasks='" + tasks + '\'' +
                ", transactions='" + transactions + '\'' +
                '}';
    }
}
