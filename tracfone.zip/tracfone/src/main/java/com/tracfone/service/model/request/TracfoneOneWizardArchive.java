
package com.tracfone.service.model.request;

/**
 *
 * @author druiz
 */
public class TracfoneOneWizardArchive {
    private String actionItemId;
    private String deactivationDate;
    private int daysToExtend;

    public String getActionItemId() {
        return actionItemId;
    }

    public void setActionItemId(String actionItemId) {
        this.actionItemId = actionItemId;
    }

    public String getDeactivationDate() {
        return deactivationDate;
    }

    public void setDeactivationDate(String deactivationDate) {
        this.deactivationDate = deactivationDate;
    }

    public int getDaysToExtend() {
        return daysToExtend;
    }

    public void setDaysToExtend(int daysToExtend) {
        this.daysToExtend = daysToExtend;
    }
    
}
