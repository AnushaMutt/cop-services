package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import com.tracfone.service.model.request.TracfoneOneCarrierZonesDeployment;
import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfig;
import com.tracfone.service.model.request.TracfoneOneNpaNxx2Carrier;
import com.tracfone.service.model.response.TFOneCPrefResponse;
import com.tracfone.service.model.response.TFOneCarrierZonesDeployment;
import com.tracfone.service.model.response.TFOneCingularMrktInfo;
import com.tracfone.service.model.response.TFOneMissingCarrierZones;
import com.tracfone.service.model.response.TFOneMissingCingularMktInfo;
import com.tracfone.service.model.response.TFOneNpaNxx2Carrier;
import com.tracfone.service.util.TracfoneOneConstantCarrierZonesDeployment;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Gaurav.Sharma
 */
@Stateless
public class TracfoneCarrierZonesDeploymentController implements TracfoneCarrierZonesDeploymentControllerLocal, TracfoneOneConstantCarrierZonesDeployment {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneCarrierZonesDeploymentController.class);

    @EJB
    private TracfoneCarrierZonesDeploymentActionLocal actionLocal;

    @Override
    public TFOneCarrierZonesDeployment validateCarrierZones(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException {
        TFOneCarrierZonesDeployment zonesDeployment = null;
        try {
            zonesDeployment = actionLocal.validateCarrierZones(carrierZonesDeployment);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_VALIDATE_CARRIER_ZONES_ERROR, TRACFONE_VALIDATE_CARRIER_ZONES_ERROR_MESSAGE, ex);
        }
        return zonesDeployment;
    }

    @Override
    public TFOneCarrierZonesDeployment validateNpaNxx(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException {
        TFOneCarrierZonesDeployment zonesDeployment = null;
        try {
            zonesDeployment = actionLocal.validateNpaNxx(carrierZonesDeployment);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_VALIDATE_NPANAXX_ERROR, TRACFONE_VALIDATE_NPANAXX_ERROR_MESSAGE, ex);
        }
        return zonesDeployment;
    }

    @Override
    public TFOneMissingCarrierZones insertMissingCarrierZones(List<TracfoneOneCarrierZones> carrierZones, int userId, String carrierName) throws TracfoneOneException {
        TFOneMissingCarrierZones response = null;
        try {
            response = actionLocal.insertMissingCarrierZones(carrierZones, userId, carrierName);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_INSERT_MISSING_CZ_ERROR, TRACFONE_INSERT_MISSING_CZ_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneCPrefResponse insertCPref(List<TracfoneOneCarrierZones> carrierZones, int userId) throws TracfoneOneException {
        TFOneCPrefResponse response = null;
        try {
            response = actionLocal.insertCPref(carrierZones, userId);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_CARRIER_ID_ERROR, TRACFONE_UPDATE_CARRIER_ID_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneNpaNxx2Carrier insertNpaNxx(List<TracfoneOneNpaNxx2Carrier> nxx2Carrier, int userId) throws TracfoneOneException {
        TFOneNpaNxx2Carrier response = null;
        try {
            response = actionLocal.insertNpaNxx(nxx2Carrier, userId);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_CARRIER_ID_ERROR, TRACFONE_UPDATE_CARRIER_ID_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneCarrierZonesDeployment validateARUSA(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException {
        TFOneCarrierZonesDeployment zonesDeployment = null;
        try {
            zonesDeployment = actionLocal.validateARUSA(carrierZonesDeployment);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_VALIDATE_AR_USA_ERROR, TRACFONE_VALIDATE_AR_USA_ERROR_MESSAGE, ex);
        }
        return zonesDeployment;
    }

    @Override
    public TFOneCarrierZonesDeployment validateCingularMrktInfo(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException {
        TFOneCarrierZonesDeployment zonesDeployment = null;
        try {
            zonesDeployment = actionLocal.validateCingularMrktInfo(carrierZonesDeployment);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_VALIDATE_CINGULAR_MRKT_ERROR, TRACFONE_VALIDATE_CINGULAR_MRKT_ERROR_MESSAGE, ex);
        }
        return zonesDeployment;
    }

    @Override
    public TFOneCarrierZonesDeployment validateZipMktSubMkt(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException {
        TFOneCarrierZonesDeployment zonesDeployment = null;
        try {
            zonesDeployment = actionLocal.validateZipMktSubMkt(carrierZonesDeployment);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_VALIDATE_ZIP_MKT_SUB_MKT_ERROR, TRACFONE_VALIDATE_ZIP_MKT_SUB_MKT_ERROR_MESSAGE, ex);
        }
        return zonesDeployment;
    }

    @Override
    public List<TFOneCingularMrktInfo> updateDealerNan(List<TracfoneOneCingularMrktInfo> cingularMrktInfos) throws TracfoneOneException {
        List<TFOneCingularMrktInfo> cingularMrktInfoList = null;
        try {
            cingularMrktInfoList = actionLocal.updateDealerNan(cingularMrktInfos);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_UPDATE_DEALER_NAN_ERROR, TRACFONE_UPDATE_DEALER_NAN_ERROR_MESSAGE, ex);
        }
        return cingularMrktInfoList;
    }

    @Override
    public TFOneMissingCingularMktInfo insertCingularMktInfo(List<TracfoneOneCingularMrktInfo> mrktInfos, int userId) throws TracfoneOneException {
        TFOneMissingCingularMktInfo response = null;
        try {
            response = actionLocal.insertCingularMktInfo(mrktInfos, userId);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_INSERT_MISSING_CINGULAR_MKT_INFO_ERROR, TRACFONE_INSERT_MISSING_CINGULAR_MKT_INFO_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneCarrierZonesDeployment validateNextAvailable(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException {
        TFOneCarrierZonesDeployment zonesDeployment = null;
        try {
            zonesDeployment = actionLocal.validateNextAvailable(carrierZonesDeployment);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_VALIDATE_TMO_NEXT_AVAILABLE_ERROR, TRACFONE_VALIDATE_TMO_NEXT_AVAILABLE_ERROR_MESSAGE, ex);
        }
        return zonesDeployment;
    }

    @Override
    public TFOneNpaNxx2Carrier insertTmoNpaNxx(List<TracfoneOneNpaNxx2Carrier> nxx2Carrier, int userId) throws TracfoneOneException {
        TFOneNpaNxx2Carrier response = null;
        try {
            response = actionLocal.insertTmoNpaNxx(nxx2Carrier, userId);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_INSERT_TMO_NPANXX_ERROR, TRACFONE_INSERT_TMO_NPANXX_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneNpaNxx2Carrier insertNpaNxxAtt(List<TracfoneOneNpaNxx2Carrier> nxx2Carriers, int userId) throws TracfoneOneException {
        TFOneNpaNxx2Carrier response = null;
        try {
            response = actionLocal.insertNpaNxxAtt(nxx2Carriers, userId);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_INSERT_NPAXX_ERROR, TRACFONE_INSERT_NPAXX_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<String> getCarriers(TracfoneOneIGCarrierConfig carrierConfig) throws TracfoneOneException {
        List<String> carrierData = new ArrayList<>();
        try {
            carrierData = actionLocal.getCarriers(carrierConfig);
        } catch (TracfoneOneException ex) {
            LOGGER.error(ex);
            throw new TracfoneOneException(TRACFONE_GET_CARRIERS_ERROR, TRACFONE_GET_CARRIERS_ERROR_MESSAGE, ex);
        }
        return carrierData;
    }
}
