package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.ejb.entity.retail.session.CRtlCarrierPrefFacadeLocal;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneCarrierGroup;
import com.tracfone.service.model.request.TracfoneOneCarrierZones;
import com.tracfone.service.model.request.TracfoneOneCarrierZonesDeployment;
import com.tracfone.service.model.request.TracfoneOneCingularMrktInfo;
import com.tracfone.service.model.request.TracfoneOneIGCarrierConfig;
import com.tracfone.service.model.request.TracfoneOneNpaNxx2Carrier;
import com.tracfone.service.model.response.TFOneCPrefResponse;
import com.tracfone.service.model.response.TFOneCarrierZones;
import com.tracfone.service.model.response.TFOneCarrierZonesDeployment;
import com.tracfone.service.model.response.TFOneCingularMrktInfo;
import com.tracfone.service.model.response.TFOneMissingCarrierZones;
import com.tracfone.service.model.response.TFOneMissingCingularMktInfo;
import com.tracfone.service.model.response.TFOneNextAvailable;
import com.tracfone.service.model.response.TFOneNpaNxx2Carrier;
import com.tracfone.service.model.response.TFOneVerizonZipNPANXX;
import com.tracfone.service.model.response.TFOneZipMktSubMkt;
import com.tracfone.service.util.CarrierZonesControllerUtil;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantCarrierZonesDeployment;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import javax.persistence.Query;

/**
 * @author Gaurav.Sharma
 */
@Stateless
public class TracfoneCarrierZonesDeploymentAction implements TracfoneCarrierZonesDeploymentActionLocal, TracfoneOneConstant, TracfoneOneConstantCarrierZonesDeployment {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneCarrierZonesDeploymentAction.class);

    @EJB
    private DataBaseController dbControllerEJB;
    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @EJB
    private CRtlCarrierPrefFacadeLocal cRtlCarrierPrefFacadeLocal;

    private String CARRIER_NAME = "CARRIER_NAME";

    @Override
    public TFOneCarrierZonesDeployment validateCarrierZones(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException {
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        List<TFOneCarrierZones> carrierZones = new ArrayList<>(1);
        List<String> newZipCodes = new ArrayList<>();
        List<String> carrierNames = CarrierZonesControllerUtil.getCarrierName(carrierZonesDeployment.getCarrierName());
        try (Connection con = dbControllerEJB.getDataSource(carrierZonesDeployment.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(buildValidateCarrierZonesQuery(TRACFONE_SEARCH_CARRIER_ZONES, carrierZonesDeployment.getCarrierName()));) {
            for (int i = 0; i < carrierZonesDeployment.getZipcodes().size(); i++) {
                stmt.setString(1, carrierZonesDeployment.getZipcodes().get(i));
                setValidateCarrierZonesStatement(stmt, carrierZonesDeployment.getCarrierName(), 2, carrierZonesDeployment.getZipcodes().get(i));
                
                int count = 0;
                try (ResultSet resultSet = stmt.executeQuery()) {
                    if(!resultSet.isBeforeFirst()){
                        newZipCodes.add(carrierZonesDeployment.getZipcodes().get(i));
                    }else {
                        while (resultSet.next()) {
                            count = resultSet.getInt(1);
                            LOGGER.info("COUNT for " + carrierZonesDeployment.getZipcodes().get(i) + " is " + count);
                            if(count == 0 || count < carrierNames.size()){
                                newZipCodes.add(carrierZonesDeployment.getZipcodes().get(i));
                            } else {
                                carrierZones.add(setCarrierZones(resultSet));
                            }
                        }
                    }
                }
            }
            zonesDeployment.setCarrierZones(carrierZones);
            zonesDeployment.setNewZipCodes(newZipCodes.stream().distinct().collect(Collectors.toList()));
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return zonesDeployment;
    }

    private String buildInClause(String query, TracfoneOneCarrierZonesDeployment carrierZonesDeployment) {
        StringBuilder builder = new StringBuilder(query);
        for (int i = 0; i < carrierZonesDeployment.getZipcodes().size(); i++) {
            builder.append("?,");
        }
        builder = new StringBuilder(builder.substring(0, builder.lastIndexOf(","))).append(")");
        LOGGER.info("Validation QUERY : " + builder);
        return builder.toString();
    }
	private String buildValidateCarrierZonesQuery(String query, String carrierName) {
        StringBuilder builder = new StringBuilder(query);
        List<String> carrierNames = CarrierZonesControllerUtil.getCarrierName(carrierName);
        for (int i = 0; i < carrierNames.size(); i++) {
            builder.append("?,");
        }
        builder = new StringBuilder(builder.substring(0, builder.lastIndexOf(","))).append(")) a,");
        builder.append("(select COUNT(1) as TOTAL_RECORDS "
                + "from CARRIERZONES where ZIP = ? AND CARRIER_NAME in (");
        for (int i = 0; i < carrierNames.size(); i++) {
            builder.append("?,");
        }
        builder = new StringBuilder(builder.substring(0, builder.lastIndexOf(","))).append(")) b");
        LOGGER.info("Search CarrierZones QUERY : " + builder);
        return builder.toString();
    }
    
    private void setValidateCarrierZonesStatement(PreparedStatement stmt, String carrierName, int index, String zipCode) throws SQLException {
        List<String> carrierNames = CarrierZonesControllerUtil.getCarrierName(carrierName);
        for (int i = 0; i < carrierNames.size(); i++) {
            stmt.setString(index++, carrierNames.get(i));
        }
        stmt.setString(index++, zipCode);
        for (int i = 0; i < carrierNames.size(); i++) {
            stmt.setString(index++, carrierNames.get(i));
        }
    }

    private TFOneCarrierZones setCarrierZones(ResultSet resultSet) throws SQLException {
        TFOneCarrierZones tfOneCarrierZones = new TFOneCarrierZones();
        tfOneCarrierZones.setZipCode(resultSet.getString("ZIP"));
        tfOneCarrierZones.setState(resultSet.getString("ST"));
        tfOneCarrierZones.setCounty(resultSet.getString("COUNTY"));
        tfOneCarrierZones.setCity(resultSet.getString("CITY"));
        tfOneCarrierZones.setCarrierId(resultSet.getString("CARRIER_ID"));
        tfOneCarrierZones.setCarrierName(resultSet.getString(CARRIER_NAME));
        tfOneCarrierZones.setBtaMarketName(resultSet.getString("BTA_MKT_NAME"));
        tfOneCarrierZones.setBtaMarketNumber(resultSet.getString("BTA_MKT_NUMBER"));
        tfOneCarrierZones.setZipStatus(resultSet.getString("ZIP_STATUS"));
        tfOneCarrierZones.setSimProfile(resultSet.getString("SIM_PROFILE"));
        tfOneCarrierZones.setSimProfile2(resultSet.getString("SIM_PROFILE_2"));
        tfOneCarrierZones.setPlanType(resultSet.getString("PLANTYPE"));
        tfOneCarrierZones.setMarketId(resultSet.getString("MARKETID"));
        tfOneCarrierZones.setRateCente(resultSet.getString("RATE_CENTE"));
        tfOneCarrierZones.setMarketArea(resultSet.getString("MRKT_AREA"));
        tfOneCarrierZones.setZone(resultSet.getString("ZONE"));
        return tfOneCarrierZones;
    }

    @Override
    public TFOneCarrierZonesDeployment validateNpaNxx(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException {
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        List<TFOneVerizonZipNPANXX> zipNPANXXs = new ArrayList<>(1);
        int index = 1;
        try (Connection con = dbControllerEJB.getDataSource(carrierZonesDeployment.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(buildInClause(TRACFONE_SEARCH_NPANXX, carrierZonesDeployment))) {
            for (int i = 0; i < carrierZonesDeployment.getZipcodes().size(); i++) {
                stmt.setString(index++, carrierZonesDeployment.getZipcodes().get(i));
            }

            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    zipNPANXXs.add(setNpaNxx(resultSet));
                }
            }
            Set<String> existingZipCodes = new HashSet<>();
            for (int i = 0; i < zipNPANXXs.size(); i++) {
                existingZipCodes.add(zipNPANXXs.get(i).getZip());
            }
            List<String> nonExistingZipCodes = new ArrayList<>(1);
            carrierZonesDeployment.getZipcodes().forEach(zip -> {
                if (!existingZipCodes.contains(zip)) {
                    nonExistingZipCodes.add(zip);
                }
            });
            zonesDeployment.setZipNPANXXs(zipNPANXXs);
            zonesDeployment.setNewZipCodes(nonExistingZipCodes);

        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return zonesDeployment;
    }

    private TFOneVerizonZipNPANXX setNpaNxx(ResultSet resultSet) throws SQLException {
        TFOneVerizonZipNPANXX zipNPANXX = new TFOneVerizonZipNPANXX();
        zipNPANXX.setZip(resultSet.getString("ZIP"));
        zipNPANXX.setnPANXX(resultSet.getString("NPANXX"));
        return zipNPANXX;
    }

    @Override
    public TFOneCarrierZonesDeployment validateARUSA(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException {
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        int index = 1;
        try {
            Query sql = cRtlCarrierPrefFacadeLocal.getEntityManager().createNativeQuery(buildInClause(TRACFONE_SEARCH_AR_USA, carrierZonesDeployment));
            for (int i = 0; i < carrierZonesDeployment.getZipcodes().size(); i++) {
                sql.setParameter(index++, carrierZonesDeployment.getZipcodes().get(i));
            }
            List<Object[]> rows = sql.getResultList();
            List<TFOneCarrierZones> result = new ArrayList<>(rows.size());
            rows.forEach(row ->
                    result.add(new TFOneCarrierZones(
                            (String) row[0], (String) row[1], (String) row[2], (BigDecimal) row[3], (String) row[4], (String) row[5],
                            (BigDecimal) row[6], (String) row[7]
                    ))
            );

            Set<String> existingZipCodes = new HashSet<>();
            for (int i = 0; i < result.size(); i++) {
                existingZipCodes.add(result.get(i).getZipCode());
            }
            List<String> nonExistingZipCodes = new ArrayList<>(1);
            carrierZonesDeployment.getZipcodes().forEach(zip -> {
                if (!existingZipCodes.contains(zip)) {
                    nonExistingZipCodes.add(zip);
                }
            });
            zonesDeployment.setArUsaData(result);
            zonesDeployment.setNewZipCodes(nonExistingZipCodes);

        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return zonesDeployment;
    }

    @Override
    public TFOneMissingCarrierZones insertMissingCarrierZones(List<TracfoneOneCarrierZones> carrierZones, int userId, String carrierName) throws TracfoneOneException {
        List<TracfoneOneCarrierZones> successRecords = new ArrayList<>(1);
        List<TracfoneOneCarrierZones> failedRecords = new ArrayList<>(1);
        TFOneMissingCarrierZones missingCarrierZones = new TFOneMissingCarrierZones();
        List<TracfoneOneCarrierZones> oneCarrierZoneses = validateCarrierZonesForInsert(carrierZones, carrierName);
        try (Connection con = dbControllerEJB.getDataSource(carrierZones.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_MISSING_CARRIERZONES);) {
            LOGGER.info("INSERT MISSING CARRIER ZONES QUERY : {}", TRACFONE_INSERT_MISSING_CARRIERZONES);
            if (oneCarrierZoneses.size() > 0) {
                oneCarrierZoneses.forEach(_e1 -> {
                    try {
                        _e1.setRateCente(_e1.getCity());
                        setMissingCarrierZonesStatement(stmt, _e1);
                        stmt.executeUpdate();
                    } catch (SQLException ex) {
                        LOGGER.info(ex);
                        if (String.valueOf(ex).contains(TABLE_NOT_FOUND_ORACODE)) {
                            _e1.setReasonToFail("carrierzones table was not found.");
                        } else if (String.valueOf(ex).contains(INVALID_TYPE_ORACODE)) {
                            _e1.setReasonToFail(INVALID_DATA_TYPE);
                        } else if (String.valueOf(ex).contains(GRANT_ORACODE)) {
                            _e1.setReasonToFail(TABLE_GRANT);
                        } else {
                            _e1.setReasonToFail(FAILED_CHECK_TECHNICAL_REASON);
                        }
                        _e1.setTechReasonToFail(ex.getMessage());
                        failedRecords.add(_e1);
                        return;
                    }
                    successRecords.add(_e1);
                });
            }
            missingCarrierZones.setFailedRecords(failedRecords);
            missingCarrierZones.setSuccessRecords(successRecords);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Missing Carrier Zones", "Inserted Missing Carrier Zones " + missingCarrierZones, null);
            tracfoneAuditEvent.fire(audit);
        }
        return missingCarrierZones;
    }
	
	private List<TracfoneOneCarrierZones> validateCarrierZonesForInsert(List<TracfoneOneCarrierZones> carrierZones, String carrierName) throws TracfoneOneException{
        List<TracfoneOneCarrierZones> carrierZoneses = new ArrayList<>();
        List<String> returnedCarrierNames = new ArrayList<>();
        List<String> carrierNames = CarrierZonesControllerUtil.getCarrierName(carrierName);
        try (Connection con = dbControllerEJB.getDataSource(carrierZones.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(buildValidateCarrierZonesQuery(TRACFONE_SEARCH_CARRIER_ZONES, carrierName));) {
            for (int i = 0; i < carrierZones.size(); i++) {
                stmt.setString(1, carrierZones.get(i).getZipCode());
                setValidateCarrierZonesStatement(stmt, carrierName, 2, carrierZones.get(i).getZipCode());
                try (ResultSet resultSet = stmt.executeQuery()) {
                    if(!resultSet.isBeforeFirst()){
                      for(String names: carrierNames){
                        carrierZoneses.add(createInsertMissingCarrierZonesRequest(carrierZones.get(i), names));
                      }
                    }else {
                        while(resultSet.next()){
                            returnedCarrierNames.add(resultSet.getString(CARRIER_NAME));
                        }
                        List<String> carrNames = new ArrayList<>(carrierNames);
                        carrNames.removeAll(returnedCarrierNames);
                        for(String names: carrNames){
                            carrierZoneses.add(createInsertMissingCarrierZonesRequest(carrierZones.get(i), names));
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return carrierZoneses;
    }
    
    private TracfoneOneCarrierZones createInsertMissingCarrierZonesRequest(TracfoneOneCarrierZones carrierZones, String carrierName){
        TracfoneOneCarrierZones carrierZones1 = new TracfoneOneCarrierZones();
        carrierZones1.setBtaMarketName(carrierZones.getBtaMarketName());
        carrierZones1.setBtaMarketNumber(carrierZones.getBtaMarketNumber());
        carrierZones1.setCarrierId(carrierZones.getCarrierId());
        carrierZones1.setCarrierName(carrierName);
        carrierZones1.setCarrierRank(carrierZones.getCarrierRank());
        carrierZones1.setCity(carrierZones.getCity());
        carrierZones1.setCounty(carrierZones.getCounty());
        carrierZones1.setMarketArea(carrierZones.getMarketArea());
        carrierZones1.setNewRank(carrierZones.getNewRank());
        carrierZones1.setPlanType("GOOD");
        carrierZones1.setMarketId(carrierZones.getMarketId());
        carrierZones1.setRateCente(carrierZones.getRateCente());
        carrierZones1.setSimProfile(CarrierZonesControllerUtil.getSimProfile(carrierName));
        carrierZones1.setSimProfile2(CarrierZonesControllerUtil.getSimProfile2(carrierName));
        carrierZones1.setState(CarrierZonesControllerUtil.getStates(carrierZones.getState()));
        carrierZones1.setZipCode(carrierZones.getZipCode());
        carrierZones1.setZipStatus("ACTIVE");
        //Checking if zones contains TEMP_ZONES
        if("TEMP_ZONE".equalsIgnoreCase(carrierZones.getZone()))
            carrierZones1.setZone(carrierZones.getZone());
        else if("T-MOBILE WFM".equalsIgnoreCase(carrierName)){
            String zone = carrierZones.getZone().substring(0,carrierZones.getZone().indexOf("-"));
           carrierZones1.setZone(zone + "_" + CarrierZonesControllerUtil.getZones(carrierName));
        }
        else
            carrierZones1.setZone(null != carrierZones.getZone() ? CarrierZonesControllerUtil.getZones(carrierName) + carrierZones.getZone() : CarrierZonesControllerUtil.getZones(carrierName));
        return carrierZones1;
    }

    private void setMissingCarrierZonesStatement(PreparedStatement stmt, TracfoneOneCarrierZones carrierZones) throws SQLException {
        int index = 1;
        if (!StringUtils.isNullOrEmpty(carrierZones.getZipCode())) {
            stmt.setString(index++, carrierZones.getZipCode());
        }
        if (!StringUtils.isNullOrEmpty(carrierZones.getState())) {
            stmt.setString(index++, carrierZones.getState());
        }
        if (!StringUtils.isNullOrEmpty(carrierZones.getCounty())) {
            stmt.setString(index++, carrierZones.getCounty());
        }
        if (!StringUtils.isNullOrEmpty(carrierZones.getZone())) {
            stmt.setString(index++, carrierZones.getZone());
        }
        if (!StringUtils.isNullOrEmpty(carrierZones.getRateCente())) {
            stmt.setString(index++, carrierZones.getRateCente());
        }
        if (!StringUtils.isNullOrEmpty(carrierZones.getMarketId())) {
            stmt.setString(index++, carrierZones.getMarketId());
        }
        if (!StringUtils.isNullOrEmpty(carrierZones.getMarketArea())) {
            stmt.setString(index++, carrierZones.getMarketArea());
        }
        if (!StringUtils.isNullOrEmpty(carrierZones.getCity())) {
            stmt.setString(index++, carrierZones.getCity());
        }
        if (!StringUtils.isNullOrEmpty(carrierZones.getBtaMarketNumber())) {
            stmt.setString(index++, carrierZones.getBtaMarketNumber());
        }
        if (!StringUtils.isNullOrEmpty(carrierZones.getBtaMarketName())) {
            stmt.setString(index++, carrierZones.getBtaMarketName());
        }
        if (!StringUtils.isNullOrEmpty(carrierZones.getCarrierName())) {
            stmt.setString(index++, carrierZones.getCarrierName());
        }
        if (!StringUtils.isNullOrEmpty(carrierZones.getZipStatus())) {
            stmt.setString(index++, carrierZones.getZipStatus());
        }
        stmt.setString(index++, carrierZones.getSimProfile());
        stmt.setString(index++, carrierZones.getSimProfile2());
        if (!StringUtils.isNullOrEmpty(carrierZones.getPlanType())) {
            stmt.setString(index, carrierZones.getPlanType());
        }
    }

    @Override
    public TFOneCPrefResponse insertCPref(List<TracfoneOneCarrierZones> carrierZones, int userId) throws TracfoneOneException {
        TFOneCPrefResponse response = new TFOneCPrefResponse();
        List<TracfoneOneCarrierZones> successRecords = new ArrayList<>(1);
        List<TracfoneOneCarrierZones> failedRecords = new ArrayList<>(1);
        try (Connection con = dbControllerEJB.getDataSource(carrierZones.get(0).getDbEnv()).getConnection();
             PreparedStatement insertStmt = con.prepareStatement(TRACFONE_INSERT_CARRIER_PREF);
             PreparedStatement stmt = con.prepareStatement(TRACFONE_SELECT_CARRIER_PREF);) {
            LOGGER.info("Insert carrier Pref query :" + TRACFONE_INSERT_CARRIER_PREF);
            carrierZones.forEach(carrierZone -> {
                try {
                    int index = 1;
                    insertStmt.setString(index++, carrierZone.getState());
                    insertStmt.setString(index++, carrierZone.getCounty());
//                    insertStmt.setInt(index++, Integer.parseInt(carrierZone.getCarrierId()));
                    insertStmt.setString(index++,carrierZone.getCarrierId());
                    insertStmt.setString(index++, carrierZone.getCarrierName());
                    insertStmt.executeUpdate();
                } catch (SQLException ex) {
                    LOGGER.error(ex);
                    failedRecords.add(createFailedReposnseForInsertCpref(carrierZone, ex));
                    return;
                }
                try {
                    int index = 1;
                    stmt.setString(index++, carrierZone.getState());
                    stmt.setString(index++, carrierZone.getCounty());
                    stmt.setString(index++, carrierZone.getCarrierId());
                    stmt.setString(index++, carrierZone.getCarrierName());
                    try (ResultSet resultSet = stmt.executeQuery()) {
                        if (!resultSet.next()) {
                            carrierZone.setReasonToFail("Duplicate record found");
                            carrierZone.setTechReasonToFail("Record already exists in table carrierpref " +
                                    "for State = " + carrierZone.getState() +
                                    " and County = " + carrierZone.getCounty() +
                                    " and Carrier Id = " + carrierZone.getCarrierId());
                            failedRecords.add(carrierZone);
                        } else {
                            do {
                                successRecords.add(seCarrierPrefStatement(resultSet));
                            } while (resultSet.next());
                        }
                    }
                } catch (SQLException ex) {
                    LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, ex);
                }
            });
            response.setFailedRecords(failedRecords);
            response.setSuccessRecords(successRecords.stream()
                    .sorted(Comparator.comparingInt(TracfoneOneCarrierZones::getNewRank))
                    .collect(Collectors.toList()));
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return response;
    }

    private TracfoneOneCarrierZones createFailedReposnseForInsertCpref(TracfoneOneCarrierZones carrierZones, Exception ex){
        if (String.valueOf(ex).contains(TABLE_NOT_FOUND_ORACODE)) {
            carrierZones.setReasonToFail("carrierpref table was not found.");
        } else if (String.valueOf(ex).contains(INVALID_TYPE_ORACODE)) {
            carrierZones.setReasonToFail(INVALID_DATA_TYPE);
        } else if (String.valueOf(ex).contains(GRANT_ORACODE)) {
            carrierZones.setReasonToFail(TABLE_GRANT);
        } else {
            carrierZones.setReasonToFail(FAILED_CHECK_TECHNICAL_REASON);
        }
        carrierZones.setTechReasonToFail(ex.getMessage());
        return carrierZones;
    }

    @Override
    public TFOneNpaNxx2Carrier insertNpaNxx(List<TracfoneOneNpaNxx2Carrier> nxx2Carrier, int userId) throws TracfoneOneException {
        List<TracfoneOneNpaNxx2Carrier> successRecords = new ArrayList<>(1);
        List<TracfoneOneNpaNxx2Carrier> failedRecords = new ArrayList<>(1);
        TFOneNpaNxx2Carrier npaNxx2Carrier = new TFOneNpaNxx2Carrier();
        try (Connection con = dbControllerEJB.getDataSource(nxx2Carrier.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_NAPNXX)) {
            if (!nxx2Carrier.isEmpty()) {
                nxx2Carrier.forEach(_e1 -> {
                    try {
                        int index = 1;
                        stmt.setString(index++, _e1.getCarrierId());
                        stmt.setString(index++, _e1.getCarrierName());
                        stmt.setString(index++, _e1.getRateCente());
                        stmt.setString(index++, _e1.getState());
                        stmt.setString(index++, _e1.getCoverageType());
                        stmt.setString(index++, _e1.getZone());
                        stmt.setString(index++, _e1.getCounty());
                        stmt.setString(index++, _e1.getMarketId());
                        stmt.setString(index++, _e1.getMarketArea());
                        stmt.setString(index++, _e1.getBtaMarketNumber());
                        stmt.setString(index++, _e1.getBtaMarketName());
                        stmt.executeUpdate();
                    } catch (SQLException ex) {
                        LOGGER.error(ex);
                        if (String.valueOf(ex).contains(TABLE_NOT_FOUND_ORACODE)) {
                            _e1.setReasonToFail(NPANXX2CARRIERZONES_TABLE_NOT_FOUND);
                        } else if (String.valueOf(ex).contains(INVALID_TYPE_ORACODE)) {
                            _e1.setReasonToFail(INVALID_DATA_TYPE);
                        } else if (String.valueOf(ex).contains(GRANT_ORACODE)) {
                            _e1.setReasonToFail(TABLE_GRANT);
                        } else if (ex.getMessage().contains(NPANXX2CARRIERZONES_DUPLICATE)) {
                            _e1.setReasonToFail(DUPLICATE_RECORD_FOUND);
                        } else {
                            _e1.setReasonToFail(FAILED_CHECK_TECHNICAL_REASON);
                        }
                        _e1.setTechReasonToFail(ex.getMessage());
                        failedRecords.add(_e1);
                        return;
                    }
                    successRecords.add(_e1);
                });
                npaNxx2Carrier.setSuccessRecords(successRecords);
                npaNxx2Carrier.setFailedRecords(failedRecords);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, INSERT_NPANXX, INSERTED_NPANXX + nxx2Carrier, null);
            tracfoneAuditEvent.fire(audit);
        }
        return npaNxx2Carrier;
    }

    private TracfoneOneCarrierZones seCarrierPrefStatement(ResultSet resultSet) throws SQLException {
        TracfoneOneCarrierZones carrierZones = new TracfoneOneCarrierZones();
        carrierZones.setState(resultSet.getString("ST"));
        carrierZones.setCounty(resultSet.getString("COUNTY"));
        carrierZones.setCarrierId(resultSet.getString("CARRIER_ID"));
        carrierZones.setCarrierName(resultSet.getString(CARRIER_NAME));
        carrierZones.setCarrierRank(resultSet.getString("CARRIER_RANK"));
        carrierZones.setNewRank(resultSet.getInt("NEW_RANK"));
        return carrierZones;
    }

    @Override
    public TFOneCarrierZonesDeployment validateCingularMrktInfo(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException {
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        List<TFOneCingularMrktInfo> cingularMrktInfoList = new ArrayList<>(1);
        int index = 1;
        try (Connection con = dbControllerEJB.getDataSource(carrierZonesDeployment.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(buildInClause(TRACFONE_SEARCH_CINGULAR_MRKT_INFO, carrierZonesDeployment))) {
            for (int i = 0; i < carrierZonesDeployment.getZipcodes().size(); i++) {
                stmt.setString(index++, carrierZonesDeployment.getZipcodes().get(i));
            }

            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    cingularMrktInfoList.add(setCingularMrktInfos(resultSet));
                }
            }
            Set<String> existingZipCodes = new HashSet<>();
            for (int i = 0; i < cingularMrktInfoList.size(); i++) {
                existingZipCodes.add(cingularMrktInfoList.get(i).getZip());
            }
            List<String> nonExistingZipCodes = new ArrayList<>(1);
            carrierZonesDeployment.getZipcodes().forEach(zip -> {
                if (!existingZipCodes.contains(zip)) {
                    nonExistingZipCodes.add(zip);
                }
            });
            zonesDeployment.setCingularMrktInfos(cingularMrktInfoList);
            zonesDeployment.setNewZipCodes(nonExistingZipCodes);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return zonesDeployment;
    }

    private TFOneCingularMrktInfo setCingularMrktInfos(ResultSet resultSet) throws SQLException {
        TFOneCingularMrktInfo tfOneCingularMrktInfo = new TFOneCingularMrktInfo();
        tfOneCingularMrktInfo.setMkt(resultSet.getString("MKT"));
        tfOneCingularMrktInfo.setNpa(resultSet.getString("NPA"));
        tfOneCingularMrktInfo.setNxx(resultSet.getString("NXX"));
        tfOneCingularMrktInfo.setNpanxx(resultSet.getString("NPANXX"));
        tfOneCingularMrktInfo.setRcNumber(resultSet.getString("RC_NUMBER"));
        tfOneCingularMrktInfo.setRcName(resultSet.getString("RC_NAME"));
        tfOneCingularMrktInfo.setRcState(resultSet.getString("RC_STATE"));
        tfOneCingularMrktInfo.setZip(resultSet.getString("ZIP"));
        tfOneCingularMrktInfo.setMktType(resultSet.getString("MKT_TYPE"));
        tfOneCingularMrktInfo.setAccountNum(resultSet.getString("ACCOUNT_NUM"));
        tfOneCingularMrktInfo.setMarketCode(resultSet.getString("MARKET_CODE"));
        tfOneCingularMrktInfo.setDealerCode(resultSet.getString("DEALER_CODE"));
        tfOneCingularMrktInfo.setSubMarketId(resultSet.getString("SUBMARKETID"));
        tfOneCingularMrktInfo.setTemplate(resultSet.getString("TEMPLATE"));
        return tfOneCingularMrktInfo;
    }

    @Override
    public TFOneCarrierZonesDeployment validateZipMktSubMkt(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException {
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        int index = 1;
        try {
            Query sql = cRtlCarrierPrefFacadeLocal.getEntityManager().createNativeQuery(buildInClause(TRACFONE_SEARCH_ZIPMKT_SUBMKT, carrierZonesDeployment));
            for (int i = 0; i < carrierZonesDeployment.getZipcodes().size(); i++) {
                sql.setParameter(index++, carrierZonesDeployment.getZipcodes().get(i));
            }
            List<Object[]> rows = sql.getResultList();
            List<TFOneZipMktSubMkt> result = new ArrayList<>(rows.size());
            rows.forEach(row ->
                    result.add(new TFOneZipMktSubMkt(
                            (String) row[0], (String) row[1], (String) row[2], (String) row[3], (String) row[4], (String) row[5],
                            (String) row[6], (String) row[7], (String) row[8], (String) row[9], (String) row[10], (String) row[11],
                            (String) row[12], (String) row[13], (String) row[14], (String) row[15], (String) row[16], row[17] != null ? (String) row[17] : null,
                            row[18] != null ? (String) row[18] : null
                    ))
            );

            Set<String> existingZipCodes = new HashSet<>();
            for (int i = 0; i < result.size(); i++) {
                existingZipCodes.add(result.get(i).getZipCode());
            }
            List<String> nonExistingZipCodes = new ArrayList<>(1);
            carrierZonesDeployment.getZipcodes().forEach(zip -> {
                if (!existingZipCodes.contains(zip)) {
                    nonExistingZipCodes.add(zip);
                }
            });
            zonesDeployment.setZipMktSubMkts(result);
            zonesDeployment.setNewZipCodes(nonExistingZipCodes);

        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return zonesDeployment;
    }

    @Override
    public List<TFOneCingularMrktInfo> updateDealerNan(List<TracfoneOneCingularMrktInfo> cingularMrktInfos) throws TracfoneOneException {
        List<TFOneCingularMrktInfo> cingularMrktInfoList = new ArrayList<>(1);
        LOGGER.info("List are going for updateDealerNan procedure" + cingularMrktInfos);
        try (Connection con = dbControllerEJB.getDataSource(cingularMrktInfos.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_SEARCH_CINGULAR_MRKT_INFO_UPD_DEALER_NAN)) {

            for (TracfoneOneCingularMrktInfo cingularMrktInfo : cingularMrktInfos) {
                if (null == cingularMrktInfo.getDealerCode()) {
                    stmt.setString(1, cingularMrktInfo.getSubMarketId());
                }
                try (ResultSet resultSet = stmt.executeQuery()) {
                    while (resultSet.next()) {
                        cingularMrktInfo.setDealerCode(resultSet.getString("DEALER_CODE"));
                    }
                }
            }
            cingularMrktInfos.forEach(e -> cingularMrktInfoList.add(setCingularMrktInfo(e)));
            LOGGER.info("List after dealer_code update" + cingularMrktInfoList);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return cingularMrktInfoList;
    }

    private TFOneCingularMrktInfo setCingularMrktInfo(TracfoneOneCingularMrktInfo cingularMrktInfo) {
        TFOneCingularMrktInfo tfOneCingularMrktInfo = new TFOneCingularMrktInfo();
        tfOneCingularMrktInfo.setMkt(cingularMrktInfo.getMkt());
        tfOneCingularMrktInfo.setNpa(cingularMrktInfo.getNpa());
        tfOneCingularMrktInfo.setNxx(cingularMrktInfo.getNxx());
        tfOneCingularMrktInfo.setNpanxx(cingularMrktInfo.getNpanxx());
        tfOneCingularMrktInfo.setRcNumber(cingularMrktInfo.getRcNumber());
        tfOneCingularMrktInfo.setRcName(cingularMrktInfo.getRcName());
        tfOneCingularMrktInfo.setRcState(cingularMrktInfo.getRcState());
        tfOneCingularMrktInfo.setZip(cingularMrktInfo.getZip());
        tfOneCingularMrktInfo.setMktType(cingularMrktInfo.getMktType());
        tfOneCingularMrktInfo.setAccountNum(cingularMrktInfo.getAccountNum());
        tfOneCingularMrktInfo.setMarketCode(cingularMrktInfo.getMarketCode());
        tfOneCingularMrktInfo.setDealerCode(cingularMrktInfo.getDealerCode());
        tfOneCingularMrktInfo.setSubMarketId(cingularMrktInfo.getSubMarketId());
        tfOneCingularMrktInfo.setTemplate(cingularMrktInfo.getTemplate());
        return tfOneCingularMrktInfo;
    }

    @Override
    public TFOneMissingCingularMktInfo insertCingularMktInfo(List<TracfoneOneCingularMrktInfo> mrktInfos, int userId) throws TracfoneOneException {
        List<TracfoneOneCingularMrktInfo> successRecords = new ArrayList<>(1);
        List<TracfoneOneCingularMrktInfo> failedRecords = new ArrayList<>(1);
        TFOneMissingCingularMktInfo missingCingularMktInfo = new TFOneMissingCingularMktInfo();
        try (Connection con = dbControllerEJB.getDataSource(mrktInfos.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_CINGULAR_MRKT_INFO);) {
            if (!mrktInfos.isEmpty()) {
                mrktInfos.forEach(_e1 -> {
                    try {
                        if (duplicateCheckCingular(_e1)) {
                            throw new TracfoneOneException(TRACFONE_DUPLICATE_CINGULAR_MKT_INFO_FOUND_ERROR,
                                    TRACFONE_DUPLICATE_CINGULAR_MKT_INFO_FOUND_ERROR_MESSAGE);
                        }
                        setCingularmrktinfoParams(stmt, _e1);
                        stmt.executeUpdate();
                    } catch (SQLException | TracfoneOneException ex) {
                        LOGGER.info(ex);
                        failedRecords.add(createFailedResponseForInsertCingularMktInfo(_e1, ex));
                        return;
                    }
                    successRecords.add(_e1);
                });
            }
            missingCingularMktInfo.setFailedRecords(failedRecords);
            missingCingularMktInfo.setSuccessRecords(successRecords);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Missing Cingular Mrkt Info",
                    "Inserted Missing Cingular Mrkt Info " + missingCingularMktInfo, null);
            tracfoneAuditEvent.fire(audit);
        }
        return missingCingularMktInfo;
    }

    private TracfoneOneCingularMrktInfo createFailedResponseForInsertCingularMktInfo(TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo, Exception ex){
        if (String.valueOf(ex).contains(TABLE_NOT_FOUND_ORACODE)) {
            tracfoneOneCingularMrktInfo.setReasonToFail("X_CINGULAR_MRKT_INFO table was not found.");
        } else if (String.valueOf(ex).contains(INVALID_TYPE_ORACODE)) {
            tracfoneOneCingularMrktInfo.setReasonToFail(INVALID_DATA_TYPE);
        } else if (String.valueOf(ex).contains(GRANT_ORACODE)) {
            tracfoneOneCingularMrktInfo.setReasonToFail(TABLE_GRANT);
        } else if (ex.getMessage().equalsIgnoreCase(TRACFONE_DUPLICATE_CINGULAR_MKT_INFO_FOUND_ERROR_MESSAGE)) {
            tracfoneOneCingularMrktInfo.setReasonToFail(TRACFONE_DUPLICATE_CINGULAR_MKT_INFO_FOUND_ERROR_MESSAGE);
        } else {
            tracfoneOneCingularMrktInfo.setReasonToFail(FAILED_CHECK_TECHNICAL_REASON);
        }
        tracfoneOneCingularMrktInfo.setTechReasonToFail(ex.getMessage());
        return tracfoneOneCingularMrktInfo;
    }

    private boolean duplicateCheckCingular(TracfoneOneCingularMrktInfo tfCingularMrktInfo) throws SQLException, TracfoneOneException {
        boolean duplicateCingularMktInfoExist = false;
        try (Connection con = dbControllerEJB.getDataSource(tfCingularMrktInfo.getDbEnv()).getConnection();) {
            int count = 0;
            try (PreparedStatement stmt = con.prepareStatement(TRACFONE_DUPLICATE_CINGULAR_MKT_INFO);) {
                stmt.setString(1, tfCingularMrktInfo.getZip());
                try (ResultSet resultSet = stmt.executeQuery();) {
                    LOGGER.info("What am I searching for Cingular Mkt Duplicate Check? " + tfCingularMrktInfo.getZip());
                    while (resultSet.next()) {
                        count = resultSet.getInt(1);
                        LOGGER.info("Cingular Mkt Duplicate found" + count);
                    }
                }
            }
            if (count > 0) {
                duplicateCingularMktInfoExist = true;
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return duplicateCingularMktInfoExist;
    }

    private void setCingularmrktinfoParams(PreparedStatement stmt, TracfoneOneCingularMrktInfo tracfoneOneCingularMrktInfo) throws SQLException {
        int index = 1;
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getMkt());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getNpa());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getNxx());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getNpanxx());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getRcNumber());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getRcName());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getRcState());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getZip());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getMktType());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getAccountNum());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getMarketCode());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getDealerCode());
        stmt.setString(index++, tracfoneOneCingularMrktInfo.getSubMarketId());
        stmt.setString(index, tracfoneOneCingularMrktInfo.getTemplate());
    }

    @Override
    public TFOneCarrierZonesDeployment validateNextAvailable(TracfoneOneCarrierZonesDeployment carrierZonesDeployment) throws TracfoneOneException {
        TFOneCarrierZonesDeployment zonesDeployment = new TFOneCarrierZonesDeployment();
        int index = 1;
        try {
            Query sql = cRtlCarrierPrefFacadeLocal.getEntityManager().createNativeQuery(buildInClause(TRACFONE_SEARCH_TMO_NEXT_AVAILABLE, carrierZonesDeployment));
            for (int i = 0; i < carrierZonesDeployment.getZipcodes().size(); i++) {
                sql.setParameter(index++, carrierZonesDeployment.getZipcodes().get(i));
            }
            List<Object[]> rows = sql.getResultList();
            List<TFOneNextAvailable> result = new ArrayList<>(rows.size());
            rows.forEach(row ->
                    result.add(new TFOneNextAvailable(
                            (String) row[0], (String) row[1], (String) row[2], (String) row[3], (String) row[4], (String) row[5], (String) row[6]
                    ))
            );

            Set<String> existingZipCodes = new HashSet<>();
            for (int i = 0; i < result.size(); i++) {
                existingZipCodes.add(result.get(i).getZipCode());
            }
            List<String> nonExistingZipCodes = new ArrayList<>(1);
            carrierZonesDeployment.getZipcodes().forEach(zip -> {
                if (!existingZipCodes.contains(zip)) {
                    nonExistingZipCodes.add(zip);
                }
            });
            zonesDeployment.setTmoNextAvailable(result);
            zonesDeployment.setNewZipCodes(nonExistingZipCodes);

        } catch (Exception e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return zonesDeployment;
    }

    @Override
    public TFOneNpaNxx2Carrier insertTmoNpaNxx(List<TracfoneOneNpaNxx2Carrier> nxx2Carrier, int userId) throws TracfoneOneException {
        List<TracfoneOneNpaNxx2Carrier> successRecords = new ArrayList<>(1);
        List<TracfoneOneNpaNxx2Carrier> failedRecords = new ArrayList<>(1);
        TFOneNpaNxx2Carrier npaNxx2Carrier = new TFOneNpaNxx2Carrier();
        try (Connection con = dbControllerEJB.getDataSource(nxx2Carrier.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_TMO_NAPNXX)) {
            if (!nxx2Carrier.isEmpty()) {
                nxx2Carrier.forEach(_e1 -> {
                    try {
                        int index = 1;
                        stmt.setString(index++, _e1.getCarrierId());
                        stmt.setString(index++, _e1.getCarrierName());
                        stmt.setString(index++, _e1.getRateCente());
                        stmt.setString(index++, _e1.getState());
                        stmt.setString(index++, _e1.getCarrierId());
                        stmt.setString(index++, _e1.getCoverageType());
                        stmt.setString(index++, _e1.getZone());
                        stmt.setString(index++, _e1.getCounty());
                        stmt.setString(index++, _e1.getMarketId());
                        stmt.setString(index++, _e1.getMarketArea());
                        stmt.setString(index++, _e1.getBtaMarketNumber());
                        stmt.setString(index++, _e1.getBtaMarketName());
                        stmt.executeUpdate();
                    } catch (SQLException ex) {
                        LOGGER.error(ex);
                        if (String.valueOf(ex).contains(TABLE_NOT_FOUND_ORACODE)) {
                            _e1.setReasonToFail(NPANXX2CARRIERZONES_TABLE_NOT_FOUND);
                        } else if (String.valueOf(ex).contains(INVALID_TYPE_ORACODE)) {
                            _e1.setReasonToFail(INVALID_DATA_TYPE);
                        } else if (String.valueOf(ex).contains(GRANT_ORACODE)) {
                            _e1.setReasonToFail(TABLE_GRANT);
                        } else if (ex.getMessage().contains(NPANXX2CARRIERZONES_DUPLICATE)) {
                            _e1.setReasonToFail(DUPLICATE_RECORD_FOUND);
                        } else {
                            _e1.setReasonToFail(FAILED_CHECK_TECHNICAL_REASON);
                        }
                        _e1.setTechReasonToFail(ex.getMessage());
                        failedRecords.add(_e1);
                        return;
                    }
                    successRecords.add(_e1);
                });
                npaNxx2Carrier.setSuccessRecords(successRecords);
                npaNxx2Carrier.setFailedRecords(failedRecords);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, INSERT_NPANXX, INSERTED_NPANXX + nxx2Carrier, null);
            tracfoneAuditEvent.fire(audit);
        }
        return npaNxx2Carrier;
    }


    @Override
    public TFOneNpaNxx2Carrier insertNpaNxxAtt(List<TracfoneOneNpaNxx2Carrier> nxx2Carriers, int userId) throws TracfoneOneException {
        List<TracfoneOneNpaNxx2Carrier> successRecords = new ArrayList<>(1);
        List<TracfoneOneNpaNxx2Carrier> failedRecords = new ArrayList<>(1);
        TFOneNpaNxx2Carrier npaNxx2Carrier = new TFOneNpaNxx2Carrier();
        try (Connection con = dbControllerEJB.getDataSource(nxx2Carriers.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_NAPNXX_ATT)) {
            if (!nxx2Carriers.isEmpty()) {
                nxx2Carriers.forEach(_e1 -> {
                    try {
                        int index = 1;
                        stmt.setString(index++, _e1.getCarrierId());
                        stmt.setString(index++, _e1.getCarrierName());
                        stmt.setString(index++, _e1.getRateCente());
                        stmt.setString(index++, _e1.getState());
                        stmt.setString(index++, _e1.getCoverageType());
                        stmt.setString(index++, _e1.getZone());
                        stmt.setString(index++, _e1.getCounty());
                        stmt.setString(index++, _e1.getMarketId());
                        stmt.setString(index++, _e1.getMarketArea());
                        stmt.setString(index++, _e1.getBtaMarketNumber());
                        stmt.setString(index++, _e1.getBtaMarketName());
                        stmt.executeUpdate();
                    } catch (SQLException ex) {
                        LOGGER.error(ex);
                        if (String.valueOf(ex).contains(TABLE_NOT_FOUND_ORACODE)) {
                            _e1.setReasonToFail(NPANXX2CARRIERZONES_TABLE_NOT_FOUND);
                        } else if (String.valueOf(ex).contains(INVALID_TYPE_ORACODE)) {
                            _e1.setReasonToFail(INVALID_DATA_TYPE);
                        } else if (String.valueOf(ex).contains(GRANT_ORACODE)) {
                            _e1.setReasonToFail(TABLE_GRANT);
                        } else if (ex.getMessage().contains(NPANXX2CARRIERZONES_DUPLICATE)) {
                            _e1.setReasonToFail(DUPLICATE_RECORD_FOUND);
                        } else {
                            _e1.setReasonToFail(FAILED_CHECK_TECHNICAL_REASON);
                        }
                        _e1.setTechReasonToFail(ex.getMessage());
                        failedRecords.add(_e1);
                        return;
                    }
                    successRecords.add(_e1);
                });
                npaNxx2Carrier.setSuccessRecords(successRecords);
                npaNxx2Carrier.setFailedRecords(failedRecords);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, INSERT_NPANXX, INSERTED_NPANXX + nxx2Carriers, null);
            tracfoneAuditEvent.fire(audit);
        }
        return npaNxx2Carrier;
    }

    private String getSearchCarrierGroupStatement(TracfoneOneIGCarrierConfig carrierConfig) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_GET_ALL_CARRIER);
        if (carrierConfig.getCarrier().equals("ATT")) {
            builder.append("'ATT%' OR UPPER(x_mkt_submkt_name) LIKE 'AT&T%'");
        }
        if (carrierConfig.getCarrier().equals("VERIZON")) {
            builder.append("'VERIZON%'");
        }
        if (carrierConfig.getCarrier().equals("CLARO")) {
            builder.append("'CLARO%'");
        }
        if (carrierConfig.getCarrier().equals("TMO")) {
            builder.append("'TMO%' OR UPPER(x_mkt_submkt_name) LIKE 'T-MOBILE%'");
        }
        searchQuery = builder.toString();
        LOGGER.info("Query to fetch carriers " + searchQuery);
        System.out.print("sssss " + searchQuery);
        return searchQuery;
    }

    @Override
    public List<String> getCarriers(TracfoneOneIGCarrierConfig carrierConfig) throws TracfoneOneException {
        List<String> carrierData = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(carrierConfig.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchCarrierGroupStatement(carrierConfig));) {
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    carrierData.add(resultSet.getString("X_CARRIER_ID"));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return carrierData;
    }
}
