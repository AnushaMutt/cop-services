package com.tracfone.service.model.report;

/**
 *
 * @author druiz
 */
public class TFOneReportAverageTimeByStatus {
    
    private String carrier;
    private String xDate;
    private String orderType;
    private String timeSegment;
    private String timeWaiting;
    private String count;
    
    
    
    public String getxDate() {
        return xDate;
    }

    public void setxDate(String xDate) {
        this.xDate = xDate;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getTimeSegment() {
        return timeSegment;
    }

    public void setTimeSegment(String timeSegment) {
        this.timeSegment = timeSegment;
    }

    public String getTimeWaiting() {
        return timeWaiting;
    }

    public void setTimeWaiting(String timeWaiting) {
        this.timeWaiting = timeWaiting;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }
}
