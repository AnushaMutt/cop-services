/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneFeatureRequirement;
import com.tracfone.service.model.request.TracfoneOneLineStatusCode;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionConfig;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneThrottleStatusCode;
import com.tracfone.service.model.response.TFOneCarrier;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneFeatureRequirement;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneLineStatusCode;
import com.tracfone.service.model.response.TFOneRPFeatureNameList;
import com.tracfone.service.model.response.TFOneRatePlanExtensionConfig;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import com.tracfone.service.model.response.TFOneThrottleStatusCode;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantPlanWizard;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.util.IOUtils;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author Nidhi Mantri
 */
@Stateless
public class TracfoneFeatureAction implements TracfoneFeatureLocalAction, TracfoneOneConstant, TracfoneOneConstantPlanWizard {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneFeatureAction.class);

    @EJB
    DataBaseController dbControllerEJB;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    private static final String AND = " AND ";

    @Override
    public List<TFOneRPFeatureNameList> getAllMasterFeatures(String dbEnv) throws TracfoneOneException {
        List<TFOneRPFeatureNameList> tfOneFeatureMasters = new ArrayList<>();
        TFOneRPFeatureNameList tfOneFeatureMaster;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_MASTER_FEATURES);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                tfOneFeatureMaster = new TFOneRPFeatureNameList();
                tfOneFeatureMaster.setFeatureName(resultSet.getString(FEATURE_NAME));
                tfOneFeatureMasters.add(tfOneFeatureMaster);
            }

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfOneFeatureMasters;
    }

    // this method is used to add new feature for new profile id in master and its association with sa.x_rp_extension_config
    @Override
    public TFOneGeneralResponse insertRpExtensionConfig(List<TracfoneOneRatePlanExtensionConfig> tfOneRpExtensionConfigs, int userId, String unique) throws TracfoneOneException {
        List<String> rpExtensionConfigObjids = new ArrayList<>();
        int[] count;
        try (Connection con = dbControllerEJB.getDataSource(tfOneRpExtensionConfigs.get(0).getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_RP_EXTENSION_CONFIG);) {

            for (TracfoneOneRatePlanExtensionConfig rpExtensionConfig : tfOneRpExtensionConfigs) {
                Set<String> featureValues = getAllFeatureValuesByProfileId(rpExtensionConfig);
                if (!featureValues.contains(rpExtensionConfig.getFeatureValue())) {
                    String rpExtensionConfigObjid = getNextSequence(con, TRACFONE_EXTENSION_CONFIG_ID_SEQ_STMT, "EXTENSION_LINKID_SEQ");
                    rpExtensionConfig.setObjid(rpExtensionConfigObjid);
                    rpExtensionConfigObjids.add(rpExtensionConfigObjid);
                    setRpExtensionConfigQueryParams(stmt, rpExtensionConfig, false);
                    stmt.addBatch();
                }
            }

            count = stmt.executeBatch();

            if (count.length != tfOneRpExtensionConfigs.size()) {
                LOGGER.info("All rp extension configs did not get committed");
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit;
            // Added this logic to track bulk insert of profile features for multiple profiles
            if (StringUtils.isNullOrEmpty(unique)) {
                audit = new TracfoneAudit(userId, "Insert RP Extension Config",
                        "Inserted RP Extension Config objIds " + rpExtensionConfigObjids, null);
            } else {
                audit = new TracfoneAudit(userId, "Bulk PF Insert",
                        "Inserted RP Extension Config objId " + tfOneRpExtensionConfigs, "CARRIER ID_" + unique);
            }
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, rpExtensionConfigObjids.toString());
    }

    private String getNextSequence(Connection con, String queryString, String seqId) throws SQLException {
        String sequenceId = null;
        try (PreparedStatement stmt = con.prepareStatement(queryString);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                sequenceId = resultSet.getString(seqId);
            }
        }
        return sequenceId;
    }

    // this method is used to get all features associated with profileid from rp_extension_config table.
    @Override
    public List<TFOneRatePlanExtensionConfig> getAllProfileFeatures(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) throws TracfoneOneException {
        List<TFOneRatePlanExtensionConfig> tfOneProfileFeatures = new ArrayList<>();
        TFOneRatePlanExtensionConfig tfOneProfileFeature;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneSearchProfileModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getProfileFeaturesStatement(tracfoneOneSearchProfileModel));) {
            int index = 1;
            if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getProfileId())) {
                stmt.setString(index++, tracfoneOneSearchProfileModel.getProfileId());
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getRatePlan())) {
                stmt.setString(index++, tracfoneOneSearchProfileModel.getRatePlan());
                stmt.setString(index++, "%" + tracfoneOneSearchProfileModel.getRatePlan().toUpperCase() + "%");
            }

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneProfileFeature = new TFOneRatePlanExtensionConfig();
                    tfOneProfileFeature.setObjid(resultSet.getString(OBJID));
                    tfOneProfileFeature.setProfileId(resultSet.getString(PROFILE_ID));
                    tfOneProfileFeature.setFeatureName(resultSet.getString(FEATURE_NAME));
                    tfOneProfileFeature.setFeatureValue(resultSet.getString(FEATURE_VALUE));
                    tfOneProfileFeature.setFeatureRequirement(resultSet.getString(FEATURE_REQUIREMENT));
                    tfOneProfileFeature.setToggleFlag(resultSet.getString("TOGGLE_FLAG"));
                    tfOneProfileFeature.setNotes(convertClobToString(resultSet.getClob("NOTES")));
                    tfOneProfileFeature.setRestrictSUIFlag(resultSet.getString("RESTRICT_SUI_FLAG"));
                    tfOneProfileFeature.setDisplaySUIFlag(resultSet.getString("DISPLAY_SUI_FLAG"));
                    tfOneProfileFeatures.add(tfOneProfileFeature);
                }
            }
        } catch (SQLException | NamingException | IOException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfOneProfileFeatures;
    }

    private String getProfileFeaturesStatement(TracfoneOneSearchProfileModel searchProfileModel) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_GET_ALL_RP_EXTENSION_CONFIGS);
        if (!StringUtils.isNullOrEmpty(searchProfileModel.getProfileId())) {
            builder.append("PROFILE_ID = ?").append(AND);
        }
        if (!StringUtils.isNullOrEmpty(searchProfileModel.getRatePlan())) {
            builder.append("(PROFILE_ID in (select PROFILE_ID from sa.X_RP_EXTENSION_CONFIG where FEATURE_VALUE = ? and UPPER(FEATURE_NAME) = 'RATE_PLAN')) ")
                    .append("OR PROFILE_ID in (select PROFILE_ID from sa.X_RP_PROFILE where UPPER(profile_desc) like ?)")
                    .append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND));
        }
        LOGGER.info(searchQuery);

        return searchQuery;
    }

    @Override
    public TFOneGeneralResponse deleteRpExtensionConfigs(String dbEnv, List<String> toBeDeletedIds, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(buildInClause(TRACFONE_DELETE_RP_EXTENSION_CONFIG, toBeDeletedIds.size()));) {
            int index = 1;
            for (String id : toBeDeletedIds) {
                stmt.setLong(index++, Long.valueOf(id));
            }
            stmt.executeUpdate();

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete RP Extension Config", "Deleted RP Extension Config objIds " + toBeDeletedIds, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, toBeDeletedIds.toString());
    }

    private String buildInClause(String deleteQuery, int size) {
        StringBuilder query = new StringBuilder(deleteQuery);
        if (size != 1) {
            int index = 1;
            while (index < size) {
                query.append(", ?");
                index++;
            }
        }
        query.append(")");

        return query.toString();
    }

    private String convertClobToString(Clob clob) throws SQLException, IOException {
        String convertedClob = null;
        if (null != clob) {
            Reader reader = clob.getCharacterStream();
            StringWriter writer = new StringWriter();
            IOUtils.copy(reader, writer);
            convertedClob = writer.toString();
        }
        return convertedClob;
    }

    private void setRpExtensionConfigQueryParams(PreparedStatement stmt,
                                                 TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig,
                                                 boolean isUpdate) throws SQLException {
        int index = 1;
        if (!isUpdate) {
            stmt.setLong(index++, Long.valueOf(tfOneRpExtensionConfig.getObjid()));
        }
        stmt.setLong(index++, Long.valueOf(tfOneRpExtensionConfig.getProfileId()));
        stmt.setString(index++, tfOneRpExtensionConfig.getFeatureName().trim());
        stmt.setString(index++, tfOneRpExtensionConfig.getFeatureValue().trim());
        stmt.setString(index++, tfOneRpExtensionConfig.getFeatureRequirement());
        stmt.setString(index++, tfOneRpExtensionConfig.getToggleFlag().trim().toUpperCase());
        if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getNotes())) {
            String notes = tfOneRpExtensionConfig.getNotes();
            stmt.setCharacterStream(index++, new StringReader(notes), notes.length());
        } else {
            stmt.setNull(index++, Types.CLOB);
        }
        stmt.setString(index++, tfOneRpExtensionConfig.getDisplaySUIFlag().toUpperCase());
        stmt.setString(index++, tfOneRpExtensionConfig.getRestrictSUIFlag().toUpperCase());
        if (isUpdate) {
            stmt.setLong(index, Long.valueOf(tfOneRpExtensionConfig.getObjid()));
        }
    }

    private String getDuplicateRpExtensionQuery() {
        String duplicateQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_GET_FEATURE_VALUES_RP_EXTENSION_CONFIGS);
        builder.append(" and feature_value = ? and objid not in (?)");
        duplicateQuery = builder.toString();
        LOGGER.info("Feature Value duplicate check : " + duplicateQuery);
        return duplicateQuery;
        }

    @Override
    public TFOneGeneralResponse updateRpExtensionConfig(TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneRpExtensionConfig.getDbEnv()).getConnection();
             PreparedStatement duplicateStmt = con.prepareStatement(getDuplicateRpExtensionQuery());) {
            int index = 1;
            duplicateStmt.setString(index++, tfOneRpExtensionConfig.getProfileId());
            duplicateStmt.setString(index++, tfOneRpExtensionConfig.getFeatureValue());
            duplicateStmt.setLong(index++, Long.valueOf(tfOneRpExtensionConfig.getObjid()));
            String featureValue = null;
            try (ResultSet resultSet = duplicateStmt.executeQuery()) {
                while (resultSet.next()) {
                    featureValue = resultSet.getString(FEATURE_VALUE);
                    break;
                }
            }

            if (StringUtils.isNullOrEmpty(featureValue)) {
                try (PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_RP_EXTENSION_CONFIG);) {
                    setRpExtensionConfigQueryParams(stmt, tfOneRpExtensionConfig, true);
                    stmt.executeUpdate();
                }
            } else {
                throw new TracfoneOneException(TRACFONE_DUPLICATE_RP_EXTENSION_CONFIG_ERROR, TRACFONE_DUPLICATE_RP_EXTENSION_CONFIG_ERROR_MESSAGE + tfOneRpExtensionConfig.getFeatureValue());
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update RP Extension Config", "Updated RP Extension Config object " + tfOneRpExtensionConfig, null);
            tracfoneAuditEvent.fire(audit);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneRpExtensionConfig.getObjid());
    }

    @Override
    public List<String> findExistingMasterFeatures(String dbEnv, Set<String> featureNames) throws TracfoneOneException {
        List<String> existingFeatures = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(buildInClause(TRACFONE_VIEW_MASTER_FEATURE, featureNames.size()));) {

            int index = 1;
            for (String featureName : featureNames) {
                stmt.setString(index++, featureName);
            }

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    existingFeatures.add(resultSet.getString(FEATURE_NAME));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return existingFeatures;
    }

    @Override
    public void insertMasterFeature(String dbEnv, Set<String> featureNames, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_MASTER_FEATURE);) {
            for (String featureName : featureNames) {
                stmt.setString(1, featureName);
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Master Feature", "Inserted Master Feature object " + featureNames, null);
            tracfoneAuditEvent.fire(audit);
        }
    }

    @Override
    public List<TFOneRatePlanExtensionConfig> viewRpExtensionConfig(TracfoneOneRatePlanExtensionConfig searchConfig) throws TracfoneOneException {
        List<TFOneRatePlanExtensionConfig> tfOneRpExtensionConfigs = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(searchConfig.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_VIEW_RP_EXTENSION_CONFIG);) {
            stmt.setLong(1, Long.valueOf(searchConfig.getProfileId()));

            try (ResultSet resultSet = stmt.executeQuery();) {
                TFOneRatePlanExtensionConfig tfOneRpExtensionConfig = null;
                while (resultSet.next()) {
                    tfOneRpExtensionConfig = new TFOneRatePlanExtensionConfig();
                    tfOneRpExtensionConfig.setObjid(resultSet.getString(OBJID));
                    tfOneRpExtensionConfig.setFeatureName(resultSet.getString(FEATURE_NAME));
                    tfOneRpExtensionConfig.setFeatureValue(resultSet.getString(FEATURE_VALUE));
                    tfOneRpExtensionConfigs.add(tfOneRpExtensionConfig);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfOneRpExtensionConfigs;
    }

    @Override
    public List<TFOneRatePlanProfile> searchBucketProfile(String dbEnv, String servicePlanId, boolean isChild) throws TracfoneOneException {
        List<TFOneRatePlanProfile> tfFilteredProfiles = new ArrayList<>();
        TFOneRatePlanProfile tfOneProfile;
        String query = TRACFONE_SEARCH_BUCKET_PROFILE;
        if (isChild) {
            query = TRACFONE_SEARCH_CHILD_BUCKET_PROFILE;
        }
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setLong(1, Long.valueOf(servicePlanId));

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneProfile = new TFOneRatePlanProfile();
                    tfOneProfile.setProfileId(resultSet.getString(PROFILE_ID));
                    tfOneProfile.setProfileDescription(resultSet.getString("PROFILE_DESC"));
                    tfFilteredProfiles.add(tfOneProfile);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfFilteredProfiles;
    }

    @Override
    public List<TFOneCarrierServicePlan> getBucketServicePlansForCopy(String dbEnv, boolean isChild) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> tfOneCarrierServicePlans = new ArrayList<>();
        TFOneCarrierServicePlan tfOneCarrierServicePlan;
        String query = TRACFONE_GET_BUCKET_SERVICEPLANS;
        if (isChild) {
            query = TRACFONE_GET_CHILD_BUCKET_SERVICEPLANS;
        }
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(query);) {
            try (ResultSet resultSet = stmt.executeQuery();) {

                while (resultSet.next()) {
                    tfOneCarrierServicePlan = new TFOneCarrierServicePlan();
                    tfOneCarrierServicePlan.setServicePlanId(resultSet.getString(OBJID));
                    tfOneCarrierServicePlan.setMktName(resultSet.getString("mkt_name"));
                    tfOneCarrierServicePlans.add(tfOneCarrierServicePlan);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfOneCarrierServicePlans;
    }

    @Override
    public List<TFOneChildPlan> getBucketChildPlans(String dbEnv, String profileId, String servicePlanId) throws TracfoneOneException {
        List<TFOneChildPlan> tfOneChildPlans = new ArrayList<>();
        TFOneChildPlan tfOneChildPlan;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_BUCKET_CHILD_PLANS);) {
            stmt.setLong(1, Long.valueOf(profileId));
            stmt.setLong(2, Long.valueOf(servicePlanId));

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneChildPlan = new TFOneChildPlan();
                    tfOneChildPlan.setChildPlanId(resultSet.getString("CHILD_ID"));
                    tfOneChildPlan.setChildDescription(resultSet.getString("CHILD_DESCRIPTION"));
                    tfOneChildPlans.add(tfOneChildPlan);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfOneChildPlans;
    }

    @Override
    public List<TFOneLineStatusCode> getAllLineStatusCodes(String dbEnv) throws TracfoneOneException {
        List<TFOneLineStatusCode> lineStatusCodes = new ArrayList<>();
        TFOneLineStatusCode lineStatusCode;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_LINE_STATUS_CODES);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                lineStatusCode = new TFOneLineStatusCode();
                lineStatusCode.setLineStatusCode(resultSet.getString("LINE_STATUS_CODE"));
                lineStatusCode.setDescription(resultSet.getString(DESCRIPTION));
                lineStatusCodes.add(lineStatusCode);
            }

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return lineStatusCodes;
    }

    @Override
    public TFOneGeneralResponse insertLineStatusCode(TracfoneOneLineStatusCode tfOneLineStatus, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneLineStatus.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_LINE_STATUS_CODE);) {

            setLineStatusQuery(stmt, tfOneLineStatus);
            stmt.executeUpdate();

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Rp Line Status", "Inserted Rp Line Status Object " + tfOneLineStatus, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneLineStatus.getLineStatusCode());
    }

    @Override
    public TFOneGeneralResponse updateLineStatusCode(TracfoneOneLineStatusCode tfOneLineStatus, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneLineStatus.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_LINE_STATUS_CODE);) {

            setLineStatusQuery(stmt, tfOneLineStatus);
            stmt.executeUpdate();

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Rp Line Status", "Updated Rp Line Status object " + tfOneLineStatus, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneLineStatus.getLineStatusCode());
    }

    private void setLineStatusQuery(PreparedStatement stmt, TracfoneOneLineStatusCode tfOneLineStatus) throws SQLException {
        stmt.setString(1, tfOneLineStatus.getDescription());
        stmt.setString(2, tfOneLineStatus.getLineStatusCode());
    }

    @Override
    public List<TFOneThrottleStatusCode> getAllThrottleStatusCodes(String dbEnv) throws TracfoneOneException {
        List<TFOneThrottleStatusCode> throttleStatusCodes = new ArrayList<>();
        TFOneThrottleStatusCode throttleStatusCode;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_THROTTLE_STATUS_CODES);
             ResultSet resultSet = stmt.executeQuery();) {

            while (resultSet.next()) {
                throttleStatusCode = new TFOneThrottleStatusCode();
                throttleStatusCode.setThrottleStatusCode(resultSet.getString("THROTTLE_STATUS_CODE"));
                throttleStatusCode.setDescription(resultSet.getString(DESCRIPTION));
                throttleStatusCodes.add(throttleStatusCode);
            }

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return throttleStatusCodes;
    }

    @Override
    public TFOneGeneralResponse insertThrottleStatusCode(TracfoneOneThrottleStatusCode tfThrottleStatusCode, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfThrottleStatusCode.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_THROTTLE_STATUS_CODE);) {

            setThrottleStatusInsertQuery(stmt, tfThrottleStatusCode);
            stmt.executeUpdate();

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Throttle Status Code", "Inserted Throttle Status Code Object " + tfThrottleStatusCode, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfThrottleStatusCode.getThrottleStatusCode());
    }

    @Override
    public TFOneGeneralResponse updateThrottleStatusCode(TracfoneOneThrottleStatusCode tfThrottleStatusCode, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfThrottleStatusCode.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_THROTTLE_STATUS_CODE);) {

            setThrottleStatusInsertQuery(stmt, tfThrottleStatusCode);
            stmt.executeUpdate();

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Throttle Status Code", "Updated Throttle Status Code Object " + tfThrottleStatusCode, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfThrottleStatusCode.getThrottleStatusCode());
    }


    private void setThrottleStatusInsertQuery(PreparedStatement stmt, TracfoneOneThrottleStatusCode tfThrottleStatusCode) throws SQLException {
        stmt.setString(1, tfThrottleStatusCode.getDescription());
        stmt.setString(2, tfThrottleStatusCode.getThrottleStatusCode());
    }

    @Override
    public TFOneGeneralResponse insertFeatureRequirement(TracfoneOneFeatureRequirement tfFeatureRequirement, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfFeatureRequirement.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_INSERT_FEATURE_REQUIREMENT);) {

            setFeatureRequirementInsertQuery(stmt, tfFeatureRequirement);
            stmt.executeUpdate();

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Insert Feature Requirement", "Inserted Feature Requirement Object " + tfFeatureRequirement, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfFeatureRequirement.getFeatureRequirement());
    }

    @Override
    public TFOneGeneralResponse updateFeatureRequirement(TracfoneOneFeatureRequirement tfFeatureRequirement, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfFeatureRequirement.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_UPDATE_FEATURE_REQUIREMENT);) {

            setFeatureRequirementInsertQuery(stmt, tfFeatureRequirement);
            stmt.executeUpdate();

        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Update Feature Requirement", "Updated Feature Requirement Object " + tfFeatureRequirement, null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfFeatureRequirement.getFeatureRequirement());
    }

    @Override
    public List<TFOneFeatureRequirement> getAllFeatureRequirements(String dbEnv) throws TracfoneOneException {
        List<TFOneFeatureRequirement> tfOneFeatureRequirements = new ArrayList<>();
        TFOneFeatureRequirement tfOneFeatureRequirement;
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_FEATURE_REQUIREMENT);
             ResultSet resultSet = stmt.executeQuery();) {
            while (resultSet.next()) {
                tfOneFeatureRequirement = new TFOneFeatureRequirement();
                tfOneFeatureRequirement.setFeatureRequirement(resultSet.getString(FEATURE_REQUIREMENT));
                tfOneFeatureRequirement.setDescription(resultSet.getString(DESCRIPTION));
                tfOneFeatureRequirements.add(tfOneFeatureRequirement);
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return tfOneFeatureRequirements;
    }

    private void setFeatureRequirementInsertQuery(PreparedStatement stmt, TracfoneOneFeatureRequirement tfFeatureRequirement) throws SQLException {
        stmt.setString(1, tfFeatureRequirement.getDescription());
        stmt.setString(2, tfFeatureRequirement.getFeatureRequirement());
    }

    @Override
    public List<TFOneCarrier> getAllCarrierIds(String dbEnv, String carrierName, String parent) throws TracfoneOneException {
        List<TFOneCarrier> tfOneCarriers = new ArrayList<>();
        TFOneCarrier tfOneCarrier;

        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_CARRIER_IDS);) {
            stmt.setString(1, carrierName);
            stmt.setLong(2, Long.valueOf(parent));
            try (ResultSet resultSet = stmt.executeQuery();) {

                while (resultSet.next()) {
                    tfOneCarrier = new TFOneCarrier();
                    tfOneCarrier.setObjId(resultSet.getString(OBJID));
                    tfOneCarrier.setCarrierId(resultSet.getString("X_CARRIER_ID"));
                    tfOneCarrier.setSubmarketName(resultSet.getString("X_MKT_SUBMKT_NAME"));
                    tfOneCarriers.add(tfOneCarrier);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfOneCarriers;
    }

    @Override
    public TFOneGeneralResponse deleteFeatureRequirement(TracfoneOneFeatureRequirement tfOneFeatureRequirement, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneFeatureRequirement.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_DELETE_FEATURE_REQUIREMENT);) {
            stmt.setString(1, tfOneFeatureRequirement.getFeatureRequirement());
            stmt.executeQuery();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Delete Feature Requirement ", "Deleted Feature Requirement " + tfOneFeatureRequirement.getFeatureRequirement(), null);
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneFeatureRequirement.getFeatureRequirement());
    }

    @Override
    public boolean checkFeatureRequirementDependencies(TracfoneOneFeatureRequirement tfOneFeatureRequirement) throws TracfoneOneException {
        boolean dependencyExists = false;
        try (Connection con = dbControllerEJB.getDataSource(tfOneFeatureRequirement.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_COUNT_FEATURE_REQUIREMENT_DEPENDENCY);) {
            stmt.setString(1, tfOneFeatureRequirement.getFeatureRequirement());
            int count = 0;
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    count = resultSet.getInt(1);
                }
            }
            if (count > 0) {
                dependencyExists = true;
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return dependencyExists;
    }

    @Override
    public Set<String> getAllFeatureValuesByProfileId(TracfoneOneRatePlanExtensionConfig tracfoneOneRatePlanExtensionConfig) throws TracfoneOneException {
        Set<String> featureValues = new HashSet<>();
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneRatePlanExtensionConfig.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_FEATURE_VALUES_RP_EXTENSION_CONFIGS);) {
            stmt.setString(1, tracfoneOneRatePlanExtensionConfig.getProfileId());
            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    featureValues.add(resultSet.getString(FEATURE_VALUE));
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        LOGGER.info("featureValues found - " + featureValues);
        return featureValues;
    }

    @Override
    public List<TFOneRatePlanExtensionConfig> searchProfileFeatures(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) throws TracfoneOneException {
        List<TFOneRatePlanExtensionConfig> tfOneFeatures = new ArrayList<>();
        TFOneRatePlanExtensionConfig tfOneFeature;
        try (Connection con = dbControllerEJB.getDataSource(tracfoneOneSearchProfileModel.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getSearchFeaturesStatement(tracfoneOneSearchProfileModel));) {
            int index = 1;
            for (String featureValue : tracfoneOneSearchProfileModel.getFeatureValue().split(",")) {
                stmt.setString(index++, featureValue);
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getProfileId())) {
                for (String profileId : tracfoneOneSearchProfileModel.getProfileId().split(",")) {
                    stmt.setString(index++, profileId);
                }
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getFeatureName())) {
                stmt.setString(index++, tracfoneOneSearchProfileModel.getFeatureName());
            }
            if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getRatePlan())) {
                stmt.setString(index++, tracfoneOneSearchProfileModel.getRatePlan());
                stmt.setString(index++, "%" + tracfoneOneSearchProfileModel.getRatePlan().toUpperCase() + "%");
            }

            try (ResultSet resultSet = stmt.executeQuery();) {
                while (resultSet.next()) {
                    tfOneFeature = new TFOneRatePlanExtensionConfig();
                    tfOneFeature.setProfileId(resultSet.getString(PROFILE_ID));
                    tfOneFeature.setProfileDescription(resultSet.getString("PROFILE_DESC"));
                    tfOneFeature.setFeatureName(resultSet.getString(FEATURE_NAME));
                    tfOneFeature.setFeatureValue(resultSet.getString(FEATURE_VALUE));
                    tfOneFeature.setFeatureRequirement(resultSet.getString(FEATURE_REQUIREMENT));
                    tfOneFeature.setDisplaySUIFlag(resultSet.getString("DISPLAY_SUI_FLAG"));
                    tfOneFeature.setRestrictSUIFlag(resultSet.getString("RESTRICT_SUI_FLAG"));
                    tfOneFeature.setToggleFlag(resultSet.getString("TOGGLE_FLAG"));
                    tfOneFeature.setNotes(resultSet.getString("NOTES"));
                    tfOneFeature.setObjid(resultSet.getString(OBJID));
                    tfOneFeatures.add(tfOneFeature);
                }
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }

        return tfOneFeatures;
    }

    @Override
    public List<String> getAllFeatureValues(String dbEnv) throws TracfoneOneException {
        List<String> featureValues = new ArrayList<>();
        try (Connection con = dbControllerEJB.getDataSource(dbEnv).getConnection();
             PreparedStatement stmt = con.prepareStatement(TRACFONE_GET_ALL_FEATURE_VALUES);
             ResultSet resultSet = stmt.executeQuery();) {
            while (resultSet.next()) {
                featureValues.add(resultSet.getString(FEATURE_VALUE));
            }
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return featureValues;
    }

    @Override
    public TFOneGeneralResponse bulkUpdateProfileFeatures(TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig, int userId) throws TracfoneOneException {
        try (Connection con = dbControllerEJB.getDataSource(tfOneRpExtensionConfig.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getUpdateQuery(tfOneRpExtensionConfig));) {
            int index = 1;
            if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getFeatureName())) {
                stmt.setString(index++, tfOneRpExtensionConfig.getFeatureName());
            }
            if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getFeatureValue())) {
                stmt.setString(index++, tfOneRpExtensionConfig.getFeatureValue());
            }
            if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getToggleFlag())) {
                stmt.setString(index++, tfOneRpExtensionConfig.getToggleFlag());
            }
            if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getNotes())) {
                stmt.setString(index++, tfOneRpExtensionConfig.getNotes());
            }
            if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getDisplaySUIFlag())) {
                stmt.setString(index++, tfOneRpExtensionConfig.getDisplaySUIFlag());
            }
            if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getRestrictSUIFlag())) {
                stmt.setString(index++, tfOneRpExtensionConfig.getRestrictSUIFlag());
            }
            if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getFeatureRequirement())) {
                stmt.setString(index++, tfOneRpExtensionConfig.getFeatureRequirement());
            }
            for (String fieldValue : tfOneRpExtensionConfig.getObjid().split(",")) {
                stmt.setString(index++, fieldValue);
            }
            stmt.executeUpdate();
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        } finally {
            TracfoneAudit audit = new TracfoneAudit(userId, "Bulk Update Profile Features", "Update Profile Features" + tfOneRpExtensionConfig, "");
            tracfoneAuditEvent.fire(audit);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, tfOneRpExtensionConfig.getObjid());
    }

    private String getSearchFeaturesStatement(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(buildInClause(TRACFONE_SEARCH_RP_EXTENSION_CONFIG,
                tracfoneOneSearchProfileModel.getFeatureValue().split(",").length));
        builder.append(AND);
        if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getProfileId())) {
            builder.append("c.PROFILE_ID in (?").append(buildInClause("",
                    tracfoneOneSearchProfileModel.getProfileId().split(",").length));
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getFeatureName())) {
            builder.append("c.FEATURE_NAME = ?");
            builder.append(AND);
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOneSearchProfileModel.getRatePlan())) {
            builder.append("((c.PROFILE_ID in (select PROFILE_ID from sa.X_RP_EXTENSION_CONFIG where FEATURE_VALUE = ? and UPPER(FEATURE_NAME) = 'RATE_PLAN')) ");
            builder.append("OR (UPPER(p.profile_desc) like ?))");
            builder.append(AND);
        }
        if (builder.lastIndexOf(AND) != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(AND)).concat(" order by c.PROFILE_ID");
        }
        LOGGER.info("This is the search query for profile feature search " + searchQuery);
        return searchQuery;
    }

    private String getUpdateQuery(TracfoneOneRatePlanExtensionConfig tfOneRpExtensionConfig) {
        String searchQuery = "";
        StringBuilder builder = new StringBuilder(TRACFONE_BULK_UPDATE_RP_EXTENSION_CONFIG);
        if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getFeatureName())) {
            builder.append("FEATURE_NAME = ?,");
        }
        if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getFeatureValue())) {
            builder.append("FEATURE_VALUE = ?,");
        }
        if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getToggleFlag())) {
            builder.append("TOGGLE_FLAG = ?,");
        }
        if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getNotes())) {
            builder.append("NOTES = ?,");
        }
        if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getDisplaySUIFlag())) {
            builder.append("DISPLAY_SUI_FLAG = ?,");
        }
        if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getRestrictSUIFlag())) {
            builder.append("RESTRICT_SUI_FLAG = ?,");
        }
        if (!StringUtils.isNullOrEmpty(tfOneRpExtensionConfig.getFeatureRequirement())) {
            builder.append("FEATURE_REQUIREMENT = ?,");
        }
        if (builder.lastIndexOf(",") != -1) {
            searchQuery = builder.substring(0, builder.lastIndexOf(",")).
                    concat(" where OBJID in (?" + buildInClause("", tfOneRpExtensionConfig.getObjid().split(",").length));
        }
        LOGGER.info(searchQuery);
        return searchQuery;
    }

}
