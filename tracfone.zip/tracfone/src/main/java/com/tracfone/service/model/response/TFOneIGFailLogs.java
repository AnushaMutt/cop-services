package com.tracfone.service.model.response;

/**
 *
 * @author Gaurav.Sharma
 */
public class TFOneIGFailLogs {

    private String callTransActionType;
    private String actionItemId;
    private String carrierId;
    private String orderType;
    private String min;
    private String esn;
    private String esnPartClassModel;
    private String esnHex;
    private String oldEsn;
    private String oldEsnHex;
    private String pin;
    private String phoneManf;
    private String endUser;
    private String accountNum;
    private String marketCode;
    private String ratePlan;
    private String ldProvider;
    private String sequenceNum;
    private String dealerCode;
    private String transmissionMethod;
    private String faxNum;
    private String onlineNum;
    private String email;
    private String networkLogin;
    private String networkPassword;
    private String systemLogin;
    private String systemPassword;
    private String template;
    private String exeName;
    private String comPort;
    private String status;
    private String statusMessage;
    private String faxBatchSize;
    private String faxBatchQtime;
    private String expidite;
    private String transProfKey;
    private String qTransaction;
    private String onlineNum2;
    private String faxNum2;
    private String creationDate;
    private String updateDate;
    private String igDbSecsToComp;
    private String blackoutWait;
    private String tuxItiServer;
    private String transactionId;
    private String technologyFlag;
    private String voiceMail;
    private String voiceMailPackage;
    private String callerId;
    private String carrierAccountId;
    private String tmoNextGenFlag;
    private String callerIdPackage;
    private String callWaiting;
    private String callWaitingPackage;
    private String rtpServer;
    private String digitalFeatureCode;
    private String stateField;
    private String zipCode;
    private String msid;
    private String newMsidFlag;
    private String sms;
    private String smsPackage;
    private String iccid;
    private String oldMin;
    private String digitalFeature;
    private String otaType;
    private String rateCenterNo;
    private String applicationSystem;
    private String subscriberUpdate;
    private String downloadDate;
    private String amount;
    private String balance;
    private String language;
    private String expDate;
    private String xMpn;
    private String xMpnCode;
    private String xPoolName;
    private String xMake;
    private String xModel;
    private String xMode;
    private String carrierInitialTransTime;
    private String carrierEndTransTime;
    private String loggedDate;
    private String loggedBy;
    private String prlNumber;

    public String getCallTransActionType() {
        return callTransActionType;
    }

    public void setCallTransActionType(String callTransActionType) {
        this.callTransActionType = callTransActionType;
    }

    public String getActionItemId() {
        return actionItemId;
    }

    public void setActionItemId(String actionItemId) {
        this.actionItemId = actionItemId;
    }

    public String getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(String carrierId) {
        this.carrierId = carrierId;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getEsn() {
        return esn;
    }

    public void setEsn(String esn) {
        this.esn = esn;
    }

    public String getEsnPartClassModel() {
        return esnPartClassModel;
    }

    public void setEsnPartClassModel(String esnPartClassModel) {
        this.esnPartClassModel = esnPartClassModel;
    }

    public String getEsnHex() {
        return esnHex;
    }

    public void setEsnHex(String esnHex) {
        this.esnHex = esnHex;
    }

    public String getOldEsn() {
        return oldEsn;
    }

    public void setOldEsn(String oldEsn) {
        this.oldEsn = oldEsn;
    }

    public String getOldEsnHex() {
        return oldEsnHex;
    }

    public void setOldEsnHex(String oldEsnHex) {
        this.oldEsnHex = oldEsnHex;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getPhoneManf() {
        return phoneManf;
    }

    public void setPhoneManf(String phoneManf) {
        this.phoneManf = phoneManf;
    }

    public String getEndUser() {
        return endUser;
    }

    public void setEndUser(String endUser) {
        this.endUser = endUser;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getMarketCode() {
        return marketCode;
    }

    public void setMarketCode(String marketCode) {
        this.marketCode = marketCode;
    }

    public String getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(String ratePlan) {
        this.ratePlan = ratePlan;
    }

    public String getLdProvider() {
        return ldProvider;
    }

    public void setLdProvider(String ldProvider) {
        this.ldProvider = ldProvider;
    }

    public String getSequenceNum() {
        return sequenceNum;
    }

    public void setSequenceNum(String sequenceNum) {
        this.sequenceNum = sequenceNum;
    }

    public String getDealerCode() {
        return dealerCode;
    }

    public void setDealerCode(String dealerCode) {
        this.dealerCode = dealerCode;
    }

    public String getTransmissionMethod() {
        return transmissionMethod;
    }

    public void setTransmissionMethod(String transmissionMethod) {
        this.transmissionMethod = transmissionMethod;
    }

    public String getFaxNum() {
        return faxNum;
    }

    public void setFaxNum(String faxNum) {
        this.faxNum = faxNum;
    }

    public String getOnlineNum() {
        return onlineNum;
    }

    public void setOnlineNum(String onlineNum) {
        this.onlineNum = onlineNum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNetworkLogin() {
        return networkLogin;
    }

    public void setNetworkLogin(String networkLogin) {
        this.networkLogin = networkLogin;
    }

    public String getNetworkPassword() {
        return networkPassword;
    }

    public void setNetworkPassword(String networkPassword) {
        this.networkPassword = networkPassword;
    }

    public String getSystemLogin() {
        return systemLogin;
    }

    public void setSystemLogin(String systemLogin) {
        this.systemLogin = systemLogin;
    }

    public String getSystemPassword() {
        return systemPassword;
    }

    public void setSystemPassword(String systemPassword) {
        this.systemPassword = systemPassword;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getExeName() {
        return exeName;
    }

    public void setExeName(String exeName) {
        this.exeName = exeName;
    }

    public String getComPort() {
        return comPort;
    }

    public void setComPort(String comPort) {
        this.comPort = comPort;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getFaxBatchSize() {
        return faxBatchSize;
    }

    public void setFaxBatchSize(String faxBatchSize) {
        this.faxBatchSize = faxBatchSize;
    }

    public String getFaxBatchQtime() {
        return faxBatchQtime;
    }

    public void setFaxBatchQtime(String faxBatchQtime) {
        this.faxBatchQtime = faxBatchQtime;
    }

    public String getExpidite() {
        return expidite;
    }

    public void setExpidite(String expidite) {
        this.expidite = expidite;
    }

    public String getTransProfKey() {
        return transProfKey;
    }

    public void setTransProfKey(String transProfKey) {
        this.transProfKey = transProfKey;
    }

    public String getqTransaction() {
        return qTransaction;
    }

    public void setqTransaction(String qTransaction) {
        this.qTransaction = qTransaction;
    }

    public String getOnlineNum2() {
        return onlineNum2;
    }

    public void setOnlineNum2(String onlineNum2) {
        this.onlineNum2 = onlineNum2;
    }

    public String getFaxNum2() {
        return faxNum2;
    }

    public void setFaxNum2(String faxNum2) {
        this.faxNum2 = faxNum2;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getIgDbSecsToComp() {
        return igDbSecsToComp;
    }

    public void setIgDbSecsToComp(String igDbSecsToComp) {
        this.igDbSecsToComp = igDbSecsToComp;
    }

    public String getBlackoutWait() {
        return blackoutWait;
    }

    public void setBlackoutWait(String blackoutWait) {
        this.blackoutWait = blackoutWait;
    }

    public String getTuxItiServer() {
        return tuxItiServer;
    }

    public void setTuxItiServer(String tuxItiServer) {
        this.tuxItiServer = tuxItiServer;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getTechnologyFlag() {
        return technologyFlag;
    }

    public void setTechnologyFlag(String technologyFlag) {
        this.technologyFlag = technologyFlag;
    }

    public String getVoiceMail() {
        return voiceMail;
    }

    public void setVoiceMail(String voiceMail) {
        this.voiceMail = voiceMail;
    }

    public String getVoiceMailPackage() {
        return voiceMailPackage;
    }

    public void setVoiceMailPackage(String voiceMailPackage) {
        this.voiceMailPackage = voiceMailPackage;
    }

    public String getCallerId() {
        return callerId;
    }

    public void setCallerId(String callerId) {
        this.callerId = callerId;
    }

    public String getCarrierAccountId() {
        return carrierAccountId;
    }

    public void setCarrierAccountId(String carrierAccountId) {
        this.carrierAccountId = carrierAccountId;
    }

    public String getTmoNextGenFlag() {
        return tmoNextGenFlag;
    }

    public void setTmoNextGenFlag(String tmoNextGenFlag) {
        this.tmoNextGenFlag = tmoNextGenFlag;
    }

    public String getCallerIdPackage() {
        return callerIdPackage;
    }

    public void setCallerIdPackage(String callerIdPackage) {
        this.callerIdPackage = callerIdPackage;
    }

    public String getCallWaiting() {
        return callWaiting;
    }

    public void setCallWaiting(String callWaiting) {
        this.callWaiting = callWaiting;
    }

    public String getCallWaitingPackage() {
        return callWaitingPackage;
    }

    public void setCallWaitingPackage(String callWaitingPackage) {
        this.callWaitingPackage = callWaitingPackage;
    }

    public String getRtpServer() {
        return rtpServer;
    }

    public void setRtpServer(String rtpServer) {
        this.rtpServer = rtpServer;
    }

    public String getDigitalFeatureCode() {
        return digitalFeatureCode;
    }

    public void setDigitalFeatureCode(String digitalFeatureCode) {
        this.digitalFeatureCode = digitalFeatureCode;
    }

    public String getStateField() {
        return stateField;
    }

    public void setStateField(String stateField) {
        this.stateField = stateField;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getMsid() {
        return msid;
    }

    public void setMsid(String msid) {
        this.msid = msid;
    }

    public String getNewMsidFlag() {
        return newMsidFlag;
    }

    public void setNewMsidFlag(String newMsidFlag) {
        this.newMsidFlag = newMsidFlag;
    }

    public String getSms() {
        return sms;
    }

    public void setSms(String sms) {
        this.sms = sms;
    }

    public String getSmsPackage() {
        return smsPackage;
    }

    public void setSmsPackage(String smsPackage) {
        this.smsPackage = smsPackage;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getOldMin() {
        return oldMin;
    }

    public void setOldMin(String oldMin) {
        this.oldMin = oldMin;
    }

    public String getDigitalFeature() {
        return digitalFeature;
    }

    public void setDigitalFeature(String digitalFeature) {
        this.digitalFeature = digitalFeature;
    }

    public String getOtaType() {
        return otaType;
    }

    public void setOtaType(String otaType) {
        this.otaType = otaType;
    }

    public String getRateCenterNo() {
        return rateCenterNo;
    }

    public void setRateCenterNo(String rateCenterNo) {
        this.rateCenterNo = rateCenterNo;
    }

    public String getApplicationSystem() {
        return applicationSystem;
    }

    public void setApplicationSystem(String applicationSystem) {
        this.applicationSystem = applicationSystem;
    }

    public String getSubscriberUpdate() {
        return subscriberUpdate;
    }

    public void setSubscriberUpdate(String subscriberUpdate) {
        this.subscriberUpdate = subscriberUpdate;
    }

    public String getDownloadDate() {
        return downloadDate;
    }

    public void setDownloadDate(String downloadDate) {
        this.downloadDate = downloadDate;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getExpDate() {
        return expDate;
    }

    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }

    public String getxMpn() {
        return xMpn;
    }

    public void setxMpn(String xMpn) {
        this.xMpn = xMpn;
    }

    public String getxMpnCode() {
        return xMpnCode;
    }

    public void setxMpnCode(String xMpnCode) {
        this.xMpnCode = xMpnCode;
    }

    public String getxPoolName() {
        return xPoolName;
    }

    public void setxPoolName(String xPoolName) {
        this.xPoolName = xPoolName;
    }

    public String getxMake() {
        return xMake;
    }

    public void setxMake(String xMake) {
        this.xMake = xMake;
    }

    public String getxModel() {
        return xModel;
    }

    public void setxModel(String xModel) {
        this.xModel = xModel;
    }

    public String getxMode() {
        return xMode;
    }

    public void setxMode(String xMode) {
        this.xMode = xMode;
    }

    public String getCarrierInitialTransTime() {
        return carrierInitialTransTime;
    }

    public void setCarrierInitialTransTime(String carrierInitialTransTime) {
        this.carrierInitialTransTime = carrierInitialTransTime;
    }

    public String getCarrierEndTransTime() {
        return carrierEndTransTime;
    }

    public void setCarrierEndTransTime(String carrierEndTransTime) {
        this.carrierEndTransTime = carrierEndTransTime;
    }

    public String getLoggedDate() {
        return loggedDate;
    }

    public void setLoggedDate(String loggedDate) {
        this.loggedDate = loggedDate;
    }

    public String getLoggedBy() {
        return loggedBy;
    }

    public void setLoggedBy(String loggedBy) {
        this.loggedBy = loggedBy;
    }

    public String getPrlNumber() {
        return prlNumber;
    }

    public void setPrlNumber(String prlNumber) {
        this.prlNumber = prlNumber;
    }

    @Override
    public String toString() {
        return "TFOneIGFailLogs{" +
                "callTransActionType='" + callTransActionType + '\'' +
                ", actionItemId='" + actionItemId + '\'' +
                ", carrierId='" + carrierId + '\'' +
                ", orderType='" + orderType + '\'' +
                ", min='" + min + '\'' +
                ", esn='" + esn + '\'' +
                ", esnPartClassModel='" + esnPartClassModel + '\'' +
                ", esnHex='" + esnHex + '\'' +
                ", oldEsn='" + oldEsn + '\'' +
                ", oldEsnHex='" + oldEsnHex + '\'' +
                ", pin='" + pin + '\'' +
                ", phoneManf='" + phoneManf + '\'' +
                ", endUser='" + endUser + '\'' +
                ", accountNum='" + accountNum + '\'' +
                ", marketCode='" + marketCode + '\'' +
                ", ratePlan='" + ratePlan + '\'' +
                ", ldProvider='" + ldProvider + '\'' +
                ", sequenceNum='" + sequenceNum + '\'' +
                ", dealerCode='" + dealerCode + '\'' +
                ", transmissionMethod='" + transmissionMethod + '\'' +
                ", faxNum='" + faxNum + '\'' +
                ", onlineNum='" + onlineNum + '\'' +
                ", email='" + email + '\'' +
                ", networkLogin='" + networkLogin + '\'' +
                ", networkPassword='" + networkPassword + '\'' +
                ", systemLogin='" + systemLogin + '\'' +
                ", systemPassword='" + systemPassword + '\'' +
                ", template='" + template + '\'' +
                ", exeName='" + exeName + '\'' +
                ", comPort='" + comPort + '\'' +
                ", status='" + status + '\'' +
                ", statusMessage='" + statusMessage + '\'' +
                ", faxBatchSize='" + faxBatchSize + '\'' +
                ", faxBatchQtime='" + faxBatchQtime + '\'' +
                ", expidite='" + expidite + '\'' +
                ", transProfKey='" + transProfKey + '\'' +
                ", qTransaction='" + qTransaction + '\'' +
                ", onlineNum2='" + onlineNum2 + '\'' +
                ", faxNum2='" + faxNum2 + '\'' +
                ", creationDate='" + creationDate + '\'' +
                ", updateDate='" + updateDate + '\'' +
                ", igDbSecsToComp='" + igDbSecsToComp + '\'' +
                ", blackoutWait='" + blackoutWait + '\'' +
                ", tuxItiServer='" + tuxItiServer + '\'' +
                ", transactionId='" + transactionId + '\'' +
                ", technologyFlag='" + technologyFlag + '\'' +
                ", voiceMail='" + voiceMail + '\'' +
                ", voiceMailPackage='" + voiceMailPackage + '\'' +
                ", callerId='" + callerId + '\'' +
                ", carrierAccountId='" + carrierAccountId + '\'' +
                ", tmoNextGenFlag='" + tmoNextGenFlag + '\'' +
                ", callerIdPackage='" + callerIdPackage + '\'' +
                ", callWaiting='" + callWaiting + '\'' +
                ", callWaitingPackage='" + callWaitingPackage + '\'' +
                ", rtpServer='" + rtpServer + '\'' +
                ", digitalFeatureCode='" + digitalFeatureCode + '\'' +
                ", stateField='" + stateField + '\'' +
                ", zipCode='" + zipCode + '\'' +
                ", msid='" + msid + '\'' +
                ", newMsidFlag='" + newMsidFlag + '\'' +
                ", sms='" + sms + '\'' +
                ", smsPackage='" + smsPackage + '\'' +
                ", iccid='" + iccid + '\'' +
                ", oldMin='" + oldMin + '\'' +
                ", digitalFeature='" + digitalFeature + '\'' +
                ", otaType='" + otaType + '\'' +
                ", rateCenterNo='" + rateCenterNo + '\'' +
                ", applicationSystem='" + applicationSystem + '\'' +
                ", subscriberUpdate='" + subscriberUpdate + '\'' +
                ", downloadDate='" + downloadDate + '\'' +
                ", amount='" + amount + '\'' +
                ", balance='" + balance + '\'' +
                ", language='" + language + '\'' +
                ", expDate='" + expDate + '\'' +
                ", xMpn='" + xMpn + '\'' +
                ", xMpnCode='" + xMpnCode + '\'' +
                ", xPoolName='" + xPoolName + '\'' +
                ", xMake='" + xMake + '\'' +
                ", xModel='" + xModel + '\'' +
                ", xMode='" + xMode + '\'' +
                ", carrierInitialTransTime='" + carrierInitialTransTime + '\'' +
                ", carrierEndTransTime='" + carrierEndTransTime + '\'' +
                ", loggedDate='" + loggedDate + '\'' +
                ", loggedBy='" + loggedBy + '\'' +
                ", prlNumber='" + prlNumber + '\'' +
                '}';
    }
}
