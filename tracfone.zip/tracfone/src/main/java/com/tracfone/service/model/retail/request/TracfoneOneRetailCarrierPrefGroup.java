package com.tracfone.service.model.retail.request;

public class TracfoneOneRetailCarrierPrefGroup {

    private String objId;
    private String description;
    private String brand;
    private String status;
    private String insertDate;
    private String updateDate;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(String insertDate) {
        this.insertDate = insertDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    @Override
    public String toString() {
        return "TracfoneOneRetailCarrierPrefGroup{" +
                "objId='" + objId + '\'' +
                ", description='" + description + '\'' +
                ", brand='" + brand + '\'' +
                ", status='" + status + '\'' +
                ", insertDate='" + insertDate + '\'' +
                ", updateDate='" + updateDate + '\'' +
                '}';
    }
}
