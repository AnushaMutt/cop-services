package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneCarrierOutage;
import com.tracfone.service.model.request.TracfoneOneServiceType;
import com.tracfone.service.model.response.TFOneCarrierOutage;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneServiceType;

import javax.ejb.Local;
import java.util.List;

@Local
public interface TracfoneOneCarrierOutageControllerLocal {

    List<TFOneCarrierOutage> searchCarrierOutage(TracfoneOneCarrierOutage tracfoneOneCarrierOutage) throws TracfoneOneException;

    TFOneGeneralResponse insertCarrierOutage(TracfoneOneCarrierOutage tracfoneOneCarrierOutage, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrierOutage(TracfoneOneCarrierOutage tracfoneOneCarrierOutage, int userId) throws TracfoneOneException;

    TFOneGeneralResponse bulkUpdateOutages(TracfoneOneCarrierOutage tracfoneOneCarrierOutage, int userId) throws TracfoneOneException;

    List<TFOneServiceType> viewAllServiceTypes(TracfoneOneServiceType tracfoneOneServiceType) throws TracfoneOneException;

    TFOneGeneralResponse insertServiceType(TracfoneOneServiceType tracfoneOneServiceType, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateServiceType(TracfoneOneServiceType tracfoneOneServiceType, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteServiceType(TracfoneOneServiceType tracfoneOneServiceType, int userId) throws TracfoneOneException;
}
