package com.tracfone.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.ejb.entity.session.TFOneReportFacadeLocal;
import com.tracfone.service.controller.TracfoneControllerLocal;
import com.tracfone.service.controller.TracfoneControllerReportLocal;
import com.tracfone.service.exception.CopUIErrorResponse;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.filter.Authorized;
import com.tracfone.service.filter.Secured;
import com.tracfone.service.model.report.TracfoneAdhocReportRequest;
import com.tracfone.service.model.response.TracfoneOneReport;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.UriInfo;

/**
 * REST Web Service
 *
 * @author spulavarthy
 */
@Path("reports")
public class TracfoneOneReportingResource implements TracfoneOneConstantReport {

    @Context
    private UriInfo context;

    @EJB
    private TracfoneControllerLocal tracfoneController;

    @EJB
    private TracfoneControllerReportLocal tracfoneControllerReport;

    @EJB
    TFOneReportFacadeLocal reportIgErrorEJB;

    @Context
    private SecurityContext securityContext;

    private static Logger logger = LogManager.getLogger(TracfoneOneReportingResource.class);

    private Gson gson = new GsonBuilder().serializeNulls().create();

    @GET
    @Path("allfailures/{flag}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getAllFailuresForIG(@PathParam("flag") boolean flag) {
        String jsonResponse = null;
        try {
            jsonResponse = tracfoneController.getAllFailures(TRACFONE_REPORTNAME_ALLFAILURES, flag);
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }

        return Response.ok(jsonResponse, MediaType.APPLICATION_JSON).build();
    }

    @GET
    @Path("monitor/{transactiontype}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response storeMonitorReportGET(@PathParam("transactiontype") String transactionType) {
        String jsonResponse = null;
        try {
            if (TRACFONE_TRANSACTIONTYPE_TT.equalsIgnoreCase(transactionType)) {
                jsonResponse = tracfoneController.getMonitorReport(TRACFONE_REPORTNAME_TT_MONITOR, REPORT_SQL_TT_MONITOR);
            } else if (TRACFONE_TRANSACTIONTYPE_PCRF.equalsIgnoreCase(transactionType)) {
                jsonResponse = tracfoneController.getMonitorReport(TRACFONE_REPORTNAME_PCRF_MONITOR, REPORT_SQL_PCRF_MONITOR);
            } else {
                jsonResponse = tracfoneController.getMonitorReport(TRACFONE_REPORTNAME_MONITOR, REPORT_SQL_MONITOR);
            }
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }

        return Response.ok(jsonResponse, MediaType.APPLICATION_JSON).build();
    }

    @GET
    @Path("monitorgraph/{transactiontype}")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response getMonitorGraphReport(@PathParam("transactiontype") String transactionType) {
        String jsonResponse = null;
        try {
            if (TRACFONE_TRANSACTIONTYPE_TT.equalsIgnoreCase(transactionType)) {
                jsonResponse = tracfoneController.getMonitorGraphReport(TRACFONE_REPORTNAME_TT_MONITOR_GRAPH, REPORT_SQL_TT_MONITOR_GRAPH_VIEW);
            } else if (TRACFONE_TRANSACTIONTYPE_PCRF.equalsIgnoreCase(transactionType)) {
                jsonResponse = tracfoneController.getMonitorGraphReport(TRACFONE_REPORTNAME_PCRF_MONITOR_GRAPH, REPORT_SQL_PCRF_MONITOR_GRAPH_VIEW);
            } else {
                jsonResponse = tracfoneController.getMonitorGraphReport(TRACFONE_REPORTNAME_MONITOR_GRAPH, REPORT_SQL_MONITOR_GRAPH_VIEW);
            }
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }

        return Response.ok(jsonResponse, MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("monitoradhoc")
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    @Authorized
    public Response adhocMonitorReport(final TracfoneAdhocReportRequest adhocReportRequest) {
        Response response = null;
        TracfoneOneReport tracfoneOneReport = null;

        try {
            if (TRACFONE_TRANSACTIONTYPE_TT.equalsIgnoreCase(adhocReportRequest.getTransactionType())) {
                tracfoneOneReport = tracfoneControllerReport.runAdhocTTMonitorReport(adhocReportRequest);
            } else if (TRACFONE_TRANSACTIONTYPE_PCRF.equalsIgnoreCase(adhocReportRequest.getTransactionType())) {
                tracfoneOneReport = tracfoneControllerReport.runAdhocPCRFMonitorReport(adhocReportRequest);
            } else {
                tracfoneOneReport = tracfoneControllerReport.runAdhocMonitorReport(adhocReportRequest);
            }
            response = Response.ok(gson.toJson(tracfoneOneReport), MediaType.APPLICATION_JSON).build();
        } catch (TracfoneOneException tfoEx) {
            logger.error(tfoEx.getMessage(), tfoEx);
            int httpResponseCode = Response.Status.BAD_REQUEST.getStatusCode();
            return Response.status(Response.Status.OK).entity(gson.toJson(new CopUIErrorResponse(tfoEx, httpResponseCode))).build();
        }
        return response;
    }

}
