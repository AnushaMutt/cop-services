/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Shireen Fathima
 */
public class TracfoneOneSearchCarrierFeatureModel {

    private String dbEnv;
    private String carrierName;
    private String servicePlanId;
    private String profileId;
    private String profileDesc;
    private String bucketId;
    private String bucketRequirement;
    private List<String> orderBy;
    private boolean legacy;
    private TracfoneOneCarrierFeature tracfoneOneCarrierFeature;

    public TracfoneOneSearchCarrierFeatureModel() {
        this.orderBy = new ArrayList<>();
        this.tracfoneOneCarrierFeature = new TracfoneOneCarrierFeature();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getProfileDesc() {
        return profileDesc;
    }

    public void setProfileDesc(String profileDesc) {
        this.profileDesc = profileDesc;
    }

    public String getBucketId() {
        return bucketId;
    }

    public void setBucketId(String bucketId) {
        this.bucketId = bucketId;
    }

    public String getBucketRequirement() {
        return bucketRequirement;
    }

    public void setBucketRequirement(String bucketRequirement) {
        this.bucketRequirement = bucketRequirement;
    }

    public List<String> getOrderBy() { return orderBy; }

    public void setOrderBy(List<String> orderBy) { this.orderBy = orderBy; }

    public boolean isLegacy() { return legacy; }

    public void setLegacy(boolean legacy) { this.legacy = legacy; }

    public TracfoneOneCarrierFeature getTracfoneOneCarrierFeature() {
        return tracfoneOneCarrierFeature;
    }

    public void setTracfoneOneCarrierFeature(TracfoneOneCarrierFeature tracfoneOneCarrierFeature) { this.tracfoneOneCarrierFeature = tracfoneOneCarrierFeature; }

    @Override
    public String toString() {
        return "TracfoneOneSearchCarrierFeatureModel{" +
                "dbEnv='" + dbEnv + '\'' +
                ", carrierName='" + carrierName + '\'' +
                ", servicePlanId='" + servicePlanId + '\'' +
                ", profileId='" + profileId + '\'' +
                ", profileDesc='" + profileDesc + '\'' +
                ", bucketId='" + bucketId + '\'' +
                ", bucketRequirement='" + bucketRequirement + '\'' +
                ", orderBy=" + orderBy +
                ", legacy=" + legacy +
                ", tracfoneOneCarrierFeature=" + tracfoneOneCarrierFeature +
                '}';
    }
}
