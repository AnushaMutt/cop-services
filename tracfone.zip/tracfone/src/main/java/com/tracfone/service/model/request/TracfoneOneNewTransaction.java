/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.request;

import com.tracfone.service.model.response.TFOneActionItemBucket;
import com.tracfone.service.model.response.TFOneFeatures;
import java.util.List;

/**
 *
 * @author druiz
 */
public class TracfoneOneNewTransaction {

    private List<TFOneActionItemBucket> Buckets;
    private List<TFOneFeatures> features;

    private String appSys;
    private Integer ratePlanProfileId;
    private Integer carrFeat;
    private String template;
    private String actionItemId;
    private String carrierId;
    private String orderType;
    private String esn;
    private String esnHex;
    private String iccid;
    private String min;
    private String msid;
    private String ratePlan;
    private String networkLogin;
    private String networkPassword;
    private String accountNum;
    private String dealerCode;
    private String marketCode;
    private String comPort;
    private String rateCenterNo;
    private String zipCode;
    private String status;
    private String qTransaction;
    private String ldProvider;
    private String techFlag;
    private String transMethod;
    private String balance;
    private String oldMin;
    private String digitalFeature;
    private String digitalFeatureCode;
    private String voiceMail;
    private String voiceMailPackage;
    private String callerId;
    private String callerIdPackage;
    private String callWaiting;
    private String callWaitingPackage;
    private String sms;
    private String smsPackage;
    private String mpn;
    private String mpnCode;
    private String ipPool;
    private String language;
    private String dataSaver;
    private String dataSaverCode;
    private String phoneManf;
    private String rechargeDate;
    private String expireDate;
    private String downloadDt;
    private String expDt;
    private String firstName;
    private String lastName;
    private String middleInitial;
    private String suffix;
    private String prefix;
    private String ssnLast4;
    private String ospAccount;
    private String currAddrHouseNumber;
    private String currAddrDirection;
    private String currAddrStreetName;
    private String currAddrStreetType;
    private String currAddrUnit;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String country;
    private String zipCode1;
    private String prlNumber;
    private String make;
    private String model;
    private String dbenv;
    private String transactionId;
    private String creationDate;

    //Additional Fields.
    private String oldEsn;
    private String oldEsnHex;
    private String subscriberUpdate;
    private String systemLogin;
    private String systemPassword;
    private String imsi;
    private String newImsiFlag;
    private String pin;
    private String cfExtensionCount;
    private String cfProfileId;
    private String xCampaignName;
    private String amount;
    private String faxBatchSize;
    private String faxNum2;
    private String faxNum;
    private String faxBatchQtime;
    private String onlineNum;
    private String onlineNum2;
    private String email;
    private String sequenceNum;
    private String otaType;
    private String rtpServer;
    private String stateField;
    private String exeName;
    private String expidite;
    private String blackoutWait;
    private String tuxItiServer;
    private String transProfKey;
    private String ratePlanExtensionConfig;
    private Integer ratePlanExtensionObjId;
    private Integer carrierAccountId;
    private Integer servicePlanId;

    // missing fields added
    private String tmoNextGenFlag;
    private String rpExtObjid;
    private String xMode;
    private String endUser;
    private String newMsidFlag;
    private boolean testEnv;
    private String esnType;
    private String eSimFlag;

    public TracfoneOneNewTransaction() {
        this.Buckets = null;
        this.appSys = null;
        this.ratePlanProfileId = null;
        this.carrFeat = null;
        this.template = null;
        this.actionItemId = null;
        this.carrierId = null;
        this.orderType = null;
        this.esn = null;
        this.esnHex = null;
        this.iccid = null;
        this.min = null;
        this.msid = null;
        this.ratePlan = null;
        this.networkLogin = null;
        this.networkPassword = null;
        this.accountNum = null;
        this.dealerCode = null;
        this.marketCode = null;
        this.comPort = null;
        this.rateCenterNo = null;
        this.zipCode = null;
        this.status = null;
        this.qTransaction = null;
        this.ldProvider = null;
        this.techFlag = null;
        this.transMethod = null;
        this.balance = null;
        this.oldMin = null;
        this.digitalFeature = null;
        this.digitalFeatureCode = null;
        this.voiceMail = null;
        this.voiceMailPackage = null;
        this.callerId = null;
        this.callerIdPackage = null;
        this.callWaiting = null;
        this.callWaitingPackage = null;
        this.sms = null;
        this.smsPackage = null;
        this.mpn = null;
        this.mpnCode = null;
        this.ipPool = null;
        this.language = null;
        this.dataSaver = null;
        this.dataSaverCode = null;
        this.phoneManf = null;
        this.rechargeDate = null;
        this.expireDate = null;
        this.downloadDt = null;
        this.expDt = null;
        this.firstName = null;
        this.lastName = null;
        this.address1 = null;
        this.address2 = null;
        this.city = null;
        this.state = null;
        this.zipCode1 = null;
        this.prlNumber = null;
        this.make = null;
        this.model = null;
        this.dbenv = null;
        this.carrierAccountId = null;
        this.servicePlanId = null;
        this.tmoNextGenFlag = null;
        this.rpExtObjid = null;
        this.xMode = null;
        this.endUser = null;
        this.newMsidFlag = null;
    }

    public String getAppSys() {
        return appSys;
    }

    public void setAppSys(String appSys) {
        this.appSys = appSys;
    }

    public Integer getRatePlanProfileId() {
        return ratePlanProfileId;
    }

    public void setRatePlanProfileId(Integer ratePlanProfileId) {
        this.ratePlanProfileId = ratePlanProfileId;
    }

    public Integer getCarrFeat() {
        return carrFeat;
    }

    public void setCarrFeat(Integer carrFeat) {
        this.carrFeat = carrFeat;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getActionItemId() {
        return actionItemId;
    }

    public void setActionItemId(String actionItemId) {
        this.actionItemId = actionItemId;
    }

    public String getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(String carrierId) {
        this.carrierId = carrierId;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getEsn() {
        return esn;
    }

    public void setEsn(String esn) {
        this.esn = esn;
    }

    public String getEsnHex() {
        return esnHex;
    }

    public void setEsnHex(String esnHex) {
        this.esnHex = esnHex;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getMsid() {
        return msid;
    }

    public void setMsid(String msid) {
        this.msid = msid;
    }

    public String getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(String ratePlan) {
        this.ratePlan = ratePlan;
    }

    public String getNetworkLogin() {
        return networkLogin;
    }

    public void setNetworkLogin(String networkLogin) {
        this.networkLogin = networkLogin;
    }

    public String getNetworkPassword() {
        return networkPassword;
    }

    public void setNetworkPassword(String networkPassword) {
        this.networkPassword = networkPassword;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getDealerCode() {
        return dealerCode;
    }

    public void setDealerCode(String dealerCode) {
        this.dealerCode = dealerCode;
    }

    public String getMarketCode() {
        return marketCode;
    }

    public void setMarketCode(String marketCode) {
        this.marketCode = marketCode;
    }

    public String getComPort() {
        return comPort;
    }

    public void setComPort(String comPort) {
        this.comPort = comPort;
    }

    public String getRateCenterNo() {
        return rateCenterNo;
    }

    public void setRateCenterNo(String rateCenterNo) {
        this.rateCenterNo = rateCenterNo;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getqTransaction() {
        return qTransaction;
    }

    public void setqTransaction(String qTransaction) {
        this.qTransaction = qTransaction;
    }

    public String getLdProvider() {
        return ldProvider;
    }

    public void setLdProvider(String ldProvider) {
        this.ldProvider = ldProvider;
    }

    public String getTechFlag() {
        return techFlag;
    }

    public void setTechFlag(String techFlag) {
        this.techFlag = techFlag;
    }

    public String getTransMethod() {
        return transMethod;
    }

    public void setTransMethod(String transMethod) {
        this.transMethod = transMethod;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getOldMin() {
        return oldMin;
    }

    public void setOldMin(String oldMin) {
        this.oldMin = oldMin;
    }

    public String getDigitalFeature() {
        return digitalFeature;
    }

    public void setDigitalFeature(String digitalFeature) {
        this.digitalFeature = digitalFeature;
    }

    public String getDigitalFeatureCode() {
        return digitalFeatureCode;
    }

    public void setDigitalFeatureCode(String digitalFeatureCode) {
        this.digitalFeatureCode = digitalFeatureCode;
    }

    public String getVoiceMail() {
        return voiceMail;
    }

    public void setVoiceMail(String voiceMail) {
        this.voiceMail = voiceMail;
    }

    public String getVoiceMailPackage() {
        return voiceMailPackage;
    }

    public void setVoiceMailPackage(String voiceMailPackage) {
        this.voiceMailPackage = voiceMailPackage;
    }

    public String getCallerId() {
        return callerId;
    }

    public void setCallerId(String callerId) {
        this.callerId = callerId;
    }

    public String getCallerIdPackage() {
        return callerIdPackage;
    }

    public void setCallerIdPackage(String callerIdPackage) {
        this.callerIdPackage = callerIdPackage;
    }

    public String getCallWaiting() {
        return callWaiting;
    }

    public void setCallWaiting(String callWaiting) {
        this.callWaiting = callWaiting;
    }

    public String getCallWaitingPackage() {
        return callWaitingPackage;
    }

    public void setCallWaitingPackage(String callWaitingPackage) {
        this.callWaitingPackage = callWaitingPackage;
    }

    public String getSms() {
        return sms;
    }

    public void setSms(String sms) {
        this.sms = sms;
    }

    public String getSmsPackage() {
        return smsPackage;
    }

    public void setSmsPackage(String smsPackage) {
        this.smsPackage = smsPackage;
    }

    public String getMpn() {
        return mpn;
    }

    public void setMpn(String mpn) {
        this.mpn = mpn;
    }

    public String getMpnCode() {
        return mpnCode;
    }

    public void setMpnCode(String mpnCode) {
        this.mpnCode = mpnCode;
    }

    public String getIpPool() {
        return ipPool;
    }

    public void setIpPool(String ipPool) {
        this.ipPool = ipPool;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getDataSaver() {
        return dataSaver;
    }

    public void setDataSaver(String dataSaver) {
        this.dataSaver = dataSaver;
    }

    public String getDataSaverCode() {
        return dataSaverCode;
    }

    public void setDataSaverCode(String dataSaverCode) {
        this.dataSaverCode = dataSaverCode;
    }

    public String getPhoneManf() {
        return phoneManf;
    }

    public void setPhoneManf(String phoneManf) {
        this.phoneManf = phoneManf;
    }

    public String getRechargeDate() {
        return rechargeDate;
    }

    public void setRechargeDate(String rechargeDate) {
        this.rechargeDate = rechargeDate;
    }

    public String getExpireDate() {
        return expireDate;
    }

    public void setExpireDate(String expireDate) {
        this.expireDate = expireDate;
    }

    public String getDownloadDt() {
        return downloadDt;
    }

    public void setDownloadDt(String downloadDt) {
        this.downloadDt = downloadDt;
    }

    public String getExpDt() {
        return expDt;
    }

    public void setExpDt(String expDt) {
        this.expDt = expDt;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode1() {
        return zipCode1;
    }

    public void setZipCode1(String zipCode1) {
        this.zipCode1 = zipCode1;
    }

    public String getPrlNumber() {
        return prlNumber;
    }

    public void setPrlNumber(String prlNumber) {
        this.prlNumber = prlNumber;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    /**
     * @return the Buckets
     */
    public List<TFOneActionItemBucket> getBuckets() {
        return Buckets;
    }

    /**
     * @param Buckets the Buckets to set
     */
    public void setBuckets(List<TFOneActionItemBucket> Buckets) {
        this.Buckets = Buckets;
    }

    public String getDbenv() {
        return dbenv;
    }

    public void setDbenv(String dbenv) {
        this.dbenv = dbenv;
    }

    public List<TFOneFeatures> getFeatures() {
        return features;
    }

    public void setFeatures(List<TFOneFeatures> features) {
        this.features = features;
    }

    public String getOldEsn() {
        return oldEsn;
    }

    public void setOldEsn(String oldEsn) {
        this.oldEsn = oldEsn;
    }

    public String getOldEsnHex() {
        return oldEsnHex;
    }

    public void setOldEsnHex(String oldEsnHex) {
        this.oldEsnHex = oldEsnHex;
    }

    public String getSubscriberUpdate() {
        return subscriberUpdate;
    }

    public void setSubscriberUpdate(String subscriberUpdate) {
        this.subscriberUpdate = subscriberUpdate;
    }

    public String getSystemLogin() {
        return systemLogin;
    }

    public void setSystemLogin(String systemLogin) {
        this.systemLogin = systemLogin;
    }

    public String getSystemPassword() {
        return systemPassword;
    }

    public void setSystemPassword(String systemPassword) {
        this.systemPassword = systemPassword;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getNewImsiFlag() {
        return newImsiFlag;
    }

    public void setNewImsiFlag(String newImsiFlag) {
        this.newImsiFlag = newImsiFlag;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getxCampaignName() {
        return xCampaignName;
    }

    public void setxCampaignName(String xCampaignName) {
        this.xCampaignName = xCampaignName;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getFaxBatchSize() {
        return faxBatchSize;
    }

    public void setFaxBatchSize(String faxBatchSize) {
        this.faxBatchSize = faxBatchSize;
    }

    public String getFaxNum2() {
        return faxNum2;
    }

    public void setFaxNum2(String faxNum2) {
        this.faxNum2 = faxNum2;
    }

    public String getFaxNum() {
        return faxNum;
    }

    public void setFaxNum(String faxNum) {
        this.faxNum = faxNum;
    }

    public String getFaxBatchQtime() {
        return faxBatchQtime;
    }

    public void setFaxBatchQtime(String faxBatchQtime) {
        this.faxBatchQtime = faxBatchQtime;
    }

    public String getOnlineNum() {
        return onlineNum;
    }

    public void setOnlineNum(String onlineNum) {
        this.onlineNum = onlineNum;
    }

    public String getOnlineNum2() {
        return onlineNum2;
    }

    public void setOnlineNum2(String onlineNum2) {
        this.onlineNum2 = onlineNum2;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSequenceNum() {
        return sequenceNum;
    }

    public void setSequenceNum(String sequenceNum) {
        this.sequenceNum = sequenceNum;
    }

    public String getOtaType() {
        return otaType;
    }

    public void setOtaType(String otaType) {
        this.otaType = otaType;
    }

    public String getRtpServer() {
        return rtpServer;
    }

    public void setRtpServer(String rtpServer) {
        this.rtpServer = rtpServer;
    }

    public String getStateField() {
        return stateField;
    }

    public void setStateField(String stateField) {
        this.stateField = stateField;
    }

    public String getExeName() {
        return exeName;
    }

    public void setExeName(String exeName) {
        this.exeName = exeName;
    }

    public String getExpidite() {
        return expidite;
    }

    public void setExpidite(String expidite) {
        this.expidite = expidite;
    }

    public String getBlackoutWait() {
        return blackoutWait;
    }

    public void setBlackoutWait(String blackoutWait) {
        this.blackoutWait = blackoutWait;
    }

    public String getTuxItiServer() {
        return tuxItiServer;
    }

    public void setTuxItiServer(String tuxItiServer) {
        this.tuxItiServer = tuxItiServer;
    }

    public String getTransProfKey() {
        return transProfKey;
    }

    public void setTransProfKey(String transProfKey) {
        this.transProfKey = transProfKey;
    }

    public String getCfExtensionCount() {
        return cfExtensionCount;
    }

    public void setCfExtensionCount(String cfExtensionCount) {
        this.cfExtensionCount = cfExtensionCount;
    }

    public String getCfProfileId() {
        return cfProfileId;
    }

    public void setCfProfileId(String cfProfileId) {
        this.cfProfileId = cfProfileId;
    }

    public String getMiddleInitial() {
        return middleInitial;
    }

    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getSsnLast4() {
        return ssnLast4;
    }

    public void setSsnLast4(String ssnLast4) {
        this.ssnLast4 = ssnLast4;
    }

    public String getOspAccount() {
        return ospAccount;
    }

    public void setOspAccount(String ospAccount) {
        this.ospAccount = ospAccount;
    }

    public String getCurrAddrHouseNumber() {
        return currAddrHouseNumber;
    }

    public void setCurrAddrHouseNumber(String currAddrHouseNumber) {
        this.currAddrHouseNumber = currAddrHouseNumber;
    }

    public String getCurrAddrDirection() {
        return currAddrDirection;
    }

    public void setCurrAddrDirection(String currAddrDirection) {
        this.currAddrDirection = currAddrDirection;
    }

    public String getCurrAddrStreetName() {
        return currAddrStreetName;
    }

    public void setCurrAddrStreetName(String currAddrStreetName) {
        this.currAddrStreetName = currAddrStreetName;
    }

    public String getCurrAddrStreetType() {
        return currAddrStreetType;
    }

    public void setCurrAddrStreetType(String currAddrStreetType) {
        this.currAddrStreetType = currAddrStreetType;
    }

    public String getCurrAddrUnit() {
        return currAddrUnit;
    }

    public void setCurrAddrUnit(String currAddrUnit) {
        this.currAddrUnit = currAddrUnit;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getRatePlanExtensionConfig() {
        return ratePlanExtensionConfig;
    }

    public void setRatePlanExtensionConfig(String ratePlanExtensionConfig) {
        this.ratePlanExtensionConfig = ratePlanExtensionConfig;
    }

    public Integer getRatePlanExtensionObjId() {
        return ratePlanExtensionObjId;
    }

    public void setRatePlanExtensionObjId(Integer ratePlanExtensionObjId) {
        this.ratePlanExtensionObjId = ratePlanExtensionObjId;
    }

    public Integer getCarrierAccountId() {
        return carrierAccountId;
    }

    public void setCarrierAccountId(Integer carrierAccountId) {
        this.carrierAccountId = carrierAccountId;
    }

    public Integer getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(Integer servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getTmoNextGenFlag() {
        return tmoNextGenFlag;
    }

    public void setTmoNextGenFlag(String tmoNextGenFlag) {
        this.tmoNextGenFlag = tmoNextGenFlag;
    }

    public String getRpExtObjid() {
        return rpExtObjid;
    }

    public void setRpExtObjid(String rpExtObjid) {
        this.rpExtObjid = rpExtObjid;
    }

    public String getxMode() {
        return xMode;
    }

    public void setxMode(String xMode) {
        this.xMode = xMode;
    }

    public String getEndUser() {
        return endUser;
    }

    public void setEndUser(String endUser) {
        this.endUser = endUser;
    }

    public String getNewMsidFlag() {
        return newMsidFlag;
    }

    public void setNewMsidFlag(String newMsidFlag) {
        this.newMsidFlag = newMsidFlag;
    }

    public boolean isTestEnv() {
        return testEnv;
    }

    public void setTestEnv(boolean testEnv) {
        this.testEnv = testEnv;
    }

    public String getEsnType() {
        return esnType;
    }

    public void setEsnType(String esnType) {
        this.esnType = esnType;
    }

    public String geteSimFlag() {
        return eSimFlag;
    }

    public void seteSimFlag(String eSimFlag) {
        this.eSimFlag = eSimFlag;
    }

    @Override
    public String toString() {
        return "TracfoneOneNewTransaction{" +
                "Buckets=" + Buckets +
                ", features=" + features +
                ", appSys='" + appSys + '\'' +
                ", ratePlanProfileId=" + ratePlanProfileId +
                ", carrFeat=" + carrFeat +
                ", template='" + template + '\'' +
                ", actionItemId='" + actionItemId + '\'' +
                ", carrierId='" + carrierId + '\'' +
                ", orderType='" + orderType + '\'' +
                ", esn='" + esn + '\'' +
                ", esnHex='" + esnHex + '\'' +
                ", iccid='" + iccid + '\'' +
                ", min='" + min + '\'' +
                ", msid='" + msid + '\'' +
                ", ratePlan='" + ratePlan + '\'' +
                ", networkLogin='" + networkLogin + '\'' +
                ", networkPassword='" + networkPassword + '\'' +
                ", accountNum='" + accountNum + '\'' +
                ", dealerCode='" + dealerCode + '\'' +
                ", marketCode='" + marketCode + '\'' +
                ", comPort='" + comPort + '\'' +
                ", rateCenterNo='" + rateCenterNo + '\'' +
                ", zipCode='" + zipCode + '\'' +
                ", status='" + status + '\'' +
                ", qTransaction='" + qTransaction + '\'' +
                ", ldProvider='" + ldProvider + '\'' +
                ", techFlag='" + techFlag + '\'' +
                ", transMethod='" + transMethod + '\'' +
                ", balance='" + balance + '\'' +
                ", oldMin='" + oldMin + '\'' +
                ", digitalFeature='" + digitalFeature + '\'' +
                ", digitalFeatureCode='" + digitalFeatureCode + '\'' +
                ", voiceMail='" + voiceMail + '\'' +
                ", voiceMailPackage='" + voiceMailPackage + '\'' +
                ", callerId='" + callerId + '\'' +
                ", callerIdPackage='" + callerIdPackage + '\'' +
                ", callWaiting='" + callWaiting + '\'' +
                ", callWaitingPackage='" + callWaitingPackage + '\'' +
                ", sms='" + sms + '\'' +
                ", smsPackage='" + smsPackage + '\'' +
                ", mpn='" + mpn + '\'' +
                ", mpnCode='" + mpnCode + '\'' +
                ", ipPool='" + ipPool + '\'' +
                ", language='" + language + '\'' +
                ", dataSaver='" + dataSaver + '\'' +
                ", dataSaverCode='" + dataSaverCode + '\'' +
                ", phoneManf='" + phoneManf + '\'' +
                ", rechargeDate='" + rechargeDate + '\'' +
                ", expireDate='" + expireDate + '\'' +
                ", downloadDt='" + downloadDt + '\'' +
                ", expDt='" + expDt + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", middleInitial='" + middleInitial + '\'' +
                ", suffix='" + suffix + '\'' +
                ", prefix='" + prefix + '\'' +
                ", ssnLast4='" + ssnLast4 + '\'' +
                ", ospAccount='" + ospAccount + '\'' +
                ", currAddrHouseNumber='" + currAddrHouseNumber + '\'' +
                ", currAddrDirection='" + currAddrDirection + '\'' +
                ", currAddrStreetName='" + currAddrStreetName + '\'' +
                ", currAddrStreetType='" + currAddrStreetType + '\'' +
                ", currAddrUnit='" + currAddrUnit + '\'' +
                ", address1='" + address1 + '\'' +
                ", address2='" + address2 + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", country='" + country + '\'' +
                ", zipCode1='" + zipCode1 + '\'' +
                ", prlNumber='" + prlNumber + '\'' +
                ", make='" + make + '\'' +
                ", model='" + model + '\'' +
                ", dbenv='" + dbenv + '\'' +
                ", transactionId='" + transactionId + '\'' +
                ", creationDate='" + creationDate + '\'' +
                ", oldEsn='" + oldEsn + '\'' +
                ", oldEsnHex='" + oldEsnHex + '\'' +
                ", subscriberUpdate='" + subscriberUpdate + '\'' +
                ", systemLogin='" + systemLogin + '\'' +
                ", systemPassword='" + systemPassword + '\'' +
                ", imsi='" + imsi + '\'' +
                ", newImsiFlag='" + newImsiFlag + '\'' +
                ", pin='" + pin + '\'' +
                ", cfExtensionCount='" + cfExtensionCount + '\'' +
                ", cfProfileId='" + cfProfileId + '\'' +
                ", xCampaignName='" + xCampaignName + '\'' +
                ", amount='" + amount + '\'' +
                ", faxBatchSize='" + faxBatchSize + '\'' +
                ", faxNum2='" + faxNum2 + '\'' +
                ", faxNum='" + faxNum + '\'' +
                ", faxBatchQtime='" + faxBatchQtime + '\'' +
                ", onlineNum='" + onlineNum + '\'' +
                ", onlineNum2='" + onlineNum2 + '\'' +
                ", email='" + email + '\'' +
                ", sequenceNum='" + sequenceNum + '\'' +
                ", otaType='" + otaType + '\'' +
                ", rtpServer='" + rtpServer + '\'' +
                ", stateField='" + stateField + '\'' +
                ", exeName='" + exeName + '\'' +
                ", expidite='" + expidite + '\'' +
                ", blackoutWait='" + blackoutWait + '\'' +
                ", tuxItiServer='" + tuxItiServer + '\'' +
                ", transProfKey='" + transProfKey + '\'' +
                ", ratePlanExtensionConfig='" + ratePlanExtensionConfig + '\'' +
                ", ratePlanExtensionObjId=" + ratePlanExtensionObjId +
                ", carrierAccountId=" + carrierAccountId +
                ", servicePlanId=" + servicePlanId +
                ", tmoNextGenFlag='" + tmoNextGenFlag + '\'' +
                ", rpExtObjid='" + rpExtObjid + '\'' +
                ", xMode='" + xMode + '\'' +
                ", endUser='" + endUser + '\'' +
                ", newMsidFlag='" + newMsidFlag + '\'' +
                ", testEnv=" + testEnv +
                ", esnType='" + esnType + '\'' +
                ", eSimFlag='" + eSimFlag + '\'' +
                '}';
    }
}
