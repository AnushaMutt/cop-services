/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.controller;

import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneApn;
import com.tracfone.service.model.request.TracfoneOneCarrierFeature;
import com.tracfone.service.model.request.TracfoneOneRatePlan;
import com.tracfone.service.model.request.TracfoneOneSearchCarrierFeatureModel;
import com.tracfone.service.model.response.TFOneApn;
import com.tracfone.service.model.response.TFOneBusinessOrganization;
import com.tracfone.service.model.response.TFOneCarrierFeature;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneParent;
import com.tracfone.service.model.response.TFOneRatePlan;

import javax.ejb.Local;
import java.util.List;

/**
 * @author Shireen Fathima
 */
@Local
public interface TracfoneRatePlanLocalAction {

    TFOneGeneralResponse insertRatePlan(TracfoneOneRatePlan tfRatePlan, int userId) throws TracfoneOneException;

    List<TracfoneOneCarrierFeature> insertCarrierFeatures(TracfoneOneRatePlan tfRatePlan, String carrierName, int userId) throws TracfoneOneException;

    TFOneRatePlan viewRatePlan(TracfoneOneRatePlan tfRatePlan, boolean isOnlyObjid) throws TracfoneOneException;

    TFOneGeneralResponse updateRatePlan(TracfoneOneRatePlan tfRatePlan, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteRatePlan(String dbEnv, List<String> idsToBeDeleted, int userId) throws TracfoneOneException;

    List<TFOneCarrierServicePlan> getServicePlansForCarrier(String carrierName, String dbEnv) throws TracfoneOneException;

    List<TFOneBusinessOrganization> getAllBusinessOrgs(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse deleteCarrierFeatures(String dbEnv, String servicePlanId, List<String> idsToBeDeleted, int userId) throws TracfoneOneException;

    List<TFOneRatePlan> getMasterRatePlans(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse updateCarrierFeature(TracfoneOneCarrierFeature tfCarrierFeature, int userId) throws TracfoneOneException;

    List<TFOneCarrierFeature> searchCarrierFeatures(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws TracfoneOneException;

    List<String> getAllCarrierNames(String dbEnv) throws TracfoneOneException;

    TFOneGeneralResponse insertApn(TracfoneOneApn tfOneApn, int userId) throws TracfoneOneException;

    TFOneGeneralResponse updateApn(TracfoneOneApn tfOneApn, int userId) throws TracfoneOneException;

    TFOneGeneralResponse deleteApn(TracfoneOneApn tfOneApn, int userId) throws TracfoneOneException;

    List<TFOneParent> getAllParentNames(String dbEnv, String carrierName) throws TracfoneOneException;

    List<TFOneRatePlan> searchRatePlansForUpdate(TracfoneOneRatePlan tracfoneOneRatePlan) throws TracfoneOneException;

    List<TFOneApn> getAllRatePlanApns(TracfoneOneApn tracfoneOneApn) throws TracfoneOneException;

    boolean isDuplicateApn(TracfoneOneApn searchApn) throws TracfoneOneException;

    List<TFOneCarrierFeature> getCarrierFeatureLinks(List<TracfoneOneCarrierFeature> selectedCarrierFeatures) throws TracfoneOneException;

    TFOneGeneralResponse insertRatePlanAssociation(TracfoneOneCarrierFeature tfOneCarrierFeature, int userId) throws TracfoneOneException;

    List<TFOneCarrierFeature> searchCarrierFeaturesForUpdate(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws TracfoneOneException;

    List<TFOneRatePlan> getCarrierRatePlans(String dbEnv, String carrierName) throws TracfoneOneException;

    List<String> duplicateCarrierFeatures(TracfoneOneCarrierFeature tfCarrierFeature) throws TracfoneOneException;

    List<TFOneCarrierFeature> getCarrierFeatureMap(TracfoneOneSearchCarrierFeatureModel tfCarrierFeatureModel) throws TracfoneOneException;
}
