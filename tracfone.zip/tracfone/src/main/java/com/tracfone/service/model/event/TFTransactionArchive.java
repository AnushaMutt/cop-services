/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.event;

import java.util.Date;

/**
 *
 * @author Srinivas Murthy Pulavarthy
 */

public class TFTransactionArchive  {

    private static final long serialVersionUID = 1L;

    public TFTransactionArchive(String userId, String actionItemId, String status, String dbenv) {
        this.userId = userId;
        this.actionItemId = actionItemId;
        this.status = status;
        this.dbEnv = dbenv;
    }
    
    private Long id;
     
    private String userId;
    
    private String actionItemId;
    
    private String transactionId;
    
    private String status;
    
    private Date createddate;
    
    private Date modifieddate;
    
    private String dbEnv;
    
    
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreateddate() {
        return createddate;
    }

    public void setCreateddate(Date createddate) {
        this.createddate = createddate;
    }

    public Date getModifieddate() {
        return modifieddate;
    }

    public void setModifieddate(Date modifieddate) {
        this.modifieddate = modifieddate;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    public String getActionItemId() {
        return actionItemId;
    }

    public void setActionItemId(String actionItemId) {
        this.actionItemId = actionItemId;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }
    
    

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TFTransactionArchive)) {
            return false;
        }
        TFTransactionArchive other = (TFTransactionArchive) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.tracfone.ejb.entity.TFTransactionArchive[ id=" + id + " ]";
    }
}
