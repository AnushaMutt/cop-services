package com.tracfone.service.model.retail.request;

public class TracfoneOneRetailTraitSearchModel {
    private String parentId;
    private String zips;
    private String brand;
    private String carrier;
    private String objIds;
    private String radius;
    private String fromDate;
    private String toDate;

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getZips() {
        return zips;
    }

    public void setZips(String zips) {
        this.zips = zips;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getObjIds() {
        return objIds;
    }

    public void setObjIds(String objIds) {
        this.objIds = objIds;
    }

    public String getRadius() {
        return radius;
    }

    public void setRadius(String radius) {
        this.radius = radius;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    @Override
    public String toString() {
        return "TracfoneOneRetailTraitSearchModel{" +
                "parentId='" + parentId + '\'' +
                ", zips='" + zips + '\'' +
                ", brand='" + brand + '\'' +
                ", carrier='" + carrier + '\'' +
                ", objIds='" + objIds + '\'' +
                ", radius='" + radius + '\'' +
                ", fromDate='" + fromDate + '\'' +
                ", toDate='" + toDate + '\'' +
                '}';
    }
}
