package com.tracfone.service.model.request;

import javax.validation.constraints.Size;

/**
 * x_rp_ancillary_code_discount
 *
 * @author Pritesh Singh
 */
public class TracfoneOneAncillaryCodeDiscount {
    private String dbEnv;
    @Size(min = 1, message = "Ancillary Code cannot be blank")
    @Size(max = 5, message = "Ancillary Code cannot have more than 5 characters")
    private String ancillaryCode;
    @Size(min = 1, message = "BRM Equivalent cannot be blank")
    @Size(max = 500, message = "BRM Equivalent cannot have more than 500 characters")
    private String newBrmEquivalent;
    private String oldBrmEquivalent;
    private boolean delete;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getAncillaryCode() {
        return ancillaryCode;
    }

    public void setAncillaryCode(String ancillaryCode) {
        this.ancillaryCode = ancillaryCode;
    }

    public String getNewBrmEquivalent() {
        return newBrmEquivalent;
    }

    public void setNewBrmEquivalent(String newBrmEquivalent) {
        this.newBrmEquivalent = newBrmEquivalent;
    }

    public String getOldBrmEquivalent() {
        return oldBrmEquivalent;
    }

    public void setOldBrmEquivalent(String oldBrmEquivalent) {
        this.oldBrmEquivalent = oldBrmEquivalent;
    }

    public boolean isDelete() {
        return delete;
    }

    public void setDelete(boolean delete) {
        this.delete = delete;
    }

    @Override
    public String toString() {
        return "TracfoneOneAncillaryCodeDiscount{" +
                "dbEnv='" + dbEnv + '\'' +
                ", ancillaryCode='" + ancillaryCode + '\'' +
                ", newBrmEquivalent='" + newBrmEquivalent + '\'' +
                ", oldBrmEquivalent='" + oldBrmEquivalent + '\'' +
                ", delete='" + delete + '\'' +
                '}';
    }
}