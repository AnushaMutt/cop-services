package com.tracfone.service.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.request.TracfoneOneGeoCoderAddress;
import com.tracfone.service.model.request.TracfoneOneGeoCoderToken;
import com.tracfone.service.model.response.TFOneGeoCodeAddress;
import com.tracfone.service.model.response.TFOneGeoCoder;
import com.tracfone.service.util.TracfoneOneConstantGeocode;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Stateless;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@Stateless
public class TracfoneOneGeoCoderController implements TracfoneOneGeoCoderControllerLocal, TracfoneOneConstantGeocode {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOneGeoCoderController.class);


    @Override
    public TFOneGeoCoder generateToken(int userId, TracfoneOneGeoCoderToken tracfoneOneGeoCoderToken) throws TracfoneOneException {
        TFOneGeoCoder tfOneGeoCoder = null;
        try {
            tfOneGeoCoder = getToken(tracfoneOneGeoCoderToken);
        } catch (TracfoneOneException e) {
            LOGGER.error(TRACFONE_GENERATE_TOKEN_ERROR, TRACFONE_GENERATE_TOKEN_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_GENERATE_TOKEN_ERROR, TRACFONE_GENERATE_TOKEN_ERROR_MESSAGE, e);
        }
        return tfOneGeoCoder;
    }

    @Override
    public TFOneGeoCodeAddress findGeoAddressLocation(int userId, TracfoneOneGeoCoderAddress tracfoneOneGeoCoderAddress) throws TracfoneOneException {
        TFOneGeoCodeAddress tfOneGeoCodeAddress = null;
        try {
            tfOneGeoCodeAddress = findCandiateAddress(tracfoneOneGeoCoderAddress);
        } catch (TracfoneOneException e) {
            LOGGER.error(TRACFONE_GEOCODE_ERROR, TRACFONE_GEOCODE_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_GEOCODE_ERROR, TRACFONE_GEOCODE_ERROR_MESSAGE, e);
        }
        return tfOneGeoCodeAddress;
    }

    public TFOneGeoCoder getToken(TracfoneOneGeoCoderToken tracfoneOneGeoCoderToken) throws TracfoneOneException {
        TFOneGeoCoder tfOneGeoCoder = null;
        Gson gson = new GsonBuilder().serializeNulls().create();
        String payload = "";

        HttpPost httpPost = new HttpPost(HOST_NAME + "/" + GENERATE_TOKEN_PATH);
        httpPost.setHeader("Accept", URL_ENCODE_FORMAT);
        httpPost.setHeader("Content-type", URL_ENCODE_FORMAT);

        List<NameValuePair> request = setGenerateTokenHeaders(tracfoneOneGeoCoderToken);
        httpPost.setEntity(new UrlEncodedFormEntity(request, StandardCharsets.UTF_8));

        PoolingHttpClientConnectionManager connectionManager = HttpConnectionController.getHttpConnectionPool();

        try (CloseableHttpClient client = HttpClients.custom().setConnectionManager(connectionManager)
                .setConnectionManagerShared(true).build();
             CloseableHttpResponse response = client.execute(httpPost)) {

            if (response != null && response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                payload = EntityUtils.toString(response.getEntity());
                tfOneGeoCoder = gson.fromJson(payload, TFOneGeoCoder.class);
                if (payload.contains("error")) {
                    LOGGER.error(TRACFONE_GENERATE_TOKEN_ERROR_MESSAGE , payload);
                    throw new TracfoneOneException(TRACFONE_GENERATE_TOKEN_ERROR_MESSAGE, payload);
                }
            } else {
                LOGGER.error(TRACFONE_GENERATE_TOKEN_ERROR_MESSAGE , payload);
                throw new TracfoneOneException(TRACFONE_GENERATE_TOKEN_ERROR_MESSAGE, payload);
            }
        } catch (Exception e) {
            LOGGER.error(TRACFONE_GENERATE_TOKEN_ERROR, TRACFONE_GENERATE_TOKEN_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_GENERATE_TOKEN_ERROR, TRACFONE_GENERATE_TOKEN_ERROR_MESSAGE, e);
        }
        return tfOneGeoCoder;
    }

    public TFOneGeoCodeAddress findCandiateAddress(TracfoneOneGeoCoderAddress tracfoneOneGeoCoderAddress) throws TracfoneOneException {
        TFOneGeoCodeAddress tfOneGeoCodeAddress = null;
        Gson gson = new GsonBuilder().serializeNulls().create();

        try {
            CloseableHttpClient client = HttpClients
                    .custom()
                    .setSSLContext(new SSLContextBuilder().loadTrustMaterial(null, TrustAllStrategy.INSTANCE).build())
                    .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                    .build();

            HttpPost httpPost = new HttpPost(HOST_NAME + FIND_ADDRESS);
            httpPost.setHeader("Accept", URL_ENCODE_FORMAT);
            httpPost.setHeader("Content-type", URL_ENCODE_FORMAT);

            List<NameValuePair> nvps = new ArrayList<>();
            nvps.add(new BasicNameValuePair("token", tracfoneOneGeoCoderAddress.getToken()));
            nvps.add(new BasicNameValuePair("f", "json"));
            nvps.add(new BasicNameValuePair("SingleLine", tracfoneOneGeoCoderAddress.getSingleLine()));
            nvps.add(new BasicNameValuePair("CountryCode", tracfoneOneGeoCoderAddress.getCountryCode()));
            nvps.add(new BasicNameValuePair("PostalExt", tracfoneOneGeoCoderAddress.getPostalExt()));
            nvps.add(new BasicNameValuePair("Postal", tracfoneOneGeoCoderAddress.getPostal()));
            nvps.add(new BasicNameValuePair("Region", tracfoneOneGeoCoderAddress.getRegion()));
            nvps.add(new BasicNameValuePair("Subregion", tracfoneOneGeoCoderAddress.getSubregion()));
            nvps.add(new BasicNameValuePair("City", tracfoneOneGeoCoderAddress.getCity()));
            nvps.add(new BasicNameValuePair("Neighborhood", tracfoneOneGeoCoderAddress.getNeighborhood()));
            nvps.add(new BasicNameValuePair("Address3", tracfoneOneGeoCoderAddress.getAddress3()));
            nvps.add(new BasicNameValuePair("Address2", tracfoneOneGeoCoderAddress.getAddress2()));
            nvps.add(new BasicNameValuePair("Address", tracfoneOneGeoCoderAddress.getAddress()));
            nvps.add(new BasicNameValuePair("magicKey", tracfoneOneGeoCoderAddress.getMagicKey()));
            nvps.add(new BasicNameValuePair("outSR", tracfoneOneGeoCoderAddress.getOutSR()));
            nvps.add(new BasicNameValuePair("searchExtent", tracfoneOneGeoCoderAddress.getSearchExtent()));
            nvps.add(new BasicNameValuePair("distance", tracfoneOneGeoCoderAddress.getDistance()));
            nvps.add(new BasicNameValuePair("location", tracfoneOneGeoCoderAddress.getLocation()));
            nvps.add(new BasicNameValuePair("category", tracfoneOneGeoCoderAddress.getCategory()));
            nvps.add(new BasicNameValuePair("sourceCountry", tracfoneOneGeoCoderAddress.getSourceCountry()));
            nvps.add(new BasicNameValuePair("locationType", tracfoneOneGeoCoderAddress.getLocationType()));
            nvps.add(new BasicNameValuePair("langCode", tracfoneOneGeoCoderAddress.getLangCode()));
            nvps.add(new BasicNameValuePair("matchOutOfRange", tracfoneOneGeoCoderAddress.getMatchOutOfRange()));
            nvps.add(new BasicNameValuePair("maxLocations", tracfoneOneGeoCoderAddress.getMaxLocations()));
            nvps.add(new BasicNameValuePair("outFields", tracfoneOneGeoCoderAddress.getOutFields()));

            httpPost.setEntity(new UrlEncodedFormEntity(nvps, StandardCharsets.UTF_8));
            CloseableHttpResponse response = client.execute(httpPost);
            String payload = getPayload(response);
            if (payload.contains("error")) {
                LOGGER.error(TRACFONE_GEOCODE_RESPONSE_ERROR, payload);
                throw new TracfoneOneException(TRACFONE_GEOCODE_RESPONSE_ERROR, payload);
            }
            tfOneGeoCodeAddress = gson.fromJson(payload, TFOneGeoCodeAddress.class);
            client.close();
        } catch (Exception e) {
            LOGGER.error(TRACFONE_GEOCODE_ERROR, TRACFONE_GEOCODE_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_GEOCODE_ERROR, TRACFONE_GEOCODE_ERROR_MESSAGE, e);
        }
        return tfOneGeoCodeAddress;
    }

    private List<NameValuePair> setGenerateTokenHeaders(TracfoneOneGeoCoderToken tracfoneOneGeoCoderToken) {
        List<NameValuePair> nvps = new ArrayList<>();
        nvps.add(new BasicNameValuePair("username", TOKEN_USER_NAME));
        nvps.add(new BasicNameValuePair("password", ESRI_TOKEN));
        nvps.add(new BasicNameValuePair("client", CLIENT));
        nvps.add(new BasicNameValuePair("referer", tracfoneOneGeoCoderToken.getReferer()));
        nvps.add(new BasicNameValuePair("f", FORMAT));
        nvps.add(new BasicNameValuePair("expiration", TOKEN_EXPIRE_TIME));
        return nvps;
    }

    private String getPayload(HttpResponse response) throws IOException {
        StringBuilder payload = new StringBuilder();
        String line = "";
        InputStreamReader inputStreamReader = new InputStreamReader((response.getEntity().getContent()));
        BufferedReader buff = new BufferedReader(inputStreamReader);
        try {
            while ((line = buff.readLine()) != null) {
                payload.append(line);
            }
        } finally {
            buff.close();
            inputStreamReader.close();
        }
        return payload.toString();
    }


}
