package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * TABLE: TABLE_X_ORDER_TYPE
 *
 * @author Pritesh Singh
 */
public class TracfoneOneOrderType {
    private String dbEnv;
    @Digits(integer = 38, fraction = 0, message = "ObjId must be a number")
    private String objId;
    @Size(min = 1, message = "Order Type cannot be null")
    @Size(max = 30, message = "Order Type cannot have more than 30 characters")
    private String orderType;
    @Size(max = 10, message = "NPA cannot have more than 10 characters")
    private String npa;
    @Size(max = 10, message = "NXX cannot have more than 10 characters")
    private String nxx;
    @Size(max = 10, message = "Bill Cycle cannot have more than 10 characters")
    private String billCycle;
    @Size(max = 30, message = "Dealer Code cannot have more than 30 characters")
    private String dealerCode;
    @Size(max = 30, message = "LD Account Num cannot have more than 30 characters")
    private String ldAccountNum;
    @Size(max = 30, message = "Market Code cannot have more than 30 characters")
    private String marketCode;
    @Digits(integer = 38, fraction = 0, message = "Order Type 2 xTrans Profile must be a number")
    private String orderType2xTransProfile;
    @Digits(integer = 38, fraction = 0, message = "Order Type 2 xCarrier must be a number")
    private String orderType2xCarrier;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getNpa() {
        return npa;
    }

    public void setNpa(String npa) {
        this.npa = npa;
    }

    public String getNxx() {
        return nxx;
    }

    public void setNxx(String nxx) {
        this.nxx = nxx;
    }

    public String getBillCycle() {
        return billCycle;
    }

    public void setBillCycle(String billCycle) {
        this.billCycle = billCycle;
    }

    public String getDealerCode() {
        return dealerCode;
    }

    public void setDealerCode(String dealerCode) {
        this.dealerCode = dealerCode;
    }

    public String getLdAccountNum() {
        return ldAccountNum;
    }

    public void setLdAccountNum(String ldAccountNum) {
        this.ldAccountNum = ldAccountNum;
    }

    public String getMarketCode() {
        return marketCode;
    }

    public void setMarketCode(String marketCode) {
        this.marketCode = marketCode;
    }

    public String getOrderType2xTransProfile() {
        return orderType2xTransProfile;
    }

    public void setOrderType2xTransProfile(String orderType2xTransProfile) {
        this.orderType2xTransProfile = orderType2xTransProfile;
    }

    public String getOrderType2xCarrier() {
        return orderType2xCarrier;
    }

    public void setOrderType2xCarrier(String orderType2xCarrier) {
        this.orderType2xCarrier = orderType2xCarrier;
    }

    @Override
    public String toString() {
        return "TracfoneOneOrderType{" +
                "dbEnv='" + dbEnv + '\'' +
                ", objId='" + objId + '\'' +
                ", orderType='" + orderType + '\'' +
                ", npa='" + npa + '\'' +
                ", nxx='" + nxx + '\'' +
                ", billCycle='" + billCycle + '\'' +
                ", dealerCode='" + dealerCode + '\'' +
                ", ldAccountNum='" + ldAccountNum + '\'' +
                ", marketCode='" + marketCode + '\'' +
                ", orderType2xTransProfile='" + orderType2xTransProfile + '\'' +
                ", orderType2xCarrier='" + orderType2xCarrier + '\'' +
                '}';
    }
}
