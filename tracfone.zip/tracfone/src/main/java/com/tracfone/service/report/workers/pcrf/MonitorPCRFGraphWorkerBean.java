package com.tracfone.service.report.workers.pcrf;

import com.tracfone.service.model.report.TFOneReportPCRFGraphReport;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Resource;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author Gaurav.Sharma
 */
@Stateless
public class MonitorPCRFGraphWorkerBean {

    @Resource(lookup = "jndi/cop_report")
    private DataSource dataSourceReports;

    private AtomicBoolean busy = new AtomicBoolean(false);

    private static final Logger LOGGER = LogManager.getLogger(MonitorPCRFGraphWorkerBean.class);

    @Lock(LockType.READ)
    public List<TFOneReportPCRFGraphReport> runPCRFMonitorGraphReport() {
        List<TFOneReportPCRFGraphReport> pcrfMonitorGraphReport = new ArrayList<>();

        if (!busy.compareAndSet(false, true)) {
            return pcrfMonitorGraphReport;
        }

        try (Connection con = dataSourceReports.getConnection();
             PreparedStatement stmt = con.prepareStatement(TracfoneOneConstantReport.REPORT_SQL_PCRF_MONITOR_GRAPH_VIEW);
             ResultSet resultSet = stmt.executeQuery();) {
            while (resultSet.next()) {
                TFOneReportPCRFGraphReport tfOneReportGraphMonitor = new TFOneReportPCRFGraphReport();
                tfOneReportGraphMonitor.setTemplate(resultSet.getString("PCRF_PARENT_NAME"));
                tfOneReportGraphMonitor.setOrderType(resultSet.getString("ORDER_TYPE"));
                tfOneReportGraphMonitor.setStatus(resultSet.getString("PCRF_STATUS_CODE"));
                tfOneReportGraphMonitor.setCount(resultSet.getString("COUNT"));
                pcrfMonitorGraphReport.add(tfOneReportGraphMonitor);
            }
        } catch (Exception e) {
            LOGGER.error("PCRF Monitor Graph report retrival error - ", e);
        } finally {
            busy.set(false);
        }
        return pcrfMonitorGraphReport;
    }
}
