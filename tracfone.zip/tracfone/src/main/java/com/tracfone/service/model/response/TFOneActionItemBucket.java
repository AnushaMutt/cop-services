package com.tracfone.service.model.response;

import java.util.List;

/**
 * @author druiz
 */
public class TFOneActionItemBucket {
    private String bucketId;
    private String rechargeDate;
    private String bucketBalance;
    private String bucketValue;  
    private String expirationDate;
    private String direction;
    private String benefitType;
    private String bucketType;
    private String bucketUsage;
    private String bucketAction;
    private String dataExpirationDate;
    private String unitOfMeasurement;
    private String bucketGroup;
    private String bucketRequirement;
    private String autoRenewFlag;
    private String autoRenewFrequency;
    private String autoRenewValue;
    private String autoRenewDay;        
    private String bucketDescription;
    private String orgBucketId;
    private String orgBucketDirection;
    private String status;
    private List<TFOneActionItemBucketTier> bucketTiers;

    public List<TFOneActionItemBucketTier> getBucketTiers() {
        return bucketTiers;
    }

    public void setBucketTiers(List<TFOneActionItemBucketTier> bucketTiers) {
        this.bucketTiers = bucketTiers;
    }    
    
    public String getDataExpirationDate() {
        return dataExpirationDate;
    }

    public void setDataExpirationDate(String dataExpirationDate) {
        this.dataExpirationDate = dataExpirationDate;
    }

    public String getUnitOfMeasurement() {
        return unitOfMeasurement;
    }

    public void setUnitOfMeasurement(String unitOfMeasure) {
        this.unitOfMeasurement = unitOfMeasure;
    }

    public String getBucketGroup() {
        return bucketGroup;
    }

    public void setBucketGroup(String bucketGroup) {
        this.bucketGroup = bucketGroup;
    }

    public String getBucketRequirement() {
        return bucketRequirement;
    }

    public void setBucketRequirement(String bucketRequirement) {
        this.bucketRequirement = bucketRequirement;
    }

    public String getAutoRenewFlag() {
        return autoRenewFlag;
    }

    public void setAutoRenewFlag(String autoRenewFlag) {
        this.autoRenewFlag = autoRenewFlag;
    }

    public String getAutoRenewFrequency() {
        return autoRenewFrequency;
    }

    public void setAutoRenewFrequency(String autoRenewFrequency) {
        this.autoRenewFrequency = autoRenewFrequency;
    }

    public String getAutoRenewValue() {
        return autoRenewValue;
    }

    public void setAutoRenewValue(String autoRenewValue) {
        this.autoRenewValue = autoRenewValue;
    }

    public String getAutoRenewDay() {
        return autoRenewDay;
    }

    public void setAutoRenewDay(String autoRenewDay) {
        this.autoRenewDay = autoRenewDay;
    }
        
    public String getBucketId() {
        return bucketId;
    }

    public void setBucketId(String bucketId) {
        this.bucketId = bucketId;
    }

    public String getBucketBalance() {
        return bucketBalance;
    }

    public void setBucketBalance(String bucketBalance) {
        this.bucketBalance = bucketBalance;
    }

    public String getRechargeDate() {
        return rechargeDate;
    }

    public void setRechargeDate(String rechargeDate) {
        this.rechargeDate = rechargeDate;
    }

    public String getBucketValue() {
        return bucketValue;
    }

    public void setBucketValue(String bucketValue) {
        this.bucketValue = bucketValue;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getBenefitType() {
        return benefitType;
    }

    public void setBenefitType(String benefitType) {
        this.benefitType = benefitType;
    }

    public String getBucketType() {
        return bucketType;
    }

    public void setBucketType(String bucketType) {
        this.bucketType = bucketType;
    }

    public String getBucketUsage() {
        return bucketUsage;
    }

    public void setBucketUsage(String bucketUsage) {
        this.bucketUsage = bucketUsage;
    }

    public String getBucketAction() {
        return bucketAction;
    }

    public void setBucketAction(String bucketAction) {
        this.bucketAction = bucketAction;
    }
    
     public String getBucketDescription() {
        return bucketDescription;
    }

    public void setBucketDescription(String bucketDescription) {
        this.bucketDescription = bucketDescription;
    }
    
    public String getOrgBucketId() {
        return orgBucketId;
    }

    public void setOrgBucketId(String orgBucketId) {
        this.orgBucketId = orgBucketId;
    }
    
    public String getOrgBucketDirection() {
        return orgBucketDirection;
    }

    public void setOrgBucketDirection(String orgBucketDirection) {
        this.orgBucketDirection = orgBucketDirection;
    }

    public String getStatus() { return status; }

    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "TFOneActionItemBucket{" +
                "bucketId='" + bucketId + '\'' +
                ", rechargeDate='" + rechargeDate + '\'' +
                ", bucketBalance='" + bucketBalance + '\'' +
                ", bucketValue='" + bucketValue + '\'' +
                ", expirationDate='" + expirationDate + '\'' +
                ", direction='" + direction + '\'' +
                ", benefitType='" + benefitType + '\'' +
                ", bucketType='" + bucketType + '\'' +
                ", bucketUsage='" + bucketUsage + '\'' +
                ", bucketAction='" + bucketAction + '\'' +
                ", dataExpirationDate='" + dataExpirationDate + '\'' +
                ", unitOfMeasurement='" + unitOfMeasurement + '\'' +
                ", bucketGroup='" + bucketGroup + '\'' +
                ", bucketRequirement='" + bucketRequirement + '\'' +
                ", autoRenewFlag='" + autoRenewFlag + '\'' +
                ", autoRenewFrequency='" + autoRenewFrequency + '\'' +
                ", autoRenewValue='" + autoRenewValue + '\'' +
                ", autoRenewDay='" + autoRenewDay + '\'' +
                ", bucketDescription='" + bucketDescription + '\'' +
                ", orgBucketId='" + orgBucketId + '\'' +
                ", orgBucketDirection='" + orgBucketDirection + '\'' +
                ", status='" + status + '\'' +
                ", bucketTiers=" + bucketTiers +
                '}';
    }
}