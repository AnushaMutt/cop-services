package com.tracfone.service.model.response;

public class TFOneGeoCoderCandidates {
    private String address;
    private TFOneGeoCoderLocation location;
    private String score;
    private TFOneGeoCoderAttributes attributes;
    private TFOneGeoCoderExtent extent;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public TFOneGeoCoderLocation getLocation() {
        return location;
    }

    public void setLocation(TFOneGeoCoderLocation location) {
        this.location = location;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public TFOneGeoCoderAttributes getAttributes() {
        return attributes;
    }

    public void setAttributes(TFOneGeoCoderAttributes attributes) {
        this.attributes = attributes;
    }

    public TFOneGeoCoderExtent getExtent() {
        return extent;
    }

    public void setExtent(TFOneGeoCoderExtent extent) {
        this.extent = extent;
    }
}
