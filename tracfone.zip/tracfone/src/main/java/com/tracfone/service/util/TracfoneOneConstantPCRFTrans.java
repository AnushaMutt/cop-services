package com.tracfone.service.util;

/**
 * This is a constant file that will be used for the PCRF transaction wizard
 *
 * @author Gaurav.Sharma
 */
public interface TracfoneOneConstantPCRFTrans {

    // ERROR MESSAGES
    String TRACFONE_GET_PCRF_TRANSACTION_ERROR = "TFE1900";
    String TRACFONE_GET_PCRF_TRANSACTION_ERROR_MESSAGE = "Unable to get PCRF Transactions";

    /**
     * Database Queries
     */
    String PCRF_TRANSACTION_START = "select * from ( "
            + "select /*+ FIRST_ROWS(n) */ a.*, ROWNUM rnum from (";

    String GET_PCRF_TRANSACTION = "select * from X_PCRF_TRANSACTION pt where ";

    String GET_PCRF_TRANSACTION_COUNT = "SELECT count(1) AS totalRecords FROM X_PCRF_TRANSACTION pt where ";

}
