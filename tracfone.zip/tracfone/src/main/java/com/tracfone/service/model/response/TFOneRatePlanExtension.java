/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.response;

/**
 *
 * @author Pritesh Singh
 */
public class TFOneRatePlanExtension {
    private String objId;
    private String lineStatusCode;
    private String throttleStatusCode;
    private String ancillaryCode;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getLineStatusCode() {
        return lineStatusCode;
    }

    public void setLineStatusCode(String lineStatusCode) {
        this.lineStatusCode = lineStatusCode;
    }

    public String getThrottleStatusCode() {
        return throttleStatusCode;
    }

    public void setThrottleStatusCode(String throttleStatusCode) {
        this.throttleStatusCode = throttleStatusCode;
    }

    public String getAncillaryCode() {
        return ancillaryCode;
    }

    public void setAncillaryCode(String ancillaryCode) {
        this.ancillaryCode = ancillaryCode;
    }

    @Override
    public String toString() {
        return "TFOneRatePlanExtension{" + "objId=" + objId + ", "
                + "lineStatusCode=" + lineStatusCode + ", "
                + "throttleStatusCode=" + throttleStatusCode + ", "
                + "ancillaryCode=" + ancillaryCode + '}';
    }
    
}
