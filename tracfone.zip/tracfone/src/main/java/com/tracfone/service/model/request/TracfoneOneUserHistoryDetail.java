/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.request;

import java.util.Date;

/**
 * COP_ID_USER_HISTORY_DETAIL
 *
 * @author Pritesh.Singh
 */
public class TracfoneOneUserHistoryDetail {

    private String dbEnv;
    private String userHistoryDetailId;
    private String userHistoryId;
    private String idType;
    private String idDetail;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getUserHistoryDetailId() {
        return userHistoryDetailId;
    }

    public void setUserHistoryDetailId(String userHistoryDetailId) {
        this.userHistoryDetailId = userHistoryDetailId;
    }

    public String getUserHistoryId() {
        return userHistoryId;
    }

    public void setUserHistoryId(String userHistoryId) {
        this.userHistoryId = userHistoryId;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdDetail() {
        return idDetail;
    }

    public void setIdDetail(String idDetail) {
        this.idDetail = idDetail;
    }

    @Override
    public String toString() {
        return "TracfoneOneUserHistoryDetail{" +
                "dbEnv='" + dbEnv + '\'' +
                ", userHistoryDetailId='" + userHistoryDetailId + '\'' +
                ", userHistoryId='" + userHistoryId + '\'' +
                ", idType='" + idType + '\'' +
                ", idDetail='" + idDetail + '\'' +
                '}';
    }
}
