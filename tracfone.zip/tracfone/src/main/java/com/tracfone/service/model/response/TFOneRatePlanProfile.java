/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

import java.util.List;

/**
 *
 * @author user
 */
public class TFOneRatePlanProfile {

    private String profileId;
    private String profileDescription;
    private List<TFOneRatePlanExtensionLink> rpExtensionLinks;
    private List <TFOneRatePlanExtensionConfig> rpExtensionConfigs;
    private List<TFOneFeatures> features;
    private List<TFOneBucket> buckets;

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getProfileDescription() {
        return profileDescription;
    }

    public void setProfileDescription(String profileDescription) {
        this.profileDescription = profileDescription;
    }

    public List<TFOneFeatures> getFeatures() {
        return features;
    }

    public void setFeatures(List<TFOneFeatures> features) {
        this.features = features;
    }

    public List<TFOneBucket> getBuckets() {
        return buckets;
    }

    public void setBuckets(List<TFOneBucket> buckets) {
        this.buckets = buckets;
    }

    public List<TFOneRatePlanExtensionLink> getRpExtensionLinks() {
        return rpExtensionLinks;
    }

    public void setRpExtensionLinks(List<TFOneRatePlanExtensionLink> rpExtensionLinks) {
        this.rpExtensionLinks = rpExtensionLinks;
    }

    public List<TFOneRatePlanExtensionConfig> getRpExtensionConfigs() {
        return rpExtensionConfigs;
    }

    public void setRpExtensionConfigs(List<TFOneRatePlanExtensionConfig> rpExtensionConfigs) {
        this.rpExtensionConfigs = rpExtensionConfigs;
    }
    
    
    @Override
    public String toString() {
        return "TFOneRatePlanProfile{" + "profileId=" + profileId + ", "
                + "profileDescription=" + profileDescription + ", "
                + "rpExtensionLinks=" + rpExtensionLinks + ", "
                + "rpExtensionConfigs=" + rpExtensionConfigs + ", "
                + "buckets=" + buckets + ", "
                + "features=" + features + '}';
    }

}
