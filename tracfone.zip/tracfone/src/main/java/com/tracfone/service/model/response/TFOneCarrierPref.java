package com.tracfone.service.model.response;

/**
 *
 * @author Gaurav.Sharma
 */
public class TFOneCarrierPref {
    private String state;
    private String county;
    private String carrierId;
    private String carrierName;
    private String carrierRank;
    private String newRank;

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(String carrierId) {
        this.carrierId = carrierId;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getCarrierRank() {
        return carrierRank;
    }

    public void setCarrierRank(String carrierRank) {
        this.carrierRank = carrierRank;
    }

    public String getNewRank() {
        return newRank;
    }

    public void setNewRank(String newRank) {
        this.newRank = newRank;
    }

    @Override
    public String toString() {
        return "TFOneCarrierPref{" + "state=" + state + ", county=" + county + ", carrierId=" + carrierId + ", carrierName=" + carrierName + ", carrierRank=" + carrierRank + ", newRank=" + newRank + '}';
    }
}
