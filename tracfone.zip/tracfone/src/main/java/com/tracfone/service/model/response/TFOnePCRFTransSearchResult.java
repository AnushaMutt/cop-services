package com.tracfone.service.model.response;

import com.tracfone.service.model.request.TracfoneonePaginationSearch;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Gaurav.Sharma
 */
public class TFOnePCRFTransSearchResult {

    private TracfoneonePaginationSearch paginationSearch;
    private List<TFOnePCRFTransaction> pcrfTransactions;

    public TFOnePCRFTransSearchResult() {
        pcrfTransactions = new ArrayList<>();
    }

    public TracfoneonePaginationSearch getPaginationSearch() {
        return paginationSearch;
    }

    public void setPaginationSearch(TracfoneonePaginationSearch paginationSearch) {
        this.paginationSearch = paginationSearch;
    }

    public List<TFOnePCRFTransaction> getPcrfTransactions() {
        return pcrfTransactions;
    }

    public void setPcrfTransactions(List<TFOnePCRFTransaction> pcrfTransactions) {
        this.pcrfTransactions = pcrfTransactions;
    }

    @Override
    public String toString() {
        return "TFOnePCRFTransSearchResult{"
                + "paginationSearch=" + paginationSearch
                + ", pcrfTransactions=" + pcrfTransactions
                + '}';
    }
}
