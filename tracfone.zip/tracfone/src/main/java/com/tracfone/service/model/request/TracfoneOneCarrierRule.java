package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * TABLE: TABLE_X_CARRIER_RULES
 *
 * @author Pritesh Singh
 */
public class TracfoneOneCarrierRule {
    private String dbEnv;
    @Digits(integer = 38, fraction = 0, message = "ObjId must be a number")
    private String objId;
    @Digits(integer = 38, fraction = 0, message = "Cooling Period must be a number")
    private String coolingPeriod;
    @Digits(integer = 38, fraction = 0, message = "ESN Change Days must be a number")
    private String esnChangeDays;
    @Digits(integer = 38, fraction = 0, message = "Line Expire Days must be a number")
    private String lineExpireDays;
    @Digits(integer = 38, fraction = 0, message = "Line Return Days must be a number")
    private String lineReturnDays;
    @Digits(integer = 38, fraction = 0, message = "Cooling After Insert must be a number")
    private String coolingAfterInsert;
    @Digits(integer = 38, fraction = 0, message = "NPA NXX Flag must be a number")
    private String npaNxxFlag;
    @Digits(integer = 38, fraction = 0, message = "Used Line Expire Days must be a number")
    private String usedLineExpireDays;
    @Digits(integer = 38, fraction = 0, message = "GSM Grace Period must be a number")
    private String gsmGracePeriod;
    @Size(max= 10, message = "Technology cannot have more than 10 characters")
    private String technology;
    @Digits(integer = 38, fraction = 0, message = "Reserve On Suspend must be a number")
    private String reserveOnSuspend;
    @Digits(integer = 38, fraction = 0, message = "Reserve Period must be a number")
    private String reservePeriod;
    @Digits(integer = 38, fraction = 0, message = "Deac After Grace must be a number")
    private String deacAfterGrace;
    @Digits(integer = 38, fraction = 0, message = "Cancel Suspend Days must be a number")
    private String cancelSuspendDays;
    @Digits(integer = 38, fraction = 0, message = "Cancel Suspend must be a number")
    private String cancelSuspend;
    @Digits(integer = 38, fraction = 0, message = "Block Create Act Item must be a number")
    private String blockCreateActItem;
    @Size(max= 30, message = "Allow 2G Act cannot have more than 30 characters")
    private String allow2gAct;
    @Size(max= 30, message = "Allow 2G React cannot have more than 30 characters")
    private String allow2gReact;
    @Digits(integer = 38, fraction = 0, message = "Allow Non Hd Acts must be a number")
    private String allowNonHdActs;
    @Digits(integer = 38, fraction = 0, message = "Allow Non Hd Reacts must be a number")
    private String allowNonHdReacts;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getCoolingPeriod() {
        return coolingPeriod;
    }

    public void setCoolingPeriod(String coolingPeriod) {
        this.coolingPeriod = coolingPeriod;
    }

    public String getEsnChangeDays() {
        return esnChangeDays;
    }

    public void setEsnChangeDays(String esnChangeDays) {
        this.esnChangeDays = esnChangeDays;
    }

    public String getLineExpireDays() {
        return lineExpireDays;
    }

    public void setLineExpireDays(String lineExpireDays) {
        this.lineExpireDays = lineExpireDays;
    }

    public String getLineReturnDays() {
        return lineReturnDays;
    }

    public void setLineReturnDays(String lineReturnDays) {
        this.lineReturnDays = lineReturnDays;
    }

    public String getCoolingAfterInsert() {
        return coolingAfterInsert;
    }

    public void setCoolingAfterInsert(String coolingAfterInsert) {
        this.coolingAfterInsert = coolingAfterInsert;
    }

    public String getNpaNxxFlag() {
        return npaNxxFlag;
    }

    public void setNpaNxxFlag(String npaNxxFlag) {
        this.npaNxxFlag = npaNxxFlag;
    }

    public String getUsedLineExpireDays() {
        return usedLineExpireDays;
    }

    public void setUsedLineExpireDays(String usedLineExpireDays) {
        this.usedLineExpireDays = usedLineExpireDays;
    }

    public String getGsmGracePeriod() {
        return gsmGracePeriod;
    }

    public void setGsmGracePeriod(String gsmGracePeriod) {
        this.gsmGracePeriod = gsmGracePeriod;
    }

    public String getTechnology() {
        return technology;
    }

    public void setTechnology(String technology) {
        this.technology = technology;
    }

    public String getReserveOnSuspend() {
        return reserveOnSuspend;
    }

    public void setReserveOnSuspend(String reserveOnSuspend) {
        this.reserveOnSuspend = reserveOnSuspend;
    }

    public String getReservePeriod() {
        return reservePeriod;
    }

    public void setReservePeriod(String reservePeriod) {
        this.reservePeriod = reservePeriod;
    }

    public String getDeacAfterGrace() {
        return deacAfterGrace;
    }

    public void setDeacAfterGrace(String deacAfterGrace) {
        this.deacAfterGrace = deacAfterGrace;
    }

    public String getCancelSuspendDays() {
        return cancelSuspendDays;
    }

    public void setCancelSuspendDays(String cancelSuspendDays) {
        this.cancelSuspendDays = cancelSuspendDays;
    }

    public String getCancelSuspend() {
        return cancelSuspend;
    }

    public void setCancelSuspend(String cancelSuspend) {
        this.cancelSuspend = cancelSuspend;
    }

    public String getBlockCreateActItem() {
        return blockCreateActItem;
    }

    public void setBlockCreateActItem(String blockCreateActItem) {
        this.blockCreateActItem = blockCreateActItem;
    }

    public String getAllow2gAct() {
        return allow2gAct;
    }

    public void setAllow2gAct(String allow2gAct) {
        this.allow2gAct = allow2gAct;
    }

    public String getAllow2gReact() {
        return allow2gReact;
    }

    public void setAllow2gReact(String allow2gReact) {
        this.allow2gReact = allow2gReact;
    }

    public String getAllowNonHdActs() {
        return allowNonHdActs;
    }

    public void setAllowNonHdActs(String allowNonHdActs) {
        this.allowNonHdActs = allowNonHdActs;
    }

    public String getAllowNonHdReacts() {
        return allowNonHdReacts;
    }

    public void setAllowNonHdReacts(String allowNonHdReacts) {
        this.allowNonHdReacts = allowNonHdReacts;
    }

    @Override
    public String toString() {
        return "TracfoneOneCarrierRule{" +
                "dbEnv='" + dbEnv + '\'' +
                ", objId='" + objId + '\'' +
                ", coolingPeriod='" + coolingPeriod + '\'' +
                ", esnChangeDays='" + esnChangeDays + '\'' +
                ", lineExpireDays='" + lineExpireDays + '\'' +
                ", lineReturnDays='" + lineReturnDays + '\'' +
                ", coolingAfterInsert='" + coolingAfterInsert + '\'' +
                ", npaNxxFlag='" + npaNxxFlag + '\'' +
                ", usedLineExpireDays='" + usedLineExpireDays + '\'' +
                ", gsmGracePeriod='" + gsmGracePeriod + '\'' +
                ", technology='" + technology + '\'' +
                ", reserveOnSuspend='" + reserveOnSuspend + '\'' +
                ", reservePeriod='" + reservePeriod + '\'' +
                ", deacAfterGrace='" + deacAfterGrace + '\'' +
                ", cancelSuspendDays='" + cancelSuspendDays + '\'' +
                ", cancelSuspend='" + cancelSuspend + '\'' +
                ", blockCreateActItem='" + blockCreateActItem + '\'' +
                ", allow2gAct='" + allow2gAct + '\'' +
                ", allow2gReact='" + allow2gReact + '\'' +
                ", allowNonHdActs='" + allowNonHdActs + '\'' +
                ", allowNonHdReacts='" + allowNonHdReacts + '\'' +
                '}';
    }
}
