package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * @author Thejaswini
 */
public class TracfoneOneCarrierSimPref {
    @Size(min = 1, message = "Rank cannot be null")
    @Digits(integer = 38, fraction = 0, message = "Rank must be a number")
    @Size(max = 38, message = "Rank cannot have more than 38 digits")
    private String rank;
    @Size(min = 1, message = "Min DLL Exch cannot be null")
    @Digits(integer = 38, fraction = 0, message = "Min DLL Exch must be a number")
    @Size(max = 38, message = "Min DLL Exch cannot have more than 38 digits")
    private String minDllExch;
    @Size(min = 1, message = "Max DLL Exch cannot be null")
    @Digits(integer = 38, fraction = 0, message = "Max DLL Exch must be a number")
    @Size(max = 38, message = "Max DLL Exch cannot have more than 38 digits")
    private String maxDllExch;
    @Size(min = 1, message = "Carrier Name cannot be null")
    @Size(max = 30, message = "Carrier Name cannot have more than 255 characters")
    private String carrierName;
    @Size(min = 1, message = "Sim Profile cannot be null")
    @Size(max = 30, message = "Sim Profile cannot have more than 30 characters")
    private String simProfile;
    private String dbEnv;
    private  String oldCarrierName;
    private String oldSimProfile;
    private String oldMinDllExch;
    private String oldMaxDllExch;
    private String oldRank;

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getMinDllExch() {
        return minDllExch;
    }

    public void setMinDllExch(String minDllExch) {
        this.minDllExch = minDllExch;
    }

    public String getMaxDllExch() {
        return maxDllExch;
    }

    public void setMaxDllExch(String maxDllExch) {
        this.maxDllExch = maxDllExch;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getSimProfile() {
        return simProfile;
    }

    public void setSimProfile(String simProfile) {
        this.simProfile = simProfile;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getOldCarrierName() {
        return oldCarrierName;
    }

    public void setOldCarrierName(String oldCarrierName) {
        this.oldCarrierName = oldCarrierName;
    }

    public String getOldSimProfile() {
        return oldSimProfile;
    }

    public void setOldSimProfile(String oldSimProfile) {
        this.oldSimProfile = oldSimProfile;
    }

    public String getOldMinDllExch() {
        return oldMinDllExch;
    }

    public void setOldMinDllExch(String oldMinDllExch) {
        this.oldMinDllExch = oldMinDllExch;
    }

    public String getOldMaxDllExch() {
        return oldMaxDllExch;
    }

    public void setOldMaxDllExch(String oldMaxDllExch) {
        this.oldMaxDllExch = oldMaxDllExch;
    }

    public String getOldRank() {
        return oldRank;
    }

    public void setOldRank(String oldRank) {
        this.oldRank = oldRank;
    }

    @Override
    public String toString() {
        return "TracfoneOneCarriersimpref{" +
                "rank='" + rank + '\'' +
                ", minDllExch='" + minDllExch + '\'' +
                ", maxDllExch='" + maxDllExch + '\'' +
                ", carrierName='" + carrierName + '\'' +
                ", simProfile='" + simProfile + '\'' +
                '}';
    }
}
