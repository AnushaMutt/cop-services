package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;

/**
 * TABLE: table_x_carrier
 *
 * @author Pritesh Singh
 */
public class TracfoneOneCarrier {
    private String dbEnv;
    @Digits(integer = 38, fraction = 0, message = "ObjId must be a number")
    private String objId;
    @Digits(integer = 38, fraction = 0, message = "Carrier Id must be a number")
    private String carrierId;
    @Size(min = 1, message = "Sub Market Name cannot be null")
    @Size(max = 30, message = "Sub Market Name cannot have more than 30 characters")
    private String submarketName;
    @Digits(integer = 38, fraction = 0, message = "Sub Market Of must be a number")
    private String submarketOf;
    @Size(max = 30, message = "City cannot have more than 30 characters")
    private String city;
    @Size(max = 30, message = "State cannot have more than 30 characters")
    private String state;
    @Digits(integer = 6, fraction = 2, message = "Tape Return Charge must be a number")
    private String tapeReturnCharge;
    @Digits(integer = 38, fraction = 0, message = "Country Code must be a number")
    private String countryCode;
    @Digits(integer = 16, fraction = 16, message = "Active Line Percent must be a number")
    private String activeLinePercent;
    @Size(min = 1, message = "Status cannot be null")
    @Size(max = 20, message = "Status cannot have more than 20 characters")
    private String status;
    @Size(max = 30, message = "LD Provider cannot have more than 30 characters")
    private String ldProvider;
    @Size(max = 50, message = "LD Account cannot have more than 50 characters")
    private String ldAccount;
    @Size(max = 50, message = "LD Pic Code cannot have more than 50 characters")
    private String ldPicCode;
    @Size(max = 60, message = "Rate Plan cannot have more than 60 characters")
    private String ratePlan;
    @Size(max = 10, message = "Dummy ESN cannot have more than 10 characters")
    private String dummyEsn;
    private String billDate;
    @Digits(integer = 38, fraction = 0, message = "Voice Mail must be a number")
    private String voiceMail;
    @Size(max = 30, message = "VM Code cannot have more than 30 characters")
    private String vmCode;
    @Digits(integer = 38, fraction = 0, message = "VM Package must be a number")
    private String vmPackage;
    @Digits(integer = 38, fraction = 0, message = "Caller Id must be a number")
    private String callerId;
    @Size(max = 30, message = "Id Code cannot have more than 30 characters")
    private String idCode;
    @Digits(integer = 38, fraction = 0, message = "Id Package must be a number")
    private String idPackage;
    @Digits(integer = 38, fraction = 0, message = "Call Waiting must be a number")
    private String callWaiting;
    @Size(max = 30, message = "CW Code cannot have more than 30 characters")
    private String cwCode;
    @Digits(integer = 38, fraction = 0, message = "CW Package must be a number")
    private String cwPackage;
    @Size(max = 30, message = "React Technology cannot have more than 30 characters")
    private String reactTechnology;
    @Digits(integer = 38, fraction = 0, message = "React Analog must be a number")
    private String reactAnalog;
    @Size(max = 20, message = "Act Technology cannot have more than 20 characters")
    private String actTechnology;
    @Digits(integer = 38, fraction = 0, message = "Act Analog must be a number")
    private String actAnalog;
    @Size(max = 60, message = "Digital Rate Plan cannot have more than 60 characters")
    private String digitalRatePlan;
    @Size(max = 30, message = "Digital Feature cannot have more than 30 characters")
    private String digitalFeature;
    @Digits(integer = 38, fraction = 0, message = "PRL Pre Loaded must be a number")
    private String prlPreLoaded;
    private List<String> carrier2CarrierGroups;
    @Digits(integer = 38, fraction = 0, message = "Tape Return Addr2Address must be a number")
    private String tapeReturnAddr2Address;
    @Digits(integer = 38, fraction = 0, message = "Carrier2Provider must be a number")
    private String carrier2Provider;
    @Digits(integer = 38, fraction = 0, message = "Carrier2Address must be a number")
    private String carrier2Address;
    @Digits(integer = 38, fraction = 0, message = "Carrier2Personality must be a number")
    private String carrier2Personality;
    @Digits(integer = 38, fraction = 0, message = "Carrier2Rule must be a number")
    private String carrier2Rule;
    @Digits(integer = 38, fraction = 0, message = "Carrier2Carr Script must be a number")
    private String carrier2CarrScript;
    @Digits(integer = 38, fraction = 0, message = "Special Mkt must be a number")
    private String specialMkt;
    @Size(max = 30, message = "New Analog Plan have more than 30 characters")
    private String newAnalogPlan;
    @Size(max = 30, message = "New Digital Plan cannot have more than 30 characters")
    private String newDigitalPlan;
    @Digits(integer = 38, fraction = 0, message = "Sms must be a number")
    private String sms;
    @Size(max = 30, message = "Sms Code cannot have more than 30 characters")
    private String smsCode;
    @Digits(integer = 38, fraction = 0, message = "Sms Package must be a number")
    private String smsPackage;
    @Digits(integer = 38, fraction = 0, message = "VM SetUp Land Line must be a number")
    private String vmSetUpLandLine;
    @Digits(integer = 38, fraction = 0, message = "Carrier2RulesCdma must be a number")
    private String carrier2RulesCdma;
    @Digits(integer = 38, fraction = 0, message = "Carrier2RulesGsm must be a number")
    private String carrier2RulesGsm;
    @Digits(integer = 38, fraction = 0, message = "Carrier2RulesTdma must be a number")
    private String carrier2RulesTdma;
    @Digits(integer = 38, fraction = 0, message = "Data Service must be a number")
    private String dataService;
    @Digits(integer = 38, fraction = 0, message = "Automated must be a number")
    private String automated;

    public TracfoneOneCarrier() {
        carrier2CarrierGroups = new ArrayList<>();
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(String carrierId) {
        this.carrierId = carrierId;
    }

    public String getSubmarketName() {
        return submarketName;
    }

    public void setSubmarketName(String submarketName) {
        this.submarketName = submarketName;
    }

    public String getSubmarketOf() {
        return submarketOf;
    }

    public void setSubmarketOf(String submarketOf) {
        this.submarketOf = submarketOf;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getTapeReturnCharge() {
        return tapeReturnCharge;
    }

    public void setTapeReturnCharge(String tapeReturnCharge) {
        this.tapeReturnCharge = tapeReturnCharge;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getActiveLinePercent() {
        return activeLinePercent;
    }

    public void setActiveLinePercent(String activeLinePercent) {
        this.activeLinePercent = activeLinePercent;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLdProvider() {
        return ldProvider;
    }

    public void setLdProvider(String ldProvider) {
        this.ldProvider = ldProvider;
    }

    public String getLdAccount() {
        return ldAccount;
    }

    public void setLdAccount(String ldAccount) {
        this.ldAccount = ldAccount;
    }

    public String getLdPicCode() {
        return ldPicCode;
    }

    public void setLdPicCode(String ldPicCode) {
        this.ldPicCode = ldPicCode;
    }

    public String getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(String ratePlan) {
        this.ratePlan = ratePlan;
    }

    public String getDummyEsn() {
        return dummyEsn;
    }

    public void setDummyEsn(String dummyEsn) {
        this.dummyEsn = dummyEsn;
    }

    public String getBillDate() {
        return billDate;
    }

    public void setBillDate(String billDate) {
        this.billDate = billDate;
    }

    public String getVoiceMail() {
        return voiceMail;
    }

    public void setVoiceMail(String voiceMail) {
        this.voiceMail = voiceMail;
    }

    public String getVmCode() {
        return vmCode;
    }

    public void setVmCode(String vmCode) {
        this.vmCode = vmCode;
    }

    public String getVmPackage() {
        return vmPackage;
    }

    public void setVmPackage(String vmPackage) {
        this.vmPackage = vmPackage;
    }

    public String getCallerId() {
        return callerId;
    }

    public void setCallerId(String callerId) {
        this.callerId = callerId;
    }

    public String getIdCode() {
        return idCode;
    }

    public void setIdCode(String idCode) {
        this.idCode = idCode;
    }

    public String getIdPackage() {
        return idPackage;
    }

    public void setIdPackage(String idPackage) {
        this.idPackage = idPackage;
    }

    public String getCallWaiting() {
        return callWaiting;
    }

    public void setCallWaiting(String callWaiting) {
        this.callWaiting = callWaiting;
    }

    public String getCwCode() {
        return cwCode;
    }

    public void setCwCode(String cwCode) {
        this.cwCode = cwCode;
    }

    public String getCwPackage() {
        return cwPackage;
    }

    public void setCwPackage(String cwPackage) {
        this.cwPackage = cwPackage;
    }

    public String getReactTechnology() {
        return reactTechnology;
    }

    public void setReactTechnology(String reactTechnology) {
        this.reactTechnology = reactTechnology;
    }

    public String getReactAnalog() {
        return reactAnalog;
    }

    public void setReactAnalog(String reactAnalog) {
        this.reactAnalog = reactAnalog;
    }

    public String getActTechnology() {
        return actTechnology;
    }

    public void setActTechnology(String actTechnology) {
        this.actTechnology = actTechnology;
    }

    public String getActAnalog() {
        return actAnalog;
    }

    public void setActAnalog(String actAnalog) {
        this.actAnalog = actAnalog;
    }

    public String getDigitalRatePlan() {
        return digitalRatePlan;
    }

    public void setDigitalRatePlan(String digitalRatePlan) {
        this.digitalRatePlan = digitalRatePlan;
    }

    public String getDigitalFeature() {
        return digitalFeature;
    }

    public void setDigitalFeature(String digitalFeature) {
        this.digitalFeature = digitalFeature;
    }

    public String getPrlPreLoaded() {
        return prlPreLoaded;
    }

    public void setPrlPreLoaded(String prlPreLoaded) {
        this.prlPreLoaded = prlPreLoaded;
    }

    public List<String> getCarrier2CarrierGroups() {
        return carrier2CarrierGroups;
    }

    public void setCarrier2CarrierGroups(List<String> carrier2CarrierGroups) {
        this.carrier2CarrierGroups = carrier2CarrierGroups;
    }

    public String getTapeReturnAddr2Address() {
        return tapeReturnAddr2Address;
    }

    public void setTapeReturnAddr2Address(String tapeReturnAddr2Address) {
        this.tapeReturnAddr2Address = tapeReturnAddr2Address;
    }

    public String getCarrier2Provider() {
        return carrier2Provider;
    }

    public void setCarrier2Provider(String carrier2Provider) {
        this.carrier2Provider = carrier2Provider;
    }

    public String getCarrier2Address() {
        return carrier2Address;
    }

    public void setCarrier2Address(String carrier2Address) {
        this.carrier2Address = carrier2Address;
    }

    public String getCarrier2Personality() {
        return carrier2Personality;
    }

    public void setCarrier2Personality(String carrier2Personality) {
        this.carrier2Personality = carrier2Personality;
    }

    public String getCarrier2Rule() {
        return carrier2Rule;
    }

    public void setCarrier2Rule(String carrier2Rule) {
        this.carrier2Rule = carrier2Rule;
    }

    public String getCarrier2CarrScript() {
        return carrier2CarrScript;
    }

    public void setCarrier2CarrScript(String carrier2CarrScript) {
        this.carrier2CarrScript = carrier2CarrScript;
    }

    public String getSpecialMkt() {
        return specialMkt;
    }

    public void setSpecialMkt(String specialMkt) {
        this.specialMkt = specialMkt;
    }

    public String getNewAnalogPlan() {
        return newAnalogPlan;
    }

    public void setNewAnalogPlan(String newAnalogPlan) {
        this.newAnalogPlan = newAnalogPlan;
    }

    public String getNewDigitalPlan() {
        return newDigitalPlan;
    }

    public void setNewDigitalPlan(String newDigitalPlan) {
        this.newDigitalPlan = newDigitalPlan;
    }

    public String getSms() {
        return sms;
    }

    public void setSms(String sms) {
        this.sms = sms;
    }

    public String getSmsCode() {
        return smsCode;
    }

    public void setSmsCode(String smsCode) {
        this.smsCode = smsCode;
    }

    public String getSmsPackage() {
        return smsPackage;
    }

    public void setSmsPackage(String smsPackage) {
        this.smsPackage = smsPackage;
    }

    public String getVmSetUpLandLine() {
        return vmSetUpLandLine;
    }

    public void setVmSetUpLandLine(String vmSetUpLandLine) {
        this.vmSetUpLandLine = vmSetUpLandLine;
    }

    public String getCarrier2RulesCdma() {
        return carrier2RulesCdma;
    }

    public void setCarrier2RulesCdma(String carrier2RulesCdma) {
        this.carrier2RulesCdma = carrier2RulesCdma;
    }

    public String getCarrier2RulesGsm() {
        return carrier2RulesGsm;
    }

    public void setCarrier2RulesGsm(String carrier2RulesGsm) {
        this.carrier2RulesGsm = carrier2RulesGsm;
    }

    public String getCarrier2RulesTdma() {
        return carrier2RulesTdma;
    }

    public void setCarrier2RulesTdma(String carrier2RulesTdma) {
        this.carrier2RulesTdma = carrier2RulesTdma;
    }

    public String getDataService() {
        return dataService;
    }

    public void setDataService(String dataService) {
        this.dataService = dataService;
    }

    public String getAutomated() {
        return automated;
    }

    public void setAutomated(String automated) {
        this.automated = automated;
    }

    @Override
    public String toString() {
        return "TracfoneOneCarrier{" +
                "dbEnv='" + dbEnv + '\'' +
                ", objId='" + objId + '\'' +
                ", carrierId='" + carrierId + '\'' +
                ", submarketName='" + submarketName + '\'' +
                ", submarketOf='" + submarketOf + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", tapereturnCharge='" + tapeReturnCharge + '\'' +
                ", countryCode='" + countryCode + '\'' +
                ", activelinePercent='" + activeLinePercent + '\'' +
                ", status='" + status + '\'' +
                ", ldProvider='" + ldProvider + '\'' +
                ", ldAccount='" + ldAccount + '\'' +
                ", ldPicCode='" + ldPicCode + '\'' +
                ", ratePlan='" + ratePlan + '\'' +
                ", dummyEsn='" + dummyEsn + '\'' +
                ", billDate='" + billDate + '\'' +
                ", voiceMail='" + voiceMail + '\'' +
                ", vmCode='" + vmCode + '\'' +
                ", vmPackage='" + vmPackage + '\'' +
                ", callerId='" + callerId + '\'' +
                ", idCode='" + idCode + '\'' +
                ", idPackage='" + idPackage + '\'' +
                ", callWaiting='" + callWaiting + '\'' +
                ", cwCode='" + cwCode + '\'' +
                ", cwPackage='" + cwPackage + '\'' +
                ", reactTechnology='" + reactTechnology + '\'' +
                ", reactAnalog='" + reactAnalog + '\'' +
                ", actTechnology='" + actTechnology + '\'' +
                ", actAnalog='" + actAnalog + '\'' +
                ", digitalRatePlan='" + digitalRatePlan + '\'' +
                ", digitalFeature='" + digitalFeature + '\'' +
                ", prlPreLoaded='" + prlPreLoaded + '\'' +
                ", carrier2CarrierGroups='" + carrier2CarrierGroups + '\'' +
                ", tapereturnAddr2Address='" + tapeReturnAddr2Address + '\'' +
                ", carrier2Provider='" + carrier2Provider + '\'' +
                ", carrier2Address='" + carrier2Address + '\'' +
                ", carrier2Personality='" + carrier2Personality + '\'' +
                ", carrier2Rule='" + carrier2Rule + '\'' +
                ", carrier2CarrScript='" + carrier2CarrScript + '\'' +
                ", specialMkt='" + specialMkt + '\'' +
                ", newAnalogPlan='" + newAnalogPlan + '\'' +
                ", newDigitalPlan='" + newDigitalPlan + '\'' +
                ", sms='" + sms + '\'' +
                ", smsCode='" + smsCode + '\'' +
                ", smsPackage='" + smsPackage + '\'' +
                ", vmSetUpLandLine='" + vmSetUpLandLine + '\'' +
                ", carrier2RulesCdma='" + carrier2RulesCdma + '\'' +
                ", carrier2RulesGsm='" + carrier2RulesGsm + '\'' +
                ", carrier2RulesTdma='" + carrier2RulesTdma + '\'' +
                ", dataService='" + dataService + '\'' +
                ", automated='" + automated + '\'' +
                '}';
    }
}
