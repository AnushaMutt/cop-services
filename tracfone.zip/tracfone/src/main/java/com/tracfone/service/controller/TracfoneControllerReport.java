/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.controller;

import com.google.gson.Gson;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.report.TFOneReportMonitor;
import com.tracfone.service.model.report.TFOneReportPCRFMonitor;
import com.tracfone.service.model.report.TFOneReportTTMonitor;
import com.tracfone.service.model.report.TracfoneAdhocReportRequest;
import com.tracfone.service.model.response.TracfoneOneReport;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * @author spulavarthy
 */
@Stateless
public class TracfoneControllerReport implements TracfoneControllerReportLocal, TracfoneOneConstantReport {
    private static Logger logger = LogManager.getLogger(TracfoneControllerReport.class);

    @Resource(lookup = "jndi/cop_report")
    private DataSource dataSourceReports;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @Override
    public TracfoneOneReport runAdhocMonitorReport(TracfoneAdhocReportRequest request) throws TracfoneOneException {
        TracfoneOneReport reportResult;
        try (Connection con = dataSourceReports.getConnection();
             PreparedStatement stmt = con.prepareStatement(REPORT_SQL_MONITOR_ADHOC);) {
            stmt.setString(1, request.getFromDate());
            stmt.setString(2, request.getToDate());
            List<TFOneReportMonitor> topIgErrorsReport = new ArrayList<>();
            try (ResultSet resultSet = stmt.executeQuery();) {
                TFOneReportMonitor tfOneReportMonitor = null;
                while (resultSet.next()) {
                    tfOneReportMonitor = new TFOneReportMonitor();
                    tfOneReportMonitor.setxDate(resultSet.getString("X_DATE"));
                    tfOneReportMonitor.setTemplate(resultSet.getString("TEMPLATE"));
                    tfOneReportMonitor.setOrderType(resultSet.getString("ORDER_TYPE"));
                    tfOneReportMonitor.setSumAllQ(resultSet.getString("SUM_ALL_Q"));
                    tfOneReportMonitor.setSumAllL(resultSet.getString("SUM_ALL_L"));
                    tfOneReportMonitor.setSumAllCp(resultSet.getString("SUM_ALL_CP"));
                    tfOneReportMonitor.setSumAllWp(resultSet.getString("SUM_ALL_WP"));
                    tfOneReportMonitor.setSumAllW(resultSet.getString("SUM_ALL_W"));
                    tfOneReportMonitor.setSumAllS(resultSet.getString("SUM_ALL_S"));
                    tfOneReportMonitor.setSumAllE(resultSet.getString("SUM_ALL_E"));
                    tfOneReportMonitor.setSumAllF(resultSet.getString("SUM_ALL_F"));
                    tfOneReportMonitor.setTransType(resultSet.getString("TRANS_TYPE"));
                    tfOneReportMonitor.setSumAllTf(resultSet.getString("SUM_ALL_TF"));
                    tfOneReportMonitor.setSumAllHw(resultSet.getString("SUM_ALL_HW"));
                    topIgErrorsReport.add(tfOneReportMonitor);
                }
            }

            Gson gson = new Gson();
            reportResult = new TracfoneOneReport();
            reportResult.setJsonResponse(gson.toJson(topIgErrorsReport));
            reportResult.setReportName(TracfoneOneConstantReport.TRACFONE_REPORTNAME_MONITOR);
            reportResult.setCreateDate(Calendar.getInstance().getTime());
            reportResult.setReportSQL(TracfoneOneConstantReport.REPORT_SQL_MONITOR_ADHOC);
        } catch (Exception ex) {
            logger.error(ex);
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_REPORT_ADHOC_MONITOR_ERROR_CODE, TracfoneOneConstant.TRACFONE_REPORT_ADHOC_MONITOR_ERROR_MESSAGE, ex);
        }
        return reportResult;
    }

    @Override
    public TracfoneOneReport runAdhocTTMonitorReport(TracfoneAdhocReportRequest adhocReportRequest) throws TracfoneOneException {
        TracfoneOneReport reportResult;
        try (Connection con = dataSourceReports.getConnection();
             PreparedStatement stmt = con.prepareStatement(REPORT_SQL_TT_MONITOR_ADHOC);) {
            stmt.setString(1, adhocReportRequest.getFromDate());
            stmt.setString(2, adhocReportRequest.getToDate());
            List<TFOneReportTTMonitor> topTTErrorsReport = new ArrayList<>();
            try (ResultSet resultSet = stmt.executeQuery();) {
                TFOneReportTTMonitor tfOneReportTTMonitor = null;
                while (resultSet.next()) {
                    tfOneReportTTMonitor = new TFOneReportTTMonitor();
                    tfOneReportTTMonitor.setCarrier(resultSet.getString("x_carrier"));
                    tfOneReportTTMonitor.setTransNum(resultSet.getString("x_transaction_num"));
                    tfOneReportTTMonitor.setxDate(resultSet.getString("x_date"));
                    tfOneReportTTMonitor.setTransType(resultSet.getString("x_transact_type"));
                    tfOneReportTTMonitor.setSumAllQ(resultSet.getString("sum_all_q"));
                    tfOneReportTTMonitor.setSumAllL(resultSet.getString("sum_all_l"));
                    tfOneReportTTMonitor.setSumAllCp(resultSet.getString("sum_all_cp"));
                    tfOneReportTTMonitor.setSumAllS(resultSet.getString("sum_all_s"));
                    tfOneReportTTMonitor.setSumAllNt(resultSet.getString("sum_all_nt"));
                    tfOneReportTTMonitor.setSumAllE(resultSet.getString("sum_all_e"));
                    tfOneReportTTMonitor.setSumAllC(resultSet.getString("sum_all_c"));
                    tfOneReportTTMonitor.setSumAllTf(resultSet.getString("sum_all_tf"));
                    tfOneReportTTMonitor.setSumOther(resultSet.getString("sum_other"));
                    tfOneReportTTMonitor.setTotalTransCount(resultSet.getString("total_trans_count"));
                    tfOneReportTTMonitor.setTotalTransSegment(resultSet.getString("total_trans_by_segment"));
                    tfOneReportTTMonitor.setFailureCount(resultSet.getString("failure_count"));
                    tfOneReportTTMonitor.setComp11Min(resultSet.getString("comp_11_min"));
                    tfOneReportTTMonitor.setComp15Min(resultSet.getString("comp_15_min"));
                    tfOneReportTTMonitor.setComp30Min(resultSet.getString("comp_30_min"));
                    tfOneReportTTMonitor.setCompGt30Min(resultSet.getString("comp_GT30_min"));
                    topTTErrorsReport.add(tfOneReportTTMonitor);
                }
            }

            Gson gson = new Gson();
            reportResult = new TracfoneOneReport();
            reportResult.setJsonResponse(gson.toJson(topTTErrorsReport));
            reportResult.setReportName(TracfoneOneConstantReport.TRACFONE_REPORTNAME_TT_MONITOR);
            reportResult.setCreateDate(Calendar.getInstance().getTime());
            reportResult.setReportSQL(TracfoneOneConstantReport.REPORT_SQL_TT_MONITOR_ADHOC);
        } catch (Exception ex) {
            logger.error(ex);
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_REPORT_ADHOC_TT_MONITOR_ERROR_CODE, TracfoneOneConstant.TRACFONE_REPORT_ADHOC_TT_MONITOR_ERROR_MESSAGE, ex);
        }
        return reportResult;
    }

    @Override
    public TracfoneOneReport runAdhocPCRFMonitorReport(TracfoneAdhocReportRequest adhocReportRequest) throws TracfoneOneException {
        TracfoneOneReport reportResult;
        try (Connection con = dataSourceReports.getConnection();
             PreparedStatement stmt = con.prepareStatement(REPORT_SQL_PCRF_MONITOR_ADHOC);) {
            stmt.setString(1, adhocReportRequest.getFromDate());
            stmt.setString(2, adhocReportRequest.getToDate());
            List<TFOneReportPCRFMonitor> pcrfMonitorReports = new ArrayList<>();
            try (ResultSet resultSet = stmt.executeQuery();) {
                TFOneReportPCRFMonitor pcrfMonitorReport = null;
                while (resultSet.next()) {
                    pcrfMonitorReport = new TFOneReportPCRFMonitor();
                    pcrfMonitorReport.setxDate(resultSet.getString("insert_timestamp"));
                    pcrfMonitorReport.setPcrfParentName(resultSet.getString("pcrf_parent_name"));
                    pcrfMonitorReport.setOrderType(resultSet.getString("order_type"));
                    pcrfMonitorReport.setSumQ(resultSet.getString("sum_Q"));
                    pcrfMonitorReport.setSumL(resultSet.getString("sum_L"));
                    pcrfMonitorReport.setSumW(resultSet.getString("sum_W"));
                    pcrfMonitorReport.setSumS(resultSet.getString("sum_S"));
                    pcrfMonitorReport.setSumC(resultSet.getString("sum_C"));
                    pcrfMonitorReport.setSumF(resultSet.getString("sum_F"));
                    pcrfMonitorReport.setSumE(resultSet.getString("sum_E"));
                    pcrfMonitorReport.setSumOthers(resultSet.getString("sum_others"));
                    pcrfMonitorReports.add(pcrfMonitorReport);
                }
            }

            Gson gson = new Gson();
            reportResult = new TracfoneOneReport();
            reportResult.setJsonResponse(gson.toJson(pcrfMonitorReports));
            reportResult.setReportName(TracfoneOneConstantReport.TRACFONE_REPORTNAME_PCRF_MONITOR);
            reportResult.setCreateDate(Calendar.getInstance().getTime());
            reportResult.setReportSQL(TracfoneOneConstantReport.REPORT_SQL_PCRF_MONITOR_ADHOC);
        } catch (Exception ex) {
            logger.error(ex);
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_REPORT_ADHOC_PCRF_MONITOR_ERROR_CODE, TracfoneOneConstant.TRACFONE_REPORT_ADHOC_PCRF_MONITOR_ERROR_MESSAGE, ex);
        }
        return reportResult;
    }

}
