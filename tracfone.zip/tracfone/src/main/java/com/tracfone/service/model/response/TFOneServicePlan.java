/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

import java.util.List;

/**
 *
 * @author Raul Martinez
 */
public class TFOneServicePlan {
    
    String servicePlanName;    
    String servicePlanId;    
    String customerPrice;
    List<TFOneRatePlanProfile> ratePlanProfile;

    public String getServicePlanName() {
        return servicePlanName;
    }

    public void setServicePlanName(String servicePlanName) {
        this.servicePlanName = servicePlanName;
    }

    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public String getCustomerPrice() {
        return customerPrice;
    }

    public void setCustomerPrice(String customerPrice) {
        this.customerPrice = customerPrice;
    }

    public List<TFOneRatePlanProfile> getRatePlanProfiles() {
        return ratePlanProfile;
    }

    public void setRatePlanProfiles(List<TFOneRatePlanProfile> ratePlanProfiles) {
        this.ratePlanProfile = ratePlanProfiles;
    }
            
}
