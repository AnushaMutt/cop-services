package com.tracfone.service.report.workers.throttle;

import com.tracfone.service.model.report.TFOneReportTTGraphReport;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Resource;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author Gaurav.Sharma
 */
@Stateless
public class MonitorTTGraphWorkerBean {

    @Resource(lookup = "jndi/cop_report")
    private DataSource dataSourceReports;

    private AtomicBoolean busy = new AtomicBoolean(false);

    private static final Logger LOGGER = LogManager.getLogger(MonitorTTGraphWorkerBean.class);

    @Lock(LockType.READ)
    public List<TFOneReportTTGraphReport> runTTMonitorGraphReport() {
        List<TFOneReportTTGraphReport> ttMonitorGraphReport = new ArrayList<>();

        if (!busy.compareAndSet(false, true)) {
            return ttMonitorGraphReport;
        }

        try (Connection con = dataSourceReports.getConnection();) {
            LOGGER.debug("Throttle Monitor Graph report - Going to Got a connection");
            try (PreparedStatement stmt = con.prepareStatement(TracfoneOneConstantReport.REPORT_SQL_TT_MONITOR_GRAPH_VIEW);
                 ResultSet resultSet = stmt.executeQuery();) {
                LOGGER.debug("Throttle Monitor Graph report - Going to retrieve the report");
                while (resultSet.next()) {
                    TFOneReportTTGraphReport tfOneReportGraphMonitor = new TFOneReportTTGraphReport();
                    tfOneReportGraphMonitor.setTemplate(resultSet.getString("x_carrier"));
                    tfOneReportGraphMonitor.setOrderType(resultSet.getString("x_transact_type"));
                    tfOneReportGraphMonitor.setStatus(resultSet.getString("x_status"));
                    tfOneReportGraphMonitor.setCount(resultSet.getString("COUNT"));
                    ttMonitorGraphReport.add(tfOneReportGraphMonitor);
                }
            }
        } catch (Exception e) {
            LOGGER.error("Throttle Monitor Graph report retrieval error - ", e);
        } finally {
            busy.set(false);
        }
        return ttMonitorGraphReport;
    }
}
