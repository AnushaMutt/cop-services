/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.response;

import java.util.List;

/**
 *
 * @author Srinivas Murthy Pulavarthy
 */
public class TFOneAdminGroup {

    private String groupId;
    private String groupName;
    private String groupDescription;
    private List<TFOneAdminAction> tfActions;

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupDescription() {
        return groupDescription;
    }

    public void setGroupDescription(String groupDescription) {
        this.groupDescription = groupDescription;
    }

    public List<TFOneAdminAction> getTfActions() {
        return tfActions;
    }

    public void setTfActions(List<TFOneAdminAction> tfActions) {
        this.tfActions = tfActions;
    }

}
