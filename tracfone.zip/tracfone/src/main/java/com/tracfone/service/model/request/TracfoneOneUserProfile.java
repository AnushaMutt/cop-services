
package com.tracfone.service.model.request;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author druiz
 */
@XmlRootElement(name = "UserProfile")
public class TracfoneOneUserProfile {
    public static final short ENABLED = 1; 
    public static final short DISABLED = 0; 
    
    @XmlElement(name = "tfUser")
    private TracfoneOneUser tfUser;
        
    @XmlElement(name = "tfGroups")
    private List<TracfoneOneGroup> tfGroups;

    @XmlElement(name = "tfRole")
    private TracfoneOneRole tfRole;

    public TracfoneOneUser getTfUser() {
        return tfUser;
    }

    public void setTfUser(TracfoneOneUser tfUser) {
        this.tfUser = tfUser;
    }

    public List<TracfoneOneGroup> getTfGroups() {
        return tfGroups;
    }

    public void setTfGroups(List<TracfoneOneGroup> tfGroups) {
        this.tfGroups = tfGroups;
    }

    public TracfoneOneRole getTfRole() {
        return tfRole;
    }

    public void setTfRole(TracfoneOneRole tfRole) {
        this.tfRole = tfRole;
    }
}
