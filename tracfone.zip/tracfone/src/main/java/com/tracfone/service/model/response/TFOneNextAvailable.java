package com.tracfone.service.model.response;

/**
 *
 * @author Thejaswini
 */
public class TFOneNextAvailable {
    private String zipCode;
    private String xType;
    private String ngp;
    private String ngpName;
    private String state;
    private String subMarket;
    private String rateCente;

    public TFOneNextAvailable(String zipCode, String xType, String ngp, String ngpName, String state, String subMarket, String rateCente) {
        this.zipCode = zipCode;
        this.xType = xType;
        this.ngp = ngp;
        this.ngpName = ngpName;
        this.state = state;
        this.subMarket = subMarket;
        this.rateCente = rateCente;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getxType() {
        return xType;
    }

    public void setxType(String xType) {
        this.xType = xType;
    }

    public String getNgp() {
        return ngp;
    }

    public void setNgp(String ngp) {
        this.ngp = ngp;
    }

    public String getNgpName() {
        return ngpName;
    }

    public void setNgpName(String ngpName) {
        this.ngpName = ngpName;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getSubMarket() {
        return subMarket;
    }

    public void setSubMarket(String subMarket) {
        this.subMarket = subMarket;
    }

    public String getRateCente() {
        return rateCente;
    }

    public void setRateCente(String rateCente) {
        this.rateCente = rateCente;
    }

    @Override
    public String toString() {
        return "TFOneNextAvailable{" +
                "zipCode='" + zipCode + '\'' +
                ", xType='" + xType + '\'' +
                ", ngp='" + ngp + '\'' +
                ", ngpName='" + ngpName + '\'' +
                ", state='" + state + '\'' +
                ", subMarket='" + subMarket + '\'' +
                ", rateCente='" + rateCente + '\'' +
                '}';
    }
}
