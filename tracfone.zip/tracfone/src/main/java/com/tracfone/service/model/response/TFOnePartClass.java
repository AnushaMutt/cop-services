package com.tracfone.service.model.response;

public class TFOnePartClass {
    private String objId;
    private String name;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "TracfoneOnePartClass{" +
                ", objId='" + objId + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}

