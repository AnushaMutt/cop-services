/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneAncillaryCode;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeConfig;
import com.tracfone.service.model.request.TracfoneOneAncillaryCodeDiscount;
import com.tracfone.service.model.request.TracfoneOneChildPlan;
import com.tracfone.service.model.request.TracfoneOneLineStatusCode;
import com.tracfone.service.model.request.TracfoneOneMultiRatePlanEsn;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtension;
import com.tracfone.service.model.request.TracfoneOneRatePlanExtensionLink;
import com.tracfone.service.model.request.TracfoneOneRatePlanProfile;
import com.tracfone.service.model.request.TracfoneOneSearchProfileModel;
import com.tracfone.service.model.request.TracfoneOneThrottleStatusCode;
import com.tracfone.service.model.response.TFOneAncillaryCode;
import com.tracfone.service.model.response.TFOneAncillaryCodeConfig;
import com.tracfone.service.model.response.TFOneAncillaryCodeDiscount;
import com.tracfone.service.model.response.TFOneCarrierServicePlan;
import com.tracfone.service.model.response.TFOneChildPlan;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TFOneMultiRatePlanEsn;
import com.tracfone.service.model.response.TFOneRatePlanExtension;
import com.tracfone.service.model.response.TFOneRatePlanProfile;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE;
import com.tracfone.service.util.TracfoneOneConstantPlanWizard;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.enterprise.event.Event;
import javax.inject.Inject;

/**
 * @author Shireen Fathima
 */
@Stateless
public class TracfoneProfileController implements TracfoneProfileControllerLocal, TracfoneOneConstantPlanWizard {
    private static final Logger LOGGER = LogManager.getLogger(TracfoneProfileController.class);

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @EJB
    TracfoneProfileLocalAction tracfoneProfileLocalAction;

    @Override
    public TFOneGeneralResponse insertProfile(TracfoneOneRatePlanProfile tfRatePlanProfile, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        validateProfileAlreadyExists(tfRatePlanProfile, false);
        try {
            response = tracfoneProfileLocalAction.insertProfile(tfRatePlanProfile, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_PROFILE_ERROR, TRACFONE_ADD_PROFILE_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneRatePlanProfile viewProfile(TracfoneOneRatePlanProfile tfRatePlanProfile) throws TracfoneOneException {
        TFOneRatePlanProfile tfOneRatePlanProfile = null;
        try {
            tfOneRatePlanProfile = tracfoneProfileLocalAction.viewProfile(tfRatePlanProfile);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_VIEW_PROFILE_ERROR, TRACFONE_VIEW_PROFILE_ERROR_MESSAGE, ex);
        }

        return tfOneRatePlanProfile;
    }

    @Override
    public TFOneGeneralResponse updateProfile(TracfoneOneRatePlanProfile tfRatePlanProfile, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        validateProfileAlreadyExists(tfRatePlanProfile, true);
        try {
            response = tracfoneProfileLocalAction.updateProfile(tfRatePlanProfile, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_PROFILE_ERROR, TRACFONE_UPDATE_PROFILE_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneGeneralResponse deleteProfile(TracfoneOneRatePlanProfile tfRatePlanProfile, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            List<String> idToBeDeleted = new ArrayList<>();
            idToBeDeleted.add(tfRatePlanProfile.getProfileId());
            response = tracfoneProfileLocalAction.deleteProfile(tfRatePlanProfile.getDbEnv(), idToBeDeleted, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_PROFILE_ERROR, TRACFONE_DELETE_PROFILE_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<TFOneAncillaryCode> getAllAncillaryCodes(String dbEnv) throws TracfoneOneException {
        List<TFOneAncillaryCode> allAncillaryCodes;
        try {
            allAncillaryCodes = tracfoneProfileLocalAction.getAllAncillaryCodes(dbEnv);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_VIEW_ALL_ANCILLARY_CODES_ERROR, TRACFONE_VIEW_ALL_ANCILLARY_CODES_ERROR_MESSAGE, ex);
        }

        return allAncillaryCodes;
    }

    /**
     * For add I can just check for duplicates based on profile description but
     * for edit I need to ensure the profile I pull is not the same as the one I
     * am sending based on the profile id.
     *
     * @param tfRatePlanProfile
     * @param isUpdate
     * @throws TracfoneOneException
     */
    private void validateProfileAlreadyExists(TracfoneOneRatePlanProfile tfRatePlanProfile, boolean isUpdate) throws TracfoneOneException {
        TracfoneOneRatePlanProfile searchProfile = new TracfoneOneRatePlanProfile();
        searchProfile.setDbEnv(tfRatePlanProfile.getDbEnv());
        searchProfile.setProfileDescription(tfRatePlanProfile.getProfileDescription().trim());
        TFOneRatePlanProfile profile = tracfoneProfileLocalAction.viewProfile(searchProfile);
        if (null != profile && !StringUtils.isNullOrEmpty(profile.getProfileId())) {
            if (!isUpdate
                    || (!StringUtils.isNullOrEmpty(tfRatePlanProfile.getProfileId()) && !tfRatePlanProfile.getProfileId().equals(profile.getProfileId()))) {
                throw new TracfoneOneException(TRACFONE_DUPLICATE_PROFILE_ERROR, TRACFONE_DUPLICATE_PROFILE_ERROR_MESSAGE);
            }
        }
    }

    @Override
    public List<TFOneChildPlan> getAllChildPlans(String dbEnv) throws TracfoneOneException {
        List<TFOneChildPlan> allChildPlans;
        try {
            allChildPlans = tracfoneProfileLocalAction.getAllChildPlans(dbEnv);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_VIEW_ALL_CHILD_PLANS_ERROR, TRACFONE_VIEW_ALL_CHILD_PLANS_ERROR_MESSAGE, ex);
        }

        return allChildPlans;
    }

    @Override
    public List<TFOneRatePlanProfile> searchProfile(TracfoneOneSearchProfileModel tfRatePlanProfile) throws TracfoneOneException {
        List<TFOneRatePlanProfile> filteredProfiles = null;
        try {
            filteredProfiles = tracfoneProfileLocalAction.searchProfile(tfRatePlanProfile);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_PROFILE_ERROR, TRACFONE_SEARCH_PROFILE_ERROR_MESSAGE, ex);
        }

        return filteredProfiles;
    }

    @Override
    public List<TFOneRatePlanProfile> searchProfilesForUpdate(TracfoneOneSearchProfileModel tracfoneOneSearchProfileModel) throws TracfoneOneException {
        List<TFOneRatePlanProfile> ratePlanProfiles = new ArrayList<>();
        try {
            ratePlanProfiles = tracfoneProfileLocalAction.searchProfilesForUpdate(tracfoneOneSearchProfileModel);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_PROFILE_FOR_UPDATE_ERROR, TRACFONE_SEARCH_PROFILE_FOR_UPDATE_ERROR_MESSAGE, ex);
        }
        return ratePlanProfiles;
    }

    @Override
    public TFOneGeneralResponse updateChildPlan(TracfoneOneChildPlan tfOneChildPlan, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        validateChildPlanAlreadyExists(tfOneChildPlan, true);
        try {
            response = tracfoneProfileLocalAction.updateChildPlan(tfOneChildPlan, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_CHILD_PLAN_ERROR, TRACFONE_UPDATE_CHILD_PLAN_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneGeneralResponse insertChildPlan(TracfoneOneChildPlan tfOneChildPlan, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        validateChildPlanAlreadyExists(tfOneChildPlan, false);
        try {
            response = tracfoneProfileLocalAction.insertChildPlan(tfOneChildPlan, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_INSERT_CHILD_PLAN_ERROR, TRACFONE_INSERT_CHILD_PLAN_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneGeneralResponse deleteChildPlan(TracfoneOneChildPlan tfOneChildPlan, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        checkDependenciesExist(tfOneChildPlan);
        try {
            response = tracfoneProfileLocalAction.deleteChildPlan(tfOneChildPlan, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_CHILD_PLAN_ERROR, TRACFONE_DELETE_CHILD_PLAN_ERROR_MESSAGE, ex);
        }

        return response;
    }

    private void validateChildPlanAlreadyExists(TracfoneOneChildPlan tfOneChildPlan, boolean isUpdate) throws TracfoneOneException {
        TracfoneOneChildPlan searchPlan = new TracfoneOneChildPlan();
        searchPlan.setDbEnv(tfOneChildPlan.getDbEnv());
        searchPlan.setChildPlanId(tfOneChildPlan.getChildPlanId());
        TFOneChildPlan childPlan = tracfoneProfileLocalAction.viewChildPlan(searchPlan);
        if (null != childPlan && !StringUtils.isNullOrEmpty(childPlan.getChildPlanId())) {
            if (!isUpdate
                    || (!StringUtils.isNullOrEmpty(tfOneChildPlan.getChildPlanId()) && !tfOneChildPlan.getChildPlanId().equals(childPlan.getChildPlanId()))) {
                throw new TracfoneOneException(TRACFONE_DUPLICATE_CHILD_PLAN_ERROR, TRACFONE_DUPLICATE_CHILD_PLAN_ERROR_MESSAGE);
            }
        }
    }

    private void checkDependenciesExist(TracfoneOneChildPlan tfOneChildPlan) throws TracfoneOneException {
        if (tracfoneProfileLocalAction.checkChildPlanDependencies(tfOneChildPlan)) {
            throw new TracfoneOneException(TRACFONE_CHILD_PLAN_DEPENDENCY_ERROR, TRACFONE_CHILD_PLAN_DEPENDENCY_ERROR_MESSAGE);
        }
    }

    @Override
    public TFOneGeneralResponse deleteAncillaryCode(TracfoneOneAncillaryCode ancillaryCode, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        TracfoneOneRatePlanExtension tfOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tfOneRatePlanExtension.setDbEnv(ancillaryCode.getDbEnv());
        tfOneRatePlanExtension.setAncillaryCode(ancillaryCode.getAncillaryCode());
        checkAncillaryCodeDependenciesExist(tfOneRatePlanExtension);
        try {
            response = tracfoneProfileLocalAction.deleteAncillaryCode(ancillaryCode, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_ANCILLARY_CODE_ERROR, TRACFONE_DELETE_ANCILLARY_CODE_ERROR_MESSAGE, ex);
        }
        return response;
    }

    private void checkAncillaryCodeDependenciesExist(TracfoneOneRatePlanExtension tfOneRatePlanExtension) throws TracfoneOneException {
        if (tracfoneProfileLocalAction.checkRpExtensionCodeDependencies(tfOneRatePlanExtension)) {
            throw new TracfoneOneException(TRACFONE_ANCILLARY_CODE_DEPENDENCY_ERROR, TRACFONE_ANCILLARY_CODE_DEPENDENCY_ERROR_MESSAGE);
        }
    }

    @Override
    public TFOneGeneralResponse insertAncillaryCode(TracfoneOneAncillaryCode ancillaryCode, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        validateAncillaryCodeAlreadyExists(ancillaryCode);
        try {
            response = tracfoneProfileLocalAction.insertAncillaryCode(ancillaryCode, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_ANCILLARY_CODE_ERROR, TRACFONE_ADD_ANCILLARY_CODE_ERROR_MESSAGE, ex);
        }
        return response;
    }

    private void validateAncillaryCodeAlreadyExists(TracfoneOneAncillaryCode tfAncillaryCode) throws TracfoneOneException {
        TracfoneOneAncillaryCode searchAncillaryCode = new TracfoneOneAncillaryCode();
        searchAncillaryCode.setDbEnv(tfAncillaryCode.getDbEnv());
        searchAncillaryCode.setAncillaryCode(tfAncillaryCode.getAncillaryCode());
        List<TFOneAncillaryCode> ancillaryCodes = tracfoneProfileLocalAction.searchAncillaryCodes(searchAncillaryCode);
        if (null != ancillaryCodes && !ancillaryCodes.isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_ANCILLARY_CODE_ERROR, TRACFONE_DUPLICATE_ANCILLARY_CODE_ERROR_MESSAGE);
        }
    }

    @Override
    public List<TFOneAncillaryCode> searchAncillaryCodes(TracfoneOneAncillaryCode ancillaryCode) throws TracfoneOneException {
        List<TFOneAncillaryCode> ancillaryCodes;
        try {
            ancillaryCodes = tracfoneProfileLocalAction.searchAncillaryCodes(ancillaryCode);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_ANCILLARY_CODE_ERROR, TRACFONE_SEARCH_ANCILLARY_CODE_ERROR_MESSAGE, ex);
        }

        return ancillaryCodes;
    }

    @Override
    public TFOneGeneralResponse updateAncillaryCode(TracfoneOneAncillaryCode ancillaryCode, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneProfileLocalAction.updateAncillaryCode(ancillaryCode, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_ANCILLARY_DESC_ERROR, TRACFONE_UPDATE_ANCILLARY_DESC_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneGeneralResponse deleteRpExtension(TracfoneOneRatePlanExtension tfRpExtension, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        checkRpExtensionDependenciesExist(tfRpExtension);
        try {
            response = tracfoneProfileLocalAction.deleteRpExtension(tfRpExtension, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_RP_EXTENSION_ERROR, TRACFONE_DELETE_RP_EXTENSION_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneGeneralResponse insertRpExtension(TracfoneOneRatePlanExtension tfRpExtension, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        validateRpExtensionAlreadyExists(tfRpExtension);
        try {
            response = tracfoneProfileLocalAction.insertRpExtension(tfRpExtension, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_RP_EXTENSION_ERROR, TRACFONE_ADD_RP_EXTENSION_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<TFOneRatePlanExtension> searchRpExtensions(TracfoneOneRatePlanExtension tfRatePlanExtension) throws TracfoneOneException {
        List<TFOneRatePlanExtension> filteredExtensions = null;
        try {
            filteredExtensions = tracfoneProfileLocalAction.searchRpExtensions(tfRatePlanExtension);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_RP_EXTENSION_ERROR, TRACFONE_SEARCH_RP_EXTENSION_ERROR_MESSAGE, ex);
        }

        return filteredExtensions;
    }

    private void validateRpExtensionAlreadyExists(TracfoneOneRatePlanExtension tfRpExtension) throws TracfoneOneException {
        TracfoneOneRatePlanExtension searchRpExtension = new TracfoneOneRatePlanExtension();
        searchRpExtension.setDbEnv(tfRpExtension.getDbEnv());
        searchRpExtension.setAncillaryCode(tfRpExtension.getAncillaryCode());
        searchRpExtension.setThrottleStatusCode(tfRpExtension.getThrottleStatusCode());
        searchRpExtension.setLineStatusCode(tfRpExtension.getLineStatusCode());
        List<TFOneRatePlanExtension> rpExtensions = tracfoneProfileLocalAction.searchRpExtensions(searchRpExtension);
        if (null != rpExtensions && !rpExtensions.isEmpty()) {
            throw new TracfoneOneException(TRACFONE_DUPLICATE_RP_EXTENSION_ERROR, TRACFONE_DUPLICATE_RP_EXTENSION_ERROR_MESSAGE);
        }
    }

    private void checkRpExtensionDependenciesExist(TracfoneOneRatePlanExtension tfRpExtension) throws TracfoneOneException {
        if (tracfoneProfileLocalAction.checkRpExtensionDependencies(tfRpExtension)) {
            throw new TracfoneOneException(TRACFONE_RP_EXTENSION_DEPENDENCY_ERROR, TRACFONE_RP_EXTENSION_DEPENDENCY_ERROR_MESSAGE);
        }
    }

    /**
     * insert into sa.x_rp_profile a new profile for each feature
     * <p>
     * Create relationship between carrier feature and profile <new_profile_id>
     * and <new_carrier_feature_id> are needed insert into
     * sa.x_rp_extension_link a link for each profile link is el.profile_id =
     * rp.profile_id, cf.objid = el.carrier_feature_objid from
     * sa.x_rp_extension_link el, sa.x_rp_profile rp,
     * sa.table_x_carrier_features cf
     *
     * @param tfRpExtensionLink
     * @param userId
     * @return
     * @throws TracfoneOneException
     */
    @Override
    public TFOneGeneralResponse insertRpExtensionLink(TracfoneOneRatePlanExtensionLink tfRpExtensionLink, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneProfileLocalAction.insertRpExtensionLink(tfRpExtensionLink, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_PROFILE_EXTENSION_LINK_ERROR, TRACFONE_ADD_PROFILE_EXTENSION_LINK_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneGeneralResponse deleteRpExtensionLink(TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneProfileLocalAction.deleteRpExtensionLink(tfOneRpExtensionLink, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_RP_EXTENSION_LINK_ERROR, TRACFONE_DELETE_RP_EXTENSION_LINK_ERROR_MESSAGE, ex);
        }

        return response;
    }

    @Override
    public TFOneGeneralResponse updateRpExtensionLink(TracfoneOneRatePlanExtensionLink tfOneRpExtensionLink, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneProfileLocalAction.updateRpExtensionLink(tfOneRpExtensionLink, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_RP_EXTENSION_LINK_ERROR, TRACFONE_UPDATE_RP_EXTENSION_LINK_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<TFOneCarrierServicePlan> getProfileServicePlans(String dbEnv, String profileId) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> servicePlans = null;
        try {
            servicePlans = tracfoneProfileLocalAction.getProfileServicePlans(dbEnv, profileId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_PROFILE_SERVICE_PLANS_ERROR, TRACFONE_GET_PROFILE_SERVICE_PLANS_ERROR_MESSAGE, ex);
        }

        return servicePlans;
    }

    @Override
    public List<TFOneCarrierServicePlan> getRatePlanServicePlans(String dbEnv, String ratePlan) throws TracfoneOneException {
        List<TFOneCarrierServicePlan> servicePlans = null;
        try {
            servicePlans = tracfoneProfileLocalAction.getRatePlanServicePlans(dbEnv, ratePlan);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_RP_SERVICE_PLANS_ERROR, TRACFONE_GET_RP_SERVICE_PLANS_ERROR_MESSAGE, ex);
        }

        return servicePlans;
    }

    @Override
    public TFOneGeneralResponse insertAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = tracfoneProfileLocalAction.insertAncillaryCodeConfig(tfAncillaryCodeConfig, userId);
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
    }

    @Override
    public TFOneGeneralResponse updateAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = tracfoneProfileLocalAction.updateAncillaryCodeConfig(tfAncillaryCodeConfig, userId);
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
    }

    @Override
    public TFOneGeneralResponse deleteAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneProfileLocalAction.deleteAncillaryCodeConfig(tfAncillaryCodeConfig, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_ANCILLARY_CODE_CONFIG_ERROR, TRACFONE_DELETE_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<TFOneAncillaryCodeConfig> getAncillaryCodeConfig(TracfoneOneAncillaryCodeConfig tfAncillaryCodeConfig) throws TracfoneOneException {
        List<TFOneAncillaryCodeConfig> tfAncillaryCodeConfigs;
        try {
            tfAncillaryCodeConfigs = tracfoneProfileLocalAction.getAncillaryCodeConfig(tfAncillaryCodeConfig);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_GET_ANCILLARY_CODE_CONFIG_ERROR, TRACFONE_GET_ANCILLARY_CODE_CONFIG_ERROR_MESSAGE, ex);
        }
        return tfAncillaryCodeConfigs;
    }

    @Override
    public TFOneGeneralResponse insertAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneProfileLocalAction.insertAncillaryCodeDiscount(tfAncillaryCodeDiscount, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_ANCILLARY_CODE_DISCOUNT_ERROR, TRACFONE_ADD_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse deleteAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            long totalAssociatedProfiles = 0;
            if (!tfAncillaryCodeDiscount.isDelete()) {
                totalAssociatedProfiles = tracfoneProfileLocalAction.checkAncillaryCodeDiscountDependencies(tfAncillaryCodeDiscount);
                response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, String.valueOf(totalAssociatedProfiles));
            }
            if (tfAncillaryCodeDiscount.isDelete() || totalAssociatedProfiles == 0) {
                response = tracfoneProfileLocalAction.deleteAncillaryCodeDiscount(tfAncillaryCodeDiscount, userId);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_ANCILLARY_CODE_DISCOUNT_ERROR, TRACFONE_DELETE_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse updateAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneProfileLocalAction.updateAncillaryCodeDiscount(tfAncillaryCodeDiscount, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_ANCILLARY_CODE_DISCOUNT_ERROR, TRACFONE_UPDATE_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<TFOneAncillaryCodeDiscount> searchAncillaryCodeDiscount(TracfoneOneAncillaryCodeDiscount tfAncillaryCodeDiscount) throws TracfoneOneException {
        List<TFOneAncillaryCodeDiscount> tfAncillaryCodeDiscounts = null;
        try {
            tfAncillaryCodeDiscounts = tracfoneProfileLocalAction.searchAncillaryCodeDiscount(tfAncillaryCodeDiscount);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_ANCILLARY_CODE_DISCOUNT_ERROR, TRACFONE_SEARCH_ANCILLARY_CODE_DISCOUNT_ERROR_MESSAGE, ex);
        }
        return tfAncillaryCodeDiscounts;
    }

    @Override
    public TFOneGeneralResponse deleteLineStatusCode(TracfoneOneLineStatusCode tfOneLineStatus, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        TracfoneOneRatePlanExtension tfOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tfOneRatePlanExtension.setDbEnv(tfOneLineStatus.getDbEnv());
        tfOneRatePlanExtension.setLineStatusCode(tfOneLineStatus.getLineStatusCode());
        checkAncillaryCodeDependenciesExist(tfOneRatePlanExtension);
        try {
            response = tracfoneProfileLocalAction.deleteLineStatusCode(tfOneLineStatus, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_LINE_STATUS_CODE_ERROR, TRACFONE_DELETE_LINE_STATUS_CODE_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse deleteThrottleStatusCode(TracfoneOneThrottleStatusCode tfOneThrottleStatusCode, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        TracfoneOneRatePlanExtension tfOneRatePlanExtension = new TracfoneOneRatePlanExtension();
        tfOneRatePlanExtension.setDbEnv(tfOneThrottleStatusCode.getDbEnv());
        tfOneRatePlanExtension.setThrottleStatusCode(tfOneThrottleStatusCode.getThrottleStatusCode());
        checkAncillaryCodeDependenciesExist(tfOneRatePlanExtension);
        try {
            response = tracfoneProfileLocalAction.deleteThrottleStatusCode(tfOneThrottleStatusCode, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_THROTTLE_STATUS_CODE_ERROR, TRACFONE_DELETE_THROTTLE_STATUS_CODE_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse insertMultiRatePlanEsn(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneProfileLocalAction.insertMultiRatePlanEsn(tracfoneOneMultiRatePlanEsn, userId, null);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_MULTI_RATE_PLAN_ESNS_ERROR, TRACFONE_ADD_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse updateMultiRatePlanEsn(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneProfileLocalAction.updateMultiRatePlanEsn(tracfoneOneMultiRatePlanEsn, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_UPDATE_MULTI_RATE_PLAN_ESNS_ERROR, TRACFONE_UPDATE_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public TFOneGeneralResponse deleteMultiRatePlanEsn(List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsns, int userId) throws TracfoneOneException {
        TFOneGeneralResponse response = null;
        try {
            response = tracfoneProfileLocalAction.deleteMultiRatePlanEsn(tracfoneOneMultiRatePlanEsns, userId);
            response = new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, response.getMessage());
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_MULTI_RATE_PLAN_ESNS_ERROR, TRACFONE_DELETE_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE, ex);
        }
        return response;
    }

    @Override
    public List<TFOneMultiRatePlanEsn> searchMultiRatePlanEsns(TracfoneOneMultiRatePlanEsn tracfoneOneMultiRatePlanEsn) throws TracfoneOneException {
        List<TFOneMultiRatePlanEsn> tfOneMultiRatePlanEsns = null;
        try {
            tfOneMultiRatePlanEsns = tracfoneProfileLocalAction.searchMultiRatePlanEsns(tracfoneOneMultiRatePlanEsn);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_SEARCH_MULTI_RATE_PLAN_ESNS_ERROR, TRACFONE_SEARCH_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE, ex);
        }
        return tfOneMultiRatePlanEsns;
    }

    @Override
    public void bulkInsertProfiles(List<TracfoneOneRatePlanProfile> tfRatePlanProfiles, int userId) throws TracfoneOneException {
        try {
            List<String> duplicateProfiles = tracfoneProfileLocalAction.searchProfilesByDesc(tfRatePlanProfiles);
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                for (TracfoneOneRatePlanProfile tfRatePlanProfile : tfRatePlanProfiles) {
                    if (!duplicateProfiles.contains(tfRatePlanProfile.getProfileDescription())) {
                        try {
                            tracfoneProfileLocalAction.insertProfile(tfRatePlanProfile, userId);
                        } catch (TracfoneOneException ex) {
                            LOGGER.error("Insertion of this Profile failed " + tfRatePlanProfile, ex);
                        }
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_PROFILE_ERROR, TRACFONE_ADD_PROFILE_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public void bulkInsertRatePlanEsn(List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsn, int userId) throws TracfoneOneException {
        // Generate a unique identifier
        long unique = (new SecureRandom().nextInt((999999999 - 100000000) + 1) + 100000000);
        // Create a record in cop_audit table for this bulk insert
        triggerAudit(userId, MULTI_RATEPLAN_ESN_BULK_INSERT,
                "Requested a bulk insert of Multi Rate Plan ESN-" + tracfoneOneMultiRatePlanEsn.size(),
                String.valueOf(tracfoneOneMultiRatePlanEsn.size()) + "_" + unique);
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {

                for (TracfoneOneMultiRatePlanEsn multiRatePlanEsn : tracfoneOneMultiRatePlanEsn) {
                    try {
                        LOGGER.info(INSERTION + multiRatePlanEsn);
                        tracfoneProfileLocalAction.insertMultiRatePlanEsn(multiRatePlanEsn, userId, String.valueOf(unique));
                    } catch (TracfoneOneException ex) {
                        LOGGER.error("Bulk Insertion of Profile Features failed " + multiRatePlanEsn, ex);
                        // This success record is required for the case when it fails insert owing to duplicate feature value.
                        if (!TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE.equalsIgnoreCase(ex.getErrorMessage())) {
                            triggerAudit(userId, MULTI_RATEPLAN_ESN_BULK_INSERT,
                                    "Inserted Multi Rate Plan ESN " + multiRatePlanEsn, "CARRIER ID_" + unique);
                        }
                        triggerAudit(userId, MULTI_RATEPLAN_ESN_BULK_INSERT,
                                "Bulk Insert Failed for Transaction " + multiRatePlanEsn + " - " + ex.getErrorMessage(),
                                "ERROR_" + unique);
                    }
                }
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_MULTI_RATE_PLAN_ESNS_ERROR, TRACFONE_ADD_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE, ex);
        }
    }

    private void triggerAudit(int userId, String action, String details, String carrierId) {
        TracfoneAudit errorAudit = new TracfoneAudit(userId, action, details, carrierId);
        tracfoneAuditEvent.fire(errorAudit);
    }
    
    @Override
    public void bulkDeleteMultiRatePlanEsn(List<TracfoneOneMultiRatePlanEsn> tracfoneOneMultiRatePlanEsns, int userId) throws TracfoneOneException {
        try {
            ExecutorService executorService = Executors.newFixedThreadPool(1);
            executorService.execute(() -> {
                tracfoneOneMultiRatePlanEsns.forEach((multiRatePlanEsn) -> {
                    try {
                        LOGGER.info("Going to delete multirateplanesn " + multiRatePlanEsn);
                        tracfoneProfileLocalAction.bulkDeleteMultiRatePlanEsn(multiRatePlanEsn, userId);
                    } catch (TracfoneOneException ex) {
                        LOGGER.info(ex);
                    }
                });
            });
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_DELETE_MULTI_RATE_PLAN_ESNS_ERROR, TRACFONE_DELETE_MULTI_RATE_PLAN_ESNS_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public List<String> validateInsertProfiles(List<TracfoneOneRatePlanProfile> tfRatePlanProfiles, int userId) throws TracfoneOneException {
        List<String> duplicates = new ArrayList<>();
        try {
            List<String> duplicateProfiles = tracfoneProfileLocalAction.searchProfilesByDesc(tfRatePlanProfiles);
            duplicates.addAll(duplicateProfiles);
        } catch (Exception ex) {
            throw new TracfoneOneException(TRACFONE_ADD_PROFILE_ERROR, TRACFONE_ADD_PROFILE_ERROR_MESSAGE, ex);
        }
        return  duplicates;
    }
}
