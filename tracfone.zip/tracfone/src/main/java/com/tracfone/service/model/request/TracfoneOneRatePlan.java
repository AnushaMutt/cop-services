/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tracfone.service.model.request;

import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *TABLE SA.X_RATE_PLAN
 * @author user
 */
public class TracfoneOneRatePlan {
    
    private boolean softDelete;
    private String dbEnv;
    private String ratePlanId;
    @NotNull(message = "Rate Plan Name cannot be null")
    @Size(min=1, message = "Rate Plan Name cannot be blank")
    @Size(max=60, message = "Rate Plan Name cannot have more than 60 characters")
    private String ratePlanName;
    @Size(max=30, message = "Private Network cannot have more than 30 characters")
    private String privateNetwork;
    @Size(max=30, message = "ESPID Update cannot have more than 30 characters")
    private String espidUpdate;
    @Size(max=30, message = "ESPID Num cannot have more than 30 characters")
    private String espidNum;
    @Digits(integer=4, fraction=0, message = "Propagate Flag Value must be a number not greater than 9999")
    private String propagateFlagValue;
    @Size(max=1, message = "Allow MForm APN Request Flag cannot have more than one character")
    private String allowMformApnRequestFlag;
    @Size(max=1, message = "Calculate Data Units Flag cannot have more than one character")
    private String calculateDataUnitsFlag;
    @Size(max=1, message = "Thresholds To TMO cannot have more than one character")
    private String thresholdsToTmo;
    @Size(max=1, message = "Hotspot Buckets Flag cannot have more than one character")
    private String hotspotBucketsFlag;
    @Valid
    private List<TracfoneOneCarrierFeature> carrierFeatures = new ArrayList<>();

    public boolean isSoftDelete() {
        return softDelete;
    }

    public void setSoftDelete(boolean softDelete) {
        this.softDelete = softDelete;
    }

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getRatePlanId() {
        return ratePlanId;
    }

    public void setRatePlanId(String ratePlanId) {
        this.ratePlanId = ratePlanId;
    }

    public String getRatePlanName() {
        return ratePlanName;
    }

    public void setRatePlanName(String ratePlanName) {
        this.ratePlanName = ratePlanName;
    }

    public String getPrivateNetwork() {
        return privateNetwork;
    }

    public void setPrivateNetwork(String privateNetwork) {
        this.privateNetwork = privateNetwork;
    }

    public String getEspidUpdate() {
        return espidUpdate;
    }

    public void setEspidUpdate(String epsidUpdate) {
        this.espidUpdate = epsidUpdate;
    }

    public String getEspidNum() {
        return espidNum;
    }

    public void setEspidNum(String epsidNum) {
        this.espidNum = epsidNum;
    }

    public String getPropagateFlagValue() {
        return propagateFlagValue;
    }

    public void setPropagateFlagValue(String propagateFlagValue) {
        this.propagateFlagValue = propagateFlagValue;
    }

    public String getAllowMformApnRequestFlag() {
        return allowMformApnRequestFlag;
    }

    public void setAllowMformApnRequestFlag(String allowMformApnRequestFlag) {
        this.allowMformApnRequestFlag = allowMformApnRequestFlag;
    }

    public String getCalculateDataUnitsFlag() {
        return calculateDataUnitsFlag;
    }

    public void setCalculateDataUnitsFlag(String calculateDataUnitsFlag) {
        this.calculateDataUnitsFlag = calculateDataUnitsFlag;
    }

    public String getThresholdsToTmo() {
        return thresholdsToTmo;
    }

    public void setThresholdsToTmo(String thresholdsToTmo) {
        this.thresholdsToTmo = thresholdsToTmo;
    }

    public String getHotspotBucketsFlag() {
        return hotspotBucketsFlag;
    }

    public void setHotspotBucketsFlag(String hotspotBucketsFlag) {
        this.hotspotBucketsFlag = hotspotBucketsFlag;
    }   

    public List<TracfoneOneCarrierFeature> getCarrierFeatures() {
        return carrierFeatures;
    }

    public void setCarrierFeatures(List<TracfoneOneCarrierFeature> carrierFeatures) {
        this.carrierFeatures = carrierFeatures;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("TracfoneOneRatePlan - ");
        sb.append("dbEnv=").append(dbEnv).append(", ");
        sb.append("softDelete=").append(softDelete).append(", ");
        sb.append("ratePlanId=").append(ratePlanId).append(", ");
        sb.append("ratePlanName=").append(ratePlanName).append(", ");
        sb.append("privateNetwork=").append(privateNetwork).append(", ");
        sb.append("espidUpdate=").append(espidUpdate).append(", ");
        sb.append("espidNum=").append(espidNum).append(", ");
        sb.append("propagateFlagValue=").append(propagateFlagValue).append(", ");
        sb.append("allowMformApnRequestFlag=").append(allowMformApnRequestFlag).append(", ");
        sb.append("calculateDataUnitsFlag=").append(calculateDataUnitsFlag).append(", ");
        sb.append("thresholdsToTmo=").append(thresholdsToTmo).append(", ");
        sb.append("hotspotBucketsFlag=").append(hotspotBucketsFlag);
        return sb.toString();
    }

}
