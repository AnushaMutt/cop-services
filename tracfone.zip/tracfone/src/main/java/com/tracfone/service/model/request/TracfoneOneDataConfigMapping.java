package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * TABLE: data_config_mapping
 *
 * @author Pritesh Singh
 */
public class TracfoneOneDataConfigMapping {
    private String dbEnv;
    @Size(min = 1, message = "Parent Id cannot be null")
    @Size(max = 30, message = "Parent Id cannot have more than 30 characters")
    private String parentId;
    @Size(min = 1, message = "Part Class Obj Id cannot be null")
    @Digits(integer = 38, fraction = 0, message = "Part Class Obj Id must be a number")
    private String partClassObjId;
    @Size(max = 60, message = "Rate Plan cannot have more than 60 characters")
    @Size(min = 1, message = "Rate Plan cannot be null")
    private String ratePlan;
    @Size(min = 1, message = "Data Config Obj Id cannot be null")
    @Digits(integer = 38, fraction = 0, message = "Data Config Obj Id must be a number")
    private String dataConfigObjId;
    private String oldParentId;
    private String oldPartClassObjId;
    private String oldRatePlan;
    private String oldDataConfigObjId;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getPartClassObjId() {
        return partClassObjId;
    }

    public void setPartClassObjId(String partClassObjId) {
        this.partClassObjId = partClassObjId;
    }

    public String getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(String ratePlan) {
        this.ratePlan = ratePlan;
    }

    public String getDataConfigObjId() {
        return dataConfigObjId;
    }

    public void setDataConfigObjId(String dataConfigObjId) {
        this.dataConfigObjId = dataConfigObjId;
    }

    public String getOldParentId() {
        return oldParentId;
    }

    public void setOldParentId(String oldParentId) {
        this.oldParentId = oldParentId;
    }

    public String getOldPartClassObjId() {
        return oldPartClassObjId;
    }

    public void setOldPartClassObjId(String oldPartClassObjId) {
        this.oldPartClassObjId = oldPartClassObjId;
    }

    public String getOldRatePlan() {
        return oldRatePlan;
    }

    public void setOldRatePlan(String oldRatePlan) {
        this.oldRatePlan = oldRatePlan;
    }

    public String getOldDataConfigObjId() {
        return oldDataConfigObjId;
    }

    public void setOldDataConfigObjId(String oldDataConfigObjId) {
        this.oldDataConfigObjId = oldDataConfigObjId;
    }

    @Override
    public String toString() {
        return "TracfoneOneDataConfigMapping{" +
                "dbEnv='" + dbEnv + '\'' +
                ", parentId='" + parentId + '\'' +
                ", partClassObjId='" + partClassObjId + '\'' +
                ", ratePlan='" + ratePlan + '\'' +
                ", dataConfigObjId='" + dataConfigObjId + '\'' +
                ", oldParentId='" + oldParentId + '\'' +
                ", oldPartClassObjId='" + oldPartClassObjId + '\'' +
                ", oldRatePlan='" + oldRatePlan + '\'' +
                ", oldDataConfigObjId='" + oldDataConfigObjId + '\'' +
                '}';
    }
}
