/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.response;

/**
 *
 * @author Shireen Fathima
 */
public class TFOneCarrierProfileChildTier {
    private String objId;
    private String carrierProfileChildObjId;
    private String usageTierId;
    private String tierDescription;
    private String tierValue;
    private String tierBehavior;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getCarrierProfileChildObjId() {
        return carrierProfileChildObjId;
    }

    public void setCarrierProfileChildObjId(String carrierProfileChildObjId) {
        this.carrierProfileChildObjId = carrierProfileChildObjId;
    }

    public String getUsageTierId() {
        return usageTierId;
    }

    public void setUsageTierId(String usageTierId) {
        this.usageTierId = usageTierId;
    }

    public String getTierDescription() {
        return tierDescription;
    }

    public void setTierDescription(String tierDescription) {
        this.tierDescription = tierDescription;
    }

    public String getTierValue() {
        return tierValue;
    }

    public void setTierValue(String tierValue) {
        this.tierValue = tierValue;
    }

    public String getTierBehavior() {
        return tierBehavior;
    }

    public void setTierBehavior(String tierBehavior) {
        this.tierBehavior = tierBehavior;
    }

    @Override
    public String toString() {
        return "TFOneCarrierProfileChildTier{" + "objId=" + objId + ", "
                + "carrierProfileChildObjId=" + carrierProfileChildObjId + ", "
                + "usageTierId=" + usageTierId + ", "
                + "tierDescription=" + tierDescription + ", "
                + "tierValue=" + tierValue + ", "
                + "tierBehavior=" + tierBehavior + '}';
    }

    
}
