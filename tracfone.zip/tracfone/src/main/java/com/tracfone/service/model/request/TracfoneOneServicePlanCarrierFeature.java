/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;

/**
 * TABLE SA.MTM_SP_CARRIERFEATURES
 * @author Shireen Fathima
 */
public class TracfoneOneServicePlanCarrierFeature {
    
    private String servicePlanId;
    private String carrierFeaturesId;
    @Digits(integer=38, fraction=0, message = "Priority must be a number")
    private String priority;

    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public String getCarrierFeaturesId() {
        return carrierFeaturesId;
    }

    public void setCarrierFeaturesId(String carrierFeaturesId) {
        this.carrierFeaturesId = carrierFeaturesId;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }    
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("TracfoneOneServicePlanCarrierFeature - ");
        sb.append("servicePlanId=").append(servicePlanId).append(", ");
        sb.append("carrierFeaturesId=").append(carrierFeaturesId).append(", ");
        sb.append("priority=").append(priority);
        return sb.toString();
    }
    
}
