package com.tracfone.service.model.retail.response;

public class TFOneRetailCarrierPrefDetail {
    private String objId;
    private String carrierPrefGroupId;
    private String carrierDetailId;
    private String rank;
    private String carrier;
    private String brand;
    private String tech;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getCarrierPrefGroupId() {
        return carrierPrefGroupId;
    }

    public void setCarrierPrefGroupId(String carrierPrefGroupId) {
        this.carrierPrefGroupId = carrierPrefGroupId;
    }

    public String getCarrierDetailId() {
        return carrierDetailId;
    }

    public void setCarrierDetailId(String carrierDetailId) {
        this.carrierDetailId = carrierDetailId;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getTech() {
        return tech;
    }

    public void setTech(String tech) {
        this.tech = tech;
    }

    @Override
    public String toString() {
        return "TFOneRetailCarrierPrefDetail{" +
                "objId='" + objId + '\'' +
                ", carrierPrefGroupId='" + carrierPrefGroupId + '\'' +
                ", carrierDetailId='" + carrierDetailId + '\'' +
                ", rank='" + rank + '\'' +
                ", carrier='" + carrier + '\'' +
                ", brand='" + brand + '\'' +
                ", tech='" + tech + '\'' +
                '}';
    }
}
