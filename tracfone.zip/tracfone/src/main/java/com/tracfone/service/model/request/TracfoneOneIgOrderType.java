package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

public class TracfoneOneIgOrderType {
    private String dbEnv;
    @Size(min = 1, message = "Programme Name cannot be null")
    @Size(max = 30, message = "Programme Name cannot have more than 30 characters")
    private String programmeName;
    @Size(min = 1, message = "Actual Order Type cannot be null")
    @Size(max = 30, message = "Actual Order Type cannot have more than 30 characters")
    private String actualOrderType;
    @Size(min = 1, message = "IG Order Type cannot be null")
    @Size(max = 30, message = "IG Order Type cannot have more than 30 characters")
    private String igOrderType;
    @Size(max = 4000, message = "SQL Text cannot have more than 30 characters")
    private String sqlText;
    @Size(min = 1, message = "Priority cannot be null")
    @Digits(integer = 38, fraction = 0, message = "Priority must be a number")
    private String priority;
    @Size(max = 1, message = "Create SO Gencode Flag cannot have more than 1 character")
    private String createSOGencodeFlag;
    @Size(max = 1, message = "Create M Form IG Flag cannot have more than 1 character")
    private String createMFormIGFlag;
    @Size(max = 1, message = "Create M FormPort Flag cannot have more than 1 character")
    private String createMFormPortFlag;
    @Size(max = 1, message = "Skip Min Validation Form cannot have more than 1 character")
    private String skipMinValidationForm;
    @Size(max = 1, message = "Skip ESN Validation Flag cannot have more than 1 character")
    private String skipESNValidationFlag;
    @Size(max = 1, message = "Create IG APN Flag cannot have more than 1 character")
    private String createIGAPNFlag;
    @Size(max = 1, message = "Insert ILD Trans Flag cannot have more than 1 character")
    private String insertILDTransFlag;
    @Size(max = 1, message = "Bogo Config Flag cannot have more than 1 character")
    private String bogoConfigFlag;
    @Size(max = 10, message = "sUIActionType cannot have more than 10 characters")
    private String sUIActionType;
    @Size(max = 1, message = "Update MSID Flag cannot have more than 1 character")
    private String updateMSIDFlag;
    @Size(max = 1, message = "Addon Cash Card Flag cannot have more than 1 character")
    private String addonCashCardFlag;
    @Size(max = 1, message = "Contact Pin Update Flag cannot have more than 1 character")
    private String contactPinUpdateFlag;
    @Size(max = 1, message = "BRM Notification Flag cannot have more than 1 character")
    private String brmNotificationFlag;
    @Size(min = 1, message = "Newer Trans Flag cannot be null")
    @Size(max = 1, message = "Newer Trans Flag cannot have more than 1 character")
    private String newerTransFlag;
    @Size(max = 1, message = "Skip Min Update Flag cannot have more than 1 character")
    private String skipMinUpdateFlag;
    @Size(max = 1, message = "Safe Link Batch Flag cannot have more than 1 character")
    private String safeLinkBatchFlag;
    @Size(max = 3, message = "Create Buckets Flag cannot have more than 3 characters")
    private String createBucketsFlag;
    @Size(min = 1, message = "Process Igate IN3 Flag cannot be null")
    @Size(max = 1, message = "Process Igate IN3 Flag cannot have more than 1 character")
    private String processIgateIN3Flag;
    @Size(min = 1, message = "Process Igate IN3 Lite Flag cannot be null")
    @Size(max = 1, message = "Process Igate IN3 Lite Flag cannot have more than 1 character")
    private String processIgateIN3LiteFlag;
    @Size(min = 1, message = "Update Case2Task Flag cannot be null")
    @Size(max = 1, message = "Update Case2Task Flag cannot have more than 1 character")
    private String updateXCase2TaskFlag;
    @Size(max = 1, message = "Dep IG Trans Flag cannot have more than 1 character")
    private String depIGTransFlag;
    @Size(max = 1, message = "Generate Account Flag cannot have more than 1 character")
    private String generateAccountFlag;
    @Size(max = 1, message = "Create IG ACM Flag cannot have more than 1 character")
    private String createIGACMFlag;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getProgrammeName() {
        return programmeName;
    }

    public void setProgrammeName(String programmeName) {
        this.programmeName = programmeName;
    }

    public String getActualOrderType() {
        return actualOrderType;
    }

    public void setActualOrderType(String actualOrderType) {
        this.actualOrderType = actualOrderType;
    }

    public String getIgOrderType() {
        return igOrderType;
    }

    public void setIgOrderType(String igOrderType) {
        this.igOrderType = igOrderType;
    }

    public String getSqlText() {
        return sqlText;
    }

    public void setSqlText(String sqlText) {
        this.sqlText = sqlText;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getCreateSOGencodeFlag() {
        return createSOGencodeFlag;
    }

    public void setCreateSOGencodeFlag(String createSOGencodeFlag) {
        this.createSOGencodeFlag = createSOGencodeFlag;
    }

    public String getCreateMFormIGFlag() {
        return createMFormIGFlag;
    }

    public void setCreateMFormIGFlag(String createMFormIGFlag) {
        this.createMFormIGFlag = createMFormIGFlag;
    }

    public String getCreateMFormPortFlag() {
        return createMFormPortFlag;
    }

    public void setCreateMFormPortFlag(String createMFormPortFlag) {
        this.createMFormPortFlag = createMFormPortFlag;
    }

    public String getSkipMinValidationForm() {
        return skipMinValidationForm;
    }

    public void setSkipMinValidationForm(String skipMinValidationForm) {
        this.skipMinValidationForm = skipMinValidationForm;
    }

    public String getSkipESNValidationFlag() {
        return skipESNValidationFlag;
    }

    public void setSkipESNValidationFlag(String skipESNValidationFlag) {
        this.skipESNValidationFlag = skipESNValidationFlag;
    }

    public String getCreateIGAPNFlag() {
        return createIGAPNFlag;
    }

    public void setCreateIGAPNFlag(String createIGAPNFlag) {
        this.createIGAPNFlag = createIGAPNFlag;
    }

    public String getInsertILDTransFlag() {
        return insertILDTransFlag;
    }

    public void setInsertILDTransFlag(String insertILDTransFlag) {
        this.insertILDTransFlag = insertILDTransFlag;
    }

    public String getBogoConfigFlag() {
        return bogoConfigFlag;
    }

    public void setBogoConfigFlag(String bogoConfigFlag) {
        this.bogoConfigFlag = bogoConfigFlag;
    }

    public String getsUIActionType() {
        return sUIActionType;
    }

    public void setsUIActionType(String sUIActionType) {
        this.sUIActionType = sUIActionType;
    }

    public String getUpdateMSIDFlag() {
        return updateMSIDFlag;
    }

    public void setUpdateMSIDFlag(String updateMSIDFlag) {
        this.updateMSIDFlag = updateMSIDFlag;
    }

    public String getAddonCashCardFlag() {
        return addonCashCardFlag;
    }

    public void setAddonCashCardFlag(String addonCashCardFlag) {
        this.addonCashCardFlag = addonCashCardFlag;
    }

    public String getContactPinUpdateFlag() {
        return contactPinUpdateFlag;
    }

    public void setContactPinUpdateFlag(String contactPinUpdateFlag) {
        this.contactPinUpdateFlag = contactPinUpdateFlag;
    }

    public String getBrmNotificationFlag() {
        return brmNotificationFlag;
    }

    public void setBrmNotificationFlag(String brmNotificationFlag) {
        this.brmNotificationFlag = brmNotificationFlag;
    }

    public String getNewerTransFlag() {
        return newerTransFlag;
    }

    public void setNewerTransFlag(String newerTransFlag) {
        this.newerTransFlag = newerTransFlag;
    }

    public String getSkipMinUpdateFlag() {
        return skipMinUpdateFlag;
    }

    public void setSkipMinUpdateFlag(String skipMinUpdateFlag) {
        this.skipMinUpdateFlag = skipMinUpdateFlag;
    }

    public String getSafeLinkBatchFlag() {
        return safeLinkBatchFlag;
    }

    public void setSafeLinkBatchFlag(String safeLinkBatchFlag) {
        this.safeLinkBatchFlag = safeLinkBatchFlag;
    }

    public String getCreateBucketsFlag() {
        return createBucketsFlag;
    }

    public void setCreateBucketsFlag(String createBucketsFlag) {
        this.createBucketsFlag = createBucketsFlag;
    }

    public String getProcessIgateIN3Flag() {
        return processIgateIN3Flag;
    }

    public void setProcessIgateIN3Flag(String processIgateIN3Flag) {
        this.processIgateIN3Flag = processIgateIN3Flag;
    }

    public String getProcessIgateIN3LiteFlag() {
        return processIgateIN3LiteFlag;
    }

    public void setProcessIgateIN3LiteFlag(String processIgateIN3LiteFlag) {
        this.processIgateIN3LiteFlag = processIgateIN3LiteFlag;
    }

    public String getUpdateXCase2TaskFlag() {
        return updateXCase2TaskFlag;
    }

    public void setUpdateXCase2TaskFlag(String updateXCase2TaskFlag) {
        this.updateXCase2TaskFlag = updateXCase2TaskFlag;
    }

    public String getDepIGTransFlag() {
        return depIGTransFlag;
    }

    public void setDepIGTransFlag(String depIGTransFlag) {
        this.depIGTransFlag = depIGTransFlag;
    }

    public String getGenerateAccountFlag() {
        return generateAccountFlag;
    }

    public void setGenerateAccountFlag(String generateAccountFlag) {
        this.generateAccountFlag = generateAccountFlag;
    }

    public String getCreateIGACMFlag() {
        return createIGACMFlag;
    }

    public void setCreateIGACMFlag(String createIGACMFlag) {
        this.createIGACMFlag = createIGACMFlag;
    }

    @Override
    public String toString() {
        return "TracfoneOneIgOrderType{" +
                "dbEnv='" + dbEnv + '\'' +
                ", programmeName='" + programmeName + '\'' +
                ", actualOrderType='" + actualOrderType + '\'' +
                ", igOrderType='" + igOrderType + '\'' +
                ", sqlText='" + sqlText + '\'' +
                ", priority='" + priority + '\'' +
                ", createSOGencodeFlag='" + createSOGencodeFlag + '\'' +
                ", createMFormIGFlag='" + createMFormIGFlag + '\'' +
                ", createMFormPortFlag='" + createMFormPortFlag + '\'' +
                ", skipMinValidationForm='" + skipMinValidationForm + '\'' +
                ", skipESNValidationFlag='" + skipESNValidationFlag + '\'' +
                ", createIGAPNFlag='" + createIGAPNFlag + '\'' +
                ", insertILDTransFlag='" + insertILDTransFlag + '\'' +
                ", bogoConfigFlag='" + bogoConfigFlag + '\'' +
                ", sUIActionType='" + sUIActionType + '\'' +
                ", updateMSIDFlag='" + updateMSIDFlag + '\'' +
                ", addonCashCardFlag='" + addonCashCardFlag + '\'' +
                ", contactPinUpdateFlag='" + contactPinUpdateFlag + '\'' +
                ", brmNotificationFlag='" + brmNotificationFlag + '\'' +
                ", newerTransFlag='" + newerTransFlag + '\'' +
                ", skipMinUpdateFlag='" + skipMinUpdateFlag + '\'' +
                ", safeLinkBatchFlag='" + safeLinkBatchFlag + '\'' +
                ", createBucketsFlag='" + createBucketsFlag + '\'' +
                ", processIgateIN3Flag='" + processIgateIN3Flag + '\'' +
                ", processIgateIN3LiteFlag='" + processIgateIN3LiteFlag + '\'' +
                ", updateXCase2TaskFlag='" + updateXCase2TaskFlag + '\'' +
                ", depIGTransFlag='" + depIGTransFlag + '\'' +
                ", generateAccountFlag='" + generateAccountFlag + '\'' +
                ", createIGACMFlag='" + createIGACMFlag + '\'' +
                '}';
    }
}
