package com.tracfone.service.model.report;

/**
 * @author thejaswini
 */
public class TFOneReportTTMonitor {
    private String carrier;
    private String transNum;
    private String xDate;
    private String transType;
    private String sumAllQ;
    private String sumAllL;
    private String sumAllCp;
    private String sumAllS;
    private String sumAllNt;
    private String sumAllE;
    private String sumAllC;
    private String sumAllTf;
    private String sumOther;
    private String totalTransCount;
    private String totalTransSegment;
    private String failureCount;
    private String comp11Min;
    private String comp15Min;
    private String comp30Min;
    private String compGt30Min;

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getTransNum() {
        return transNum;
    }

    public void setTransNum(String transNum) {
        this.transNum = transNum;
    }

    public String getxDate() {
        return xDate;
    }

    public void setxDate(String xDate) {
        this.xDate = xDate;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public String getSumAllQ() {
        return sumAllQ;
    }

    public void setSumAllQ(String sumAllQ) {
        this.sumAllQ = sumAllQ;
    }

    public String getSumAllL() {
        return sumAllL;
    }

    public void setSumAllL(String sumAllL) {
        this.sumAllL = sumAllL;
    }

    public String getSumAllCp() {
        return sumAllCp;
    }

    public void setSumAllCp(String sumAllCp) {
        this.sumAllCp = sumAllCp;
    }

    public String getSumAllS() {
        return sumAllS;
    }

    public void setSumAllS(String sumAllS) {
        this.sumAllS = sumAllS;
    }

    public String getSumAllNt() {
        return sumAllNt;
    }

    public void setSumAllNt(String sumAllNt) {
        this.sumAllNt = sumAllNt;
    }

    public String getSumAllE() {
        return sumAllE;
    }

    public void setSumAllE(String sumAllE) {
        this.sumAllE = sumAllE;
    }

    public String getSumAllC() {
        return sumAllC;
    }

    public void setSumAllC(String sumAllC) {
        this.sumAllC = sumAllC;
    }

    public String getSumAllTf() {
        return sumAllTf;
    }

    public void setSumAllTf(String sumAllTf) {
        this.sumAllTf = sumAllTf;
    }

    public String getSumOther() {
        return sumOther;
    }

    public void setSumOther(String sumOther) {
        this.sumOther = sumOther;
    }

    public String getTotalTransCount() {
        return totalTransCount;
    }

    public void setTotalTransCount(String totalTransCount) {
        this.totalTransCount = totalTransCount;
    }

    public String getTotalTransSegment() {
        return totalTransSegment;
    }

    public void setTotalTransSegment(String totalTransSegment) {
        this.totalTransSegment = totalTransSegment;
    }

    public String getFailureCount() {
        return failureCount;
    }

    public void setFailureCount(String failureCount) {
        this.failureCount = failureCount;
    }

    public String getComp11Min() {
        return comp11Min;
    }

    public void setComp11Min(String comp11Min) {
        this.comp11Min = comp11Min;
    }

    public String getComp15Min() {
        return comp15Min;
    }

    public void setComp15Min(String comp15Min) {
        this.comp15Min = comp15Min;
    }

    public String getComp30Min() {
        return comp30Min;
    }

    public void setComp30Min(String comp30Min) {
        this.comp30Min = comp30Min;
    }

    public String getCompGt30Min() {
        return compGt30Min;
    }

    public void setCompGt30Min(String compGt30Min) {
        this.compGt30Min = compGt30Min;
    }

    @Override
    public String toString() {
        return "TFOneReportTTMonitor{" +
                "carrier='" + carrier + '\'' +
                ", transNum='" + transNum + '\'' +
                ", xDate='" + xDate + '\'' +
                ", transType='" + transType + '\'' +
                ", sumAllQ='" + sumAllQ + '\'' +
                ", sumAllL='" + sumAllL + '\'' +
                ", sumAllCp='" + sumAllCp + '\'' +
                ", sumAllS='" + sumAllS + '\'' +
                ", sumAllNt='" + sumAllNt + '\'' +
                ", sumAllE='" + sumAllE + '\'' +
                ", sumAllC='" + sumAllC + '\'' +
                ", sumAllTf='" + sumAllTf + '\'' +
                ", sumOther='" + sumOther + '\'' +
                ", totalTransCount='" + totalTransCount + '\'' +
                ", totalTransSegment='" + totalTransSegment + '\'' +
                ", failureCount='" + failureCount + '\'' +
                ", comp11Min='" + comp11Min + '\'' +
                ", comp15Min='" + comp15Min + '\'' +
                ", comp30Min='" + comp30Min + '\'' +
                ", compGt30Min='" + compGt30Min + '\'' +
                '}';
    }
}
