package com.tracfone.service.util;

/**
 * @author Thejaswini
 */
public interface TracfoneOneConstantGeocode {
        static String TOKEN_USER_NAME="CopToolUni";
        static String ESRI_TOKEN = "CopToolUni.1234";
        static String HOST_NAME = "https://esri.tracfone.com";
        static String GENERATE_TOKEN_PATH = "portal/sharing/rest/generateToken";
        static String CLIENT = "referer";
        static String TOKEN_EXPIRE_TIME = "60";
        static String FORMAT = "json";
        static String FIND_ADDRESS = "/arcgis/rest/services/TracFone_USA_Geocoding_Service/GeocodeServer/findAddressCandidates";
        static String URL_ENCODE_FORMAT = "application/x-www-form-urlencoded";

        // ERROR MESSAGES
        String TRACFONE_GENERATE_TOKEN_ERROR = "TFE3000";
        String TRACFONE_GENERATE_TOKEN_ERROR_MESSAGE = "Unable to generate token";

        String TRACFONE_GEOCODE_RESPONSE_ERROR = "TFE3001";
        String TRACFONE_GEOCODE_RESPONSE_ERROR_MESSAGE = "Geocode did not return a status 200.";

        String TRACFONE_GEOCODE_ERROR = "TFE3002";
        String TRACFONE_GEOCODE_ERROR_MESSAGE = "Exception occurred while calling Geocode";

        String TRCFONE_POOLING_HTTP_CLIENT_CONNECTION_MANAGER_ERROR = "TFE3003";
        String TRCFONE_POOLING_HTTP_CLIENT_CONNECTION_MANAGER_ERROR_MESSAGE = "Exception thrown from HTTP connection pool";

}
