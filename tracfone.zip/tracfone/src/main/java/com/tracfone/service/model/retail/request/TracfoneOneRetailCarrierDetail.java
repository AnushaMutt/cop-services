package com.tracfone.service.model.retail.request;

/**
 * C_RTL_CARRIER_DTL
 *
 * @author Pritesh Singh
 */
public class TracfoneOneRetailCarrierDetail {
    private String objId;
    private String status;
    private String cdtl2Carrier;
    private String cdtl2Brand;
    private String cdtl2Tech;
    private String cdtl2User;
    private String insertDate;
    private String updateDate;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCdtl2Carrier() {
        return cdtl2Carrier;
    }

    public void setCdtl2Carrier(String cdtl2Carrier) {
        this.cdtl2Carrier = cdtl2Carrier;
    }

    public String getCdtl2Brand() {
        return cdtl2Brand;
    }

    public void setCdtl2Brand(String cdtl2Brand) {
        this.cdtl2Brand = cdtl2Brand;
    }

    public String getCdtl2Tech() {
        return cdtl2Tech;
    }

    public void setCdtl2Tech(String cdtl2Tech) {
        this.cdtl2Tech = cdtl2Tech;
    }

    public String getCdtl2User() {
        return cdtl2User;
    }

    public void setCdtl2User(String cdtl2User) {
        this.cdtl2User = cdtl2User;
    }

    public String getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(String insertDate) {
        this.insertDate = insertDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    @Override
    public String toString() {
        return "TracfoneOneRetailCarrierDetail{" +
                "objId='" + objId + '\'' +
                ", status='" + status + '\'' +
                ", cdtl2Carrier='" + cdtl2Carrier + '\'' +
                ", cdtl2Brand='" + cdtl2Brand + '\'' +
                ", cdtl2Tech='" + cdtl2Tech + '\'' +
                ", cdtl2User='" + cdtl2User + '\'' +
                ", insertdate='" + insertDate + '\'' +
                ", updateDate='" + updateDate + '\'' +
                '}';
    }
}
