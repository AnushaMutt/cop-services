package com.tracfone.service.model.request;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

/**
 * @author Gaurav.Sharma
 */
public class TracfoneOneCarrierZones {

    private String dbEnv;
    private String zipCode;
    @Size(max = 2, message = "State cannot have more than 2 characters")
    private String state;
    @Size(max = 50, message = "County cannot have more than 50 characters")
    private String county;
    @Size(max = 100, message = "Zone cannot have more than 100 characters")
    private String zone;
    @Size(max = 30, message = "Rate Cente cannot have more than 30 characters")
    private String rateCente;
    @Digits(integer = 10, fraction = 0, message = "Market Id must be a number")
    private String marketId;
    @Size(max = 33, message = "Markter Area cannot have more than 33 characters")
    private String marketArea;
    @Size(max = 100, message = "City cannot have more than 100 characters")
    private String city;
    @Size(max = 4, message = "BTA Market Number cannot have more than 4 characters")
    private String btaMarketNumber;
    @Size(max = 100, message = "BTA Market Name cannot have more than 100 characters")
    private String btaMarketName;
    @Digits(integer = 126, fraction = 0, message = "Carrier Id must be a number")
    private String carrierId;
    @Size(max = 255, message = "Carrier Name cannot have more than 255 characters")
    private String carrierName;
    @Size(max = 15, message = "Zip Status cannot have more than 15 characters")
    private String zipStatus;
    @Size(max = 30, message = "SIM Profile cannot have more than 30 characters")
    private String simProfile;
    @Size(max = 30, message = "SIM Profile 2 cannot have more than 30 characters")
    private String simProfile2;
    @Size(max = 40, message = "Plan Type cannot have more than 40 characters")
    private String planType;
    private String carrierRank;
    private int newRank;
    private String reasonToFail;
    private String techReasonToFail;
    private String oldZipCode;
    @Size(max = 2, message = "State cannot have more than 2 characters")
    private String oldState;
    @Size(max = 50, message = "County cannot have more than 50 characters")
    private String oldCounty;
    @Size(max = 100, message = "Zone cannot have more than 100 characters")
    private String oldZone;
    @Size(max = 255, message = "Carrier Name cannot have more than 255 characters")
    private String oldCarrierName;
    private boolean checkDuplicate;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public String getRateCente() {
        return rateCente;
    }

    public void setRateCente(String rateCente) {
        this.rateCente = rateCente;
    }

    public String getMarketId() {
        return marketId;
    }

    public void setMarketId(String marketId) {
        this.marketId = marketId;
    }

    public String getMarketArea() {
        return marketArea;
    }

    public void setMarketArea(String marketArea) {
        this.marketArea = marketArea;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getBtaMarketNumber() {
        return btaMarketNumber;
    }

    public void setBtaMarketNumber(String btaMarketNumber) {
        this.btaMarketNumber = btaMarketNumber;
    }

    public String getBtaMarketName() {
        return btaMarketName;
    }

    public void setBtaMarketName(String btaMarketName) {
        this.btaMarketName = btaMarketName;
    }

    public String getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(String carrierId) {
        this.carrierId = carrierId;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getZipStatus() {
        return zipStatus;
    }

    public void setZipStatus(String zipStatus) {
        this.zipStatus = zipStatus;
    }

    public String getSimProfile() {
        return simProfile;
    }

    public void setSimProfile(String simProfile) {
        this.simProfile = simProfile;
    }

    public String getSimProfile2() {
        return simProfile2;
    }

    public void setSimProfile2(String simProfile2) {
        this.simProfile2 = simProfile2;
    }

    public String getPlanType() {
        return planType;
    }

    public void setPlanType(String planType) {
        this.planType = planType;
    }

    public String getCarrierRank() {
        return carrierRank;
    }

    public void setCarrierRank(String carrierRank) {
        this.carrierRank = carrierRank;
    }

    public int getNewRank() {
        return newRank;
    }

    public void setNewRank(int newRank) {
        this.newRank = newRank;
    }

    public String getReasonToFail() {
        return reasonToFail;
    }

    public void setReasonToFail(String reasonToFail) {
        this.reasonToFail = reasonToFail;
    }

    public String getTechReasonToFail() {
        return techReasonToFail;
    }

    public void setTechReasonToFail(String techReasonToFail) {
        this.techReasonToFail = techReasonToFail;
    }

    public String getOldZipCode() {
        return oldZipCode;
    }

    public void setOldZipCode(String oldZipCode) {
        this.oldZipCode = oldZipCode;
    }

    public String getOldState() {
        return oldState;
    }

    public void setOldState(String oldState) {
        this.oldState = oldState;
    }

    public String getOldCounty() {
        return oldCounty;
    }

    public void setOldCounty(String oldCounty) {
        this.oldCounty = oldCounty;
    }

    public String getOldZone() {
        return oldZone;
    }

    public void setOldZone(String oldZone) {
        this.oldZone = oldZone;
    }

    public String getOldCarrierName() {
        return oldCarrierName;
    }

    public void setOldCarrierName(String oldCarrierName) {
        this.oldCarrierName = oldCarrierName;
    }

    public boolean isCheckDuplicate() {
        return checkDuplicate;
    }

    public void setCheckDuplicate(boolean checkDuplicate) {
        this.checkDuplicate = checkDuplicate;
    }

    @Override
    public String toString() {
        return "TracfoneOneCarrierZones{" +
                "dbEnv='" + dbEnv + '\'' +
                ", zipCode='" + zipCode + '\'' +
                ", state='" + state + '\'' +
                ", county='" + county + '\'' +
                ", zone='" + zone + '\'' +
                ", rateCente='" + rateCente + '\'' +
                ", marketId='" + marketId + '\'' +
                ", marketArea='" + marketArea + '\'' +
                ", city='" + city + '\'' +
                ", btaMarketNumber='" + btaMarketNumber + '\'' +
                ", btaMarketName='" + btaMarketName + '\'' +
                ", carrierId='" + carrierId + '\'' +
                ", carrierName='" + carrierName + '\'' +
                ", zipStatus='" + zipStatus + '\'' +
                ", simProfile='" + simProfile + '\'' +
                ", simProfile2='" + simProfile2 + '\'' +
                ", planType='" + planType + '\'' +
                ", carrierRank='" + carrierRank + '\'' +
                ", newRank=" + newRank +
                ", reasonToFail='" + reasonToFail + '\'' +
                ", techReasonToFail='" + techReasonToFail + '\'' +
                ", oldZipCode='" + oldZipCode + '\'' +
                ", oldState='" + oldState + '\'' +
                ", oldCounty='" + oldCounty + '\'' +
                ", oldZone='" + oldZone + '\'' +
                ", oldCarrierName='" + oldCarrierName + '\'' +
                ", checkDuplicate=" + checkDuplicate +
                '}';
    }
}
