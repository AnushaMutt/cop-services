/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.model.response;

import java.util.List;

/**
 *
 * @author Shireen Fathima
 */
public class TFOneBucket {
    
    private String bucketId;
    private String activeFlag;
    private String measureUnit;
    private String bucketDesc;
    private String bucketType;
    private String ratePlan;
    private String suiDisplayType;
    private String bucketGroup;
    private String priorityGroup;
    private TFOneBucketList tfOneBucketList;
    private List<String> bucketIdConfigurations;
    private List<String> carrierProfileBuckets;
    private List<String> carrierProfileChildBuckets;

    public String getBucketId() {
        return bucketId;
    }

    public void setBucketId(String bucketId) {
        this.bucketId = bucketId;
    }

    public String getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(String activeFlag) {
        this.activeFlag = activeFlag;
    }

    public String getMeasureUnit() {
        return measureUnit;
    }

    public void setMeasureUnit(String measureUnit) {
        this.measureUnit = measureUnit;
    }

    public String getBucketDesc() {
        return bucketDesc;
    }

    public void setBucketDesc(String bucketDesc) {
        this.bucketDesc = bucketDesc;
    }

    public String getBucketType() {
        return bucketType;
    }

    public void setBucketType(String bucketType) {
        this.bucketType = bucketType;
    }

    public String getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(String ratePlan) {
        this.ratePlan = ratePlan;
    }

    public String getSuiDisplayType() {
        return suiDisplayType;
    }

    public void setSuiDisplayType(String suiDisplayType) {
        this.suiDisplayType = suiDisplayType;
    }

    public String getBucketGroup() {
        return bucketGroup;
    }

    public void setBucketGroup(String bucketGroup) {
        this.bucketGroup = bucketGroup;
    }

    public String getPriorityGroup() {
        return priorityGroup;
    }

    public void setPriorityGroup(String priorityGroup) {
        this.priorityGroup = priorityGroup;
    }

    public TFOneBucketList getTfOneBucketList() {
        return tfOneBucketList;
    }

    public void setTfOneBucketList(TFOneBucketList tfOneBucketList) {
        this.tfOneBucketList = tfOneBucketList;
    }

    public List<String> getBucketIdConfigurations() {
        return bucketIdConfigurations;
    }

    public void setBucketIdConfigurations(List<String> bucketIdConfigurations) {
        this.bucketIdConfigurations = bucketIdConfigurations;
    }

    public List<String> getCarrierProfileBuckets() {
        return carrierProfileBuckets;
    }

    public void setCarrierProfileBuckets(List<String> carrierProfileBuckets) {
        this.carrierProfileBuckets = carrierProfileBuckets;
    }

    public List<String> getCarrierProfileChildBuckets() {
        return carrierProfileChildBuckets;
    }

    public void setCarrierProfileChildBuckets(List<String> carrierProfileChildBuckets) {
        this.carrierProfileChildBuckets = carrierProfileChildBuckets;
    }

    @Override
    public String toString() {
        return "TFOneBucket{" + "bucketId=" + bucketId + ", "
                + "activeFlag=" + activeFlag + ", "
                + "measureUnit=" + measureUnit + ", "
                + "bucketDesc=" + bucketDesc + ", "
                + "bucketType=" + bucketType + ", "
                + "ratePlan=" + ratePlan + ", "
                + "suiDisplayType=" + suiDisplayType + ", "
                + "bucketGroup=" + bucketGroup + ", "
                + "priorityGroup=" + priorityGroup + ", "
                + "tfOneBucketList=" + tfOneBucketList + ", "
                + "bucketIdConfigurations=" + bucketIdConfigurations + ", "
                + "carrierProfileBuckets=" + carrierProfileBuckets + ", "
                + "carrierProfileChildBuckets=" + carrierProfileChildBuckets + '}';
    }
    
}
