/*
 * TracFone Wireless, Inc.
 */
package com.tracfone.service.util;

/**
 * This is a constant file that will be used for the throttle transaction wizard
 *
 * @author Gaurav.Sharma
 */
public interface TracfoneOneConstantThrottleTrans {

    // ERROR MESSAGES
    String TRACFONE_GET_THROTTLE_TRANSACTION_ERROR = "TFE1800";
    String TRACFONE_GET_THROTTLE_TRANSACTION_ERROR_MESSAGE = "Unable to get Throttle Transactions";

    String TRACFONE_REWORK_THROTTLE_TRANSACTION_ERROR = "TFE1801";
    String TRACFONE_REWORK_THROTTLE_TRANSACTION_ERROR_MESSAGE = "Unable to rework Throttle Transactions";

    String TRACFONE_REQUEUE_THROTTLE_TRANSACTION_ERROR = "TFE1802";
    String TRACFONE_REQUEUE_THROTTLE_TRANSACTION_ERROR_MESSAGE = "Unable to requeue Throttle Transactions";

    String TRACFONE_ADD_THROTTLE_TRANSACTION_ERROR = "TFE1803";
    String TRACFONE_ADD_THROTTLE_TRANSACTION_ERROR_MESSAGE = "Unable to add Throttle Transaction";

    String TRACFONE_GET_POLICY_NAME_ERROR = "TFE1804";
    String TRACFONE_GET_POLICY_NAME_ERROR_MESSAGE = "Unable to get Policy Name";

    String TRACFONE_ADD_THROTTLE_TRANSACTION_TYPE_ERROR = "TFE1805";
    String TRACFONE_ADD_THROTTLE_TRANSACTION_TYPE_ERROR_MESSAGE = "Throttle Transaction Type can be only TTON, TTOFF, HSBON, HSBOF";

    String TRACFONE_GET_USAGE_TIER_ID_ERROR = "TFE1806";
    String TRACFONE_GET_USAGE_TIER_ID_ERROR_MESSAGE = "Unable to get Usage Tier Id";

    String TRACFONE_GET_COS_ERROR = "TFE1807";
    String TRACFONE_GET_COS_ERROR_MESSAGE = "Unable to get COS";

    String TRACFONE_GET_PRIORITY_ERROR = "TFE1808";
    String TRACFONE_GET_PRIORITY_ERROR_MESSAGE = "Unable to get Priority";

    String TRACFONE_GET_THRESHOLD_ERROR = "TFE1809";
    String TRACFONE_GET_THRESHOLD_ERROR_MESSAGE = "Unable to get Threshold";

    String TRACFONE_GET_ENTITLEMENT_ERROR = "TFE1810";
    String TRACFONE_GET_ENTITLEMENT_ERROR_MESSAGE = "Unable to get Entitlement";

    String TRACFONE_GET_RULE_ID_ERROR = "TFE1811";
    String TRACFONE_GET_RULE_ID_ERROR_MESSAGE = "Unable to get Rule Id";

    /**
     * Database Queries
     */
    String THROTTLE_TRANSACTION_START = "select * from ( " +
            "select /*+ FIRST_ROWS(n) */ a.*, ROWNUM rnum from (";

    String GET_THROTTLE_TRANSACTION = "select * from W3CI.table_x_throttling_transaction tt where ";

    String GET_THROTTLE_TRANSACTION_COUNT = "SELECT count(1) AS totalRecords FROM W3CI.table_x_throttling_transaction tt where ";

    String SEARCH_THROTTLE_REWORKTRANSACTION = "DECLARE\n"
            + "  counter1               number:=0;\n"
            + "  counter2               number:=0;\n"
            + "  user_history_id        number:=0;\n"
            + "  id_detail_clob         CLOB;\n"
            + "  temp_clob              CLOB;\n"
            + "  v_userId               number:=?;\n"
            + "  v_type                 VARCHAR2(20):=?;\n"
            + "\n"
            + "cursor c1 is\n"
            + "SELECT  distinct\n"
            + "        cg.x_Carrier_name,   \n"
            + "        TTP.OBJID x_policy_objid,\n"
            + "        TTP.X_POLICY_DESCRIPTION,\n"
            + "        tig.*\n"
            + "FROM    W3CI.TABLE_X_THROTTLING_TRANSACTION tig left outer join \n"
            + "        W3CI.TABLE_X_THROTTLING_RULE ttr on ttr.objid = tig.x_rule_id left outer join\n"
            + "        table_X_parent p on p.objid  = ttr.x_parent_id left outer join\n"
            + "        table_x_carrier_group cg on p.objid  = cg.x_carrier_group2x_parent left outer join\n"
            + "        W3CI.TABLE_X_THROTTLING_POLICY ttp on ttp.objid = ttr.x_policy_id\n"
            + "WHERE ";

    String THROTTLE_REWORKTRANSACTION_NEWTANSACTIONCHECK = "\n\nfunction fun_newer_trans (f_min in varchar2,f_trans_type in varchar2,f_objid in number) return boolean as\n"
            + "cursor f1 is\n"
            + "select  *\n"
            + "from    W3CI.TABLE_X_THROTTLING_TRANSACTION\n"
            + "where   x_min = f_min\n"
            + "and     objid||'' > f_objid\n"
            + "order by objid;\n"
            + "f1_rec f1%rowtype;\n"
            + "\n"
            + "begin\n"
            + "open f1;\n"
            + " fetch f1 into f1_rec;\n"
            + "  if f1%notfound then\n"
            + "   close f1;\n"
            + "   return false;   \n"
            + "  end if;\n"
            + "close f1;\n"
            + "\n"
            + "if f_trans_type in ('TTON','HSBON') and f1_rec.x_transact_type in ('TTOFF','HSBOFF') then \n"
            + " return true;\n"
            + "elsif f_trans_type in ('TTOFF','HSBOFF','TTON','HSBON') and f_trans_type = f1_rec.x_transact_type then\n"
            + " return true;\n"
            + "elsif f_trans_type in ('TTOFF','HSBOFF') and f1_rec.x_transact_type in ('TTON','HSBON') then\n"
            + " return true;\n"
            + "else\n"
            + " return false; \n"
            + "end if;\n"
            + "end fun_newer_trans;\n\n";

    String THROTTLE_REWORKTRANSACTION_START = "BEGIN\n"
            + "     user_history_id := COP.SEQ_COP_ID_USER_HISTORY.NEXTVAL;\n"
            + "     dbms_lob.createtemporary(id_detail_clob, TRUE);\n"
            + "for rec1 in c1\n"
            + "loop\n"
            + "  if fun_newer_trans(rec1.x_min,rec1.x_transact_type,rec1.objid) then\n"
            + "    update w3ci.table_x_throttling_transaction\n"
            + "       set x_status = 'W',\n"
            + "        x_api_message = 'new_trans_found'\n"
            + "     WHERE objid = rec1.objid;\n"
            + "     commit;\n"
            + "     counter1:= counter1 + 1;\n"
            + "  else \n"
            + "    update w3ci.table_x_throttling_transaction tig\n"
            + "       set ";

    String THROTTLE_REWORKTRANSACTION_END = "\nWHERE objid = rec1.objid;\n"
            + "     commit;\n"
            + "     counter2:= counter2 + 1;\n"
            + "  end if;\n"
            + "     IF id_detail_clob = empty_clob() THEN \n"
            + "         temp_clob := to_clob(rec1.objid);\n"
            + "         DBMS_LOB.APPEND(id_detail_clob, temp_clob);\n"
            + "     ELSE\n"
            + "         temp_clob := ',' || to_clob(rec1.objid);\n"
            + "         DBMS_LOB.APPEND(id_detail_clob, temp_clob);\n"
            + "     END IF;\n"
            + "end loop;\n\n"
            + "BEGIN\n"
            + "     insert into COP.COP_ID_USER_HISTORY (ID, USER_ID, TYPE, CREATION_DATE, UPDATE_DATE) \n"
            + "     values (user_history_id, v_userId, v_type, sysdate, sysdate);\n"
            + "     insert into COP.COP_ID_USER_HISTORY_DETAIL (ID, HISTORY_ID, ID_TYPE, ID_DETAIL, CREATION_DATE, UPDATE_DATE)\n"
            + "     values (COP.SEQ_COP_ID_USER_HISTORY_DETAIL.NEXTVAL, user_history_id, 'TRANSACTION_ID', id_detail_clob, sysdate, sysdate);\n"
            + "     commit;\n"
            + "EXCEPTION\n"
            + "WHEN others THEN\n"
            + "dbms_output.put_line('In this block');\n"
            + "END;\n"
            + "dbms_output.put_line('counter1_new_trans_found:'||to_char(counter1));\n"
            + "dbms_output.put_line('counter2_requeued:'||to_char(counter2));\n"
            + "END;";

    String TRACFONE_GENERATE_TTON_THROTTLE_TRANSACTION = "{call W3CI.THROTTLING.SP_THROTTLING_VALVE(\n" +
            "    P_MIN => ?,\n" +
            "    P_ESN => ?,\n" +
            "    P_POLICY_NAME => ?,\n" +
            "    P_TRANSACTION_NUM => ?,\n" +
            "    P_ERROR_CODE => ?,\n" +
            "    P_ERROR_MESSAGE => ?,\n" +
            "    P_CREATION_DATE => sysdate\n" +
            "    --p_bypass_off=>P_bypass_off\n" +
            "  )}";
    String TRACFONE_GENERATE_TTOFF_THROTTLE_TRANSACTION = "{call W3CI.THROTTLING.sp_expire_cache(\n" +
            "    P_MIN => ?,\n" +
            "    P_ESN => ?,\n" +
            "    P_ERROR_CODE => ?,\n" +
            "    P_ERROR_MESSAGE => ?,\n" +
            "    P_BYPASS_OFF => ?\n" +
            "  )}";
    String TRACFONE_GENERATE_HSBON_THROTTLE_TRANSACTION = "{call SA.SERVICE_PROFILE_PKG.THROTTLE_SUBSCRIBER(\n" +
            "    I_SOURCE => ?,\n" +
            "    I_MIN => ?,\n" +
            "    I_PARENT_NAME => ?,\n" +
            "    I_USAGE_TIER_ID => ?,\n" +
            "    I_POLICY_NAME => ?,\n" +
            "    O_ERR_CODE => ?,\n" +
            "    O_ERR_MSG => ?,\n" +
            "    I_THROTTLE_GROUP_TYPE => ?,\n" +
            "    I_THRESHOLD_REACHED_TIME => sysdate\n" +
            "  )}";

    String TRACFONE_GET_ALL_POLICY_NAME = "select OBJID, X_POLICY_NAME, X_POLICY_DESCRIPTION from W3CI.TABLE_X_THROTTLING_POLICY";

    String TRACFONE_TT_SEQ_STMT = "SELECT w3ci.sequ_x_throttling_transaction.nextval AS TT_OBJID_SEQ from dual";

    String TRACFONE_GET_ALL_USAGE_TIER_ID = "SELECT distinct USAGE_TIER_ID FROM X_USAGE_TIER";

    String TRACFONE_GET_ALL_COS = "SELECT distinct COS FROM sa.X_COS";

    String TRACFONE_GET_PRIORITY = "SELECT distinct QUEUE_PRIORITY FROM sa.X_COS where COS = ?";

    String TRACFONE_GET_RULE_ID = "SELECT distinct tr.objid from W3CI.TABLE_X_THROTTLING_POLICY tp, W3CI.TABLE_X_THROTTLING_RULE tr " +
            "where tp.objid = tr.X_POLICY_ID and tp.objid = ?";
}