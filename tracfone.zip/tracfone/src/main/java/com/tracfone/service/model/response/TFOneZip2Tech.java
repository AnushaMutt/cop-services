package com.tracfone.service.model.response;

import com.tracfone.service.model.request.TracfoneonePaginationSearch;

public class TFOneZip2Tech {

    private String dbEnv;
    private String zips;
    private String state;
    private String county;
    private String pref1;
    private String pref2;
    private String service;
    private String language;
    private String action;
    private String market;
    private String zip2;
    private String aid;
    private String vid;
    private String vc;
    private String sahcid;
    private String com;
    private String locale;
    private String siteType;
    private String gotoPhoneList;
    private String tech;
    private String techZip;
    private String techkey;
    private String prefParent;
    private TracfoneonePaginationSearch paginationSearch;

    public String getDbEnv() {
        return dbEnv;
    }

    public void setDbEnv(String dbEnv) {
        this.dbEnv = dbEnv;
    }

    public String getZips() {
        return zips;
    }

    public void setZips(String zips) {
        this.zips = zips;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getPref1() {
        return pref1;
    }

    public void setPref1(String pref1) {
        this.pref1 = pref1;
    }

    public String getPref2() {
        return pref2;
    }

    public void setPref2(String pref2) {
        this.pref2 = pref2;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getMarket() {
        return market;
    }

    public void setMarket(String market) {
        this.market = market;
    }

    public String getZip2() {
        return zip2;
    }

    public void setZip2(String zip2) {
        this.zip2 = zip2;
    }

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getVid() {
        return vid;
    }

    public void setVid(String vid) {
        this.vid = vid;
    }

    public String getVc() {
        return vc;
    }

    public void setVc(String vc) {
        this.vc = vc;
    }

    public String getSahcid() {
        return sahcid;
    }

    public void setSahcid(String sahcid) {
        this.sahcid = sahcid;
    }

    public String getCom() {
        return com;
    }

    public void setCom(String com) {
        this.com = com;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    public String getSiteType() {
        return siteType;
    }

    public void setSiteType(String siteType) {
        this.siteType = siteType;
    }

    public String getGotoPhoneList() {
        return gotoPhoneList;
    }

    public void setGotoPhoneList(String gotoPhoneList) {
        this.gotoPhoneList = gotoPhoneList;
    }

    public String getTech() {
        return tech;
    }

    public void setTech(String tech) {
        this.tech = tech;
    }

    public String getTechZip() {
        return techZip;
    }

    public void setTechZip(String techZip) {
        this.techZip = techZip;
    }

    public String getTechkey() {
        return techkey;
    }

    public void setTechkey(String techkey) {
        this.techkey = techkey;
    }

    public String getPrefParent() {
        return prefParent;
    }

    public void setPrefParent(String prefParent) {
        this.prefParent = prefParent;
    }

    public TracfoneonePaginationSearch getPaginationSearch() {
        return paginationSearch;
    }

    public void setPaginationSearch(TracfoneonePaginationSearch paginationSearch) {
        this.paginationSearch = paginationSearch;
    }

    @Override
    public String toString() {
        return "TFOneZip2Tech{" +
                "dbEnv='" + dbEnv + '\'' +
                ", zips='" + zips + '\'' +
                ", state='" + state + '\'' +
                ", county='" + county + '\'' +
                ", pref1='" + pref1 + '\'' +
                ", pref2='" + pref2 + '\'' +
                ", service='" + service + '\'' +
                ", language='" + language + '\'' +
                ", action='" + action + '\'' +
                ", market='" + market + '\'' +
                ", zip2='" + zip2 + '\'' +
                ", aid='" + aid + '\'' +
                ", vid='" + vid + '\'' +
                ", vc='" + vc + '\'' +
                ", sahcid='" + sahcid + '\'' +
                ", com='" + com + '\'' +
                ", locale='" + locale + '\'' +
                ", siteType='" + siteType + '\'' +
                ", gotoPhoneList='" + gotoPhoneList + '\'' +
                ", tech='" + tech + '\'' +
                ", techZip='" + techZip + '\'' +
                ", techkey='" + techkey + '\'' +
                ", prefParent='" + prefParent + '\'' +
                ", paginationSearch=" + paginationSearch +
                '}';
    }
}

