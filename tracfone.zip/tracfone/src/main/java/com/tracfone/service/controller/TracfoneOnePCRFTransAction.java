package com.tracfone.service.controller;

import com.mysql.jdbc.StringUtils;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOnePCRFTransaction;
import com.tracfone.service.model.request.TracfoneOneSearchAdditionalModel;
import com.tracfone.service.model.request.TracfoneonePaginationSearch;
import com.tracfone.service.model.response.TFOnePCRFTransSearchResult;
import com.tracfone.service.model.response.TFOnePCRFTransaction;
import com.tracfone.service.util.PCRFTransControllerUtil;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantPCRFTrans;
import jersey.repackaged.com.google.common.collect.Lists;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

/**
 * @author Gaurav.Sharma
 */
@Stateless
public class TracfoneOnePCRFTransAction implements TracfoneOnePCRFTransActionLocal, TracfoneOneConstantPCRFTrans, TracfoneOneConstant {

    private static final Logger LOGGER = LogManager.getLogger(TracfoneOnePCRFTransAction.class);

    @EJB
    private DataBaseController dbControllerEJB;

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    private static final String NULL = "NULL";
    private static final String AND = " AND ";
    private static final String OR = " OR ";

    @Override
    public TFOnePCRFTransSearchResult viewPcrfTransaction(TracfoneOnePCRFTransaction pcrfTransactions) throws TracfoneOneException {
        TFOnePCRFTransSearchResult pcrfTransSearchResult = new TFOnePCRFTransSearchResult();
        try (Connection con = dbControllerEJB.getDataSource(pcrfTransactions.getDbEnv()).getConnection();
             PreparedStatement stmt = con.prepareStatement(getPcrfTransactionStatement(PCRF_TRANSACTION_START, pcrfTransactions));
             PreparedStatement stmtCount = con.prepareStatement(generateDynamicSearchQuery(GET_PCRF_TRANSACTION_COUNT, pcrfTransactions, "pt."));) {

            setViewPcrfTransactionStatement(stmt, stmtCount, pcrfTransactions);
            TFOnePCRFTransaction pcrfTransaction;
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    pcrfTransaction = setPcrfTransaction(resultSet);
                    pcrfTransSearchResult.getPcrfTransactions().add(pcrfTransaction);
                }
            }

            int count = 0;
            try (ResultSet resultSetCount = stmtCount.executeQuery()) {
                while (resultSetCount.next()) {
                    count = resultSetCount.getInt(1);
                }
            }
            LOGGER.info("Total Count " + count);
            TracfoneonePaginationSearch tracfoneonePaginationSearch = new TracfoneonePaginationSearch();
            tracfoneonePaginationSearch.setStartIndex(pcrfTransactions.getPaginationSearch().getStartIndex());
            tracfoneonePaginationSearch.setEndIndex(pcrfTransactions.getPaginationSearch().getEndIndex());
            tracfoneonePaginationSearch.setTotal(count);
            pcrfTransSearchResult.setPaginationSearch(tracfoneonePaginationSearch);
            LOGGER.info("Result " + pcrfTransSearchResult);
        } catch (SQLException | NamingException e) {
            LOGGER.error(TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
            throw new TracfoneOneException(TRACFONE_DATASOURCE_CONNECTION_ERROR_CODE,
                    TRACFONE_DATASOURCE_CONNECTION_ERROR_MESSAGE, e);
        }
        return pcrfTransSearchResult;
    }

    private String getPcrfTransactionStatement(String query, TracfoneOnePCRFTransaction tracfoneOnePcrfTransaction) {
        boolean pagination = false;
        int startIndex = 0;
        int endIndex = 0;
        if (tracfoneOnePcrfTransaction.getPaginationSearch() != null) {
            startIndex = tracfoneOnePcrfTransaction.getPaginationSearch().getStartIndex();
            endIndex = tracfoneOnePcrfTransaction.getPaginationSearch().getEndIndex();
            pagination = (endIndex - startIndex) <= TracfoneOneConstant.FETCH_SIZE;
        }

        StringBuilder sBuilder = new StringBuilder(generateDynamicSearchQuery(query + GET_PCRF_TRANSACTION, tracfoneOnePcrfTransaction, "pt."));
        // Pagination check for large result queries.
        if (pagination) {
            // Adding 1 to each of these since a ROWNUM of 0 never exists and it is being sent this way from the UI
            startIndex++;
            endIndex++;
            sBuilder.append(") a "
                    + "where ROWNUM < "
                    + endIndex + ") "
                    + "where rnum  >= " + startIndex);
        } else {
            TracfoneonePaginationSearch defaultPagination = new TracfoneonePaginationSearch();
            defaultPagination.setStartIndex(1);
            defaultPagination.setEndIndex(1000);
            tracfoneOnePcrfTransaction.setPaginationSearch(defaultPagination);
            sBuilder.append(") a "
                    + " where ROWNUM < "
                    + "1000 ) "
                    + "where rnum  >= 0");
        }

        LOGGER.info("The search query is " + sBuilder.toString());
        return sBuilder.toString();
    }

    private String generateDynamicSearchQuery(String query, TracfoneOnePCRFTransaction tracfoneOnePcrfTransaction, String alias) {
        StringBuilder sBuilder = new StringBuilder(query);
        String dbColumnName = null;
        for (TracfoneOneSearchAdditionalModel searchColumn : tracfoneOnePcrfTransaction.getSearchColumns()) {
            LOGGER.info("Request values for " + searchColumn.getSearchColumnName() + " are " + searchColumn.getSearchValues());
            dbColumnName = alias.concat(PCRFTransControllerUtil.getDBColumnName(searchColumn.getSearchColumnName()));

            if ("objId".equalsIgnoreCase(dbColumnName)) {
                sBuilder = handleSearchQueryForObjIds(sBuilder, dbColumnName, searchColumn.getSearchValues());
            } else {
                if (NULL.equalsIgnoreCase(searchColumn.getSearchValues().get(0))) {
                    sBuilder = buildNullClause(sBuilder, dbColumnName, "").append(AND);
                } else if (searchColumn.isSearchIsColumnNotIn()) {
                    sBuilder = buildNullOrNotInClause(searchColumn.getSearchValues().size(), sBuilder, dbColumnName);
                } else if (searchColumn.isSearchIsColumnLike()) {
                    sBuilder = buildQueryParamStringForLike(sBuilder, dbColumnName);
                } else {
                    sBuilder = buildQueryParamString(searchColumn.getSearchValues().size(), sBuilder, dbColumnName);
                }
            }
        }

        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getFromInsertTimestamp())) {
            sBuilder.append(" INSERT_TIMESTAMP >= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND INSERT_TIMESTAMP <= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ");
        } else if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getToInsertTimestamp())) {
            sBuilder.append(" INSERT_TIMESTAMP <= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getFromUpdateTimestamp())) {
            sBuilder.append(" UPDATE_TIMESTAMP >= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND UPDATE_TIMESTAMP <= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ");
        } else if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getToUpdateTimestamp())) {
            sBuilder.append(" UPDATE_TIMESTAMP <= TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getInstallDate())) {
            sBuilder.append(" INSTALL_DATE = TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getTtl())) {
            sBuilder.append(" TTL = TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getFutureTtl())) {
            sBuilder.append(" FUTURE_TTL = TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getRedemptionDate())) {
            sBuilder.append(" REDEMPTION_DATE = TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getDateField1())) {
            sBuilder.append(" DATE_FIELD_1 = TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ");
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getBlackoutWaitDate())) {
            sBuilder.append(" BLACKOUT_WAIT_DATE = TO_DATE(?, 'yyyy:MM:DD HH24:MI:SS') AND ");
        }
        LOGGER.info("generateDynamicSearchQuery " + sBuilder.toString());
        return sBuilder.substring(0, sBuilder.lastIndexOf(AND));
    }

    private StringBuilder handleSearchQueryForObjIds(StringBuilder sBuilder, String dbColumnName, List<String> searchValues) {
        if (searchValues.size() < 1000) {
            sBuilder = buildQueryParamString(searchValues.size(), sBuilder, dbColumnName);
        } else {
            List<List<String>> splitIds = Lists.partition(searchValues, 1000);
            sBuilder.append("(");
            StringBuilder transBuilder = new StringBuilder();
            for (List<String> objIds : splitIds) {
                StringBuilder tempBuilder = new StringBuilder();
                tempBuilder = buildQueryParamString(objIds.size(), tempBuilder, "ig.TRANSACTION_ID");
                transBuilder.append(tempBuilder.substring(4));
                transBuilder.append(OR);
                LOGGER.info("transactions ids query " + transBuilder);
            }
            sBuilder = sBuilder.append(transBuilder.substring(0, transBuilder.lastIndexOf(OR))).append(")");
            LOGGER.info("sBuilder split query " + sBuilder);
        }
        return sBuilder;
    }

    private void setViewPcrfTransactionStatement(PreparedStatement stmt, PreparedStatement stmtCount, TracfoneOnePCRFTransaction tracfoneOnePcrfTransaction) throws SQLException {
        int index = 1;
        for (TracfoneOneSearchAdditionalModel column : tracfoneOnePcrfTransaction.getSearchColumns()) {
            for (String fieldValue : column.getSearchValues()) {
                if (NULL.equalsIgnoreCase(fieldValue)) {
                    break;
                }
                if (column.isSearchIsColumnLike()) {
                    stmt.setString(index, "%" + fieldValue.trim() + "%");
                    stmtCount.setString(index++, "%" + fieldValue.trim() + "%");
                } else {
                    stmt.setString(index, fieldValue.trim());
                    stmtCount.setString(index++, fieldValue.trim());
                }
            }
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getFromInsertTimestamp())) {
            stmt.setString(index, tracfoneOnePcrfTransaction.getFromInsertTimestamp().trim());
            stmtCount.setString(index++, tracfoneOnePcrfTransaction.getFromInsertTimestamp().trim());
            //to date
            if (tracfoneOnePcrfTransaction.getToInsertTimestamp() != null && !tracfoneOnePcrfTransaction.getToInsertTimestamp().isEmpty()) {
                stmt.setString(index, tracfoneOnePcrfTransaction.getToInsertTimestamp().trim());
                stmtCount.setString(index++, tracfoneOnePcrfTransaction.getToInsertTimestamp().trim());
            } else {
                stmt.setString(index, getDefaultTodayDate().trim());
                stmtCount.setString(index++, getDefaultTodayDate().trim());
            }
        } else if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getToInsertTimestamp())) {
            stmt.setString(index, tracfoneOnePcrfTransaction.getToInsertTimestamp().trim());
            stmtCount.setString(index++, tracfoneOnePcrfTransaction.getToInsertTimestamp().trim());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getFromUpdateTimestamp())) {
            stmt.setString(index, tracfoneOnePcrfTransaction.getFromUpdateTimestamp().trim());
            stmtCount.setString(index++, tracfoneOnePcrfTransaction.getFromUpdateTimestamp().trim());
            //to date
            if (tracfoneOnePcrfTransaction.getToUpdateTimestamp() != null && !tracfoneOnePcrfTransaction.getToUpdateTimestamp().isEmpty()) {
                stmt.setString(index, tracfoneOnePcrfTransaction.getToUpdateTimestamp().trim());
                stmtCount.setString(index++, tracfoneOnePcrfTransaction.getToUpdateTimestamp().trim());
            } else {
                stmt.setString(index, getDefaultTodayDate().trim());
                stmtCount.setString(index++, getDefaultTodayDate().trim());
            }
        } else if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getToUpdateTimestamp())) {
            stmt.setString(index, tracfoneOnePcrfTransaction.getToUpdateTimestamp().trim());
            stmtCount.setString(index++, tracfoneOnePcrfTransaction.getToUpdateTimestamp().trim());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getInstallDate())) {
            stmt.setString(index, tracfoneOnePcrfTransaction.getInstallDate().trim());
            stmtCount.setString(index++, tracfoneOnePcrfTransaction.getInstallDate().trim());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getTtl())) {
            stmt.setString(index, tracfoneOnePcrfTransaction.getTtl().trim());
            stmtCount.setString(index++, tracfoneOnePcrfTransaction.getTtl().trim());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getFutureTtl())) {
            stmt.setString(index, tracfoneOnePcrfTransaction.getFutureTtl().trim());
            stmtCount.setString(index++, tracfoneOnePcrfTransaction.getFutureTtl().trim());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getRedemptionDate())) {
            stmt.setString(index, tracfoneOnePcrfTransaction.getRedemptionDate().trim());
            stmtCount.setString(index++, tracfoneOnePcrfTransaction.getRedemptionDate().trim());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getBlackoutWaitDate())) {
            stmt.setString(index, tracfoneOnePcrfTransaction.getBlackoutWaitDate().trim());
            stmtCount.setString(index++, tracfoneOnePcrfTransaction.getBlackoutWaitDate().trim());
        }
        if (!StringUtils.isNullOrEmpty(tracfoneOnePcrfTransaction.getDateField1())) {
            stmt.setString(index, tracfoneOnePcrfTransaction.getDateField1().trim());
            stmtCount.setString(index, tracfoneOnePcrfTransaction.getDateField1().trim());
        }
    }

    private TFOnePCRFTransaction setPcrfTransaction(ResultSet resultSet) throws SQLException {
        TFOnePCRFTransaction pcrfTransaction = new TFOnePCRFTransaction();
        pcrfTransaction.setObjId(resultSet.getString("OBJID"));
        pcrfTransaction.setActionType(resultSet.getString("ACTION_TYPE"));
        pcrfTransaction.setAddonsFlag(resultSet.getString("ADDONS_FLAG"));
        pcrfTransaction.setBlackoutWaitDate(resultSet.getString("BLACKOUT_WAIT_DATE"));
        pcrfTransaction.setBrand(resultSet.getString("BRAND"));
        pcrfTransaction.setMin(resultSet.getString("MIN"));
        pcrfTransaction.setEsn(resultSet.getString("ESN"));
        pcrfTransaction.setCaseId(resultSet.getString("CASE_ID"));
        pcrfTransaction.setCharField1(resultSet.getString("CHAR_FIELD_1"));
        pcrfTransaction.setCharField2(resultSet.getString("CHAR_FIELD_2"));
        pcrfTransaction.setCharField3(resultSet.getString("CHAR_FIELD_3"));
        pcrfTransaction.setContactObjId(resultSet.getString("CONTACT_OBJID"));
        pcrfTransaction.setContentDeliveryFormat(resultSet.getString("CONTENT_DELIVERY_FORMAT"));
        pcrfTransaction.setConversionFactor(resultSet.getString("CONVERSION_FACTOR"));
        pcrfTransaction.setSubscriberId(resultSet.getString("SUBSCRIBER_ID"));
        pcrfTransaction.setDataUsage(resultSet.getString("DATA_USAGE"));
        pcrfTransaction.setDateField1(resultSet.getString("DATE_FIELD_1"));
        pcrfTransaction.setGroupId(resultSet.getString("GROUP_ID"));
        pcrfTransaction.setDealerId(resultSet.getString("DEALER_ID"));
        pcrfTransaction.setDenomination(resultSet.getString("DENOMINATION"));
        pcrfTransaction.setFutureTtl(resultSet.getString("FUTURE_TTL"));
        pcrfTransaction.setHiSpeedDataUsage(resultSet.getString("HI_SPEED_DATA_USAGE"));
        pcrfTransaction.setImsi(resultSet.getString("IMSI"));
        pcrfTransaction.setInsertTimestamp(resultSet.getString("INSERT_TIMESTAMP"));
        pcrfTransaction.setInstallDate(resultSet.getString("INSTALL_DATE"));
        pcrfTransaction.setLanguage(resultSet.getString("LANGUAGE"));
        pcrfTransaction.setLifeLineId(resultSet.getString("LIFELINE_ID"));
        pcrfTransaction.setMdn(resultSet.getString("MDN"));
        pcrfTransaction.setOrderType(resultSet.getString("ORDER_TYPE"));
        pcrfTransaction.setPartInstStatus(resultSet.getString("PART_INST_STATUS"));
        pcrfTransaction.setPcrfCos(resultSet.getString("PCRF_COS"));
        pcrfTransaction.setPcrfParentName(resultSet.getString("PCRF_PARENT_NAME"));
        pcrfTransaction.setPcrfStatusCode(resultSet.getString("PCRF_STATUS_CODE"));
        pcrfTransaction.setPhoneManufacturer(resultSet.getString("PHONE_MANUFACTURER"));
        pcrfTransaction.setPhoneModel(resultSet.getString("PHONE_MODEL"));
        pcrfTransaction.setPosaFlag(resultSet.getString("POSA_FLAG"));
        pcrfTransaction.setProgramParameterId(resultSet.getString("PROGRAM_PARAMETER_ID"));
        pcrfTransaction.setPropagateFlag(resultSet.getString("PROPAGATE_FLAG"));
        pcrfTransaction.setRatePlan(resultSet.getString("RATE_PLAN"));
        pcrfTransaction.setRcsEnableFlag(resultSet.getString("RCS_ENABLE_FLAG"));
        pcrfTransaction.setRedemptionDate(resultSet.getString("REDEMPTION_DATE"));
        pcrfTransaction.setRetryCount(resultSet.getString("RETRY_COUNT"));
        pcrfTransaction.setServicePlanId(resultSet.getString("SERVICE_PLAN_ID"));
        pcrfTransaction.setSim(resultSet.getString("SIM"));
        pcrfTransaction.setSourceSystem(resultSet.getString("SOURCESYSTEM"));
        pcrfTransaction.setStatusMessage(resultSet.getString("STATUS_MESSAGE"));
        pcrfTransaction.setServicePlanType(resultSet.getString("SERVICE_PLAN_TYPE"));
        pcrfTransaction.setTemplate(resultSet.getString("TEMPLATE"));
        pcrfTransaction.setTtl(resultSet.getString("TTL"));
        pcrfTransaction.setUnlockStatus(resultSet.getString("UNLOCK_STATUS"));
        pcrfTransaction.setUpdateTimestamp(resultSet.getString("UPDATE_TIMESTAMP"));
        pcrfTransaction.setVmbcCertificationFlag(resultSet.getString("VMBC_CERTIFICATION_FLAG"));
        pcrfTransaction.setWebObjId(resultSet.getString("WEB_OBJID"));
        pcrfTransaction.setWfMacId(resultSet.getString("WF_MAC_ID"));
        pcrfTransaction.setZipCode(resultSet.getString("ZIPCODE"));

        return pcrfTransaction;
    }

    private StringBuilder buildNullOrNotInClause(int size, StringBuilder sbuilder, String optionalFieldName) {
        sbuilder = buildQueryParamStringForNotINs(size, sbuilder, optionalFieldName, true);
        sbuilder = buildNullClause(sbuilder, optionalFieldName, OR);
        return sbuilder.append(")").append(AND);
    }

    private StringBuilder buildNullClause(StringBuilder sbuilder, String fieldName, String connector) {
        return sbuilder.append(connector).append(fieldName).append(" IS NULL ");
    }

    private StringBuilder buildQueryParamStringForNotINs(int amountQueryParam, StringBuilder sBuilder, String queryParamName, boolean includeNullCheck) {
        if (amountQueryParam <= 0) {
            return sBuilder;
        }
        // Construct the insert param with the first value.
        if (includeNullCheck) {
            sBuilder.append("(");
        }
        sBuilder.append(queryParamName).append(" not in ( ").append("?");
        amountQueryParam -= 1;

        for (int i = 0; i < amountQueryParam; i++) {
            sBuilder.append(",?");
        }
        sBuilder.append(" )");
        return sBuilder;
    }

    private StringBuilder buildQueryParamStringForLike(StringBuilder sBuilder, String queryParamName) {
        return sBuilder.append(queryParamName).append(" like ? ").append(AND);
    }

    private StringBuilder buildQueryParamString(int amountQueryParam, StringBuilder sBuilder, String queryParamName) {
        if (amountQueryParam <= 0) {
            return sBuilder;
        }
        // Construct the insert param with the first value.
        sBuilder.append(queryParamName).append(" in ( ").append("?");
        amountQueryParam -= 1;

        for (int i = 0; i < amountQueryParam; i++) {
            sBuilder.append(",?");
        }
        sBuilder.append(" )").append(AND);
        return sBuilder;
    }

    private String getDefaultTodayDate() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy:MM:dd");
        return sdFormat.format(cal.getTime());
    }

}
