package com.tracfone.service.controller;

import com.google.gson.Gson;
import com.tracfone.ejb.entity.Action;
import com.tracfone.ejb.entity.Audit;
import com.tracfone.ejb.entity.Dbenvironment;
import com.tracfone.ejb.entity.Group;
import com.tracfone.ejb.entity.GroupActions;
import com.tracfone.ejb.entity.Roles;
import com.tracfone.ejb.entity.TFTransactionArchive;
import com.tracfone.ejb.entity.Tracfoneoneuser;
import com.tracfone.ejb.entity.Usergroups;
import com.tracfone.ejb.entity.retail.CRtlTFOneReport;
import com.tracfone.ejb.entity.retail.session.CRtlReportFacadeLocal;
import com.tracfone.ejb.entity.session.ActionFacadeLocal;
import com.tracfone.ejb.entity.session.AuditFacadeLocal;
import com.tracfone.ejb.entity.session.AuthorizationFacadeLocal;
import com.tracfone.ejb.entity.session.DbenvironmentFacadeLocal;
import com.tracfone.ejb.entity.session.GroupActionsFacadeLocal;
import com.tracfone.ejb.entity.session.GroupFacadeLocal;
import com.tracfone.ejb.entity.session.RolesFacadeLocal;
import com.tracfone.ejb.entity.session.TFOneReportFacadeLocal;
import com.tracfone.ejb.entity.session.TFTransactionArchiveFacadeLocal;
import com.tracfone.ejb.entity.session.TracfoneoneuserFacadeLocal;
import com.tracfone.ejb.entity.session.UserHistoryFacadeLocal;
import com.tracfone.ejb.entity.session.UserTaskFacadeLocal;
import com.tracfone.ejb.entity.session.UsergroupsFacadeLocal;
import com.tracfone.service.exception.TracfoneOneAuthorizationException;
import com.tracfone.service.exception.TracfoneOneException;
import com.tracfone.service.model.event.TracfoneAudit;
import com.tracfone.service.model.request.TracfoneOneAction;
import com.tracfone.service.model.request.TracfoneOneGroup;
import com.tracfone.service.model.request.TracfoneOneUserProfile;
import com.tracfone.service.model.response.TFOneAdminAction;
import com.tracfone.service.model.response.TFOneAdminGroup;
import com.tracfone.service.model.response.TFOneAdminProfile;
import com.tracfone.service.model.response.TFOneAdminRole;
import com.tracfone.service.model.response.TFOneAdminUser;
import com.tracfone.service.model.response.TFOneAuditHistory;
import com.tracfone.service.model.response.TFOneDatabaseEnvironment;
import com.tracfone.service.model.response.TFOneGeneralResponse;
import com.tracfone.service.model.response.TracfoneOneReport;
import com.tracfone.service.util.TracfoneOneConstant;
import com.tracfone.service.util.TracfoneOneConstantReport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.persistence.EntityNotFoundException;
import javax.xml.bind.DatatypeConverter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_REPORT_ALL_IG_FAILURES_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_REPORT_ALL_IG_FAILURES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_REPORT_ALL_PCRF_FAILURES_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_REPORT_ALL_PCRF_FAILURES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_REPORT_ALL_TT_FAILURES_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_REPORT_ALL_TT_FAILURES_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_REPORT_PCRF_MONITOR_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_REPORT_PCRF_MONITOR_ERROR_MESSAGE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_REPORT_TT_MONITOR_ERROR_CODE;
import static com.tracfone.service.util.TracfoneOneConstant.TRACFONE_REPORT_TT_MONITOR_ERROR_MESSAGE;

/**
 * @author user
 */
@Stateless
public class TracfoneController implements TracfoneControllerLocal {
    @EJB
    TracfoneEJBAdminUtilLocal tracfoneEJBAdminUtil;

    @EJB
    TracfoneoneuserFacadeLocal trafoneUserEJB;

    @EJB
    RolesFacadeLocal rolesEJB;

    @EJB
    UsergroupsFacadeLocal userGroupsEJB;

    @EJB
    ActionFacadeLocal actionEJB;

    @EJB
    GroupFacadeLocal groupEJB;

    @EJB
    GroupActionsFacadeLocal groupActionsEJB;

    @EJB
    TFOneReportFacadeLocal reportEJB;

    @EJB
    UserTaskFacadeLocal userTaskEJB;

    @EJB
    UserHistoryFacadeLocal userHistoryEJB;

    @EJB
    DbenvironmentFacadeLocal dbEnvEJB;

    @EJB
    AuthorizationFacadeLocal authorizationEJB;

    @EJB
    AuditFacadeLocal auditEJB;

    @EJB
    CRtlReportFacadeLocal cRtlReportFacadeLocal;

    @EJB
    TFTransactionArchiveFacadeLocal tfTransactionArchiveFacadeLocalEJB;

    private static final Logger logger = LogManager.getLogger(TracfoneController.class);

    @Inject
    private Event<TracfoneAudit> tracfoneAuditEvent;

    @Override
    public TFOneAdminUser login(String userName, String userLDAPPassword) throws TracfoneOneException {
        logger.debug("Enter: login - " + userName);
        return checkUserInTracfoneOne(userName);
    }

    @Override
    public TFOneGeneralResponse logout(String token) throws TracfoneOneException {
        try {
            Tracfoneoneuser tracfoneUser = this.getUserByToken(token);

            if (tracfoneUser != null) {
                tracfoneUser.setToken("");
                //update the empty token
                trafoneUserEJB.edit(tracfoneUser);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_INVALID_TRACFONEONE_LOGOUT_ERROR_CODE, TracfoneOneConstant.TRACFONE_INVALID_TRACFONEONE_LOGOUT_ERROR_MESSAGE, ex);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, "Logout Succesfull.");
    }

    private String generateUUIDForUser() {
        UUID uuid = UUID.randomUUID();
        String randomUUIDString = uuid.toString();
        byte[] message = randomUUIDString.getBytes(StandardCharsets.UTF_8);
        return DatatypeConverter.printBase64Binary(message);
    }


    /**
     * @param userName
     * @return
     * @throws TracfoneOneException
     */
    private TFOneAdminUser checkUserInTracfoneOne(String userName) throws TracfoneOneException {
        Tracfoneoneuser tracfoneUser = null;
        TFOneAdminUser tfUser = null;
        try {

            tracfoneUser = trafoneUserEJB.findTracfoneUserByName(userName);
            if (tracfoneUser != null) {
                String uuidUser = generateUUIDForUser();
                //update the token in the database for the user
                tracfoneUser.setToken(uuidUser);
                trafoneUserEJB.edit(tracfoneUser);

                //create the Response Model TFUser
                tfUser = new TFOneAdminUser();
                tfUser.setUserName(tracfoneUser.getUsername());
                tfUser.setUserId(tracfoneUser.getId());
                tfUser.setEmail(tracfoneUser.getEmail());
                tfUser.setToken(uuidUser);
                tfUser.setDescription(tracfoneUser.getDescription());
            } else {
                throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_INVALID_TRACFONEONE_LOGIN_ERROR_CODE, TracfoneOneConstant.TRACFONE_INVALID_TRACFONEONE_LOGIN_ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_INVALID_TRACFONEONE_LOGIN_ERROR_CODE, TracfoneOneConstant.TRACFONE_INVALID_TRACFONEONE_LOGIN_ERROR_MESSAGE, ex);
        }
        return tfUser;
    }

    @Override
    public TFOneAdminUser validateToken(String token) throws TracfoneOneException {

        TFOneAdminUser tfUser = null;
        Tracfoneoneuser tracfoneUser = this.getUserByToken(token);

        //validate the returned User.
        if (tracfoneUser != null && !tracfoneUser.getUsername().isEmpty()) {
            tfUser = new TFOneAdminUser();
            tfUser.setUserName(tracfoneUser.getUsername());
            tfUser.setUserId(tracfoneUser.getId());
            tfUser.setEmail(tracfoneUser.getEmail());
            tfUser.setToken(tracfoneUser.getToken());
            tfUser.setDescription(tracfoneUser.getDescription());

            return tfUser;
        } else {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_INVALID_TRACFONEONE_LOGIN_ERROR_CODE, TracfoneOneConstant.TRACFONE_INVALID_TRACFONEONE_LOGIN_ERROR_MESSAGE);
        }
    }

    @Override
    public int checkAccessForRequestedResource(int userId, String requestedResource) throws TracfoneOneException {

        int accessCount = 0;
        try {
            accessCount = authorizationEJB.find(userId, requestedResource);

            if (accessCount == 0) {
                throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_UNAUTHORIZED_ERROR_CODE, TracfoneOneConstant.TRACFONE_UNAUTHORIZED_ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_UNAUTHORIZED_ERROR_CODE, TracfoneOneConstant.TRACFONE_UNAUTHORIZED_ERROR_MESSAGE, ex);
        }
        return accessCount;
    }

    @Override
    public List<TFOneDatabaseEnvironment> getDatabaseEnvironments(int userId) throws TracfoneOneException {

        List<TFOneDatabaseEnvironment> tfOneDatabaseEnvironments = new ArrayList<>();
        try {
            List<Dbenvironment> dbEnvironments = dbEnvEJB.findAll();
            if (dbEnvironments != null) {
                for (Dbenvironment dbEnvironment : dbEnvironments) {
                    TFOneDatabaseEnvironment tfOneDatabaseEnvironment = new TFOneDatabaseEnvironment();
                    tfOneDatabaseEnvironment.setId(dbEnvironment.getId());
                    tfOneDatabaseEnvironment.setName(dbEnvironment.getName());
                    tfOneDatabaseEnvironment.setDescription(dbEnvironment.getDescription());
                    tfOneDatabaseEnvironments.add(tfOneDatabaseEnvironment);
                }
            }
            return tfOneDatabaseEnvironments;
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_CODE, TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public List<TFOneAdminRole> getRoles(Integer userId) throws TracfoneOneAuthorizationException, TracfoneOneException {
        List<TFOneAdminRole> tfRoles = new ArrayList<>();

        int rolePriority = this.isAuthorized(userId);

        try {
            List<Roles> roles = rolesEJB.findAllByPriority(rolePriority);
            if (roles != null) {
                for (Roles role : roles) {
                    TFOneAdminRole tfRole = new TFOneAdminRole();
                    tfRole.setRoleId(role.getId());
                    tfRole.setRoleName(role.getName());
                    tfRole.setRolePriority(role.getPriority());
                    tfRoles.add(tfRole);
                }
            }
            return tfRoles;
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_CODE, TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public TFOneAdminRole getRole(Integer userId, Integer adminUserId) throws TracfoneOneException {

        TFOneAdminRole tfRole = new TFOneAdminRole();

        try {
            Tracfoneoneuser userEJB = trafoneUserEJB.find(userId);
            Roles ejbRole = rolesEJB.find(userEJB.getRoleId());
            Roles role = rolesEJB.find(ejbRole.getId());

            if (role != null) {
                tfRole.setRoleId(role.getId());
                tfRole.setRoleName(role.getName());
                tfRole.setRolePriority(role.getPriority());
            }
            return tfRole;
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_CODE, TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_MESSAGE, ex);
        }
    }

    @Override
    public List<TFOneAdminUser> getAllUsers(Integer adminUserId) throws TracfoneOneException {

        List<Tracfoneoneuser> tracfoneUsers = null;
        List<TFOneAdminUser> tfUsers = new ArrayList<>();
        TFOneAdminUser tfUser = null;

        try {
            tracfoneUsers = trafoneUserEJB.findAll();
            for (Tracfoneoneuser tracfoneUser : tracfoneUsers) {
                //create the Response Model TFUser
                tfUser = new TFOneAdminUser();
                tfUser.setUserName(tracfoneUser.getUsername());
                tfUser.setUserId(tracfoneUser.getId());
                tfUser.setEmail(tracfoneUser.getEmail() != null ? tracfoneUser.getEmail() : "");
                tfUser.setDescription(tracfoneUser.getDescription() != null ? tracfoneUser.getDescription() : "");
                tfUsers.add(tfUser);
            }
            tfUsers = tfUsers.stream()
                    .sorted(Comparator.comparing(TFOneAdminUser::getUserName))
                    .collect(Collectors.toList());
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_USERS_RETRIEVAL_ERROR_CODE, TracfoneOneConstant.TRACFONE_USERS_RETRIEVAL_ERROR_MESSAGE);
        }
        return tfUsers;
    }

    @Override
    public List<TFOneAdminUser> getAllUsersWithAction(Integer actionId, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException {

        List<TFOneAdminUser> allUsersFoundByAction = new ArrayList<>();
        List<Integer> userIDs = null;
        List<Tracfoneoneuser> users = null;

        try {
            //1. Retrieves all group IDs that have the action desired.
            List<Integer> groupIDs = groupActionsEJB.findAllEntityByActionId(actionId);

            //2. Retrieve all users that have the groups in step 1.
            if (groupIDs != null && !groupIDs.isEmpty())
                userIDs = userGroupsEJB.findEntitiesByListOfGroupIDs(groupIDs);

            //3. Get all users
            if (userIDs != null && !userIDs.isEmpty())
                users = trafoneUserEJB.findByListOfId(userIDs);

            if (users != null && users.size() > 0) {
                for (Tracfoneoneuser tracfoneoneuser : users) {
                    TFOneAdminUser tfUser = new TFOneAdminUser();
                    tfUser.setUserId(tracfoneoneuser.getId());
                    tfUser.setUserName(tracfoneoneuser.getUsername());
                    tfUser.setEmail(tracfoneoneuser.getEmail());
                    tfUser.setDescription(tracfoneoneuser.getDescription());
                    allUsersFoundByAction.add(tfUser);
                }
            }

        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_GROUP_UPDATE_ERROR_CODE, TracfoneOneConstant.TRACFONE_GROUP_UPDATE_ERROR_MESSAGE, ex);
        }

        return allUsersFoundByAction;
    }

    @Override
    public List<TFOneAdminAction> getAllActions(Integer userId, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException {

        List<Action> tracfoneActions = null;
        List<TFOneAdminAction> tfActions = new ArrayList<>();
        TFOneAdminAction tfAction = null;

        int rolePriority = this.isAuthorized(adminUserId);

        try {
            // Validate if user's role has priority to see all actions.
            tracfoneActions = actionEJB.findAll();
            if (rolePriority == TracfoneOneConstant.TRACFONE_ROLEPRIORITY_ADMIN) {
                // TODO - if priority is less than root, show only actions user has.
            }

            for (Action action : tracfoneActions) {
                //create the Response Model TFUser
                tfAction = new TFOneAdminAction();
                tfAction.setActionId(action.getId().toString());
                tfAction.setActionName(action.getName());
                tfAction.setDescription(action.getDescription());
                tfAction.setRoute(action.getRouteurl());
                tfActions.add(tfAction);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_ACTION_RETRIEVAL_ERROR_CODE, TracfoneOneConstant.TRACFONE_ACTION_RETRIEVAL_ERROR_MESSAGE, ex);
        }
        return tfActions;
    }

    /**
     * @param userId
     * @param adminUserId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    @Override
    public List<TFOneAdminGroup> getAllGroups(Integer userId, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException {
        return getAllGroups(userId, adminUserId, true);
    }

    /**
     * @param userId
     * @param adminUserId
     * @param allowRootRetrieval
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    @Override
    public List<TFOneAdminGroup> getAllGroups(Integer userId, Integer adminUserId, boolean allowRootRetrieval)
            throws TracfoneOneAuthorizationException, TracfoneOneException {

        List<Group> tracfoneGroups = null;
        List<TFOneAdminGroup> tfGroups = new ArrayList<>();
        TFOneAdminGroup tfGroup = null;

        int rolePriority = this.isAuthorized(adminUserId);

        try {

            // Validate if user's role has priority to see all actions.
            if (rolePriority == TracfoneOneConstant.TRACFONE_ROLEPRIORITY_ROOT && allowRootRetrieval) {
                tracfoneGroups = groupEJB.findAll();
            } else {
                List<Integer> userGroups = userGroupsEJB.findByUserid(userId);

                if (userGroups.isEmpty()) {
                    return tfGroups;
                }

                tracfoneGroups = groupEJB.findAllByGroupId(userGroups);
            }

            for (Group group : tracfoneGroups) {
                //create the Response Model TFUser
                tfGroup = new TFOneAdminGroup();
                tfGroup.setGroupId(group.getId().toString());
                tfGroup.setGroupName(group.getGroupname());
                tfGroup.setGroupDescription(group.getDescription());
                tfGroups.add(tfGroup);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_GROUP_RETRIEVAL_ERROR_CODE, TracfoneOneConstant.TRACFONE_GROUP_RETRIEVAL_ERROR_MESSAGE, ex);
        }
        return tfGroups;
    }

    /**
     * @param groupId
     * @param adminUserId
     * @return
     * @throws TracfoneOneException
     */
    @Override
    public TFOneAdminGroup getGroup(Integer groupId, Integer adminUserId) throws TracfoneOneException {
        Group tracfoneGroup = null;
        TFOneAdminGroup tfGroup = null;

        try {
            tracfoneGroup = groupEJB.find(groupId);
            tfGroup = new TFOneAdminGroup();
            tfGroup.setGroupId(tracfoneGroup.getId().toString());
            tfGroup.setGroupName(tracfoneGroup.getGroupname());
            tfGroup.setGroupDescription(tracfoneGroup.getDescription());
            tfGroup.setTfActions(getAllActionsForGroup(groupId));

        } catch (EntityNotFoundException en) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_GROUP_RETRIEVAL_ERROR_CODE, TracfoneOneConstant.TRACFONE_GROUP_RETRIEVAL_ERROR_MESSAGE, en);
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_GROUP_RETRIEVAL_ERROR_CODE, TracfoneOneConstant.TRACFONE_GROUP_RETRIEVAL_ERROR_MESSAGE, ex);
        }
        return tfGroup;
    }

    @Override
    public TFOneAdminProfile getProfile(Integer userId, Integer adminUserId, boolean allowRootRetrieval) throws TracfoneOneAuthorizationException, TracfoneOneException {

        TFOneAdminProfile tfUserProfile = new TFOneAdminProfile();
        TFOneAdminUser tfUser = new TFOneAdminUser();
        TFOneAdminRole tfRole = new TFOneAdminRole();
        Roles userRole = null;
        Tracfoneoneuser tracfoneoneuser = null;

        // Aunthenticate user requesting, do not check for Admin/Root access. User can access profile.
        int adminRolePriority = this.isAuthorized(adminUserId);

        //Find the user by Id
        tracfoneoneuser = getUserById(userId);

        try {
            // Get the role of the user.
            userRole = rolesEJB.find(tracfoneoneuser.getRoleId());
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_CODE, TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_MESSAGE, ex);
        }

        if (adminRolePriority < userRole.getPriority()) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_INVALID_ROLE_ERROR_CODE, TracfoneOneConstant.TRACFONE_INVALID_ROLE_ERROR_MESSAGE);
        }

        tfRole.setRoleId(userRole.getId());
        tfRole.setRoleName(userRole.getName());
        tfRole.setRolePriority(userRole.getPriority());

        // Build user info.
        tfUser.setUserId(tracfoneoneuser.getId());
        tfUser.setUserName(tracfoneoneuser.getUsername());
        tfUser.setToken(tracfoneoneuser.getToken());
        tfUser.setEmail(tracfoneoneuser.getEmail());
        tfUser.setDescription(tracfoneoneuser.getDescription());

        // Get the groups that the user has.
        List<TFOneAdminGroup> userGroups = getAllGroups(tracfoneoneuser.getId(), adminUserId, allowRootRetrieval);

        for (TFOneAdminGroup tfGroup : userGroups) {
            tfGroup.setTfActions(getAllActionsForGroup(new Integer(tfGroup.getGroupId())));
        }

        // Build the profile
        tfUserProfile.setTfUser(tfUser);
        tfUserProfile.setTfGroups(userGroups);
        tfUserProfile.setTfRole(tfRole);

        return tfUserProfile;
    }

    @Override
    public TFOneGeneralResponse deleteUserProfile(Integer userId, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException {

        Tracfoneoneuser tracfoneoneuser = null;
        Roles userRole = null;

        // Authenticate user requesting as Admin/Root.
        int adminRolePriority = this.isAuthorized(adminUserId);
        tracfoneoneuser = getUserById(userId);

        if (tracfoneoneuser.getRoleId() != null) {
            try {
                // Get the role of the user to delete.
                userRole = rolesEJB.find(tracfoneoneuser.getRoleId());
            } catch (Exception ex) {
                throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_CODE, TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_MESSAGE, ex);
            }
            if (adminRolePriority < userRole.getPriority()) {
                // User requesting action has Lower priority than the requested user.
                throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_INVALID_ROLE_ERROR_CODE, TracfoneOneConstant.TRACFONE_INVALID_ROLE_ERROR_MESSAGE);
            }
        }

        try {
            //Delete the user for the associated groups
            List<Usergroups> existingGroups = userGroupsEJB.findEntityByUserid(userId);
            //loop and delete the Group List
            for (Usergroups existingGroup : existingGroups) {
                userGroupsEJB.remove(existingGroup);
            }

            //Finally delete the user who is not eligible to use this stunning & marvelous application
            trafoneUserEJB.remove(tracfoneoneuser);

        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_DELETE_PROFILE_ERROR_CODE, TracfoneOneConstant.TRACFONE_DELETE_PROFILE_ERROR_MESSAGE, ex);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TracfoneOneConstant.TRACFONE_USER_REMOVED_SUCCESS);
    }

    /**
     * @param groupRequestModel
     * @param adminUserId
     * @return
     * @throws TracfoneOneException
     */
    @Override
    public TFOneGeneralResponse createGroup(TracfoneOneGroup groupRequestModel, Integer adminUserId) throws TracfoneOneException {

        if (groupRequestModel == null || groupRequestModel.getGroupName() == null || groupRequestModel.getGroupName().trim().isEmpty()) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_GROUP_CREATE_ERROR_CODE, TracfoneOneConstant.TRACFONE_GROUP_CREATE_ERROR_MESSAGE);
        }

        try {
            Group tracfoneGroup = tracfoneEJBAdminUtil.buildNewGroupEntity(groupRequestModel);
            groupEJB.create(tracfoneGroup);

            List<GroupActions> existingActionIDs = new ArrayList<>();
            List<TracfoneOneAction> actionsInRequest = groupRequestModel.getTfActions();
            List<GroupActions> actionsToAdd = tracfoneEJBAdminUtil.getGroupActionsIdToAdd(tracfoneGroup.getId(), existingActionIDs, actionsInRequest);

            for (GroupActions actionToAdd : actionsToAdd) {
                groupActionsEJB.create(actionToAdd);
            }

        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_GROUP_CREATE_ERROR_CODE, TracfoneOneConstant.TRACFONE_GROUP_CREATE_ERROR_MESSAGE, ex);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TracfoneOneConstant.TRACFONE_GROUP_CREATE_SUCCESS);
    }

    /**
     * @param groupRequestModel
     * @param adminUserId
     * @return
     * @throws TracfoneOneException
     */
    @Override
    public TFOneGeneralResponse updateGroup(TracfoneOneGroup groupRequestModel, Integer adminUserId) throws TracfoneOneException {

        // Aunthenticate user requesting as Admin/Root.
        Group tracfoneGroup = null;

        if (groupRequestModel == null || groupRequestModel.getGroupName() == null || groupRequestModel.getGroupName().trim().isEmpty()) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_GROUP_CREATE_ERROR_CODE, TracfoneOneConstant.TRACFONE_GROUP_CREATE_ERROR_MESSAGE);
        }

        try {
            Integer groupID = groupRequestModel.getGroupId();

            if (groupID == null) {
                throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_GROUP_CREATE_ERROR_CODE, TracfoneOneConstant.TRACFONE_GROUP_CREATE_ERROR_MESSAGE);
            }

            tracfoneGroup = groupEJB.find(groupID);
            tracfoneGroup = tracfoneEJBAdminUtil.buildGroupEntity(groupRequestModel, tracfoneGroup);
            groupEJB.edit(tracfoneGroup);

            List<GroupActions> existingActionIDs = groupActionsEJB.findAllEntityByGroupId(groupID);
            List<TracfoneOneAction> actionsInRequest = groupRequestModel.getTfActions();

            List<GroupActions> actionsToAdd = tracfoneEJBAdminUtil.getGroupActionsIdToAdd(groupID, existingActionIDs, actionsInRequest);
            List<GroupActions> actionsToDelete = tracfoneEJBAdminUtil.getGroupActionsIdToDelete(existingActionIDs, actionsInRequest);

            for (GroupActions actionToAdd : actionsToAdd) {
                groupActionsEJB.edit(actionToAdd);
            }

            for (GroupActions action : actionsToDelete) {
                groupActionsEJB.remove(action);
            }

        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_GROUP_UPDATE_ERROR_CODE, TracfoneOneConstant.TRACFONE_GROUP_UPDATE_ERROR_MESSAGE, ex);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TracfoneOneConstant.TRACFONE_GROUP_UPDATE_SUCCESS);

    }

    /**
     * @param userProfileRequestModel
     * @param adminUserId
     * @return
     * @throws TracfoneOneException
     */
    @Override
    public TFOneGeneralResponse updateUser(TracfoneOneUserProfile userProfileRequestModel, Integer adminUserId) throws TracfoneOneException {

        // TODO - if admin priority is less than new user role priority throw autherization exception.
        Tracfoneoneuser tracfoneUser = null;

        //validate request model
        if (userProfileRequestModel == null || userProfileRequestModel.getTfRole() == null || userProfileRequestModel.getTfRole().getRoleId() == null) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_CODE, TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_MESSAGE);
        }
        if (userProfileRequestModel.getTfUser() == null || userProfileRequestModel.getTfUser().getUserName() == null
                || userProfileRequestModel.getTfUser().getUserName().trim().isEmpty()) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_USER_LOOKUP_ERROR_CODE, TracfoneOneConstant.TRACFONE_USER_LOOKUP_ERROR_MESSAGE);
        }

        try {
            Integer userId = userProfileRequestModel.getTfUser().getUserId();

            if (userId == null) {
                throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_USER_UPDATE_ERROR_CODE, TracfoneOneConstant.TRACFONE_USER_UPDATE_BADID_ERROR_MESSAGE);
            }

            tracfoneUser = trafoneUserEJB.find(userId);

            if (tracfoneUser != null) {

                // User Info.
                tracfoneUser = tracfoneEJBAdminUtil.buildUserEntity(userProfileRequestModel, tracfoneUser);
                trafoneUserEJB.edit(tracfoneUser);

                List<Usergroups> existingGroups = userGroupsEJB.findEntityByUserid(userId);
                List<TracfoneOneGroup> groupsInRequest = userProfileRequestModel.getTfGroups();

                List<Usergroups> userGroupsToAdd = tracfoneEJBAdminUtil.getUserGroupsToAdd(userId, existingGroups, groupsInRequest);
                List<Usergroups> userGroupsToDelete = tracfoneEJBAdminUtil.getUserGroupsToDelete(existingGroups, groupsInRequest);

                // Groups.
                for (Usergroups groupToAdd : userGroupsToAdd) {
                    userGroupsEJB.edit(groupToAdd);
                }

                for (Usergroups groupToDelete : userGroupsToDelete) {
                    userGroupsEJB.remove(groupToDelete);
                }
            } else {
                throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_USER_UPDATE_ERROR_CODE, TracfoneOneConstant.TRACFONE_USER_UPDATE_ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_USER_UPDATE_ERROR_CODE, TracfoneOneConstant.TRACFONE_USER_UPDATE_NOTINDB_ERROR_MESSAGE, ex);
        }

        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TracfoneOneConstant.TRACFONE_USER_UPDATE_SUCCESS);
    }

    /**
     * @param userProfileRequestModel
     * @param adminUserId
     * @return
     * @throws TracfoneOneAuthorizationException
     * @throws TracfoneOneException
     */
    @Override
    public TFOneGeneralResponse createUser(TracfoneOneUserProfile userProfileRequestModel, Integer adminUserId) throws TracfoneOneAuthorizationException, TracfoneOneException {

        //validate request model
        if (userProfileRequestModel == null || userProfileRequestModel.getTfRole() == null || userProfileRequestModel.getTfRole().getRoleId() == null) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_CODE, TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_MESSAGE);
        }
        if (userProfileRequestModel.getTfUser() == null || userProfileRequestModel.getTfUser().getUserName() == null || userProfileRequestModel.getTfUser().getUserName().trim().isEmpty()) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_USER_LOOKUP_ERROR_CODE, TracfoneOneConstant.TRACFONE_USER_LOOKUP_ERROR_MESSAGE);
        }

        // TODO - if admin priority is less than new user role priority throw autherization exception.
        Tracfoneoneuser tracfoneUser = new Tracfoneoneuser();

        try {
            // User Info.
            tracfoneUser = tracfoneEJBAdminUtil.buildUserEntity(userProfileRequestModel, tracfoneUser);
            trafoneUserEJB.create(tracfoneUser);

            List<Usergroups> existingGroups = new ArrayList<>();
            List<TracfoneOneGroup> groupsInRequest = userProfileRequestModel.getTfGroups();

            List<Usergroups> userGroupsToAdd = tracfoneEJBAdminUtil.getUserGroupsToAdd(tracfoneUser.getId(), existingGroups, groupsInRequest);

            for (Usergroups groupToAdd : userGroupsToAdd) {
                userGroupsEJB.edit(groupToAdd);
            }
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_USER_CREATE_ERROR_CODE, TracfoneOneConstant.TRACFONE_USER_CREATE_ERROR_MESSAGE, ex);
        }
        return new TFOneGeneralResponse(TFOneGeneralResponse.SUCCESS, TracfoneOneConstant.TRACFONE_USER_CREATE_SUCCESS);
    }

    @Override
    public String getMonitorReport(String reportName, String reportSql) throws TracfoneOneException {
        TracfoneOneReport tfOneReport = new TracfoneOneReport();
        tfOneReport.setReportName(reportName);
        CRtlTFOneReport cRtlTFOneReport = new CRtlTFOneReport();
        Gson gson = new Gson();
        try {
            cRtlTFOneReport = this.cRtlReportFacadeLocal.findLastRowInserted(reportName);
            if (null != cRtlTFOneReport) {
                tfOneReport.setJsonResponse(cRtlTFOneReport.getJsonResponse());
                tfOneReport.setCreateDate(cRtlTFOneReport.getCreateddate());
            }
        } catch (Exception ex) {
            if (TracfoneOneConstantReport.TRACFONE_REPORTNAME_TT_MONITOR.equalsIgnoreCase(reportName)) {
                throw new TracfoneOneException(TRACFONE_REPORT_TT_MONITOR_ERROR_CODE, TRACFONE_REPORT_TT_MONITOR_ERROR_MESSAGE, ex);
            } else if (TracfoneOneConstantReport.TRACFONE_REPORTNAME_PCRF_MONITOR.equalsIgnoreCase(reportName)) {
                throw new TracfoneOneException(TRACFONE_REPORT_PCRF_MONITOR_ERROR_CODE, TRACFONE_REPORT_PCRF_MONITOR_ERROR_MESSAGE, ex);
            }
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_REPORT_MONITOR_ERROR_CODE, TracfoneOneConstant.TRACFONE_REPORT_MONITOR_ERROR_MESSAGE, ex);
        }
        return gson.toJson(tfOneReport);
    }

    @Override
    public String getAllFailures(String reportName, boolean flag) throws TracfoneOneException {
        TracfoneOneReport tfOneReport = new TracfoneOneReport();
        tfOneReport.setReportName(reportName);
        CRtlTFOneReport cRtlTFOneReport = new CRtlTFOneReport();
        Gson gson = new Gson();
        try {
            cRtlTFOneReport = this.cRtlReportFacadeLocal.findLastRowInserted(reportName);
            if (null != cRtlTFOneReport) {
                tfOneReport.setJsonResponse(cRtlTFOneReport.getJsonResponse());
                tfOneReport.setCreateDate(cRtlTFOneReport.getCreateddate());
            }

        } catch (Exception ex) {
            if (TracfoneOneConstantReport.TRACFONE_REPORTNAME_ALL_TT_FAILURES.equalsIgnoreCase(reportName)) {
                throw new TracfoneOneException(TRACFONE_REPORT_ALL_TT_FAILURES_ERROR_CODE, TRACFONE_REPORT_ALL_TT_FAILURES_ERROR_MESSAGE, ex);
            } else if (TracfoneOneConstantReport.TRACFONE_REPORTNAME_ALL_PCRF_FAILURES.equalsIgnoreCase(reportName)) {
                throw new TracfoneOneException(TRACFONE_REPORT_ALL_PCRF_FAILURES_ERROR_CODE, TRACFONE_REPORT_ALL_PCRF_FAILURES_ERROR_MESSAGE, ex);
            }
            throw new TracfoneOneException(TRACFONE_REPORT_ALL_IG_FAILURES_ERROR_CODE, TRACFONE_REPORT_ALL_IG_FAILURES_ERROR_MESSAGE, ex);
        }
        return gson.toJson(tfOneReport);
    }

    @Override
    public String getMonitorGraphReport(String reportName, String reportSql) throws TracfoneOneException {
        TracfoneOneReport tfOneReport = new TracfoneOneReport();
        tfOneReport.setReportName(reportName);
        CRtlTFOneReport cRtlTFOneReport = new CRtlTFOneReport();
        Gson gson = new Gson();
        try {
            cRtlTFOneReport = this.cRtlReportFacadeLocal.findLastRowInserted(reportName);
            if (null != cRtlTFOneReport) {
                tfOneReport.setJsonResponse(cRtlTFOneReport.getJsonResponse());
                tfOneReport.setCreateDate(cRtlTFOneReport.getCreateddate());
            }
        } catch (Exception ex) {
            if (TracfoneOneConstantReport.TRACFONE_REPORTNAME_TT_MONITOR_GRAPH.equalsIgnoreCase(reportName)) {
                throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_REPORT_TT_MONITOR_GRAPH_ERROR_CODE, TracfoneOneConstant.TRACFONE_REPORT_TT_MONITOR_GRAPH_ERROR_MESSAGE, ex);
            } else if (TracfoneOneConstantReport.TRACFONE_REPORTNAME_PCRF_MONITOR_GRAPH.equalsIgnoreCase(reportName)) {
                throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_REPORT_PCRF_MONITOR_GRAPH_ERROR_CODE, TracfoneOneConstant.TRACFONE_REPORT_PCRF_MONITOR_GRAPH_ERROR_MESSAGE, ex);
            }
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_REPORT_MONITOR_GRAPH_ERROR_CODE, TracfoneOneConstant.TRACFONE_REPORT_MONITOR_GRAPH_ERROR_MESSAGE, ex);
        }
        return gson.toJson(tfOneReport);
    }

    /**
     * Retrieve user by token.
     *
     * @param token
     * @return
     * @throws TracfoneOneException
     */
    private Tracfoneoneuser getUserByToken(String token) throws TracfoneOneException {
        Tracfoneoneuser tracfoneUser = null;
        try {
            tracfoneUser = trafoneUserEJB.validateToken(token);
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_INVALID_TOKEN_ERROR_CODE, TracfoneOneConstant.TRACFONE_INVALID_TOKEN_ERROR_MESSAGE, ex);
        }
        return tracfoneUser;
    }

    /**
     * Retrieve user by token.
     *
     * @param userId
     * @return
     * @throws TracfoneOneException
     */
    private Tracfoneoneuser getUserById(Integer userId) throws TracfoneOneException {
        Tracfoneoneuser tracfoneUser = null;
        try {
            tracfoneUser = trafoneUserEJB.find(userId);
        } catch (Exception ex) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_INVALID_TRACFONEONE_LOGIN_ERROR_CODE, TracfoneOneConstant.TRACFONE_INVALID_TRACFONEONE_LOGIN_ERROR_MESSAGE, ex);
        }
        return tracfoneUser;
    }

    /**
     * Collect all actions that belong to the group id.
     *
     * @param groupId
     * @return
     * @throws TracfoneOneException
     */
    private List<TFOneAdminAction> getAllActionsForGroup(Integer groupId) {
        List<TFOneAdminAction> tfOneActions = new ArrayList<>();

        // Get all action Ids that belong to the group id.
        List<Integer> ejbGroupActionsId = groupActionsEJB.findAllByGroupId(groupId);

        if (ejbGroupActionsId == null || ejbGroupActionsId.isEmpty()) {
            return tfOneActions;
        }

        List<Action> ejbActions = actionEJB.findAllActionsByID(ejbGroupActionsId);

        for (Action ejbAction : ejbActions) {
            TFOneAdminAction tfOneAction = new TFOneAdminAction();
            tfOneAction.setActionId(ejbAction.getId().toString());
            tfOneAction.setActionName(ejbAction.getName());
            tfOneAction.setDescription(ejbAction.getDescription());
            tfOneAction.setRoute(ejbAction.getRouteurl());
            tfOneActions.add(tfOneAction);
        }
        return tfOneActions;
    }

    private int isAuthorized(Integer userId) throws TracfoneOneException {
        Roles ejbRole = null;
        int userEjbPriority = -1;

        try {
            Tracfoneoneuser userEJB = trafoneUserEJB.find(userId);
            ejbRole = rolesEJB.find(userEJB.getRoleId());

        } catch (Exception e) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_CODE, TracfoneOneConstant.TRACFONE_ROLES_RETRIEVAL_ERROR_MESSAGE, e);
        }

        userEjbPriority = ejbRole.getPriority();
        return userEjbPriority;
    }

    @Override
    public List<TFOneAuditHistory> getAuditHistoryForUserId(Integer userId) throws TracfoneOneException {
        List<TFOneAuditHistory> tfAudits = new ArrayList<>();
        try {
            List<Audit> auditHistory = auditEJB.findAllAuditsByUserId(userId);
            for (Audit audit : auditHistory) {
                TFOneAuditHistory tfAudit = new TFOneAuditHistory();
                tfAudit.setAction(audit.getAction());
                tfAudit.setCarrierId(audit.getCarrierId());
                tfAudit.setCreatedDate(audit.getCreateDate());
                tfAudit.setDetails(audit.getDetails());
                tfAudit.setUserId(audit.getUserId());
                tfAudits.add(tfAudit);
            }
        } catch (Exception e) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_AUDIT_HISTORY_RETRIEVAL_ERROR_CODE, TracfoneOneConstant.TRACFONE_AUDIT_HISTORY_RETRIEVAL_ERROR_MESSAGE, e);
        }
        return tfAudits;
    }

    @Override
    public void purgeUserAudit() throws TracfoneOneException {
        try {
            auditEJB.deleteAudit(TracfoneOneConstant.NUMBER_OF_DAYS_BEFORE_AUDIT_TO_PURGE);
        } catch (Exception e) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_PURGE_AUDIT_ERROR_CODE, TracfoneOneConstant.TRACFONE_PURGE_AUDIT_ERROR_MESSAGE, e);
        }
    }

    @Override
    public void purgeTFOneReport() throws TracfoneOneException {
        try {
            reportEJB.deletetfOneReport(TracfoneOneConstant.NUMBER_OF_DAYS_BEFORE_REPORT_TO_PURGE);
        } catch (Exception e) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_PURGE_REPORT_ERROR_CODE, TracfoneOneConstant.TRACFONE_PURGE_REPORT_ERROR_MESSAGE, e);
        }
    }

    @Override
    public List<TFTransactionArchive> deactiveCOPTransactionArchive() throws TracfoneOneException {
        try {
            return tfTransactionArchiveFacadeLocalEJB.findAllEligibleTFTransactionArchives(TracfoneOneConstant.NUMBER_OF_DAYS_TO_DEACTIVATE);
        } catch (Exception e) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_DEACTIVATE_JOB_REPORT_ERROR_CODE, TracfoneOneConstant.TRACFONE_DEACTIVATE_JOB_ERROR_MESSAGE, e);
        }
    }

    @Override
    public void purgeUserHistory() throws TracfoneOneException {
        try {
            userTaskEJB.deleteUserTask(TracfoneOneConstant.NUMBER_OF_DAYS_BEFORE_USER_TASK_TO_PURGE);
        } catch (Exception e) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_PURGE_USER_HISTORY_ERROR_CODE, TracfoneOneConstant.TRACFONE_PURGE_USER_HISTORY_ERROR_MESSAGE, e);
        }
    }

    @Override
    public void purgeUserTasks() throws TracfoneOneException {
        try {
            userHistoryEJB.deleteUserHistory(TracfoneOneConstant.NUMBER_OF_DAYS_BEFORE_USER_HISTORY_TO_PURGE);
        } catch (Exception e) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_PURGE_USER_TASK_ERROR_MESSAGE, TracfoneOneConstant.TRACFONE_PURGE_USER_TASK_ERROR_CODE, e);
        }
    }

    @Override
    public void duplicateUserNameCheck(String username) throws TracfoneOneException {
        // Duplicate User Check
        Tracfoneoneuser duplicate = null;
        try {
            duplicate = trafoneUserEJB.findTracfoneUserByName(username);
        } catch (Exception e) {
            logger.info("This is a new user " + username);
        }
        if (duplicate != null) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_DUPLICATE_USER_ERROR_CODE, TracfoneOneConstant.TRACFONE_DUPLICATE_USER_ERROR_MESSAGE);
        }
    }

    @Override
    public void duplicateSignatureCheck(String description) throws TracfoneOneException {
        Tracfoneoneuser duplicate = null;
        try {
            duplicate = trafoneUserEJB.findTracfoneUserByDescription(description);
        } catch (Exception e) {
            logger.info("This is a new signature " + description);
        }
        if (duplicate != null) {
            throw new TracfoneOneException(TracfoneOneConstant.TRACFONE_DUPLICATE_SIGNATURE_ERROR_CODE, TracfoneOneConstant.TRACFONE_DUPLICATE_SIGNATURE_ERROR_MESSAGE);
        }
    }

}
