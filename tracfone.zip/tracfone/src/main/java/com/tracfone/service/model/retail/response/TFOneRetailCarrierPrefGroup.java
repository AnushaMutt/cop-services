package com.tracfone.service.model.retail.response;

import java.util.ArrayList;
import java.util.List;

public class TFOneRetailCarrierPrefGroup {
    private String objId;
    private String secUserId;
    private String status;
    private String description;
    private String brand;
    private String insertDate;
    private String updateDate;
    private List<TFOneRetailCarrierPrefDetail> carrierPrefDetails;

    public TFOneRetailCarrierPrefGroup() {
        carrierPrefDetails = new ArrayList<>();
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getSecUserId() {
        return secUserId;
    }

    public void setSecUserId(String secUserId) {
        this.secUserId = secUserId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(String insertDate) {
        this.insertDate = insertDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public List<TFOneRetailCarrierPrefDetail> getCarrierPrefDetails() {
        return carrierPrefDetails;
    }

    public void setCarrierPrefDetails(List<TFOneRetailCarrierPrefDetail> carrierPrefDetails) {
        this.carrierPrefDetails = carrierPrefDetails;
    }

    @Override
    public String toString() {
        return "TFOneRetailCarrierPrefGroup{" +
                "objId='" + objId + '\'' +
                ", secUserId='" + secUserId + '\'' +
                ", status='" + status + '\'' +
                ", description='" + description + '\'' +
                ", brand='" + brand + '\'' +
                ", insertDate=" + insertDate +
                ", updateDate=" + updateDate +
                ", carrierPrefDetails=" + carrierPrefDetails +
                '}';
    }
}
