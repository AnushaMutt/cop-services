package com.tracfone.service.model.retail.response;

public class TFOneTraitLogicRule {
    private String objId;
    private String ruleName;
    private String innerRadius;
    private String innerPop;
    private String innerGeo;
    private String outerRadius;
    private String outerPop;
    private String outerGeo;
    private String useOuterPop;
    private String rule2Logic;
    private String rule2User;
    private String prefAllCarr;

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public String getInnerRadius() {
        return innerRadius;
    }

    public void setInnerRadius(String innerRadius) {
        this.innerRadius = innerRadius;
    }

    public String getInnerPop() {
        return innerPop;
    }

    public void setInnerPop(String innerPop) {
        this.innerPop = innerPop;
    }

    public String getInnerGeo() {
        return innerGeo;
    }

    public void setInnerGeo(String innerGeo) {
        this.innerGeo = innerGeo;
    }

    public String getOuterRadius() {
        return outerRadius;
    }

    public void setOuterRadius(String outerRadius) {
        this.outerRadius = outerRadius;
    }

    public String getOuterPop() {
        return outerPop;
    }

    public void setOuterPop(String outerPop) {
        this.outerPop = outerPop;
    }

    public String getOuterGeo() {
        return outerGeo;
    }

    public void setOuterGeo(String outerGeo) {
        this.outerGeo = outerGeo;
    }

    public String getUseOuterPop() {
        return useOuterPop;
    }

    public void setUseOuterPop(String useOuterPop) {
        this.useOuterPop = useOuterPop;
    }

    public String getRule2Logic() {
        return rule2Logic;
    }

    public void setRule2Logic(String rule2Logic) {
        this.rule2Logic = rule2Logic;
    }

    public String getRule2User() {
        return rule2User;
    }

    public void setRule2User(String rule2User) {
        this.rule2User = rule2User;
    }

    public String getPrefAllCarr() {
        return prefAllCarr;
    }

    public void setPrefAllCarr(String prefAllCarr) {
        this.prefAllCarr = prefAllCarr;
    }

    @Override
    public String toString() {
        return "TFOneTraitLogicRule{" +
                "objId='" + objId + '\'' +
                ", ruleName='" + ruleName + '\'' +
                ", innerRadius='" + innerRadius + '\'' +
                ", innerPop='" + innerPop + '\'' +
                ", innerGeo='" + innerGeo + '\'' +
                ", outerRadius='" + outerRadius + '\'' +
                ", outerPop='" + outerPop + '\'' +
                ", outerGeo='" + outerGeo + '\'' +
                ", useOuterPop='" + useOuterPop + '\'' +
                ", rule2Logic='" + rule2Logic + '\'' +
                ", rule2User='" + rule2User + '\'' +
                ", prefAllCarr='" + prefAllCarr + '\'' +
                '}';
    }
}
