package com.tracfone.service.model.response;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author druiz
 */
public class TFOneAdminActionItem {
    private List<TFOneActionItemBucket> buckets;
    private boolean hasBuckets;
    private String env;
    private String callTransActionType;
    private String actionItemId;
    private String carrierId;
    private String orderType;
    private String min;
    private String esn;
    private String esnPartClassModel;
    private String esnHex;
    private String oldEsn;
    private String oldEsnHex;
    private String pin;
    private String phoneManf;
    private String endUser;
    private String accountNum;
    private String marketCode;
    private String ratePlan;
    private String ldProvider;
    private String sequenceNum;
    private String dealerCode;
    private String transmissionMethod;
    private String faxNum;
    private String onlineNum;
    private String email;
    private String networkLogin;
    private String networkPassword;
    private String systemLogin;
    private String systemPassword;
    private String template;
    private String exeName;
    private String comPort;
    private String status;
    private String statusMessage;
    private String faxBatchSize;
    private String faxBatchQtime;
    private String expidite;
    private String transProfKey;
    private String qTransaction;
    private String onlineNum2;
    private String faxNum2;
    private String creationDate;
    private String updateDate;
    private String igDbSecsToComp;
    private String blackoutWait;
    private String tuxItiServer;
    private String transactionId;
    private String technologyFlag;
    private String voiceMail;
    private String voiceMailPackage;
    private String callerId;
    private String carrierAccountId;
    private String tmoNextGenFlag;
    private String callerIdPackage;
    private String callWaiting;
    private String callWaitingPackage;
    private String rtpServer;
    private String digitalFeatureCode;
    private String stateField;
    private String zipCode;
    private String msid;
    private String newMsidFlag;
    private String sms;
    private String smsPackage;
    private String iccid;
    private String oldMin;
    private String digitalFeature;
    private String otaType;
    private String rateCenterNo;
    private String applicationSystem;
    private String subscriberUpdate;
    private String downloadDate;
    private String prlNumber;
    private String amount;
    private String balance;
    private String language;
    private String expDate;
    private String xMpn;
    private String xMpnCode;
    private String xPoolName;
    private String imsi;
    private String newImsiFlag;
    private String xMake;
    private String xModel;
    private String xMode;
    private String carrierInitialTransTime;
    private String carrierEndTransTime;
    private String igCarrSecsToComp;
    private String cfExtensionCount;
    private String dataSaver;
    private String dataSaverCode;
    private String xCampaignName;
    private String carrierFeatureObjid;
    private String cfProfileId;
    private String rpExtObjid;
    private String bucketId;
    private String rechargeDate;
    private String bucketBalance;
    private String bucketValue;
    private String expirationDate;
    private String direction;
    private String benefitType;
    private String bucketType;
    private String bucketUsage;
    private String bucketAction;
    private String firstName;
    private String middleInitial;
    private String lastName;
    private String suffix;
    private String prefix;
    private String ssnLast4;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String zipCode1;
    private String country;
    private String ospAccount;
    private String currAddrHouseNumber;
    private String currAddrDirection;
    private String currAddrStreetName;
    private String currAddrStreetType;
    private String currAddrUnit;
    private String servicePlanId;
    private String igTransInProgress;
    private String igFailLogs;
    private String eSimFlag;
    private Map<String, String> additionalDbColumns;

    public TFOneAdminActionItem(){
        buckets = new ArrayList<>();
    }

    public String getCarrierAccountId() {
        return carrierAccountId;
    }

    public void setCarrierAccountId(String carrierAccountId) {
        this.carrierAccountId = carrierAccountId;
    }

    public String getTmoNextGenFlag() {
        return tmoNextGenFlag;
    }

    public void setTmoNextGenFlag(String tmoNextGenFlag) {
        this.tmoNextGenFlag = tmoNextGenFlag;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }
    
    public List<TFOneActionItemBucket> getBuckets() {
        return buckets;
    }

    public void setBuckets(List<TFOneActionItemBucket> buckets) {
        this.buckets = buckets;
    }

    public String getCallTransActionType() {
        return callTransActionType;
    }

    public void setCallTransActionType(String callTransActionType) {
        this.callTransActionType = callTransActionType;
    }

    public String getActionItemId() {
        return actionItemId;
    }

    public void setActionItemId(String actionItemId) {
        this.actionItemId = actionItemId;
    }

    public String getCarrierId() {
        return carrierId;
    }

    public void setCarrierId(String carrierId) {
        this.carrierId = carrierId;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getEsn() {
        return esn;
    }

    public void setEsn(String esn) {
        this.esn = esn;
    }

    public String getEsnPartClassModel() {
        return esnPartClassModel;
    }

    public void setEsnPartClassModel(String esnPartClassModel) {
        this.esnPartClassModel = esnPartClassModel;
    }

    public String getEsnHex() {
        return esnHex;
    }

    public void setEsnHex(String esnHex) {
        this.esnHex = esnHex;
    }

    public String getOldEsn() {
        return oldEsn;
    }

    public void setOldEsn(String oldEsn) {
        this.oldEsn = oldEsn;
    }

    public String getOldEsnHex() {
        return oldEsnHex;
    }

    public void setOldEsnHex(String oldEsnHex) {
        this.oldEsnHex = oldEsnHex;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getPhoneManf() {
        return phoneManf;
    }

    public void setPhoneManf(String phoneManf) {
        this.phoneManf = phoneManf;
    }

    public String getEndUser() {
        return endUser;
    }

    public void setEndUser(String endUser) {
        this.endUser = endUser;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getMarketCode() {
        return marketCode;
    }

    public void setMarketCode(String marketCode) {
        this.marketCode = marketCode;
    }

    public String getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(String ratePlan) {
        this.ratePlan = ratePlan;
    }

    public String getLdProvider() {
        return ldProvider;
    }

    public void setLdProvider(String ldProvider) {
        this.ldProvider = ldProvider;
    }

    public String getSequenceNum() {
        return sequenceNum;
    }

    public void setSequenceNum(String sequenceNum) {
        this.sequenceNum = sequenceNum;
    }

    public String getDealerCode() {
        return dealerCode;
    }

    public void setDealerCode(String dealerCode) {
        this.dealerCode = dealerCode;
    }

    public String getTransmissionMethod() {
        return transmissionMethod;
    }

    public void setTransmissionMethod(String transmissionMethod) {
        this.transmissionMethod = transmissionMethod;
    }

    public String getFaxNum() {
        return faxNum;
    }

    public void setFaxNum(String faxNum) {
        this.faxNum = faxNum;
    }

    public String getOnlineNum() {
        return onlineNum;
    }

    public void setOnlineNum(String onlineNum) {
        this.onlineNum = onlineNum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNetworkLogin() {
        return networkLogin;
    }

    public void setNetworkLogin(String networkLogin) {
        this.networkLogin = networkLogin;
    }

    public String getNetworkPassword() {
        return networkPassword;
    }

    public void setNetworkPassword(String networkPassword) {
        this.networkPassword = networkPassword;
    }

    public String getSystemLogin() {
        return systemLogin;
    }

    public void setSystemLogin(String systemLogin) {
        this.systemLogin = systemLogin;
    }

    public String getSystemPassword() {
        return systemPassword;
    }

    public void setSystemPassword(String systemPassword) {
        this.systemPassword = systemPassword;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getExeName() {
        return exeName;
    }

    public void setExeName(String exeName) {
        this.exeName = exeName;
    }

    public String getComPort() {
        return comPort;
    }

    public void setComPort(String comPort) {
        this.comPort = comPort;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getFaxBatchSize() {
        return faxBatchSize;
    }

    public void setFaxBatchSize(String faxBatchSize) {
        this.faxBatchSize = faxBatchSize;
    }

    public String getFaxBatchQtime() {
        return faxBatchQtime;
    }

    public void setFaxBatchQtime(String faxBatchQtime) {
        this.faxBatchQtime = faxBatchQtime;
    }

    public String getExpidite() {
        return expidite;
    }

    public void setExpidite(String expidite) {
        this.expidite = expidite;
    }

    public String getTransProfKey() {
        return transProfKey;
    }

    public void setTransProfKey(String transProfKey) {
        this.transProfKey = transProfKey;
    }

    public String getqTransaction() {
        return qTransaction;
    }

    public void setqTransaction(String qTransaction) {
        this.qTransaction = qTransaction;
    }

    public String getOnlineNum2() {
        return onlineNum2;
    }

    public void setOnlineNum2(String onlineNum2) {
        this.onlineNum2 = onlineNum2;
    }

    public String getFaxNum2() {
        return faxNum2;
    }

    public void setFaxNum2(String faxNum2) {
        this.faxNum2 = faxNum2;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getIgDbSecsToComp() {
        return igDbSecsToComp;
    }

    public void setIgDbSecsToComp(String igDbSecsToComp) {
        this.igDbSecsToComp = igDbSecsToComp;
    }

    public String getBlackoutWait() {
        return blackoutWait;
    }

    public void setBlackoutWait(String blackoutWait) {
        this.blackoutWait = blackoutWait;
    }

    public String getTuxItiServer() {
        return tuxItiServer;
    }

    public void setTuxItiServer(String tuxItiServer) {
        this.tuxItiServer = tuxItiServer;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getTechnologyFlag() {
        return technologyFlag;
    }

    public void setTechnologyFlag(String technologyFlag) {
        this.technologyFlag = technologyFlag;
    }

    public String getVoiceMail() {
        return voiceMail;
    }

    public void setVoiceMail(String voiceMail) {
        this.voiceMail = voiceMail;
    }

    public String getVoiceMailPackage() {
        return voiceMailPackage;
    }

    public void setVoiceMailPackage(String voiceMailPackage) {
        this.voiceMailPackage = voiceMailPackage;
    }

    public String getCallerId() {
        return callerId;
    }

    public void setCallerId(String callerId) {
        this.callerId = callerId;
    }

    public String getCallerIdPackage() {
        return callerIdPackage;
    }

    public void setCallerIdPackage(String callerIdPackage) {
        this.callerIdPackage = callerIdPackage;
    }

    public String getCallWaiting() {
        return callWaiting;
    }

    public void setCallWaiting(String callWaiting) {
        this.callWaiting = callWaiting;
    }

    public String getCallWaitingPackage() {
        return callWaitingPackage;
    }

    public void setCallWaitingPackage(String callWaitingPackage) {
        this.callWaitingPackage = callWaitingPackage;
    }

    public String getRtpServer() {
        return rtpServer;
    }

    public void setRtpServer(String rtpServer) {
        this.rtpServer = rtpServer;
    }

    public String getDigitalFeatureCode() {
        return digitalFeatureCode;
    }

    public void setDigitalFeatureCode(String digitalFeatureCode) {
        this.digitalFeatureCode = digitalFeatureCode;
    }

    public String getStateField() {
        return stateField;
    }

    public void setStateField(String stateField) {
        this.stateField = stateField;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getMsid() {
        return msid;
    }

    public void setMsid(String msid) {
        this.msid = msid;
    }

    public String getNewMsidFlag() {
        return newMsidFlag;
    }

    public void setNewMsidFlag(String newMsidFlag) {
        this.newMsidFlag = newMsidFlag;
    }

    public String getSms() {
        return sms;
    }

    public void setSms(String sms) {
        this.sms = sms;
    }

    public String getSmsPackage() {
        return smsPackage;
    }

    public void setSmsPackage(String smsPackage) {
        this.smsPackage = smsPackage;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getOldMin() {
        return oldMin;
    }

    public void setOldMin(String oldMin) {
        this.oldMin = oldMin;
    }

    public String getDigitalFeature() {
        return digitalFeature;
    }

    public void setDigitalFeature(String digitalFeature) {
        this.digitalFeature = digitalFeature;
    }

    public String getOtaType() {
        return otaType;
    }

    public void setOtaType(String otaType) {
        this.otaType = otaType;
    }

    public String getRateCenterNo() {
        return rateCenterNo;
    }

    public void setRateCenterNo(String rateCenterNo) {
        this.rateCenterNo = rateCenterNo;
    }

    public String getApplicationSystem() {
        return applicationSystem;
    }

    public void setApplicationSystem(String applicationSystem) {
        this.applicationSystem = applicationSystem;
    }

    public String getSubscriberUpdate() {
        return subscriberUpdate;
    }

    public void setSubscriberUpdate(String subscriberUpdate) {
        this.subscriberUpdate = subscriberUpdate;
    }

    public String getDownloadDate() {
        return downloadDate;
    }

    public void setDownloadDate(String downloadDate) {
        this.downloadDate = downloadDate;
    }

    public String getPrlNumber() {
        return prlNumber;
    }

    public void setPrlNumber(String prlNumber) {
        this.prlNumber = prlNumber;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getExpDate() {
        return expDate;
    }

    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }

    public String getxMpn() {
        return xMpn;
    }

    public void setxMpn(String xMpn) {
        this.xMpn = xMpn;
    }

    public String getxMpnCode() {
        return xMpnCode;
    }

    public void setxMpnCode(String xMpnCode) {
        this.xMpnCode = xMpnCode;
    }

    public String getxPoolName() {
        return xPoolName;
    }

    public void setxPoolName(String xPoolName) {
        this.xPoolName = xPoolName;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getNewImsiFlag() {
        return newImsiFlag;
    }

    public void setNewImsiFlag(String newImsiFlag) {
        this.newImsiFlag = newImsiFlag;
    }

    public String getxMake() {
        return xMake;
    }

    public void setxMake(String xMake) {
        this.xMake = xMake;
    }

    public String getxModel() {
        return xModel;
    }

    public void setxModel(String xModel) {
        this.xModel = xModel;
    }

    public String getxMode() {
        return xMode;
    }

    public void setxMode(String xMode) {
        this.xMode = xMode;
    }

    public String getCarrierInitialTransTime() {
        return carrierInitialTransTime;
    }

    public void setCarrierInitialTransTime(String carrierInitialTransTime) {
        this.carrierInitialTransTime = carrierInitialTransTime;
    }

    public String getCarrierEndTransTime() {
        return carrierEndTransTime;
    }

    public void setCarrierEndTransTime(String carrierEndTransTime) {
        this.carrierEndTransTime = carrierEndTransTime;
    }

    public String getIgCarrSecsToComp() {
        return igCarrSecsToComp;
    }

    public void setIgCarrSecsToComp(String igCarrSecsToComp) {
        this.igCarrSecsToComp = igCarrSecsToComp;
    }

    public String getCfExtensionCount() {
        return cfExtensionCount;
    }

    public void setCfExtensionCount(String cfExtensionCount) {
        this.cfExtensionCount = cfExtensionCount;
    }

    public String getDataSaver() {
        return dataSaver;
    }

    public void setDataSaver(String dataSaver) {
        this.dataSaver = dataSaver;
    }

    public String getDataSaverCode() {
        return dataSaverCode;
    }

    public void setDataSaverCode(String dataSaverCode) {
        this.dataSaverCode = dataSaverCode;
    }

    public String getxCampaignName() {
        return xCampaignName;
    }

    public void setxCampaignName(String xCampaignName) {
        this.xCampaignName = xCampaignName;
    }

    public String getCarrierFeatureObjid() {
        return carrierFeatureObjid;
    }

    public void setCarrierFeatureObjid(String carrierFeatureObjid) {
        this.carrierFeatureObjid = carrierFeatureObjid;
    }

    public String getCfProfileId() {
        return cfProfileId;
    }

    public void setCfProfileId(String cfProfileId) {
        this.cfProfileId = cfProfileId;
    }

    public String getRpExtObjid() {
        return rpExtObjid;
    }

    public void setRpExtObjid(String rpExtObjid) {
        this.rpExtObjid = rpExtObjid;
    }

    public String getBucketId() {
        return bucketId;
    }

    public void setBucketId(String bucketId) {
        this.bucketId = bucketId;
    }

    public String getRechargeDate() {
        return rechargeDate;
    }

    public void setRechargeDate(String rechargeDate) {
        this.rechargeDate = rechargeDate;
    }

    public String getBucketBalance() {
        return bucketBalance;
    }

    public void setBucketBalance(String bucketBalance) {
        this.bucketBalance = bucketBalance;
    }

    public String getBucketValue() {
        return bucketValue;
    }

    public void setBucketValue(String bucketValue) {
        this.bucketValue = bucketValue;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getBenefitType() {
        return benefitType;
    }

    public void setBenefitType(String benefitType) {
        this.benefitType = benefitType;
    }

    public String getBucketType() {
        return bucketType;
    }

    public void setBucketType(String bucketType) {
        this.bucketType = bucketType;
    }

    public String getBucketUsage() {
        return bucketUsage;
    }

    public void setBucketUsage(String bucketUsage) {
        this.bucketUsage = bucketUsage;
    }

    public String getBucketAction() {
        return bucketAction;
    }

    public void setBucketAction(String bucketAction) {
        this.bucketAction = bucketAction;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleInitial() {
        return middleInitial;
    }

    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getSsnLast4() {
        return ssnLast4;
    }

    public void setSsnLast4(String ssnLast4) {
        this.ssnLast4 = ssnLast4;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode1() {
        return zipCode1;
    }

    public void setZipCode1(String zipCode1) {
        this.zipCode1 = zipCode1;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getOspAccount() {
        return ospAccount;
    }

    public void setOspAccount(String ospAccount) {
        this.ospAccount = ospAccount;
    }

    public String getCurrAddrHouseNumber() {
        return currAddrHouseNumber;
    }

    public void setCurrAddrHouseNumber(String currAddrHouseNumber) {
        this.currAddrHouseNumber = currAddrHouseNumber;
    }

    public String getCurrAddrDirection() {
        return currAddrDirection;
    }

    public void setCurrAddrDirection(String currAddrDirection) {
        this.currAddrDirection = currAddrDirection;
    }

    public String getCurrAddrStreetName() {
        return currAddrStreetName;
    }

    public void setCurrAddrStreetName(String currAddrStreetName) {
        this.currAddrStreetName = currAddrStreetName;
    }

    public String getCurrAddrStreetType() {
        return currAddrStreetType;
    }

    public void setCurrAddrStreetType(String currAddrStreetType) {
        this.currAddrStreetType = currAddrStreetType;
    }

    public String getCurrAddrUnit() {
        return currAddrUnit;
    }

    public void setCurrAddrUnit(String currAddrUnit) {
        this.currAddrUnit = currAddrUnit;
    }
    
     public boolean isHasBuckets() {
        return hasBuckets;
    }

    public void setHasBuckets(boolean hasBuckets) {
        this.hasBuckets = hasBuckets;
    }

    public String getServicePlanId() {
        return servicePlanId;
    }

    public void setServicePlanId(String servicePlanId) {
        this.servicePlanId = servicePlanId;
    }

    public String getIgTransInProgress() {
        return igTransInProgress;
    }

    public void setIgTransInProgress(String igTransInProgress) {
        this.igTransInProgress = igTransInProgress;
    }

    public String getIgFailLogs() {
        return igFailLogs;
    }

    public void setIgFailLogs(String igFailLogs) {
        this.igFailLogs = igFailLogs;
    }

    public Map<String, String> getAdditionalDbColumns() {
        return additionalDbColumns;
    }

    public String geteSimFlag() {
        return eSimFlag;
    }

    public void seteSimFlag(String eSimFlag) {
        this.eSimFlag = eSimFlag;
    }

    public void setAdditionalDbColumns(Map<String, String> additionalDbColumns) {
        this.additionalDbColumns = additionalDbColumns;
    }
}